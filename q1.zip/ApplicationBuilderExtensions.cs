using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;
using new_assistant.Infrastructure.Middleware;
using new_assistant.Infrastructure.Services;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace new_assistant.Infrastructure.Extensions;

/// <summary>
/// Extension методы для настройки middleware pipeline
/// </summary>
public static class ApplicationBuilderExtensions
{
    /// <summary>
    /// Настройка корреляции ID и глобального обработчика исключений
    /// </summary>
    public static IApplicationBuilder UseCustomExceptionHandling(this IApplicationBuilder app)
    {
        app.UseMiddleware<CorrelationIdMiddleware>();
        
        // UseExceptionHandler() автоматически использует зарегистрированный IExceptionHandler (ASP.NET Core 8+)
        // GlobalExceptionHandler должен быть зарегистрирован через AddExceptionHandler в ServiceCollectionExtensions
        app.UseExceptionHandler();

        return app;
    }

    /// <summary>
    /// Настройка Forwarded Headers (настройка выполняется в ServiceCollectionExtensions)
    /// </summary>
    public static IApplicationBuilder UseCustomForwardedHeaders(this IApplicationBuilder app)
    {
        app.UseForwardedHeaders();
        return app;
    }

    /// <summary>
    /// Настройка HTTPS и HSTS
    /// HTTPS обрабатывается балансировщиком нагрузки, поэтому не используем редиректы
    /// </summary>
    public static IApplicationBuilder UseCustomHttps(this IApplicationBuilder app, IWebHostEnvironment environment)
    {
        // HTTPS обрабатывается балансировщиком нагрузки на уровне инфраструктуры
        // Не используем UseHttpsRedirection и UseHsts, так как приложение работает только на HTTP
        // Балансировщик будет обрабатывать HTTPS и проксировать запросы на HTTP порт приложения

        return app;
    }

    /// <summary>
    /// Настройка Cookie Policy
    /// </summary>
    public static IApplicationBuilder UseCustomCookiePolicy(this IApplicationBuilder app)
    {
        app.UseCookiePolicy();

        return app;
    }

    /// <summary>
    /// Настройка Rate Limiting (настройка выполняется в ServiceCollectionExtensions)
    /// </summary>
    public static IApplicationBuilder UseCustomRateLimiting(this IApplicationBuilder app)
    {
        var rateLimitingSettings = app.ApplicationServices.GetRequiredService<IOptions<RateLimitingSettings>>().Value;
        var loggerFactory = app.ApplicationServices.GetService<ILoggerFactory>();
        var logger = loggerFactory?.CreateLogger("ApplicationBuilderExtensions");
        
        if (rateLimitingSettings.Enabled)
        {
            app.UseRateLimiter();
            logger?.LogInformation(
                "Rate limiting enabled: Auth={AuthLimit}/min, API={ApiLimit}/min, Admin={AdminLimit}/min",
                rateLimitingSettings.AuthRequestsPerMinute,
                rateLimitingSettings.ApiRequestsPerMinute,
                rateLimitingSettings.AdminApiRequestsPerMinute);
        }
        else
        {
            logger?.LogWarning("Rate limiting is disabled. This is not recommended for production environments.");
        }
        
        return app;
    }

    /// <summary>
    /// Настройка Authentication и Authorization
    /// </summary>
    public static IApplicationBuilder UseCustomAuthentication(this IApplicationBuilder app)
    {
        app.UseAuthentication();
        app.UseAuthorization();

        return app;
    }

    /// <summary>
    /// Настройка Security Headers (CSP, X-Frame-Options, и т.д.)
    /// </summary>
    public static IApplicationBuilder UseCustomSecurityHeaders(this IApplicationBuilder app)
    {
        try
        {
            // Проверяем, что конфигурация зарегистрирована
            // Детальная валидация будет выполнена в конструкторе SecurityHeadersMiddleware
            var keycloakAuthSettings = app.ApplicationServices.GetRequiredService<IOptions<KeycloakAuthenticationSettings>>().Value;
            
            if (keycloakAuthSettings == null)
            {
                throw new InvalidOperationException(
                    "Keycloak configuration is missing. " +
                    "Ensure that KeycloakAuthenticationSettings is registered via AddApplicationSettings.");
            }
        }
        catch (InvalidOperationException)
        {
            throw; // Пробрасываем дальше
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                "Failed to configure security headers. Ensure KeycloakAuthenticationSettings is properly registered.",
                ex);
        }

        app.UseMiddleware<SecurityHeadersMiddleware>();
        return app;
    }

    /// <summary>
    /// Настройка маршрутизации для Blazor и API
    /// </summary>
    public static WebApplication UseCustomRouting(this WebApplication app)
    {
        app.UseStaticFiles();
        app.MapControllers();

        // Получаем версию из Assembly
        var version = typeof(ApplicationBuilderExtensions).Assembly
            .GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion
            ?? typeof(ApplicationBuilderExtensions).Assembly.GetName()?.Version?.ToString()
            ?? "1.0.0";

        app.MapGet("/api", () => new
        {
            Message = "KeyCloak Assistant API",
            Version = version,
            Timestamp = DateTime.UtcNow,
            Endpoints = new[]
            {
                "/api/health - Health check",
            }
        });

        app.MapBlazorHub();
        app.MapFallbackToPage("/_Host");

        return app;
    }
    
    /// <summary>
    /// Альтернативный метод для использования с IApplicationBuilder (для маршрутизации используйте UseCustomRouting с WebApplication)
    /// </summary>
    public static IApplicationBuilder UseCustomStaticFiles(this IApplicationBuilder app)
    {
        app.UseStaticFiles();
        return app;
    }

    /// <summary>
    /// Настройка cleanup для Singleton сервисов с IDisposable
    /// </summary>
    public static IApplicationBuilder UseCustomCleanup(this IApplicationBuilder app)
    {
        var lifetime = app.ApplicationServices.GetRequiredService<IHostApplicationLifetime>();
        
        // Сохраняем ссылки на SINGLETON сервисы заранее, до ApplicationStopping
        // Это гарантирует, что сервисы будут доступны во время остановки приложения
        // ВАЖНО: Scoped сервисы (KeycloakHttpClient, IKeycloakStageHttpClient) нельзя получить из root provider
        // Они автоматически освобождаются в конце каждого request scope
        var logger = app.ApplicationServices.GetService<ILogger<Program>>();
        
        // Scoped сервисы нельзя получить из root provider, поэтому оборачиваем в try-catch
        ITokenExchangeService? tokenExchangeService = null;
        IUserMenuService? userMenuService = null;
        try
        {
            tokenExchangeService = app.ApplicationServices.GetService<ITokenExchangeService>();
        }
        catch (InvalidOperationException)
        {
            // Scoped сервисы недоступны из root provider - это нормально, они будут освобождены автоматически
            logger?.LogDebug("ITokenExchangeService is scoped and cannot be resolved from root provider");
        }
        
        try
        {
            userMenuService = app.ApplicationServices.GetService<IUserMenuService>();
        }
        catch (InvalidOperationException)
        {
            // Scoped сервисы недоступны из root provider - это нормально, они будут освобождены автоматически
            logger?.LogDebug("IUserMenuService is scoped and cannot be resolved from root provider");
        }
        
        lifetime.ApplicationStopping.Register(() =>
        {
            var servicesToDispose = new List<object>();

            try
            {
                // Используем сохраненные ссылки только для Singleton сервисов
                // KeycloakHttpClient и IKeycloakStageHttpClient теперь Scoped и освобождаются автоматически
                if (tokenExchangeService != null) servicesToDispose.Add(tokenExchangeService);
                if (userMenuService != null) servicesToDispose.Add(userMenuService);

                // Освобождаем ресурсы
                foreach (var service in servicesToDispose)
                {
                    try
                    {
                        if (service is IAsyncDisposable asyncDisposable)
                        {
                            // Используем GetAwaiter().GetResult() для синхронного вызова в Register
                            asyncDisposable.DisposeAsync().GetAwaiter().GetResult();
                        }
                        else if (service is IDisposable disposable)
                        {
                            disposable.Dispose();
                        }
                    }
                    catch (Exception ex)
                    {
                        logger?.LogWarning(ex, "Ошибка при освобождении ресурса {ServiceType}", service.GetType().Name);
                    }
                }
            }
            catch (Exception ex)
            {
                logger?.LogError(ex, "Критическая ошибка при освобождении ресурсов при остановке приложения");
            }
        });

        return app;
    }
}

