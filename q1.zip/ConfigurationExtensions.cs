using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.DataProtection.AuthenticatedEncryption;
using Microsoft.AspNetCore.DataProtection.AuthenticatedEncryption.ConfigurationModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using new_assistant.Configuration;
using Serilog;
using System;
using System.IO;
using System.Linq;
using System.Net.Sockets;

namespace new_assistant.Infrastructure.Extensions;

/// <summary>
/// Extension методы для конфигурации приложения
/// </summary>
public static class ConfigurationExtensions
{
    /// <summary>
    /// Настройка Kestrel для HTTP/HTTPS
    /// </summary>
    /// <param name="builder">WebHost builder для настройки</param>
    /// <param name="configuration">Конфигурация приложения</param>
    /// <returns>WebHost builder для цепочки вызовов</returns>
    /// <exception cref="InvalidOperationException">Выбрасывается при ошибках конфигурации в Production</exception>
    public static IWebHostBuilder ConfigureKestrelServer(this IWebHostBuilder builder, IConfiguration configuration)
    {
        // Отключаем автоматическое определение портов через UseUrls
        builder.UseUrls(); // Очищаем дефолтные URLs

        builder.ConfigureKestrel((context, options) =>
        {
            // Получаем logger через конфигурацию или создаем временный
            // В .NET 9 WebHostBuilderContext не имеет свойства Services напрямую
            // Используем временный logger, так как сервисы еще не доступны на этом этапе
            var logger = CreateEarlyLogger();

            // Получаем HTTP порт из конфигурации с дефолтным значением 8888
            // HTTPS обрабатывается балансировщиком нагрузки, поэтому не настраиваем его здесь
            var httpPort = configuration.GetValue<int>("Kestrel:Endpoints:Http:Port", 8888);

            // Валидация порта
            ValidatePort(httpPort, "HTTP", logger);

            // Опциональная проверка доступности порта (предупреждение, не ошибка)
            if (!IsPortAvailable(httpPort))
            {
                logger?.LogWarning("HTTP порт {HttpPort} может быть занят. Приложение попытается использовать его при старте.", httpPort);
            }

            // Настройка HTTP порта (HTTPS обрабатывается балансировщиком нагрузки)
            options.ListenAnyIP(httpPort);
            logger?.LogInformation("HTTP сервер настроен на порт: {HttpPort}. HTTPS обрабатывается балансировщиком нагрузки.", httpPort);
        });

        return builder;
    }

    /// <summary>
    /// Пытается настроить HTTPS сертификат из конфигурации или переменных окружения
    /// </summary>
    /// <param name="options">Опции Kestrel сервера</param>
    /// <param name="configuration">Конфигурация приложения</param>
    /// <param name="httpsPort">HTTPS порт</param>
    /// <param name="logger">Логгер для записи событий</param>
    /// <returns>true, если сертификат успешно настроен; false в противном случае</returns>
    private static bool TryConfigureHttpsCertificate(
        KestrelServerOptions options,
        IConfiguration configuration,
        int httpsPort,
        Microsoft.Extensions.Logging.ILogger? logger)
    {
        try
        {
            // Пытаемся получить сертификат из конфигурации
            var certPath = configuration["Kestrel:Certificates:Default:Path"];
            var certPassword = configuration["Kestrel:Certificates:Default:Password"];

            if (!string.IsNullOrEmpty(certPath) && IsValidCertificatePath(certPath))
            {
                if (TryLoadCertificateFromPath(options, certPath, certPassword, httpsPort, logger, "конфигурации"))
                {
                    return true;
                }
            }

            // Fallback: пытаемся получить сертификат из переменных окружения
            var envCertPath = Environment.GetEnvironmentVariable("ASPNETCORE_Kestrel__Certificates__Default__Path");
            var envCertPassword = Environment.GetEnvironmentVariable("ASPNETCORE_Kestrel__Certificates__Default__Password");

            if (!string.IsNullOrEmpty(envCertPath) && IsValidCertificatePath(envCertPath))
            {
                if (TryLoadCertificateFromPath(options, envCertPath, envCertPassword, httpsPort, logger, "переменной окружения"))
                {
                    return true;
                }
            }
        }
        catch (Exception ex)
        {
            logger?.LogError(ex, "Неожиданная ошибка при настройке HTTPS сертификата");
            return false;
        }

        return false;
    }

    /// <summary>
    /// Загружает сертификат из указанного пути
    /// </summary>
    private static bool TryLoadCertificateFromPath(
        KestrelServerOptions options,
        string certPath,
        string? certPassword,
        int httpsPort,
        Microsoft.Extensions.Logging.ILogger? logger,
        string source)
    {
        try
        {
            // Проверка на максимальную длину пути
            if (!IsPathLengthValid(certPath))
            {
                logger?.LogWarning("Путь к сертификату слишком длинный ({Source}): {CertPath}", source, certPath);
                return false;
            }

            // Дополнительная проверка перед использованием (защита от race condition)
            if (!File.Exists(certPath))
            {
                logger?.LogWarning("Файл сертификата не найден ({Source}): {CertPath}", source, certPath);
                return false;
            }

            options.ListenAnyIP(httpsPort, listenOptions =>
            {
                try
                {
                    // Повторная проверка перед использованием (race condition protection)
                    if (!File.Exists(certPath))
                    {
                        throw new FileNotFoundException($"Сертификат был удален после проверки ({source}): {certPath}");
                    }

                    listenOptions.UseHttps(certPath, certPassword ?? string.Empty);
                    logger?.LogInformation("HTTPS сертификат загружен ({Source}): {CertPath}, порт: {HttpsPort}", source, certPath, httpsPort);
                }
                catch (Exception ex)
                {
                    logger?.LogError(ex, "Ошибка при загрузке HTTPS сертификата ({Source}) из {CertPath}", source, certPath);
                    throw;
                }
            });
            return true;
        }
        catch (UnauthorizedAccessException ex)
        {
            logger?.LogError(ex, "Нет доступа к файлу сертификата ({Source}): {CertPath}", source, certPath);
            return false;
        }
        catch (FileNotFoundException ex)
        {
            logger?.LogError(ex, "Файл сертификата не найден ({Source}): {CertPath}", source, certPath);
            return false;
        }
        catch (IOException ex)
        {
            logger?.LogError(ex, "Ошибка ввода-вывода при работе с сертификатом ({Source}): {CertPath}", source, certPath);
            return false;
        }
    }

    /// <summary>
    /// Валидирует порт на корректность диапазона
    /// </summary>
    private static void ValidatePort(int port, string portName, Microsoft.Extensions.Logging.ILogger? logger)
    {
        if (port < 1 || port > 65535)
        {
            var error = $"{portName} порт должен быть в диапазоне 1-65535. Текущее значение: {port}";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }
    }

    /// <summary>
    /// Проверяет валидность пути к сертификату
    /// </summary>
    private static bool IsValidCertificatePath(string? path)
    {
        if (string.IsNullOrWhiteSpace(path))
            return false;

        try
        {
            // Проверка на недопустимые символы
            if (path.IndexOfAny(Path.GetInvalidPathChars()) >= 0)
                return false;

            // Проверка расширения файла
            var extension = Path.GetExtension(path).ToLowerInvariant();
            var allowedExtensions = new[] { ".pfx", ".p12", ".cer", ".crt" };
            if (!allowedExtensions.Contains(extension))
            {
                return false;
            }

            return true;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Проверяет, что длина пути не превышает допустимую
    /// </summary>
    private static bool IsPathLengthValid(string path)
    {
        if (string.IsNullOrEmpty(path))
            return false;

        try
        {
            var fullPath = Path.GetFullPath(path);
            // Windows MAX_PATH ограничение (260 символов)
            const int maxPathLength = 260;
            return fullPath.Length <= maxPathLength;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Проверяет доступность порта (опциональная проверка)
    /// </summary>
    private static bool IsPortAvailable(int port)
    {
        try
        {
            using var listener = new TcpListener(System.Net.IPAddress.Any, port);
            listener.Start();
            listener.Stop();
            return true;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Настройка Serilog для структурированного логирования
    /// </summary>
    /// <param name="builder">Host builder для настройки</param>
    /// <returns>Host builder для цепочки вызовов</returns>
    public static IHostBuilder ConfigureSerilog(this IHostBuilder builder)
    {
        // Получаем настройку preserveStaticLogger из конфигурации до вызова UseSerilog
        // IHostBuilder не имеет метода GetSetting в .NET 9
        // Значение будет получено позже через IConfiguration в UseSerilog
        // Используем значение по умолчанию false
        var preserveStaticLogger = false;

        builder.UseSerilog((context, configuration) =>
        {
            try
            {
                // Получаем часовой пояс из конфигурации
                var timeZoneId = context.Configuration.GetValue<string>("Serilog:TimeZone", "Europe/Moscow");
                string timeZoneString = "UTC";

                try
                {
                    var timeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZoneId);
                    var timeZoneOffset = timeZone.GetUtcOffset(DateTimeOffset.Now);
                    timeZoneString = $"UTC{(timeZoneOffset >= TimeSpan.Zero ? "+" : "")}{timeZoneOffset:hh\\:mm}";
                }
                catch (TimeZoneNotFoundException)
                {
                    // Fallback к UTC, если часовой пояс не найден
                    timeZoneString = "UTC";
                    LogEarly($"ПРЕДУПРЕЖДЕНИЕ: Часовой пояс '{timeZoneId}' не найден. Используется UTC.");
                }

                // Получаем путь к логам из конфигурации
                var dataPathsSettings = context.Configuration.GetSection("DataPaths").Get<DataPathsSettings>() ?? new DataPathsSettings();
                var logsDirectory = dataPathsSettings.GetLogsDirectoryPath();

                // Убеждаемся, что директория существует
                try
                {
                    dataPathsSettings.EnsureDirectoriesExist();
                }
                catch (Exception ex)
                {
                    // Если не удалось создать директорию, используем временную
                    logsDirectory = Path.GetTempPath();
                    LogEarly($"ОШИБКА: Не удалось создать директорию логов. Используется временная: {logsDirectory}. {ex.Message}");
                }

                var logFilePath = Path.Combine(logsDirectory, "audit-.log");

                configuration
                    .ReadFrom.Configuration(context.Configuration)
                    .Enrich.FromLogContext()
                    .Enrich.WithProperty("Application", "KeycloakAssistant")
                    .Enrich.WithProperty("TimeZone", timeZoneString)
                    .WriteTo.Console()
                    .WriteTo.File(
                        path: logFilePath,
                        rollingInterval: RollingInterval.Day,
                        retainedFileCountLimit: 30,
                        outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] {Message:lj}{NewLine}{Exception}");
            }
            catch (Exception ex)
            {
                // Fallback к базовой конфигурации
                LogEarly($"ОШИБКА при настройке Serilog: {ex.Message}");
                LogEarly($"Stack trace: {ex.StackTrace}");
                
                try
                {
                    var fallbackLogPath = Path.Combine(Path.GetTempPath(), "logs", "fallback-.log");
                    var fallbackLogDir = Path.GetDirectoryName(fallbackLogPath);

                    if (string.IsNullOrEmpty(fallbackLogDir))
                    {
                        // Fallback к корневой директории temp
                        fallbackLogDir = Path.GetTempPath();
                        fallbackLogPath = Path.Combine(fallbackLogDir, "fallback-.log");
                    }

                    if (!Directory.Exists(fallbackLogDir))
                    {
                        Directory.CreateDirectory(fallbackLogDir);
                    }

                    configuration
                        .WriteTo.Console()
                        .WriteTo.File(
                            path: fallbackLogPath,
                            rollingInterval: RollingInterval.Day,
                            retainedFileCountLimit: 7,
                            outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] {Message:lj}{NewLine}{Exception}");
                }
                catch (Exception fallbackEx)
                {
                    // Последний fallback - только консоль
                    LogEarly($"КРИТИЧЕСКАЯ ОШИБКА: Не удалось настроить даже fallback логирование: {fallbackEx.Message}");
                    configuration.WriteTo.Console();
                }
            }
        }, preserveStaticLogger: preserveStaticLogger);

        return builder;
    }

    /// <summary>
    /// Настройка Data Protection для корректной работы с cookie
    /// </summary>
    /// <param name="services">Коллекция сервисов</param>
    /// <param name="configuration">Конфигурация приложения</param>
    /// <returns>Коллекция сервисов для цепочки вызовов</returns>
    /// <exception cref="InvalidOperationException">Выбрасывается при ошибках конфигурации или создания директории</exception>
    public static IServiceCollection AddDataProtectionConfiguration(this IServiceCollection services, IConfiguration configuration)
    {
        var dataPathsSettings = configuration.GetSection("DataPaths").Get<DataPathsSettings>() ?? new DataPathsSettings();

        // Валидация настроек
        if (string.IsNullOrWhiteSpace(dataPathsSettings.DataDirectory))
        {
            throw new InvalidOperationException(
                "DataPaths:DataDirectory не может быть пустым. Проверьте конфигурацию в appsettings.json.");
        }

        // Получаем абсолютный путь к директории данных
        var dataDirectoryPath = dataPathsSettings.GetDataDirectoryPath();
        var keysDirectory = Path.Combine(dataDirectoryPath, "keys");

        // Проверка на path traversal (защита от выхода за пределы директории данных)
        var fullDataPath = Path.GetFullPath(dataDirectoryPath);
        var fullKeysPath = Path.GetFullPath(keysDirectory);
        if (!fullKeysPath.StartsWith(fullDataPath, StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(
                $"Недопустимый путь для директории ключей: {keysDirectory}. Путь должен находиться внутри DataDirectory.");
        }

        var keysDirectoryInfo = new DirectoryInfo(keysDirectory);

        try
        {
            // Убеждаемся, что директория существует
            if (!keysDirectoryInfo.Exists)
            {
                keysDirectoryInfo.Create();
                LogEarly($"ИНФОРМАЦИЯ: Создана директория для ключей Data Protection: {keysDirectory}");
            }
        }
        catch (Exception ex)
        {
            var errorMessage = $"Не удалось создать директорию для ключей Data Protection: {keysDirectory}";
            LogEarly($"ОШИБКА: {errorMessage}. {ex.Message}");
            throw new InvalidOperationException(errorMessage, ex);
        }

        // Получаем время жизни ключа из конфигурации
        var keyLifetimeDays = configuration.GetValue<int>("DataProtection:KeyLifetimeDays", 90);
        if (keyLifetimeDays <= 0)
        {
            LogEarly($"ПРЕДУПРЕЖДЕНИЕ: Недопустимое значение DataProtection:KeyLifetimeDays: {keyLifetimeDays}. Используется значение по умолчанию: 90");
            keyLifetimeDays = 90;
        }
        else if (keyLifetimeDays > 365)
        {
            LogEarly($"ПРЕДУПРЕЖДЕНИЕ: Значение DataProtection:KeyLifetimeDays слишком большое: {keyLifetimeDays}. Рекомендуется не более 365 дней. Используется 365.");
            keyLifetimeDays = 365;
        }

        services.AddDataProtection()
            .SetApplicationName("KeyCloakAssistant")
            .PersistKeysToFileSystem(keysDirectoryInfo)
            .SetDefaultKeyLifetime(TimeSpan.FromDays(keyLifetimeDays))
            .UseCryptographicAlgorithms(new AuthenticatedEncryptorConfiguration()
            {
                EncryptionAlgorithm = EncryptionAlgorithm.AES_256_CBC,
                ValidationAlgorithm = ValidationAlgorithm.HMACSHA256
            });

        LogEarly($"ИНФОРМАЦИЯ: Data Protection настроен. Директория ключей: {keysDirectory}, Время жизни ключа: {keyLifetimeDays} дней");

        return services;
    }

    /// <summary>
    /// Валидация критических настроек на раннем этапе
    /// </summary>
    /// <param name="configuration">Конфигурация приложения</param>
    /// <param name="logger">Логгер для записи ошибок (опционально)</param>
    /// <exception cref="InvalidOperationException">Выбрасывается при отсутствии или невалидности критических настроек</exception>
    public static void ValidateCriticalSettings(IConfiguration configuration, Microsoft.Extensions.Logging.ILogger? logger = null)
    {
        // Валидация Keycloak Authentication настроек
        var keycloakAuthSettings = configuration
            .GetSection("Authentication:Keycloak")
            .Get<KeycloakAuthenticationSettings>();

        if (keycloakAuthSettings == null)
        {
            var error = "Keycloak configuration is missing. Check the Authentication:Keycloak section in appsettings.json.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Валидация конкретных свойств Keycloak Authentication
        if (string.IsNullOrWhiteSpace(keycloakAuthSettings.Authority))
        {
            var error = "Keycloak Authority is not configured or is empty. Check Authentication:Keycloak:Authority in appsettings.json.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        if (!Uri.TryCreate(keycloakAuthSettings.Authority, UriKind.Absolute, out var authorityUri))
        {
            var error = $"Keycloak Authority is not a valid URI: {keycloakAuthSettings.Authority}. Check Authentication:Keycloak:Authority in appsettings.json.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Проверка схемы URI
        if (authorityUri.Scheme != Uri.UriSchemeHttp && authorityUri.Scheme != Uri.UriSchemeHttps)
        {
            var error = $"Keycloak Authority must use HTTP or HTTPS scheme. Current scheme: {authorityUri.Scheme}";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Предупреждение для HTTP в production
        if (authorityUri.Scheme == Uri.UriSchemeHttp)
        {
            logger?.LogWarning("Keycloak Authority использует HTTP вместо HTTPS. Это небезопасно для production окружения.");
        }

        if (string.IsNullOrWhiteSpace(keycloakAuthSettings.ClientId))
        {
            var error = "Keycloak ClientId is not configured or is empty. Check Authentication:Keycloak:ClientId in appsettings.json.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // ClientSecret может быть пустым для public клиентов, но обычно требуется
        // Проверяем только предупреждением, не ошибкой
        if (string.IsNullOrWhiteSpace(keycloakAuthSettings.ClientSecret))
        {
            logger?.LogWarning("Keycloak ClientSecret is not configured. This may be intentional for public clients, but is unusual.");
        }

        // Валидация Keycloak Admin настроек
        var keycloakAdminSettings = configuration
            .GetSection("KeycloakAdmin")
            .Get<KeycloakAdminSettings>();

        if (keycloakAdminSettings == null)
        {
            var error = "Keycloak Admin configuration is missing. Check the KeycloakAdmin section in appsettings.json.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Валидация конкретных свойств Keycloak Admin
        if (string.IsNullOrWhiteSpace(keycloakAdminSettings.BaseUrl))
        {
            var error = "KeycloakAdmin BaseUrl is not configured or is empty. Check KeycloakAdmin:BaseUrl in appsettings.json.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        if (!Uri.TryCreate(keycloakAdminSettings.BaseUrl, UriKind.Absolute, out var baseUrlUri))
        {
            var error = $"KeycloakAdmin BaseUrl is not a valid URI: {keycloakAdminSettings.BaseUrl}. Check KeycloakAdmin:BaseUrl in appsettings.json.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Проверка схемы URI
        if (baseUrlUri.Scheme != Uri.UriSchemeHttp && baseUrlUri.Scheme != Uri.UriSchemeHttps)
        {
            var error = $"KeycloakAdmin BaseUrl must use HTTP or HTTPS scheme. Current scheme: {baseUrlUri.Scheme}";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Предупреждение для HTTP в production
        if (baseUrlUri.Scheme == Uri.UriSchemeHttp)
        {
            logger?.LogWarning("KeycloakAdmin BaseUrl использует HTTP вместо HTTPS. Это небезопасно для production окружения.");
        }

        if (string.IsNullOrWhiteSpace(keycloakAdminSettings.Realm))
        {
            var error = "KeycloakAdmin Realm is not configured or is empty. Check KeycloakAdmin:Realm in appsettings.json.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        if (string.IsNullOrWhiteSpace(keycloakAdminSettings.ClientId))
        {
            var error = "KeycloakAdmin ClientId is not configured or is empty. Check KeycloakAdmin:ClientId in appsettings.json.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        if (string.IsNullOrWhiteSpace(keycloakAdminSettings.ClientSecret))
        {
            var error = "KeycloakAdmin ClientSecret is not configured or is empty. Check KeycloakAdmin:ClientSecret in appsettings.json.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Валидация RequestTimeoutSeconds
        if (keycloakAdminSettings.RequestTimeoutSeconds <= 0)
        {
            var error = $"KeycloakAdmin RequestTimeoutSeconds must be greater than 0. Current value: {keycloakAdminSettings.RequestTimeoutSeconds}. Check KeycloakAdmin:RequestTimeoutSeconds in appsettings.json.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Валидация MaxSearchResults
        if (keycloakAdminSettings.MaxSearchResults <= 0)
        {
            var error = $"KeycloakAdmin MaxSearchResults must be greater than 0. Current value: {keycloakAdminSettings.MaxSearchResults}. Check KeycloakAdmin:MaxSearchResults in appsettings.json.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Валидация MaxConcurrentRequests
        if (keycloakAdminSettings.MaxConcurrentRequests <= 0)
        {
            var error = $"KeycloakAdmin MaxConcurrentRequests must be greater than 0. Current value: {keycloakAdminSettings.MaxConcurrentRequests}. Check KeycloakAdmin:MaxConcurrentRequests in appsettings.json.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        logger?.LogInformation("Критические настройки успешно валидированы");
    }

    /// <summary>
    /// Создает простой logger для использования на раннем этапе конфигурации
    /// </summary>
    private static Microsoft.Extensions.Logging.ILogger CreateEarlyLogger()
    {
        using var loggerFactory = LoggerFactory.Create(builder =>
        {
            builder
                .AddConsole()
                .SetMinimumLevel(LogLevel.Information);
        });
        return loggerFactory.CreateLogger(typeof(ConfigurationExtensions).FullName ?? "ConfigurationExtensions");
    }

    /// <summary>
    /// Логирует сообщение на раннем этапе (когда Serilog еще не настроен)
    /// </summary>
    private static void LogEarly(string message)
    {
        try
        {
            using var loggerFactory = LoggerFactory.Create(builder =>
            {
                builder
                    .AddConsole()
                    .SetMinimumLevel(LogLevel.Information);
            });
            var logger = loggerFactory.CreateLogger(typeof(ConfigurationExtensions).FullName ?? "ConfigurationExtensions");
            
            // Определяем уровень логирования по префиксу
            if (message.StartsWith("КРИТИЧЕСКАЯ ОШИБКА") || message.StartsWith("ОШИБКА"))
            {
                logger.LogError(message);
            }
            else if (message.StartsWith("ПРЕДУПРЕЖДЕНИЕ"))
            {
                logger.LogWarning(message);
            }
            else
            {
                logger.LogInformation(message);
            }
        }
        catch
        {
            // Последний fallback - Console
            Console.WriteLine(message);
        }
    }
}

