using Microsoft.Extensions.Logging;
using new_assistant.Core.Constants;
using new_assistant.Core.Interfaces;
using new_assistant.Infrastructure.Services;

namespace new_assistant.Pages.ClientDetails;

/// <summary>
/// Единый обработчик ошибок для компонента ClientDetails
/// </summary>
public static class ClientDetailsErrorHandler
{
    /// <summary>
    /// Обработать ошибку с логированием и возвратом понятного сообщения для пользователя
    /// </summary>
    public static (string UserMessage, string LogMessage) HandleError(
        Exception ex,
        ILogger logger,
        string operation,
        string? context = null)
    {
        var logMessage = context != null
            ? $"Ошибка при {operation} (контекст: {context})"
            : $"Ошибка при {operation}";

        // Логируем полную информацию об ошибке
        logger.LogError(ex, logMessage);

        // Возвращаем понятное сообщение для пользователя
        var userMessage = ex switch
        {
            ArgumentException => $"Некорректные параметры: {ex.Message}",
            InvalidOperationException => $"Операция не может быть выполнена: {ex.Message}",
            UnauthorizedAccessException => "Недостаточно прав для выполнения операции",
            TimeoutException => "Операция превысила время ожидания. Попробуйте позже.",
            System.Net.Http.HttpRequestException => "Ошибка при обращении к серверу. Проверьте подключение.",
            TaskCanceledException => "Операция была отменена",
            _ => $"Произошла ошибка при {operation}. Обратитесь к администратору."
        };

        return (userMessage, logMessage);
    }

    /// <summary>
    /// Обработать ошибку и показать уведомление пользователю
    /// </summary>
    public static async Task HandleAndNotifyAsync(
        Exception ex,
        ILogger logger,
        Func<NotificationType, string, string, Task> showNotificationFunc,
        string operation,
        string? context = null)
    {
        var (userMessage, _) = HandleError(ex, logger, operation, context);
        await showNotificationFunc(
            NotificationType.Error,
            "Ошибка",
            userMessage).ConfigureAwait(false);
    }
}

