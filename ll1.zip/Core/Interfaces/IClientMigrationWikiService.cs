namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс сервиса для работы с Wiki страницами при миграции клиентов
/// </summary>
public interface IClientMigrationWikiService
{
    /// <summary>
    /// Извлечь метаданные из Wiki URL
    /// </summary>
    Task<(string PageId, string Title, string Url, bool IsValid)> ExtractWikiMetadataAsync(
        string wikiUrl, 
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Обновить или создать Wiki страницу в репозитории
    /// </summary>
    Task<string?> UpdateWikiPageInRepositoryAsync(
        string clientId,
        string? wikiUrl,
        string migratedBy,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Обновить Wiki страницу в Confluence
    /// </summary>
    Task<string?> UpdateWikiPageInConfluenceAsync(
        Core.DTOs.ClientDetailsDto clientDetails,
        string migratedBy,
        CancellationToken cancellationToken = default);
}

