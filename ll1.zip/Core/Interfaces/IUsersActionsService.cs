namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для сервиса выполнения действий с пользователями через users-management API
/// </summary>
public interface IUsersActionsService
{
    /// <summary>
    /// Снять блокировку брутфорса для пользователя
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>true, если операция выполнена успешно, иначе false</returns>
    Task<bool> RemoveBruteForceStatusAsync(
        string accessToken,
        string realm,
        string userId,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Выполнить действия через email для пользователя (например, обновление пароля, конфигурация OTP)
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="actions">Список действий для выполнения</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>true, если операция выполнена успешно, иначе false</returns>
    Task<bool> ExecuteActionsEmailAsync(
        string accessToken,
        string realm,
        string userId,
        List<string> actions,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Заблокировать пользователя
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="reason">Причина блокировки</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>true, если блокировка выполнена успешно, иначе false</returns>
    Task<bool> BlockUserAsync(
        string accessToken,
        string realm,
        string userId,
        string reason,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Разблокировать пользователя
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="reason">Причина разблокировки</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>true, если разблокировка выполнена успешно, иначе false</returns>
    Task<bool> UnblockUserAsync(
        string accessToken,
        string realm,
        string userId,
        string reason,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
}

