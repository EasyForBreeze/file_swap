using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для работы с Keycloak STAGE контуром
/// </summary>
public interface IKeycloakStageService
{
    /// <summary>
    /// Получить список реалмов в STAGE (кроме master)
    /// </summary>
    Task<IEnumerable<string>> GetRealmsListAsync(CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Проверить существование клиента в STAGE realm
    /// </summary>
    Task<bool> ClientExistsAsync(string clientId, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Создать клиента в STAGE realm
    /// </summary>
    Task<string> CreateClientAsync(ClientDetailsDto clientDetails, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить Client Secret для клиента в STAGE
    /// </summary>
    Task<string?> GetClientSecretAsync(string clientInternalId, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Проверить существование realm role в STAGE
    /// </summary>
    Task<bool> RealmRoleExistsAsync(string roleName, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Проверить существование client role в STAGE
    /// </summary>
    Task<bool> ClientRoleExistsAsync(string clientId, string roleName, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Создать локальные роли клиента в STAGE
    /// </summary>
    Task CreateClientRolesAsync(string clientInternalId, List<string> roleNames, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Назначить realm roles для service account в STAGE
    /// </summary>
    Task AssignRealmRolesToServiceAccountAsync(string clientInternalId, List<string> roleNames, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Назначить client roles для service account в STAGE
    /// </summary>
    Task AssignClientRolesToServiceAccountAsync(string clientInternalId, string targetClientId, List<string> roleNames, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Проверить существование client scope в STAGE
    /// </summary>
    Task<bool> ClientScopeExistsAsync(string scopeName, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Проверить существование authentication flow в STAGE
    /// </summary>
    Task<bool> AuthenticationFlowExistsAsync(string flowAlias, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Копировать protocol mappers в STAGE клиент
    /// </summary>
    Task CopyProtocolMappersAsync(string clientInternalId, List<System.Text.Json.JsonElement> mappers, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Назначить client scopes клиенту в STAGE
    /// </summary>
    Task AssignClientScopesAsync(string clientInternalId, List<string> scopeNames, string realm, bool isDefault, CancellationToken cancellationToken = default);
}

