using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Билдер для генерации контента страниц Confluence
/// </summary>
public interface IConfluencePageBuilder
{
    /// <summary>
    /// Построить контент страницы для создания
    /// </summary>
    string BuildPageContent(ClientCreationData data);

    /// <summary>
    /// Обновить контент страницы на основе существующего контента
    /// </summary>
    Task<string> UpdatePageContent(ClientDetailsDto details, string currentContent);

    /// <summary>
    /// Построить префикс realm
    /// </summary>
    string BuildRealmPrefix(string? realm);
}

