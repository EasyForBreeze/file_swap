using new_assistant.Core.Entities;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Репозиторий для управления связями клиентов и Wiki страниц
/// </summary>
public interface IWikiPageRepository
{
    /// <summary>
    /// Сохранить информацию о Wiki странице для клиента
    /// </summary>
    Task<int> SaveWikiPageAsync(ClientWikiPage wikiPage);

    /// <summary>
    /// Получить информацию о Wiki странице по Client ID и Realm
    /// </summary>
    Task<ClientWikiPage?> GetWikiPageByClientAsync(string clientId, string realm);

    /// <summary>
    /// Получить информацию о Wiki странице по Client ID вне зависимости от realm
    /// </summary>
    Task<ClientWikiPage?> GetWikiPageAnyRealmAsync(string clientId);

    /// <summary>
    /// Обновить информацию о Wiki странице
    /// </summary>
    Task UpdateWikiPageAsync(ClientWikiPage wikiPage);

    /// <summary>
    /// Обновить статус Wiki страницы (например, пометить как Archived)
    /// </summary>
    Task UpdateWikiPageStatusAsync(string clientId, string realm, string status);

    /// <summary>
    /// Удалить запись о Wiki странице
    /// </summary>
    Task DeleteWikiPageAsync(string clientId, string realm);

    /// <summary>
    /// Проверить, существует ли Wiki страница для клиента
    /// </summary>
    Task<bool> WikiPageExistsAsync(string clientId, string realm);
}

