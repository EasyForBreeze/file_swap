namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для генерации примеров токенов Keycloak
/// </summary>
public interface IKeycloakTokenExamplesService
{
    /// <summary>
    /// Генерация example access token для пользователя
    /// </summary>
    Task<string> GenerateExampleAccessTokenAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Генерация example ID token для пользователя
    /// </summary>
    Task<string> GenerateExampleIdTokenAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Генерация example userinfo для пользователя
    /// </summary>
    Task<string> GenerateExampleUserInfoAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default);
}

