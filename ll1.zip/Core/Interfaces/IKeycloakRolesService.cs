using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для управления ролями Keycloak
/// </summary>
public interface IKeycloakRolesService
{
    /// <summary>
    /// Синхронизировать локальные роли клиента с Keycloak
    /// </summary>
    Task SyncClientLocalRolesAsync(string clientId, string realm, string internalId, List<string> currentRoles, List<string> newRoles, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Синхронизировать service account роли с Keycloak
    /// </summary>
    Task SyncServiceAccountRolesAsync(string clientId, string realm, string internalId, List<string> currentRoles, List<string> newRoles, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Поиск ролей для Service Account (realm + client roles)
    /// </summary>
    Task<(List<RoleSearchResult> Roles, List<ClientWithRoles> Clients)> SearchRolesForServiceAccountAsync(string realm, string clientInternalId, string searchTerm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Поиск ролей для нового клиента (без clientInternalId)
    /// </summary>
    Task<(List<RoleSearchResult> Roles, List<ClientWithRoles> Clients)> SearchRolesForNewClientAsync(string realm, string searchTerm, CancellationToken cancellationToken = default);
}

