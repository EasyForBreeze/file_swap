namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для мониторинга производительности SQLite операций
/// </summary>
public interface ISqlitePerformanceMonitor
{
    /// <summary>
    /// Записать время выполнения операции в статистику
    /// </summary>
    /// <param name="databaseName">Название БД (например, "audit", "wiki_pages", "forbidden_clients")</param>
    /// <param name="elapsedMs">Время выполнения в миллисекундах</param>
    void RecordOperation(string databaseName, long elapsedMs);
    
    /// <summary>
    /// Получить общую статистику по всем SQLite БД
    /// </summary>
    (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetTotalStats();
    
    /// <summary>
    /// Получить статистику по конкретной БД
    /// </summary>
    (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetDatabaseStats(string databaseName);
    
    /// <summary>
    /// Получить статистику по всем БД
    /// </summary>
    Dictionary<string, (long TotalTimeMs, long RequestCount, double AverageTimeMs)> GetAllDatabaseStats();
    
    /// <summary>
    /// Сбросить всю статистику
    /// </summary>
    void ResetAllStats();
    
    /// <summary>
    /// Сбросить статистику конкретной БД
    /// </summary>
    void ResetDatabaseStats(string databaseName);
}

