using System.Globalization;
using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Провайдер шаблонов для страниц Confluence
/// </summary>
public interface IConfluenceTemplateProvider
{
    /// <summary>
    /// Получить шаблон по умолчанию
    /// </summary>
    TemplatePayload Template { get; }
    
    /// <summary>
    /// Получить шаблон по имени
    /// </summary>
    /// <param name="templateName">Имя шаблона (null для шаблона по умолчанию)</param>
    /// <param name="culture">Культура для локализации (null для текущей культуры)</param>
    /// <returns>Шаблон или шаблон по умолчанию, если указанный не найден</returns>
    TemplatePayload GetTemplate(string? templateName = null, string? culture = null);
    
    /// <summary>
    /// Получить шаблон по умолчанию для указанной культуры
    /// </summary>
    /// <param name="culture">Культура для локализации (null для текущей культуры)</param>
    /// <returns>Шаблон для указанной культуры</returns>
    TemplatePayload GetTemplateForCulture(string? culture = null);
    
    /// <summary>
    /// Проверить существование шаблона
    /// </summary>
    /// <param name="templateName">Имя шаблона</param>
    /// <param name="culture">Культура для локализации (null для текущей культуры)</param>
    /// <returns>true, если шаблон существует</returns>
    bool TemplateExists(string templateName, string? culture = null);
    
    /// <summary>
    /// Получить заголовок страницы с подстановкой параметров
    /// </summary>
    /// <param name="realmPrefix">Префикс realm (первые 3 символа)</param>
    /// <param name="clientId">Идентификатор клиента</param>
    /// <param name="templateName">Имя шаблона для получения формата заголовка (null для шаблона по умолчанию)</param>
    /// <returns>Сформированный заголовок страницы</returns>
    string GetTitle(string realmPrefix, string clientId, string? templateName = null);
    
    /// <summary>
    /// Валидировать наличие всех обязательных плейсхолдеров в шаблоне
    /// </summary>
    /// <param name="template">Текст шаблона для валидации</param>
    /// <returns>true, если все обязательные плейсхолдеры присутствуют</returns>
    bool ValidatePlaceholders(string template);
}

