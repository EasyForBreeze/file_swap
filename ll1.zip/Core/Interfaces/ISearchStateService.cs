using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces
{
    /// <summary>
    /// Сервис для управления состоянием поиска клиентов и кэширования данных
    /// </summary>
    /// <remarks>
    /// Сервис обеспечивает изоляцию данных по пользователям, потокобезопасность и защиту от утечек памяти.
    /// Все временные метки используют UTC время.
    /// </remarks>
    public interface ISearchStateService
    {
        /// <summary>
        /// Сохранить состояние поиска для текущего пользователя
        /// </summary>
        /// <param name="searchQuery">Поисковый запрос. Не может быть null или пустой строкой.</param>
        /// <param name="searchResponse">Результат поиска. Может быть null.</param>
        /// <param name="currentPage">Номер текущей страницы. Должен быть больше 0.</param>
        /// <param name="lastSearchTime">Время последнего поиска в UTC. Не может быть в будущем.</param>
        /// <exception cref="ArgumentNullException">Когда searchQuery равен null.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Когда currentPage меньше 1.</exception>
        /// <exception cref="ArgumentException">Когда lastSearchTime в будущем.</exception>
        /// <example>
        /// <code>
        /// searchStateService.SaveSearchState("test", response, 1, DateTime.UtcNow);
        /// </code>
        /// </example>
        void SaveSearchState(string searchQuery, ClientsSearchResponse? searchResponse, int currentPage, DateTime? lastSearchTime);

        /// <summary>
        /// Получить сохраненное состояние поиска для текущего пользователя
        /// </summary>
        /// <returns>Состояние поиска или null, если состояние не сохранено</returns>
        /// <remarks>
        /// Возвращает состояние, изолированное для текущего пользователя.
        /// Если пользователь не аутентифицирован, используется ключ "anonymous".
        /// </remarks>
        SearchState? GetSearchState();

        /// <summary>
        /// Очистить сохраненное состояние
        /// </summary>
        void ClearSearchState();

        /// <summary>
        /// Проверить, есть ли сохраненное состояние
        /// </summary>
        bool HasSavedState();

        /// <summary>
        /// Сохранить список клиентов пользователя в кэш
        /// </summary>
        /// <param name="clients">Список клиентов для кэширования. Не может быть null.</param>
        /// <exception cref="ArgumentNullException">Когда clients равен null.</exception>
        /// <remarks>
        /// Если количество клиентов превышает MaxCacheSize, сохраняются только самые свежие записи (по UpdatedAt).
        /// Кэш изолирован по пользователям.
        /// </remarks>
        void CacheUserClients(List<ClientDetailsDto> clients);

        /// <summary>
        /// Получить кэшированные клиенты пользователя
        /// </summary>
        /// <returns>Копия списка кэшированных клиентов или null, если кэш пуст</returns>
        /// <remarks>
        /// Возвращается копия списка для защиты от модификации исходных данных.
        /// Кэш изолирован по пользователям.
        /// </remarks>
        List<ClientDetailsDto>? GetCachedUserClients();

        /// <summary>
        /// Проверить, актуален ли кэш клиентов для текущего пользователя (не старше указанного времени)
        /// </summary>
        /// <param name="maxAge">Максимальный возраст кэша. Используется UTC время для сравнения.</param>
        /// <returns>true если кэш валиден, иначе false</returns>
        /// <remarks>
        /// Проверка выполняется относительно UTC времени.
        /// </remarks>
        bool IsUserClientsCacheValid(TimeSpan maxAge);

        /// <summary>
        /// Инвалидировать (очистить) кэш клиентов пользователя
        /// </summary>
        void InvalidateUserClientsCache();

        /// <summary>
        /// Событие запроса на обновление списка клиентов
        /// </summary>
        event Action? OnUserClientsRefreshRequested;

        /// <summary>
        /// Запросить принудительное обновление списка клиентов
        /// </summary>
        void RequestUserClientsRefresh();

        /// <summary>
        /// Получить метрики использования кэша
        /// </summary>
        /// <returns>Кортеж с количеством попаданий, промахов и процентом попаданий</returns>
        /// <remarks>
        /// Метрики собираются для всех пользователей. HitRate вычисляется как Hits / (Hits + Misses).
        /// </remarks>
        (long Hits, long Misses, double HitRate) GetCacheMetrics();

        /// <summary>
        /// Сохранить состояние поиска для текущего пользователя (асинхронная версия)
        /// </summary>
        /// <param name="searchQuery">Поисковый запрос. Не может быть null или пустой строкой.</param>
        /// <param name="searchResponse">Результат поиска. Может быть null.</param>
        /// <param name="currentPage">Номер текущей страницы. Должен быть больше 0.</param>
        /// <param name="lastSearchTime">Время последнего поиска в UTC. Не может быть в будущем.</param>
        /// <param name="cancellationToken">Токен отмены операции</param>
        /// <exception cref="ArgumentNullException">Когда searchQuery равен null.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Когда currentPage меньше 1.</exception>
        /// <exception cref="ArgumentException">Когда lastSearchTime в будущем.</exception>
        Task SaveSearchStateAsync(string searchQuery, ClientsSearchResponse? searchResponse, int currentPage, DateTime? lastSearchTime, CancellationToken cancellationToken = default);

        /// <summary>
        /// Получить сохраненное состояние поиска для текущего пользователя (асинхронная версия)
        /// </summary>
        /// <param name="cancellationToken">Токен отмены операции</param>
        /// <returns>Состояние поиска или null, если состояние не сохранено</returns>
        Task<SearchState?> GetSearchStateAsync(CancellationToken cancellationToken = default);
    }
}
