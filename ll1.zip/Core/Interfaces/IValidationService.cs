namespace new_assistant.Core.Interfaces;

/// <summary>
/// Сервис для валидации данных клиентов Keycloak
/// </summary>
public interface IValidationService
{
    /// <summary>
    /// Проверяет валидность имени роли
    /// </summary>
    /// <param name="roleName">Имя роли для проверки</param>
    /// <returns>true, если имя роли валидно</returns>
    bool IsValidRoleName(string? roleName);

    /// <summary>
    /// Проверяет валидность Redirect URI
    /// </summary>
    /// <param name="uri">URI для проверки</param>
    /// <returns>true, если URI валиден</returns>
    bool IsValidRedirectUri(string? uri);
}

