using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для сервиса получения и обновления информации о пользователях через users-management API
/// </summary>
public interface IUsersInfoService
{
    /// <summary>
    /// Получить детальную информацию о пользователе по его ID
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Детальная информация о пользователе или null, если пользователь не найден</returns>
    Task<UserDetailedInfoDto?> GetUserInfoAsync(
        string accessToken,
        string realm,
        string userId,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Обновить информацию о пользователе (имя, фамилия, email)
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="firstName">Имя пользователя (может быть null)</param>
    /// <param name="lastName">Фамилия пользователя (может быть null)</param>
    /// <param name="email">Email пользователя (может быть null)</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>true, если обновление выполнено успешно, иначе false</returns>
    Task<bool> UpdateUserAsync(
        string accessToken,
        string realm,
        string userId,
        string? firstName,
        string? lastName,
        string? email,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Создать нового пользователя в указанном реалме
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="username">Имя пользователя</param>
    /// <param name="firstName">Имя</param>
    /// <param name="lastName">Фамилия</param>
    /// <param name="email">Email</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>true, если создание выполнено успешно, иначе false</returns>
    Task<bool> CreateUserAsync(
        string accessToken,
        string realm,
        string username,
        string firstName,
        string lastName,
        string email,
        CancellationToken cancellationToken = default);
}

