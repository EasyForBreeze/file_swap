namespace new_assistant.Core.Entities;

/// <summary>
/// Сущность запрещенного клиента.
/// Клиенты в этом списке запрещены для взаимодействия обычными пользователями.
/// </summary>
public class ForbiddenClient
{
    /// <summary>
    /// Уникальный идентификатор записи
    /// </summary>
    public int Id { get; set; }
    
    /// <summary>
    /// Client ID из Keycloak
    /// </summary>
    public string ClientId { get; set; } = string.Empty;
    
    /// <summary>
    /// Realm из Keycloak
    /// </summary>
    public string Realm { get; set; } = string.Empty;
    
    /// <summary>
    /// Username администратора, который добавил клиента в запрещенные
    /// </summary>
    public string AddedBy { get; set; } = string.Empty;
    
    /// <summary>
    /// Дата и время добавления в запрещенные
    /// </summary>
    public DateTime AddedAt { get; set; }
}

