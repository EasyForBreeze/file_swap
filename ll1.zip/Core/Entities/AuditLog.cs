namespace new_assistant.Core.Entities;

/// <summary>
/// Сущность для хранения логов аудита действий пользователей
/// </summary>
public class AuditLog
{
    /// <summary>
    /// Уникальный идентификатор записи аудита
    /// </summary>
    public long Id { get; set; }

    /// <summary>
    /// Тип события (ClientCreated, ClientUpdated, ClientDeleted, AccessGranted, AccessRevoked, RoleAdded, RoleRemoved, SecretRegenerated, UserLogin)
    /// </summary>
    public string EventType { get; set; } = string.Empty;

    /// <summary>
    /// Имя пользователя, выполнившего действие
    /// </summary>
    public string Username { get; set; } = string.Empty;

    /// <summary>
    /// Client ID, над которым выполнено действие (если применимо)
    /// </summary>
    public string? ClientId { get; set; }

    /// <summary>
    /// Реалм, в котором выполнено действие (если применимо)
    /// </summary>
    public string? Realm { get; set; }

    /// <summary>
    /// Целевой пользователь (для событий назначения/отзыва прав)
    /// </summary>
    public string? TargetUsername { get; set; }

    /// <summary>
    /// Описание действия
    /// </summary>
    public string Description { get; set; } = string.Empty;

    /// <summary>
    /// Детали изменений в формате JSON (старые и новые значения)
    /// </summary>
    public string? ChangeDetails { get; set; }

    /// <summary>
    /// Дата и время события (UTC)
    /// </summary>
    public DateTime CreatedAt { get; set; }
}

