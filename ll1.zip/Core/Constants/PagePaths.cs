namespace new_assistant.Core.Constants;

/// <summary>
/// Константы для путей страниц приложения.
/// Используются для проверки доступа и навигации.
/// </summary>
public static class PagePaths
{
    /// <summary>
    /// Главная страница
    /// </summary>
    public const string Home = "/";
    
    /// <summary>
    /// Страница "Мои клиенты"
    /// </summary>
    public const string MyClients = "/my-clients";
    
    /// <summary>
    /// Страница информации о пользователе в разделе управления пользователями
    /// </summary>
    public const string UserManagementInfo = "/user-management/info";
    
    /// <summary>
    /// Страница добавления пользователя в разделе управления пользователями
    /// </summary>
    public const string UserManagementAdd = "/user-management/add";
    
    /// <summary>
    /// Страница просмотра логов (только для администраторов)
    /// </summary>
    public const string Logs = "/logs";
    
    /// <summary>
    /// Страница аудита (только для администраторов)
    /// </summary>
    public const string Audit = "/audit";
    
    /// <summary>
    /// Страница управления клиентами (только для администраторов)
    /// </summary>
    public const string Clients = "/clients";
    
    /// <summary>
    /// Страница управления запрещенными клиентами (только для администраторов)
    /// </summary>
    public const string AdminForbiddenClients = "/admin/forbidden-clients";
    
    /// <summary>
    /// Страница миграции клиентов (только для администраторов)
    /// </summary>
    public const string ClientMigration = "/client-migration";
    
    /// <summary>
    /// Страница доступа запрещена
    /// </summary>
    public const string AccessDenied = "/access-denied";
}

