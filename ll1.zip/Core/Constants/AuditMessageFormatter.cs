namespace new_assistant.Core.Constants;

/// <summary>
/// Форматирование сообщений для аудит-логов
/// </summary>
public static class AuditMessageFormatter
{
    public static string ClientCreated(string clientId, string realm)
        => $"Создан клиент {clientId} в реалме {realm}";

    public static string ClientDeleted(string clientId, string realm)
        => $"Удален клиент {clientId} из реалма {realm}";

    public static string ClientUpdated(string changedFields)
        => $"Изменены поля: {changedFields}";

    public static string AccessGranted(string targetUsername, string clientId, string realm)
        => $"Пользователю {targetUsername} предоставлен доступ к клиенту {clientId} в реалме {realm}";

    public static string AccessRevoked(string targetUsername, string clientId, string realm)
        => $"У пользователя {targetUsername} отозван доступ к клиенту {clientId} в реалме {realm}";

    public static string RoleAdded(string roleName, string clientId, string realm)
        => $"Добавлена роль '{roleName}' для клиента {clientId} в реалме {realm}";

    public static string RoleRemoved(string roleName, string clientId, string realm)
        => $"Удалена роль '{roleName}' для клиента {clientId} в реалме {realm}";

    public static string SecretRegenerated(string clientId, string realm)
        => $"Регенерирован Client Secret для клиента {clientId} в реалме {realm}";

    public static string UserLogin(string username)
        => $"Пользователь {username} вошел в систему";

    public static string ForbiddenClientAdded(string clientId, string realm)
        => $"Клиент {clientId} из реалма {realm} добавлен в запрещенные";

    public static string ForbiddenClientRemoved(string clientId, string realm)
        => $"Клиент {clientId} из реалма {realm} удален из запрещенных";

    public static string ClientMigrated(string sourceRealm, string targetRealm, string status)
        => $"Клиент перенесён из TEST ({sourceRealm}) в STAGE ({targetRealm}). Статус: {status}";
}

