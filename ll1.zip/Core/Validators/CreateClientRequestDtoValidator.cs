using FluentValidation;
using new_assistant.Core.DTOs;

namespace new_assistant.Core.Validators;

/// <summary>
/// Валидатор для CreateClientRequestDto (API запросы)
/// </summary>
public class CreateClientRequestDtoValidator : AbstractValidator<CreateClientRequestDto>
{
    public CreateClientRequestDtoValidator()
    {
        RuleFor(x => x.Realm)
            .NotEmpty().WithMessage("Realm обязателен")
            .MaximumLength(100).WithMessage("Realm не должен превышать 100 символов");

        RuleFor(x => x.ClientId)
            .NotEmpty().WithMessage("Client ID обязателен")
            .Matches(@"^app-[a-z0-9-]+$")
            .WithMessage("Client ID должен начинаться с 'app-' и содержать только буквы, цифры и дефисы")
            .MaximumLength(255).WithMessage("Client ID не должен превышать 255 символов");

        RuleFor(x => x.Name)
            .NotEmpty().WithMessage("Название обязательно")
            .MaximumLength(200).WithMessage("Название не должно превышать 200 символов");

        RuleFor(x => x.Description)
            .MaximumLength(500).WithMessage("Описание не должно превышать 500 символов");
    }
}

