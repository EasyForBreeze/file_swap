namespace new_assistant.Core.DTOs;

/// <summary>
/// DTO для отображения записей аудита
/// </summary>
public class AuditLogDto
{
    public long Id { get; set; }
    public string EventType { get; set; } = string.Empty;
    public string EventTypeDisplay { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public string? ClientId { get; set; }
    public string? Realm { get; set; }
    public string? TargetUsername { get; set; }
    public string Description { get; set; } = string.Empty;
    public string? ChangeDetails { get; set; }
    public DateTime CreatedAt { get; set; }
}

/// <summary>
/// DTO для фильтрации записей аудита
/// </summary>
public class AuditLogFilterDto
{
    public string? EventType { get; set; }
    public string? Username { get; set; }
    public string? ClientId { get; set; }
    public string? Realm { get; set; }
    public DateTime? DateFrom { get; set; }
    public DateTime? DateTo { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 10;
}

/// <summary>
/// DTO для изменений полей клиента
/// </summary>
public class FieldChangeDto
{
    public string FieldName { get; set; } = string.Empty;
    public string? OldValue { get; set; }
    public string? NewValue { get; set; }
}

/// <summary>
/// Результат запроса с пагинацией
/// </summary>
public class AuditLogPagedResult
{
    public List<AuditLogDto> Items { get; set; } = new();
    public int TotalCount { get; set; }
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int TotalPages => (int)Math.Ceiling(TotalCount / (double)PageSize);
}

