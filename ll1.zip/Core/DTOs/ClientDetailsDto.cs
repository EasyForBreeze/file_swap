namespace new_assistant.Core.DTOs;

/// <summary>
/// Детальная информация о клиенте для просмотра/редактирования.
/// </summary>
public class ClientDetailsDto
{
    public string Id { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool Enabled { get; set; } = true;
    public string Protocol { get; set; } = "openid-connect";
    public string ClientType { get; set; } = "confidential"; // public, confidential, bearer-only
    public string AccessType { get; set; } = "confidential"; // public, confidential, bearer-only
    public string? RootUrl { get; set; }
    public string? BaseUrl { get; set; }
    public string? AdminUrl { get; set; }
    public List<string> RedirectUris { get; set; } = new();
    public List<string> WebOrigins { get; set; } = new();
    public bool ServiceAccountsEnabled { get; set; } = false;
    public bool DirectAccessGrantsEnabled { get; set; } = false;
    public bool AuthorizationServicesEnabled { get; set; } = false;
    public bool FrontChannelLogout { get; set; } = true;
    
    // Capability config
    public bool ClientAuthentication { get; set; } = true;
    public bool StandardFlow { get; set; } = true;
    public string? ClientSecret { get; set; }
    public List<string> LocalRoles { get; set; } = new();
    public List<string> ServiceRoles { get; set; } = new();
    public List<string> Endpoints { get; set; } = new();
    public List<ClientEventDto> Events { get; set; } = new();
    public string Realm { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public Dictionary<string, List<string>> Attributes { get; set; } = new();
    public List<string> DefaultClientScopes { get; set; } = new();
    public List<string> OptionalClientScopes { get; set; } = new();
    public string? PublicationStatus { get; set; }
    public string? TicketNumber { get; set; }
    public string? TicketUrl { get; set; }
}

/// <summary>
/// Событие клиента.
/// </summary>
public record ClientEventDto
{
    public string Id { get; init; } = string.Empty;
    public DateTime Time { get; init; }
    public string Type { get; init; } = string.Empty;
    public string? Details { get; init; }
    public string? UserId { get; init; }
    public string? IpAddress { get; init; }
}

/// <summary>
/// Результат поиска ролей для Service Account.
/// </summary>
public class RoleSearchResult
{
    public string RoleName { get; set; } = string.Empty;
    public string RoleId { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string Source { get; set; } = "realm"; // "realm" или "client"
    public string? ClientId { get; set; } // Для client roles
    public string? ClientName { get; set; } // Для client roles
    public string? ClientInternalId { get; set; } // Internal ID клиента для client roles
}

/// <summary>
/// Клиент с его ролями для поиска.
/// </summary>
public class ClientWithRoles
{
    public string ClientId { get; set; } = string.Empty;
    public string ClientName { get; set; } = string.Empty;
    public string InternalId { get; set; } = string.Empty;
    public List<RoleSearchResult> Roles { get; set; } = new();
}

/// <summary>
/// Service Account роль с информацией о её источнике.
/// </summary>
public class ServiceAccountRoleDto
{
    public string RoleName { get; set; } = string.Empty;
    public string RoleId { get; set; } = string.Empty;
    public string Source { get; set; } = "realm"; // "realm" или "client"
    public string? ClientId { get; set; } // Для client roles
    public string? ClientInternalId { get; set; } // Internal ID клиента для client roles
    
    /// <summary>
    /// Форматированное имя роли для отображения
    /// </summary>
    public string DisplayName => Source == "client" ? $"{ClientId}:{RoleName}" : RoleName;
}