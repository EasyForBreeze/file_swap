namespace new_assistant.Core.DTOs;

/// <summary>
/// Immutable record, представляющий состояние всех модальных окон.
/// Используется для функционального подхода к управлению состоянием.
/// </summary>
/// <param name="IsCreateClientModalVisible">Видимость модального окна создания клиента.</param>
/// <param name="IsDeleteConfirmationModalVisible">Видимость модального окна подтверждения удаления.</param>
/// <param name="IsClientCreatedInfoModalVisible">Видимость модального окна с информацией о созданном клиенте.</param>
/// <param name="DeleteClientName">Имя клиента для удаления.</param>
/// <param name="CreationResult">Результат создания клиента.</param>
public record ModalState(
    bool IsCreateClientModalVisible = false,
    bool IsDeleteConfirmationModalVisible = false,
    bool IsClientCreatedInfoModalVisible = false,
    string? DeleteClientName = null,
    ClientCreationResultDto? CreationResult = null
)
{
    /// <summary>
    /// Создает новое состояние с закрытыми всеми модальными окнами.
    /// </summary>
    public static ModalState Closed => new ModalState();

    /// <summary>
    /// Проверяет, открыто ли хотя бы одно модальное окно.
    /// </summary>
    public bool HasAnyModalOpen => 
        IsCreateClientModalVisible || 
        IsDeleteConfirmationModalVisible || 
        IsClientCreatedInfoModalVisible;
}

