using System.Text.Json.Serialization;

namespace new_assistant.Core.DTOs;

/// <summary>
/// Базовая модель роли Keycloak (realm или client role)
/// </summary>
public class KeycloakRoleDto
{
    /// <summary>
    /// Уникальный идентификатор роли
    /// </summary>
    [JsonPropertyName("id")]
    public string Id { get; set; } = string.Empty;

    /// <summary>
    /// Название роли
    /// </summary>
    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Описание роли
    /// </summary>
    [JsonPropertyName("description")]
    public string? Description { get; set; }

    /// <summary>
    /// Является ли роль клиентской (true) или realm (false)
    /// </summary>
    [JsonPropertyName("clientRole")]
    public bool ClientRole { get; set; }

    /// <summary>
    /// Является ли роль композитной (содержит другие роли)
    /// </summary>
    [JsonPropertyName("composite")]
    public bool Composite { get; set; }

    /// <summary>
    /// Является ли роль контейнером для других ролей
    /// </summary>
    [JsonPropertyName("containerId")]
    public string? ContainerId { get; set; }

    /// <summary>
    /// Атрибуты роли
    /// </summary>
    [JsonPropertyName("attributes")]
    public Dictionary<string, List<string>>? Attributes { get; set; }
}

/// <summary>
/// Модель роли с информацией о клиенте (для client roles)
/// </summary>
public class KeycloakClientRoleDto : KeycloakRoleDto
{
    /// <summary>
    /// ID клиента, которому принадлежит роль
    /// </summary>
    [JsonPropertyName("clientId")]
    public string? ClientId { get; set; }
}

/// <summary>
/// Модель для создания новой роли
/// </summary>
public class CreateKeycloakRoleRequest
{
    /// <summary>
    /// Название роли (обязательное)
    /// </summary>
    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Описание роли
    /// </summary>
    [JsonPropertyName("description")]
    public string? Description { get; set; }

    /// <summary>
    /// Является ли роль клиентской
    /// </summary>
    [JsonPropertyName("clientRole")]
    public bool ClientRole { get; set; } = true;

    /// <summary>
    /// Атрибуты роли
    /// </summary>
    [JsonPropertyName("attributes")]
    public Dictionary<string, List<string>>? Attributes { get; set; }
}

/// <summary>
/// Модель для назначения роли пользователю
/// </summary>
public class RoleMappingRequest
{
    /// <summary>
    /// ID роли
    /// </summary>
    [JsonPropertyName("id")]
    public string Id { get; set; } = string.Empty;

    /// <summary>
    /// Название роли
    /// </summary>
    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;
}

/// <summary>
/// Модель role mappings пользователя из Keycloak API
/// </summary>
public class KeycloakRoleMappingsDto
{
    /// <summary>
    /// Realm роли пользователя
    /// </summary>
    [JsonPropertyName("realmMappings")]
    public List<KeycloakRoleDto>? RealmMappings { get; set; }

    /// <summary>
    /// Client роли пользователя, сгруппированные по клиентам
    /// </summary>
    [JsonPropertyName("clientMappings")]
    public Dictionary<string, KeycloakClientMappingDto>? ClientMappings { get; set; }
}

/// <summary>
/// Модель client mapping из Keycloak API
/// </summary>
public class KeycloakClientMappingDto
{
    /// <summary>
    /// ID клиента
    /// </summary>
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    /// <summary>
    /// Client ID (название клиента)
    /// </summary>
    [JsonPropertyName("clientId")]
    public string? ClientId { get; set; }

    /// <summary>
    /// Роли клиента для пользователя
    /// </summary>
    [JsonPropertyName("mappings")]
    public List<KeycloakRoleDto>? Mappings { get; set; }
}

/// <summary>
/// Модель client scope из Keycloak API
/// </summary>
public class KeycloakClientScopeDto
{
    /// <summary>
    /// ID scope
    /// </summary>
    [JsonPropertyName("id")]
    public string Id { get; set; } = string.Empty;

    /// <summary>
    /// Название scope
    /// </summary>
    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Описание scope
    /// </summary>
    [JsonPropertyName("description")]
    public string? Description { get; set; }

    /// <summary>
    /// Протокол (openid-connect, saml)
    /// </summary>
    [JsonPropertyName("protocol")]
    public string? Protocol { get; set; }
}

/// <summary>
/// DTO для назначения роли пользователю (используется в batch операциях)
/// </summary>
public class AssignRoleMappingDto
{
    /// <summary>
    /// ID роли
    /// </summary>
    [JsonPropertyName("id")]
    public string Id { get; set; } = string.Empty;

    /// <summary>
    /// Название роли
    /// </summary>
    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;
}

/// <summary>
/// DTO для роли из UI-EXT API (available-roles endpoint)
/// UI-EXT API использует другой формат: "role" вместо "name", и может содержать "client" для client roles
/// </summary>
public class KeycloakUiExtRoleDto
{
    /// <summary>
    /// Уникальный идентификатор роли
    /// </summary>
    [JsonPropertyName("id")]
    public string Id { get; set; } = string.Empty;

    /// <summary>
    /// Название роли (UI-EXT API использует "role" вместо "name")
    /// </summary>
    [JsonPropertyName("role")]
    public string? Role { get; set; }

    /// <summary>
    /// Название роли (fallback, если используется стандартный формат)
    /// </summary>
    [JsonPropertyName("name")]
    public string? Name { get; set; }

    /// <summary>
    /// Описание роли
    /// </summary>
    [JsonPropertyName("description")]
    public string? Description { get; set; }

    /// <summary>
    /// Client ID (если это client role)
    /// </summary>
    [JsonPropertyName("client")]
    public string? Client { get; set; }

    /// <summary>
    /// Client ID (внутренний UUID, если это client role)
    /// </summary>
    [JsonPropertyName("clientId")]
    public string? ClientId { get; set; }

    /// <summary>
    /// Получить название роли (использует Role или Name)
    /// </summary>
    public string GetRoleName() => Role ?? Name ?? string.Empty;
}

