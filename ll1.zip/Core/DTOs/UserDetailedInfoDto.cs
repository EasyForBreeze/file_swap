using System.Text.Json;

namespace new_assistant.Core.DTOs;

/// <summary>
/// Детальная информация о пользователе из users-management API
/// </summary>
public class UserDetailedInfoDto
{
    public string Id { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? Email { get; set; }
    public bool EmailVerified { get; set; }
    public bool Enabled { get; set; }
    public string? FederationLink { get; set; }
    public Dictionary<string, List<string>>? Attributes { get; set; }
    public List<UserRealmRoleDto> RealmRoles { get; set; } = new();
    public List<UserClientRoleDto> ClientRoles { get; set; } = new();
    public List<UserGroupDto> Groups { get; set; } = new();
    public List<UserCredentialDto> Credentials { get; set; } = new();
    public BruteForceStatusDto? BruteForceStatus { get; set; }
    public List<string> RequiredActions { get; set; } = new();
    public long CreatedTimestamp { get; set; }
    
    // Вычисляемые свойства
    public string DisplayName => 
        !string.IsNullOrEmpty(FirstName) || !string.IsNullOrEmpty(LastName)
            ? $"{FirstName} {LastName}".Trim()
            : Username;
    
    public DateTime CreatedDate => DateTimeOffset.FromUnixTimeMilliseconds(CreatedTimestamp).DateTime;
}

public class UserRealmRoleDto
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
}

public class UserClientRoleDto
{
    public string ClientId { get; set; } = string.Empty;
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
}

public class UserGroupDto
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
}

public class UserCredentialDto
{
    public string Id { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty;
    public long CreatedDate { get; set; }
    public string? UserLabel { get; set; }
    
    // Вычисляемое свойство
    public DateTime CreatedDateTime => DateTimeOffset.FromUnixTimeMilliseconds(CreatedDate).DateTime;
}

public class BruteForceStatusDto
{
    public int NumFailures { get; set; }
    public bool Disabled { get; set; }
    public string? LastIPFailure { get; set; }
    public long LastFailure { get; set; }
    
    // Вычисляемое свойство
    public DateTime? LastFailureDate => LastFailure > 0 ? DateTimeOffset.FromUnixTimeMilliseconds(LastFailure).DateTime : null;
}

