namespace new_assistant.Core.DTOs;

/// <summary>
/// Ответ на запрос создания клиента
/// </summary>
public class CreateClientResponse
{
    public bool Success { get; set; }
    public string? ClientId { get; set; }
    public string? KeycloakInternalId { get; set; }
    public string? WikiPageUrl { get; set; }
    public string? ErrorMessage { get; set; }
}
