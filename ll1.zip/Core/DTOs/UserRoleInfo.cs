namespace new_assistant.Core.DTOs;

/// <summary>
/// Информация о роли пользователя в конкретном реалме
/// </summary>
public class UserRoleInfo
{
    /// <summary>
    /// Название роли (например, kc-ga-users-management-api.block.user)
    /// </summary>
    public string RoleName { get; set; } = string.Empty;
    
    /// <summary>
    /// Реалм, в котором найдена роль (например, internal-dom-idm)
    /// </summary>
    public string Realm { get; set; } = string.Empty;
}

