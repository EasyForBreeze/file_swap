using System.ComponentModel.DataAnnotations;

namespace new_assistant.Core.DTOs;

/// <summary>
/// Запрос на создание клиента в Keycloak
/// </summary>
public class CreateClientRequestDto
{
    /// <summary>
    /// Реалм для создания клиента
    /// </summary>
    [Required]
    public string Realm { get; set; } = string.Empty;

    /// <summary>
    /// Client ID в Keycloak (будет префикс app-bank-)
    /// </summary>
    [Required]
    [RegularExpression(@"^[a-zA-Z0-9_-]+$", ErrorMessage = "Client ID может содержать только буквы, цифры, дефисы и подчеркивания.")]
    public string ClientId { get; set; } = string.Empty;

    /// <summary>
    /// Name клиента (читаемое имя)
    /// </summary>
    public string? Name { get; set; }

    /// <summary>
    /// Описание клиента
    /// </summary>
    public string? Description { get; set; }

    /// <summary>
    /// Включена ли аутентификация клиента (confidential vs public)
    /// </summary>
    public bool ClientAuthentication { get; set; } = true;

    /// <summary>
    /// Включен ли Standard Flow (Authorization Code Flow)
    /// </summary>
    public bool StandardFlow { get; set; } = false;

    /// <summary>
    /// Включен ли Service Account
    /// </summary>
    public bool ServiceAccount { get; set; } = false;

    /// <summary>
    /// Список локальных ролей для создания (будут префикс kc-gf-)
    /// </summary>
    public List<string> LocalRoles { get; set; } = new();

    /// <summary>
    /// Список Redirect URIs для Standard Flow
    /// </summary>
    public List<string> RedirectUris { get; set; } = new();

    /// <summary>
    /// Название системы-владельца
    /// </summary>
    [Required]
    public string OwnerSystemName { get; set; } = string.Empty;

    /// <summary>
    /// URL системы-владельца
    /// </summary>
    [Url(ErrorMessage = "Некорректный формат URL")]
    public string? OwnerSystemUrl { get; set; }

    /// <summary>
    /// Имя владельца
    /// </summary>
    public string? OwnerName { get; set; }

    /// <summary>
    /// Менеджер поддержки
    /// </summary>
    public string? SupportManager { get; set; }
}
