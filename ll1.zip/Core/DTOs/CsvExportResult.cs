namespace new_assistant.Core.DTOs;

/// <summary>
/// Результат экспорта в CSV
/// </summary>
public class CsvExportResult
{
    public byte[] Content { get; set; } = Array.Empty<byte>();
    public string Encoding { get; set; } = "UTF-8";
    public string FileName { get; set; } = "audit_logs.csv";
    public string ContentType { get; set; } = "text/csv; charset=utf-8";
}

