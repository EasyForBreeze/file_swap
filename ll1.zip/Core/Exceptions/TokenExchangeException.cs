namespace new_assistant.Core.Exceptions;

/// <summary>
/// Базовое исключение для ошибок token exchange
/// </summary>
public class TokenExchangeException : Exception
{
    /// <summary>
    /// Реалм, для которого выполнялся token exchange
    /// </summary>
    public string? Realm { get; }
    
    public TokenExchangeException(string? realm, string message) : base(message)
    {
        Realm = realm;
    }
    
    public TokenExchangeException(string? realm, string message, Exception innerException) 
        : base(message, innerException)
    {
        Realm = realm;
    }
}

/// <summary>
/// Исключение, возникающее при ошибках конфигурации token exchange
/// </summary>
public class TokenExchangeConfigurationException : TokenExchangeException
{
    public TokenExchangeConfigurationException(string? realm, string message) 
        : base(realm, message) { }
    
    public TokenExchangeConfigurationException(string? realm, string message, Exception innerException) 
        : base(realm, message, innerException) { }
}

/// <summary>
/// Исключение, возникающее при сетевых ошибках или ошибках HTTP при token exchange
/// </summary>
public class TokenExchangeNetworkException : TokenExchangeException
{
    /// <summary>
    /// HTTP статус код ответа (если доступен)
    /// </summary>
    public System.Net.HttpStatusCode? StatusCode { get; }
    
    public TokenExchangeNetworkException(string? realm, string message, System.Net.HttpStatusCode? statusCode = null) 
        : base(realm, message)
    {
        StatusCode = statusCode;
    }
    
    public TokenExchangeNetworkException(string? realm, string message, Exception innerException, System.Net.HttpStatusCode? statusCode = null) 
        : base(realm, message, innerException)
    {
        StatusCode = statusCode;
    }
}

/// <summary>
/// Исключение, возникающее при ошибках валидации токена
/// </summary>
public class TokenExchangeValidationException : TokenExchangeException
{
    public TokenExchangeValidationException(string? realm, string message) 
        : base(realm, message) { }
    
    public TokenExchangeValidationException(string? realm, string message, Exception innerException) 
        : base(realm, message, innerException) { }
}

