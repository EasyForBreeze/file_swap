namespace new_assistant.Core.Helpers;

/// <summary>
/// Утилитный класс для парсинга client roles
/// </summary>
public static class ClientRoleParser
{
    /// <summary>
    /// Парсит client role в формате "clientId:roleName" или "clientId|additionalInfo:roleName"
    /// </summary>
    /// <param name="role">Роль в формате "clientId:roleName"</param>
    /// <returns>Кортеж (clientId, roleName) или null, если формат некорректный</returns>
    public static (string ClientId, string RoleName)? ParseClientRole(string role)
    {
        if (string.IsNullOrWhiteSpace(role))
            return null;
        
        if (!role.Contains(':'))
            return null;
        
        var parts = role.Split(':');
        if (parts.Length < 2)
            return null;
        
        var clientPart = parts[0];
        var roleName = parts[parts.Length - 1];
        
        // Обработка формата "clientId|additionalInfo:roleName"
        var targetClientId = clientPart.Contains('|')
            ? clientPart.Split('|')[0]
            : clientPart;
        
        if (string.IsNullOrWhiteSpace(targetClientId) || string.IsNullOrWhiteSpace(roleName))
            return null;
        
        return (targetClientId, roleName);
    }
    
    /// <summary>
    /// Группирует client roles по clientId
    /// </summary>
    /// <param name="clientRoles">Список client roles в формате "clientId:roleName"</param>
    /// <returns>Словарь, где ключ - clientId, значение - HashSet roleName для O(1) операций</returns>
    public static Dictionary<string, HashSet<string>> GroupByClientId(IEnumerable<string> clientRoles)
    {
        var result = new Dictionary<string, HashSet<string>>();
        
        if (clientRoles == null)
            return result;
        
        foreach (var role in clientRoles)
        {
            var parsed = ParseClientRole(role);
            if (!parsed.HasValue)
                continue;
            
            var (clientId, roleName) = parsed.Value;
            
            if (!result.ContainsKey(clientId))
                result[clientId] = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            
            // Дедупликация на уровне клиента (O(1) операция с HashSet)
            result[clientId].Add(roleName);
        }
        
        return result;
    }
    
    /// <summary>
    /// Группирует client roles по clientId и возвращает как Dictionary с List (для обратной совместимости)
    /// </summary>
    /// <param name="clientRoles">Список client roles в формате "clientId:roleName"</param>
    /// <returns>Словарь, где ключ - clientId, значение - список roleName</returns>
    public static Dictionary<string, List<string>> GroupByClientIdAsList(IEnumerable<string> clientRoles)
    {
        var hashSetResult = GroupByClientId(clientRoles);
        return hashSetResult.ToDictionary(
            kvp => kvp.Key, 
            kvp => kvp.Value.ToList(), 
            StringComparer.OrdinalIgnoreCase);
    }
}

