using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services.Confluence;

/// <summary>
/// Клиент для работы с Confluence API
/// </summary>
public class ConfluenceApiClient : IConfluenceApiClient
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ConfluenceSettings _settings;
    private readonly ILogger<ConfluenceApiClient> _logger;
    private readonly IPerformanceMetricsService? _metricsService;

    // Константы для retry логики
    private const int MaxVersionRetryAttempts = 3;
    private const int VersionRetryDelayMs = 500;
    private const int HttpConflictStatusCode = 409; // Conflict
    private const int HealthCheckTimeoutSeconds = 5;

    public ConfluenceApiClient(
        IHttpClientFactory httpClientFactory,
        IOptions<ConfluenceSettings> settings,
        ILogger<ConfluenceApiClient> logger,
        IPerformanceMetricsService? metricsService = null)
    {
        _httpClientFactory = httpClientFactory;
        _settings = settings.Value;
        _logger = logger;
        _metricsService = metricsService;
    }

    private HttpClient CreateHttpClient()
    {
        var client = _httpClientFactory.CreateClient("Confluence");
        ConfigureHttpClient(client);
        return client;
    }

    private void ConfigureHttpClient(HttpClient client)
    {
        // Валидация настроек
        if (string.IsNullOrWhiteSpace(_settings.BaseUrl))
            throw new InvalidOperationException("Confluence BaseUrl is not configured");

        if (!Uri.TryCreate(_settings.BaseUrl, UriKind.Absolute, out var baseUri))
            throw new InvalidOperationException($"Invalid Confluence BaseUrl: {_settings.BaseUrl}");

        if (_settings.RequestTimeoutSeconds <= 0)
            throw new InvalidOperationException("RequestTimeoutSeconds must be greater than 0");

        client.BaseAddress = baseUri;
        client.Timeout = TimeSpan.FromSeconds(_settings.RequestTimeoutSeconds);

        // Если задан Token — используем Bearer. Иначе — Basic
        if (!string.IsNullOrWhiteSpace(_settings.Token))
        {
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _settings.Token);
        }
        else
        {
            // Basic Auth для Confluence
            if (string.IsNullOrWhiteSpace(_settings.Username) || string.IsNullOrWhiteSpace(_settings.Password))
                throw new InvalidOperationException("Confluence Username and Password must be configured when Token is not provided");

            var authToken = Convert.ToBase64String(
                Encoding.UTF8.GetBytes($"{_settings.Username}:{_settings.Password}"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);
        }
        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
    }

    public async Task<ConfluencePageResponse?> CreatePageAsync(
        string title,
        string content,
        string spaceKey,
        string parentPageId,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        const string operationName = "Confluence.CreatePage";

        try
        {
            using var client = CreateHttpClient();

            var payload = new
            {
                type = "page",
                title = title,
                space = new { key = spaceKey },
                ancestors = new[] { new { id = parentPageId } },
                body = new
                {
                    storage = new
                    {
                        value = content,
                        representation = "storage"
                    }
                }
            };

            var json = JsonSerializer.Serialize(payload);
            var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync("/rest/api/content", httpContent, cancellationToken).ConfigureAwait(false);

            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                _logger.LogError("Failed to create Confluence page. Status: {Status}, Error: {Error}",
                    response.StatusCode, errorContent);
                
                _metricsService?.RecordError(operationName, $"HTTP_{response.StatusCode}");
                return null;
            }

            var responseJson = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            var result = JsonSerializer.Deserialize<JsonElement>(responseJson);

            var page = ParseConfluencePageResponse(result, title, content);
            if (page == null)
            {
                _logger.LogError("Failed to parse Confluence page response");
                _metricsService?.RecordError(operationName, "ParseError");
                return null;
            }

            stopwatch.Stop();
            _metricsService?.RecordOperationTime(operationName, stopwatch.ElapsedMilliseconds);
            _metricsService?.RecordSuccess(operationName);

            return page;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP error creating Confluence page");
            _metricsService?.RecordError(operationName, "HttpRequestException");
            return null;
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogWarning(ex, "Request timeout creating Confluence page");
            _metricsService?.RecordError(operationName, "Timeout");
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error creating Confluence page");
            _metricsService?.RecordError(operationName, "UnexpectedError");
            return null;
        }
    }

    public async Task<ConfluencePageResponse?> GetPageAsync(
        string pageId,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        const string operationName = "Confluence.GetPage";

        try
        {
            using var client = CreateHttpClient();

            var response = await client.GetAsync(
                $"/rest/api/content/{pageId}?expand=body.storage,version",
                cancellationToken).ConfigureAwait(false);

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError("Failed to get Confluence page {PageId}. Status: {Status}",
                    pageId, response.StatusCode);
                _metricsService?.RecordError(operationName, $"HTTP_{response.StatusCode}");
                return null;
            }

            var responseJson = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            var result = JsonSerializer.Deserialize<JsonElement>(responseJson);

            // Безопасная обработка JSON ответа
            if (!result.TryGetProperty("title", out var titleElement) || string.IsNullOrWhiteSpace(titleElement.GetString()))
            {
                _logger.LogError("Confluence API response missing or invalid 'title' field for page {PageId}", pageId);
                _metricsService?.RecordError(operationName, "ParseError");
                return null;
            }

            if (!result.TryGetProperty("version", out var versionElement) ||
                !versionElement.TryGetProperty("number", out var versionNumber))
            {
                _logger.LogError("Confluence API response missing or invalid 'version' field for page {PageId}", pageId);
                _metricsService?.RecordError(operationName, "ParseError");
                return null;
            }

            if (!result.TryGetProperty("body", out var bodyElement) ||
                !bodyElement.TryGetProperty("storage", out var storageElement) ||
                !storageElement.TryGetProperty("value", out var valueElement) ||
                string.IsNullOrWhiteSpace(valueElement.GetString()))
            {
                _logger.LogError("Confluence API response missing or invalid 'body.storage.value' field for page {PageId}", pageId);
                _metricsService?.RecordError(operationName, "ParseError");
                return null;
            }

            var title = titleElement.GetString()!;
            var version = versionNumber.GetInt32();
            var body = valueElement.GetString()!;
            var pageUrl = $"{_settings.BaseUrl}/pages/viewpage.action?pageId={pageId}";

            stopwatch.Stop();
            _metricsService?.RecordOperationTime(operationName, stopwatch.ElapsedMilliseconds);
            _metricsService?.RecordSuccess(operationName);

            return new ConfluencePageResponse
            {
                Id = pageId,
                Title = title,
                Version = version,
                Url = pageUrl,
                Body = body
            };
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP error getting Confluence page {PageId}", pageId);
            _metricsService?.RecordError(operationName, "HttpRequestException");
            return null;
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogWarning(ex, "Request timeout getting Confluence page {PageId}", pageId);
            _metricsService?.RecordError(operationName, "Timeout");
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error getting Confluence page {PageId}", pageId);
            _metricsService?.RecordError(operationName, "UnexpectedError");
            return null;
        }
    }

    public async Task<ConfluencePageResponse?> UpdatePageAsync(
        string pageId,
        string title,
        string content,
        int expectedVersion,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        const string operationName = "Confluence.UpdatePage";
        int currentVersion = expectedVersion;

        // Retry логика для обработки конфликтов версий (race condition)
        for (int attempt = 0; attempt < MaxVersionRetryAttempts; attempt++)
        {
            try
            {
                using var client = CreateHttpClient();

                // Оптимизация: на первой попытке используем expectedVersion без дополнительного запроса
                // Если получим 409 Conflict, то на следующей попытке получим актуальную версию
                if (attempt > 0)
                {
                    // На повторных попытках получаем актуальную версию
                    var currentPage = await GetPageAsync(pageId, cancellationToken);
                    if (currentPage == null)
                    {
                        _logger.LogError("Failed to get current page from Confluence for page ID {PageId}", pageId);
                        _metricsService?.RecordError(operationName, "GetPageFailed");
                        return null;
                    }

                    currentVersion = currentPage.Version;
                }

                // Выполняем обновление с актуальной версией
                var payload = new
                {
                    version = new { number = currentVersion + 1 },
                    title = title,
                    type = "page",
                    body = new
                    {
                        storage = new
                        {
                            value = content,
                            representation = "storage"
                        }
                    }
                };

                var json = JsonSerializer.Serialize(payload);
                var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await client.PutAsync(
                    $"/rest/api/content/{pageId}",
                    httpContent,
                    cancellationToken).ConfigureAwait(false);

                // Обработка конфликта версий (409 Conflict)
                if (response.StatusCode == (HttpStatusCode)HttpConflictStatusCode && attempt < MaxVersionRetryAttempts - 1)
                {
                    _logger.LogWarning(
                        "Version conflict detected (409 Conflict) for page {PageId}, retrying... (Attempt {Attempt}/{MaxAttempts})",
                        pageId, attempt + 1, MaxVersionRetryAttempts);

                    await Task.Delay(TimeSpan.FromMilliseconds(VersionRetryDelayMs), cancellationToken);
                    continue;
                }

                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                    _logger.LogError("Failed to update Confluence page {PageId}. Status: {Status}, Error: {Error}",
                        pageId, response.StatusCode, errorContent);
                    _metricsService?.RecordError(operationName, $"HTTP_{response.StatusCode}");
                    return null;
                }

                var responseJson = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                var result = JsonSerializer.Deserialize<JsonElement>(responseJson);

                // Безопасная обработка JSON ответа
                if (!result.TryGetProperty("version", out var versionElement) ||
                    !versionElement.TryGetProperty("number", out var versionNumber))
                {
                    _logger.LogError("Confluence API response missing or invalid 'version' field for page {PageId}", pageId);
                    _metricsService?.RecordError(operationName, "ParseError");
                    return null;
                }

                var version = versionNumber.GetInt32();
                var pageUrl = $"{_settings.BaseUrl}/pages/viewpage.action?pageId={pageId}";

                stopwatch.Stop();
                _metricsService?.RecordOperationTime(operationName, stopwatch.ElapsedMilliseconds);
                _metricsService?.RecordSuccess(operationName);

                return new ConfluencePageResponse
                {
                    Id = pageId,
                    Title = title,
                    Version = version,
                    Url = pageUrl,
                    Body = content
                };
            }
            catch (HttpRequestException ex) when (ex.Message.Contains(HttpConflictStatusCode.ToString()) && attempt < MaxVersionRetryAttempts - 1)
            {
                // Конфликт версий в исключении - повторяем
                _logger.LogWarning(ex,
                    "Version conflict detected in exception for page {PageId}, retrying... (Attempt {Attempt}/{MaxAttempts})",
                    pageId, attempt + 1, MaxVersionRetryAttempts);

                await Task.Delay(TimeSpan.FromMilliseconds(VersionRetryDelayMs), cancellationToken);
                continue;
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogWarning(ex, "Request timeout updating Confluence page {PageId}", pageId);
                _metricsService?.RecordError(operationName, "Timeout");
                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception updating Confluence page {PageId}", pageId);
                _metricsService?.RecordError(operationName, "UnexpectedError");
                return null;
            }
        }

        _logger.LogError("Failed to update Confluence page {PageId} after {MaxAttempts} attempts due to version conflicts",
            pageId, MaxVersionRetryAttempts);
        _metricsService?.RecordError(operationName, "MaxRetriesExceeded");
        return null;
    }

    public async Task<bool> AddLabelsAsync(
        string pageId,
        List<string> labels,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(pageId))
            throw new ArgumentException("Page ID cannot be null or empty", nameof(pageId));

        if (labels == null || labels.Count == 0)
            return true;

        var payload = labels
            .Where(l => !string.IsNullOrWhiteSpace(l))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Select(l => new { prefix = "global", name = l })
            .ToList();

        if (payload.Count == 0)
            return true;

        try
        {
            using var client = CreateHttpClient();

            var json = JsonSerializer.Serialize(payload);
            var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync($"/rest/api/content/{pageId}/label", httpContent, cancellationToken).ConfigureAwait(false);

            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                _logger.LogWarning("Не удалось добавить метки к странице {PageId}. Status: {Status}. Error: {Error}", pageId, response.StatusCode, error);
                return false;
            }

            return true;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error adding labels to page {PageId}", pageId);
            return false;
        }
    }

    public async Task<bool> IsAvailableAsync(CancellationToken cancellationToken = default)
    {
        if (!_settings.Enabled)
            return false;

        try
        {
            using var client = CreateHttpClient();
            // Комбинируем переданный токен с таймаутом health check
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            cts.CancelAfter(TimeSpan.FromSeconds(HealthCheckTimeoutSeconds));
            var response = await client.GetAsync("/rest/api/space", cts.Token).ConfigureAwait(false);
            return response.IsSuccessStatusCode;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogDebug(ex, "Confluence API is not available");
            return false;
        }
        catch (TaskCanceledException)
        {
            _logger.LogDebug("Confluence API health check timeout");
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Confluence API is not available");
            return false;
        }
    }

    public async Task<(string Id, string Title, string Url, int Version)?> ResolvePageAsync(
        string spaceKey,
        string title,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(spaceKey))
            throw new ArgumentException("Space key cannot be null or empty", nameof(spaceKey));

        if (string.IsNullOrWhiteSpace(title))
            throw new ArgumentException("Title cannot be null or empty", nameof(title));

        try
        {
            using var client = CreateHttpClient();
            var query = $"/rest/api/content?spaceKey={Uri.EscapeDataString(spaceKey)}&title={Uri.EscapeDataString(title)}&expand=version";
            var response = await client.GetAsync(query, cancellationToken).ConfigureAwait(false);

            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                _logger.LogWarning("Confluence ResolvePageAsync failed. Space={Space}, Title={Title}, Status={Status}. Error={Error}",
                    spaceKey, title, response.StatusCode, error);
                return null;
            }

            var json = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            using var document = JsonDocument.Parse(json);
            var root = document.RootElement;
            if (!root.TryGetProperty("results", out var results) || results.GetArrayLength() == 0)
            {
                return null;
            }

            var first = results[0];

            // Безопасная обработка JSON ответа
            if (!first.TryGetProperty("id", out var idElement) || string.IsNullOrWhiteSpace(idElement.GetString()))
            {
                _logger.LogWarning("Confluence API response missing or invalid 'id' field for space={Space} title={Title}", spaceKey, title);
                return null;
            }

            var id = idElement.GetString()!;
            var version = first.TryGetProperty("version", out var versionElement) && versionElement.TryGetProperty("number", out var versionNumber)
                ? versionNumber.GetInt32()
                : 1;

            var url = first.TryGetProperty("_links", out var links) && links.TryGetProperty("webui", out var webui)
                ? new Uri(new Uri(_settings.BaseUrl), webui.GetString() ?? string.Empty).ToString()
                : string.Empty;

            var titleValue = first.TryGetProperty("title", out var titleElement)
                ? titleElement.GetString()
                : title;

            return (id, titleValue ?? title, url, version);
        }
        catch (HttpRequestException ex)
        {
            _logger.LogWarning(ex, "HTTP error in ResolvePageAsync for space={Space} title={Title}", spaceKey, title);
            return null;
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogWarning(ex, "Request timeout in ResolvePageAsync for space={Space} title={Title}", spaceKey, title);
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error in ResolvePageAsync for space={Space} title={Title}", spaceKey, title);
            return null;
        }
    }

    private ConfluencePageResponse? ParseConfluencePageResponse(JsonElement result, string title, string content)
    {
        if (!result.TryGetProperty("id", out var idElement) ||
            string.IsNullOrWhiteSpace(idElement.GetString()))
        {
            _logger.LogError("Confluence API response missing or invalid 'id' field");
            return null;
        }

        var pageId = idElement.GetString()!;

        if (!result.TryGetProperty("version", out var versionElement) ||
            !versionElement.TryGetProperty("number", out var versionNumber))
        {
            _logger.LogError("Confluence API response missing or invalid 'version' field");
            return null;
        }

        var version = versionNumber.GetInt32();
        var pageUrl = $"{_settings.BaseUrl}/pages/viewpage.action?pageId={pageId}";

        return new ConfluencePageResponse
        {
            Id = pageId,
            Title = title,
            Version = version,
            Url = pageUrl,
            Body = content
        };
    }
}

