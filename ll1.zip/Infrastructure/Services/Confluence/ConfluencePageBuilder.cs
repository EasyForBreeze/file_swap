using System.Collections.Concurrent;
using System.Net;
using System.Text;
using System.Xml.Linq;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services.Confluence;

/// <summary>
/// Билдер для генерации контента страниц Confluence с кэшированием
/// </summary>
public class ConfluencePageBuilder : IConfluencePageBuilder
{
    private readonly IConfluenceTemplateProvider _templateProvider;
    private readonly IConfluencePageParser _parser;
    private readonly ILogger<ConfluencePageBuilder> _logger;
    private readonly IMemoryCache? _cache;

    // Константы
    private const string XhtmlNamespace = "http://www.w3.org/1999/xhtml";
    private const string AtlassianConfluenceNamespace = "http://atlassian.com/content";
    private const string AtlassianResourceInterfaceNamespace = "http://atlassian.com/resource-interface";
    private const string XIncludeNamespace = "http://www.w3.org/2001/XInclude";
    private const int RealmPrefixLength = 3;
    private const int MaxDocumentSizeBytes = 10_000_000; // 10MB
    private const int MaxFragmentSizeBytes = 1_000_000; // 1MB
    private const int EstimatedTableHeaderSize = 500;
    private const int EstimatedRoleRowSize = 80;
    private const int EstimatedServiceRoleRowSize = 100;
    private const int EstimatedUriRowSize = 100;
    private const int EstimatedContentBufferSize = 500;
    private const int EstimatedScopesBaseSize = 200;
    private const int EstimatedScopeSize = 50;

    // Кэш для шаблонов (TTL: 1 час)
    private static readonly TimeSpan TemplateCacheExpiration = TimeSpan.FromHours(1);
    private const string TemplateCacheKey = "ConfluenceTemplate";

    public ConfluencePageBuilder(
        IConfluenceTemplateProvider templateProvider,
        IConfluencePageParser parser,
        ILogger<ConfluencePageBuilder> logger,
        IMemoryCache? cache = null)
    {
        _templateProvider = templateProvider;
        _parser = parser;
        _logger = logger;
        _cache = cache;
    }

    public string BuildPageContent(ClientCreationData data)
    {
        // Получаем шаблон из кэша или загружаем
        var template = GetCachedTemplate();

        // Информационная система с ссылкой
        var infoSystemCell = string.IsNullOrWhiteSpace(data.OwnerSystemUrl)
            ? $"<td>{EscapeHtml(data.OwnerSystemName)}</td>"
            : $"<td><a href=\"{EscapeHtmlAttribute(data.OwnerSystemUrl)}\">{EscapeHtml(data.OwnerSystemName)}</a></td>";

        // Оптимизация: используем Dictionary и StringBuilder для замены плейсхолдеров
        var replacements = new Dictionary<string, string>(StringComparer.Ordinal)
        {
            ["{{INFO_SYSTEM_CELL}}"] = infoSystemCell,
            ["{{REALM_CELL}}"] = $"<td>{EscapeHtml(data.Realm)}</td>",
            ["{{CLIENT_ID}}"] = EscapeHtml(data.ClientId),
            ["{{CLIENT_NAME}}"] = EscapeHtml(data.Name ?? data.ClientId),
            ["{{ACCESS_TYPE}}"] = data.ClientAuthentication ? "confidential" : "public",
            ["{{CLIENT_STATUS}}"] = FormatBooleanStatus(true), // Всегда enabled при создании
            ["{{SERVICE_OWNER_CELL}}"] = $"<td>{EscapeHtml(data.OwnerName ?? "")}</td>",
            ["{{SERVICE_MANAGER_CELL}}"] = $"<td>{EscapeHtml(data.SupportManager ?? "")}</td>",
            ["{{DESCRIPTION}}"] = EscapeHtml(data.Description ?? ""),
            ["{{STANDARD_FLOW}}"] = FormatBooleanStatus(data.StandardFlow),
            ["{{DIRECT_ACCESS_GRANTS}}"] = FormatBooleanStatus(false), // По умолчанию Off
            ["{{SERVICE_ACCOUNTS}}"] = FormatBooleanStatus(data.ServiceAccount),
            ["{{DEVICE_AUTHORIZATION}}"] = FormatBooleanStatus(false), // По умолчанию Off
            ["{{CLIENT_SCOPES}}"] = BuildClientScopesDisplay(null, null),
            ["{{PUBLICATION_STATUS}}"] = EscapeHtml(data.PublicationStatus ?? "TEST"),
            ["{{REDIRECT_TABLE}}"] = BuildRedirectUrisTable(data.RedirectUris),
            ["{{LOCAL_ROLES_TABLE}}"] = BuildLocalRolesTable(data.LocalRoles, "TEST"),
            ["{{SERVICE_ROLES_TABLE}}"] = "<p>Нет Service Account ролей</p>"
        };

        var ticketLinkHtml = BuildTicketLinkHtml(data.TicketNumber, data.TicketUrl);
        replacements["{{TICKET_FTEST}}"] = ticketLinkHtml ?? string.Empty;
        replacements["{{TICKET_PREPROD}}"] = string.Empty;
        replacements["{{TICKET_PROD}}"] = string.Empty;

        // Используем StringBuilder для эффективной замены
        var sb = new StringBuilder(template);
        foreach (var replacement in replacements)
        {
            sb.Replace(replacement.Key, replacement.Value);
        }

        return sb.ToString();
    }

    public async Task<string> UpdatePageContent(ClientDetailsDto details, string currentContent)
    {
        if (string.IsNullOrWhiteSpace(currentContent))
        {
            return string.Empty;
        }

        // Ограничение размера документа
        if (currentContent.Length > MaxDocumentSizeBytes)
        {
            _logger.LogWarning("Page body exceeds maximum size: {Size} bytes", currentContent.Length);
            return currentContent;
        }

        // Оптимизируем создание wrappedBody используя StringBuilder
        var wrappedBodyBuilder = new StringBuilder(currentContent.Length + 200);
        wrappedBodyBuilder.Append("<root xmlns=\"");
        wrappedBodyBuilder.Append(XhtmlNamespace);
        wrappedBodyBuilder.Append("\" xmlns:ac=\"");
        wrappedBodyBuilder.Append(AtlassianConfluenceNamespace);
        wrappedBodyBuilder.Append("\" xmlns:ri=\"");
        wrappedBodyBuilder.Append(AtlassianResourceInterfaceNamespace);
        wrappedBodyBuilder.Append("\" xmlns:xi=\"");
        wrappedBodyBuilder.Append(XIncludeNamespace);
        wrappedBodyBuilder.Append("\">");
        wrappedBodyBuilder.Append(currentContent);
        wrappedBodyBuilder.Append("</root>");

        // Используем безопасный парсер XML для защиты от XXE
        XDocument document;
        try
        {
            document = ParseXmlSafely(wrappedBodyBuilder.ToString());
        }
        catch (System.Xml.XmlException ex)
        {
            _logger.LogError(ex, "Failed to parse XML document");
            return currentContent;
        }

        var root = document.Root;
        if (root == null)
        {
            return currentContent;
        }
        var xhtmlNs = (XNamespace)XhtmlNamespace;

        // ВАЖНО: Сохраняем "Статус публикации" из существующей страницы
        var publicationStatus = _parser.ExtractField(currentContent, "Статус публикации");
        if (string.IsNullOrWhiteSpace(publicationStatus))
        {
            publicationStatus = _parser.ExtractFieldFromXml(wrappedBodyBuilder.ToString(), "Статус публикации");
        }
        if (string.IsNullOrWhiteSpace(publicationStatus))
        {
            publicationStatus = details.PublicationStatus;
        }
        if (string.IsNullOrWhiteSpace(publicationStatus))
        {
            publicationStatus = "TEST";
        }

        var requestFtest = _parser.ExtractField(currentContent, "Заявка FTEST");
        var requestPreProd = _parser.ExtractField(currentContent, "Заявка PrePROD");
        var requestProd = _parser.ExtractField(currentContent, "Заявка PROD");

        UpdateTableCell(root, xhtmlNs, "Realm (Пространство)", EscapeHtml(details.Realm));
        UpdateTableCell(root, xhtmlNs, "Client ID (ID клиента)", EscapeHtml(details.ClientId));
        UpdateTableCell(root, xhtmlNs, "Name (Имя)", EscapeHtml(string.IsNullOrWhiteSpace(details.Name) ? details.ClientId : details.Name));
        UpdateTableCell(root, xhtmlNs, "Access Type (Тип доступа)", details.ClientAuthentication ? "confidential" : "public");
        UpdateTableCell(root, xhtmlNs, "Status (Статус)", FormatBooleanStatus(details.Enabled));
        UpdateTableCell(root, xhtmlNs, "Description (Описание)", EscapeHtml(details.Description ?? string.Empty));
        UpdateTableCell(root, xhtmlNs, "Standard flow", FormatBooleanStatus(details.StandardFlow));
        UpdateTableCell(root, xhtmlNs, "Direct Access Grants", FormatBooleanStatus(details.DirectAccessGrantsEnabled));
        UpdateTableCell(root, xhtmlNs, "Service Accounts", FormatBooleanStatus(details.ServiceAccountsEnabled));
        UpdateTableCell(root, xhtmlNs, "OAuth 2.0 Device Authorization Grant", FormatBooleanStatus(details.AuthorizationServicesEnabled));
        UpdateTableCell(root, xhtmlNs, "Client Scopes", BuildClientScopesDisplay(details.DefaultClientScopes, details.OptionalClientScopes));

        var redirectContent = $"{BuildRedirectUrisTable(details.RedirectUris)}<p class=\"auto-cursor-target\"><br /></p>";
        UpdateTableCell(root, xhtmlNs, "Valid Redirect URIs", redirectContent);

        // Извлекаем существующие локальные роли с их контурами
        var existingLocalRoles = _parser.ExtractLocalRoles(currentContent);
        var mergedLocalRoles = MergeRolesWithContours(existingLocalRoles, details.LocalRoles ?? Enumerable.Empty<string>());
        var localRolesContent = $"{BuildLocalRolesTableWithContours(mergedLocalRoles)}<p class=\"auto-cursor-target\"><br /></p>";
        UpdateTableCell(root, xhtmlNs, "Client Roles (Роль клиента)", localRolesContent);

        // Извлекаем существующие service роли с их контурами
        var existingServiceRoles = _parser.ExtractServiceRoles(currentContent);
        var mergedServiceRoles = MergeServiceRolesWithContours(existingServiceRoles, details.ServiceRoles ?? Enumerable.Empty<string>(), details.ClientId);
        var serviceRolesContent = $"{BuildServiceRolesTableWithContours(mergedServiceRoles, details.ClientId)}<p class=\"auto-cursor-target\"><br /></p>";
        UpdateTableCell(root, xhtmlNs, "Service Account Role", serviceRolesContent);

        // Сохраняем "Статус публикации"
        UpdateTableCell(root, xhtmlNs, "Статус публикации", EscapeHtml(publicationStatus ?? string.Empty));

        if (!string.IsNullOrWhiteSpace(requestFtest))
        {
            UpdateTableCell(root, xhtmlNs, "Заявка FTEST", EscapeHtml(requestFtest));
        }

        var ticketLinkHtml = BuildTicketLinkHtml(details.TicketNumber, details.TicketUrl);
        if (!string.IsNullOrWhiteSpace(ticketLinkHtml))
        {
            UpdateTableCell(root, xhtmlNs, "Заявка PrePROD", ticketLinkHtml);
        }
        else if (!string.IsNullOrWhiteSpace(requestPreProd))
        {
            UpdateTableCell(root, xhtmlNs, "Заявка PrePROD", EscapeHtml(requestPreProd));
        }

        if (!string.IsNullOrWhiteSpace(requestProd))
        {
            UpdateTableCell(root, xhtmlNs, "Заявка PROD", EscapeHtml(requestProd));
        }

        // Оптимизируем создание результата
        var estimatedLength = currentContent.Length + EstimatedContentBufferSize;
        var builder = new StringBuilder(estimatedLength);
        foreach (var node in root.Nodes())
        {
            builder.Append(node.ToString(System.Xml.Linq.SaveOptions.DisableFormatting));
        }

        return await Task.FromResult(builder.ToString()).ConfigureAwait(false);
    }

    public string BuildRealmPrefix(string? realm)
    {
        const string defaultPrefix = "INT";

        if (string.IsNullOrWhiteSpace(realm))
            return defaultPrefix;

        var trimmed = realm.Trim();
        if (trimmed.Length <= RealmPrefixLength)
            return trimmed.ToUpperInvariant();

        return trimmed.Substring(0, RealmPrefixLength).ToUpperInvariant();
    }

    #region Private Helper Methods

    private string GetCachedTemplate()
    {
        if (_cache == null)
        {
            return _templateProvider.Template.Body;
        }

        return _cache.GetOrCreate(TemplateCacheKey, entry =>
        {
            entry.AbsoluteExpirationRelativeToNow = TemplateCacheExpiration;
            return _templateProvider.Template.Body;
        }) ?? _templateProvider.Template.Body;
    }

    private string FormatBooleanStatus(bool value)
    {
        return value
            ? @"<span style=""color:var(--ds-text-accent-blue-bolder,#09326c);"">On</span>"
            : @"<span style=""color:var(--ds-text-accent-blue-bolder,#09326c);"">Off</span>";
    }

    private string BuildRedirectUrisTable(List<string>? redirectUris)
    {
        if (redirectUris == null || redirectUris.Count == 0)
        {
            return "<p>Нет настроенных Redirect URIs</p>";
        }

        var estimatedCapacity = EstimatedTableHeaderSize + (redirectUris.Count * EstimatedUriRowSize);
        var sb = new StringBuilder(estimatedCapacity);
        sb.Append(@"<table class=""wrapped relative-table"" style=""width: 100.0%;"">
<colgroup><col style=""width: 33.33%;"" /><col style=""width: 33.33%;"" /><col style=""width: 33.34%;"" /></colgroup>
<thead><tr>
<th style=""text-align: center;""><span style=""color:var(--ds-background-accent-lime-bolder,#5b7f24);"">TEST</span></th>
<th style=""text-align: center;""><span style=""color:var(--ds-background-accent-lime-bolder,#5b7f24);"">STAGE</span></th>
<th style=""text-align: center;""><span style=""color:var(--ds-background-accent-lime-bolder,#5b7f24);"">PROD</span></th>
</tr></thead>
<tbody>");

        foreach (var uri in redirectUris)
        {
            sb.Append($@"<tr>
<td>{EscapeHtml(uri)}</td>
<td></td>
<td></td>
</tr>");
        }

        sb.Append("</tbody></table>");
        return sb.ToString();
    }

    private string BuildLocalRolesTable(List<string>? localRoles, string contour = "TEST")
    {
        if (localRoles == null || localRoles.Count == 0)
        {
            return "<p>Нет локальных ролей</p>";
        }

        var estimatedCapacity = EstimatedTableHeaderSize + (localRoles.Count * EstimatedRoleRowSize);
        var sb = new StringBuilder(estimatedCapacity);
        sb.Append(@"<table class=""wrapped relative-table"" style=""width: 100.0%;"">
<colgroup><col style=""width: 40%;"" /><col style=""width: 40%;"" /><col style=""width: 20%;"" /></colgroup>
<thead><tr>
<th><span style=""color:var(--ds-background-accent-lime-bolder,#5b7f24);"">Название</span></th>
<th><span style=""color:var(--ds-background-accent-lime-bolder,#5b7f24);"">Описание</span></th>
<th><span style=""color:var(--ds-background-accent-lime-bolder,#5b7f24);"">Контур</span></th>
</tr></thead>
<tbody>");

        foreach (var role in localRoles)
        {
            sb.Append($@"<tr>
<td>{EscapeHtml(role)}</td>
<td></td>
<td>{EscapeHtml(contour)}</td>
</tr>");
        }

        sb.Append("</tbody></table>");
        return sb.ToString();
    }

    private string BuildLocalRolesTableWithContours(Dictionary<string, string> rolesWithContours)
    {
        if (rolesWithContours == null || rolesWithContours.Count == 0)
        {
            return "<p>Нет локальных ролей</p>";
        }

        var estimatedCapacity = EstimatedTableHeaderSize + (rolesWithContours.Count * EstimatedRoleRowSize);
        var sb = new StringBuilder(estimatedCapacity);
        sb.Append(@"<table class=""wrapped relative-table"" style=""width: 100.0%;"">
<colgroup><col style=""width: 40%;"" /><col style=""width: 40%;"" /><col style=""width: 20%;"" /></colgroup>
<thead><tr>
<th><span style=""color:var(--ds-background-accent-lime-bolder,#5b7f24);"">Название</span></th>
<th><span style=""color:var(--ds-background-accent-lime-bolder,#5b7f24);"">Описание</span></th>
<th><span style=""color:var(--ds-background-accent-lime-bolder,#5b7f24);"">Контур</span></th>
</tr></thead>
<tbody>");

        foreach (var role in rolesWithContours.OrderBy(r => r.Key))
        {
            sb.Append($@"<tr>
<td>{EscapeHtml(role.Key)}</td>
<td></td>
<td>{EscapeHtml(role.Value)}</td>
</tr>");
        }

        sb.Append("</tbody></table>");
        return sb.ToString();
    }

    private string BuildServiceRolesTableWithContours(Dictionary<string, string> rolesWithContours, string clientId)
    {
        if (string.IsNullOrWhiteSpace(clientId))
        {
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        }

        if (rolesWithContours == null || rolesWithContours.Count == 0)
        {
            return "<p>Нет Service Account ролей</p>";
        }

        var estimatedCapacity = EstimatedTableHeaderSize + (rolesWithContours.Count * EstimatedServiceRoleRowSize);
        var sb = new StringBuilder(estimatedCapacity);
        sb.Append(@"<table class=""wrapped relative-table"" style=""width: 100.0%;"">
<colgroup><col style=""width: 40%;"" /><col style=""width: 40%;"" /><col style=""width: 20%;"" /></colgroup>
<thead><tr>
<th><span style=""color:var(--ds-background-accent-lime-bolder,#5b7f24);"">Название</span></th>
<th><span style=""color:var(--ds-background-accent-lime-bolder,#5b7f24);"">ClientID</span></th>
<th><span style=""color:var(--ds-background-accent-lime-bolder,#5b7f24);"">Контур</span></th>
</tr></thead>
<tbody>");

        foreach (var roleEntry in rolesWithContours.OrderBy(r => r.Key))
        {
            string roleName;
            string roleClientId;

            if (roleEntry.Key.Contains('|'))
            {
                var parts = roleEntry.Key.Split('|', 2);
                roleName = parts[0];
                roleClientId = parts.Length > 1 ? parts[1] : "unknown";
            }
            else
            {
                roleName = roleEntry.Key;
                roleClientId = "realm";
            }

            sb.Append($@"<tr>
<td>{EscapeHtml(roleName)}</td>
<td>{EscapeHtml(roleClientId)}</td>
<td>{EscapeHtml(roleEntry.Value)}</td>
</tr>");
        }

        sb.Append("</tbody></table>");
        return sb.ToString();
    }

    private string BuildClientScopesDisplay(IEnumerable<string>? defaultScopes, IEnumerable<string>? optionalScopes)
    {
        var defaults = (defaultScopes?
            .Where(s => !string.IsNullOrWhiteSpace(s))
            .Select(s => s.Trim())
            .Distinct(StringComparer.Ordinal) ?? Enumerable.Empty<string>()).ToList();

        var optionals = (optionalScopes?
            .Where(s => !string.IsNullOrWhiteSpace(s))
            .Select(s => s.Trim())
            .Distinct(StringComparer.Ordinal) ?? Enumerable.Empty<string>()).ToList();

        if (defaults.Count == 0 && optionals.Count == 0)
        {
            return "<em><span style=\"color:var(--ds-text-accent-blue-bolder,#09326c);\">—</span></em>";
        }

        var estimatedCapacity = EstimatedScopesBaseSize + ((defaults.Count + optionals.Count) * EstimatedScopeSize);
        var sb = new StringBuilder(estimatedCapacity);
        sb.Append("<div>");
        if (defaults.Count > 0)
        {
            sb.Append("<p><strong>Default:</strong> ");
            sb.Append(EscapeHtml(string.Join(", ", defaults)));
            sb.Append("</p>");
        }

        if (optionals.Count > 0)
        {
            sb.Append("<p><strong>Optional:</strong> ");
            sb.Append(EscapeHtml(string.Join(", ", optionals)));
            sb.Append("</p>");
        }

        sb.Append("</div>");
        return sb.ToString();
    }

    private string? BuildTicketLinkHtml(string? ticketNumber, string? ticketUrl)
    {
        var hasNumber = !string.IsNullOrWhiteSpace(ticketNumber);
        var hasUrl = !string.IsNullOrWhiteSpace(ticketUrl);

        if (!hasNumber && !hasUrl)
        {
            return null;
        }

        var displayText = hasNumber ? ticketNumber!.Trim() : ticketUrl!.Trim();
        var encodedText = EscapeHtml(displayText);

        if (hasUrl)
        {
            var trimmedUrl = ticketUrl!.Trim();

            // Валидация URL - разрешаем только http/https
            if (!Uri.TryCreate(trimmedUrl, UriKind.Absolute, out var uri) ||
                (uri.Scheme != "http" && uri.Scheme != "https"))
            {
                _logger.LogWarning("Invalid URL scheme in ticket URL: {Url}", trimmedUrl);
                return $"<strong>{encodedText}</strong>";
            }

            var encodedUrl = EscapeHtmlAttribute(uri.ToString());
            return $"<strong><a href=\"{encodedUrl}\" target=\"_blank\" rel=\"noopener noreferrer\">{encodedText}</a></strong>";
        }

        return $"<strong>{encodedText}</strong>";
    }

    private Dictionary<string, string> MergeRolesWithContours(Dictionary<string, string> existingRoles, IEnumerable<string> newRoles)
    {
        if (existingRoles == null)
        {
            throw new ArgumentNullException(nameof(existingRoles));
        }

        var newRolesCount = 0;
        if (newRoles != null)
        {
            if (!newRoles.TryGetNonEnumeratedCount(out newRolesCount))
            {
                newRolesCount = newRoles.Count();
            }
        }
        var estimatedCapacity = existingRoles.Count + newRolesCount;
        var merged = new Dictionary<string, string>(estimatedCapacity, StringComparer.OrdinalIgnoreCase);

        foreach (var existingRole in existingRoles)
        {
            merged[existingRole.Key] = existingRole.Value;
        }

        if (newRoles != null)
        {
            foreach (var newRole in newRoles)
            {
                if (!string.IsNullOrWhiteSpace(newRole) && !merged.ContainsKey(newRole))
                {
                    merged[newRole] = "TEST";
                }
            }
        }

        return merged;
    }

    private Dictionary<string, string> MergeServiceRolesWithContours(Dictionary<string, string> existingRoles, IEnumerable<string> newRoles, string clientId)
    {
        if (existingRoles == null)
        {
            throw new ArgumentNullException(nameof(existingRoles));
        }

        if (string.IsNullOrWhiteSpace(clientId))
        {
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        }

        var newRolesCount = 0;
        if (newRoles != null)
        {
            if (!newRoles.TryGetNonEnumeratedCount(out newRolesCount))
            {
                newRolesCount = newRoles.Count();
            }
        }
        var estimatedCapacity = existingRoles.Count + newRolesCount;
        var merged = new Dictionary<string, string>(estimatedCapacity, StringComparer.OrdinalIgnoreCase);

        foreach (var existingRole in existingRoles)
        {
            merged[existingRole.Key] = existingRole.Value;
        }

        if (newRoles != null)
        {
            foreach (var newRole in newRoles)
            {
                if (string.IsNullOrWhiteSpace(newRole))
                    continue;

                string key;
                string roleName;
                string roleClientId;

                if (newRole.Contains('|'))
                {
                    var firstSplit = newRole.Split('|', 2);
                    if (firstSplit.Length == 2)
                    {
                        roleClientId = firstSplit[0];
                        var parts = firstSplit[1].Split(':', 3);
                        roleName = parts.Length == 3 ? parts[2] : newRole;
                    }
                    else
                    {
                        roleName = newRole;
                        roleClientId = "unknown";
                    }
                }
                else
                {
                    roleName = newRole;
                    roleClientId = "realm";
                }

                key = roleClientId == "realm" ? roleName : $"{roleName}|{roleClientId}";

                if (!merged.ContainsKey(key))
                {
                    merged[key] = "TEST";
                }
            }
        }

        return merged;
    }

    private void UpdateTableCell(XElement root, XNamespace xhtmlNs, string headerLabel, string newInnerHtml)
    {
        if (root == null || string.IsNullOrWhiteSpace(headerLabel))
        {
            return;
        }

        var rows = root.Descendants(xhtmlNs + "tr").Concat(root.Descendants("tr"));
        foreach (var row in rows)
        {
            var header = row.Elements(xhtmlNs + "th").Concat(row.Elements("th")).FirstOrDefault();
            if (header == null)
            {
                continue;
            }

            var headerText = WebUtility.HtmlDecode(header.Value ?? string.Empty).Trim();
            if (!headerText.Contains(headerLabel, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            var cell = row.Elements(xhtmlNs + "td").Concat(row.Elements("td")).FirstOrDefault();
            if (cell == null)
            {
                continue;
            }

            if (!string.IsNullOrWhiteSpace(newInnerHtml) || cell.Value != null)
            {
                cell.ReplaceNodes(ParseFragment(newInnerHtml, xhtmlNs));
            }
            break;
        }
    }

    private IEnumerable<XNode> ParseFragment(string? htmlFragment, XNamespace xhtmlNs)
    {
        if (string.IsNullOrWhiteSpace(htmlFragment))
        {
            return new[] { new XText(string.Empty) };
        }

        if (htmlFragment.Length > MaxFragmentSizeBytes)
        {
            _logger.LogWarning("HTML fragment exceeds maximum size: {Size} bytes", htmlFragment.Length);
            return new[] { new XText(htmlFragment) };
        }

        // В C# нельзя использовать yield return в try-catch блоках
        // Используем вспомогательный метод для парсинга
        return ParseFragmentInternal(htmlFragment);
    }

    /// <summary>
    /// Вспомогательный метод для парсинга HTML фрагмента с обработкой ошибок.
    /// </summary>
    private IEnumerable<XNode> ParseFragmentInternal(string htmlFragment)
    {
        try
        {
            var wrapper = XElement.Parse(
                $"<wrapper xmlns=\"{XhtmlNamespace}\" xmlns:ac=\"{AtlassianConfluenceNamespace}\" xmlns:ri=\"{AtlassianResourceInterfaceNamespace}\" xmlns:xi=\"{XIncludeNamespace}\">{htmlFragment}</wrapper>",
                System.Xml.Linq.LoadOptions.PreserveWhitespace);

            return wrapper.Nodes();
        }
        catch (System.Xml.XmlException ex)
        {
            _logger.LogWarning(ex, "Failed to parse HTML fragment");
            return new[] { new XText(htmlFragment) };
        }
    }

    private string EscapeHtml(string text)
    {
        if (string.IsNullOrEmpty(text))
            return string.Empty;

        return WebUtility.HtmlEncode(text);
    }

    private string EscapeHtmlAttribute(string text)
    {
        if (string.IsNullOrEmpty(text))
            return string.Empty;

        return WebUtility.HtmlEncode(text)
            .Replace("\"", "&quot;")
            .Replace("'", "&#39;");
    }

    private XDocument ParseXmlSafely(string xmlContent)
    {
        var settings = new System.Xml.XmlReaderSettings
        {
            DtdProcessing = System.Xml.DtdProcessing.Prohibit,
            XmlResolver = null,
            MaxCharactersFromEntities = 0,
            MaxCharactersInDocument = MaxDocumentSizeBytes
        };

        using var reader = System.Xml.XmlReader.Create(new System.IO.StringReader(xmlContent), settings);
        return XDocument.Load(reader, System.Xml.Linq.LoadOptions.None);
    }

    #endregion
}

