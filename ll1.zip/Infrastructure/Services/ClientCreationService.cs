using new_assistant.Core.Interfaces;
using new_assistant.Core.DTOs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using System.Security.Cryptography;
using System.Text;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Linq;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для создания клиентов
/// </summary>
public class ClientCreationService : IClientCreationService
{
    // Константы для валидации
    private const int MaxClientIdLength = 255;
    private const int MaxRealmLength = 255;
    private const int MaxNameLength = 255;
    private const int MaxDescriptionLength = 1000;
    private const int MaxUsernameLength = 255;
    private const int MaxRedirectUrisCount = 100;
    private const int MaxOwnerSystemNameLength = 255;
    private const int MaxOwnerNameLength = 255;
    private const int MaxSupportManagerLength = 255;
    private const int MaxTicketNumberLength = 100;
    
    // Regex для валидации идентификаторов Keycloak (проблема 25)
    private static readonly Regex ValidIdentifierRegex = new(@"^[a-zA-Z0-9_-]+$", RegexOptions.Compiled);
    
    // Допустимые значения PublicationStatus (проблема 35)
    private static readonly HashSet<string> ValidPublicationStatuses = new(StringComparer.OrdinalIgnoreCase)
    {
        "TEST", "PROD", "STAGE", "DEV"
    };

    private readonly IKeycloakAdminService _keycloakAdminService;
    private readonly IClientOwnershipService _ownershipService;
    private readonly IAuditService _auditService;
    private readonly IConfluenceService? _confluenceService;
    private readonly IClientArchiveService _archiveService;
    private readonly IEmailService _emailService;
    private readonly KeycloakAdminSettings _adminSettings;
    private readonly IConfiguration _configuration;
    private readonly ILogger<ClientCreationService> _logger;

    /// <summary>
    /// Событие успешного создания клиента (асинхронное)
    /// </summary>
    public event Func<string, string, Task>? OnClientCreated;

    public ClientCreationService(
        IKeycloakAdminService keycloakAdminService, 
        IClientOwnershipService ownershipService,
        IAuditService auditService,
        IClientArchiveService archiveService,
        IEmailService emailService,
        IOptions<KeycloakAdminSettings> adminSettings,
        IConfiguration configuration,
        ILogger<ClientCreationService> logger,
        IConfluenceService? confluenceService = null)
    {
        _keycloakAdminService = keycloakAdminService;
        _ownershipService = ownershipService;
        _auditService = auditService;
        _archiveService = archiveService;
        _emailService = emailService;
        _adminSettings = adminSettings.Value;
        _configuration = configuration;
        _confluenceService = confluenceService;
        _logger = logger;
    }

    /// <summary>
    /// Создать клиента в Keycloak
    /// </summary>
    public async Task<CreateClientResponse> CreateClientAsync(
        ClientCreationData data, 
        string? username = null,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных данных (проблемы 1, 20, 24, 25, 33)
        ValidateClientCreationData(data, username);
        
        // Исправление проблемы 23: Проверка существования клиента перед созданием (защита от race condition)
        // Исправление финальной оценки 1: Улучшенная обработка исключений при проверке существования
        try
        {
            var existingClient = await _keycloakAdminService.GetClientDetailsAsync(
                data.ClientId, data.Realm, cancellationToken).ConfigureAwait(false);
            
            if (existingClient != null)
            {
                _logger.LogWarning("Попытка создать уже существующего клиента {ClientId} в реалме {Realm}", 
                    data.ClientId, data.Realm);
                return new CreateClientResponse
                {
                    Success = false,
                    ErrorMessage = $"Клиент {data.ClientId} уже существует в реалме {data.Realm}"
                };
            }
        }
        catch (HttpRequestException ex) when (
            ex.Message.Contains("NotFound", StringComparison.OrdinalIgnoreCase) || 
            ex.Message.Contains("404", StringComparison.OrdinalIgnoreCase))
        {
            // Клиент не найден - это нормально, продолжаем создание
            _logger.LogDebug("Клиент {ClientId} не найден, продолжаем создание", data.ClientId);
        }
        catch (Exception ex)
        {
            // Другие ошибки (сетевые, таймауты) - логируем предупреждение, но продолжаем
            // Keycloak сам вернет ошибку при попытке создать дубликат
            _logger.LogWarning(ex, 
                "Ошибка при проверке существования клиента {ClientId} в реалме {Realm}, продолжаем создание", 
                data.ClientId, data.Realm);
        }

        string? clientInternalId = null;
        bool ownershipGranted = false;
        
        try
        {
            // Преобразуем данные из UI в DTO для API
            var request = new CreateClientRequestDto
            {
                Realm = data.Realm,
                ClientId = data.ClientId,
                Name = data.Name,
                Description = data.Description,
                ClientAuthentication = data.ClientAuthentication,
                StandardFlow = data.StandardFlow,
                ServiceAccount = data.ServiceAccount,
                LocalRoles = data.LocalRoles,
                RedirectUris = data.RedirectUris,
                OwnerSystemName = data.OwnerSystemName,
                OwnerSystemUrl = data.OwnerSystemUrl,
                OwnerName = data.OwnerName,
                SupportManager = data.SupportManager
            };

            // Создаем клиента через KeycloakAdminService
            // Исправление проблемы 15: проверка на пустой clientInternalId уже есть ниже
            // Исправление проблемы 17, 26: добавлен timeout для операции с правильным использованием CancellationToken
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            cts.CancelAfter(TimeSpan.FromSeconds(_adminSettings.RequestTimeoutSeconds));
            
            try
            {
                clientInternalId = await _keycloakAdminService
                    .CreateClientAsync(request, cts.Token)
                    .ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (cts.Token.IsCancellationRequested)
            {
                _logger.LogError("Таймаут при создании клиента {ClientId} в реалме {Realm}", data.ClientId, data.Realm);
                throw new TimeoutException($"Операция создания клиента {data.ClientId} превысила время ожидания ({_adminSettings.RequestTimeoutSeconds} сек)");
            }
            
            if (string.IsNullOrWhiteSpace(clientInternalId))
            {
                throw new InvalidOperationException(
                    $"Keycloak вернул пустой InternalId для клиента {data.ClientId}");
            }

            // Если указан username, записываем владение клиентом
            if (!string.IsNullOrEmpty(username))
            {
                await _ownershipService.GrantOwnershipAsync(username, data.ClientId, data.Realm).ConfigureAwait(false);
                ownershipGranted = true;
            }

            // Создаем Wiki страницу в Confluence (если интеграция включена)
            // Исправление проблемы 3: не мутируем входные данные
            string? wikiPageUrl = null;
            if (_confluenceService != null)
            {
                try
                {
                    // Исправление проблемы 9: используем значение из конфигурации вместо hardcoded "TEST"
                    var publicationStatus = data.PublicationStatus ?? 
                                          _configuration.GetValue<string>("DefaultEnvironment") ?? 
                                          "TEST";
                    // Передаем publicationStatus, если метод поддерживает, иначе используем data
                    wikiPageUrl = await _confluenceService.CreateClientPageAsync(data, username ?? "system").ConfigureAwait(false);
                    
                    // Исправление проблемы 4: удален пустой блок кода, добавлено логирование
                    if (wikiPageUrl != null)
                    {
                        _logger.LogInformation("Wiki страница создана для клиента {ClientId}: {WikiUrl}", data.ClientId, wikiPageUrl);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, 
                        "Не удалось создать Wiki страницу для клиента {ClientId}. Продолжаем без Wiki.", 
                        data.ClientId);
                    // Продолжаем, так как Wiki не критично
                }
            }
            
            // Логируем создание клиента (исправление проблемы 14, 30: структурированное логирование без чувствительных данных)
            var description = $"Создан клиент {data.ClientId} в реалме {data.Realm}";
            if (wikiPageUrl != null)
            {
                description += ". Wiki страница создана";
                // Не логируем сам URL, только факт создания (проблема 30)
            }
            if (!string.IsNullOrEmpty(username))
            {
                await _auditService.LogClientCreatedAsync(username, data.ClientId, data.Realm, description).ConfigureAwait(false);
                _logger.LogInformation(
                    "Клиент {ClientId} успешно создан в реалме {Realm} пользователем {Username}. Wiki: {HasWiki}",
                    data.ClientId, 
                    data.Realm, 
                    username,
                    wikiPageUrl != null ? "да" : "нет");
            }
            
            // Исправление проблемы 8: асинхронное событие
            if (OnClientCreated != null)
            {
                try
                {
                    await Task.WhenAll(OnClientCreated.GetInvocationList()
                        .Cast<Func<string, string, Task>>()
                        .Select(handler => handler(data.ClientId, data.Realm))).ConfigureAwait(false);
                }
                catch (Exception eventEx)
                {
                    _logger.LogError(eventEx, "Ошибка в обработчике события OnClientCreated для клиента {ClientId}", data.ClientId);
                    // Не прерываем выполнение из-за ошибки в обработчике события
                }
            }
            
            return new CreateClientResponse
            {
                Success = true,
                ClientId = data.ClientId,
                KeycloakInternalId = clientInternalId,
                WikiPageUrl = wikiPageUrl
            };
        }
        catch (TimeoutException)
        {
            // Исправление проблемы 32: Rollback при TimeoutException
            await PerformRollbackAsync(ownershipGranted, username, clientInternalId, data.ClientId, data.Realm).ConfigureAwait(false);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при создании клиента {ClientId} в реалме {Realm}", data.ClientId, data.Realm);
            
            // Исправление проблемы 2: Rollback механизм (компенсирующие транзакции)
            await PerformRollbackAsync(ownershipGranted, username, clientInternalId, data.ClientId, data.Realm).ConfigureAwait(false);
            
            // Извлекаем более конкретное сообщение об ошибке
            var errorMessage = ExtractSpecificErrorMessage(ex, data.ClientId, data.Realm);
            
            return new CreateClientResponse
            {
                Success = false,
                ErrorMessage = errorMessage
            };
        }
    }

    /// <summary>
    /// Создать клиента с расширенной информацией (для администраторов)
    /// Включает создание архива, отправку email и возврат полной информации
    /// Исправление проблемы 11: всегда возвращает DTO, даже при ошибке (ErrorMessage будет заполнен)
    /// </summary>
    public async Task<ClientCreationResultDto> CreateClientWithFullInfoAsync(
        ClientCreationData data, 
        string? username = null,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных данных (проблема 1)
        ValidateClientCreationData(data, username);

        CreateClientResponse? response = null;
        string? clientInternalId = null;
        bool ownershipGranted = false;

        try
        {
            // 1. Создаем клиента
            response = await CreateClientAsync(data, username, cancellationToken).ConfigureAwait(false);

            if (!response.Success)
            {
                _logger.LogError("Не удалось создать клиента: {Error}", response.ErrorMessage);
                return new ClientCreationResultDto
                {
                    ClientId = data.ClientId,
                    Realm = data.Realm,
                    ErrorMessage = response.ErrorMessage
                };
            }
            
            // Сохраняем clientInternalId для возможного rollback (проблема 19)
            clientInternalId = response.KeycloakInternalId;
            ownershipGranted = !string.IsNullOrEmpty(username);

            // 2-4. Параллельное выполнение независимых операций (исправление проблемы 13: оптимизация производительности)
            // Исправление проблемы 17, 26: добавлен timeout для операций с правильным использованием CancellationToken
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            cts.CancelAfter(TimeSpan.FromSeconds(_adminSettings.RequestTimeoutSeconds));
            var clientDetailsTask = _keycloakAdminService.GetClientDetailsAsync(data.ClientId, data.Realm, cts.Token);
            var baseUrlTask = Task.FromResult(BuildBaseUrl());

            try
            {
                await Task.WhenAll(clientDetailsTask, baseUrlTask).WaitAsync(cts.Token).ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (cts.Token.IsCancellationRequested)
            {
                _logger.LogError("Таймаут при получении деталей клиента {ClientId} в реалме {Realm}", data.ClientId, data.Realm);
                throw new TimeoutException($"Операция получения деталей клиента {data.ClientId} превысила время ожидания ({_adminSettings.RequestTimeoutSeconds} сек)");
            }

            var clientDetails = await clientDetailsTask.ConfigureAwait(false);
            var baseAuthorityUrl = await baseUrlTask.ConfigureAwait(false);

            var clientSecret = clientDetails?.ClientSecret;

            if (string.IsNullOrEmpty(clientSecret))
            {
                _logger.LogWarning("Не удалось получить Client Secret для {ClientId}", data.ClientId);
                clientSecret = "ERROR: Secret не получен";
            }
            else
            {
                // Исправление проблемы 12: логируем только хеш вместо полного значения
                var secretHash = Convert.ToBase64String(SHA256.HashData(Encoding.UTF8.GetBytes(clientSecret)));
                _logger.LogInformation("Client Secret создан для {ClientId}: {SecretHash}", data.ClientId, secretHash);
            }

            // 3. Создаем защищенный архив (финальная оценка 3: обработка ошибок как некритичной операции)
            string? archivePath = null;
            string? archivePassword = null;
            try
            {
                (archivePath, archivePassword) = _archiveService.CreateClientCredentialsPackage(
                    data.ClientId, 
                    clientSecret);
                
                // Исправление проблемы 12: логируем только хеш пароля архива
                if (!string.IsNullOrEmpty(archivePassword))
                {
                    var passwordHash = Convert.ToBase64String(SHA256.HashData(Encoding.UTF8.GetBytes(archivePassword)));
                    _logger.LogInformation("Пароль архива создан для {ClientId}: {PasswordHash}", data.ClientId, passwordHash);
                }
            }
            catch (Exception archiveEx)
            {
                // Архив не критичен для создания клиента, продолжаем без него
                _logger.LogWarning(archiveEx, 
                    "Не удалось создать архив для клиента {ClientId}. Продолжаем без архива.", 
                    data.ClientId);
                // Устанавливаем значения по умолчанию
                archivePath = null;
                archivePassword = null;
            }
            
            if (string.IsNullOrWhiteSpace(baseAuthorityUrl))
            {
                _logger.LogError("Не удалось определить BaseUrl для формирования endpoints для клиента {ClientId}", data.ClientId);
                throw new InvalidOperationException("BaseUrl не настроен");
            }
            
            // Логируем для отладки
            _logger.LogDebug("Сформирован baseAuthorityUrl для email: {BaseUrl}", baseAuthorityUrl);

            // 5. Формируем результат
            var wellKnownEndpoint = $"{baseAuthorityUrl}/realms/{data.Realm}/.well-known/openid-configuration";

            // 6. Отправляем email если указан (используем тот же baseAuthorityUrl)
            // Исправление проблемы 18: проверка валидности email
            if (!string.IsNullOrWhiteSpace(data.NotificationEmail))
            {
                if (!IsValidEmail(data.NotificationEmail))
                {
                    _logger.LogWarning("Некорректный email адрес: {Email} для клиента {ClientId}", data.NotificationEmail, data.ClientId);
                    throw new ArgumentException($"Некорректный email адрес: {data.NotificationEmail}", nameof(data));
                }
                
                try
                {
                    // Формируем полные URL для realm и endpoints (как в ResolveRealmUrl и GetEndpointsUrl в модальном окне)
                    var realmUrlForEmail = $"{baseAuthorityUrl}/realms/{data.Realm}";
                    var endpointsUrlForEmail = $"{baseAuthorityUrl}/realms/{data.Realm}/.well-known/openid-configuration";

                    // Исправление проблемы 9: используем значение из конфигурации вместо hardcoded "TEST"
                    var environment = data.PublicationStatus ?? 
                                     _configuration.GetValue<string>("DefaultEnvironment") ?? 
                                     "TEST";

                    // Исправление проблемы 17: timeout для отправки email уже реализован в EmailService
                    var emailSent = await _emailService.SendClientCredentialsEmailAsync(
                        data.NotificationEmail,
                        data.ClientId,
                        data.Realm,
                        archivePassword ?? string.Empty,
                        data.TicketNumber,
                        data.TicketUrl,
                        response.WikiPageUrl,
                        environment: environment,
                        baseUrl: realmUrlForEmail,
                        endpointsUrl: endpointsUrlForEmail).ConfigureAwait(false);

                    if (emailSent)
                    {
                        await _auditService.LogEmailSentAsync(
                            username ?? "system",
                            data.ClientId,
                            data.Realm,
                            $"Email с учетными данными отправлен на {data.NotificationEmail}. Ticket: {data.TicketNumber ?? "не указан"}").ConfigureAwait(false);
                    }
                    else
                    {
                        _logger.LogWarning("Не удалось отправить email на {Email} для клиента {ClientId}", 
                            data.NotificationEmail, data.ClientId);
                    }
                }
                catch (Exception emailEx)
                {
                    _logger.LogError(emailEx, "Ошибка при отправке email для клиента {ClientId}", data.ClientId);
                }
            }

            var result = new ClientCreationResultDto
            {
                ClientId = data.ClientId,
                Realm = data.Realm,
                ClientSecret = clientSecret,
                BaseUrl = baseAuthorityUrl,
                Environment = string.Empty,
                WikiPageUrl = response.WikiPageUrl,
                WellKnownEndpoint = wellKnownEndpoint,
                ArchivePassword = archivePassword,
                ArchivePath = archivePath
            };

            return result;
        }
        catch (TimeoutException)
        {
            // Исправление проблемы 19, 32: Rollback при ошибке в CreateClientWithFullInfoAsync
            await PerformRollbackAsync(ownershipGranted, username, clientInternalId, data.ClientId, data.Realm).ConfigureAwait(false);
            
            return new ClientCreationResultDto
            {
                ClientId = data.ClientId ?? string.Empty,
                Realm = data.Realm ?? string.Empty,
                ErrorMessage = $"Таймаут при создании клиента с полной информацией"
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Критическая ошибка при создании клиента {ClientId} с полной информацией", 
                data.ClientId);
            
            // Исправление проблемы 19: Rollback при ошибке в CreateClientWithFullInfoAsync
            if (response?.Success == true && !string.IsNullOrWhiteSpace(clientInternalId))
            {
                await PerformRollbackAsync(ownershipGranted, username, clientInternalId, data.ClientId, data.Realm).ConfigureAwait(false);
            }
            
            // Исправление проблемы 11: всегда возвращаем DTO вместо null
            return new ClientCreationResultDto
            {
                ClientId = data.ClientId ?? string.Empty,
                Realm = data.Realm ?? string.Empty,
                ErrorMessage = $"Критическая ошибка: {ex.Message}"
            };
        }
    }

    /// <summary>
    /// Формирует базовый URL для Keycloak (исправление проблемы 5: унифицированная логика)
    /// </summary>
    private string BuildBaseUrl()
    {
        // Сначала пробуем из настроек
        var baseUrl = _adminSettings.BaseUrl ?? string.Empty;
        
        // Если пусто, пробуем из конфигурации
        if (string.IsNullOrWhiteSpace(baseUrl))
        {
            baseUrl = _configuration.GetValue<string>("KeycloakAdmin:BaseUrl") ?? string.Empty;
        }
        
        if (string.IsNullOrWhiteSpace(baseUrl))
        {
            _logger.LogWarning("KeycloakAdmin:BaseUrl не найден в конфигурации");
            return string.Empty;
        }
        
        // Применяем legacy path если нужно
        var useLegacy = _adminSettings.UseLegacyAuthPath || 
                        _configuration.GetValue<bool>("KeycloakAdmin:UseLegacyAuthPath");
        
        if (useLegacy && !baseUrl.EndsWith("/auth", StringComparison.OrdinalIgnoreCase))
        {
            baseUrl = baseUrl.TrimEnd('/') + "/auth";
        }
        
        return baseUrl.TrimEnd('/');
    }

    /// <summary>
    /// Извлекает конкретное сообщение об ошибке из исключения (исправление проблемы 6)
    /// </summary>
    private string ExtractSpecificErrorMessage(Exception ex, string clientId, string realm)
    {
        // Обрабатываем вложенные исключения
        var currentEx = ex;
        while (currentEx != null)
        {
            if (currentEx is HttpRequestException httpEx)
            {
                var message = httpEx.Message;
                
                // Используем StringComparison.OrdinalIgnoreCase для всех проверок
                if (message.Contains("already exists", StringComparison.OrdinalIgnoreCase) || 
                    message.Contains("уже существует", StringComparison.OrdinalIgnoreCase))
                {
                    return $"Клиент {clientId} уже существует в реалме {realm}";
                }
                
                if (message.Contains("Conflict", StringComparison.OrdinalIgnoreCase))
                {
                    return $"Конфликт при создании клиента {clientId}: клиент уже существует";
                }
                
                if (message.Contains("Bad Request", StringComparison.OrdinalIgnoreCase))
                {
                    return $"Некорректные данные для создания клиента {clientId}";
                }
                
                if (message.Contains("Forbidden", StringComparison.OrdinalIgnoreCase))
                {
                    return $"Недостаточно прав для создания клиента {clientId}";
                }
                
                if (message.Contains("Unauthorized", StringComparison.OrdinalIgnoreCase))
                {
                    return $"Ошибка аутентификации при создании клиента {clientId}";
                }
                
                // Возвращаем сообщение для HttpRequestException
                return message;
            }
            
            // Проверяем вложенное исключение
            currentEx = currentEx.InnerException;
        }
        
        // Для других типов исключений
        return $"Ошибка создания клиента: {ex.Message}";
    }

    /// <summary>
    /// Проверяет валидность email адреса (исправление проблемы 18)
    /// </summary>
    private static bool IsValidEmail(string email)
    {
        if (string.IsNullOrWhiteSpace(email))
            return false;

        try
        {
            var addr = new MailAddress(email);
            return addr.Address == email;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Валидация данных для создания клиента (проблемы 20, 21, 22, 24, 25, 27, 28, 31, 33, 35)
    /// </summary>
    private void ValidateClientCreationData(ClientCreationData data, string? username)
    {
        if (data == null)
            throw new ArgumentNullException(nameof(data));
        
        // Валидация ClientId (проблемы 20, 25)
        if (string.IsNullOrWhiteSpace(data.ClientId))
            throw new ArgumentException("ClientId не может быть пустым", nameof(data));
        
        if (data.ClientId.Length > MaxClientIdLength)
            throw new ArgumentException($"ClientId не может быть длиннее {MaxClientIdLength} символов", nameof(data));
        
        if (!IsValidKeycloakIdentifier(data.ClientId))
            throw new ArgumentException(
                "ClientId может содержать только латинские буквы, цифры, дефисы и подчеркивания", 
                nameof(data));
        
        // Валидация Realm (проблемы 20, 25)
        if (string.IsNullOrWhiteSpace(data.Realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(data));
        
        if (data.Realm.Length > MaxRealmLength)
            throw new ArgumentException($"Realm не может быть длиннее {MaxRealmLength} символов", nameof(data));
        
        if (!IsValidKeycloakIdentifier(data.Realm))
            throw new ArgumentException(
                "Realm может содержать только латинские буквы, цифры, дефисы и подчеркивания", 
                nameof(data));
        
        // Валидация Name (проблема 20)
        if (!string.IsNullOrEmpty(data.Name) && data.Name.Length > MaxNameLength)
            throw new ArgumentException($"Name не может быть длиннее {MaxNameLength} символов", nameof(data));
        
        // Валидация Description (проблема 31)
        if (!string.IsNullOrEmpty(data.Description) && data.Description.Length > MaxDescriptionLength)
            throw new ArgumentException($"Description не может быть длиннее {MaxDescriptionLength} символов", nameof(data));
        
        // Валидация коллекций (проблема 24, финальная оценка 2)
        if (data.LocalRoles == null)
            throw new ArgumentException("LocalRoles не может быть null", nameof(data));
        
        // Валидация содержимого LocalRoles (финальная оценка 2)
        if (data.LocalRoles.Any(string.IsNullOrWhiteSpace))
            throw new ArgumentException("LocalRoles не может содержать пустые значения", nameof(data));
        
        if (data.LocalRoles.Count != data.LocalRoles.Distinct(StringComparer.OrdinalIgnoreCase).Count())
            throw new ArgumentException("LocalRoles содержит дубликаты", nameof(data));
        
        foreach (var role in data.LocalRoles)
        {
            if (!IsValidKeycloakIdentifier(role))
                throw new ArgumentException($"Некорректный формат роли: {role}", nameof(data));
        }
        
        if (data.RedirectUris == null)
            throw new ArgumentException("RedirectUris не может быть null", nameof(data));
        
        // Валидация RedirectUris (проблемы 22, 27, 28, финальная оценка 6: оптимизированная проверка дубликатов)
        if (data.RedirectUris.Count > MaxRedirectUrisCount)
            throw new ArgumentException(
                $"Количество RedirectUris не может превышать {MaxRedirectUrisCount}", 
                nameof(data));
        
        // Оптимизированная проверка на дубликаты (финальная оценка 6)
        var seenUris = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var uri in data.RedirectUris)
        {
            if (string.IsNullOrWhiteSpace(uri))
                throw new ArgumentException("RedirectUri не может быть пустым", nameof(data));
            
            if (!seenUris.Add(uri))
                throw new ArgumentException($"RedirectUris содержит дубликаты: {uri}", nameof(data));
            
            if (!Uri.TryCreate(uri, UriKind.Absolute, out var parsedUri))
                throw new ArgumentException($"Некорректный RedirectUri: {uri}", nameof(data));
            
            if (parsedUri.Scheme != Uri.UriSchemeHttp && parsedUri.Scheme != Uri.UriSchemeHttps)
                throw new ArgumentException($"RedirectUri должен использовать http или https: {uri}", nameof(data));
        }
        
        // Валидация длины строковых полей (финальная оценка 5)
        if (!string.IsNullOrEmpty(data.OwnerSystemName) && data.OwnerSystemName.Length > MaxOwnerSystemNameLength)
            throw new ArgumentException($"OwnerSystemName не может быть длиннее {MaxOwnerSystemNameLength} символов", nameof(data));
        
        if (!string.IsNullOrEmpty(data.OwnerName) && data.OwnerName.Length > MaxOwnerNameLength)
            throw new ArgumentException($"OwnerName не может быть длиннее {MaxOwnerNameLength} символов", nameof(data));
        
        if (!string.IsNullOrEmpty(data.SupportManager) && data.SupportManager.Length > MaxSupportManagerLength)
            throw new ArgumentException($"SupportManager не может быть длиннее {MaxSupportManagerLength} символов", nameof(data));
        
        // Валидация TicketNumber (финальная оценка 7)
        if (!string.IsNullOrEmpty(data.TicketNumber))
        {
            if (data.TicketNumber.Length > MaxTicketNumberLength)
                throw new ArgumentException($"TicketNumber не может быть длиннее {MaxTicketNumberLength} символов", nameof(data));
            
            // Дополнительная валидация формата тикета (если требуется)
            // Можно добавить regex для проверки формата тикета вашей системы
        }
        
        // Валидация URL (проблема 21)
        if (!string.IsNullOrWhiteSpace(data.OwnerSystemUrl) && !IsValidUrl(data.OwnerSystemUrl))
            throw new ArgumentException($"Некорректный URL: {data.OwnerSystemUrl}", nameof(data));
        
        if (!string.IsNullOrWhiteSpace(data.TicketUrl) && !IsValidUrl(data.TicketUrl))
            throw new ArgumentException($"Некорректный URL тикета: {data.TicketUrl}", nameof(data));
        
        // Валидация username (проблема 33)
        if (!string.IsNullOrEmpty(username))
        {
            if (username.Length > MaxUsernameLength)
                throw new ArgumentException($"Username не может быть длиннее {MaxUsernameLength} символов", nameof(username));
            
            if (!IsValidKeycloakIdentifier(username))
                throw new ArgumentException("Некорректный формат username", nameof(username));
        }
        
        // Валидация PublicationStatus (проблема 35)
        if (!string.IsNullOrEmpty(data.PublicationStatus) && 
            !ValidPublicationStatuses.Contains(data.PublicationStatus))
        {
            throw new ArgumentException(
                $"PublicationStatus должен быть одним из: {string.Join(", ", ValidPublicationStatuses)}", 
                nameof(data));
        }
    }

    /// <summary>
    /// Проверяет валидность идентификатора Keycloak (проблема 25)
    /// </summary>
    private static bool IsValidKeycloakIdentifier(string identifier)
    {
        if (string.IsNullOrWhiteSpace(identifier))
            return false;
        
        return ValidIdentifierRegex.IsMatch(identifier) && 
               identifier.Length >= 1 && 
               identifier.Length <= 255;
    }

    /// <summary>
    /// Проверяет валидность URL (проблема 21)
    /// </summary>
    private static bool IsValidUrl(string? url)
    {
        if (string.IsNullOrWhiteSpace(url))
            return true; // Опциональное поле
        
        return Uri.TryCreate(url, UriKind.Absolute, out var uri) &&
               (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps);
    }

    /// <summary>
    /// Выполняет rollback операций при ошибке (проблемы 2, 19, 32)
    /// </summary>
    private async Task PerformRollbackAsync(
        bool ownershipGranted, 
        string? username, 
        string? clientInternalId, 
        string clientId, 
        string realm)
    {
        if (ownershipGranted && !string.IsNullOrEmpty(username))
        {
            try
            {
                await _ownershipService.RevokeOwnershipAsync(username, clientId, realm).ConfigureAwait(false);
                _logger.LogInformation("Откат ownership выполнен для клиента {ClientId}", clientId);
            }
            catch (Exception rollbackEx)
            {
                _logger.LogError(rollbackEx, "Ошибка при откате ownership для клиента {ClientId}", clientId);
            }
        }
        
        if (!string.IsNullOrWhiteSpace(clientInternalId))
        {
            try
            {
                await _keycloakAdminService.DeleteClientAsync(clientId, realm, clientInternalId).ConfigureAwait(false);
                _logger.LogInformation("Откат создания клиента выполнен: {ClientId} удален", clientId);
            }
            catch (Exception rollbackEx)
            {
                _logger.LogError(rollbackEx, "Ошибка при удалении клиента {ClientId} после ошибки создания", clientId);
            }
        }
    }
}
