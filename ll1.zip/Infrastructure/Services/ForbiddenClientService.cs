using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для работы с запрещенными клиентами (системные + кастомные)
/// </summary>
public class ForbiddenClientService : IForbiddenClientService
{
    private readonly IForbiddenClientRepository _forbiddenRepo;
    private readonly ILogger<ForbiddenClientService>? _logger;
    private readonly IMemoryCache? _cache;
    private readonly HashSet<string> _alwaysForbidden;
    private readonly TimeSpan _cacheExpiration;
    private readonly int _maxCachedItems;
    private readonly SemaphoreSlim _cacheSemaphore;
    
    private const string CacheKey = "ForbiddenClients_All";
    
    // Статистика кэша (thread-safe счетчики)
    private long _cacheHits = 0;
    private long _cacheMisses = 0;

    /// <summary>
    /// Инициализирует новый экземпляр <see cref="ForbiddenClientService"/>
    /// </summary>
    /// <param name="forbiddenRepo">Репозиторий для работы с запрещенными клиентами</param>
    /// <param name="forbiddenOptions">Настройки запрещенных клиентов</param>
    /// <param name="logger">Логгер для записи событий (опционально)</param>
    /// <param name="cache">Кэш для хранения данных (опционально)</param>
    /// <exception cref="ArgumentNullException">
    /// Выбрасывается если <paramref name="forbiddenRepo"/> равен <c>null</c>.
    /// </exception>
    public ForbiddenClientService(
        IForbiddenClientRepository forbiddenRepo,
        IOptions<ForbiddenSettings> forbiddenOptions,
        ILogger<ForbiddenClientService>? logger = null,
        IMemoryCache? cache = null)
    {
        _forbiddenRepo = forbiddenRepo ?? throw new ArgumentNullException(nameof(forbiddenRepo));
        _logger = logger;
        _cache = cache;
        _cacheSemaphore = new SemaphoreSlim(1, 1);
        
        // Безопасная обработка null для настроек
        var list = forbiddenOptions?.Value?.AlwaysForbiddenClientIds 
                   ?? new List<string>();
        
        // Фильтрация и нормализация: убираем null, пустые строки, пробелы
        _alwaysForbidden = new HashSet<string>(
            list
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .Select(s => s.Trim())
                .Where(s => s.Length > 0),
            StringComparer.OrdinalIgnoreCase);
        
        // Конфигурируемое время жизни кэша
        _cacheExpiration = forbiddenOptions?.Value?.CacheExpiration 
                          ?? TimeSpan.FromMinutes(5);
        
        // Конфигурируемый максимальный размер кэша
        _maxCachedItems = forbiddenOptions?.Value?.MaxCachedItems > 0
                         ? forbiddenOptions.Value.MaxCachedItems
                         : 10000;
    }

    /// <summary>
    /// Проверить, является ли клиент запрещенным (с учетом системных и кастомных запретов)
    /// </summary>
    /// <param name="clientId">Идентификатор клиента для проверки</param>
    /// <param name="realm">Название реалма, в котором находится клиент</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>
    /// <c>true</c> если клиент запрещен (системный или кастомный запрет), 
    /// <c>false</c> если клиент разрешен.
    /// В случае ошибки при обращении к БД возвращает <c>true</c> (fail-safe стратегия).
    /// </returns>
    /// <exception cref="ArgumentException">
    /// Выбрасывается если <paramref name="clientId"/> или <paramref name="realm"/> 
    /// равны <c>null</c> или пустой строке.
    /// </exception>
    /// <exception cref="OperationCanceledException">
    /// Выбрасывается если операция была отменена через <paramref name="cancellationToken"/>.
    /// </exception>
    /// <remarks>
    /// <para>
    /// Метод сначала проверяет системные запрещенные клиенты (быстрая проверка в памяти),
    /// затем обращается к БД для проверки кастомных запретов.
    /// </para>
    /// <para>
    /// Системные запрещенные клиенты применяются ко всем реалмам,
    /// кастомные запреты привязаны к конкретному реалму.
    /// </para>
    /// <para>
    /// В случае ошибки при обращении к БД метод возвращает <c>true</c> (fail-safe),
    /// что обеспечивает безопасность - лучше заблокировать клиента, чем разрешить доступ к запрещенному.
    /// </para>
    /// </remarks>
    public async Task<bool> IsForbiddenAsync(
        string clientId, 
        string realm, 
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(clientId, nameof(clientId));
        ArgumentException.ThrowIfNullOrWhiteSpace(realm, nameof(realm));
        
        cancellationToken.ThrowIfCancellationRequested();
        
        try
        {
            // Нормализуем clientId для консистентности
            var clientIdNormalized = clientId.Trim();
            
            // Быстрая проверка системных запрещенных клиентов
            if (_alwaysForbidden.Contains(clientIdNormalized))
            {
                return true;
            }

            // Проверка кастомных запретов (с привязкой к конкретному реалму)
            return await _forbiddenRepo.IsForbiddenAsync(clientId, realm, cancellationToken)
                .ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, 
                "Ошибка при проверке запрещенного клиента. ClientId: {ClientId}, Realm: {Realm}", 
                clientId, realm);
            // Fail-safe: в случае ошибки считаем клиент запрещенным для безопасности
            return true;
        }
    }

    /// <summary>
    /// Проверить, является ли клиент системным запрещенным клиентом
    /// </summary>
    /// <param name="clientId">Идентификатор клиента для проверки</param>
    /// <returns>
    /// <c>true</c> если клиент является системным запрещенным, <c>false</c> в противном случае.
    /// </returns>
    /// <remarks>
    /// Метод выполняет быструю проверку в памяти без обращения к БД.
    /// </remarks>
    public bool IsSystemForbidden(string clientId)
    {
        if (string.IsNullOrWhiteSpace(clientId))
        {
            return false;
        }
        
        return _alwaysForbidden.Contains(clientId.Trim());
    }

    /// <summary>
    /// Получить копию HashSet системных запрещенных клиентов
    /// </summary>
    /// <returns>
    /// Неизменяемая копия HashSet системных запрещенных клиентов.
    /// Возвращается копия коллекции для обеспечения инкапсуляции.
    /// </returns>
    /// <remarks>
    /// <para>
    /// Системные запрещенные клиенты настраиваются через конфигурацию приложения
    /// и применяются ко всем реалмам без исключений.
    /// </para>
    /// <para>
    /// Метод возвращает копию коллекции, чтобы предотвратить изменение внутреннего состояния сервиса.
    /// </para>
    /// </remarks>
    public IReadOnlySet<string> GetAlwaysForbiddenSet()
    {
        return _alwaysForbidden.ToHashSet(StringComparer.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Отфильтровать список клиентов, исключив запрещенные
    /// </summary>
    /// <param name="clients">Список клиентов для фильтрации</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>
    /// Отфильтрованный список клиентов без запрещенных.
    /// Элементы с <c>null</c> значениями или пустыми обязательными полями (<see cref="ClientSearchResult.ClientId"/>, 
    /// <see cref="ClientSearchResult.Realm"/>) также исключаются из результата.
    /// </returns>
    /// <exception cref="ArgumentNullException">
    /// Выбрасывается если <paramref name="clients"/> равен <c>null</c>.
    /// </exception>
    /// <exception cref="OperationCanceledException">
    /// Выбрасывается если операция была отменена через <paramref name="cancellationToken"/>.
    /// </exception>
    /// <remarks>
    /// <para>
    /// Метод фильтрует список клиентов, исключая:
    /// <list type="bullet">
    /// <item><description>Системные запрещенные клиенты (из конфигурации)</description></item>
    /// <item><description>Кастомные запрещенные клиенты (из БД, с кэшированием)</description></item>
    /// <item><description>Элементы с <c>null</c> значениями или пустыми обязательными полями</description></item>
    /// </list>
    /// </para>
    /// <para>
    /// Для оптимизации производительности кастомные запрещенные клиенты кэшируются.
    /// </para>
    /// <para>
    /// В случае ошибки при обращении к БД метод возвращает исходный список (fail-safe),
    /// чтобы не потерять данные при временных проблемах с БД.
    /// </para>
    /// </remarks>
    public async Task<List<ClientSearchResult>> FilterForbiddenClientsAsync(
        List<ClientSearchResult> clients,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(clients);
        
        if (clients.Count == 0)
        {
            return clients;
        }

        // Фильтруем null элементы и элементы с пустыми обязательными полями
        var validClients = clients
            .Where(c => c != null && 
                       !string.IsNullOrWhiteSpace(c.ClientId) && 
                       !string.IsNullOrWhiteSpace(c.Realm))
            .ToList();
            
        if (validClients.Count == 0)
        {
            return new List<ClientSearchResult>();
        }

        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            // Получаем кастомные запрещенные клиенты из кэша или БД
            var forbiddenClients = await GetForbiddenClientsCachedAsync(cancellationToken)
                .ConfigureAwait(false);
            
            // Оптимизация: если нет запрещенных клиентов, фильтруем только системные
            if (forbiddenClients.Count == 0)
            {
                return validClients
                    .Where(c => !_alwaysForbidden.Contains(c.ClientId.ToLowerInvariant()))
                    .ToList();
            }
            
            var forbiddenSet = new HashSet<(string ClientId, string Realm)>(
                forbiddenClients.Count,
                new TupleComparer(StringComparer.OrdinalIgnoreCase, StringComparer.OrdinalIgnoreCase));
                
            foreach (var fc in forbiddenClients)
            {
                forbiddenSet.Add((fc.ClientId.ToLowerInvariant(), fc.Realm.ToLowerInvariant()));
            }

            // Оптимизация: создаем нормализованные версии клиентов один раз
            var normalizedClients = validClients
                .Select(c => new
                {
                    Original = c,
                    Normalized = (ClientId: c.ClientId.ToLowerInvariant(), Realm: c.Realm.ToLowerInvariant())
                })
                .ToList();

            // Фильтруем: убираем системные И кастомные запрещенные
            return normalizedClients
                .Where(nc => 
                    !_alwaysForbidden.Contains(nc.Normalized.ClientId) &&
                    !forbiddenSet.Contains(nc.Normalized))
                .Select(nc => nc.Original)
                .ToList();
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, 
                "Ошибка при фильтрации запрещенных клиентов. Количество клиентов: {Count}", 
                validClients.Count);
            // В случае ошибки возвращаем исходный список (fail-safe)
            return validClients;
        }
    }

    /// <summary>
    /// Инвалидировать кэш запрещенных клиентов
    /// </summary>
    /// <remarks>
    /// Вызывайте этот метод после добавления или удаления запрещенных клиентов,
    /// чтобы обеспечить актуальность кэшированных данных.
    /// </remarks>
    public void InvalidateCache()
    {
        _cache?.Remove(CacheKey);
        _logger?.LogDebug("Кэш запрещенных клиентов инвалидирован");
    }

    /// <summary>
    /// Получить статистику использования кэша
    /// </summary>
    /// <returns>
    /// Кортеж с количеством попаданий в кэш (Hits), промахов (Misses) и коэффициентом попаданий (HitRatio).
    /// </returns>
    public (long Hits, long Misses, double HitRatio) GetCacheStats()
    {
        var hits = Interlocked.Read(ref _cacheHits);
        var misses = Interlocked.Read(ref _cacheMisses);
        var total = hits + misses;
        var hitRatio = total > 0 ? (double)hits / total : 0.0;
        return (hits, misses, hitRatio);
    }

    /// <summary>
    /// Получить список запрещенных клиентов из кэша или БД
    /// </summary>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>
    /// Список кортежей (ClientId, Realm) запрещенных клиентов.
    /// В случае ошибки возвращает пустой список.
    /// </returns>
    /// <remarks>
    /// <para>
    /// Метод использует кэш для уменьшения нагрузки на БД.
    /// Время жизни кэша настраивается через конфигурацию.
    /// </para>
    /// <para>
    /// При ошибке доступа к БД возвращается пустой список,
    /// что позволяет продолжить работу без кастомных запретов.
    /// </para>
    /// <para>
    /// Используется double-check locking pattern для предотвращения race condition.
    /// </para>
    /// </remarks>
    private async Task<List<(string ClientId, string Realm)>> GetForbiddenClientsCachedAsync(
        CancellationToken cancellationToken)
    {
        // Первая проверка кэша (без блокировки)
        if (_cache?.TryGetValue(CacheKey, out List<(string ClientId, string Realm)>? cached) == true && cached != null)
        {
            Interlocked.Increment(ref _cacheHits);
            _logger?.LogDebug("Кэш запрещенных клиентов: попадание (hit). Количество: {Count}", cached.Count);
            return cached;
        }

        // Блокировка для предотвращения race condition
        await _cacheSemaphore.WaitAsync(cancellationToken);
        try
        {
            // Double-check после получения блокировки
            if (_cache?.TryGetValue(CacheKey, out List<(string ClientId, string Realm)>? cachedAfterLock) == true && cachedAfterLock != null)
            {
                Interlocked.Increment(ref _cacheHits);
                _logger?.LogDebug("Кэш запрещенных клиентов: попадание (hit) после double-check. Количество: {Count}", cachedAfterLock.Count);
                return cachedAfterLock;
            }

            Interlocked.Increment(ref _cacheMisses);
            _logger?.LogDebug("Кэш запрещенных клиентов: промах (miss). Загрузка из БД...");
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            
            try
            {
                var forbiddenClients = await _forbiddenRepo.GetAllForbiddenClientIdsAsync(cancellationToken)
                    .ConfigureAwait(false);
                
                // Валидация данных из БД
                var validForbiddenClients = forbiddenClients
                    .Where(fc => !string.IsNullOrWhiteSpace(fc.ClientId) && 
                                !string.IsNullOrWhiteSpace(fc.Realm))
                    .ToList();
                
                stopwatch.Stop();
                _logger?.LogInformation(
                    "Загружено {Count} запрещенных клиентов из БД за {ElapsedMs}мс (после валидации: {ValidCount})", 
                    forbiddenClients.Count,
                    stopwatch.ElapsedMilliseconds,
                    validForbiddenClients.Count);
                
                // Проверка на максимальный размер кэша
                if (validForbiddenClients.Count > _maxCachedItems)
                {
                    _logger?.LogWarning(
                        "Количество запрещенных клиентов ({Count}) превышает максимальное для кэширования ({Max}). " +
                        "Кэширование отключено для этого запроса.",
                        validForbiddenClients.Count, 
                        _maxCachedItems);
                    return validForbiddenClients; // Возвращаем без кэширования
                }
                
                _cache?.Set(CacheKey, validForbiddenClients, _cacheExpiration);
                return validForbiddenClients;
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                _logger?.LogError(ex, 
                    "Ошибка при получении списка запрещенных клиентов из БД за {ElapsedMs}мс", 
                    stopwatch.ElapsedMilliseconds);
                // Возвращаем пустой список в случае ошибки
                return new List<(string ClientId, string Realm)>();
            }
        }
        finally
        {
            _cacheSemaphore.Release();
        }
    }

    /// <summary>
    /// Вспомогательный класс для сравнения кортежей (ClientId, Realm) с учетом регистра
    /// </summary>
    private sealed class TupleComparer : IEqualityComparer<(string ClientId, string Realm)>
    {
        private readonly StringComparer _clientIdComparer;
        private readonly StringComparer _realmComparer;

        public TupleComparer(StringComparer clientIdComparer, StringComparer realmComparer)
        {
            _clientIdComparer = clientIdComparer;
            _realmComparer = realmComparer;
        }

        public bool Equals((string ClientId, string Realm) x, (string ClientId, string Realm) y)
        {
            return _clientIdComparer.Equals(x.ClientId, y.ClientId) &&
                   _realmComparer.Equals(x.Realm, y.Realm);
        }

        public int GetHashCode((string ClientId, string Realm) obj)
        {
            return HashCode.Combine(
                _clientIdComparer.GetHashCode(obj.ClientId),
                _realmComparer.GetHashCode(obj.Realm));
        }
    }
}
