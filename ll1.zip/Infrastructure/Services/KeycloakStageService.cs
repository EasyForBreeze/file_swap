using System.Net;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для работы с Keycloak STAGE контуром.
/// Предоставляет высокоуровневые методы для управления клиентами, ролями, scopes и другими ресурсами Keycloak в STAGE окружении.
/// </summary>
/// <remarks>
/// <para>Сервис обеспечивает:</para>
/// <list type="bullet">
/// <item><description>Создание и управление клиентами Keycloak</description></item>
/// <item><description>Работу с realm и client ролями</description></item>
/// <item><description>Назначение ролей service account</description></item>
/// <item><description>Управление client scopes и protocol mappers</description></item>
/// <item><description>Проверку существования различных ресурсов</description></item>
/// </list>
/// <para>Все методы асинхронны и поддерживают cancellation tokens для отмены операций.</para>
/// </remarks>
public class KeycloakStageService : IKeycloakStageService
{
    private readonly IKeycloakStageHttpClient _httpClient;
    private readonly KeycloakStageSettings _settings;
    private readonly ILogger<KeycloakStageService> _logger;

    public KeycloakStageService(
        IKeycloakStageHttpClient httpClient,
        IOptions<KeycloakStageSettings> settings,
        ILogger<KeycloakStageService> logger)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _settings = settings?.Value ?? throw new ArgumentNullException(nameof(settings));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Получает список всех реалмов в STAGE окружении, исключая реалмы из списка исключений (обычно master).
    /// </summary>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>Список имен реалмов. Возвращает пустой список при ошибках (ошибки логируются).</returns>
    /// <remarks>
    /// Метод обрабатывает ошибки внутренне и возвращает пустой список при возникновении исключений.
    /// Реалмы из настроек ExcludedRealms будут автоматически исключены из результата.
    /// </remarks>
    public async Task<IEnumerable<string>> GetRealmsListAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            var endpoint = "admin/realms";
            var realms = await _httpClient.GetAsync<List<JsonElement>>(endpoint, cancellationToken).ConfigureAwait(false);
            
            if (realms == null)
                return Array.Empty<string>();

            return realms
                .Select(r => 
                {
                    if (r.TryGetProperty("realm", out var realmProp))
                    {
                        return realmProp.GetString();
                    }
                    return null;
                })
                .Where(r => !string.IsNullOrEmpty(r) && !_settings.ExcludedRealms.Contains(r!))
                .Cast<string>()
                .ToList();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка получения списка реалмов из STAGE");
            return Array.Empty<string>();
        }
    }

    /// <summary>
    /// Проверяет существование клиента с указанным ClientId в указанном realm STAGE окружения.
    /// </summary>
    /// <param name="clientId">Идентификатор клиента для проверки (clientId, не internal ID)</param>
    /// <param name="realm">Имя realm для проверки</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>true, если клиент существует, иначе false. Возвращает false при ошибках (ошибки логируются).</returns>
    /// <exception cref="ArgumentException">Если clientId или realm пусты или содержат только пробелы</exception>
    public async Task<bool> ClientExistsAsync(string clientId, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId не может быть пустым", nameof(clientId));
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        try
        {
            _logger.LogDebug("Проверка существования клиента {ClientId} в STAGE realm {Realm}", clientId, realm);
            
            var endpoint = $"admin/realms/{realm}/clients?clientId={WebUtility.UrlEncode(clientId)}";
            
            var clients = await _httpClient.GetAsync<List<JsonElement>>(endpoint, cancellationToken).ConfigureAwait(false);
            var exists = clients != null && clients.Any();
            
            _logger.LogDebug("Клиент {ClientId} в STAGE realm {Realm} существует: {Exists}", clientId, realm, exists);
            
            return exists;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка проверки существования клиента {ClientId} в STAGE realm {Realm}", clientId, realm);
            return false;
        }
    }

    /// <summary>
    /// Создает нового клиента в указанном realm STAGE окружения на основе предоставленных деталей.
    /// </summary>
    /// <param name="clientDetails">Детали клиента для создания (ClientId, настройки протокола, redirect URIs и т.д.)</param>
    /// <param name="realm">Имя realm, в котором будет создан клиент</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>Internal ID созданного клиента (UUID), извлекаемый из Location header ответа</returns>
    /// <exception cref="ArgumentNullException">Если clientDetails равен null</exception>
    /// <exception cref="ArgumentException">Если ClientId в clientDetails или realm пусты</exception>
    /// <exception cref="HttpRequestException">При ошибках HTTP запроса (ошибки создания клиента)</exception>
    /// <exception cref="InvalidOperationException">Если не удалось извлечь internal ID из Location header ответа</exception>
    /// <remarks>
    /// Метод автоматически извлекает internal ID клиента из Location header ответа Keycloak.
    /// Если извлечение не удалось, будет выброшено исключение с детальной информацией об ошибке.
    /// </remarks>
    public async Task<string> CreateClientAsync(ClientDetailsDto clientDetails, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        if (clientDetails == null)
            throw new ArgumentNullException(nameof(clientDetails));
        
        if (string.IsNullOrWhiteSpace(clientDetails.ClientId))
            throw new ArgumentException("ClientId не может быть пустым", nameof(clientDetails));
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        try
        {
            _logger.LogInformation("Создание клиента {ClientId} в STAGE realm {Realm}", clientDetails.ClientId, realm);
            
            var endpoint = $"admin/realms/{realm}/clients";
            var clientPayload = BuildClientCreationPayload(clientDetails);

            using var response = await _httpClient.PostAsync(endpoint, clientPayload, cancellationToken).ConfigureAwait(false);
            
            if (!response.IsSuccessStatusCode)
            {
                string error;
                try
                {
                    error = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Не удалось прочитать содержимое ошибки для клиента {ClientId}", clientDetails.ClientId);
                    error = $"Unable to read error content: {ex.Message}";
                }
                
                _logger.LogError("Ошибка создания клиента {ClientId} в STAGE realm {Realm}: {StatusCode} - {Error}", 
                    clientDetails.ClientId, realm, response.StatusCode, error);
                
                var httpEx = new HttpRequestException($"Ошибка создания клиента в STAGE: {response.StatusCode} - {error}");
                httpEx.Data["StatusCode"] = response.StatusCode;
                httpEx.Data["Realm"] = realm;
                httpEx.Data["ClientId"] = clientDetails.ClientId;
                throw httpEx;
            }

            // Получаем Location header для извлечения internal ID
            var location = response.Headers.Location?.ToString();
            if (string.IsNullOrEmpty(location))
            {
                throw new InvalidOperationException("Не удалось получить internal ID созданного клиента: Location header отсутствует");
            }

            string internalId;
            try
            {
                var locationUri = new Uri(location, UriKind.RelativeOrAbsolute);
                var segments = locationUri.Segments;
                internalId = segments.LastOrDefault()?.TrimEnd('/') ?? string.Empty;

                if (string.IsNullOrWhiteSpace(internalId) || internalId == "clients")
                {
                    // Попробуем извлечь ID из пути (UUID формат, поддерживает заглавные и строчные буквы)
                    var match = Regex.Match(location, @"/([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})(?:/|$)", RegexOptions.IgnoreCase);
                    if (match.Success)
                    {
                        internalId = match.Groups[1].Value;
                    }
                    else
                    {
                        throw new InvalidOperationException($"Не удалось извлечь internal ID из Location header: {location}");
                    }
                }
            }
            catch (UriFormatException ex)
            {
                _logger.LogError(ex, "Неверный формат Location header: {Location}", location);
                throw new InvalidOperationException($"Неверный формат Location header: {location}", ex);
            }
            _logger.LogInformation("Клиент {ClientId} успешно создан в STAGE realm {Realm} с ID {InternalId}", 
                clientDetails.ClientId, realm, internalId);

            return internalId;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка создания клиента {ClientId} в STAGE realm {Realm}", clientDetails.ClientId, realm);
            throw;
        }
    }

    private static object BuildClientCreationPayload(ClientDetailsDto clientDetails)
    {
        var redirectUris = SanitizeStringList(clientDetails.RedirectUris);
        var webOrigins = SanitizeStringList(clientDetails.WebOrigins);
        var attributes = BuildAttributesPayload(clientDetails.Attributes);

        var baseUrl = NormalizeUrl(clientDetails.BaseUrl);
        var rootUrl = NormalizeUrl(clientDetails.RootUrl);
        var adminUrl = NormalizeUrl(clientDetails.AdminUrl);

        return new
        {
            clientId = clientDetails.ClientId,
            name = clientDetails.Name,
            description = clientDetails.Description,
            enabled = clientDetails.Enabled,
            protocol = clientDetails.Protocol ?? "openid-connect",
            publicClient = clientDetails.ClientType == "public" || clientDetails.AccessType == "public",
            serviceAccountsEnabled = clientDetails.ServiceAccountsEnabled,
            directAccessGrantsEnabled = clientDetails.DirectAccessGrantsEnabled,
            standardFlowEnabled = clientDetails.StandardFlow,
            implicitFlowEnabled = false,
            authorizationServicesEnabled = clientDetails.AuthorizationServicesEnabled,
            frontchannelLogout = true,
            redirectUris,
            webOrigins,
            baseUrl,
            rootUrl,
            adminUrl,
            attributes
        };
    }

    private static List<string> SanitizeStringList(IEnumerable<string?>? source)
    {
        return source?
            .Select(value => value?.Trim())
            .Where(value => !string.IsNullOrEmpty(value))
            .Select(value => value!)
            .Distinct(StringComparer.Ordinal)
            .ToList()
            ?? new List<string>();
    }

    private static Dictionary<string, object> BuildAttributesPayload(Dictionary<string, List<string>>? attributes)
    {
        if (attributes == null || attributes.Count == 0)
        {
            return new Dictionary<string, object>();
        }

        var result = new Dictionary<string, object>(StringComparer.Ordinal);

        foreach (var kvp in attributes)
        {
            var key = kvp.Key?.Trim();
            if (string.IsNullOrEmpty(key))
            {
                continue;
            }

            var sourceValues = kvp.Value ?? new List<string>();
            var values = sourceValues
                .Select(value => value?.Trim())
                .Where(value => !string.IsNullOrEmpty(value))
                .Select(value => value!)
                .Distinct(StringComparer.Ordinal)
                .ToList();

            if (values.Count > 0)
            {
                result[key] = values.Count == 1
                    ? values[0]
                    : values;
            }
        }

        return result;
    }

    private static string? NormalizeUrl(string? url)
    {
        if (string.IsNullOrWhiteSpace(url))
        {
            return null;
        }

        var trimmed = url.Trim();
        
        // Базовая валидация URL (опционально, зависит от требований)
        // Keycloak может принимать как абсолютные, так и относительные URL
        // Поэтому проверяем только, что это не пустая строка после trim
        // Если требуется строгая валидация, можно добавить проверку через Uri.TryCreate
        
        return trimmed;
    }

    /// <summary>
    /// Получает Client Secret для указанного клиента по его internal ID.
    /// </summary>
    /// <param name="clientInternalId">Internal ID клиента (UUID)</param>
    /// <param name="realm">Имя realm, в котором находится клиент</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>Client Secret в виде строки, или null, если secret не найден или произошла ошибка</returns>
    /// <exception cref="ArgumentException">Если clientInternalId или realm пусты</exception>
    /// <remarks>
    /// Метод обрабатывает ошибки внутренне и возвращает null при возникновении проблем.
    /// Все ошибки логируются для последующего анализа.
    /// </remarks>
    public async Task<string?> GetClientSecretAsync(string clientInternalId, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        if (string.IsNullOrWhiteSpace(clientInternalId))
            throw new ArgumentException("ClientInternalId не может быть пустым", nameof(clientInternalId));
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        try
        {
            _logger.LogDebug("Получение client secret для клиента {ClientInternalId} в STAGE realm {Realm}", clientInternalId, realm);
            
            var endpoint = $"admin/realms/{realm}/clients/{clientInternalId}/client-secret";

            var secretData = await _httpClient.GetAsync<JsonElement>(endpoint, cancellationToken).ConfigureAwait(false);
            
            if (secretData.ValueKind == JsonValueKind.Undefined)
            {
                _logger.LogDebug("Client secret не найден для клиента {ClientInternalId} в STAGE realm {Realm}", clientInternalId, realm);
                return null;
            }

            if (!secretData.TryGetProperty("value", out var valueProp))
            {
                _logger.LogWarning("Client secret response does not contain 'value' property for client {ClientInternalId}", clientInternalId);
                return null;
            }

            var secret = valueProp.GetString();
            if (string.IsNullOrEmpty(secret))
            {
                _logger.LogWarning("Client secret 'value' is null or empty for client {ClientInternalId}", clientInternalId);
                return null;
            }
            
            _logger.LogDebug("Client secret успешно получен для клиента {ClientInternalId} в STAGE realm {Realm}", clientInternalId, realm);
            
            return secret;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка получения client secret для {ClientInternalId} в STAGE realm {Realm}", clientInternalId, realm);
            return null;
        }
    }

    /// <summary>
    /// Проверяет существование realm роли с указанным именем в указанном realm STAGE окружения.
    /// </summary>
    /// <param name="roleName">Имя realm роли для проверки</param>
    /// <param name="realm">Имя realm для проверки</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>true, если роль существует, иначе false. Возвращает false при ошибках (ошибки логируются).</returns>
    /// <exception cref="ArgumentException">Если roleName или realm пусты или содержат только пробелы</exception>
    /// <remarks>
    /// Метод использует HEAD запрос для проверки существования роли без загрузки её данных.
    /// HttpRequestException обрабатываются как "роль не найдена" и возвращают false.
    /// </remarks>
    public async Task<bool> RealmRoleExistsAsync(string roleName, string realm, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(roleName))
        {
            throw new ArgumentException("RoleName не может быть пустым", nameof(roleName));
        }
        
        if (string.IsNullOrWhiteSpace(realm))
        {
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        }
        
        try
        {
            var endpoint = $"admin/realms/{realm}/roles/{WebUtility.UrlEncode(roleName)}";
            var roleJson = await _httpClient.GetAsync<JsonElement>(endpoint, cancellationToken).ConfigureAwait(false);
            return roleJson.ValueKind != JsonValueKind.Undefined;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogDebug(ex, "Realm role {RoleName} не найдена в realm {Realm}", roleName, realm);
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка проверки существования realm role {RoleName} в realm {Realm}", roleName, realm);
            return false;
        }
    }

    /// <summary>
    /// Проверяет существование client роли с указанным именем для указанного клиента в STAGE окружении.
    /// </summary>
    /// <param name="clientId">ClientId клиента (не internal ID)</param>
    /// <param name="roleName">Имя client роли для проверки</param>
    /// <param name="realm">Имя realm, в котором находится клиент</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>true, если роль существует, иначе false. Возвращает false при ошибках (ошибки логируются).</returns>
    /// <exception cref="ArgumentException">Если clientId, roleName или realm пусты</exception>
    /// <remarks>
    /// Метод сначала находит клиента по ClientId, затем проверяет существование роли.
    /// Если клиент не найден или произошла ошибка, возвращается false.
    /// </remarks>
    public async Task<bool> ClientRoleExistsAsync(string clientId, string roleName, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId не может быть пустым", nameof(clientId));
        
        if (string.IsNullOrWhiteSpace(roleName))
            throw new ArgumentException("RoleName не может быть пустым", nameof(roleName));
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        try
        {
            _logger.LogDebug("Проверка существования client роли {RoleName} для клиента {ClientId} в STAGE realm {Realm}", 
                roleName, clientId, realm);
            
            // Сначала найти internal ID клиента
            var clientEndpoint = $"admin/realms/{realm}/clients?clientId={WebUtility.UrlEncode(clientId)}";
            var clients = await _httpClient.GetAsync<List<JsonElement>>(clientEndpoint, cancellationToken).ConfigureAwait(false);
            if (clients == null || !clients.Any())
            {
                _logger.LogDebug("Клиент {ClientId} не найден в STAGE realm {Realm}", clientId, realm);
                return false;
            }

            var matchingClient = clients.FirstOrDefault(c =>
                c.TryGetProperty("clientId", out var cid) &&
                string.Equals(cid.GetString(), clientId, StringComparison.OrdinalIgnoreCase));

            if (matchingClient.ValueKind == JsonValueKind.Undefined)
            {
                matchingClient = clients.First();
            }

            if (!matchingClient.TryGetProperty("id", out var idProp) || string.IsNullOrEmpty(idProp.GetString()))
            {
                _logger.LogWarning("Клиент {ClientId} найден, но не содержит 'id' property", clientId);
                return false;
            }

            var clientInternalId = idProp.GetString()!;
            var roleEndpoint = $"admin/realms/{realm}/clients/{clientInternalId}/roles/{WebUtility.UrlEncode(roleName)}";
            var roleJson = await _httpClient.GetAsync<JsonElement>(roleEndpoint, cancellationToken).ConfigureAwait(false);
            var exists = roleJson.ValueKind != JsonValueKind.Undefined;
            
            _logger.LogDebug("Client роль {RoleName} для клиента {ClientId} в STAGE realm {Realm} существует: {Exists}", 
                roleName, clientId, realm, exists);
            
            return exists;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка проверки существования client роли {RoleName} для клиента {ClientId} в STAGE realm {Realm}", 
                roleName, clientId, realm);
            return false;
        }
    }

    /// <summary>
    /// Создает одну или несколько client ролей для указанного клиента в STAGE окружении.
    /// </summary>
    /// <param name="clientInternalId">Internal ID клиента (UUID), для которого создаются роли</param>
    /// <param name="roleNames">Список имен ролей для создания</param>
    /// <param name="realm">Имя realm, в котором находится клиент</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <exception cref="ArgumentException">Если clientInternalId или realm пусты</exception>
    /// <exception cref="ArgumentNullException">Если roleNames равен null</exception>
    /// <remarks>
    /// <para>Метод обрабатывает роли последовательно и логирует результаты для каждой роли:</para>
    /// <list type="bullet">
    /// <item><description>Успешно созданные роли</description></item>
    /// <item><description>Роли, которые уже существуют (конфликт)</description></item>
    /// <item><description>Роли, которые не удалось создать (ошибки)</description></item>
    /// </list>
    /// <para>Пустой список roleNames не приводит к ошибке - метод просто завершается без действий.</para>
    /// <para>В конце операции выводится сводная статистика по созданию ролей.</para>
    /// </remarks>
    public async Task CreateClientRolesAsync(string clientInternalId, List<string> roleNames, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        if (string.IsNullOrWhiteSpace(clientInternalId))
            throw new ArgumentException("ClientInternalId не может быть пустым", nameof(clientInternalId));
        
        if (roleNames == null)
            throw new ArgumentNullException(nameof(roleNames));
        
        if (roleNames.Count == 0)
        {
            _logger.LogWarning("Пустой список roleNames для клиента {ClientId}", clientInternalId);
            return;
        }
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        try
        {
            _logger.LogInformation("Создание {Count} client ролей для клиента {ClientInternalId} в STAGE realm {Realm}", 
                roleNames.Count, clientInternalId, realm);
            
            var endpoint = $"admin/realms/{realm}/clients/{clientInternalId}/roles";

            int successCount = 0;
            int conflictCount = 0;
            int failedCount = 0;

            foreach (var roleName in roleNames)
            {
                var roleData = new
                {
                    name = roleName,
                    description = $"Роль {roleName}",
                    clientRole = true
                };

                using var response = await _httpClient.PostAsync(endpoint, roleData, cancellationToken).ConfigureAwait(false);
                
                if (response.IsSuccessStatusCode)
                {
                    successCount++;
                    _logger.LogDebug("Роль {RoleName} создана для клиента {ClientId} в STAGE", roleName, clientInternalId);
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.Conflict)
                {
                    conflictCount++;
                    _logger.LogDebug("Роль {RoleName} уже существует для клиента {ClientId} в STAGE", roleName, clientInternalId);
                }
                else
                {
                    failedCount++;
                    _logger.LogWarning("Не удалось создать роль {RoleName} для клиента {ClientId}: {StatusCode}", 
                        roleName, clientInternalId, response.StatusCode);
                }
            }

            _logger.LogInformation("Создание ролей завершено для клиента {ClientId}: создано {Success}, конфликтов {Conflict}, ошибок {Failed}", 
                clientInternalId, successCount, conflictCount, failedCount);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка создания ролей для клиента {ClientId} в STAGE", clientInternalId);
            throw;
        }
    }

    /// <summary>
    /// Назначает указанные realm роли service account пользователю указанного клиента в STAGE окружении.
    /// </summary>
    /// <param name="clientInternalId">Internal ID клиента (UUID), service account которого получает роли</param>
    /// <param name="roleNames">Список имен realm ролей для назначения</param>
    /// <param name="realm">Имя realm, в котором находится клиент</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <exception cref="ArgumentException">Если clientInternalId или realm пусты</exception>
    /// <exception cref="ArgumentNullException">Если roleNames равен null</exception>
    /// <exception cref="InvalidOperationException">Если service account не найден или не найдено ни одной роли для назначения</exception>
    /// <exception cref="HttpRequestException">При ошибках HTTP запроса при назначении ролей</exception>
    /// <remarks>
    /// <para>Метод выполняет следующие шаги:</para>
    /// <list type="number">
    /// <item><description>Получает service account пользователя для указанного клиента</description></item>
    /// <item><description>Параллельно получает информацию о всех запрошенных realm ролях</description></item>
    /// <item><description>Фильтрует только найденные роли (роли, которых нет, логируются как предупреждения)</description></item>
    /// <item><description>Назначает все найденные роли service account пользователю</description></item>
    /// </list>
    /// <para>Если ни одна из запрошенных ролей не найдена, выбрасывается InvalidOperationException.</para>
    /// </remarks>
    public async Task AssignRealmRolesToServiceAccountAsync(string clientInternalId, List<string> roleNames, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        if (string.IsNullOrWhiteSpace(clientInternalId))
            throw new ArgumentException("ClientInternalId не может быть пустым", nameof(clientInternalId));
        
        if (roleNames == null)
            throw new ArgumentNullException(nameof(roleNames));
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        try
        {
            _logger.LogInformation("Назначение {Count} realm ролей service account клиента {ClientInternalId} в STAGE realm {Realm}", 
                roleNames.Count, clientInternalId, realm);
            
            // Получить ID service account пользователя
            var saUserEndpoint = $"admin/realms/{realm}/clients/{clientInternalId}/service-account-user";

            var saUser = await _httpClient.GetAsync<JsonElement>(saUserEndpoint, cancellationToken).ConfigureAwait(false);
            if (saUser.ValueKind == JsonValueKind.Undefined)
            {
                throw new InvalidOperationException("Service account user не найден");
            }

            if (!saUser.TryGetProperty("id", out var saUserIdProp) || string.IsNullOrEmpty(saUserIdProp.GetString()))
            {
                throw new InvalidOperationException("Service account user не содержит 'id' property");
            }

            var saUserId = saUserIdProp.GetString()!;

            // Получить realm roles для назначения (параллельно для оптимизации)
            var roleTasks = roleNames.Select(async roleName =>
            {
                try
                {
                    var roleEndpoint = $"admin/realms/{realm}/roles/{WebUtility.UrlEncode(roleName)}";
                    var role = await _httpClient.GetAsync<JsonElement>(roleEndpoint, cancellationToken).ConfigureAwait(false);
                    
                    if (role.ValueKind != JsonValueKind.Undefined)
                    {
                        if (!role.TryGetProperty("id", out var idProp) || !role.TryGetProperty("name", out var nameProp))
                        {
                            _logger.LogWarning("Realm role {RoleName} не содержит обязательных полей 'id' или 'name'", roleName);
                            return null;
                        }
                        
                        var idValue = idProp.GetString();
                        var nameValue = nameProp.GetString();
                        
                        if (string.IsNullOrEmpty(idValue) || string.IsNullOrEmpty(nameValue))
                        {
                            _logger.LogWarning("Realm role {RoleName} содержит null или пустые значения для 'id' или 'name'", roleName);
                            return null;
                        }
                        
                        return new
                        {
                            id = idValue,
                            name = nameValue
                        } as object;
                    }
                    
                    _logger.LogDebug("Realm role {RoleName} не найдена в realm {Realm}", roleName, realm);
                    return null;
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Ошибка получения realm role {RoleName} из realm {Realm}", roleName, realm);
                    return null;
                }
            });
            
            var roleResults = await Task.WhenAll(roleTasks);
            var roles = roleResults.Where(r => r != null).ToList();

            if (!roles.Any())
            {
                _logger.LogWarning("Не найдено ни одной realm роли для назначения service account {ClientId}. Запрошенные роли: {RoleNames}", 
                    clientInternalId, string.Join(", ", roleNames));
                throw new InvalidOperationException($"Не найдено ни одной realm роли из запрошенных: {string.Join(", ", roleNames)}");
            }

            var assignEndpoint = $"admin/realms/{realm}/users/{saUserId}/role-mappings/realm";
            using var response = await _httpClient.PostAsync(assignEndpoint, roles, cancellationToken).ConfigureAwait(false);

            if (!response.IsSuccessStatusCode)
            {
                string error;
                try
                {
                    error = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Не удалось прочитать содержимое ошибки при назначении realm roles для {ClientId}", clientInternalId);
                    error = $"Unable to read error content: {ex.Message}";
                }
                
                _logger.LogError("Ошибка назначения realm roles для service account {ClientId}: {StatusCode} - {Error}", 
                    clientInternalId, response.StatusCode, error);
                throw new HttpRequestException($"Не удалось назначить realm roles: {response.StatusCode} - {error}");
            }

            _logger.LogInformation("Назначено {Count} realm roles для service account клиента {ClientId} в STAGE", 
                roles.Count, clientInternalId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка назначения realm roles для service account {ClientId} в STAGE", clientInternalId);
            throw;
        }
    }

    /// <summary>
    /// Назначает указанные client роли от другого клиента (targetClient) service account пользователю указанного клиента в STAGE окружении.
    /// </summary>
    /// <param name="clientInternalId">Internal ID клиента (UUID), service account которого получает роли</param>
    /// <param name="targetClientId">ClientId клиента (не internal ID), от которого берутся роли</param>
    /// <param name="roleNames">Список имен client ролей для назначения</param>
    /// <param name="realm">Имя realm, в котором находятся клиенты</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <exception cref="ArgumentException">Если clientInternalId, targetClientId или realm пусты</exception>
    /// <exception cref="ArgumentNullException">Если roleNames равен null</exception>
    /// <exception cref="InvalidOperationException">Если service account не найден</exception>
    /// <exception cref="HttpRequestException">При ошибках HTTP запроса при назначении ролей</exception>
    /// <remarks>
    /// <para>Метод выполняет следующие шаги:</para>
    /// <list type="number">
    /// <item><description>Получает service account пользователя для указанного клиента</description></item>
    /// <item><description>Находит target клиент по ClientId и получает его internal ID</description></item>
    /// <item><description>Последовательно получает информацию о каждой запрошенной client роли</description></item>
    /// <item><description>Фильтрует только найденные роли (роли, которых нет, логируются как предупреждения)</description></item>
    /// <item><description>Назначает все найденные роли service account пользователю</description></item>
    /// </list>
    /// <para>Если target клиент не найден или ни одна из ролей не найдена, метод завершается без ошибок (логируется предупреждение).</para>
    /// </remarks>
    public async Task AssignClientRolesToServiceAccountAsync(string clientInternalId, string targetClientId, List<string> roleNames, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        if (string.IsNullOrWhiteSpace(clientInternalId))
            throw new ArgumentException("ClientInternalId не может быть пустым", nameof(clientInternalId));
        
        if (string.IsNullOrWhiteSpace(targetClientId))
            throw new ArgumentException("TargetClientId не может быть пустым", nameof(targetClientId));
        
        if (roleNames == null)
            throw new ArgumentNullException(nameof(roleNames));
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        try
        {
            _logger.LogInformation("Назначение {Count} client ролей service account клиента {ClientInternalId} для клиента {TargetClientId} в STAGE realm {Realm}", 
                roleNames.Count, clientInternalId, targetClientId, realm);
            
            // Получить ID service account пользователя
            var saUserEndpoint = $"admin/realms/{realm}/clients/{clientInternalId}/service-account-user";

            var saUser = await _httpClient.GetAsync<JsonElement>(saUserEndpoint, cancellationToken).ConfigureAwait(false);
            if (saUser.ValueKind == JsonValueKind.Undefined)
            {
                throw new InvalidOperationException("Service account user не найден");
            }

            if (!saUser.TryGetProperty("id", out var saUserIdProp) || string.IsNullOrEmpty(saUserIdProp.GetString()))
            {
                throw new InvalidOperationException("Service account user не содержит 'id' property");
            }

            var saUserId = saUserIdProp.GetString()!;

            // Найти target client internal ID
            var clientEndpoint = $"admin/realms/{realm}/clients?clientId={WebUtility.UrlEncode(targetClientId)}";
            
            var clients = await _httpClient.GetAsync<List<JsonElement>>(clientEndpoint, cancellationToken).ConfigureAwait(false);
            if (clients == null || !clients.Any())
            {
                _logger.LogWarning("Target client {TargetClientId} не найден в STAGE", targetClientId);
                return;
            }

            var matchingClient = clients.FirstOrDefault(c =>
                c.TryGetProperty("clientId", out var cid) &&
                string.Equals(cid.GetString(), targetClientId, StringComparison.OrdinalIgnoreCase));

            if (matchingClient.ValueKind == JsonValueKind.Undefined)
            {
                matchingClient = clients.First();
            }

            if (!matchingClient.TryGetProperty("id", out var targetIdProp) || string.IsNullOrEmpty(targetIdProp.GetString()))
            {
                _logger.LogWarning("Target client {TargetClientId} найден, но не содержит 'id' property", targetClientId);
                return;
            }

            var targetClientInternalId = targetIdProp.GetString()!;

            // Получить client roles для назначения
            var roles = new List<object>();
            foreach (var roleName in roleNames)
            {
                var roleEndpoint = $"admin/realms/{realm}/clients/{targetClientInternalId}/roles/{WebUtility.UrlEncode(roleName)}";

                var role = await _httpClient.GetAsync<JsonElement>(roleEndpoint, cancellationToken).ConfigureAwait(false);
                if (role.ValueKind != JsonValueKind.Undefined)
                {
                    if (!role.TryGetProperty("id", out var roleIdProp) || !role.TryGetProperty("name", out var roleNameProp))
                    {
                        _logger.LogWarning("Client role {RoleName} не содержит обязательных полей 'id' или 'name'", roleName);
                        continue;
                    }
                    
                    var roleId = roleIdProp.GetString();
                    var roleNameValue = roleNameProp.GetString();
                    
                    if (string.IsNullOrEmpty(roleId) || string.IsNullOrEmpty(roleNameValue))
                    {
                        _logger.LogWarning("Client role {RoleName} содержит пустые значения для 'id' или 'name'", roleName);
                        continue;
                    }
                    
                    roles.Add(new
                    {
                        id = roleId,
                        name = roleNameValue,
                        clientRole = true,
                        containerId = targetClientInternalId
                    });
                }
            }

            if (!roles.Any())
            {
                _logger.LogWarning("Не найдено ни одной client роли для назначения service account {ClientId}", clientInternalId);
                return;
            }

            var assignEndpoint = $"admin/realms/{realm}/users/{saUserId}/role-mappings/clients/{targetClientInternalId}";
            using var response = await _httpClient.PostAsync(assignEndpoint, roles, cancellationToken).ConfigureAwait(false);

            if (response.IsSuccessStatusCode)
            {
                _logger.LogInformation("Назначено {Count} client roles от {TargetClient} для service account {ClientId} в STAGE", 
                    roles.Count, targetClientId, clientInternalId);
            }
            else
            {
                string error;
                try
                {
                    error = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Не удалось прочитать содержимое ошибки при назначении client roles для {ClientId}", clientInternalId);
                    error = $"Unable to read error content: {ex.Message}";
                }
                
                _logger.LogError("Ошибка назначения client roles для service account {ClientId}: {StatusCode} - {Error}", 
                    clientInternalId, response.StatusCode, error);
                throw new HttpRequestException($"Не удалось назначить client roles: {response.StatusCode} - {error}");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка назначения client roles для service account {ClientId} в STAGE", clientInternalId);
            throw;
        }
    }

    /// <summary>
    /// Проверяет существование client scope с указанным именем в указанном realm STAGE окружения.
    /// </summary>
    /// <param name="scopeName">Имя client scope для проверки</param>
    /// <param name="realm">Имя realm для проверки</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>true, если scope существует, иначе false. Возвращает false при ошибках (ошибки логируются).</returns>
    /// <exception cref="ArgumentException">Если scopeName или realm пусты или содержат только пробелы</exception>
    /// <remarks>
    /// Метод получает список всех client scopes в realm и проверяет наличие scope с указанным именем (без учета регистра).
    /// HttpRequestException обрабатываются как "scope не найден" и возвращают false.
    /// </remarks>
    public async Task<bool> ClientScopeExistsAsync(string scopeName, string realm, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(scopeName))
        {
            throw new ArgumentException("ScopeName не может быть пустым", nameof(scopeName));
        }
        
        if (string.IsNullOrWhiteSpace(realm))
        {
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        }
        
        try
        {
            var endpoint = $"admin/realms/{realm}/client-scopes";

            var scopes = await _httpClient.GetAsync<List<JsonElement>>(endpoint, cancellationToken).ConfigureAwait(false);
            
            if (scopes == null)
                return false;

            return scopes.Any(s => 
                s.TryGetProperty("name", out var nameProp) && 
                string.Equals(nameProp.GetString(), scopeName, StringComparison.OrdinalIgnoreCase));
        }
        catch (HttpRequestException ex)
        {
            _logger.LogDebug(ex, "Client scope {ScopeName} не найден в realm {Realm}", scopeName, realm);
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка проверки существования client scope {ScopeName} в realm {Realm}", scopeName, realm);
            return false;
        }
    }

    /// <summary>
    /// Проверяет существование authentication flow с указанным алиасом в указанном realm STAGE окружения.
    /// </summary>
    /// <param name="flowAlias">Алиас authentication flow для проверки</param>
    /// <param name="realm">Имя realm для проверки</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>true, если flow существует, иначе false. Возвращает false при ошибках (ошибки логируются).</returns>
    /// <exception cref="ArgumentException">Если flowAlias или realm пусты или содержат только пробелы</exception>
    /// <remarks>
    /// Метод получает список всех authentication flows в realm и проверяет наличие flow с указанным алиасом (без учета регистра).
    /// HttpRequestException обрабатываются как "flow не найден" и возвращают false.
    /// </remarks>
    public async Task<bool> AuthenticationFlowExistsAsync(string flowAlias, string realm, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(flowAlias))
        {
            throw new ArgumentException("FlowAlias не может быть пустым", nameof(flowAlias));
        }
        
        if (string.IsNullOrWhiteSpace(realm))
        {
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        }
        
        try
        {
            var endpoint = $"admin/realms/{realm}/authentication/flows";

            var flows = await _httpClient.GetAsync<List<JsonElement>>(endpoint, cancellationToken).ConfigureAwait(false);
            
            if (flows == null)
                return false;

            return flows.Any(f => 
                f.TryGetProperty("alias", out var aliasProp) && 
                string.Equals(aliasProp.GetString(), flowAlias, StringComparison.OrdinalIgnoreCase));
        }
        catch (HttpRequestException ex)
        {
            _logger.LogDebug(ex, "Authentication flow {FlowAlias} не найден в realm {Realm}", flowAlias, realm);
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка проверки существования authentication flow {FlowAlias} в realm {Realm}", flowAlias, realm);
            return false;
        }
    }

    /// <summary>
    /// Копирует protocol mappers в указанный клиент в STAGE окружении.
    /// </summary>
    /// <param name="clientInternalId">Internal ID клиента (UUID), в который копируются mappers</param>
    /// <param name="mappers">Список protocol mappers для копирования (JsonElement объектов)</param>
    /// <param name="realm">Имя realm, в котором находится клиент</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <exception cref="ArgumentException">Если clientInternalId или realm пусты</exception>
    /// <exception cref="ArgumentNullException">Если mappers равен null</exception>
    /// <remarks>
    /// <para>Метод обрабатывает mappers последовательно:</para>
    /// <list type="bullet">
    /// <item><description>Пропускает mappers с неверным типом (не объекты)</description></item>
    /// <item><description>Успешно созданные mappers логируются</description></item>
    /// <item><description>Конфликты (уже существующие mappers) игнорируются</description></item>
    /// <item><description>Другие ошибки логируются как предупреждения</description></item>
    /// </list>
    /// <para>Метод не выбрасывает исключения при ошибках - все ошибки логируются, но выполнение продолжается.</para>
    /// <para>Это связано с тем, что protocol mappers не являются критичными для работы клиента.</para>
    /// </remarks>
    public async Task CopyProtocolMappersAsync(string clientInternalId, List<JsonElement> mappers, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        if (string.IsNullOrWhiteSpace(clientInternalId))
        {
            throw new ArgumentException("ClientInternalId не может быть пустым", nameof(clientInternalId));
        }
        
        if (mappers == null)
        {
            throw new ArgumentNullException(nameof(mappers));
        }
        
        if (string.IsNullOrWhiteSpace(realm))
        {
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        }
        
        try
        {
            var endpoint = $"admin/realms/{realm}/clients/{clientInternalId}/protocol-mappers/models";

            foreach (var mapper in mappers)
            {
                if (mapper.ValueKind != JsonValueKind.Object)
                {
                    _logger.LogWarning("Protocol mapper имеет неверный тип: {ValueKind}", mapper.ValueKind);
                    continue;
                }
                
                using var response = await _httpClient.PostAsync(endpoint, mapper, cancellationToken).ConfigureAwait(false);
                
                if (response.IsSuccessStatusCode)
                {
                    _logger.LogDebug("Protocol mapper скопирован для клиента {ClientId} в STAGE", clientInternalId);
                }
                else if (response.StatusCode != System.Net.HttpStatusCode.Conflict)
                {
                    var statusCode = (int)response.StatusCode;
                    _logger.LogWarning("Не удалось скопировать protocol mapper для {ClientId}: {StatusCode}", 
                        clientInternalId, statusCode);
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка копирования protocol mappers для клиента {ClientId} в STAGE", clientInternalId);
            // Не бросаем исключение - mappers не критичны
        }
    }

    /// <summary>
    /// Назначает указанные client scopes указанному клиенту в STAGE окружении как default или optional scopes.
    /// </summary>
    /// <param name="clientInternalId">Internal ID клиента (UUID), которому назначаются scopes</param>
    /// <param name="scopeNames">Список имен client scopes для назначения</param>
    /// <param name="realm">Имя realm, в котором находится клиент</param>
    /// <param name="isDefault">Если true, scopes назначаются как default, иначе как optional</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <exception cref="ArgumentException">Если clientInternalId или realm пусты</exception>
    /// <exception cref="ArgumentNullException">Если scopeNames равен null</exception>
    /// <remarks>
    /// <para>Метод выполняет следующие шаги:</para>
    /// <list type="number">
    /// <item><description>Получает список всех доступных client scopes в realm</description></item>
    /// <item><description>Для каждого запрошенного scope находит соответствующий scope по имени (без учета регистра)</description></item>
    /// <item><description>Назначает найденные scopes клиенту как default или optional (в зависимости от параметра isDefault)</description></item>
    /// </list>
    /// <para>Scopes, которые не найдены, логируются как предупреждения и пропускаются.</para>
    /// <para>Пустой список scopeNames не приводит к ошибке - метод просто завершается без действий.</para>
    /// <para>Метод не выбрасывает исключения при ошибках - все ошибки логируются, но выполнение продолжается.</para>
    /// <para>Это связано с тем, что client scopes не являются критичными для работы клиента.</para>
    /// </remarks>
    public async Task AssignClientScopesAsync(string clientInternalId, List<string> scopeNames, string realm, bool isDefault, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        if (string.IsNullOrWhiteSpace(clientInternalId))
        {
            throw new ArgumentException("ClientInternalId не может быть пустым", nameof(clientInternalId));
        }
        
        if (scopeNames == null)
        {
            throw new ArgumentNullException(nameof(scopeNames));
        }
        
        if (scopeNames.Count == 0)
        {
            _logger.LogDebug("Пустой список scopeNames для клиента {ClientId}", clientInternalId);
            return;
        }
        
        if (string.IsNullOrWhiteSpace(realm))
        {
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        }
        
        try
        {
            // Получить все доступные scopes
            var scopesEndpoint = $"admin/realms/{realm}/client-scopes";

            var allScopes = await _httpClient.GetAsync<List<JsonElement>>(scopesEndpoint, cancellationToken).ConfigureAwait(false);
            
            if (allScopes == null)
                return;

            foreach (var scopeName in scopeNames)
            {
                var scope = allScopes.FirstOrDefault(s => 
                    s.TryGetProperty("name", out var nameProp) && 
                    string.Equals(nameProp.GetString(), scopeName, StringComparison.OrdinalIgnoreCase));
                    
                if (scope.ValueKind == JsonValueKind.Undefined)
                {
                    _logger.LogWarning("Client scope {ScopeName} не найден в STAGE", scopeName);
                    continue;
                }

                if (!scope.TryGetProperty("id", out var idProp) || string.IsNullOrEmpty(idProp.GetString()))
                {
                    _logger.LogWarning("Client scope {ScopeName} найден, но не содержит 'id' property", scopeName);
                    continue;
                }

                var scopeId = idProp.GetString()!;
                var assignType = isDefault ? "default-client-scopes" : "optional-client-scopes";
                
                var assignEndpoint = $"admin/realms/{realm}/clients/{clientInternalId}/{assignType}/{scopeId}";

                using var response = await _httpClient.PutAsync(assignEndpoint, new { }, cancellationToken).ConfigureAwait(false);
                
                if (response.IsSuccessStatusCode)
                {
                    _logger.LogDebug("Client scope {ScopeName} назначен клиенту {ClientId} в STAGE ({Type})", 
                        scopeName, clientInternalId, isDefault ? "default" : "optional");
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка назначения client scopes для клиента {ClientId} в STAGE", clientInternalId);
            // Не бросаем исключение - scopes не критичны
        }
    }
}

