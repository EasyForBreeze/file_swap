using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Фоновый сервис для автоматической очистки старых аудит логов
/// </summary>
public class AuditLogCleanupService : BackgroundService
{
    private readonly ILogger<AuditLogCleanupService> _logger;
    private readonly DataPathsSettings _dataPathsSettings;
    private readonly AuditLogCleanupSettings _settings;
    private readonly string _connectionString;
    private readonly string _lockFilePath;
    private FileStream? _lockFileStream;
    private static readonly SemaphoreSlim _schemaInitSemaphore = new SemaphoreSlim(1, 1);

    // Схема таблицы вынесена в константу для устранения дублирования
    private const string CreateTableSql = @"
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            username TEXT NOT NULL,
            client_id TEXT,
            realm TEXT,
            target_username TEXT,
            description TEXT NOT NULL,
            change_details TEXT,
            created_at TEXT NOT NULL
        );
    ";

    // Индексы создаются отдельно и только при первой инициализации
    private const string CreateIndexesSql = @"
        CREATE INDEX IF NOT EXISTS idx_audit_event_type ON audit_logs(event_type);
        CREATE INDEX IF NOT EXISTS idx_audit_username ON audit_logs(username);
        CREATE INDEX IF NOT EXISTS idx_audit_client_id ON audit_logs(client_id);
        CREATE INDEX IF NOT EXISTS idx_audit_realm ON audit_logs(realm);
        CREATE INDEX IF NOT EXISTS idx_audit_created_at ON audit_logs(created_at DESC);
    ";

    public AuditLogCleanupService(
        ILogger<AuditLogCleanupService> logger,
        DataPathsSettings dataPathsSettings,
        IOptions<AuditLogCleanupSettings> settings)
    {
        _logger = logger;
        _dataPathsSettings = dataPathsSettings;
        _settings = settings.Value;

        // Валидация параметров
        if (_settings.RetentionDays <= 0)
            throw new ArgumentException("RetentionDays must be greater than 0", nameof(settings));

        if (_settings.CleanupInterval <= TimeSpan.Zero)
            throw new ArgumentException("CleanupInterval must be greater than TimeSpan.Zero", nameof(settings));

        if (_settings.BatchSize <= 0)
            throw new ArgumentException("BatchSize must be greater than 0", nameof(settings));

        if (_settings.VacuumThresholdPercent < 0 || _settings.VacuumThresholdPercent > 100)
            throw new ArgumentException("VacuumThresholdPercent must be between 0 and 100", nameof(settings));

        if (_settings.ProgressLogIntervalSeconds < 0)
            throw new ArgumentException("ProgressLogIntervalSeconds must be greater than or equal to 0", nameof(settings));

        // Проверка и создание директории для БД
        EnsureDatabaseDirectoryExists();

        var dbPath = _dataPathsSettings.GetAuditDbPath();
        _connectionString = $"Data Source={dbPath};Mode=ReadWriteCreate;Cache=Shared;Pooling=True";

        // Путь к файлу блокировки
        var directory = Path.GetDirectoryName(dbPath) ?? ".";
        _lockFilePath = Path.Combine(directory, "audit_cleanup.lock");
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // Проверка, включен ли сервис
        if (!_settings.Enabled)
        {
            _logger.LogInformation("AuditLogCleanupService отключен через конфигурацию");
            return;
        }

        _logger.LogInformation(
            "🔄 AuditLogCleanupService запущен. Период проверки: {Interval}, Срок хранения: {Retention} дней",
            _settings.CleanupInterval, _settings.RetentionDays);

        // Используем настройку InitialDelay вместо хардкода
        var initialDelay = _settings.InitialDelay ?? TimeSpan.FromMinutes(1);
        await Task.Delay(initialDelay, stoppingToken);

        // Гарантируем, что БД и таблица существуют (может не быть, если ещё не писали аудит)
        try
        {
            await EnsureDatabaseExistsAsync(stoppingToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось инициализировать БД аудита перед очисткой. Продолжаем с последующими попытками.");
        }

        while (!stoppingToken.IsCancellationRequested)
        {
            var lockAcquired = false;
            try
            {
                // Пытаемся получить блокировку перед очисткой
                if (_settings.EnableFileLock)
                {
                    lockAcquired = await TryAcquireLockAsync(stoppingToken);
                    if (!lockAcquired)
                    {
                        _logger.LogDebug("Не удалось получить блокировку для очистки. Другой процесс уже выполняет очистку. Пропускаем итерацию.");
                        await Task.Delay(_settings.CleanupInterval, stoppingToken);
                        continue;
                    }
                }

                await CleanupOldLogsAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Ошибка при очистке старых аудит логов");
            }
            finally
            {
                // Освобождаем блокировку только если она была получена
                if (lockAcquired || !_settings.EnableFileLock)
                {
                    ReleaseLock();
                }
            }

            // Ждём до следующей проверки
            try
            {
                await Task.Delay(_settings.CleanupInterval, stoppingToken);
            }
            catch (TaskCanceledException)
            {
                // Приложение останавливается, выходим из цикла
                break;
            }
        }

        ReleaseLock();
        _logger.LogInformation("⏹️ AuditLogCleanupService остановлен");
    }

    /// <summary>
    /// Удаляет аудит логи старше указанного количества дней
    /// </summary>
    private async Task<CleanupMetrics> CleanupOldLogsAsync(CancellationToken cancellationToken)
    {
        var metrics = new CleanupMetrics { StartTime = DateTime.UtcNow };
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        var cutoffDate = DateTime.UtcNow.AddDays(-_settings.RetentionDays);

        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync(cancellationToken);

            // Гарантируем существование схемы (только при первой инициализации)
            await EnsureSchemaAsync(connection, cancellationToken);

            // Получаем размер БД до очистки
            metrics.DatabaseSizeBeforeMB = await GetDatabaseSizeMBAsync(connection, cancellationToken);

            // Получаем общее количество записей ДО удаления (для расчета процента VACUUM)
            var totalCountBefore = await GetTotalLogCountAsync(connection, cancellationToken);

            // Сначала узнаём, сколько записей будет удалено (опционально)
            var cutoffDateString = cutoffDate.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");
            long countToDelete = 0;

            if (!_settings.SkipCountQuery)
            {
                countToDelete = await GetOldLogsCountAsync(connection, cutoffDateString, cancellationToken);
                metrics.RecordsToDelete = countToDelete;

                if (countToDelete == 0)
                {
                    _logger.LogDebug("✅ Старых логов для удаления не найдено (старше {CutoffDate:yyyy-MM-dd})", cutoffDate);
                    metrics.EndTime = DateTime.UtcNow;
                    metrics.Duration = stopwatch.Elapsed;
                    return metrics;
                }

                _logger.LogInformation(
                    "Найдено {Count} записей для удаления (старше {CutoffDate:yyyy-MM-dd})",
                    countToDelete, cutoffDate);
            }
            else
            {
                _logger.LogInformation(
                    "Пропущен COUNT запрос для оптимизации. Начинаем удаление записей старше {CutoffDate:yyyy-MM-dd}",
                    cutoffDate);
            }

            // Удаляем старые записи батчами
            var deletedCount = await DeleteInBatchesAsync(connection, cutoffDateString, cancellationToken);
            metrics.RecordsDeleted = deletedCount;

            // Выполняем VACUUM только если включен и удалено достаточно записей
            // Используем totalCountBefore для правильного расчета процента
            if (_settings.EnableVacuum && deletedCount > 0 && totalCountBefore > 0)
            {
                // Правильный расчет: процент от общего количества ДО удаления
                var deletedPercent = (deletedCount * 100.0) / totalCountBefore;
                metrics.VacuumExecuted = deletedPercent >= _settings.VacuumThresholdPercent;
                
                if (metrics.VacuumExecuted)
                {
                    await ExecuteVacuumAsync(connection, cancellationToken);
                }
                else
                {
                    _logger.LogDebug(
                        "VACUUM пропущен: удалено {DeletedPercent:F2}% записей (удалено: {Deleted}, было всего: {Total}), требуется минимум {Threshold}%",
                        deletedPercent, deletedCount, totalCountBefore, _settings.VacuumThresholdPercent);
                }
            }

            // Получаем размер БД после очистки
            metrics.DatabaseSizeAfterMB = await GetDatabaseSizeMBAsync(connection, cancellationToken);
            metrics.SizeReductionMB = metrics.DatabaseSizeBeforeMB - metrics.DatabaseSizeAfterMB;

            stopwatch.Stop();
            metrics.EndTime = DateTime.UtcNow;
            metrics.Duration = stopwatch.Elapsed;

            // Логируем метрики
            _logger.LogInformation(
                "🗑️ Очистка аудит логов завершена: удалено {DeletedCount} записей старше {CutoffDate:yyyy-MM-dd}, " +
                "время: {ElapsedMs}мс, размер БД: {SizeBefore:F2}MB → {SizeAfter:F2}MB (уменьшение: {SizeReduction:F2}MB), " +
                "VACUUM: {VacuumExecuted}",
                deletedCount, cutoffDate, metrics.Duration.TotalMilliseconds,
                metrics.DatabaseSizeBeforeMB, metrics.DatabaseSizeAfterMB, metrics.SizeReductionMB,
                metrics.VacuumExecuted ? "выполнен" : "пропущен");

            return metrics;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            metrics.EndTime = DateTime.UtcNow;
            metrics.Duration = stopwatch.Elapsed;
            _logger.LogError(ex, "❌ Ошибка при очистке старых логов, время: {ElapsedMs}мс", metrics.Duration.TotalMilliseconds);
            throw;
        }
    }

    /// <summary>
    /// Получает размер базы данных в мегабайтах
    /// </summary>
    private async Task<double> GetDatabaseSizeMBAsync(
        SqliteConnection connection,
        CancellationToken cancellationToken)
    {
        try
        {
            // Получаем page_count и page_size отдельными запросами
            await using var pageCountCommand = connection.CreateCommand();
            pageCountCommand.CommandText = "PRAGMA page_count";
            var pageCount = Convert.ToInt64(await pageCountCommand.ExecuteScalarAsync(cancellationToken));

            await using var pageSizeCommand = connection.CreateCommand();
            pageSizeCommand.CommandText = "PRAGMA page_size";
            var pageSize = Convert.ToInt64(await pageSizeCommand.ExecuteScalarAsync(cancellationToken));

            var sizeBytes = pageCount * pageSize;
            return sizeBytes / (1024.0 * 1024.0); // Конвертируем в MB
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось получить размер БД. Возвращаем 0.");
            return 0;
        }
    }

    /// <summary>
    /// Получает количество старых логов для удаления
    /// </summary>
    private async Task<long> GetOldLogsCountAsync(
        SqliteConnection connection,
        string cutoffDateString,
        CancellationToken cancellationToken)
    {
        await using var countCommand = connection.CreateCommand();
        countCommand.CommandText = @"
            SELECT COUNT(*) 
            FROM audit_logs 
            WHERE created_at < @cutoffDate
        ";
        countCommand.Parameters.AddWithValue("@cutoffDate", cutoffDateString);

        var result = await countCommand.ExecuteScalarAsync(cancellationToken);
        return result != null && result != DBNull.Value
            ? Convert.ToInt64(result)
            : 0;
    }

    /// <summary>
    /// Получает общее количество логов в БД
    /// </summary>
    private async Task<long> GetTotalLogCountAsync(
        SqliteConnection connection,
        CancellationToken cancellationToken)
    {
        await using var countCommand = connection.CreateCommand();
        countCommand.CommandText = "SELECT COUNT(*) FROM audit_logs";

        var result = await countCommand.ExecuteScalarAsync(cancellationToken);
        return result != null && result != DBNull.Value
            ? Convert.ToInt64(result)
            : 0;
    }

    /// <summary>
    /// Удаляет записи батчами для оптимизации производительности
    /// </summary>
    private async Task<int> DeleteInBatchesAsync(
        SqliteConnection connection,
        string cutoffDateString,
        CancellationToken cancellationToken)
    {
        int totalDeleted = 0;
        int batchNumber = 0;
        var lastProgressLogTime = DateTime.UtcNow;
        var progressLogInterval = TimeSpan.FromSeconds(_settings.ProgressLogIntervalSeconds);

        while (!cancellationToken.IsCancellationRequested)
        {
            cancellationToken.ThrowIfCancellationRequested();

            await using var transaction = (Microsoft.Data.Sqlite.SqliteTransaction)await connection.BeginTransactionAsync(cancellationToken);
            try
            {
                await using var deleteCommand = connection.CreateCommand();
                deleteCommand.Transaction = transaction;
                deleteCommand.CommandText = @"
                    DELETE FROM audit_logs 
                    WHERE id IN (
                        SELECT id FROM audit_logs 
                        WHERE created_at < @cutoffDate 
                        LIMIT @batchSize
                    )";
                deleteCommand.Parameters.AddWithValue("@cutoffDate", cutoffDateString);
                deleteCommand.Parameters.AddWithValue("@batchSize", _settings.BatchSize);

                var deleted = await deleteCommand.ExecuteNonQueryAsync(cancellationToken);
                await transaction.CommitAsync(cancellationToken);

                if (deleted == 0)
                    break;

                totalDeleted += deleted;
                batchNumber++;

                // Логируем прогресс по времени или каждые 10 батчей
                var shouldLogProgress = false;
                if (_settings.ProgressLogIntervalSeconds > 0)
                {
                    var timeSinceLastLog = DateTime.UtcNow - lastProgressLogTime;
                    if (timeSinceLastLog >= progressLogInterval)
                    {
                        shouldLogProgress = true;
                        lastProgressLogTime = DateTime.UtcNow;
                    }
                }
                else if (batchNumber % 10 == 0)
                {
                    shouldLogProgress = true;
                }

                if (shouldLogProgress)
                {
                    _logger.LogInformation(
                        "Прогресс очистки: батч #{BatchNumber}, удалено в батче: {Deleted}, всего удалено: {Total}",
                        batchNumber, deleted, totalDeleted);
                }

                // Небольшая задержка между батчами для снижения нагрузки
                if (_settings.BatchDelayMs > 0)
                {
                    await Task.Delay(_settings.BatchDelayMs, cancellationToken);
                }
            }
            catch (OperationCanceledException)
            {
                await transaction.RollbackAsync(cancellationToken);
                _logger.LogWarning("Удаление прервано по запросу отмены. Удалено {Total} записей в {BatchNumber} батчах", totalDeleted, batchNumber);
                throw;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync(cancellationToken);
                _logger.LogError(ex, "Ошибка при удалении батча #{BatchNumber}", batchNumber);
                throw;
            }
        }

        return totalDeleted;
    }

    /// <summary>
    /// Выполняет VACUUM с обработкой ошибок
    /// </summary>
    private async Task ExecuteVacuumAsync(SqliteConnection connection, CancellationToken cancellationToken)
    {
        try
        {
            _logger.LogInformation("Выполняется VACUUM для оптимизации БД...");
            var vacuumStopwatch = System.Diagnostics.Stopwatch.StartNew();

            cancellationToken.ThrowIfCancellationRequested();

            await using var vacuumCommand = connection.CreateCommand();
            vacuumCommand.CommandText = "VACUUM";
            await vacuumCommand.ExecuteNonQueryAsync(cancellationToken);

            vacuumStopwatch.Stop();
            _logger.LogInformation(
                "VACUUM выполнен успешно за {ElapsedMs}мс",
                vacuumStopwatch.ElapsedMilliseconds);
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("VACUUM прерван по запросу отмены");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                ex,
                "Не удалось выполнить VACUUM. Это не критично, БД продолжит работать нормально.");
            // Не пробрасываем исключение, т.к. VACUUM не критичен
        }
    }

    /// <summary>
    /// Пытается получить файловую блокировку для предотвращения одновременного выполнения
    /// </summary>
    private async Task<bool> TryAcquireLockAsync(CancellationToken cancellationToken)
    {
        try
        {
            // Освобождаем предыдущую блокировку, если есть
            ReleaseLock();

            // Пытаемся создать файл с эксклюзивной блокировкой
            _lockFileStream = new FileStream(
                _lockFilePath,
                FileMode.Create,
                FileAccess.Write,
                FileShare.None,
                bufferSize: 1,
                useAsync: true);

            // Записываем PID процесса для отладки
            var pid = System.Diagnostics.Process.GetCurrentProcess().Id;
            var pidBytes = System.Text.Encoding.UTF8.GetBytes(pid.ToString());
            await _lockFileStream.WriteAsync(new ReadOnlyMemory<byte>(pidBytes), cancellationToken);
            await _lockFileStream.FlushAsync(cancellationToken);

            return true;
        }
        catch (IOException)
        {
            // Файл уже заблокирован другим процессом
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Неожиданная ошибка при попытке получить блокировку");
            return false;
        }
    }

    /// <summary>
    /// Освобождает файловую блокировку
    /// </summary>
    private void ReleaseLock()
    {
        try
        {
            _lockFileStream?.Dispose();
            _lockFileStream = null;

            // Удаляем файл блокировки, если он существует
            if (File.Exists(_lockFilePath))
            {
                File.Delete(_lockFilePath);
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при освобождении блокировки");
        }
    }

    /// <summary>
    /// Гарантирует существование файла БД и схемы таблицы аудита
    /// </summary>
    private async Task EnsureDatabaseExistsAsync(CancellationToken cancellationToken)
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await EnsureSchemaAsync(connection, cancellationToken);
    }

    /// <summary>
    /// Гарантирует существование схемы таблицы (индексы создаются только при первой инициализации)
    /// </summary>
    private async Task EnsureSchemaAsync(SqliteConnection connection, CancellationToken cancellationToken)
    {
        // Создаем таблицу всегда (идемпотентно)
        await using var tableCommand = connection.CreateCommand();
        tableCommand.CommandText = CreateTableSql;
        await tableCommand.ExecuteNonQueryAsync(cancellationToken);

        // Индексы создаем только если их еще нет (проверяем каждый раз для надежности)
        await _schemaInitSemaphore.WaitAsync(cancellationToken);
        try
        {
            // Всегда проверяем существование индексов (не полагаемся на статический флаг)
            // Это гарантирует работу даже если БД была пересоздана
            await using var checkIndexCommand = connection.CreateCommand();
            checkIndexCommand.CommandText = @"
                SELECT COUNT(*) FROM sqlite_master 
                WHERE type='index' AND name='idx_audit_created_at'
            ";
            var indexExists = Convert.ToInt32(await checkIndexCommand.ExecuteScalarAsync(cancellationToken)) > 0;

            if (!indexExists)
            {
                try
                {
                    _logger.LogInformation("Создание индексов для таблицы audit_logs...");
                    await using var indexCommand = connection.CreateCommand();
                    indexCommand.CommandText = CreateIndexesSql;
                    await indexCommand.ExecuteNonQueryAsync(cancellationToken);
                    _logger.LogInformation("Индексы успешно созданы");
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Не удалось создать индексы. Продолжаем без них.");
                }
            }
        }
        finally
        {
            _schemaInitSemaphore.Release();
        }
    }

    /// <summary>
    /// Проверяет и создает директорию для БД, если она не существует
    /// </summary>
    private void EnsureDatabaseDirectoryExists()
    {
        var dbPath = _dataPathsSettings.GetAuditDbPath();
        var directory = Path.GetDirectoryName(dbPath);
        if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
        {
            Directory.CreateDirectory(directory);
            _logger.LogInformation("Создана директория для БД аудита: {Directory}", directory);
        }
    }

    /// <summary>
    /// Метрики очистки для мониторинга
    /// </summary>
    private class CleanupMetrics
    {
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public TimeSpan Duration { get; set; }
        public long RecordsToDelete { get; set; }
        public int RecordsDeleted { get; set; }
        public double DatabaseSizeBeforeMB { get; set; }
        public double DatabaseSizeAfterMB { get; set; }
        public double SizeReductionMB { get; set; }
        public bool VacuumExecuted { get; set; }
    }

    public override void Dispose()
    {
        ReleaseLock();
        base.Dispose();
    }
}
