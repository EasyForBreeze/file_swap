using System.Diagnostics;
using System.Globalization;
using System.Net;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using new_assistant.Core.Exceptions;

namespace new_assistant.Infrastructure.Services.Keycloak;

/// <summary>
/// Клиент для работы с секретами клиентов Keycloak
/// </summary>
public class KeycloakClientSecretsClient : KeycloakHttpClientBase
{
    // Константы для валидации параметров
    // MaxRealmLength и MaxClientIdLength используются из базового класса KeycloakHttpClientBase
    private const int MaxContentLength = 10 * 1024 * 1024; // 10 MB
    
    // Константы для сообщений логирования
    private const string LogSemaphoreDisposed = "Semaphore disposed, cannot execute operation: {Operation}";
    private const string LogResponseContentNull = "Response.Content is null for {Operation}";
    private const string LogEmptyResponse = "Response content is null or empty for {Operation}";
    private const string LogJsonDeserializationError = "Ошибка десериализации JSON при {Operation}. Content: {Content}";
    private const string LogInvalidResponseFormat = "Неверный формат ответа при {Operation}";
    private const string LogHttpRequestError = "Ошибка HTTP запроса при {Operation}: {StatusCode}";
    private const string LogHttpRequestErrorWithContent = "Ошибка HTTP запроса при {Operation}: {StatusCode} - {Error}";
    private const string LogOperationCanceled = "Операция {Operation} была отменена";
    private const string LogTimeout = "Timeout при {Operation}";
    private const string LogUnexpectedError = "Неожиданная ошибка при {Operation} - {Time}мс";
    private const string LogErrorReadingResponseBody = "Не удалось прочитать тело ответа при ошибке для {Operation}";
    private const string LogResponseTooLarge = "Response content length ({ContentLength}) exceeds maximum allowed length ({MaxLength}) for {Operation}";
    private const string LogInvalidJsonFormat = "Deserialized secret JSON is null or undefined for {Operation}";
    private const string LogNullResponse = "HttpClient.SendAsync returned null response for {Operation}";
    private const string LogOperationSuccess = "Операция {Operation} завершена успешно. Realm: {Realm}, ClientId: {ClientId}, Time: {Time}мс";
    private const string LogSecretNotFound = "Не удалось получить client secret для {Operation}: Realm={Realm}, ClientId={ClientId}";
    private const string LogClientSecretNotFound = "Client secret not found for {Operation}: Realm={Realm}, ClientId={ClientId}";
    private const string LogNoErrorContent = "No error content available";
    private const string LogErrorContentTooLarge = "Error content too large ({ContentLength} bytes) for {Operation}, skipping read";
    
    // Опасные символы для проверки injection атак
    // Расширенный список для защиты от path traversal и injection атак
    private static readonly char[] InvalidChars = 
    { 
        '/', '\\', '?', '#', '[', ']', '@', '!', '$', '&', '\'', '(', ')', 
        '*', '+', ',', ';', '=', '%', ' ', '\t', '\r', '\n'
    };
    
    // Используем JsonSerializerOptions из базового класса (исправление проблемы #6)
    private static JsonSerializerOptions DefaultJsonOptions => KeycloakHttpClientBase.DefaultJsonSerializerOptions;
    
    /// <summary>
    /// Валидирует параметры realm и clientInternalId
    /// </summary>
    /// <param name="realm">Название реалма для валидации</param>
    /// <param name="clientInternalId">Внутренний ID клиента для валидации (должен быть UUID)</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах или наличии опасных символов</exception>
    private void ValidateRealmAndClientId(string realm, string clientInternalId)
    {
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        if (realm.Length > MaxRealmLength)
            throw new ArgumentException($"Realm length ({realm.Length}) exceeds maximum allowed length ({MaxRealmLength})", nameof(realm));
        
        // Проверка на потенциально опасные символы для предотвращения injection (оптимизировано через IndexOfAny)
        if (realm.IndexOfAny(InvalidChars) >= 0)
            throw new ArgumentException("Realm contains invalid characters", nameof(realm));
        
        if (string.IsNullOrWhiteSpace(clientInternalId))
            throw new ArgumentException("Client internal ID cannot be null or empty", nameof(clientInternalId));
        if (clientInternalId.Length > MaxClientIdLength)
            throw new ArgumentException($"Client internal ID length ({clientInternalId.Length}) exceeds maximum allowed length ({MaxClientIdLength})", nameof(clientInternalId));
        
        // Проверка на потенциально опасные символы для предотвращения injection (оптимизировано через IndexOfAny)
        if (clientInternalId.IndexOfAny(InvalidChars) >= 0)
            throw new ArgumentException("Client internal ID contains invalid characters", nameof(clientInternalId));
        
        // Валидация формата UUID
        if (!Guid.TryParse(clientInternalId, out _))
            throw new ArgumentException($"Client internal ID must be a valid UUID format, but was: {clientInternalId}", nameof(clientInternalId));
    }
    
    /// <summary>
    /// Выполняет HTTP запрос с обработкой rate limiting и метриками
    /// </summary>
    /// <param name="request">HTTP запрос для выполнения</param>
    /// <param name="endpoint">Endpoint для логирования и повтора запроса</param>
    /// <param name="operationName">Название операции для логирования</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>HTTP ответ от сервера</returns>
    private async Task<HttpResponseMessage> ExecuteRequestWithRateLimitAsync(
        HttpRequestMessage request,
        string endpoint,
        string operationName,
        CancellationToken cancellationToken = default)
    {
        // Сохраняем информацию о запросе для возможного повтора
        var method = request.Method;
        HttpResponseMessage? response = null;
        
        try
        {
            response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            
            // Обработка rate limiting - если получили 429, создаем новый запрос для повтора
            var finalResponse = await HandleRateLimitAsync(
                response,
                async () =>
                {
                    // Создаем новый запрос для повтора (HttpRequestMessage нельзя использовать повторно)
                    using var retryRequest = await CreateAuthorizedRequestAsync(method, endpoint, cancellationToken).ConfigureAwait(false);
                    return await HttpClient.SendAsync(retryRequest, cancellationToken).ConfigureAwait(false);
                },
                cancellationToken).ConfigureAwait(false);
            
            // Записываем метрику HTTP запроса
            RecordHttpRequest(method.ToString(), endpoint, finalResponse.IsSuccessStatusCode);
            
            // Если finalResponse - это новый response (retry), то response нужно dispose
            // Если finalResponse - это тот же response, то не нужно dispose дважды
            if (finalResponse != response)
            {
                response.Dispose();
                response = null; // Помечаем как освобожденный
            }
            
            return finalResponse;
        }
        catch
        {
            // В случае ошибки нужно dispose response
            response?.Dispose();
            throw;
        }
    }
    
    /// <summary>
    /// Парсит секрет из JSON ответа
    /// </summary>
    /// <param name="secretJson">JSON элемент, содержащий секрет</param>
    /// <returns>Значение секрета или null, если секрет не найден</returns>
    private static string? ParseSecretFromJson(JsonElement secretJson)
    {
        // Проверяем, что JSON является объектом
        if (secretJson.ValueKind != JsonValueKind.Object)
        {
            return null;
        }
        
        // Извлекаем значение свойства "value"
        return secretJson.TryGetProperty("value", out var valueProp) ? valueProp.GetString() : null;
    }
    
    /// <summary>
    /// Безопасно читает содержимое ошибки из HTTP ответа
    /// </summary>
    /// <param name="response">HTTP ответ от сервера</param>
    /// <param name="operationName">Название операции для логирования</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Содержимое ошибки или null, если не удалось прочитать</returns>
    private async Task<string?> ReadErrorContentSafelyAsync(
        HttpResponseMessage response,
        string operationName,
        CancellationToken cancellationToken = default)
    {
        if (response.Content == null)
        {
            return null;
        }
        
        try
        {
            // БЕЗОПАСНОСТЬ: Проверяем размер контента перед чтением для защиты от DoS атак
            var contentLength = response.Content.Headers.ContentLength;
            if (contentLength.HasValue && contentLength.Value > MaxContentLength)
            {
                Logger?.LogWarning(LogErrorContentTooLarge, contentLength.Value, operationName);
                return "Content too large to read";
            }
            
            return await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            Logger?.LogWarning(ex, LogErrorReadingResponseBody, operationName);
            return null;
        }
    }
    
    /// <summary>
    /// Обрабатывает HTTP ответ с ошибкой
    /// </summary>
    /// <param name="response">HTTP ответ от сервера</param>
    /// <param name="errorContent">Содержимое ошибки (может быть null)</param>
    /// <param name="operationName">Название операции для логирования</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента</param>
    /// <param name="throwOnError">Если true, выбрасывает исключения при ошибках</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <exception cref="KeycloakClientSecretNotFoundException">Выбрасывается при 404 (если throwOnError=true)</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при других ошибках (если throwOnError=true)</exception>
    private Task HandleErrorResponseAsync(
        HttpResponseMessage response,
        string? errorContent,
        string operationName,
        string realm,
        string clientInternalId,
        bool throwOnError,
        CancellationToken cancellationToken = default)
    {
        // ВАЖНО: Никогда не логируем секреты напрямую (исправление проблемы #9)
        // Всегда обрезаем errorContent до минимальной длины для безопасности
        // Максимальная длина для логирования секретов - 50 символов (вместо 200)
        const int MaxSecretContentLengthForLogging = 50;
        
        string truncatedError;
        if (errorContent == null)
        {
            truncatedError = LogNoErrorContent;
        }
        else
        {
            // Всегда обрезаем до минимальной длины при работе с секретами
            var maxLength = Math.Min(MaxSecretContentLengthForLogging, MaxContentLengthForLogging);
            if (errorContent.Length > maxLength)
            {
                truncatedError = errorContent.Substring(0, maxLength) + "...";
            }
            else
            {
                truncatedError = errorContent;
            }
            
            // БЕЗОПАСНОСТЬ: Проверка на наличие потенциальных секретов в errorContent
            // Если найдены ключевые слова, полностью скрываем контент
            var lowerContent = errorContent.ToLowerInvariant();
            if (lowerContent.Contains("secret") || 
                lowerContent.Contains("password") || 
                lowerContent.Contains("token") ||
                lowerContent.Contains("key") ||
                lowerContent.Contains("credential") ||
                lowerContent.Contains("client_secret") ||
                lowerContent.Contains("access_token"))
            {
                truncatedError = "Error content contains potentially sensitive data and was redacted";
            }
        }
        
        // Различаем случаи "секрет не найден" (404) и другие ошибки
        if (response.StatusCode == HttpStatusCode.NotFound)
        {
            // Для 404 логируем как предупреждение, а не ошибку
            Logger?.LogWarning(LogClientSecretNotFound, operationName, realm, clientInternalId);
            RecordError(operationName, "NotFound");
            
            if (throwOnError)
            {
                throw new KeycloakClientSecretNotFoundException(realm, clientInternalId);
            }
        }
        else
        {
            Logger?.LogError(LogHttpRequestErrorWithContent, operationName, response.StatusCode, truncatedError);
            RecordError(operationName, $"HttpRequestFailed_{response.StatusCode}");
            
            if (throwOnError)
            {
                throw new HttpRequestException(
                    $"Не удалось выполнить {operationName}: {response.StatusCode}" + 
                    (errorContent != null ? $" - {errorContent}" : ""));
            }
        }
        
        return Task.CompletedTask;
    }
    
    /// <summary>
    /// Парсит секрет из HTTP ответа
    /// </summary>
    /// <param name="response">HTTP ответ от сервера</param>
    /// <param name="operationName">Название операции для логирования</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Значение секрета или null, если секрет не найден или произошла ошибка</returns>
    private async Task<string?> ParseSecretFromResponseAsync(
        HttpResponseMessage response,
        string operationName,
        CancellationToken cancellationToken = default)
    {
        if (response.Content == null)
        {
            Logger?.LogWarning(LogResponseContentNull, operationName);
            RecordError(operationName, "ResponseContentNull");
            return null;
        }
        
        var content = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
        
        if (string.IsNullOrWhiteSpace(content))
        {
            Logger?.LogWarning(LogEmptyResponse, operationName);
            RecordError(operationName, "EmptyResponse");
            return null;
        }
        
        if (content.Length > MaxContentLength)
        {
            Logger?.LogWarning(LogResponseTooLarge, content.Length, MaxContentLength, operationName);
            RecordError(operationName, "ResponseTooLarge");
            return null;
        }
        
        JsonElement secretJson;
        var parseStopwatch = Stopwatch.StartNew();
        try
        {
            // Использовать JsonDocument для более эффективного парсинга
            using var document = JsonDocument.Parse(content, new JsonDocumentOptions 
            { 
                AllowTrailingCommas = false,
                CommentHandling = JsonCommentHandling.Skip
            });
            secretJson = document.RootElement;
            
            parseStopwatch.Stop();
            // Метрика времени парсинга JSON
            RecordRequestTime(parseStopwatch.ElapsedMilliseconds);
            // Метрика размера ответа (группируем по диапазонам для уменьшения количества метрик)
            var sizeCategory = content.Length switch
            {
                < 100 => "Small",
                < 1000 => "Medium",
                < 10000 => "Large",
                _ => "VeryLarge"
            };
            MetricsService?.RecordSuccess($"{MetricsOperationName}.{operationName}.ResponseSize.{sizeCategory}");
        }
        catch (JsonException ex)
        {
            parseStopwatch.Stop();
            Logger?.LogError(ex, LogJsonDeserializationError, 
                operationName,
                content.Length > MaxContentLengthForLogging ? content.Substring(0, MaxContentLengthForLogging) + "..." : content);
            RecordError(operationName, "JsonDeserializationError");
            return null;
        }
        
        if (secretJson.ValueKind == JsonValueKind.Null || secretJson.ValueKind == JsonValueKind.Undefined)
        {
            Logger?.LogWarning(LogInvalidJsonFormat, operationName);
            RecordError(operationName, "InvalidJsonFormat");
            return null;
        }
        
        var secret = ParseSecretFromJson(secretJson);
        
        if (secret == null)
        {
            Logger?.LogWarning(LogInvalidResponseFormat, operationName);
            RecordError(operationName, "InvalidResponseFormat");
            return null;
        }
        
        return secret;
    }
    
    /// <summary>
    /// Выполняет операцию с client secret (общий метод для GET и POST)
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="method">HTTP метод (GET для получения, POST для регенерации)</param>
    /// <param name="operationName">Название операции для логирования и метрик</param>
    /// <param name="throwOnError">Если true, выбрасывает исключения при ошибках; если false, возвращает null</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Client secret или null, если секрет не найден или произошла ошибка (при throwOnError=false)</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибке HTTP запроса (если throwOnError=true)</exception>
    /// <exception cref="InvalidOperationException">Выбрасывается при неожиданных ошибках (если throwOnError=true)</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции</exception>
    /// <exception cref="TimeoutException">Выбрасывается при превышении времени ожидания (если throwOnError=true)</exception>
    private async Task<string?> ExecuteSecretOperationAsync(
        string realm,
        string clientInternalId,
        HttpMethod method,
        string operationName,
        bool throwOnError,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        ValidateRealmAndClientId(realm, clientInternalId);
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger?.LogWarning(LogSemaphoreDisposed, operationName);
            RecordError(operationName, "SemaphoreDisposed");
            return null;
        }
        
        try
        {
            // Формируем endpoint с использованием string.Format для безопасности и производительности
            var endpoint = string.Format(
                CultureInfo.InvariantCulture,
                "admin/realms/{0}/clients/{1}/client-secret",
                realm,
                clientInternalId);
            
            // CreateAuthorizedRequestAsync автоматически получает токен и валидирует endpoint
            using var request = await CreateAuthorizedRequestAsync(method, endpoint, cancellationToken).ConfigureAwait(false);
            using var response = await ExecuteRequestWithRateLimitAsync(request, endpoint, operationName, cancellationToken).ConfigureAwait(false);
            
            if (response == null)
            {
                Logger?.LogError(LogNullResponse, operationName);
                RecordError(operationName, "NullResponse");
                if (throwOnError)
                    throw new InvalidOperationException($"HttpClient returned null response for {operationName}");
                return null;
            }
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await ReadErrorContentSafelyAsync(response, operationName, cancellationToken).ConfigureAwait(false);
                await HandleErrorResponseAsync(response, errorContent, operationName, realm, clientInternalId, throwOnError, cancellationToken).ConfigureAwait(false);
                return null;
            }
            
            var secret = await ParseSecretFromResponseAsync(response, operationName, cancellationToken).ConfigureAwait(false);
            
            if (secret != null)
            {
                RecordSuccess(operationName);
                Logger?.LogInformation(LogOperationSuccess, operationName, realm, clientInternalId, stopwatch.ElapsedMilliseconds);
            }
            else
            {
                // Секрет не найден или не удалось распарсить
                Logger?.LogWarning(LogSecretNotFound, operationName, realm, clientInternalId);
            }
            
            return secret;
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            // Это timeout, а не отмена пользователем (исправление проблемы #5)
            // Используем паттерн проверки InnerException как в других местах кода
            Logger?.LogError(LogTimeout, operationName);
            RecordError(operationName, "Timeout");
            if (throwOnError)
            {
                throw new TimeoutException($"Timeout при {operationName}", ex.InnerException);
            }
            return null;
        }
        catch (TaskCanceledException)
        {
            // Это отмена операции пользователем
            Logger?.LogWarning(LogOperationCanceled, operationName);
            RecordError(operationName, "TaskCanceled");
            throw new OperationCanceledException("Операция была отменена", cancellationToken);
        }
        catch (OperationCanceledException)
        {
            Logger?.LogWarning(LogOperationCanceled, operationName);
            RecordError(operationName, "OperationCanceled");
            throw;
        }
        catch (HttpRequestException)
        {
            // Пробрасываем HttpRequestException дальше для операций модификации
            throw;
        }
        catch (Exception ex) when (!(ex is OperationCanceledException || ex is HttpRequestException || ex is TimeoutException))
        {
            Logger?.LogError(ex, LogUnexpectedError, operationName, stopwatch.ElapsedMilliseconds);
            RecordError(operationName, "UnexpectedException");
            
            if (throwOnError)
            {
                throw new InvalidOperationException($"Неожиданная ошибка при {operationName}: {ex.Message}", ex);
            }
            
            return null;
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Инициализирует новый экземпляр класса KeycloakClientSecretsClient
    /// </summary>
    /// <param name="httpClient">HTTP клиент для выполнения запросов</param>
    /// <param name="settings">Настройки для работы с Keycloak Admin API</param>
    /// <param name="logger">Логгер для записи событий</param>
    /// <param name="cacheService">Сервис кэширования</param>
    /// <param name="metricsService">Сервис для записи метрик производительности</param>
    public KeycloakClientSecretsClient(
        System.Net.Http.HttpClient httpClient,
        new_assistant.Configuration.KeycloakAdminSettings settings,
        ILogger logger,
        new_assistant.Core.Interfaces.IKeycloakCacheService cacheService,
        new_assistant.Core.Interfaces.IPerformanceMetricsService metricsService)
        : base(httpClient, settings, logger, cacheService, metricsService)
    {
    }
    
    /// <summary>
    /// Получение client secret для указанного клиента в реалме
    /// </summary>
    /// <param name="realm">Название реалма (должно быть валидным именем реалма Keycloak)</param>
    /// <param name="clientInternalId">Внутренний ID клиента в формате UUID (например: "550e8400-e29b-41d4-a716-446655440000")</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Client secret или null, если секрет не найден или произошла ошибка</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах (null, пустая строка, невалидный UUID)</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции</exception>
    /// <example>
    /// <code>
    /// var secret = await client.GetClientSecretAsync("myrealm", "550e8400-e29b-41d4-a716-446655440000");
    /// if (secret != null)
    /// {
    ///     Console.WriteLine($"Secret retrieved successfully");
    /// }
    /// </code>
    /// </example>
    public async Task<string?> GetClientSecretAsync(string realm, string clientInternalId, CancellationToken cancellationToken = default)
    {
        const string operationName = nameof(GetClientSecretAsync);
        // Для операций чтения (GET) возвращаем null при ошибках, не выбрасываем исключения
        return await ExecuteSecretOperationAsync(realm, clientInternalId, HttpMethod.Get, operationName, throwOnError: false, cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Регенерация client secret для указанного клиента в реалме
    /// </summary>
    /// <param name="realm">Название реалма (должно быть валидным именем реалма Keycloak)</param>
    /// <param name="clientInternalId">Внутренний ID клиента в формате UUID (например: "550e8400-e29b-41d4-a716-446655440000")</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Новый client secret после регенерации</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах (null, пустая строка, невалидный UUID)</exception>
    /// <exception cref="KeycloakClientSecretNotFoundException">Выбрасывается при 404 (клиент или секрет не найден)</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибке HTTP запроса</exception>
    /// <exception cref="InvalidOperationException">Выбрасывается при неожиданных ошибках</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции</exception>
    /// <exception cref="TimeoutException">Выбрасывается при превышении времени ожидания</exception>
    /// <example>
    /// <code>
    /// try
    /// {
    ///     var newSecret = await client.RegenerateClientSecretAsync("myrealm", "550e8400-e29b-41d4-a716-446655440000");
    ///     Console.WriteLine($"New secret generated: {newSecret}");
    /// }
    /// catch (KeycloakClientSecretNotFoundException ex)
    /// {
    ///     Console.WriteLine($"Client not found: {ex.Realm}/{ex.ClientInternalId}");
    /// }
    /// </code>
    /// </example>
    public async Task<string?> RegenerateClientSecretAsync(string realm, string clientInternalId, CancellationToken cancellationToken = default)
    {
        const string operationName = nameof(RegenerateClientSecretAsync);
        // Для операций модификации (POST) выбрасываем исключения при ошибках
        return await ExecuteSecretOperationAsync(realm, clientInternalId, HttpMethod.Post, operationName, throwOnError: true, cancellationToken).ConfigureAwait(false);
    }
}

