using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services.Keycloak;

/// <summary>
/// Базовый класс для HTTP клиентов Keycloak Admin API
/// Содержит общие методы для работы с токенами, semaphore, dispose и метриками
/// </summary>
public abstract class KeycloakHttpClientBase : IDisposable
{
    protected readonly HttpClient HttpClient;
    protected readonly KeycloakAdminSettings Settings;
    protected readonly ILogger Logger;
    protected readonly IKeycloakCacheService CacheService;
    protected readonly IPerformanceMetricsService MetricsService;
    protected readonly SemaphoreSlim Semaphore;
    protected readonly SemaphoreSlim TokenLock;
    protected volatile string? CachedToken;
    protected long TokenExpiresAtTicks;
    protected bool Disposed;
    
    // Базовый URL для Admin API, сформированный один раз при инициализации
    protected readonly string AdminApiBaseUrl;
    
    protected const string MetricsOperationName = "Keycloak.AdminAPI";
    
    // Константы для HTTP заголовков и контент-типов
    private const string ApplicationJson = "application/json";
    private const string ApplicationFormUrlEncoded = "application/x-www-form-urlencoded";
    private const string AcceptHeader = "Accept";
    protected const string BearerScheme = "Bearer";
    
    // Константы для OAuth2 token request
    private const string GrantType = "grant_type";
    private const string GrantTypeClientCredentials = "client_credentials";
    private const string ClientId = "client_id";
    private const string ClientSecret = "client_secret";
    
    // Константы для JSON свойств токена
    private const string AccessTokenProperty = "access_token";
    private const string ExpiresInProperty = "expires_in";
    
    // Константы для значений по умолчанию
    private const int DefaultTokenExpirationSeconds = 3600; // 1 час
    
    // Константы для retry логики получения токена
    private const int MaxTokenRetryAttempts = 3;
    private const int BaseRetryDelayMs = 1000; // 1 секунда
    private const int MaxRetryDelayMs = 10000; // 10 секунд
    
    // Константы для валидации
    protected const int MaxEndpointLength = 2000;
    protected const int MaxContentLengthForLogging = 200;
    protected const int MaxRealmLength = 100;
    protected const int MaxClientIdLength = 200;
    private const int MaxClientSecretLength = 500;
    
    // Константы для ограничения размера запросов и ответов (исправление проблемы #34)
    protected const int MaxRequestSizeBytes = 10 * 1024 * 1024; // 10 MB
    protected const int MaxResponseSizeBytes = 10 * 1024 * 1024; // 10 MB
    
    // Статические JsonSerializerOptions для переиспользования (исправление проблемы #6)
    // Используется всеми специализированными клиентами для консистентности и производительности
    public static readonly JsonSerializerOptions DefaultJsonSerializerOptions = new JsonSerializerOptions
    {
        PropertyNameCaseInsensitive = true,
        ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = false,
        MaxDepth = 64,
        PropertyNamingPolicy = null,
        WriteIndented = false
    };
    
    // JsonSerializerOptions для сериализации (без null значений)
    protected static readonly JsonSerializerOptions SerializeJsonSerializerOptions = new JsonSerializerOptions
    {
        DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull,
        WriteIndented = false,
        PropertyNameCaseInsensitive = true
    };
    
    /// <summary>
    /// Стратегия обработки ошибок для методов
    /// </summary>
    protected enum ErrorHandlingStrategy
    {
        /// <summary>
        /// Возвращать пустой результат при ошибке (для GET запросов)
        /// </summary>
        ReturnEmpty,
        
        /// <summary>
        /// Бросать исключение при ошибке (для операций изменения данных)
        /// </summary>
        ThrowException,
        
        /// <summary>
        /// Возвращать null при ошибке (для опциональных операций)
        /// </summary>
        ReturnNull
    }
    
    protected KeycloakHttpClientBase(
        HttpClient httpClient,
        KeycloakAdminSettings settings,
        ILogger logger,
        IKeycloakCacheService cacheService,
        IPerformanceMetricsService metricsService)
    {
        HttpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        Settings = settings ?? throw new ArgumentNullException(nameof(settings));
        Logger = logger ?? throw new ArgumentNullException(nameof(logger));
        CacheService = cacheService ?? throw new ArgumentNullException(nameof(cacheService));
        MetricsService = metricsService ?? throw new ArgumentNullException(nameof(metricsService));
        
        // Валидация MaxConcurrentRequests
        if (settings.MaxConcurrentRequests <= 0)
        {
            throw new ArgumentException("MaxConcurrentRequests must be greater than 0", nameof(settings));
        }
        if (settings.MaxConcurrentRequests > 100)
        {
            throw new ArgumentException("MaxConcurrentRequests cannot exceed 100", nameof(settings));
        }
        
        Semaphore = new SemaphoreSlim(settings.MaxConcurrentRequests, settings.MaxConcurrentRequests);
        TokenLock = new SemaphoreSlim(1, 1);
        TokenExpiresAtTicks = DateTime.MinValue.Ticks;
        
        // Формируем базовый URL для Admin API с учетом UseLegacyAuthPath
        AdminApiBaseUrl = BuildAdminApiBaseUrl();
        
        ConfigureHttpClient();
    }
    
    /// <summary>
    /// Формирует базовый URL для Admin API с учетом UseLegacyAuthPath
    /// </summary>
    private string BuildAdminApiBaseUrl()
    {
        if (Settings == null)
        {
            throw new InvalidOperationException("Settings cannot be null");
        }
        if (string.IsNullOrWhiteSpace(Settings.BaseUrl))
        {
            throw new ArgumentException("BaseUrl cannot be null or empty", nameof(Settings.BaseUrl));
        }
        
        // Улучшенная валидация BaseUrl с использованием Uri.TryCreate
        // Это более надежно, чем Uri.IsWellFormedUriString, так как проверяет схему и другие аспекты
        if (!Uri.TryCreate(Settings.BaseUrl, UriKind.Absolute, out var baseUri))
        {
            throw new ArgumentException($"BaseUrl is not a valid absolute URI: {Settings.BaseUrl}", nameof(Settings.BaseUrl));
        }
        
        // Проверка схемы (только http и https разрешены)
        if (baseUri.Scheme != Uri.UriSchemeHttp && baseUri.Scheme != Uri.UriSchemeHttps)
        {
            throw new ArgumentException($"BaseUrl must use http or https scheme, but was: {baseUri.Scheme}", nameof(Settings.BaseUrl));
        }
        
        var baseUrl = Settings.BaseUrl.TrimEnd('/');
        
        // Если UseLegacyAuthPath = true, добавляем /auth перед Admin API
        // и гарантируем закрывающий слэш, чтобы относительные пути корректно конкатенировались
        if (Settings.UseLegacyAuthPath && !baseUrl.EndsWith("/auth", StringComparison.OrdinalIgnoreCase))
        {
            return $"{baseUrl}/auth/";
        }
        
        // Если UseLegacyAuthPath = false, гарантируем закрывающий слэш
        return baseUrl.EndsWith("/") ? baseUrl : baseUrl + "/";
    }

    protected void ConfigureHttpClient()
    {
        if (Settings == null)
        {
            throw new InvalidOperationException("Settings cannot be null");
        }
        
        // Валидация RequestTimeoutSeconds
        if (Settings.RequestTimeoutSeconds <= 0)
        {
            throw new ArgumentException("RequestTimeoutSeconds must be greater than 0", nameof(Settings));
        }
        if (Settings.RequestTimeoutSeconds > 3600) // 1 час максимум
        {
            throw new ArgumentException("RequestTimeoutSeconds cannot exceed 3600 seconds", nameof(Settings));
        }
        
        // Проверяем, не настроен ли уже BaseAddress
        // Если HttpClient получен через IHttpClientFactory, он может быть уже настроен
        if (HttpClient.BaseAddress == null)
        {
            HttpClient.BaseAddress = new Uri(AdminApiBaseUrl);
        }
        else if (HttpClient.BaseAddress.ToString() != AdminApiBaseUrl)
        {
            Logger.LogWarning(
                "HttpClient BaseAddress уже настроен на {ExistingBaseAddress}, но ожидался {ExpectedBaseAddress}. " +
                "Используется существующий BaseAddress.",
                HttpClient.BaseAddress, AdminApiBaseUrl);
        }
        
        // Timeout настраиваем всегда, так как может быть изменен
        HttpClient.Timeout = TimeSpan.FromSeconds(Settings.RequestTimeoutSeconds);
        
        // Добавляем Accept header только если его еще нет (чтобы избежать дублирования)
        if (!HttpClient.DefaultRequestHeaders.Contains(AcceptHeader))
        {
            HttpClient.DefaultRequestHeaders.Add(AcceptHeader, ApplicationJson);
        }
        
        Logger.LogDebug(
            "[KeycloakAdmin] Инициализация: BaseUrl={BaseUrl}, AdminApiBaseUrl={AdminApiBaseUrl}, UseLegacyAuthPath={UseLegacyAuthPath}, Realm={Realm}",
            Settings.BaseUrl, AdminApiBaseUrl, Settings.UseLegacyAuthPath, Settings.Realm);
    }
    
    /// <summary>
    /// Записать время выполнения запроса в статистику
    /// </summary>
    protected void RecordRequestTime(long elapsedMs)
    {
        if (MetricsService == null)
        {
            Logger?.LogWarning("MetricsService is null, cannot record operation time");
            return;
        }
        MetricsService.RecordOperationTime(MetricsOperationName, elapsedMs);
    }
    
    /// <summary>
    /// Записать метрику успешной операции с указанием метода
    /// </summary>
    protected void RecordSuccess(string methodName)
    {
        MetricsService?.RecordSuccess($"{MetricsOperationName}.{methodName}");
    }
    
    /// <summary>
    /// Записать метрику ошибки с указанием метода и типа ошибки
    /// </summary>
    protected void RecordError(string methodName, string errorType)
    {
        MetricsService?.RecordError($"{MetricsOperationName}.{methodName}", errorType);
    }
    
    /// <summary>
    /// Записать метрику использования кэша (cache hit)
    /// </summary>
    protected void RecordCacheHit(string cacheKey)
    {
        MetricsService?.RecordSuccess($"{MetricsOperationName}.CacheHit");
        if (Logger?.IsEnabled(LogLevel.Debug) == true)
        {
            Logger.LogDebug("Cache hit для ключа: {CacheKey}", cacheKey);
        }
    }
    
    /// <summary>
    /// Записать метрику промаха кэша (cache miss)
    /// </summary>
    protected void RecordCacheMiss(string cacheKey)
    {
        MetricsService?.RecordSuccess($"{MetricsOperationName}.CacheMiss");
        if (Logger?.IsEnabled(LogLevel.Debug) == true)
        {
            Logger.LogDebug("Cache miss для ключа: {CacheKey}", cacheKey);
        }
    }
    
    /// <summary>
    /// Записать метрику HTTP запроса
    /// </summary>
    protected void RecordHttpRequest(string method, string endpoint, bool success)
    {
        var operationName = $"{MetricsOperationName}.HttpRequest.{method}";
        if (success)
        {
            RecordSuccess(operationName);
        }
        else
        {
            RecordError(operationName, "HttpRequestFailed");
        }
    }
    
    /// <summary>
    /// Безопасно освободить semaphore, игнорируя Dispose
    /// </summary>
    protected void SafeReleaseSemaphore()
    {
        try
        {
            if (!Disposed)
            {
                Semaphore.Release();
            }
        }
        catch (ObjectDisposedException)
        {
            // Игнорируем, если объект уже disposed
        }
    }
    
    /// <summary>
    /// Безопасно освободить tokenLock, игнорируя Dispose
    /// </summary>
    protected void SafeReleaseTokenLock()
    {
        try
        {
            if (!Disposed)
            {
                TokenLock.Release();
            }
        }
        catch (ObjectDisposedException)
        {
            // Игнорируем, если объект уже disposed
        }
    }
    
    /// <summary>
    /// Безопасно получить семафор, возвращая false если объект disposed
    /// </summary>
    protected async Task<bool> SafeWaitSemaphore(CancellationToken cancellationToken = default)
    {
        try
        {
            if (Disposed)
            {
                return false;
            }
            await Semaphore.WaitAsync(cancellationToken).ConfigureAwait(false);
            return true;
        }
        catch (ObjectDisposedException)
        {
            return false;
        }
        catch (OperationCanceledException)
        {
            // Пробрасываем OperationCanceledException дальше (исправление проблемы #36)
            // Это позволяет вызывающему коду правильно обработать отмену операции
            throw;
        }
    }

    /// <summary>
    /// Безопасно получить tokenLock
    /// </summary>
    protected async Task<bool> SafeWaitTokenLock(CancellationToken cancellationToken = default)
    {
        try
        {
            if (Disposed)
            {
                return false;
            }
            await TokenLock.WaitAsync(cancellationToken).ConfigureAwait(false);
            return true;
        }
        catch (ObjectDisposedException)
        {
            return false;
        }
        catch (OperationCanceledException)
        {
            // Операция была отменена через CancellationToken
            return false;
        }
    }

    /// <summary>
    /// БЕЗОПАСНОСТЬ: Обработка 429 Too Many Requests от Keycloak
    /// </summary>
    protected async Task<HttpResponseMessage> HandleRateLimitAsync(
        HttpResponseMessage response, 
        Func<Task<HttpResponseMessage>> retryAction,
        CancellationToken cancellationToken)
    {
        if (response == null)
        {
            throw new ArgumentNullException(nameof(response));
        }
        if (retryAction == null)
        {
            throw new ArgumentNullException(nameof(retryAction));
        }
        
        if (response.StatusCode == HttpStatusCode.TooManyRequests)
        {
            // Получаем Retry-After заголовок (в секундах)
            var retryAfter = response.Headers.RetryAfter?.Delta ?? TimeSpan.FromSeconds(60);
            
            Logger.LogWarning(
                "⚠️ Keycloak вернул 429 Too Many Requests. Ожидание {RetryAfter} секунд перед повторной попыткой",
                retryAfter.TotalSeconds);
            
            await Task.Delay(retryAfter, cancellationToken).ConfigureAwait(false);
            
            // Повторяем запрос
            var retryResponse = await retryAction().ConfigureAwait(false);
            
            // Проверка на null после повторного запроса
            if (retryResponse == null)
            {
                Logger.LogError("Retry action returned null response after rate limit retry");
                throw new InvalidOperationException("Retry action returned null response");
            }
            
            return retryResponse;
        }
        
        return response;
    }

    /// <summary>
    /// Получение admin token для Keycloak с thread-safe кэшированием и retry логикой
    /// </summary>
    protected async Task<string> GetAdminTokenAsync(CancellationToken cancellationToken = default)
    {
        // Double-checked locking для thread-safety (исправление проблемы #31)
        // Используем volatile read для CachedToken и Interlocked.Read для TokenExpiresAtTicks
        // Это гарантирует видимость изменений между потоками
        var currentTime = DateTime.UtcNow.Ticks;
        var cachedExpiresAt = Interlocked.Read(ref TokenExpiresAtTicks);
        var cachedToken = CachedToken; // Volatile read через volatile поле
        
        if (!string.IsNullOrEmpty(cachedToken) && currentTime < cachedExpiresAt)
        {
            // Токен из кэша - не логируем
            return cachedToken;
        }
        
        // Отладочное логирование - почему токен не из кэша
        if (string.IsNullOrEmpty(cachedToken))
        {
            Logger.LogDebug("Токен пустой, запрашиваем новый");
        }
        else
        {
            var timeLeft = TimeSpan.FromTicks(cachedExpiresAt - currentTime);
            Logger.LogDebug("Токен истек, осталось {TimeLeft}мс, запрашиваем новый", timeLeft.TotalMilliseconds);
        }
        
        var tokenLockAcquired = await SafeWaitTokenLock(cancellationToken).ConfigureAwait(false);
        if (!tokenLockAcquired)
        {
            throw new InvalidOperationException("Cannot acquire token lock, HttpClient disposed");
        }
        
        try
        {
            // Проверяем еще раз после получения лока (double-checked locking)
            // Исправление проблемы #31: используем volatile read для CachedToken
            var currentTimeAfterLock = DateTime.UtcNow.Ticks;
            var cachedExpiresAtAfterLock = Interlocked.Read(ref TokenExpiresAtTicks);
            var cachedTokenAfterLock = CachedToken; // Volatile read
            
            if (!string.IsNullOrEmpty(cachedTokenAfterLock) && currentTimeAfterLock < cachedExpiresAtAfterLock)
            {
                // Токен из кэша - не логируем
                return cachedTokenAfterLock;
            }
            
            // Только здесь начинаем логирование - когда реально получаем новый токен
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            
            // Проверка на null для Settings перед использованием
            if (Settings == null)
            {
                ClearTokenCache();
                throw new InvalidOperationException("Settings cannot be null");
            }
            
            // Валидация настроек перед использованием
            if (string.IsNullOrWhiteSpace(Settings.Realm))
            {
                ClearTokenCache();
                throw new InvalidOperationException("Realm cannot be null or empty in settings");
            }
            if (Settings.Realm.Length > MaxRealmLength)
            {
                ClearTokenCache();
                throw new InvalidOperationException($"Realm length ({Settings.Realm.Length}) exceeds maximum allowed length ({MaxRealmLength})");
            }
            if (string.IsNullOrWhiteSpace(Settings.ClientId))
            {
                ClearTokenCache();
                throw new InvalidOperationException("ClientId cannot be null or empty in settings");
            }
            if (Settings.ClientId.Length > MaxClientIdLength)
            {
                ClearTokenCache();
                throw new InvalidOperationException($"ClientId length ({Settings.ClientId.Length}) exceeds maximum allowed length ({MaxClientIdLength})");
            }
            if (string.IsNullOrWhiteSpace(Settings.ClientSecret))
            {
                ClearTokenCache();
                throw new InvalidOperationException("ClientSecret cannot be null or empty in settings");
            }
            if (Settings.ClientSecret.Length > MaxClientSecretLength)
            {
                ClearTokenCache();
                throw new InvalidOperationException($"ClientSecret length ({Settings.ClientSecret.Length}) exceeds maximum allowed length ({MaxClientSecretLength})");
            }
            
            // Получаем токен с retry логикой (exponential backoff)
            return await GetTokenWithRetryAsync(cancellationToken).ConfigureAwait(false);
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            ClearTokenCache();
            Logger.LogError("Timeout при получении токена от Keycloak");
            throw;
        }
        catch (TaskCanceledException)
        {
            ClearTokenCache();
            Logger.LogWarning("Операция получения токена была отменена (TaskCanceledException)");
            throw;
        }
        catch (OperationCanceledException)
        {
            ClearTokenCache();
            Logger.LogWarning("Операция получения токена была отменена");
            throw;
        }
        catch (HttpRequestException)
        {
            // Очищаем кэш при ошибках HTTP запроса
            ClearTokenCache();
            throw;
        }
        catch (InvalidOperationException)
        {
            // Очищаем кэш при ошибках валидации
            ClearTokenCache();
            throw;
        }
        catch (Exception ex)
        {
            // Очищаем кэш при любых неожиданных ошибках
            ClearTokenCache();
            Logger.LogError(ex, "Неожиданная ошибка при получении токена от Keycloak");
            throw;
        }
        finally
        {
            try
            {
                if (!Disposed)
                {
                    TokenLock.Release();
                }
            }
            catch (ObjectDisposedException)
            {
                // Игнорируем, если объект уже disposed
            }
        }
    }
    
    /// <summary>
    /// Очищает кэш токена (используется при критических ошибках для предотвращения утечек памяти)
    /// </summary>
    private void ClearTokenCache()
    {
        CachedToken = null;
        Interlocked.Exchange(ref TokenExpiresAtTicks, DateTime.MinValue.Ticks);
    }
    
    /// <summary>
    /// Получение токена с retry логикой (exponential backoff)
    /// </summary>
    private async Task<string> GetTokenWithRetryAsync(CancellationToken cancellationToken)
    {
        Exception? lastException = null;
        
        for (int attempt = 1; attempt <= MaxTokenRetryAttempts; attempt++)
        {
            try
            {
                return await GetTokenSingleAttemptAsync(cancellationToken).ConfigureAwait(false);
            }
            catch (HttpRequestException ex) when (attempt < MaxTokenRetryAttempts)
            {
                // Retry только для временных ошибок (5xx или network errors)
                var statusCode = ex.Data.Contains("StatusCode") ? ex.Data["StatusCode"] : null;
                var isRetryable = statusCode == null || 
                    (statusCode is HttpStatusCode code && (int)code >= 500);
                
                if (!isRetryable)
                {
                    // Не retry для постоянных ошибок (4xx)
                    throw;
                }
                
                lastException = ex;
                
                // Exponential backoff: delay = baseDelay * 2^(attempt-1)
                var delayMs = Math.Min(BaseRetryDelayMs * (int)Math.Pow(2, attempt - 1), MaxRetryDelayMs);
                
                Logger.LogWarning(
                    "Ошибка получения токена (попытка {Attempt}/{MaxAttempts}). Повтор через {DelayMs}мс. Ошибка: {Error}",
                    attempt, MaxTokenRetryAttempts, delayMs, ex.Message);
                
                await Task.Delay(delayMs, cancellationToken).ConfigureAwait(false);
            }
            catch (TaskCanceledException) when (attempt < MaxTokenRetryAttempts)
            {
                // Retry для timeout ошибок
                lastException = new TimeoutException("Request timeout when getting token", new TaskCanceledException());
                
                var delayMs = Math.Min(BaseRetryDelayMs * (int)Math.Pow(2, attempt - 1), MaxRetryDelayMs);
                
                Logger.LogWarning(
                    "Timeout при получении токена (попытка {Attempt}/{MaxAttempts}). Повтор через {DelayMs}мс",
                    attempt, MaxTokenRetryAttempts, delayMs);
                
                await Task.Delay(delayMs, cancellationToken).ConfigureAwait(false);
            }
        }
        
        // Все попытки исчерпаны
        ClearTokenCache();
        if (lastException != null)
        {
            throw new HttpRequestException(
                $"Не удалось получить токен после {MaxTokenRetryAttempts} попыток", 
                lastException);
        }
        
        throw new HttpRequestException($"Не удалось получить токен после {MaxTokenRetryAttempts} попыток");
    }
    
    /// <summary>
    /// Одна попытка получения токена
    /// </summary>
    private async Task<string> GetTokenSingleAttemptAsync(CancellationToken cancellationToken)
    {
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        
        // Формируем token endpoint с учетом UseLegacyAuthPath и Realm из настроек
        // Для получения токена используем BaseUrl напрямую (не AdminApiBaseUrl)
        var authEndpoint = Settings!.UseLegacyAuthPath 
            ? $"/auth/realms/{Settings.Realm}/protocol/openid-connect/token"
            : $"/realms/{Settings.Realm}/protocol/openid-connect/token";
        
        // Оптимизация: используем уже очищенный BaseUrl из настроек (избегаем повторного TrimEnd)
        // Базовая очистка выполняется один раз при инициализации в BuildAdminApiBaseUrl
        // Но для формирования абсолютного URL нужно убрать слэш еще раз, если он есть
        var baseUrlForToken = Settings.BaseUrl.TrimEnd('/');
        var tokenFullUrl = $"{baseUrlForToken}{authEndpoint}";
        
        // Улучшенная проверка валидности tokenFullUrl с использованием Uri.TryCreate
        if (!Uri.TryCreate(tokenFullUrl, UriKind.Absolute, out var tokenUri))
        {
            throw new InvalidOperationException($"Invalid token URL format: {tokenFullUrl}");
        }
        
        // Проверка схемы
        if (tokenUri.Scheme != Uri.UriSchemeHttp && tokenUri.Scheme != Uri.UriSchemeHttps)
        {
            throw new InvalidOperationException($"Token URL must use http or https scheme, but was: {tokenUri.Scheme}");
        }
            
        // Используем массив вместо List для небольшого фиксированного количества элементов (оптимизация памяти)
        var tokenRequest = new[]
        {
            new KeyValuePair<string, string>(GrantType, GrantTypeClientCredentials),
            new KeyValuePair<string, string>(ClientId, Settings.ClientId),
            new KeyValuePair<string, string>(ClientSecret, Settings.ClientSecret)
        };
        
        using var formContent = new FormUrlEncodedContent(tokenRequest);
        // Используем абсолютный URL для получения токена (не зависит от BaseAddress)
        using var request = new HttpRequestMessage(HttpMethod.Post, tokenUri)
        {
            Content = formContent
        };
        
        // Временно убираем Authorization header если он есть
        request.Headers.Authorization = null;
        request.Content!.Headers.ContentType = new MediaTypeHeaderValue(ApplicationFormUrlEncoded);
        
        using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
        
        if (!response.IsSuccessStatusCode)
        {
            stopwatch.Stop();
            var errorContent = response.Content != null
                ? await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false)
                : string.Empty;
            Logger.LogError(
                "[KeycloakAdmin] ❌ ОШИБКА получения токена - {Time}мс | StatusCode={StatusCode} | StatusText={ReasonPhrase} | Response={ErrorContent} | BaseUrl={BaseUrl} | Realm={Realm} | ClientId={ClientId} | UseLegacyAuthPath={UseLegacyAuthPath}",
                stopwatch.ElapsedMilliseconds, 
                response.StatusCode, 
                response.ReasonPhrase ?? "Unknown",
                errorContent,
                Settings.BaseUrl,
                Settings.Realm,
                Settings.ClientId,
                Settings.UseLegacyAuthPath);
            
            // Сохраняем StatusCode в Data для проверки в retry логике
            var ex = new HttpRequestException($"Не удалось получить токен: {response.StatusCode} - {errorContent}");
            ex.Data["StatusCode"] = response.StatusCode;
            throw ex;
        }
            
        // Проверка на наличие контента перед десериализацией
        if (response.Content == null)
        {
            stopwatch.Stop();
            Logger.LogError("[KeycloakAdmin] ❌ ОШИБКА получения токена - Response.Content is null | StatusCode={StatusCode} | BaseUrl={BaseUrl} | Realm={Realm}",
                response.StatusCode, Settings!.BaseUrl, Settings.Realm);
            throw new InvalidOperationException("Response content is null when trying to deserialize token response");
        }
        
        JsonElement tokenResponse;
        try
        {
            tokenResponse = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken).ConfigureAwait(false);
        }
        catch (JsonException ex)
        {
            stopwatch.Stop();
            // Проверка на null перед чтением контента
            string errorContent;
            if (response.Content == null)
            {
                errorContent = "Response content is null";
            }
            else
            {
                errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                // Проверка на пустой контент
                if (string.IsNullOrWhiteSpace(errorContent))
                {
                    errorContent = "Empty or null response content";
                }
            }
            Logger.LogError(ex, 
                "[KeycloakAdmin] ❌ ОШИБКА десериализации JSON при получении токена - {Time}мс | Response={ErrorContent} | BaseUrl={BaseUrl} | Realm={Realm}",
                stopwatch.ElapsedMilliseconds,
                errorContent?.Length > MaxContentLengthForLogging ? errorContent.Substring(0, MaxContentLengthForLogging) + "..." : errorContent,
                Settings!.BaseUrl,
                Settings.Realm);
            throw new InvalidOperationException($"Не удалось десериализовать ответ от Keycloak: {ex.Message}", ex);
        }
        
        // Проверка наличия access_token с использованием TryGetProperty для безопасности (оптимизация: один вызов TryGetProperty)
        if (!tokenResponse.TryGetProperty(AccessTokenProperty, out var accessTokenProperty) || 
            string.IsNullOrEmpty(accessTokenProperty.GetString()))
        {
            throw new InvalidOperationException($"Property '{AccessTokenProperty}' not found or empty in Keycloak token response");
        }
        
        var newToken = accessTokenProperty.GetString()!;
        
        // Финальная проверка на пустой токен перед присваиванием
        if (string.IsNullOrEmpty(newToken))
        {
            throw new InvalidOperationException($"Token value is null or empty after extraction from '{AccessTokenProperty}' property");
        }
        
        CachedToken = newToken;
        
        // Проверка наличия expires_in с использованием TryGetProperty для безопасности (оптимизация: один вызов TryGetProperty)
        int expiresIn;
        if (!tokenResponse.TryGetProperty(ExpiresInProperty, out var expiresInProperty) || 
            !expiresInProperty.TryGetInt32(out expiresIn))
        {
            Logger.LogWarning("Свойство '{ExpiresInProperty}' не найдено в ответе Keycloak, используется значение по умолчанию {DefaultExpiration} секунд",
                ExpiresInProperty, DefaultTokenExpirationSeconds);
            expiresIn = DefaultTokenExpirationSeconds;
        }
        
        // Оставляем запас в 10 секунд или 10% от времени жизни токена, но не меньше 5 секунд
        var bufferSeconds = Math.Max(5, Math.Min(10, expiresIn / 10));
        var expiresAt = DateTime.UtcNow.AddSeconds(expiresIn - bufferSeconds);
        Interlocked.Exchange(ref TokenExpiresAtTicks, expiresAt.Ticks);
        
        stopwatch.Stop();
        RecordRequestTime(stopwatch.ElapsedMilliseconds);
        
        // Финальная проверка перед возвратом токена (защита от race condition)
        if (string.IsNullOrEmpty(CachedToken))
        {
            Logger.LogError("[KeycloakAdmin] ❌ КРИТИЧЕСКАЯ ОШИБКА: CachedToken стал пустым после получения токена");
            throw new InvalidOperationException("CachedToken is null or empty after token retrieval - this should never happen");
        }
        
        return CachedToken;
    }
    
    /// <summary>
    /// Создать HTTP запрос с авторизацией
    /// </summary>
    /// <remarks>
    /// ВАЖНО: Вызывающий код должен обернуть возвращаемый HttpRequestMessage в using для правильного освобождения ресурсов.
    /// </remarks>
    protected async Task<HttpRequestMessage> CreateAuthorizedRequestAsync(
        HttpMethod method,
        string endpoint,
        CancellationToken cancellationToken = default)
    {
        if (method == null)
        {
            throw new ArgumentNullException(nameof(method));
        }
        if (string.IsNullOrWhiteSpace(endpoint))
        {
            throw new ArgumentException("Endpoint cannot be null or empty", nameof(endpoint));
        }
        if (endpoint.Length > MaxEndpointLength)
        {
            throw new ArgumentException($"Endpoint length ({endpoint.Length}) exceeds maximum allowed length ({MaxEndpointLength})", nameof(endpoint));
        }
        
        var token = await GetAdminTokenAsync(cancellationToken).ConfigureAwait(false);
        var request = new HttpRequestMessage(method, endpoint);
        request.Headers.Authorization = new AuthenticationHeaderValue(BearerScheme, token);
        
        // Проверка размера запроса (исправление проблемы #34)
        if (request.Content != null && request.Content.Headers.ContentLength.HasValue)
        {
            var contentLength = request.Content.Headers.ContentLength.Value;
            if (contentLength > MaxRequestSizeBytes)
            {
                throw new ArgumentException($"Request content size ({contentLength} bytes) exceeds maximum allowed size ({MaxRequestSizeBytes} bytes)", nameof(request));
            }
        }
        
        return request;
    }

    public virtual void Dispose()
    {
        // Защита от повторного вызова Dispose
        if (Disposed)
            return;
            
        Disposed = true;
        
        // Освобождаем семафоры для управления конкурентным доступом
        try
        {
            Semaphore?.Dispose();
        }
        catch (ObjectDisposedException)
        {
            // Игнорируем, если уже освобожден
        }
        catch (Exception)
        {
            // Игнорируем другие ошибки при dispose
        }
        
        try
        {
            TokenLock?.Dispose();
        }
        catch (ObjectDisposedException)
        {
            // Игнорируем, если уже освобожден
        }
        catch (Exception)
        {
            // Игнорируем другие ошибки при dispose
        }
        
        // ВАЖНО: НЕ освобождаем HttpClient здесь!
        // HttpClient управляется IHttpClientFactory или другим внешним механизмом.
        // HttpClient, созданные через IHttpClientFactory.CreateClient(), автоматически управляются фабрикой
        // и НЕ должны быть освобождены вручную. Фабрика сама управляет их жизненным циклом,
        // переиспользует соединения и правильно освобождает ресурсы.
        
        // Очищаем кэшированный токен
        CachedToken = null;
        TokenExpiresAtTicks = DateTime.MinValue.Ticks;
    }
    
    /// <summary>
    /// Унифицированный метод для выполнения операций с обработкой ошибок (исправление проблемы #26, #13)
    /// Устраняет дублирование кода обработки исключений во всех специализированных клиентах
    /// </summary>
    /// <typeparam name="TResult">Тип результата операции</typeparam>
    /// <param name="operation">Операция для выполнения</param>
    /// <param name="operationName">Название операции для логирования</param>
    /// <param name="defaultValue">Значение по умолчанию при ошибке (если strategy не ThrowException)</param>
    /// <param name="strategy">Стратегия обработки ошибок</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Результат операции или значение по умолчанию</returns>
    protected async Task<TResult> ExecuteWithErrorHandlingAsync<TResult>(
        Func<CancellationToken, Task<TResult>> operation,
        string operationName,
        TResult defaultValue,
        ErrorHandlingStrategy strategy = ErrorHandlingStrategy.ReturnEmpty,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation: {Operation}", operationName);
            RecordError(operationName, "SemaphoreDisposed");
            return strategy == ErrorHandlingStrategy.ThrowException 
                ? throw new ObjectDisposedException(nameof(KeycloakHttpClientBase))
                : defaultValue;
        }
        
        try
        {
            var result = await operation(cancellationToken).ConfigureAwait(false);
            RecordSuccess(operationName);
            return result;
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при операции {Operation}", operationName);
            RecordError(operationName, "Timeout");
            if (strategy == ErrorHandlingStrategy.ThrowException)
            {
                throw new TimeoutException($"Timeout при {operationName}", ex.InnerException);
            }
            return defaultValue;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция {Operation} была отменена (TaskCanceledException)", operationName);
            RecordError(operationName, "TaskCanceled");
            if (strategy == ErrorHandlingStrategy.ThrowException)
            {
                throw new OperationCanceledException("Операция была отменена", cancellationToken);
            }
            return defaultValue;
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning("Операция {Operation} была отменена", operationName);
            RecordError(operationName, "OperationCanceled");
            throw; // Всегда пробрасываем OperationCanceledException
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, "HTTP ошибка при операции {Operation}", operationName);
            RecordError(operationName, "HttpRequestException");
            if (strategy == ErrorHandlingStrategy.ThrowException)
            {
                throw;
            }
            return defaultValue;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при операции {Operation}", operationName);
            RecordError(operationName, "UnexpectedException");
            if (strategy == ErrorHandlingStrategy.ThrowException)
            {
                throw;
            }
            return defaultValue;
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
}

