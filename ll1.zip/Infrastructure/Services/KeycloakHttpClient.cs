using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading;
using new_assistant.Configuration;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;
using new_assistant.Infrastructure.Services.Keycloak;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// HTTP клиент для работы с Keycloak Admin API
/// Использует специализированные клиенты для разделения ответственности
/// </summary>
public class KeycloakHttpClient : IDisposable, IAsyncDisposable
{
    private readonly KeycloakAdminSettings _settings;
    private readonly ILogger<KeycloakHttpClient> _logger;
    private readonly IKeycloakCacheService _cacheService;
    private readonly IPerformanceMetricsService _metricsService;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILoggerFactory _loggerFactory;
    private int _disposed; // 0 = не освобожден, 1 = освобожден (используется для потокобезопасности через Interlocked)
    
    /// <summary>
    /// JsonSerializerOptions для legacy методов (Obsolete)
    /// Используется только для обратной совместимости в методах, помеченных [Obsolete]
    /// и будет удален вместе с этими методами в версии 2.0
    /// Используем JsonSerializerOptions из базового класса (исправление проблемы #6)
    /// </summary>
    private static JsonSerializerOptions LegacyJsonOptions => KeycloakHttpClientBase.DefaultJsonSerializerOptions;
    
    // Специализированные клиенты
    private readonly KeycloakRealmsClient _realmsClient;
    private readonly KeycloakClientsClient _clientsClient;
    private readonly KeycloakClientSecretsClient _clientSecretsClient;
    private readonly KeycloakRolesClient _rolesClient;
    private readonly KeycloakUsersClient _usersClient;
    private readonly KeycloakEventsClient _eventsClient;
    private readonly KeycloakTokensClient _tokensClient;
    
    /// <summary>
    /// [Obsolete] Получить статистику производительности Keycloak
    /// </summary>
    /// <remarks>
    /// ⚠️ Этот метод устарел и всегда возвращает нулевые значения. Используйте <see cref="IPerformanceMetricsService.GetMetrics()"/> вместо этого метода.
    /// Метод будет удален в версии 2.0.
    /// </remarks>
    [Obsolete("Используйте IPerformanceMetricsService.GetMetrics() вместо этого метода. Метод будет удален в версии 2.0.", false)]
    public static (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetPerformanceStats()
    {
        // Обратная совместимость - для старых вызовов
        // В будущих версиях этот метод будет удален
        return (0, 0, 0);
    }
    
    /// <summary>
    /// [Obsolete] Сбросить статистику производительности
    /// </summary>
    /// <remarks>
    /// ⚠️ Этот метод устарел и не выполняет никаких действий. Используйте <see cref="IPerformanceMetricsService.Reset()"/> вместо этого метода.
    /// Метод будет удален в версии 2.0.
    /// </remarks>
    [Obsolete("Используйте IPerformanceMetricsService.Reset() вместо этого метода. Метод будет удален в версии 2.0.", false)]
    public static void ResetPerformanceStats()
    {
        // Обратная совместимость - для старых вызовов
        // В будущих версиях этот метод будет удален
    }
    

    public KeycloakHttpClient(
        KeycloakAdminSettings settings,
        ILogger<KeycloakHttpClient> logger,
        IKeycloakCacheService cacheService,
        IPerformanceMetricsService metricsService,
        IHttpClientFactory httpClientFactory,
        ILoggerFactory loggerFactory)
    {
        _settings = settings ?? throw new ArgumentNullException(nameof(settings));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _cacheService = cacheService ?? throw new ArgumentNullException(nameof(cacheService));
        _metricsService = metricsService ?? throw new ArgumentNullException(nameof(metricsService));
        _httpClientFactory = httpClientFactory ?? throw new ArgumentNullException(nameof(httpClientFactory));
        _loggerFactory = loggerFactory ?? throw new ArgumentNullException(nameof(loggerFactory));
        
        // Инициализируем специализированные клиенты
        // Используем IHttpClientFactory для создания HttpClient - это правильно управляет жизненным циклом
        // Все специализированные клиенты используют один именованный клиент "KeycloakAdmin"
        // IHttpClientFactory управляет пулом соединений и переиспользованием HttpClient
        
        try
        {
            // Создаем один общий HttpClient через IHttpClientFactory
            // Именованный клиент "KeycloakAdmin" уже настроен в ServiceCollectionExtensions
            // Важно: НЕ нужно освобождать HttpClient созданные через IHttpClientFactory - это делает фабрика
            // Используем один экземпляр HttpClient для всех специализированных клиентов,
            // так как HttpClient потокобезопасен и может использоваться одновременно несколькими клиентами
            var sharedHttpClient = _httpClientFactory.CreateClient("KeycloakAdmin");
            
            // Используем ILoggerFactory для всех клиентов для консистентности
            _realmsClient = new KeycloakRealmsClient(
                sharedHttpClient, settings, loggerFactory.CreateLogger<KeycloakRealmsClient>(), cacheService, metricsService);
            _clientsClient = new KeycloakClientsClient(
                sharedHttpClient, settings, loggerFactory.CreateLogger<KeycloakClientsClient>(), cacheService, metricsService);
            _clientSecretsClient = new KeycloakClientSecretsClient(
                sharedHttpClient, settings, loggerFactory.CreateLogger<KeycloakClientSecretsClient>(), cacheService, metricsService);
            
            // Создаем специализированные клиенты для KeycloakRolesClient с правильной последовательностью зависимостей
            var clientRolesClient = new KeycloakClientRolesClient(
                sharedHttpClient, settings, loggerFactory.CreateLogger<KeycloakClientRolesClient>(), cacheService, metricsService);
            var realmRolesClient = new KeycloakRealmRolesClient(
                sharedHttpClient, settings, loggerFactory.CreateLogger<KeycloakRealmRolesClient>(), cacheService, metricsService);
            var roleMappingClient = new KeycloakRoleMappingClient(
                sharedHttpClient, settings, loggerFactory.CreateLogger<KeycloakRoleMappingClient>(), cacheService, metricsService, realmRolesClient);
            var batchOperationsClient = new KeycloakRoleBatchOperationsClient(
                sharedHttpClient, settings, loggerFactory.CreateLogger<KeycloakRoleBatchOperationsClient>(), cacheService, metricsService, realmRolesClient, roleMappingClient);
            
            // Теперь создаем KeycloakRolesClient с внедренными зависимостями
            _rolesClient = new KeycloakRolesClient(
                sharedHttpClient, settings, loggerFactory.CreateLogger<KeycloakRolesClient>(), cacheService, metricsService,
                clientRolesClient, realmRolesClient, roleMappingClient, batchOperationsClient);
            
            _usersClient = new KeycloakUsersClient(
                sharedHttpClient, settings, loggerFactory.CreateLogger<KeycloakUsersClient>(), cacheService, metricsService);
            _eventsClient = new KeycloakEventsClient(
                sharedHttpClient, settings, loggerFactory.CreateLogger<KeycloakEventsClient>(), cacheService, metricsService);
            _tokensClient = new KeycloakTokensClient(
                sharedHttpClient, settings, loggerFactory.CreateLogger<KeycloakTokensClient>(), cacheService, metricsService);
        }
        catch (Exception ex)
        {
            // Логируем ошибку инициализации
            logger.LogError(ex, "Ошибка при инициализации KeycloakHttpClient");
            
            // Освобождаем только успешно созданные клиенты
            var clientsToDispose = new List<IDisposable>();
            if (_realmsClient != null) clientsToDispose.Add(_realmsClient);
            if (_clientsClient != null) clientsToDispose.Add(_clientsClient);
            if (_clientSecretsClient != null) clientsToDispose.Add(_clientSecretsClient);
            if (_rolesClient != null) clientsToDispose.Add(_rolesClient);
            if (_usersClient != null) clientsToDispose.Add(_usersClient);
            if (_eventsClient != null) clientsToDispose.Add(_eventsClient);
            if (_tokensClient != null) clientsToDispose.Add(_tokensClient);
            
            foreach (var client in clientsToDispose)
            {
                try
                {
                    client.Dispose();
                }
                catch (ObjectDisposedException)
                {
                    // Игнорируем, если уже освобожден
                }
                catch (Exception disposeEx)
                {
                    // Логируем ошибки при dispose, но продолжаем освобождение остальных
                    logger.LogWarning(disposeEx, "Ошибка при освобождении клиента {ClientType}", client.GetType().Name);
                }
            }
            
            // HttpClient создан через фабрику, не нужно освобождать вручную
            // Фабрика управляет жизненным циклом автоматически
            
            throw;
        }
    }


    /// <summary>
    /// Поиск клиентов в конкретном реалме
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="searchTerm">Термин для поиска</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список найденных клиентов</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ArgumentNullException">Выбрасывается если searchTerm равен null</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public async Task<List<ClientSearchResult>> SearchClientsInRealmAsync(
        string realm, 
        string searchTerm, 
        CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateSearchTerm(searchTerm);
        
        return await _clientsClient.SearchClientsInRealmAsync(realm, searchTerm, cancellationToken)
            .ConfigureAwait(false);
    }

    /// <summary>
    /// Получение списка реалмов (с кэшированием)
    /// </summary>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список названий реалмов</returns>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// Результат кэшируется для улучшения производительности.
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public Task<List<string>> GetRealmsListAsync(CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        return _realmsClient.GetRealmsListAsync(cancellationToken);
    }
    
    /// <summary>
    /// Получить детальную информацию о всех реалмах (с Display Name)
    /// </summary>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список реалмов с детальной информацией</returns>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public Task<List<RealmDto>> GetRealmsWithDetailsAsync(CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        return _realmsClient.GetRealmsWithDetailsAsync(cancellationToken);
    }

    /// <summary>
    /// Создать нового клиента в Keycloak
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientData">Данные клиента в формате JsonElement</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Внутренний ID созданного клиента (UUID)</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public async Task<string> CreateClientAsync(string realm, JsonElement clientData, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        if (clientData.ValueKind == JsonValueKind.Null)
            throw new ArgumentException("Client data cannot be null", nameof(clientData));
        
        // Проверка типа JsonElement
        if (clientData.ValueKind != JsonValueKind.Object)
            throw new ArgumentException($"Client data must be a JSON object, but got {clientData.ValueKind}", nameof(clientData));
        
        // Проверка обязательных полей
        if (!clientData.TryGetProperty("clientId", out var clientIdProperty) || 
            clientIdProperty.ValueKind == JsonValueKind.Null || 
            string.IsNullOrWhiteSpace(clientIdProperty.GetString()))
        {
            throw new ArgumentException("Client data must contain a valid 'clientId' field", nameof(clientData));
        }
        
        // Валидация clientId через валидатор после извлечения
        var clientId = clientIdProperty.GetString()!;
        KeycloakParameterValidator.ValidateClientId(clientId);
        
        return await _clientsClient.CreateClientAsync(realm, clientData, cancellationToken)
            .ConfigureAwait(false);
    }

    /// <summary>
    /// Получение полной информации о клиенте по clientId
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientId">Client ID клиента</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Полная информация о клиенте в формате JsonElement, или null если клиент не найден</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public Task<JsonElement?> GetClientFullInfoAsync(string realm, string clientId, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientId(clientId);
        
        return _clientsClient.GetClientFullInfoAsync(realm, clientId, cancellationToken);
    }

    /// <summary>
    /// Получение client secret
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Client secret в виде строки, или null если secret не найден</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// <para>⚠️ ВАЖНО: Этот метод возвращает чувствительные данные (client secret). Убедитесь, что:</para>
    /// <para>- Secret не логируется в логи приложения</para>
    /// <para>- Secret не передается в URL или query параметрах</para>
    /// <para>- Secret правильно обрабатывается в памяти (избегайте задержек в памяти)</para>
    /// <para>При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение. Ошибки логируются без деталей secret.</para>
    /// </remarks>
    public Task<string?> GetClientSecretAsync(string realm, string clientInternalId, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientInternalId(clientInternalId);
        
        return _clientSecretsClient.GetClientSecretAsync(realm, clientInternalId, cancellationToken);
    }

    /// <summary>
    /// Регенерация client secret
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Новый client secret в виде строки</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// <para>⚠️ ВАЖНО: Этот метод возвращает чувствительные данные (новый client secret). Убедитесь, что:</para>
    /// <para>- Secret не логируется в логи приложения</para>
    /// <para>- Secret не передается в URL или query параметрах</para>
    /// <para>- Secret правильно обрабатывается в памяти (избегайте задержек в памяти)</para>
    /// <para>- Старый secret становится недействительным после регенерации</para>
    /// <para>При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение. Ошибки логируются без деталей secret.</para>
    /// </remarks>
    public Task<string?> RegenerateClientSecretAsync(string realm, string clientInternalId, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientInternalId(clientInternalId);
        
        return _clientSecretsClient.RegenerateClientSecretAsync(realm, clientInternalId, cancellationToken);
    }
    
    /// <summary>
    /// Получение ролей клиента
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список ролей клиента</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// <para>Поведение при ошибках зависит от реализации специализированного клиента <see cref="KeycloakRolesClient.GetClientRolesAsync"/>.</para>
    /// <para>При ошибке выполнения запроса к Keycloak API метод может возвращать пустой список или выбрасывать исключение в зависимости от стратегии обработки ошибок специализированного клиента.</para>
    /// </remarks>
    public Task<List<KeycloakRoleDto>> GetClientRolesAsync(string realm, string clientInternalId, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientInternalId(clientInternalId);
        
        return _rolesClient.GetClientRolesAsync(realm, clientInternalId, cancellationToken);
    }
    
    /// <summary>
    /// [Obsolete] Получение ролей клиента (legacy версия с JsonElement)
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список ролей клиента в формате JsonElement. Возвращает пустой список при ошибке.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// ⚠️ Этот метод устарел. Используйте <see cref="GetClientRolesAsync"/> для получения типизированных моделей.
    /// Метод будет удален в версии 2.0.
    /// </remarks>
    [Obsolete("Используйте GetClientRolesAsync с типизированными моделями KeycloakRoleDto. Метод будет удален в версии 2.0.", false)]
    public async Task<List<JsonElement>> GetClientRolesAsyncLegacy(string realm, string clientInternalId, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientInternalId(clientInternalId);
        
        var roles = await GetClientRolesAsync(realm, clientInternalId, cancellationToken)
            .ConfigureAwait(false);
        return roles.Select(r => JsonSerializer.SerializeToElement(r, LegacyJsonOptions))
            .ToList();
    }
    
    /// <summary>
    /// Получение client scopes клиента (default или optional)
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="isDefault">Если true, возвращает default scopes, иначе optional scopes</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список названий client scopes</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public Task<List<string>> GetClientScopesAsync(string realm, string clientInternalId, bool isDefault, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientInternalId(clientInternalId);
        
        return _rolesClient.GetClientScopesAsync(realm, clientInternalId, isDefault, cancellationToken);
    }
    
    /// <summary>
    /// Получение событий из реалма
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список событий реалма в формате JsonElement</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public Task<IReadOnlyList<JsonElement>> GetRealmEventsAsync(string realm, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        
        return _eventsClient.GetRealmEventsAsync(realm, cancellationToken);
    }

    /// <summary>
    /// Получение событий из реалма с указанием количества и опциональным фильтром по clientId
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="maxEvents">Максимальное количество событий для возврата</param>
    /// <param name="clientId">Опциональный фильтр по Client ID. Если null, возвращаются события всех клиентов.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список событий реалма в формате JsonElement</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public Task<IReadOnlyList<JsonElement>> GetRealmEventsWithLimitAsync(string realm, int maxEvents, string? clientId = null, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        if (maxEvents < 0)
            throw new ArgumentException("Max events cannot be negative", nameof(maxEvents));
        if (maxEvents > KeycloakParameterValidator.MaxEventsLimit)
            throw new ArgumentException(
                $"Max events ({maxEvents}) exceeds maximum allowed limit ({KeycloakParameterValidator.MaxEventsLimit})", 
                nameof(maxEvents));
        
        // Валидация clientId, если он не null
        if (clientId != null)
            KeycloakParameterValidator.ValidateClientId(clientId);
        
        return _eventsClient.GetRealmEventsAsync(realm, maxEvents, clientId, cancellationToken);
    }
    
    /// <summary>
    /// Получение событий из реалма с пагинацией (first и max) и опциональным фильтром по clientId
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="first">Индекс первого события для возврата (для пагинации)</param>
    /// <param name="maxEvents">Максимальное количество событий для возврата</param>
    /// <param name="clientId">Опциональный фильтр по Client ID. Если null, возвращаются события всех клиентов.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список событий реалма в формате JsonElement</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public Task<IReadOnlyList<JsonElement>> GetRealmEventsWithPaginationAsync(string realm, int first, int maxEvents, string? clientId = null, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        if (first < 0)
            throw new ArgumentException("First cannot be negative", nameof(first));
        if (maxEvents < 0)
            throw new ArgumentException("Max events cannot be negative", nameof(maxEvents));
        if (maxEvents > KeycloakParameterValidator.MaxEventsLimit)
            throw new ArgumentException(
                $"Max events ({maxEvents}) exceeds maximum allowed limit ({KeycloakParameterValidator.MaxEventsLimit})", 
                nameof(maxEvents));
        
        // Валидация clientId, если он не null
        if (clientId != null)
            KeycloakParameterValidator.ValidateClientId(clientId);
        
        return _eventsClient.GetRealmEventsAsync(realm, first, maxEvents, clientId, cancellationToken);
    }
    
    /// <summary>
    /// Получение service account пользователя для клиента
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>ID пользователя service account, или null если service account не включен для клиента</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public Task<string?> GetServiceAccountUserIdAsync(string realm, string clientInternalId, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientInternalId(clientInternalId);
        
        return _rolesClient.GetServiceAccountUserIdAsync(realm, clientInternalId, cancellationToken);
    }
    
    /// <summary>
    /// Получить доступные роли для назначения пользователю через ui-ext эндпоинт (оптимизированный метод)
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя (UUID)</param>
    /// <param name="searchTerm">Термин для поиска ролей (по умолчанию пустая строка - возвращает все роли). Используется для фильтрации результатов по имени роли.</param>
    /// <param name="first">Индекс первой роли для возврата (для пагинации, по умолчанию 0). Должен быть неотрицательным.</param>
    /// <param name="max">Максимальное количество ролей для возврата (по умолчанию 101). Должен быть неотрицательным.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список доступных ролей для назначения пользователю. Возвращает роли, которые еще не назначены пользователю.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах (отрицательные first или max)</exception>
    /// <exception cref="ArgumentNullException">Выбрасывается если searchTerm равен null</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// <para>Метод использует оптимизированный ui-ext эндпоинт Keycloak для получения доступных ролей.</para>
    /// <para>Для получения уже назначенных ролей используйте <see cref="GetUserRoleMappingsAsync"/>.</para>
    /// <para>При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.</para>
    /// </remarks>
    public async Task<List<KeycloakRoleDto>> GetAvailableRolesForUserAsync(
        string realm, 
        string userId, 
        string searchTerm = "", 
        int first = 0, 
        int max = 101, 
        CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUserId(userId);
        if (searchTerm == null)
            throw new ArgumentNullException(nameof(searchTerm));
        if (first < 0)
            throw new ArgumentException("First cannot be negative", nameof(first));
        if (max < 0)
            throw new ArgumentException("Max cannot be negative", nameof(max));
        
        return await _rolesClient.GetAvailableRolesForUserAsync(realm, userId, searchTerm, first, max, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// [Obsolete] Получить доступные роли для назначения пользователю (legacy версия с JsonElement)
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="searchTerm">Термин для поиска ролей (по умолчанию пустая строка - все роли)</param>
    /// <param name="first">Индекс первой роли для возврата (для пагинации, по умолчанию 0)</param>
    /// <param name="max">Максимальное количество ролей для возврата (по умолчанию 101)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список доступных ролей в формате JsonElement</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ArgumentNullException">Выбрасывается если searchTerm равен null</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// ⚠️ Этот метод устарел. Используйте <see cref="GetAvailableRolesForUserAsync"/> для получения типизированных моделей.
    /// Метод будет удален в версии 2.0.
    /// </remarks>
    [Obsolete("Используйте GetAvailableRolesForUserAsync с типизированными моделями KeycloakRoleDto. Метод будет удален в версии 2.0.", false)]
    public async Task<List<JsonElement>> GetAvailableRolesForUserAsyncLegacy(
        string realm, 
        string userId, 
        string searchTerm = "", 
        int first = 0, 
        int max = 101, 
        CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUserId(userId);
        if (searchTerm == null)
            throw new ArgumentNullException(nameof(searchTerm));
        if (first < 0)
            throw new ArgumentException("First cannot be negative", nameof(first));
        if (max < 0)
            throw new ArgumentException("Max cannot be negative", nameof(max));
        
        var roles = await GetAvailableRolesForUserAsync(realm, userId, searchTerm, first, max, cancellationToken)
            .ConfigureAwait(false);
        return roles.Select(r => JsonSerializer.SerializeToElement(r, LegacyJsonOptions))
            .ToList();
    }
    
    /// <summary>
    /// Получение role mappings для пользователя
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список ролей, назначенных пользователю (realm и client роли)</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public Task<List<KeycloakClientRoleDto>> GetUserRoleMappingsAsync(string realm, string userId, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUserId(userId);
        
        return _rolesClient.GetUserRoleMappingsAsync(realm, userId, cancellationToken);
    }
    
    /// <summary>
    /// [Obsolete] Получение role mappings для пользователя (legacy версия с JsonElement)
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список ролей, назначенных пользователю, в формате JsonElement</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// ⚠️ Этот метод устарел. Используйте <see cref="GetUserRoleMappingsAsync"/> для получения типизированных моделей.
    /// Метод будет удален в версии 2.0.
    /// </remarks>
    [Obsolete("Используйте GetUserRoleMappingsAsync с типизированными моделями KeycloakClientRoleDto. Метод будет удален в версии 2.0.", false)]
    public async Task<List<JsonElement>> GetUserRoleMappingsAsyncLegacy(string realm, string userId, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUserId(userId);
        
        var roles = await GetUserRoleMappingsAsync(realm, userId, cancellationToken)
            .ConfigureAwait(false);
        return roles.Select(r => JsonSerializer.SerializeToElement(r, LegacyJsonOptions))
            .ToList();
    }
    
    /// <summary>
    /// Поиск пользователей по username в конкретном реалме
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="username">Username для поиска</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список найденных пользователей</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public async Task<List<UserSearchResultDto>> SearchUsersByUsernameAsync(string realm, string username, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUsername(username);
        
        var result = await _usersClient.SearchUsersByUsernameAsync(realm, username, cancellationToken).ConfigureAwait(false);
        // Конвертируем IReadOnlyList в List для обратной совместимости
        return result is List<UserSearchResultDto> list ? list : result.ToList();
    }
    
    /// <summary>
    /// Генерация example access token для пользователя
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="scope">Опциональный scope для токена. Если null, используется scope по умолчанию.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Access token в виде строки</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// <para>⚠️ ВАЖНО: Этот метод возвращает чувствительные данные (access token). Убедитесь, что:</para>
    /// <para>- Token не логируется в логи приложения</para>
    /// <para>- Token не передается в URL или query параметрах</para>
    /// <para>- Token правильно обрабатывается в памяти</para>
    /// <para>При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.</para>
    /// </remarks>
    public async Task<string> GenerateExampleAccessTokenAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientInternalId(clientInternalId);
        KeycloakParameterValidator.ValidateUserId(userId);
        KeycloakParameterValidator.ValidateScope(scope);
        
        return await _tokensClient.GenerateExampleAccessTokenAsync(realm, clientInternalId, userId, scope, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// Генерация example ID token для пользователя
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="scope">Опциональный scope для токена. Если null, используется scope по умолчанию.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>ID token в виде строки</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// <para>⚠️ ВАЖНО: Этот метод возвращает чувствительные данные (ID token). Убедитесь, что:</para>
    /// <para>- Token не логируется в логи приложения</para>
    /// <para>- Token не передается в URL или query параметрах</para>
    /// <para>- Token правильно обрабатывается в памяти</para>
    /// <para>При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.</para>
    /// </remarks>
    public async Task<string> GenerateExampleIdTokenAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientInternalId(clientInternalId);
        KeycloakParameterValidator.ValidateUserId(userId);
        KeycloakParameterValidator.ValidateScope(scope);
        
        return await _tokensClient.GenerateExampleIdTokenAsync(realm, clientInternalId, userId, scope, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// Генерация example userinfo для пользователя
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="scope">Опциональный scope для токена. Если null, используется scope по умолчанию.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>UserInfo в виде JSON строки (может содержать персональные данные пользователя)</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// <para>⚠️ ВАЖНО: Этот метод возвращает данные пользователя (UserInfo). Убедитесь, что:</para>
    /// <para>- Данные не логируются в логи приложения без необходимости</para>
    /// <para>- Данные не передаются в URL или query параметрах</para>
    /// <para>- Данные правильно обрабатываются в соответствии с политикой конфиденциальности</para>
    /// <para>При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.</para>
    /// </remarks>
    public async Task<string> GenerateExampleUserInfoAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientInternalId(clientInternalId);
        KeycloakParameterValidator.ValidateUserId(userId);
        KeycloakParameterValidator.ValidateScope(scope);
        
        return await _tokensClient.GenerateExampleUserInfoAsync(realm, clientInternalId, userId, scope, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// Обновить клиента в Keycloak
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="internalId">Внутренний ID клиента (UUID)</param>
    /// <param name="clientData">Обновленные данные клиента</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ArgumentNullException">Выбрасывается если clientData равен null</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public async Task UpdateClientAsync(string realm, string internalId, object clientData, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientInternalId(internalId);
        if (clientData == null)
            throw new ArgumentNullException(nameof(clientData));
        
        await _clientsClient.UpdateClientAsync(realm, internalId, clientData, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// Удалить клиента из реалма
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="internalId">Внутренний ID клиента (UUID)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public async Task DeleteClientAsync(string realm, string internalId, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientInternalId(internalId);
        
        await _clientsClient.DeleteClientAsync(realm, internalId, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// Создать роль клиента
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="roleName">Название роли для создания</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public async Task CreateClientRoleAsync(string realm, string clientInternalId, string roleName, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientInternalId(clientInternalId);
        KeycloakParameterValidator.ValidateRoleName(roleName);
        
        await _rolesClient.CreateClientRoleAsync(realm, clientInternalId, roleName, description: null, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// Удалить роль клиента
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="roleName">Название роли для удаления</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public async Task DeleteClientRoleAsync(string realm, string clientInternalId, string roleName, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientInternalId(clientInternalId);
        KeycloakParameterValidator.ValidateRoleName(roleName);
        
        await _rolesClient.DeleteClientRoleAsync(realm, clientInternalId, roleName, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// Получить доступные realm роли для назначения пользователю
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список доступных realm ролей</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public Task<List<KeycloakRoleDto>> GetAvailableRealmRolesAsync(string realm, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        
        return _rolesClient.GetAvailableRealmRolesAsync(realm, cancellationToken);
    }
    
    /// <summary>
    /// [Obsolete] Получить доступные realm роли (legacy версия с JsonElement)
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список доступных realm ролей в формате JsonElement</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// ⚠️ Этот метод устарел. Используйте <see cref="GetAvailableRealmRolesAsync"/> для получения типизированных моделей.
    /// Метод будет удален в версии 2.0.
    /// </remarks>
    [Obsolete("Используйте GetAvailableRealmRolesAsync с типизированными моделями KeycloakRoleDto. Метод будет удален в версии 2.0.", false)]
    public async Task<List<JsonElement>> GetAvailableRealmRolesAsyncLegacy(string realm, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        
        var roles = await GetAvailableRealmRolesAsync(realm, cancellationToken)
            .ConfigureAwait(false);
        return roles.Select(r => JsonSerializer.SerializeToElement(r, LegacyJsonOptions))
            .ToList();
    }
    
    /// <summary>
    /// Назначить realm роль пользователю
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="roleName">Название realm роли для назначения</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public async Task AssignRealmRoleToUserAsync(string realm, string userId, string roleName, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUserId(userId);
        KeycloakParameterValidator.ValidateRoleName(roleName);
        
        await _rolesClient.AssignRealmRoleToUserAsync(realm, userId, roleName, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// Удалить любую роль у пользователя (realm или client role)
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="roleName">Название роли для удаления</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public async Task RemoveRoleFromUserAsync(string realm, string userId, string roleName, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUserId(userId);
        KeycloakParameterValidator.ValidateRoleName(roleName);
        
        await _rolesClient.RemoveRoleFromUserAsync(realm, userId, roleName, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// Назначает client роль пользователю
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="roleId">ID роли клиента</param>
    /// <param name="roleName">Название роли клиента</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public async Task AssignClientRoleToUserAsync(string realm, string userId, string clientInternalId, string roleId, string roleName, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUserId(userId);
        KeycloakParameterValidator.ValidateClientInternalId(clientInternalId);
        if (string.IsNullOrWhiteSpace(roleId))
            throw new ArgumentException("Role ID cannot be null or empty", nameof(roleId));
        // Валидация формата UUID для roleId
        KeycloakParameterValidator.ValidateClientInternalId(roleId, nameof(roleId));
        KeycloakParameterValidator.ValidateRoleName(roleName);
        
        await _rolesClient.AssignClientRoleToUserAsync(realm, userId, clientInternalId, roleId, roleName, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// Удаляет client роль у пользователя
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="roleId">ID роли клиента</param>
    /// <param name="roleName">Название роли клиента</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public async Task RemoveClientRoleFromUserAsync(string realm, string userId, string clientInternalId, string roleId, string roleName, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUserId(userId);
        KeycloakParameterValidator.ValidateClientInternalId(clientInternalId);
        if (string.IsNullOrWhiteSpace(roleId))
            throw new ArgumentException("Role ID cannot be null or empty", nameof(roleId));
        // Валидация формата UUID для roleId
        KeycloakParameterValidator.ValidateClientInternalId(roleId, nameof(roleId));
        KeycloakParameterValidator.ValidateRoleName(roleName);
        
        await _rolesClient.RemoveClientRoleFromUserAsync(realm, userId, clientInternalId, roleId, roleName, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// Назначить несколько realm ролей пользователю одним запросом (batch)
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя (UUID)</param>
    /// <param name="roleNames">Список названий realm ролей для назначения. Максимум <see cref="KeycloakParameterValidator.MaxBatchSize"/> элементов. Не может содержать null, пустые строки или дубликаты.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах, пустом списке ролей, превышении максимального размера (<see cref="KeycloakParameterValidator.MaxBatchSize"/>), наличии null/пустых строк или дубликатов в списке</exception>
    /// <exception cref="ArgumentNullException">Выбрасывается если roleNames равен null</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// <para>Этот метод выполняет batch операцию для назначения нескольких ролей одновременно, что более эффективно чем множественные вызовы <see cref="AssignRealmRoleToUserAsync"/>.</para>
    /// <para>При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.</para>
    /// <para>Роли должны существовать в указанном реалме перед вызовом этого метода.</para>
    /// </remarks>
    public async Task AssignMultipleRealmRolesToUserAsync(string realm, string userId, List<string> roleNames, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUserId(userId);
        if (roleNames == null)
            throw new ArgumentNullException(nameof(roleNames));
        if (roleNames.Count == 0)
            throw new ArgumentException("Role names list cannot be empty", nameof(roleNames));
        if (roleNames.Count > KeycloakParameterValidator.MaxBatchSize)
            throw new ArgumentException(
                $"Role names list cannot contain more than {KeycloakParameterValidator.MaxBatchSize} items, but was {roleNames.Count}", 
                nameof(roleNames));
        if (roleNames.Any(string.IsNullOrWhiteSpace))
            throw new ArgumentException("Role names cannot contain null or empty values", nameof(roleNames));
        
        // Проверка на дубликаты
        var distinctCount = roleNames.Distinct(StringComparer.Ordinal).Count();
        if (distinctCount != roleNames.Count)
            throw new ArgumentException($"Role names list contains duplicates. Total: {roleNames.Count}, Distinct: {distinctCount}", nameof(roleNames));
        
        await _rolesClient.AssignMultipleRealmRolesToUserAsync(realm, userId, roleNames, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// Назначить несколько client ролей пользователю одним запросом (batch)
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя (UUID)</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="roles">Список кортежей (roleId, roleName) для назначения. Максимум <see cref="KeycloakParameterValidator.MaxBatchSize"/> элементов. Не может содержать null, пустые строки или дубликаты roleId.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах, пустом списке ролей, превышении максимального размера (<see cref="KeycloakParameterValidator.MaxBatchSize"/>), наличии null/пустых строк или дубликатов roleId в списке</exception>
    /// <exception cref="ArgumentNullException">Выбрасывается если roles равен null</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// <para>Этот метод выполняет batch операцию для назначения нескольких client ролей одновременно, что более эффективно чем множественные вызовы <see cref="AssignClientRoleToUserAsync"/>.</para>
    /// <para>При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.</para>
    /// <para>Роли должны существовать для указанного клиента перед вызовом этого метода. Для получения списка ролей клиента используйте <see cref="GetClientRolesAsync"/>.</para>
    /// </remarks>
    public async Task AssignMultipleClientRolesToUserAsync(string realm, string userId, string clientInternalId, 
        List<(string roleId, string roleName)> roles, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUserId(userId);
        KeycloakParameterValidator.ValidateClientInternalId(clientInternalId);
        if (roles == null)
            throw new ArgumentNullException(nameof(roles));
        if (roles.Count == 0)
            throw new ArgumentException("Roles list cannot be empty", nameof(roles));
        if (roles.Count > KeycloakParameterValidator.MaxBatchSize)
            throw new ArgumentException(
                $"Roles list cannot contain more than {KeycloakParameterValidator.MaxBatchSize} items, but was {roles.Count}", 
                nameof(roles));
        if (roles.Any(r => string.IsNullOrWhiteSpace(r.roleId) || string.IsNullOrWhiteSpace(r.roleName)))
            throw new ArgumentException("Roles cannot contain null or empty role IDs or names", nameof(roles));
        
        // Проверка на дубликаты по roleId
        var distinctRoleIds = roles.Select(r => r.roleId).Distinct(StringComparer.Ordinal).Count();
        if (distinctRoleIds != roles.Count)
            throw new ArgumentException($"Roles list contains duplicate role IDs. Total: {roles.Count}, Distinct: {distinctRoleIds}", nameof(roles));
        
        await _rolesClient.AssignMultipleClientRolesToUserAsync(realm, userId, clientInternalId, roles, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// Удалить несколько client ролей у пользователя одним запросом (batch)
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="roles">Список кортежей (roleId, roleName) для удаления</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах или пустом списке ролей</exception>
    /// <exception cref="ArgumentNullException">Выбрасывается если roles равен null</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public async Task RemoveMultipleClientRolesFromUserAsync(string realm, string userId, string clientInternalId, 
        List<(string roleId, string roleName)> roles, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUserId(userId);
        KeycloakParameterValidator.ValidateClientInternalId(clientInternalId);
        if (roles == null)
            throw new ArgumentNullException(nameof(roles));
        if (roles.Count == 0)
            throw new ArgumentException("Roles list cannot be empty", nameof(roles));
        if (roles.Count > KeycloakParameterValidator.MaxBatchSize)
            throw new ArgumentException(
                $"Roles list cannot contain more than {KeycloakParameterValidator.MaxBatchSize} items, but was {roles.Count}", 
                nameof(roles));
        if (roles.Any(r => string.IsNullOrWhiteSpace(r.roleId) || string.IsNullOrWhiteSpace(r.roleName)))
            throw new ArgumentException("Roles cannot contain null or empty role IDs or names", nameof(roles));
        
        // Проверка на дубликаты по roleId
        var distinctRoleIds = roles.Select(r => r.roleId).Distinct(StringComparer.Ordinal).Count();
        if (distinctRoleIds != roles.Count)
            throw new ArgumentException($"Roles list contains duplicate role IDs. Total: {roles.Count}, Distinct: {distinctRoleIds}", nameof(roles));
        
        await _rolesClient.RemoveMultipleClientRolesFromUserAsync(realm, userId, clientInternalId, roles, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// Удалить несколько realm ролей у пользователя одним запросом (batch)
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="roleNames">Список названий realm ролей для удаления</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах или пустом списке ролей</exception>
    /// <exception cref="ArgumentNullException">Выбрасывается если roleNames равен null</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public async Task RemoveMultipleRealmRolesFromUserAsync(string realm, string userId, List<string> roleNames, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUserId(userId);
        if (roleNames == null)
            throw new ArgumentNullException(nameof(roleNames));
        if (roleNames.Count == 0)
            throw new ArgumentException("Role names list cannot be empty", nameof(roleNames));
        if (roleNames.Count > KeycloakParameterValidator.MaxBatchSize)
            throw new ArgumentException(
                $"Role names list cannot contain more than {KeycloakParameterValidator.MaxBatchSize} items, but was {roleNames.Count}", 
                nameof(roleNames));
        if (roleNames.Any(string.IsNullOrWhiteSpace))
            throw new ArgumentException("Role names cannot contain null or empty values", nameof(roleNames));
        
        // Проверка на дубликаты
        var distinctCount = roleNames.Distinct(StringComparer.Ordinal).Count();
        if (distinctCount != roleNames.Count)
            throw new ArgumentException($"Role names list contains duplicates. Total: {roleNames.Count}, Distinct: {distinctCount}", nameof(roleNames));
        
        await _rolesClient.RemoveMultipleRealmRolesFromUserAsync(realm, userId, roleNames, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// Получение всех доступных типов событий из реалма (с кэшированием)
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список типов событий</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// Результат кэшируется для улучшения производительности.
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public Task<IReadOnlyList<string>> GetEventTypesAsync(string realm, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        
        return _eventsClient.GetEventTypesAsync(realm, forceRefresh: false, cancellationToken);
    }
    
    /// <summary>
    /// Поиск пользователей в KeyCloak по username
    /// </summary>
    /// <param name="searchTerm">Термин для поиска (часть username)</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список найденных пользователей</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public async Task<List<Controllers.UserSearchResult>> SearchUsersAsync(string searchTerm, string realm, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateSearchTerm(searchTerm);
        KeycloakParameterValidator.ValidateRealm(realm);
        
        var result = await _usersClient.SearchUsersAsync(searchTerm, realm, cancellationToken).ConfigureAwait(false);
        // Конвертируем IReadOnlyList в List для обратной совместимости
        return result is List<Controllers.UserSearchResult> list ? list : result.ToList();
    }
    
    /// <summary>
    /// Поиск клиентов по Client ID (с опциональной фильтрацией по realm)
    /// </summary>
    /// <param name="searchTerm">Термин для поиска (часть Client ID). Не может быть null и не должен содержать control characters.</param>
    /// <param name="realm">Опциональное название реалма. Если null, поиск выполняется во всех доступных реалмах.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список найденных клиентов во всех указанных реалмах</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах (null searchTerm, превышение максимальной длины, control characters)</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// <para>Если realm не указан, метод получает список всех доступных реалмов через <see cref="GetRealmsListAsync"/> и выполняет поиск в каждом из них.</para>
    /// <para>При ошибке получения списка реалмов или при ошибке выполнения запроса к Keycloak API метод возвращает пустой список вместо выбрасывания исключения.</para>
    /// <para>Для поиска в конкретном реалме используйте <see cref="SearchClientsInRealmAsync"/>.</para>
    /// </remarks>
    public async Task<List<Controllers.ClientSearchResult>> SearchClientsByIdAsync(string searchTerm, string? realm = null, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateSearchTerm(searchTerm);
        if (realm != null)
            KeycloakParameterValidator.ValidateRealm(realm, nameof(realm));
        
        // Если realm не указан, получаем список всех реалмов и передаем его
        // Это устраняет зависимость от _realmsClient в KeycloakClientsClient
        List<string>? realmsList = null;
        if (realm == null)
        {
            try
            {
                // Используем прямой вызов к специализированному клиенту вместо рекурсивного вызова через публичный метод
                // Это более эффективно, так как избегает дополнительных проверок и валидаций
                realmsList = await _realmsClient.GetRealmsListAsync(cancellationToken).ConfigureAwait(false);
                
                if (realmsList == null || realmsList.Count == 0)
                {
                    _logger.LogWarning(
                        "No realms found, returning empty search results for search term: {SearchTerm}", 
                        searchTerm);
                    return new List<Controllers.ClientSearchResult>();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, 
                    "Ошибка при получении списка реалмов для поиска клиентов. Search term: {SearchTerm}", 
                    searchTerm);
                // Выбрасываем исключение, чтобы вызывающий код знал о проблеме
                throw new InvalidOperationException(
                    "Не удалось получить список реалмов для поиска клиентов", ex);
            }
        }
        
        return await _clientsClient.SearchClientsByIdAsync(searchTerm, realm, realmsList, cancellationToken)
            .ConfigureAwait(false);
    }
    
    /// <summary>
    /// Получить всех клиентов реалма в виде JsonElement для доступа к Internal ID
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список всех клиентов реалма в формате JsonElement</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public Task<List<JsonElement>> GetAllClientsAsJsonAsync(string realm, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        
        return _clientsClient.GetAllClientsAsJsonAsync(realm, cancellationToken);
    }
    
    /// <summary>
    /// Найти пользователя по username в конкретном реалме
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="username">Username пользователя</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Информация о пользователе в формате JsonElement, или null если пользователь не найден</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public Task<JsonElement?> GetUserByUsernameAsync(string realm, string username, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUsername(username);
        
        return _usersClient.GetUserByUsernameAsync(realm, username, cancellationToken);
    }
    
    /// <summary>
    /// Получить роли клиента для пользователя
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="clientUuid">UUID клиента</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список названий ролей клиента, назначенных пользователю</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <remarks>
    /// При ошибке выполнения запроса к Keycloak API метод выбрасывает исключение.
    /// </remarks>
    public Task<List<string>> GetUserClientRolesAsync(string realm, string userId, string clientUuid, CancellationToken cancellationToken = default)
    {
        ThrowIfDisposed();
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUserId(userId);
        if (string.IsNullOrWhiteSpace(clientUuid))
            throw new ArgumentException("Client UUID cannot be null or empty", nameof(clientUuid));
        
        return _rolesClient.GetUserClientRolesAsync(realm, userId, clientUuid, cancellationToken);
    }
    
    /// <summary>
    /// Проверка доступности Keycloak API (health check)
    /// </summary>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>true если Keycloak доступен, false в противном случае</returns>
    /// <remarks>
    /// Метод выполняет простую проверку доступности Keycloak, пытаясь получить список реалмов.
    /// Используйте этот метод для health checks в системах мониторинга.
    /// Метод не выбрасывает исключения, а возвращает false при любой ошибке.
    /// </remarks>
    public async Task<bool> IsHealthyAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            ThrowIfDisposed();
            // Простая проверка доступности Keycloak через получение списка реалмов
            await GetRealmsListAsync(cancellationToken).ConfigureAwait(false);
            return true;
        }
        catch (ObjectDisposedException)
        {
            // Объект освобожден - не здоров
            _logger.LogWarning("KeycloakHttpClient is disposed, health check failed.");
            return false;
        }
        catch (Exception ex)
        {
            // Логируем ошибку для диагностики, но не выбрасываем исключение
            _logger.LogError(ex, "Keycloak health check failed. Keycloak may be unavailable.");
            return false;
        }
    }
    
    /// <summary>
    /// Освобождение ресурсов
    /// </summary>
    public void Dispose()
    {
        // Атомарная проверка и установка флага для потокобезопасности
        if (Interlocked.Exchange(ref _disposed, 1) != 0)
            return; // Уже освобожден
        
        // Сохраняем ссылки в локальные переменные для потокобезопасности
        // Это предотвращает race condition при одновременном вызове Dispose из разных потоков
        var realmsClient = _realmsClient;
        var clientsClient = _clientsClient;
        var clientSecretsClient = _clientSecretsClient;
        var rolesClient = _rolesClient;
        var usersClient = _usersClient;
        var eventsClient = _eventsClient;
        var tokensClient = _tokensClient;
        
        // Список клиентов для освобождения
        var clientsToDispose = new IDisposable?[]
        {
            realmsClient,
            clientsClient,
            clientSecretsClient,
            rolesClient,
            usersClient,
            eventsClient,
            tokensClient
        };
        
        // Освобождаем каждый клиент отдельно, чтобы ошибка в одном не блокировала остальные
        foreach (var client in clientsToDispose)
        {
            try
            {
                client?.Dispose();
            }
            catch (ObjectDisposedException)
            {
                // Игнорируем, если уже освобожден
            }
            catch (Exception ex)
            {
                // Логируем ошибку, но продолжаем освобождение остальных
                _logger.LogError(ex, 
                    "Ошибка при освобождении клиента {ClientType}", 
                    client?.GetType().Name ?? "Unknown");
            }
        }
        
        // ВАЖНО: НЕ освобождаем HttpClient здесь!
        // Все HttpClient созданы через IHttpClientFactory.CreateClient("KeycloakAdmin")
        // и управляются фабрикой. Фабрика автоматически управляет их жизненным циклом,
        // переиспользует соединения и правильно освобождает ресурсы.
    }
    
    /// <summary>
    /// Асинхронное освобождение ресурсов
    /// </summary>
    public async ValueTask DisposeAsync()
    {
        // Атомарная проверка и установка флага для потокобезопасности
        if (Interlocked.Exchange(ref _disposed, 1) != 0)
            return; // Уже освобожден
        
        // Сохраняем ссылки в локальные переменные для потокобезопасности
        var realmsClient = _realmsClient;
        var clientsClient = _clientsClient;
        var clientSecretsClient = _clientSecretsClient;
        var rolesClient = _rolesClient;
        var usersClient = _usersClient;
        var eventsClient = _eventsClient;
        var tokensClient = _tokensClient;
        
        // Обрабатываем клиенты, которые поддерживают IAsyncDisposable
        var asyncClients = new IDisposable?[]
        {
            realmsClient,
            clientsClient,
            clientSecretsClient,
            rolesClient,
            usersClient,
            eventsClient,
            tokensClient
        };
        
        foreach (var client in asyncClients)
        {
            try
            {
                if (client is IAsyncDisposable asyncDisposable)
                {
                    await asyncDisposable.DisposeAsync().ConfigureAwait(false);
                }
                else if (client != null)
                {
                    // Для клиентов без IAsyncDisposable используем синхронный Dispose
                    client.Dispose();
                }
            }
            catch (ObjectDisposedException)
            {
                // Игнорируем, если уже освобожден
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, 
                    "Ошибка при асинхронном освобождении клиента {ClientType}", 
                    client?.GetType().Name ?? "Unknown");
            }
        }
        
        // НЕ вызываем Dispose() - ресурсы уже освобождены
    }

    /// <summary>
    /// Проверяет, не был ли объект освобожден
    /// </summary>
    private void ThrowIfDisposed()
    {
        if (Interlocked.CompareExchange(ref _disposed, 0, 0) != 0)
            throw new ObjectDisposedException(nameof(KeycloakHttpClient));
    }
}
