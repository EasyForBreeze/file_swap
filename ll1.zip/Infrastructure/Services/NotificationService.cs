using System.Collections.Concurrent;
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Logging;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для показа уведомлений
/// </summary>
public class NotificationService : INotificationService
{
    private const int MaxNotifications = 50;
    private readonly ConcurrentDictionary<int, NotificationItem> _notifications = new();
    private readonly ConcurrentDictionary<int, CancellationTokenSource> _notificationTimers = new();
    private readonly SemaphoreSlim _operationLock = new SemaphoreSlim(1, 1);
    private readonly ILogger<NotificationService> _logger;
    private int _notificationIdCounter = 0;
    private Func<Task>? _onStateChangedAsync;
    private readonly CancellationTokenSource _cts = new();
    private bool _disposed;
    
    // Кэширование для оптимизации производительности
    private IReadOnlyList<NotificationItem>? _cachedNotifications;
    private int _lastNotificationCount = -1;

    public NotificationService(ILogger<NotificationService> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public IReadOnlyList<NotificationItem> Notifications
    {
        get
        {
            var currentCount = _notifications.Count;
            // Инвалидируем кэш только при изменении количества уведомлений
            if (_cachedNotifications == null || _lastNotificationCount != currentCount)
            {
                _cachedNotifications = _notifications.Values.ToList().AsReadOnly();
                _lastNotificationCount = currentCount;
            }
            return _cachedNotifications;
        }
    }

    /// <summary>
    /// Устанавливает callback для обновления UI
    /// </summary>
    public void SetStateChangedCallback(Func<Task> callback)
    {
        ThrowIfDisposed();
        if (callback == null)
            throw new ArgumentNullException(nameof(callback));

        _onStateChangedAsync = callback;
    }

    /// <summary>
    /// Очищает callback
    /// </summary>
    public void ClearCallback()
    {
        _onStateChangedAsync = null;
    }

    /// <summary>
    /// Показывает уведомление
    /// </summary>
    public async Task ShowNotificationAsync(
        NotificationType type,
        string title,
        string message,
        int durationMs = 5000,
        string? actionLink = null,
        string? actionText = null)
    {
        ThrowIfDisposed();

        // Валидация параметров
        if (string.IsNullOrWhiteSpace(title))
            throw new ArgumentException("Title cannot be null or empty", nameof(title));
        if (string.IsNullOrWhiteSpace(message))
            throw new ArgumentException("Message cannot be null or empty", nameof(message));
        if (durationMs < 0)
            throw new ArgumentOutOfRangeException(nameof(durationMs), "Duration must be non-negative");

        await _operationLock.WaitAsync(_cts.Token);
        try
        {
            ThrowIfDisposed();

            // Удаляем старые уведомления при превышении лимита
            while (_notifications.Count >= MaxNotifications)
            {
                var oldest = _notifications.Values
                    .OrderBy(n => n.CreatedAt)
                    .FirstOrDefault();
                if (oldest != null)
                {
                    _notifications.TryRemove(oldest.Id, out _);
                    if (_notificationTimers.TryRemove(oldest.Id, out var oldCts))
                    {
                        oldCts.Cancel();
                        oldCts.Dispose();
                    }
                    InvalidateCache();
                }
            }

            var notification = new NotificationItem
            {
                Id = Interlocked.Increment(ref _notificationIdCounter),
                Type = type,
                Title = title,
                Message = message,
                ActionLink = actionLink,
                ActionText = actionText,
                CreatedAt = DateTime.UtcNow
            };

            _notifications.TryAdd(notification.Id, notification);
            InvalidateCache();

            // Вызываем callback для обновления UI
            await InvokeCallbackAsync();

            // Запускаем таймер для автоматического удаления
            var notificationCts = new CancellationTokenSource();
            _notificationTimers.TryAdd(notification.Id, notificationCts);

            _ = Task.Run(async () =>
            {
                try
                {
                    await Task.Delay(durationMs, notificationCts.Token).ConfigureAwait(false);

                    // Устанавливаем флаг выхода
                    if (_notifications.TryGetValue(notification.Id, out var existing))
                    {
                        existing.SetExiting();
                        await InvokeCallbackAsync();
                    }

                    await Task.Delay(300, notificationCts.Token).ConfigureAwait(false);

                    // Удаляем уведомление
                    if (_notifications.TryRemove(notification.Id, out _))
                    {
                        InvalidateCache();
                        await InvokeCallbackAsync();
                    }
                }
                catch (TaskCanceledException)
                {
                    // Сервис удаляется или уведомление отменено вручную
                    if (_notifications.TryRemove(notification.Id, out _))
                    {
                        InvalidateCache();
                    }
                }
                catch (Exception ex)
                {
                    // Логируем ошибку для диагностики
                    _logger.LogError(ex, "Error in notification timer for ID {NotificationId}", notification.Id);
                    
                    // Удаляем уведомление при ошибке
                    _notifications.TryRemove(notification.Id, out _);
                    InvalidateCache();
                }
                finally
                {
                    _notificationTimers.TryRemove(notification.Id, out _);
                    notificationCts.Dispose();
                }
            }, _cts.Token);
        }
        finally
        {
            _operationLock.Release();
        }
    }

    /// <summary>
    /// Удаляет уведомление по ID
    /// </summary>
    public void RemoveNotification(int id)
    {
        ThrowIfDisposed();

        if (!_notifications.TryGetValue(id, out var notification))
            return;

        notification.SetExiting();

        // Отменяем таймер уведомления
        if (_notificationTimers.TryGetValue(id, out var cts))
        {
            cts.Cancel();
        }

        // Вызываем callback для обновления UI
        _ = Task.Run(async () =>
        {
            try
            {
                await InvokeCallbackAsync();
                await Task.Delay(300, _cts.Token).ConfigureAwait(false);
                
                if (_notifications.TryRemove(id, out _))
                {
                    InvalidateCache();
                    await InvokeCallbackAsync();
                }
            }
            catch (TaskCanceledException)
            {
                // Сервис удаляется
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing notification ID {NotificationId}", id);
            }
            finally
            {
                if (_notificationTimers.TryRemove(id, out var timerCts))
                {
                    timerCts.Dispose();
                }
            }
        }, _cts.Token);
    }

    /// <summary>
    /// Безопасно вызывает callback для обновления UI
    /// </summary>
    private async Task InvokeCallbackAsync()
    {
        var callback = Volatile.Read(ref _onStateChangedAsync);
        if (callback != null)
        {
            try
            {
                await callback.Invoke();
            }
            catch (Exception ex)
            {
                // Логируем ошибку callback, но не прерываем выполнение
                _logger.LogError(ex, "Error invoking notification callback");
            }
        }
    }

    /// <summary>
    /// Инвалидирует кэш уведомлений
    /// </summary>
    private void InvalidateCache()
    {
        _cachedNotifications = null;
        _lastNotificationCount = -1;
    }

    /// <summary>
    /// Проверяет, не был ли сервис удален
    /// </summary>
    private void ThrowIfDisposed()
    {
        if (_disposed)
        {
            throw new ObjectDisposedException(nameof(NotificationService));
        }
    }

    /// <summary>
    /// Освобождает ресурсы
    /// </summary>
    public void Dispose()
    {
        if (_disposed)
            return;

        // Исправление критической проблемы: использование TryWait с таймаутом вместо блокирующего Wait()
        // Это предотвращает deadlock при вызове Dispose из async контекста
        bool lockAcquired = false;
        try
        {
            // Пытаемся получить блокировку без ожидания или с коротким таймаутом (100ms)
            lockAcquired = _operationLock.Wait(TimeSpan.FromMilliseconds(100));
            
            if (_disposed)
                return;

            // Отменяем все операции
            _cts.Cancel();
            _onStateChangedAsync = null;

            // Отменяем все таймеры уведомлений
            foreach (var cts in _notificationTimers.Values)
            {
                try
                {
                    cts.Cancel();
                    cts.Dispose();
                }
                catch (Exception ex)
                {
                    // Логируем ошибку, но продолжаем освобождение остальных ресурсов
                    _logger.LogWarning(ex, "Error disposing notification timer");
                }
            }

            // Очищаем коллекции
            _notificationTimers.Clear();
            _notifications.Clear();
            InvalidateCache();

            // Освобождаем ресурсы
            _cts.Dispose();
            _disposed = true;
        }
        catch (Exception ex)
        {
            // Логируем ошибку при освобождении ресурсов
            _logger.LogError(ex, "Error during NotificationService disposal");
            _disposed = true; // Устанавливаем флаг даже при ошибке
        }
        finally
        {
            if (lockAcquired)
            {
                try
                {
                    _operationLock.Release();
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Error releasing operation lock during disposal");
                }
            }
            
            try
            {
                _operationLock.Dispose();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error disposing operation lock");
            }
        }
    }
}
