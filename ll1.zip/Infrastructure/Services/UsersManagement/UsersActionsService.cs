using System.Diagnostics;
using System.Linq;
using System.Net.Http.Json;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services.UsersManagement;

/// <summary>
/// Сервис для выполнения действий с пользователями (блокировка, разблокировка, brute force, email actions) через users-management API
/// </summary>
public class UsersActionsService : UsersManagementBaseService, IUsersActionsService
{
    // Константы для валидации
    private const int MaxReasonLength = 1000;
    private const int AuditTimeoutSeconds = 5;
    private const int MaxActionsCount = 10;
    private const int MaxErrorContentLength = 1000;
    private const int MaxDescriptionLength = 2000;
    
    // Регулярное выражение для валидации UUID
    private static readonly Regex UuidRegex = new(
        @"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$",
        RegexOptions.Compiled);
    
    // Регулярное выражение для валидации realm
    private static readonly Regex RealmNameRegex = new(
        @"^[a-zA-Z0-9_-]+$",
        RegexOptions.Compiled);
    
    // Допустимые значения actions
    private static readonly HashSet<string> ValidActions = new(StringComparer.OrdinalIgnoreCase)
    {
        ActionTypes.UpdatePassword,
        ActionTypes.ConfigureTotp,
        ActionTypes.VerifyEmail,
        ActionTypes.UpdateProfile
    };
    
    /// <summary>
    /// Константы для типов событий аудита
    /// </summary>
    private static class EventTypes
    {
        public const string UserPasswordUpdate = "UserPasswordUpdate";
        public const string UserOtpConfigured = "UserOtpConfigured";
        public const string UserBlocked = "UserBlocked";
        public const string UserUnblocked = "UserUnblocked";
        public const string UserBlockFailed = "UserBlockFailed";
        public const string UserUnblockFailed = "UserUnblockFailed";
        public const string RemoveBruteForceFailed = "RemoveBruteForceFailed";
        public const string ExecuteActionsEmailFailed = "ExecuteActionsEmailFailed";
    }
    
    /// <summary>
    /// Константы для типов действий
    /// </summary>
    private static class ActionTypes
    {
        public const string UpdatePassword = "UPDATE_PASSWORD";
        public const string ConfigureTotp = "CONFIGURE_TOTP";
        public const string VerifyEmail = "VERIFY_EMAIL";
        public const string UpdateProfile = "UPDATE_PROFILE";
    }
    
    public UsersActionsService(
        HttpClient httpClient,
        Microsoft.Extensions.Options.IOptions<new_assistant.Configuration.KeycloakAdminSettings> settings,
        new_assistant.Core.Interfaces.IAuditService auditService,
        Microsoft.AspNetCore.Http.IHttpContextAccessor httpContextAccessor,
        new_assistant.Core.Interfaces.ITokenExchangeService tokenExchangeService,
        new_assistant.Core.Interfaces.IPerformanceMetricsService metricsService,
        ILogger<UsersActionsService> logger)
        : base(httpClient, settings, auditService, httpContextAccessor, tokenExchangeService, metricsService, logger)
    {
    }
    
    /// <summary>
    /// Валидация формата userId (UUID)
    /// </summary>
    private void ValidateUserId(string userId)
    {
        if (string.IsNullOrWhiteSpace(userId))
            throw new ArgumentException("User ID cannot be null or empty", nameof(userId));
        
        if (!UuidRegex.IsMatch(userId))
        {
            Logger.LogWarning("User ID не соответствует формату UUID: {UserId}", userId);
            // Не выбрасываем исключение, так как API может принимать и другие форматы
        }
    }
    
    /// <summary>
    /// Валидация формата realm
    /// </summary>
    private void ValidateRealmFormat(string realm)
    {
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        if (realm.Length > 255)
            throw new ArgumentException("Realm name cannot exceed 255 characters", nameof(realm));
        
        if (!RealmNameRegex.IsMatch(realm))
            throw new ArgumentException(
                "Realm name contains invalid characters. Only letters, numbers, underscores and hyphens are allowed",
                nameof(realm));
    }
    
    /// <summary>
    /// Валидация длины reason
    /// </summary>
    private void ValidateReason(string reason)
    {
        if (string.IsNullOrWhiteSpace(reason))
            throw new ArgumentException("Reason cannot be null or empty", nameof(reason));
        
        if (reason.Length > MaxReasonLength)
            throw new ArgumentException(
                $"Reason cannot exceed {MaxReasonLength} characters. Current length: {reason.Length}",
                nameof(reason));
    }
    
    /// <summary>
    /// Санитизация reason для предотвращения XSS (экранирование вместо удаления)
    /// </summary>
    private static string SanitizeReason(string reason)
    {
        if (string.IsNullOrWhiteSpace(reason))
            return reason;
        
        // Экранируем потенциально опасные символы вместо удаления
        return reason
            .Replace("&", "&amp;")  // Должно быть первым, чтобы не экранировать уже экранированные символы
            .Replace("<", "&lt;")
            .Replace(">", "&gt;")
            .Replace("\"", "&quot;")
            .Replace("'", "&#x27;");
    }
    
    /// <summary>
    /// Валидация и нормализация списка actions (не модифицирует входной список)
    /// </summary>
    private List<string> ValidateAndNormalizeActions(IReadOnlyList<string> actions)
    {
        if (actions == null || actions.Count == 0)
            throw new ArgumentException("Actions list cannot be null or empty", nameof(actions));
        
        if (actions.Count > MaxActionsCount)
            throw new ArgumentException(
                $"Actions list cannot contain more than {MaxActionsCount} items, but was {actions.Count}",
                nameof(actions));
        
        if (actions.Any(string.IsNullOrWhiteSpace))
            throw new ArgumentException("Actions list cannot contain null or empty values", nameof(actions));
        
        // Проверка на дубликаты и создание нового списка
        var uniqueActions = actions.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        if (uniqueActions.Count != actions.Count)
        {
            Logger.LogWarning("Обнаружены дубликаты в списке actions. Оригинальный список: {OriginalCount}, Уникальный: {UniqueCount}",
                actions.Count, uniqueActions.Count);
        }
        
        var invalidActions = uniqueActions.Where(a => !ValidActions.Contains(a)).ToList();
        if (invalidActions.Any())
        {
            throw new ArgumentException(
                $"Invalid actions: {string.Join(", ", invalidActions)}. Valid actions: {string.Join(", ", ValidActions)}",
                nameof(actions));
        }
        
        return uniqueActions;
    }
    
    /// <summary>
    /// Обрезать errorContent до максимальной длины
    /// </summary>
    private string TruncateErrorContent(string errorContent)
    {
        if (string.IsNullOrWhiteSpace(errorContent))
            return "No error details";
        
        if (errorContent.Length > MaxErrorContentLength)
        {
            Logger.LogWarning("Error content truncated from {OriginalLength} to {MaxLength} characters",
                errorContent.Length, MaxErrorContentLength);
            return errorContent.Substring(0, MaxErrorContentLength) + "... [truncated]";
        }
        
        return errorContent;
    }
    
    /// <summary>
    /// Обрезать description до максимальной длины
    /// </summary>
    private string TruncateDescription(string description)
    {
        if (string.IsNullOrWhiteSpace(description))
            return description;
        
        if (description.Length > MaxDescriptionLength)
        {
            Logger.LogWarning("Description truncated from {OriginalLength} to {MaxLength} characters",
                description.Length, MaxDescriptionLength);
            return description.Substring(0, MaxDescriptionLength) + "... [truncated]";
        }
        
        return description;
    }
    
    /// <summary>
    /// Выполнить операцию аудита с таймаутом
    /// </summary>
    private async Task LogAuditWithTimeoutAsync(
        string actingUser,
        string eventType,
        string userId,
        string? targetUsername,
        string realm,
        string description,
        Dictionary<string, string>? metadata,
        CancellationToken cancellationToken = default)
    {
        try
        {
            await AuditService.LogUserManagementActionAsync(
                    actingUser,
                    eventType,
                    userId,
                    targetUsername,
                    realm,
                    description,
                    metadata)
                .WaitAsync(TimeSpan.FromSeconds(AuditTimeoutSeconds), cancellationToken)
                .ConfigureAwait(false);
        }
        catch (TimeoutException)
        {
            Logger.LogWarning("Таймаут при логировании аудита для операции {EventType}, UserId={UserId}", eventType, userId);
            // Не прерываем выполнение, так как основная операция уже выполнена
        }
        catch (Exception auditEx)
        {
            Logger.LogError(auditEx, "Ошибка при логировании аудита для операции {EventType}, UserId={UserId}", eventType, userId);
            // Не прерываем выполнение
        }
    }
    
    /// <summary>
    /// Получает информацию о событии аудита для действия пользователя
    /// </summary>
    /// <param name="action">Тип действия (UPDATE_PASSWORD, CONFIGURE_TOTP и т.д.)</param>
    /// <param name="actingUser">Пользователь, выполняющий действие</param>
    /// <param name="targetDisplay">Отображаемое имя целевого пользователя</param>
    /// <returns>Кортеж с типом события аудита и описанием, или (null, null) если действие не требует аудита</returns>
    private static (string? EventType, string Description) GetAuditEventInfoForAction(
        string action, 
        string actingUser, 
        string targetDisplay)
    {
        string? eventType = action switch
        {
            ActionTypes.UpdatePassword => EventTypes.UserPasswordUpdate,
            ActionTypes.ConfigureTotp => EventTypes.UserOtpConfigured,
            _ => null
        };

        if (eventType == null)
        {
            return (null, string.Empty);
        }

        string description = eventType switch
        {
            EventTypes.UserPasswordUpdate => $"Пользователь {actingUser} инициировал обновление пароля для пользователя {targetDisplay}.",
            EventTypes.UserOtpConfigured => $"Пользователь {actingUser} инициировал настройку OTP для пользователя {targetDisplay}.",
            _ => $"Пользователь {actingUser} выполнил действие {action} для пользователя {targetDisplay}."
        };

        return (eventType, description);
    }
    
    /// <summary>
    /// Снять блокировку брутфорса для пользователя
    /// </summary>
    public async Task<bool> RemoveBruteForceStatusAsync(
        string accessToken,
        string realm,
        string userId,
        CancellationToken cancellationToken = default)
    {
        const string operationName = "RemoveBruteForceStatus";
        
        // Валидация входных параметров
        ValidateCommonParameters(accessToken, realm, operationName);
        ValidateRealmFormat(realm);
        ValidateUserId(userId);
        
        using var scope = Logger.BeginScope(new Dictionary<string, object>
        {
            ["Realm"] = realm,
            ["UserId"] = userId,
            ["Operation"] = operationName
        });
        
        try
        {
            Logger.LogInformation("Начало выполнения операции {Operation} для пользователя {UserId} в реалме {Realm}",
                operationName, userId, realm);
            
            // Формируем endpoint для users-management API
            var endpoint = $"auth/realms/{realm}/users-management/{ApiVersionV1}/users/{userId}/brute-force";
            
            Logger.LogDebug("Отправка DELETE запроса на снятие блокировки брутфорса: Endpoint={Endpoint}", endpoint);
            
            // Создаем запрос
            var request = await CreateRequestAsync(HttpMethod.Delete, endpoint, accessToken, realm, cancellationToken).ConfigureAwait(false);
            request.Headers.Add("Accept", "application/json");
            
            var stopwatch = Stopwatch.StartNew();
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            stopwatch.Stop();
            MetricsService.RecordOperationTime(MetricsOperationName, stopwatch.ElapsedMilliseconds);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                var safeErrorContent = TruncateErrorContent(errorContent);
                
                Logger.LogError("Ошибка снятия блокировки брутфорса: StatusCode={StatusCode}, Error={Error}, Realm={Realm}, UserId={UserId}", 
                    response.StatusCode, safeErrorContent, realm, userId);
                
                MetricsService.RecordError(MetricsOperationName, $"HTTP_{((int)response.StatusCode)}");
                
                // Логируем неудачную попытку в аудит
                var actingUser = GetActingUsername();
                var description = TruncateDescription($"Неудачная попытка снятия блокировки брутфорса для пользователя {userId}. Ошибка: {safeErrorContent}");
                var metadata = new Dictionary<string, string>
                {
                    ["error"] = safeErrorContent,
                    ["statusCode"] = ((int)response.StatusCode).ToString()
                };
                
                await LogAuditWithTimeoutAsync(
                    actingUser,
                    EventTypes.RemoveBruteForceFailed,
                    userId,
                    null,
                    realm,
                    description,
                    metadata,
                    cancellationToken);
                
                return false;
            }
            
            MetricsService.RecordSuccess(MetricsOperationName);
            Logger.LogInformation("Блокировка брутфорса успешно снята: Realm={Realm}, UserId={UserId}", realm, userId);
            return true;
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning("Операция снятия блокировки брутфорса была отменена: Realm={Realm}, UserId={UserId}", realm, userId);
            throw;
        }
        catch (Exception ex)
        {
            MetricsService.RecordError(MetricsOperationName, ex.GetType().Name);
            Logger.LogError(ex, "Ошибка при снятии блокировки брутфорса в реалме {Realm}, UserId={UserId}, Message={Message}", realm, userId, ex.Message);
            return false;
        }
    }
    
    /// <summary>
    /// Выполнить действия через email для пользователя (например, обновление пароля, конфигурация OTP)
    /// </summary>
    public async Task<bool> ExecuteActionsEmailAsync(
        string accessToken,
        string realm,
        string userId,
        List<string> actions,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        const string operationName = "ExecuteActionsEmail";
        
        // Валидация входных параметров
        ValidateCommonParameters(accessToken, realm, operationName);
        ValidateRealmFormat(realm);
        ValidateUserId(userId);
        var normalizedActions = ValidateAndNormalizeActions(actions);
        
        var actionCount = normalizedActions.Count;
        
        using var scope = Logger.BeginScope(new Dictionary<string, object>
        {
            ["Realm"] = realm,
            ["UserId"] = userId,
            ["Operation"] = operationName,
            ["ActionCount"] = actionCount
        });
        
        try
        {
            Logger.LogInformation("Начало выполнения операции {Operation} для пользователя {UserId} в реалме {Realm}, ActionCount={ActionCount}",
                operationName, userId, realm, actionCount);
            
            // Формируем endpoint для users-management API
            var endpoint = $"auth/realms/{realm}/users-management/{ApiVersionV1}/users/{userId}/execute-actions-email";
            
            // Формируем тело запроса
            var requestData = new Dictionary<string, object>
            {
                ["actions"] = normalizedActions
            };
            
            // Создаем JSON из словаря
            var jsonContent = JsonContent.Create(requestData);
            
            Logger.LogDebug("Отправка PUT запроса на выполнение действий через email: Endpoint={Endpoint}, ActionCount={ActionCount}", endpoint, actionCount);
            
            // Создаем запрос
            var request = await CreateRequestAsync(HttpMethod.Put, endpoint, accessToken, realm, cancellationToken).ConfigureAwait(false);
            request.Content = jsonContent;
            request.Headers.Add("Accept", "application/json");
            
            var stopwatch = Stopwatch.StartNew();
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            stopwatch.Stop();
            MetricsService.RecordOperationTime(MetricsOperationName, stopwatch.ElapsedMilliseconds);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                var safeErrorContent = TruncateErrorContent(errorContent);
                
                Logger.LogError("Ошибка выполнения действий через email: StatusCode={StatusCode}, Error={Error}, Realm={Realm}, UserId={UserId}, ActionCount={ActionCount}", 
                    response.StatusCode, safeErrorContent, realm, userId, actionCount);
                
                MetricsService.RecordError(MetricsOperationName, $"HTTP_{((int)response.StatusCode)}");
                
                // Логируем неудачную попытку в аудит
                var failedActionsActingUser = GetActingUsername();
                var failedActionsTargetDisplay = FormatTargetDisplay(targetUsername, userId);
                var actionsStr = string.Join(", ", normalizedActions);
                var failedActionsDescription = TruncateDescription($"Неудачная попытка выполнения действий через email для пользователя {failedActionsTargetDisplay}. Действия: {actionsStr}. Ошибка: {safeErrorContent}");
                var failedActionsMetadata = new Dictionary<string, string>
                {
                    ["actions"] = actionsStr,
                    ["error"] = safeErrorContent,
                    ["statusCode"] = ((int)response.StatusCode).ToString()
                };
                
                await LogAuditWithTimeoutAsync(
                    failedActionsActingUser,
                    EventTypes.ExecuteActionsEmailFailed,
                    userId,
                    targetUsername,
                    realm,
                    failedActionsDescription,
                    failedActionsMetadata,
                    cancellationToken);
                
                return false;
            }
            
            MetricsService.RecordSuccess(MetricsOperationName);
            Logger.LogInformation("Действия через email успешно отправлены: Realm={Realm}, UserId={UserId}, Actions={Actions}", 
                realm, userId, string.Join(", ", normalizedActions));

            var actingUser = GetActingUsername();
            var targetDisplay = FormatTargetDisplay(targetUsername, userId);
            
            // Логируем каждое действие в аудит
            foreach (var action in normalizedActions)
            {
                var (eventType, description) = GetAuditEventInfoForAction(action, actingUser, targetDisplay);
                
                if (eventType == null)
                {
                    continue;
                }

                var metadata = new Dictionary<string, string>
                {
                    ["action"] = action
                };

                await LogAuditWithTimeoutAsync(
                    actingUser,
                    eventType,
                    userId,
                    targetUsername,
                    realm,
                    TruncateDescription(description),
                    metadata,
                    cancellationToken);
            }
            return true;
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning("Операция выполнения действий через email была отменена: Realm={Realm}, UserId={UserId}", realm, userId);
            throw;
        }
        catch (Exception ex)
        {
            MetricsService.RecordError(MetricsOperationName, ex.GetType().Name);
            var safeActionCount = actions?.Count ?? 0;
            Logger.LogError(ex, "Ошибка при выполнении действий через email в реалме {Realm}, UserId={UserId}, ActionCount={ActionCount}", 
                realm, userId, safeActionCount);
            return false;
        }
    }
    
    /// <summary>
    /// Заблокировать пользователя
    /// </summary>
    public async Task<bool> BlockUserAsync(
        string accessToken,
        string realm,
        string userId,
        string reason,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        const string operationName = "BlockUser";
        
        // Валидация входных параметров
        ValidateCommonParameters(accessToken, realm, operationName);
        ValidateRealmFormat(realm);
        ValidateUserId(userId);
        ValidateReason(reason);
        
        // Санитизация reason
        var sanitizedReason = SanitizeReason(reason);
        var reasonLength = sanitizedReason.Length;
        
        using var scope = Logger.BeginScope(new Dictionary<string, object>
        {
            ["Realm"] = realm,
            ["UserId"] = userId,
            ["Operation"] = operationName
        });
        
        try
        {
            Logger.LogInformation("Начало выполнения операции {Operation} для пользователя {UserId} в реалме {Realm}",
                operationName, userId, realm);
            
            // Формируем endpoint для users-management API
            var endpoint = $"auth/realms/{realm}/users-management/{ApiVersionV2}/users/{userId}/blocking";
            
            // Формируем тело запроса с санитизированным reason
            var requestData = new Dictionary<string, object>
            {
                ["reason"] = sanitizedReason
            };
            
            // Создаем JSON из словаря
            var jsonContent = JsonContent.Create(requestData);
            
            Logger.LogDebug("Отправка POST запроса на блокировку пользователя: Endpoint={Endpoint}, ReasonLength={ReasonLength}", endpoint, reasonLength);
            
            // Создаем запрос
            var request = await CreateRequestAsync(HttpMethod.Post, endpoint, accessToken, realm, cancellationToken).ConfigureAwait(false);
            request.Content = jsonContent;
            request.Headers.Add("Accept", "application/json");
            
            var stopwatch = Stopwatch.StartNew();
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            stopwatch.Stop();
            MetricsService.RecordOperationTime(MetricsOperationName, stopwatch.ElapsedMilliseconds);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                var safeErrorContent = TruncateErrorContent(errorContent);
                
                Logger.LogError("Ошибка блокировки пользователя: StatusCode={StatusCode}, Error={Error}, Realm={Realm}, UserId={UserId}, ReasonLength={ReasonLength}", 
                    response.StatusCode, safeErrorContent, realm, userId, reasonLength);
                
                MetricsService.RecordError(MetricsOperationName, $"HTTP_{((int)response.StatusCode)}");
                
                // Логируем неудачную попытку в аудит
                var blockFailedActingUser = GetActingUsername();
                var blockFailedTargetDisplay = FormatTargetDisplay(targetUsername, userId);
                var blockFailedDescription = TruncateDescription($"Неудачная попытка блокировки пользователя {blockFailedTargetDisplay}. Причина: {sanitizedReason}. Ошибка: {safeErrorContent}");
                var blockFailedMetadata = new Dictionary<string, string>
                {
                    ["reason"] = sanitizedReason,
                    ["error"] = safeErrorContent,
                    ["statusCode"] = ((int)response.StatusCode).ToString()
                };
                
                await LogAuditWithTimeoutAsync(
                    blockFailedActingUser,
                    EventTypes.UserBlockFailed,
                    userId,
                    targetUsername,
                    realm,
                    blockFailedDescription,
                    blockFailedMetadata,
                    cancellationToken);
                
                return false;
            }
            
            MetricsService.RecordSuccess(MetricsOperationName);
            Logger.LogInformation("Пользователь успешно заблокирован: Realm={Realm}, UserId={UserId}, ReasonLength={ReasonLength}", 
                realm, userId, reasonLength);

            var actingUser = GetActingUsername();
            var targetDisplay = FormatTargetDisplay(targetUsername, userId);
            var metadata = new Dictionary<string, string>
            {
                ["reason"] = sanitizedReason
            };

            var description = TruncateDescription($"Пользователь {actingUser} заблокировал пользователя {targetDisplay}. Причина: {sanitizedReason}.");
            await LogAuditWithTimeoutAsync(
                actingUser,
                EventTypes.UserBlocked,
                userId,
                targetUsername,
                realm,
                description,
                metadata,
                cancellationToken);
            return true;
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning("Операция блокировки пользователя была отменена: Realm={Realm}, UserId={UserId}", realm, userId);
            throw;
        }
        catch (Exception ex)
        {
            MetricsService.RecordError(MetricsOperationName, ex.GetType().Name);
            Logger.LogError(ex, "Ошибка при блокировке пользователя в реалме {Realm}, UserId={UserId}, ReasonLength={ReasonLength}", 
                realm, userId, reasonLength);
            return false;
        }
    }
    
    /// <summary>
    /// Разблокировать пользователя
    /// </summary>
    public async Task<bool> UnblockUserAsync(
        string accessToken,
        string realm,
        string userId,
        string reason,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        const string operationName = "UnblockUser";
        
        // Валидация входных параметров
        ValidateCommonParameters(accessToken, realm, operationName);
        ValidateRealmFormat(realm);
        ValidateUserId(userId);
        ValidateReason(reason);
        
        // Санитизация reason
        var sanitizedReason = SanitizeReason(reason);
        var reasonLength = sanitizedReason.Length;
        
        using var scope = Logger.BeginScope(new Dictionary<string, object>
        {
            ["Realm"] = realm,
            ["UserId"] = userId,
            ["Operation"] = operationName
        });
        
        try
        {
            Logger.LogInformation("Начало выполнения операции {Operation} для пользователя {UserId} в реалме {Realm}",
                operationName, userId, realm);
            
            // Формируем endpoint для users-management API
            var endpoint = $"auth/realms/{realm}/users-management/{ApiVersionV2}/users/{userId}/unblocking";
            
            // Формируем тело запроса с санитизированным reason
            var requestData = new Dictionary<string, object>
            {
                ["reason"] = sanitizedReason
            };
            
            // Создаем JSON из словаря
            var jsonContent = JsonContent.Create(requestData);
            
            Logger.LogDebug("Отправка POST запроса на разблокировку пользователя: Endpoint={Endpoint}, ReasonLength={ReasonLength}", endpoint, reasonLength);
            
            // Создаем запрос
            var request = await CreateRequestAsync(HttpMethod.Post, endpoint, accessToken, realm, cancellationToken).ConfigureAwait(false);
            request.Content = jsonContent;
            request.Headers.Add("Accept", "application/json");
            
            var stopwatch = Stopwatch.StartNew();
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            stopwatch.Stop();
            MetricsService.RecordOperationTime(MetricsOperationName, stopwatch.ElapsedMilliseconds);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                var safeErrorContent = TruncateErrorContent(errorContent);
                
                Logger.LogError("Ошибка разблокировки пользователя: StatusCode={StatusCode}, Error={Error}, Realm={Realm}, UserId={UserId}, ReasonLength={ReasonLength}", 
                    response.StatusCode, safeErrorContent, realm, userId, reasonLength);
                
                MetricsService.RecordError(MetricsOperationName, $"HTTP_{((int)response.StatusCode)}");
                
                // Логируем неудачную попытку в аудит
                var unblockFailedActingUser = GetActingUsername();
                var unblockFailedTargetDisplay = FormatTargetDisplay(targetUsername, userId);
                var unblockFailedDescription = TruncateDescription($"Неудачная попытка разблокировки пользователя {unblockFailedTargetDisplay}. Причина: {sanitizedReason}. Ошибка: {safeErrorContent}");
                var unblockFailedMetadata = new Dictionary<string, string>
                {
                    ["reason"] = sanitizedReason,
                    ["error"] = safeErrorContent,
                    ["statusCode"] = ((int)response.StatusCode).ToString()
                };
                
                await LogAuditWithTimeoutAsync(
                    unblockFailedActingUser,
                    EventTypes.UserUnblockFailed,
                    userId,
                    targetUsername,
                    realm,
                    unblockFailedDescription,
                    unblockFailedMetadata,
                    cancellationToken);
                
                return false;
            }
            
            MetricsService.RecordSuccess(MetricsOperationName);
            Logger.LogInformation("Пользователь успешно разблокирован: Realm={Realm}, UserId={UserId}, ReasonLength={ReasonLength}", 
                realm, userId, reasonLength);

            var actingUser = GetActingUsername();
            var targetDisplay = FormatTargetDisplay(targetUsername, userId);
            var metadata = new Dictionary<string, string>
            {
                ["reason"] = sanitizedReason
            };

            var description = TruncateDescription($"Пользователь {actingUser} разблокировал пользователя {targetDisplay}. Причина: {sanitizedReason}.");
            await LogAuditWithTimeoutAsync(
                actingUser,
                EventTypes.UserUnblocked,
                userId,
                targetUsername,
                realm,
                description,
                metadata,
                cancellationToken);
            return true;
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning("Операция разблокировки пользователя была отменена: Realm={Realm}, UserId={UserId}", realm, userId);
            throw;
        }
        catch (Exception ex)
        {
            MetricsService.RecordError(MetricsOperationName, ex.GetType().Name);
            Logger.LogError(ex, "Ошибка при разблокировке пользователя в реалме {Realm}, UserId={UserId}, ReasonLength={ReasonLength}", 
                realm, userId, reasonLength);
            return false;
        }
    }
}

