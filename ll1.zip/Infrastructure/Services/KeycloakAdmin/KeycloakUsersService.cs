using System.Text.Json;
using new_assistant.Core.Interfaces;
using new_assistant.Core.DTOs;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services.KeycloakAdmin;

/// <summary>
/// Сервис для работы с пользователями Keycloak
/// </summary>
public class KeycloakUsersService : IKeycloakUsersService
{
    private readonly KeycloakHttpClient _httpClient;
    private readonly ILogger<KeycloakUsersService> _logger;

    public KeycloakUsersService(
        KeycloakHttpClient httpClient,
        ILogger<KeycloakUsersService> logger)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Получить пользователя по username в указанном реалме
    /// </summary>
    public async Task<JsonElement?> GetUserByUsernameAsync(string realm, string username, CancellationToken cancellationToken = default)
    {
        return await _httpClient.GetUserByUsernameAsync(realm, username, cancellationToken);
    }
    
    /// <summary>
    /// Получить client роли пользователя
    /// </summary>
    public async Task<List<string>> GetUserClientRolesAsync(string realm, string userId, string clientUuid, CancellationToken cancellationToken = default)
    {
        return await _httpClient.GetUserClientRolesAsync(realm, userId, clientUuid, cancellationToken);
    }
    
    /// <summary>
    /// Поиск пользователей в KeyCloak по username
    /// </summary>
    public async Task<List<Controllers.UserSearchResult>> SearchUsersAsync(string searchTerm, string realm, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(searchTerm))
            throw new ArgumentException("SearchTerm не может быть пустым", nameof(searchTerm));
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        try
        {
            var users = await _httpClient.SearchUsersAsync(searchTerm, realm, cancellationToken);
            
            return users;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при поиске пользователей: {SearchTerm} в реалме: {Realm}", searchTerm, realm);
            throw;
        }
    }
    
    /// <summary>
    /// Поиск пользователей по username в конкретном реалме
    /// </summary>
    public async Task<List<UserSearchResultDto>> SearchUsersByUsernameAsync(string realm, string username, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username не может быть пустым", nameof(username));
        
        var result = await _httpClient.SearchUsersByUsernameAsync(realm, username, cancellationToken).ConfigureAwait(false);
        // Результат уже List<UserSearchResultDto> из KeycloakHttpClient
        return result;
    }
}

