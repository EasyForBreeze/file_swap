using System.Diagnostics;
using System.Text.Json;
using new_assistant.Core.Interfaces;
using new_assistant.Core.DTOs;
using System.Linq;
using new_assistant.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace new_assistant.Infrastructure.Services.KeycloakAdmin;

/// <summary>
/// Сервис для управления клиентами Keycloak (CRUD операции)
/// </summary>
public class KeycloakClientManagementService : IKeycloakClientManagementService
{
    // Константы для строковых литералов
    private static class ClientConstants
    {
        public const string ProtocolOpenIdConnect = "openid-connect";
    }
    
    private readonly KeycloakHttpClient _httpClient;
    private readonly KeycloakAdminSettings _settings;
    private readonly ILogger<KeycloakClientManagementService> _logger;
    private readonly IForbiddenClientService _forbiddenService;
    private readonly IPerformanceMetricsService _metricsService;

    public KeycloakClientManagementService(
        KeycloakHttpClient httpClient,
        IOptions<KeycloakAdminSettings> settings,
        ILogger<KeycloakClientManagementService> logger,
        IForbiddenClientService forbiddenService,
        IPerformanceMetricsService metricsService)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _settings = settings?.Value ?? throw new ArgumentNullException(nameof(settings));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _forbiddenService = forbiddenService ?? throw new ArgumentNullException(nameof(forbiddenService));
        _metricsService = metricsService ?? throw new ArgumentNullException(nameof(metricsService));
    }

    private async Task EnsureClientNotForbiddenAsync(string clientId, string realm, CancellationToken cancellationToken)
    {
        // Проверяем через централизованный сервис
        if (await _forbiddenService.IsForbiddenAsync(clientId, realm, cancellationToken).ConfigureAwait(false))
        {
            // Определяем тип запрета
            var alwaysForbiddenSet = _forbiddenService.GetAlwaysForbiddenSet();
            var idLower = clientId?.ToLowerInvariant() ?? string.Empty;
            var isSystemClient = alwaysForbiddenSet.Contains(idLower);
            
            if (isSystemClient)
            {
                _logger.LogWarning("Операция отклонена: системный клиент {ClientId} запрещен во всех реалмах", clientId);
                throw new InvalidOperationException($"Клиент '{clientId}' является системным и запрещен для изменений.");
            }
            else
            {
                _logger.LogWarning("Операция отклонена: клиент {ClientId} в реалме {Realm} находится в списке запрещенных", clientId, realm);
                throw new InvalidOperationException($"Клиент '{clientId}' в реалме '{realm}' находится в списке запрещенных. Изменения запрещены.");
            }
        }
    }

    /// <summary>
    /// Создать нового клиента в Keycloak
    /// </summary>
    public async Task<string> CreateClientAsync(CreateClientRequestDto request, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        if (request == null)
            throw new ArgumentNullException(nameof(request));
        
        if (string.IsNullOrWhiteSpace(request.ClientId))
            throw new ArgumentException("ClientId не может быть пустым", nameof(request));
        
        if (string.IsNullOrWhiteSpace(request.Realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(request));
        
        var stopwatch = Stopwatch.StartNew();
        try
        {
            _logger.LogInformation("Создание клиента {ClientId} в реалме {Realm}", request.ClientId, request.Realm);
            
            // Проверяем что клиент не в запрещенном списке
            await EnsureClientNotForbiddenAsync(request.ClientId, request.Realm, cancellationToken).ConfigureAwait(false);

            // Создаем JSON объект для Keycloak API
            var clientData = new
            {
                clientId = request.ClientId,
                name = request.Name ?? request.ClientId,
                description = request.Description ?? "",
                enabled = true,
                protocol = ClientConstants.ProtocolOpenIdConnect,
                publicClient = !request.ClientAuthentication,
                serviceAccountsEnabled = request.ServiceAccount,
                standardFlowEnabled = request.StandardFlow,
                directAccessGrantsEnabled = false,
                implicitFlowEnabled = false,
                frontchannelLogout = true,
                redirectUris = request.RedirectUris.ToArray(),
                webOrigins = request.RedirectUris.ToArray(),
                attributes = new Dictionary<string, string>
                {
                    ["owner.system.name"] = request.OwnerSystemName,
                    ["owner.system.url"] = request.OwnerSystemUrl ?? "",
                    ["owner.name"] = request.OwnerName ?? "",
                    ["support.manager"] = request.SupportManager ?? ""
                }
            };

            var json = JsonSerializer.Serialize(clientData, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            var jsonElement = JsonSerializer.Deserialize<JsonElement>(json);
            
            // Создаем клиента в Keycloak
            var clientInternalId = await _httpClient.CreateClientAsync(request.Realm, jsonElement, cancellationToken);

            // Создаем локальные роли для клиента
            if (request.LocalRoles.Any())
            {
                var roleCreationErrors = new List<string>();
                
                foreach (var role in request.LocalRoles)
                {
                    try
                    {
                        await _httpClient.CreateClientRoleAsync(request.Realm, clientInternalId, role, cancellationToken);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Не удалось создать локальную роль {Role} для клиента {ClientId}", role, request.ClientId);
                        roleCreationErrors.Add(role);
                    }
                }
                
                if (roleCreationErrors.Any())
                {
                    _logger.LogWarning("Клиент {ClientId} создан, но не удалось создать роли: {Roles}", 
                        request.ClientId, string.Join(", ", roleCreationErrors));
                }
            }

            return clientInternalId;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка создания клиента {ClientId} в реалме {Realm}", request.ClientId, request.Realm);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            _metricsService.RecordOperationTime("KeycloakClientManagement.CreateClient", stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Обновить детали клиента в Keycloak
    /// </summary>
    public async Task UpdateClientDetailsAsync(ClientDetailsDto clientDetails, CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            await EnsureClientNotForbiddenAsync(clientDetails.ClientId, clientDetails.Realm, cancellationToken).ConfigureAwait(false);
            // Формируем объект для отправки в Keycloak API
            var updatePayload = BuildClientUpdatePayload(clientDetails);

            // Вызываем HTTP метод для обновления клиента
            await _httpClient.UpdateClientAsync(clientDetails.Realm, clientDetails.Id, updatePayload, cancellationToken);
            
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при обновлении деталей клиента {ClientId} в реалме {Realm}", clientDetails.ClientId, clientDetails.Realm);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            _metricsService.RecordOperationTime("KeycloakClientManagement.UpdateClientDetails", stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Удалить клиента из Keycloak
    /// </summary>
    public async Task DeleteClientAsync(string clientId, string realm, string internalId, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId не может быть пустым", nameof(clientId));
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        if (string.IsNullOrWhiteSpace(internalId))
            throw new ArgumentException("InternalId не может быть пустым", nameof(internalId));
        
        var stopwatch = Stopwatch.StartNew();
        try
        {
            await EnsureClientNotForbiddenAsync(clientId, realm, cancellationToken).ConfigureAwait(false);
            
            _logger.LogInformation("Начато удаление клиента {ClientId} (internal: {InternalId}) из реалма {Realm}", 
                clientId, internalId, realm);
            
            // Удаляем клиента через HTTP клиент
            await _httpClient.DeleteClientAsync(realm, internalId, cancellationToken);
            
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при удалении клиента {ClientId} из реалма {Realm}", clientId, realm);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            _metricsService.RecordOperationTime("KeycloakClientManagement.DeleteClient", stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Регенерация client secret
    /// </summary>
    public async Task<string?> RegenerateClientSecretAsync(string clientId, string realm, string internalId, CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            await EnsureClientNotForbiddenAsync(clientId, realm, cancellationToken).ConfigureAwait(false);
            var newSecret = await _httpClient.RegenerateClientSecretAsync(realm, internalId, cancellationToken);
            
            if (newSecret != null)
            {
                return newSecret;
            }
            
            _logger.LogWarning("Не удалось регенерировать secret для клиента {ClientId}", clientId);
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при регенерации secret клиента {ClientId}", clientId);
            return null;
        }
        finally
        {
            stopwatch.Stop();
            _metricsService.RecordOperationTime("KeycloakClientManagement.RegenerateClientSecret", stopwatch.ElapsedMilliseconds);
        }
    }

    private object BuildClientUpdatePayload(ClientDetailsDto clientDetails)
    {
        if (clientDetails == null)
            throw new ArgumentNullException(nameof(clientDetails));
        
        var redirectUris = SanitizeStringList(clientDetails.RedirectUris);
        var webOrigins = SanitizeStringList(clientDetails.WebOrigins);
        var attributes = BuildAttributesPayload(clientDetails.Attributes);

        var rootUrl = NormalizeUrl(clientDetails.RootUrl);
        var baseUrl = NormalizeUrl(clientDetails.BaseUrl);
        var adminUrl = NormalizeUrl(clientDetails.AdminUrl);

        return new
        {
            id = clientDetails.Id,
            clientId = clientDetails.ClientId,
            name = clientDetails.Name,
            description = clientDetails.Description,
            enabled = clientDetails.Enabled,
            protocol = clientDetails.Protocol,
            publicClient = clientDetails.AccessType == "public",
            bearerOnly = clientDetails.AccessType == "bearer-only",
            standardFlowEnabled = clientDetails.StandardFlow,
            implicitFlowEnabled = false,
            directAccessGrantsEnabled = clientDetails.DirectAccessGrantsEnabled,
            serviceAccountsEnabled = clientDetails.ServiceAccountsEnabled,
            authorizationServicesEnabled = clientDetails.AuthorizationServicesEnabled,
            frontchannelLogout = clientDetails.FrontChannelLogout,
            rootUrl,
            baseUrl,
            adminUrl,
            redirectUris,
            webOrigins,
            attributes
        };
    }

    private static List<string> SanitizeStringList(IEnumerable<string?>? source)
    {
        return source?
            .Select(value => value?.Trim())
            .Where(value => !string.IsNullOrEmpty(value))
            .Select(value => value!)
            .Distinct(StringComparer.Ordinal)
            .ToList()
            ?? new List<string>();
    }

    private static Dictionary<string, object> BuildAttributesPayload(Dictionary<string, List<string>>? attributes)
    {
        if (attributes == null || attributes.Count == 0)
        {
            return new Dictionary<string, object>();
        }

        var result = new Dictionary<string, object>(StringComparer.Ordinal);

        foreach (var kvp in attributes)
        {
            var key = kvp.Key?.Trim();
            if (string.IsNullOrEmpty(key))
            {
                continue;
            }

            var sourceValues = kvp.Value ?? new List<string>();
            var values = sourceValues
                .Select(value => value?.Trim())
                .Where(value => !string.IsNullOrEmpty(value))
                .Select(value => value!)
                .Distinct(StringComparer.Ordinal)
                .ToList();

            if (values is { Count: > 0 })
            {
                result[key] = values.Count == 1
                    ? values[0]
                    : values;
            }
        }

        return result;
    }

    private static string? NormalizeUrl(string? url)
    {
        if (string.IsNullOrWhiteSpace(url))
        {
            return null;
        }

        return url.Trim();
    }
}

