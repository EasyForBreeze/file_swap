using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading;
using new_assistant.Configuration;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// HTTP клиент для работы с Keycloak STAGE Admin API.
/// Обеспечивает автоматическую аутентификацию, кеширование токенов, ограничение одновременных запросов и мониторинг производительности.
/// </summary>
/// <remarks>
/// <para>Клиент автоматически управляет токенами доступа:</para>
/// <list type="bullet">
/// <item><description>Кеширует токены и переиспользует их до истечения срока действия</description></item>
/// <item><description>Автоматически обновляет токены при необходимости</description></item>
/// <item><description>Использует thread-safe механизмы для доступа к кешу токенов</description></item>
/// </list>
/// <para>Клиент ограничивает количество одновременных запросов для предотвращения перегрузки Keycloak сервера.</para>
/// <para>Все операции логируются и отправляют метрики производительности (если IPerformanceMetricsService зарегистрирован).</para>
/// </remarks>
public class KeycloakStageHttpClient : IKeycloakStageHttpClient
{
    private readonly HttpClient _httpClient;
    private readonly KeycloakStageSettings _settings;
    private readonly ILogger<KeycloakStageHttpClient> _logger;
    private readonly IPerformanceMetricsService? _metricsService;
    private readonly SemaphoreSlim _semaphore;
    private readonly SemaphoreSlim _tokenLock;
    private readonly object _tokenCacheLock = new object();
    private string? _cachedToken;
    private long _tokenExpiresAtTicks;
    private bool _disposed;
    
    // Метрики для отслеживания использования кеша токена
    private long _tokenCacheHits;
    private long _tokenCacheMisses;
    
    // Базовый URL для Admin API, сформированный один раз при инициализации
    private readonly string _adminApiBaseUrl;

    /// <summary>
    /// Инициализирует новый экземпляр KeycloakStageHttpClient.
    /// </summary>
    /// <param name="httpClient">HttpClient для выполнения HTTP запросов. Должен быть настроен через IHttpClientFactory.</param>
    /// <param name="settings">Настройки подключения к Keycloak (URL, realm, credentials и т.д.)</param>
    /// <param name="logger">Логгер для записи событий и ошибок</param>
    /// <param name="metricsService">Сервис метрик для мониторинга производительности (опционально)</param>
    /// <param name="skipConfigure">Если true, пропускает настройку HttpClient (используется при DI, когда HttpClient уже настроен)</param>
    /// <exception cref="ArgumentNullException">Если httpClient, settings или logger равны null</exception>
    /// <exception cref="ArgumentException">Если настройки содержат недопустимые значения (пустые строки, отрицательные числа и т.д.)</exception>
    public KeycloakStageHttpClient(
        HttpClient httpClient, 
        KeycloakStageSettings settings,
        ILogger<KeycloakStageHttpClient> logger,
        IPerformanceMetricsService? metricsService = null,
        bool skipConfigure = false)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _settings = settings ?? throw new ArgumentNullException(nameof(settings));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _metricsService = metricsService;
        
        if (_settings.MaxConcurrentRequests <= 0)
        {
            throw new ArgumentException("MaxConcurrentRequests must be greater than 0", nameof(settings));
        }
        
        if (_settings.RequestTimeoutSeconds <= 0)
        {
            throw new ArgumentException("RequestTimeoutSeconds must be greater than 0", nameof(settings));
        }
        
        if (string.IsNullOrWhiteSpace(_settings.BaseUrl))
        {
            throw new ArgumentException("BaseUrl cannot be null or empty", nameof(settings));
        }
        
        if (string.IsNullOrWhiteSpace(_settings.Realm))
        {
            throw new ArgumentException("Realm cannot be null or empty", nameof(settings));
        }
        
        if (string.IsNullOrWhiteSpace(_settings.ClientId))
        {
            throw new ArgumentException("ClientId cannot be null or empty", nameof(settings));
        }
        
        if (string.IsNullOrWhiteSpace(_settings.ClientSecret))
        {
            throw new ArgumentException("ClientSecret cannot be null or empty", nameof(settings));
        }
        
        _semaphore = new SemaphoreSlim(_settings.MaxConcurrentRequests, _settings.MaxConcurrentRequests);
        _tokenLock = new SemaphoreSlim(1, 1);
        _tokenExpiresAtTicks = DateTime.MinValue.Ticks;
        
        // Формируем базовый URL для Admin API с учетом UseLegacyAuthPath
        _adminApiBaseUrl = BuildAdminApiBaseUrl();
        
        if (!skipConfigure)
        {
            ConfigureHttpClient();
        }
    }

    /// <summary>
    /// Формирует базовый URL для Admin API с учетом UseLegacyAuthPath
    /// </summary>
    private string BuildAdminApiBaseUrl()
    {
        var baseUrl = _settings.BaseUrl.TrimEnd('/');
        
        // Если UseLegacyAuthPath = true, добавляем /auth перед Admin API и закрывающий слэш
        if (_settings.UseLegacyAuthPath && !baseUrl.EndsWith("/auth", StringComparison.OrdinalIgnoreCase))
        {
            return $"{baseUrl}/auth/";
        }
        
        // Если UseLegacyAuthPath = false, гарантируем закрывающий слэш
        return baseUrl.EndsWith("/") ? baseUrl : baseUrl + "/";
    }

    /// <summary>
    /// Настраивает HttpClient для работы с Keycloak Admin API.
    /// ВНИМАНИЕ: Этот метод вызывается только если skipConfigure = false.
    /// При использовании через DI (ServiceCollectionExtensions) HttpClient уже настроен,
    /// поэтому используется skipConfigure: true для избежания дублирования настроек.
    /// </summary>
    private void ConfigureHttpClient()
    {
        // Устанавливаем BaseAddress для Admin API endpoints
        _httpClient.BaseAddress = new Uri(_adminApiBaseUrl);
        _httpClient.Timeout = TimeSpan.FromSeconds(_settings.RequestTimeoutSeconds);
        _httpClient.DefaultRequestHeaders.Add("Accept", "application/json");
    }

    /// <summary>
    /// Безопасно освободить semaphore, игнорируя Dispose
    /// </summary>
    private void SafeReleaseSemaphore()
    {
        try
        {
            if (!_disposed && _semaphore != null)
            {
                _semaphore.Release();
            }
        }
        catch (ObjectDisposedException)
        {
            // Игнорируем, если объект уже disposed
        }
        catch (SemaphoreFullException ex)
        {
            // Это критическая ошибка - попытка освободить семафор больше раз, чем было получено
            _logger.LogError(ex, "SemaphoreFullException: Attempted to release semaphore more times than acquired");
        }
    }

    /// <summary>
    /// Безопасно освободить tokenLock, игнорируя Dispose
    /// </summary>
    private void SafeReleaseTokenLock()
    {
        try
        {
            if (!_disposed)
            {
                _tokenLock.Release();
            }
        }
        catch (ObjectDisposedException)
        {
            // Игнорируем, если объект уже disposed
        }
    }

    /// <summary>
    /// Безопасно получить семафор, возвращая false если объект disposed
    /// </summary>
    private async Task<bool> SafeWaitSemaphore(CancellationToken cancellationToken = default)
    {
        try
        {
            if (_disposed)
            {
                return false;
            }
            
            await _semaphore.WaitAsync(cancellationToken).ConfigureAwait(false);
            return true;
        }
        catch (ObjectDisposedException)
        {
            return false;
        }
        catch (OperationCanceledException)
        {
            // Token был отменен - это нормально, не логируем как ошибку
            return false;
        }
    }

    private async Task<string> GetAdminTokenAsync(CancellationToken cancellationToken)
    {
        var now = DateTime.UtcNow;
        string? cachedToken;
        long expiresAtTicks;
        
        // Атомарное чтение обеих переменных
        lock (_tokenCacheLock)
        {
            expiresAtTicks = _tokenExpiresAtTicks;
            cachedToken = _cachedToken;
        }
        
        var expiresAt = new DateTime(expiresAtTicks, DateTimeKind.Utc);

        if (cachedToken != null && now < expiresAt)
        {
            Interlocked.Increment(ref _tokenCacheHits);
            _logger.LogDebug("Using cached admin token (expires in {Seconds} seconds)", 
                (expiresAt - now).TotalSeconds);
            return cachedToken;
        }
        
        Interlocked.Increment(ref _tokenCacheMisses);

        _logger.LogInformation("Requesting new admin token from Keycloak");
        var tokenRequestStartTime = DateTime.UtcNow;

        await _tokenLock.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            // Double-check после получения lock
            lock (_tokenCacheLock)
            {
                expiresAtTicks = _tokenExpiresAtTicks;
                cachedToken = _cachedToken;
            }
            
            expiresAt = new DateTime(expiresAtTicks, DateTimeKind.Utc);
            if (cachedToken != null && now < expiresAt)
            {
                Interlocked.Decrement(ref _tokenCacheMisses); // Компенсируем предыдущий increment
                Interlocked.Increment(ref _tokenCacheHits);
                _logger.LogDebug("Using cached admin token after lock (expires in {Seconds} seconds)", 
                    (expiresAt - now).TotalSeconds);
                return cachedToken;
            }

            // Формируем token endpoint с учетом UseLegacyAuthPath и Realm из настроек
            // Для получения токена используем BaseUrl напрямую (не AdminApiBaseUrl)
            var authEndpoint = _settings.UseLegacyAuthPath 
                ? $"/auth/realms/{_settings.Realm}/protocol/openid-connect/token"
                : $"/realms/{_settings.Realm}/protocol/openid-connect/token";
            
            // Формируем абсолютный URL для получения токена
            var tokenFullUrl = $"{_settings.BaseUrl.TrimEnd('/')}{authEndpoint}";

            if (!Uri.TryCreate(tokenFullUrl, UriKind.Absolute, out var tokenUri))
            {
                RecordTokenRefreshError(tokenRequestStartTime, "InvalidTokenUrl", $"Invalid token URL: {tokenFullUrl}");
                _logger.LogError("Invalid token URL: {TokenUrl}", tokenFullUrl);
                throw new InvalidOperationException($"Invalid token URL: {tokenFullUrl}");
            }

            var content = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("grant_type", "client_credentials"),
                new KeyValuePair<string, string>("client_id", _settings.ClientId),
                new KeyValuePair<string, string>("client_secret", _settings.ClientSecret)
            });

            // Используем абсолютный URL для получения токена (не зависит от BaseAddress)
            var response = await _httpClient.PostAsync(tokenUri, content, cancellationToken).ConfigureAwait(false);

            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                RecordTokenRefreshError(tokenRequestStartTime, $"Http{(int)response.StatusCode}", 
                    $"Failed to obtain admin token. Status: {response.StatusCode}");
                
                _logger.LogError("Failed to obtain admin token. Status: {StatusCode}, Response: {ErrorContent}", 
                    response.StatusCode, errorContent);
                response.EnsureSuccessStatusCode(); // Бросит исключение с контекстом
            }

            var tokenResponse = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken: cancellationToken).ConfigureAwait(false);

            if (tokenResponse.ValueKind == JsonValueKind.Null || tokenResponse.ValueKind == JsonValueKind.Undefined)
            {
                RecordTokenRefreshError(tokenRequestStartTime, "NullTokenResponse", "Token response is null or undefined");
                _logger.LogError("Token response is null or undefined");
                throw new InvalidOperationException("Token response is null or undefined");
            }

            if (!tokenResponse.TryGetProperty("access_token", out var accessTokenElement))
            {
                RecordTokenRefreshError(tokenRequestStartTime, "MissingAccessToken", 
                    "Token response missing 'access_token' property");
                _logger.LogError("Token response does not contain 'access_token' property. Response: {Response}", 
                    tokenResponse.GetRawText());
                throw new InvalidOperationException("Token response missing 'access_token' property");
            }

            var accessToken = accessTokenElement.GetString();
            if (string.IsNullOrWhiteSpace(accessToken))
            {
                RecordTokenRefreshError(tokenRequestStartTime, "EmptyAccessToken", 
                    "Token response contains empty 'access_token'");
                _logger.LogError("Token response contains empty 'access_token'");
                throw new InvalidOperationException("Token response contains empty 'access_token'");
            }

            int expiresIn;
            if (!tokenResponse.TryGetProperty("expires_in", out var expiresInElement))
            {
                _logger.LogWarning("Token response does not contain 'expires_in', using default 300 seconds");
                expiresIn = 300; // Default
            }
            else
            {
                expiresIn = expiresInElement.GetInt32();
                if (expiresIn <= 0)
                {
                    _logger.LogWarning("Invalid 'expires_in' value: {ExpiresIn}, using default 300 seconds", expiresIn);
                    expiresIn = 300;
                }
            }

            var bufferSeconds = Math.Max(5, Math.Min(10, expiresIn / 10));
            expiresAt = DateTime.UtcNow.AddSeconds(expiresIn - bufferSeconds);
            
            // Атомарная запись (внутри lock не нужно использовать Interlocked)
            lock (_tokenCacheLock)
            {
                _tokenExpiresAtTicks = expiresAt.Ticks;
                _cachedToken = accessToken;
            }

            var tokenRequestDuration = DateTime.UtcNow - tokenRequestStartTime;
            var durationMs = (long)tokenRequestDuration.TotalMilliseconds;
            
            _metricsService?.RecordOperationTime("KeycloakStage.TokenRefresh", durationMs);
            _metricsService?.RecordSuccess("KeycloakStage.TokenRefresh");
            
            _logger.LogInformation("Successfully obtained admin token in {Duration}ms (expires in {ExpiresIn} seconds)", 
                durationMs, expiresIn);

            return accessToken;
        }
        catch (Exception ex)
        {
            // Записываем метрики для всех исключений (включая InvalidOperationException, если они не были обработаны выше)
            // Проверяем, были ли метрики уже записаны выше, чтобы не дублировать
            RecordTokenRefreshError(tokenRequestStartTime, ex.GetType().Name, ex.Message);
            
            // Прокидываем исключение дальше
            throw;
        }
        finally
        {
            SafeReleaseTokenLock();
        }
    }

    /// <summary>
    /// Записывает метрики ошибки для операции обновления токена.
    /// Вынесено в отдельный метод для устранения дублирования кода.
    /// </summary>
    /// <param name="startTime">Время начала операции</param>
    /// <param name="errorType">Тип ошибки для метрик</param>
    /// <param name="errorMessage">Сообщение об ошибке для логирования (опционально)</param>
    private void RecordTokenRefreshError(DateTime startTime, string errorType, string? errorMessage = null)
    {
        try
        {
            var duration = DateTime.UtcNow - startTime;
            var durationMs = (long)duration.TotalMilliseconds;
            
            _metricsService?.RecordOperationTime("KeycloakStage.TokenRefresh", durationMs);
            _metricsService?.RecordError("KeycloakStage.TokenRefresh", errorType);
            
            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                _logger.LogDebug("Token refresh error recorded: {ErrorType}, {ErrorMessage}", errorType, errorMessage);
            }
        }
        catch
        {
            // Игнорируем ошибки при записи метрик, чтобы не скрывать оригинальное исключение
        }
    }

    /// <summary>
    /// Выполняет GET запрос к указанному endpoint Keycloak Admin API.
    /// Автоматически добавляет Bearer токен аутентификации и обрабатывает ошибки.
    /// </summary>
    /// <typeparam name="T">Тип объекта для десериализации ответа. Используйте JsonElement для динамической обработки JSON.</typeparam>
    /// <param name="endpoint">Endpoint относительно базового URL Admin API (например, "admin/realms/my-realm/clients")</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>Десериализованный объект типа T или default(T), если запрос не выполнен или ответ пуст</returns>
    /// <exception cref="ArgumentException">Если endpoint пуст или null</exception>
    /// <exception cref="HttpRequestException">При ошибках HTTP запроса или таймауте</exception>
    /// <exception cref="JsonException">При ошибках десериализации JSON</exception>
    public async Task<T?> GetAsync<T>(string endpoint, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(endpoint))
        {
            throw new ArgumentException("Endpoint cannot be null or empty", nameof(endpoint));
        }

        const string operationName = "KeycloakStage.GET";
        var startTime = DateTime.UtcNow;

        var acquired = await SafeWaitSemaphore(cancellationToken);
        if (!acquired)
        {
            _logger.LogWarning("Semaphore disposed, cannot execute GET {Endpoint}", endpoint);
            return default;
        }
        
        try
        {
            var token = await GetAdminTokenAsync(cancellationToken).ConfigureAwait(false);
            
            var request = new HttpRequestMessage(HttpMethod.Get, endpoint);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

            try
            {
                var response = await _httpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
                response.EnsureSuccessStatusCode();

                try
                {
                    var result = await response.Content.ReadFromJsonAsync<T>(
                        cancellationToken: cancellationToken).ConfigureAwait(false);
                    
                    var duration = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
                    _metricsService?.RecordOperationTime(operationName, duration);
                    _metricsService?.RecordSuccess(operationName);
                    
                    return result;
                }
                catch (JsonException ex)
                {
                    var content = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                    _logger.LogError(ex, "Failed to deserialize response from {Endpoint}. Content: {Content}", 
                        endpoint, content);
                    
                    var duration = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
                    _metricsService?.RecordOperationTime(operationName, duration);
                    _metricsService?.RecordError(operationName, "JsonDeserializationError");
                    
                    throw;
                }
            }
            catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException || !cancellationToken.IsCancellationRequested)
            {
                var duration = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
                _metricsService?.RecordOperationTime(operationName, duration);
                _metricsService?.RecordError(operationName, "Timeout");
                
                _logger.LogWarning("Request to {Endpoint} timed out after {Timeout} seconds", 
                    endpoint, _settings.RequestTimeoutSeconds);
                throw new HttpRequestException($"Request to {endpoint} timed out", ex);
            }
            catch (Exception ex)
            {
                var duration = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
                _metricsService?.RecordOperationTime(operationName, duration);
                _metricsService?.RecordError(operationName, ex.GetType().Name);
                throw;
            }
        }
        finally
        {
            SafeReleaseSemaphore();
        }
    }

    /// <summary>
    /// Выполняет POST запрос к указанному endpoint Keycloak Admin API.
    /// Автоматически добавляет Bearer токен аутентификации и сериализует содержимое в JSON.
    /// </summary>
    /// <param name="endpoint">Endpoint относительно базового URL Admin API</param>
    /// <param name="content">Объект для сериализации в JSON тело запроса. Может быть null для пустого тела.</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>HttpResponseMessage с ответом сервера. ВАЖНО: вызывающий код должен вызвать Dispose() для освобождения ресурсов.</returns>
    /// <exception cref="ArgumentException">Если endpoint пуст или null</exception>
    /// <exception cref="HttpRequestException">При ошибках HTTP запроса или таймауте</exception>
    /// <remarks>
    /// ВАЖНО: Возвращаемый HttpResponseMessage должен быть освобожден вызывающим кодом через вызов Dispose() или использование using.
    /// Пример использования:
    /// <code>
    /// using var response = await client.PostAsync("admin/realms/my-realm/clients", clientData, cancellationToken);
    /// if (response.IsSuccessStatusCode) 
    /// {
    ///     var location = response.Headers.Location;
    ///     // обработка успешного ответа
    /// }
    /// </code>
    /// </remarks>
    public async Task<HttpResponseMessage> PostAsync(string endpoint, object? content, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(endpoint))
        {
            throw new ArgumentException("Endpoint cannot be null or empty", nameof(endpoint));
        }

        const string operationName = "KeycloakStage.POST";
        var startTime = DateTime.UtcNow;

        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            _logger.LogWarning("Semaphore disposed, cannot execute POST {Endpoint}", endpoint);
            return new HttpResponseMessage(System.Net.HttpStatusCode.ServiceUnavailable);
        }
        
        try
        {
            var token = await GetAdminTokenAsync(cancellationToken).ConfigureAwait(false);
            
            var request = new HttpRequestMessage(HttpMethod.Post, endpoint);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            
            if (content != null)
            {
                var json = JsonSerializer.Serialize(content);
                request.Content = new StringContent(json, Encoding.UTF8, "application/json");
            }

            try
            {
                var response = await _httpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
                
                var duration = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
                _metricsService?.RecordOperationTime(operationName, duration);
                
                if (response.IsSuccessStatusCode)
                {
                    _metricsService?.RecordSuccess(operationName);
                }
                else
                {
                    _metricsService?.RecordError(operationName, $"Http{(int)response.StatusCode}");
                }
                
                return response;
            }
            catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException || !cancellationToken.IsCancellationRequested)
            {
                var duration = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
                _metricsService?.RecordOperationTime(operationName, duration);
                _metricsService?.RecordError(operationName, "Timeout");
                
                _logger.LogWarning("Request to {Endpoint} timed out after {Timeout} seconds", 
                    endpoint, _settings.RequestTimeoutSeconds);
                throw new HttpRequestException($"Request to {endpoint} timed out", ex);
            }
            catch (Exception ex)
            {
                var duration = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
                _metricsService?.RecordOperationTime(operationName, duration);
                _metricsService?.RecordError(operationName, ex.GetType().Name);
                throw;
            }
        }
        finally
        {
            SafeReleaseSemaphore();
        }
    }

    /// <summary>
    /// Выполняет PUT запрос к указанному endpoint Keycloak Admin API.
    /// Автоматически добавляет Bearer токен аутентификации и сериализует содержимое в JSON.
    /// </summary>
    /// <param name="endpoint">Endpoint относительно базового URL Admin API</param>
    /// <param name="content">Объект для сериализации в JSON тело запроса. Не может быть null.</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>HttpResponseMessage с ответом сервера. ВАЖНО: вызывающий код должен вызвать Dispose() для освобождения ресурсов.</returns>
    /// <exception cref="ArgumentException">Если endpoint пуст или null</exception>
    /// <exception cref="ArgumentNullException">Если content равен null</exception>
    /// <exception cref="HttpRequestException">При ошибках HTTP запроса или таймауте</exception>
    /// <remarks>
    /// ВАЖНО: Возвращаемый HttpResponseMessage должен быть освобожден вызывающим кодом через вызов Dispose() или использование using.
    /// Пример использования:
    /// <code>
    /// using var response = await client.PutAsync($"admin/realms/my-realm/clients/{clientId}", updateData, cancellationToken);
    /// response.EnsureSuccessStatusCode();
    /// </code>
    /// </remarks>
    public async Task<HttpResponseMessage> PutAsync(string endpoint, object content, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(endpoint))
        {
            throw new ArgumentException("Endpoint cannot be null or empty", nameof(endpoint));
        }

        if (content == null)
        {
            throw new ArgumentNullException(nameof(content));
        }

        const string operationName = "KeycloakStage.PUT";
        var startTime = DateTime.UtcNow;

        var acquired = await SafeWaitSemaphore(cancellationToken);
        if (!acquired)
        {
            _logger.LogWarning("Semaphore disposed, cannot execute PUT {Endpoint}", endpoint);
            return new HttpResponseMessage(System.Net.HttpStatusCode.ServiceUnavailable);
        }
        
        try
        {
            var token = await GetAdminTokenAsync(cancellationToken).ConfigureAwait(false);
            
            var request = new HttpRequestMessage(HttpMethod.Put, endpoint);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            
            var json = JsonSerializer.Serialize(content);
            request.Content = new StringContent(json, Encoding.UTF8, "application/json");

            try
            {
                var response = await _httpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
                
                var duration = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
                _metricsService?.RecordOperationTime(operationName, duration);
                
                if (response.IsSuccessStatusCode)
                {
                    _metricsService?.RecordSuccess(operationName);
                }
                else
                {
                    _metricsService?.RecordError(operationName, $"Http{(int)response.StatusCode}");
                }
                
                return response;
            }
            catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException || !cancellationToken.IsCancellationRequested)
            {
                var duration = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
                _metricsService?.RecordOperationTime(operationName, duration);
                _metricsService?.RecordError(operationName, "Timeout");
                
                _logger.LogWarning("Request to {Endpoint} timed out after {Timeout} seconds", 
                    endpoint, _settings.RequestTimeoutSeconds);
                throw new HttpRequestException($"Request to {endpoint} timed out", ex);
            }
            catch (Exception ex)
            {
                var duration = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
                _metricsService?.RecordOperationTime(operationName, duration);
                _metricsService?.RecordError(operationName, ex.GetType().Name);
                throw;
            }
        }
        finally
        {
            SafeReleaseSemaphore();
        }
    }

    /// <summary>
    /// Выполняет HEAD запрос к указанному endpoint Keycloak Admin API.
    /// Используется для проверки существования ресурса без загрузки его содержимого.
    /// Автоматически добавляет Bearer токен аутентификации.
    /// </summary>
    /// <param name="endpoint">Endpoint относительно базового URL Admin API</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>true, если ресурс существует (HTTP статус 2xx), иначе false. Возвращает false также при ошибках сети или таймаутах.</returns>
    /// <exception cref="ArgumentException">Если endpoint пуст или null</exception>
    public async Task<bool> HeadAsync(string endpoint, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(endpoint))
        {
            throw new ArgumentException("Endpoint cannot be null or empty", nameof(endpoint));
        }

        const string operationName = "KeycloakStage.HEAD";
        var startTime = DateTime.UtcNow;

        var acquired = await SafeWaitSemaphore(cancellationToken);
        if (!acquired)
        {
            _logger.LogWarning("Semaphore disposed, cannot execute HEAD {Endpoint}", endpoint);
            return false;
        }
        
        try
        {
            var token = await GetAdminTokenAsync(cancellationToken).ConfigureAwait(false);
            
            var request = new HttpRequestMessage(HttpMethod.Head, endpoint);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            var success = response.IsSuccessStatusCode;
            
            var duration = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
            _metricsService?.RecordOperationTime(operationName, duration);
            
            if (success)
            {
                _metricsService?.RecordSuccess(operationName);
            }
            else
            {
                _metricsService?.RecordError(operationName, $"Http{(int)response.StatusCode}");
            }
            
            return success;
        }
        catch (HttpRequestException ex)
        {
            var duration = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
            _metricsService?.RecordOperationTime(operationName, duration);
            _metricsService?.RecordError(operationName, "HttpRequestException");
            
            _logger.LogWarning(ex, "HTTP error during HEAD request to {Endpoint}", endpoint);
            return false;
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException || !cancellationToken.IsCancellationRequested)
        {
            var duration = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
            _metricsService?.RecordOperationTime(operationName, duration);
            _metricsService?.RecordError(operationName, "Timeout");
            
            _logger.LogWarning("Timeout during HEAD request to {Endpoint}", endpoint);
            return false;
        }
        catch (Exception ex)
        {
            var duration = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
            _metricsService?.RecordOperationTime(operationName, duration);
            _metricsService?.RecordError(operationName, ex.GetType().Name);
            
            _logger.LogError(ex, "Unexpected error during HEAD request to {Endpoint}", endpoint);
            return false;
        }
        finally
        {
            SafeReleaseSemaphore();
        }
    }

    /// <summary>
    /// Получает статистику использования кеша токенов.
    /// </summary>
    /// <returns>Объект с информацией о количестве попаданий и промахов кеша</returns>
    public TokenCacheStatistics GetTokenCacheStatistics()
    {
        return new TokenCacheStatistics
        {
            CacheHits = Interlocked.Read(ref _tokenCacheHits),
            CacheMisses = Interlocked.Read(ref _tokenCacheMisses)
        };
    }

    /// <summary>
    /// Освобождает все ресурсы, используемые KeycloakStageHttpClient.
    /// </summary>
    /// <remarks>
    /// ВАЖНО: HttpClient, переданный в конструктор, НЕ освобождается этим методом,
    /// так как он управляется IHttpClientFactory.
    /// </remarks>
    public void Dispose()
    {
        if (!_disposed)
        {
            // НЕ dispose-им _httpClient, так как он управляется IHttpClientFactory
            _semaphore?.Dispose();
            _tokenLock?.Dispose();
            _disposed = true;
        }
    }
}

