using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using new_assistant.Configuration;

namespace new_assistant.Infrastructure.HealthChecks;

/// <summary>
/// Health check для проверки доступности SQLite баз данных
/// </summary>
public class SqliteHealthCheck : IHealthCheck
{
    private readonly DataPathsSettings _dataPathsSettings;
    private readonly ILogger<SqliteHealthCheck> _logger;

    public SqliteHealthCheck(DataPathsSettings dataPathsSettings, ILogger<SqliteHealthCheck> logger)
    {
        _dataPathsSettings = dataPathsSettings;
        _logger = logger;
    }

    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        var databases = new Dictionary<string, string>
        {
            { "audit", _dataPathsSettings.GetAuditDbPath() },
            { "forbidden_clients", _dataPathsSettings.GetForbiddenClientsDbPath() },
            { "wiki_pages", _dataPathsSettings.GetWikiPagesDbPath() },
            { "ownership", _dataPathsSettings.GetOwnershipDbPath() }
        };

        var results = new Dictionary<string, object>();
        var unhealthyDatabases = new List<string>();
        var totalSize = 0L;

        foreach (var (name, path) in databases)
        {
            try
            {
                var connectionString = $"Data Source={path};Mode=ReadOnly";
                
                await using var connection = new SqliteConnection(connectionString);
                await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
                
                // Проверяем что БД читаемая
                await using var command = connection.CreateCommand();
                command.CommandText = "SELECT 1";
                await command.ExecuteScalarAsync(cancellationToken).ConfigureAwait(false);
                
                // Получаем размер файла
                var fileInfo = new FileInfo(path);
                var size = fileInfo.Exists ? fileInfo.Length : 0;
                totalSize += size;
                
                results[name] = new
                {
                    status = "healthy",
                    size = FormatBytes(size),
                    path = path
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка проверки БД {DatabaseName}", name);
                unhealthyDatabases.Add(name);
                results[name] = new
                {
                    status = "unhealthy",
                    error = ex.Message
                };
            }
        }

        results["totalSize"] = FormatBytes(totalSize);
        results["timestamp"] = DateTime.UtcNow;

        if (unhealthyDatabases.Any())
        {
            return HealthCheckResult.Unhealthy(
                $"SQLite проблемы: {string.Join(", ", unhealthyDatabases)}",
                data: results);
        }

        return HealthCheckResult.Healthy(
            $"Все SQLite базы данных ({databases.Count}) работают нормально",
            data: results);
    }

    private static string FormatBytes(long bytes)
    {
        string[] sizes = { "B", "KB", "MB", "GB" };
        double len = bytes;
        int order = 0;
        while (len >= 1024 && order < sizes.Length - 1)
        {
            order++;
            len /= 1024;
        }
        return $"{len:0.##} {sizes[order]}";
    }
}

