using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using new_assistant.Configuration;
using System.IO;

namespace new_assistant.Controllers;

/// <summary>
/// Контроллер для работы с логами приложения
/// </summary>
[Authorize(Roles = "assistant-admin")]
[ApiController]
[Route("api/logs")]
[EnableRateLimiting("admin")]
public class LogsController : ControllerBase
{
    private readonly DataPathsSettings _dataPathsSettings;
    private readonly ILogger<LogsController> _logger;

    public LogsController(
        DataPathsSettings dataPathsSettings,
        ILogger<LogsController> logger)
    {
        _dataPathsSettings = dataPathsSettings;
        _logger = logger;
    }

    /// <summary>
    /// Скачивание файла лога
    /// </summary>
    /// <param name="file">Имя файла лога</param>
    /// <returns>Файл лога</returns>
    [HttpGet("download")]
    public IActionResult DownloadLogFile([FromQuery] string file)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(file))
            {
                _logger.LogWarning("Попытка скачивания лога без указания имени файла");
                return BadRequest("Имя файла не указано");
            }

            // Защита от path traversal атак
            if (file.Contains("..") || file.Contains("/") || file.Contains("\\"))
            {
                _logger.LogWarning("Попытка скачивания файла с недопустимым именем: {FileName}", file);
                return BadRequest("Недопустимое имя файла");
            }

            var logsDirectory = _dataPathsSettings.GetLogsDirectoryPath();
            var filePath = Path.Combine(logsDirectory, file);

            if (!System.IO.File.Exists(filePath))
            {
                _logger.LogWarning("Файл лога не найден: {FileName}", file);
                return NotFound($"Файл {file} не найден");
            }

            // Проверяем, что файл находится в директории логов
            if (!filePath.StartsWith(logsDirectory, StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogWarning("Попытка доступа к файлу вне директории логов: {FilePath}", filePath);
                return Forbid();
            }

            _logger.LogInformation("Скачивание файла лога {FileName} пользователем {User}", 
                file, User.Identity?.Name ?? "Unknown");

            // Используем streaming для больших файлов вместо чтения всего файла в память
            var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read, 4096, FileOptions.SequentialScan);
            return File(fileStream, "text/plain", file);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при скачивании файла лога {FileName}", file);
            return StatusCode(500, "Ошибка при скачивании файла");
        }
    }
}

