using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using new_assistant.Core.Interfaces;

namespace new_assistant.Controllers;

/// <summary>
/// Контроллер для работы с архивами учетных данных клиентов
/// </summary>
[Authorize(Roles = "assistant-admin")]
[ApiController]
[Route("api/client")]
[EnableRateLimiting("admin")]
public class ClientArchiveController : ControllerBase
{
    private readonly IClientArchiveService _archiveService;
    private readonly ILogger<ClientArchiveController> _logger;

    public ClientArchiveController(
        IClientArchiveService archiveService,
        ILogger<ClientArchiveController> logger)
    {
        _archiveService = archiveService;
        _logger = logger;
    }

    /// <summary>
    /// Скачивание архива с учетными данными клиента
    /// </summary>
    /// <param name="clientId">Client ID</param>
    /// <returns>Файл архива</returns>
    [HttpGet("download-archive")]
    public IActionResult DownloadArchive([FromQuery] string clientId)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(clientId))
            {
                _logger.LogWarning("Попытка скачивания архива без указания Client ID");
                return BadRequest("Client ID не указан");
            }

            var archivePath = _archiveService.GetArchivePath(clientId);

            if (string.IsNullOrEmpty(archivePath))
            {
                _logger.LogWarning("Архив для клиента {ClientId} не найден", clientId);
                return NotFound($"Архив для клиента {clientId} не найден");
            }

            var fileBytes = System.IO.File.ReadAllBytes(archivePath);
            var fileName = $"{clientId}_credentials.zip";

            _logger.LogWarning("Скачивание архива для клиента {ClientId} пользователем {User}", 
                User.Identity?.Name ?? "Unknown", clientId);

            return File(fileBytes, "application/zip", fileName);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при скачивании архива для клиента {ClientId}", clientId);
            return StatusCode(500, "Ошибка при скачивании архива");
        }
    }

    /// <summary>
    /// Удаление архива клиента (для очистки после скачивания)
    /// </summary>
    /// <param name="clientId">Client ID</param>
    /// <returns>Результат операции</returns>
    [HttpDelete("archive/{clientId}")]
    public IActionResult DeleteArchive(string clientId)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(clientId))
            {
                return BadRequest("Client ID не указан");
            }

            var archivePath = _archiveService.GetArchivePath(clientId);

            if (string.IsNullOrEmpty(archivePath))
            {
                return NotFound($"Архив для клиента {clientId} не найден");
            }

            _archiveService.CleanupFiles(archivePath);

            _logger.LogWarning("Архив для клиента {ClientId} удален пользователем {User}", 
                clientId, User.Identity?.Name ?? "Unknown");

            return Ok();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при удалении архива для клиента {ClientId}", clientId);
            return StatusCode(500, "Ошибка при удалении архива");
        }
    }
}

