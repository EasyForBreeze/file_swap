using Microsoft.AspNetCore.Mvc;
using new_assistant.Core.Interfaces;
using new_assistant.Core.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.RateLimiting;

namespace new_assistant.Controllers;

[ApiController]
[Route("api/[controller]")]
[EnableRateLimiting("api")]
public class ClientController : ControllerBase
{
    private readonly IKeycloakAdminService _keycloakAdminService;
    private readonly ILogger<ClientController> _logger;

    public ClientController(IKeycloakAdminService keycloakAdminService, ILogger<ClientController> logger)
    {
        _keycloakAdminService = keycloakAdminService;
        _logger = logger;
    }

    /// <summary>
    /// Создать нового клиента в Keycloak
    /// </summary>
    /// <param name="request">Данные для создания клиента</param>
    /// <returns>Результат создания клиента</returns>
    [HttpPost]
    [Authorize(Roles = "assistant-admin")]
    public async Task<ActionResult<CreateClientResponse>> CreateClient([FromBody] CreateClientRequestDto request)
    {
        try
        {

            var validationResult = ValidateRequest(request);
            if (!validationResult.IsValid)
            {
                _logger.LogWarning($"Ошибка валидации при создании клиента: {validationResult.ErrorMessage}");
                return BadRequest(new CreateClientResponse { Success = false, ErrorMessage = validationResult.ErrorMessage });
            }

                   // Проверяем, существует ли клиент с таким ClientId
                   var existingClient = await _keycloakAdminService.GetClientDetailsAsync(request.ClientId, request.Realm);
                   if (existingClient != null)
                   {
                       _logger.LogWarning($"Попытка создать клиента с существующим ClientId: {request.ClientId} в реалме {request.Realm}");
                       return BadRequest(new CreateClientResponse { Success = false, ErrorMessage = $"Клиент с ClientId '{request.ClientId}' уже существует в реалме '{request.Realm}'." });
                   }

            var clientInternalId = await _keycloakAdminService.CreateClientAsync(request, HttpContext.RequestAborted);

            return Ok(new CreateClientResponse { Success = true, ClientId = request.ClientId, KeycloakInternalId = clientInternalId });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Ошибка при создании клиента {request.ClientId} в реалме {request.Realm}");
            return StatusCode(500, new CreateClientResponse { Success = false, ErrorMessage = $"Внутренняя ошибка сервера: {ex.Message}" });
        }
    }

    /// <summary>
    /// Валидация запроса создания клиента
    /// </summary>
    private ValidationResult ValidateRequest(CreateClientRequestDto request)
    {
        if (string.IsNullOrWhiteSpace(request.Realm))
        {
            return new ValidationResult { IsValid = false, ErrorMessage = "Реалм не может быть пустым" };
        }
        if (string.IsNullOrWhiteSpace(request.ClientId))
        {
            return new ValidationResult { IsValid = false, ErrorMessage = "Client ID не может быть пустым" };
        }
        if (!System.Text.RegularExpressions.Regex.IsMatch(request.ClientId, @"^[a-zA-Z0-9_-]+$"))
        {
            return new ValidationResult { IsValid = false, ErrorMessage = "Client ID может содержать только буквы, цифры, дефисы и подчеркивания." };
        }
        if (request.StandardFlow && (!request.RedirectUris.Any() || request.RedirectUris.Any(string.IsNullOrWhiteSpace)))
        {
            return new ValidationResult { IsValid = false, ErrorMessage = "Для Standard Flow необходимо указать хотя бы один Redirect URI." };
        }
        if (string.IsNullOrWhiteSpace(request.OwnerSystemName))
        {
            return new ValidationResult { IsValid = false, ErrorMessage = "Название системы-владельца не может быть пустым." };
        }
        if (!string.IsNullOrWhiteSpace(request.OwnerSystemUrl) && !Uri.IsWellFormedUriString(request.OwnerSystemUrl, UriKind.Absolute))
        {
            return new ValidationResult { IsValid = false, ErrorMessage = "Некорректный формат URL системы-владельца." };
        }
        return new ValidationResult { IsValid = true };
    }

    private class ValidationResult
    {
        public bool IsValid { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
