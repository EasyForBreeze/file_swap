using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using new_assistant.Infrastructure.Extensions;
using System.IO;

var builder = WebApplication.CreateBuilder(args);

// Загрузка дополнительного конфигурационного файла
builder.Configuration.AddJsonFile(
    Path.Combine(builder.Environment.ContentRootPath, "token-exchange.json"),
    optional: true,
    reloadOnChange: true);

// Конфигурация Kestrel для HTTP/HTTPS
builder.WebHost.ConfigureKestrelServer(builder.Configuration);

// Настройка Serilog для структурированного логирования
builder.Host.ConfigureSerilog();

// Валидация критических настроек на раннем этапе
new_assistant.Infrastructure.Extensions.ConfigurationExtensions.ValidateCriticalSettings(builder.Configuration);

// Регистрация настроек через IOptions<T>
builder.Services.AddApplicationSettings(builder.Configuration);

// Регистрация базовых сервисов
builder.Services.AddBaseServices(builder.Configuration);

// Регистрация Forbidden Client сервисов (должно быть перед Keycloak, так как KeycloakAdminService зависит от него)
builder.Services.AddForbiddenClientServices();

// Регистрация Keycloak сервисов
builder.Services.AddKeycloakServices(builder.Configuration);

// Регистрация Keycloak Stage сервисов
builder.Services.AddKeycloakStageServices(builder.Configuration);

// Регистрация User Management сервисов
builder.Services.AddUserManagementServices(builder.Configuration);

// Регистрация Token Exchange сервисов
builder.Services.AddTokenExchangeServices(builder.Configuration);

// Регистрация Confluence сервисов
builder.Services.AddConfluenceServices();

// Регистрация Audit сервисов
builder.Services.AddAuditServices();

// Регистрация дополнительных сервисов приложения
builder.Services.AddApplicationServices();

// Регистрация фоновых сервисов
builder.Services.AddBackgroundServices();

// Регистрация FluentValidation
builder.Services.AddValidationServices();

// Регистрация Blazor Server и Razor Pages
builder.Services.AddBlazorServices(builder.Environment);

// Регистрация Health Checks
builder.Services.AddHealthCheckServices();

// Настройка Cookie Policy
builder.Services.AddCookiePolicyConfiguration(builder.Environment);

// Настройка Data Protection
builder.Services.AddDataProtectionConfiguration(builder.Configuration);

// Настройка Rate Limiting
builder.Services.AddRateLimitingConfiguration(builder.Configuration);

// Настройка Forwarded Headers
builder.Services.AddForwardedHeadersConfiguration(builder.Configuration, builder.Environment);

// Настройка Authentication (Cookie + OpenID Connect)
builder.Services.AddAuthenticationConfiguration(builder.Configuration, builder.Environment);

var app = builder.Build();

// Настройка Exception Handling и Correlation ID
app.UseCustomExceptionHandling();

// Настройка Forwarded Headers
app.UseCustomForwardedHeaders();

// Настройка HTTPS и HSTS
app.UseCustomHttps(builder.Environment);

// Настройка Cookie Policy
app.UseCustomCookiePolicy();

// Настройка Rate Limiting
app.UseCustomRateLimiting();

// Настройка Authentication и Authorization
app.UseCustomAuthentication();

// Настройка Security Headers (CSP, X-Frame-Options, и т.д.)
// Должен быть после Authentication, но до Routing для корректной работы CSP nonce
app.UseCustomSecurityHeaders();

// Настройка маршрутизации для Blazor и API
app.UseCustomRouting();

// Настройка cleanup для Singleton сервисов с IDisposable
// Регистрирует обработчик ApplicationStopping для корректного освобождения ресурсов
app.UseCustomCleanup();

app.Run();

