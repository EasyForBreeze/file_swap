using System;
using System.Collections.Generic;

namespace new_assistant.Configuration;

public class TokenExchangeSettings
{
    public List<TokenExchangeRealmSettings> Realms { get; set; } = new();
    
    /// <summary>
    /// Запас времени в секундах для проверки истечения токена (по умолчанию 15)
    /// </summary>
    public int SafetyWindowSeconds { get; set; } = 15;
    
    /// <summary>
    /// Максимальный размер кэша токенов (по умолчанию 100)
    /// </summary>
    public int MaxCacheSize { get; set; } = 100;
    
    /// <summary>
    /// TTL для токенов в кэше по умолчанию (по умолчанию 30 минут)
    /// </summary>
    public TimeSpan DefaultTokenCacheTtl { get; set; } = TimeSpan.FromMinutes(30);
    
    /// <summary>
    /// Интервал очистки неиспользуемых семафоров (по умолчанию 1 час)
    /// </summary>
    public TimeSpan SemaphoreCleanupInterval { get; set; } = TimeSpan.FromHours(1);
    
    /// <summary>
    /// Максимальное время простоя семафора перед удалением (по умолчанию 24 часа)
    /// </summary>
    public TimeSpan SemaphoreMaxIdleTime { get; set; } = TimeSpan.FromHours(24);
    
    /// <summary>
    /// Максимальное количество повторных попыток token exchange (по умолчанию 2, т.е. 3 попытки всего)
    /// </summary>
    public int MaxRetryAttempts { get; set; } = 2;
    
    /// <summary>
    /// Начальная задержка перед повторной попыткой (по умолчанию 1 секунда)
    /// </summary>
    public TimeSpan InitialRetryDelay { get; set; } = TimeSpan.FromSeconds(1);
    
    /// <summary>
    /// Использовать экспоненциальную задержку между повторными попытками (по умолчанию true)
    /// </summary>
    public bool UseExponentialBackoff { get; set; } = true;
    
    /// <summary>
    /// Включить circuit breaker для защиты от каскадных сбоев (по умолчанию true)
    /// </summary>
    public bool EnableCircuitBreaker { get; set; } = true;
    
    /// <summary>
    /// Количество последовательных ошибок для открытия circuit breaker (по умолчанию 5)
    /// </summary>
    public int CircuitBreakerFailureThreshold { get; set; } = 5;
    
    /// <summary>
    /// Время, в течение которого circuit breaker остается открытым (по умолчанию 5 минут)
    /// </summary>
    public TimeSpan CircuitBreakerOpenDuration { get; set; } = TimeSpan.FromMinutes(5);
    
    /// <summary>
    /// Таймаут запросов в секундах (по умолчанию 30)
    /// </summary>
    public int RequestTimeoutSeconds { get; set; } = 30;
}

public class TokenExchangeRealmSettings
{
    public string Realm { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string ClientSecret { get; set; } = string.Empty;
    public string SubjectIssuer { get; set; } = string.Empty;
    public string TokenEndpoint { get; set; } = string.Empty;
    
    /// <summary>
    /// Переопределение TTL кэша для конкретного реалма (если не указано, используется DefaultTokenCacheTtl)
    /// </summary>
    public TimeSpan? CacheTtl { get; set; }
}

