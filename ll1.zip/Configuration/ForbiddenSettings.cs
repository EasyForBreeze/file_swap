namespace new_assistant.Configuration;

public class ForbiddenSettings
{
    public List<string> AlwaysForbiddenClientIds { get; set; } = new();
    
    /// <summary>
    /// Время жизни кэша запрещенных клиентов
    /// </summary>
    public TimeSpan CacheExpiration { get; set; } = TimeSpan.FromMinutes(5);
    
    /// <summary>
    /// Максимальное количество элементов для кэширования
    /// </summary>
    public int MaxCachedItems { get; set; } = 10000;
}


