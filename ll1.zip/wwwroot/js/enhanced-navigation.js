// КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ: Фиксируем ширину ВСЕХ контейнеров анимации
function fixAnimationContainerWidth() {
    // Получаем МАКСИМАЛЬНУЮ ширину viewport (с учетом возможного скроллбара)
    const viewportWidth = Math.max(
        document.documentElement.clientWidth,
        window.innerWidth || 0
    );
    
    // Находим ВСЕ контейнеры с фоновой анимацией
    const containers = [
        document.getElementById('main-floating-background'),
        ...document.querySelectorAll('.fixed.inset-0.overflow-hidden.pointer-events-none.z-0')
    ].filter(el => el !== null);
    
    console.log(`[Animation Fix] Found ${containers.length} animation containers`);
    
    containers.forEach((container, index) => {
        // Устанавливаем ФИКСИРОВАННУЮ ширину в пикселях
        container.style.width = viewportWidth + 'px';
        container.style.maxWidth = viewportWidth + 'px';
        container.style.left = '0';
        container.style.right = 'auto';
        
        console.log(`[Animation Fix] Container ${index + 1} width fixed to ${viewportWidth}px`);
    });
}

// Вызываем при загрузке DOM
document.addEventListener('DOMContentLoaded', fixAnimationContainerWidth);

// Вызываем после каждого Blazor рендера
if (typeof Blazor !== 'undefined') {
    Blazor.addEventListener('enhancedload', fixAnimationContainerWidth);
}

// Настройка плавных переходов
Blazor.addEventListener('enhancedload', function () {
    // Добавляем класс для плавного появления
    const mainContent = document.querySelector('main');
    if (mainContent) {
        mainContent.classList.add('page-transition-enter');
        setTimeout(() => {
            mainContent.classList.remove('page-transition-enter');
        }, 400);
    }
    
    // Сбрасываем анимацию для элементов с классом animate-stagger
    // чтобы CSS анимации работали корректно
    const staggerElements = document.querySelectorAll('.animate-stagger');
    staggerElements.forEach((element) => {
        // Удаляем inline стили, чтобы CSS анимации работали
        element.style.opacity = '';
    });
});

// Обработка начала навигации
Blazor.addEventListener('enhancedloadstart', function () {
    const mainContent = document.querySelector('main');
    if (mainContent) {
        mainContent.classList.add('page-transition-exit');
    }
});

// Плавная прокрутка к началу страницы при навигации
Blazor.addEventListener('enhancedload', function () {
    setTimeout(() => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    }, 50);
});

// Функция для переключения видимости пароля
window.togglePasswordVisibility = function(inputId) {
    const input = document.getElementById(inputId);
    if (input) {
        input.type = input.type === 'password' ? 'text' : 'password';
    }
};

// Функция для плавного скролла к элементу
window.scrollToElement = function(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
};

// Функция для открытия URL в новой вкладке (CSP-безопасно через создание ссылки)
window.openUrlInNewTab = function(url) {
    const link = document.createElement('a');
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};

