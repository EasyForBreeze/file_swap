using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using new_assistant.Core.Interfaces;
using System.Text.Json;

namespace new_assistant.Controllers;

/// <summary>
/// Контроллер для управления доступом пользователей к клиентам
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "assistant-admin")]
[EnableRateLimiting("admin")]
public class ClientAccessController : ControllerBase
{
    private readonly IKeycloakAdminService _keycloakService;
    private readonly IClientOwnershipService _ownershipService;
    private readonly ILogger<ClientAccessController> _logger;

    public ClientAccessController(
        IKeycloakAdminService keycloakService,
        IClientOwnershipService ownershipService,
        ILogger<ClientAccessController> logger)
    {
        _keycloakService = keycloakService;
        _ownershipService = ownershipService;
        _logger = logger;
    }

    /// <summary>
    /// Поиск пользователей в KeyCloak по username
    /// </summary>
    [HttpGet("search-users")]
    public async Task<IActionResult> SearchUsers([FromQuery] string query, [FromQuery] string? realm = null)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(query) || query.Length < 2)
            {
                return Ok(new List<UserSearchResult>());
            }

            // Если реалм не указан, используем реалм аутентификации из настроек
            var searchRealm = realm ?? "internal-bank-idm"; // Default realm для поиска пользователей
            
            var users = await _keycloakService.SearchUsersAsync(query, searchRealm);
            return Ok(users);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при поиске пользователей: {Query}", query);
            return StatusCode(500, new { error = "Ошибка при поиске пользователей" });
        }
    }

    /// <summary>
    /// Поиск клиентов по Client ID
    /// </summary>
    [HttpGet("search-clients")]
    public async Task<IActionResult> SearchClients([FromQuery] string query, [FromQuery] string? realm = null)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(query) || query.Length < 2)
            {
                return Ok(new List<ClientSearchResult>());
            }

            var clients = await _keycloakService.SearchClientsByIdAsync(query, realm);
            return Ok(clients);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при поиске клиентов: {Query}", query);
            return StatusCode(500, new { error = "Ошибка при поиске клиентов" });
        }
    }

    /// <summary>
    /// Получить список клиентов, назначенных пользователю
    /// </summary>
    [HttpGet("user-clients/{username}")]
    public async Task<IActionResult> GetUserClients(string username)
    {
        try
        {
            var userClients = await _ownershipService.GetAllUserClientsAsync(username);
            return Ok(userClients);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при получении клиентов пользователя: {Username}", username);
            return StatusCode(500, new { error = "Ошибка при получении клиентов пользователя" });
        }
    }

    /// <summary>
    /// Назначить клиента пользователю
    /// </summary>
    [HttpPost("assign")]
    public async Task<IActionResult> AssignClient([FromBody] AssignClientRequest request)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(request.Username) || 
                string.IsNullOrWhiteSpace(request.ClientId) || 
                string.IsNullOrWhiteSpace(request.Realm))
            {
                return BadRequest(new { error = "Все поля обязательны для заполнения" });
            }

            // Проверяем, не назначен ли клиент уже этому пользователю
            var existingClients = await _ownershipService.GetUserClientsAsync(request.Username, request.Realm);
            if (existingClients.Contains(request.ClientId))
            {
                return BadRequest(new { error = "Этот клиент уже назначен данному пользователю" });
            }

            // Назначаем доступ
            await _ownershipService.GrantAccessAsync(request.Username, request.ClientId, request.Realm);

            _logger.LogWarning("Назначен доступ к клиенту {ClientId} пользователю {Username} в реалме {Realm}", 
                request.ClientId, request.Username, request.Realm);

            return Ok(new { success = true, message = "Доступ успешно назначен" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при назначении клиента {ClientId} пользователю {Username}", 
                request.ClientId, request.Username);
            return StatusCode(500, new { error = "Ошибка при назначении доступа" });
        }
    }

    /// <summary>
    /// Удалить доступ пользователя к клиенту
    /// </summary>
    [HttpDelete("revoke")]
    public async Task<IActionResult> RevokeAccess([FromQuery] string username, [FromQuery] string clientId, [FromQuery] string realm)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(username) || 
                string.IsNullOrWhiteSpace(clientId) || 
                string.IsNullOrWhiteSpace(realm))
            {
                return BadRequest(new { error = "Все параметры обязательны" });
            }

            await _ownershipService.RevokeAccessAsync(username, clientId, realm);

            _logger.LogWarning("Удален доступ к клиенту {ClientId} у пользователя {Username} в реалме {Realm}", 
                username, clientId, realm);

            return Ok(new { success = true, message = "Доступ успешно удалён" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при удалении доступа пользователя {Username} к клиенту {ClientId}", 
                username, clientId);
            return StatusCode(500, new { error = "Ошибка при удалении доступа" });
        }
    }
}

/// <summary>
/// Модель для запроса назначения клиента
/// </summary>
public class AssignClientRequest
{
    public string Username { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string Realm { get; set; } = string.Empty;
}

/// <summary>
/// Результат поиска пользователя
/// </summary>
public class UserSearchResult
{
    public string Username { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public bool Enabled { get; set; }
}

/// <summary>
/// Результат поиска клиента
/// </summary>
public class ClientSearchResult
{
    public string ClientId { get; set; } = string.Empty;
    public string Realm { get; set; } = string.Empty;
    public string? Name { get; set; }
    public string? Description { get; set; }
    public bool Enabled { get; set; }
}

