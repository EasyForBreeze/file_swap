using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;
using System.Security.Claims;

namespace new_assistant.Controllers;

/// <summary>
/// API контроллер для переноса клиентов из TEST в STAGE
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Authorize]
[EnableRateLimiting("admin")]
public class ClientMigrationController : ControllerBase
{
    private readonly IClientMigrationService _migrationService;
    private readonly IUserRoleService _userRoleService;
    private readonly ILogger<ClientMigrationController> _logger;

    public ClientMigrationController(
        IClientMigrationService migrationService,
        IUserRoleService userRoleService,
        ILogger<ClientMigrationController> logger)
    {
        _migrationService = migrationService;
        _userRoleService = userRoleService;
        _logger = logger;
    }

    /// <summary>
    /// Валидация возможности переноса клиента
    /// </summary>
    /// <param name="request">Данные для валидации переноса</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Результат валидации</returns>
    [HttpPost("validate")]
    public async Task<IActionResult> ValidateMigration(
        [FromBody] ClientMigrationRequest request,
        CancellationToken cancellationToken = default)
    {
        try
        {
            // Проверка прав администратора
            var username = User.FindFirstValue(ClaimTypes.Name) ?? "Unknown";
            var isAdmin = _userRoleService.IsAdmin();

            if (!isAdmin)
            {
                _logger.LogWarning("Попытка валидации миграции без прав администратора: {User}", username);
                return Forbid();
            }

            // Валидация выполняется в сервисе, контроллер обрабатывает исключения
            var result = await _migrationService.ValidateMigrationAsync(request, cancellationToken);

            return Ok(new
            {
                canMigrate = result.CanMigrate,
                clientExistsInTarget = result.ClientExistsInTarget,
                missingRealmRoles = result.MissingRealmRoles,
                missingClientRoles = result.MissingClientRoles,
                missingClientScopes = result.MissingClientScopes,
                warningCount = result.WarningCount,
                messages = result.Messages,
                existingWikiPageUrl = result.ExistingWikiPageUrl
            });
        }
        catch (ArgumentNullException ex)
        {
            _logger.LogWarning(ex, "Некорректные входные данные для валидации миграции");
            return BadRequest(new { error = ex.Message });
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Ошибка валидации входных данных: {Message}", ex.Message);
            return BadRequest(new { error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка валидации миграции для клиента {ClientId}", request?.ClientId ?? "unknown");
            return StatusCode(500, new { error = "Внутренняя ошибка сервера при валидации" });
        }
    }

    /// <summary>
    /// Выполнить перенос клиента из TEST в STAGE
    /// </summary>
    /// <param name="request">Данные для переноса</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Результат переноса</returns>
    [HttpPost("migrate")]
    public async Task<IActionResult> MigrateClient(
        [FromBody] ClientMigrationRequest request,
        CancellationToken cancellationToken = default)
    {
        try
        {
            // Проверка прав администратора
            var username = User.FindFirstValue(ClaimTypes.Name) ?? "Unknown";
            var isAdmin = _userRoleService.IsAdmin();

            if (!isAdmin)
            {
                _logger.LogWarning("Попытка миграции без прав администратора: {User}", username);
                return Forbid();
            }

            // Валидация выполняется в сервисе, контроллер обрабатывает исключения
            // Валидация перед миграцией (обязательно!)
            var validationResult = await _migrationService.ValidateMigrationAsync(request, cancellationToken);
            
            if (!validationResult.CanMigrate)
            {
                return BadRequest(new 
                { 
                    error = "Миграция невозможна",
                    messages = validationResult.Messages
                });
            }

            // Выполняем миграцию
            var result = await _migrationService.MigrateClientAsync(request, username, cancellationToken);

            if (!result.Success)
            {
                return BadRequest(new
                {
                    success = false,
                    errors = result.Errors,
                    warnings = result.Warnings
                });
            }

            return Ok(new
            {
                success = result.Success,
                clientId = result.ClientId,
                newClientSecret = result.NewClientSecret,
                newInternalId = result.NewInternalId,
                archivePassword = result.ArchivePassword,
                redirectUris = result.RedirectUris,
                wikiPageUrl = result.WikiPageUrl,
                localRolesMigrated = result.LocalRolesMigrated,
                serviceRolesMigrated = result.ServiceRolesMigrated,
                warnings = result.Warnings,
                errors = result.Errors
            });
        }
        catch (ArgumentNullException ex)
        {
            _logger.LogWarning(ex, "Некорректные входные данные для миграции");
            return BadRequest(new { error = ex.Message });
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Ошибка валидации входных данных: {Message}", ex.Message);
            return BadRequest(new { error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Критическая ошибка миграции клиента {ClientId}", request?.ClientId ?? "unknown");
            return StatusCode(500, new { error = "Внутренняя ошибка сервера при миграции" });
        }
    }

}

