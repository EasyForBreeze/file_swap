using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace new_assistant.Controllers;

[ApiController]
[Route("api/[controller]")]
[EnableRateLimiting("health")]
public class HealthController : ControllerBase
{
    private readonly HealthCheckService _healthCheckService;

    public HealthController(HealthCheckService healthCheckService)
    {
        _healthCheckService = healthCheckService;
    }

    /// <summary>
    /// Получить состояние здоровья всех компонентов системы
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var report = await _healthCheckService.CheckHealthAsync();
        
        var result = new
        {
            Status = report.Status.ToString(),
            TotalDuration = $"{report.TotalDuration.TotalMilliseconds:F2}ms",
            Timestamp = DateTime.UtcNow,
            Application = "KeyCloak Assistant API",
            Checks = report.Entries.Select(entry => new
            {
                Name = entry.Key,
                Status = entry.Value.Status.ToString(),
                Duration = $"{entry.Value.Duration.TotalMilliseconds:F2}ms",
                Description = entry.Value.Description,
                Data = entry.Value.Data,
                Exception = entry.Value.Exception?.Message,
                Tags = entry.Value.Tags
            })
        };

        var statusCode = report.Status == HealthStatus.Healthy ? 200 :
                        report.Status == HealthStatus.Degraded ? 200 : 503;

        return StatusCode(statusCode, result);
    }

    /// <summary>
    /// Получить состояние конкретного компонента
    /// </summary>
    [HttpGet("{checkName}")]
    public async Task<IActionResult> GetByName(string checkName)
    {
        var report = await _healthCheckService.CheckHealthAsync(check => check.Name == checkName);
        
        if (!report.Entries.Any())
        {
            return NotFound(new { Error = $"Health check '{checkName}' not found" });
        }

        var entry = report.Entries.First();
        var result = new
        {
            Name = entry.Key,
            Status = entry.Value.Status.ToString(),
            Duration = $"{entry.Value.Duration.TotalMilliseconds:F2}ms",
            Description = entry.Value.Description,
            Data = entry.Value.Data,
            Exception = entry.Value.Exception?.Message,
            Tags = entry.Value.Tags,
            Timestamp = DateTime.UtcNow
        };

        var statusCode = entry.Value.Status == HealthStatus.Healthy ? 200 :
                        entry.Value.Status == HealthStatus.Degraded ? 200 : 503;

        return StatusCode(statusCode, result);
    }
}
