namespace new_assistant.Configuration;

/// <summary>
/// Настройки для сервиса очистки архивов
/// </summary>
public class ArchiveCleanupSettings
{
    /// <summary>
    /// Интервал между очистками
    /// </summary>
    public TimeSpan CleanupInterval { get; set; } = TimeSpan.FromDays(1);

    /// <summary>
    /// Количество дней хранения архивов
    /// </summary>
    public int ArchiveRetentionDays { get; set; } = 1;

    /// <summary>
    /// Задержка перед первой очисткой после запуска сервиса
    /// </summary>
    public TimeSpan? InitialDelay { get; set; } = null;
}

