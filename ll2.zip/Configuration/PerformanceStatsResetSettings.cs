namespace new_assistant.Configuration;

/// <summary>
/// Настройки для сервиса сброса статистики производительности
/// </summary>
public class PerformanceStatsResetSettings
{
    public const string SectionName = "PerformanceStatsReset";
    
    /// <summary>
    /// Включен ли сервис сброса статистики
    /// </summary>
    public bool Enabled { get; set; } = true;
    
    /// <summary>
    /// Интервал сброса статистики в минутах
    /// </summary>
    public int ResetIntervalMinutes { get; set; } = 30;
    
    /// <summary>
    /// Интервал сброса как TimeSpan
    /// </summary>
    public TimeSpan ResetInterval => TimeSpan.FromMinutes(ResetIntervalMinutes);
}

