using Microsoft.Extensions.Logging;
using Serilog.Context;
using System.Diagnostics;

namespace new_assistant.Infrastructure.Middleware;

/// <summary>
/// Middleware для добавления correlation ID к каждому запросу
/// </summary>
public class CorrelationIdMiddleware
{
    private readonly RequestDelegate _next;
    private const string CorrelationIdHeaderName = "X-Correlation-ID";
    private const string CorrelationIdLogPropertyName = "CorrelationId";

    public CorrelationIdMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // Получаем или создаем correlation ID
        var correlationId = context.Request.Headers[CorrelationIdHeaderName].FirstOrDefault();
        
        if (string.IsNullOrWhiteSpace(correlationId))
        {
            // Создаем новый correlation ID (GUID без дефисов для краткости)
            correlationId = Guid.NewGuid().ToString("N");
        }
        
        // Добавляем correlation ID в заголовки ответа
        context.Response.Headers[CorrelationIdHeaderName] = correlationId;
        
        // Добавляем correlation ID в HttpContext.Items для доступа в обработчиках
        context.Items[CorrelationIdLogPropertyName] = correlationId;
        
        // Добавляем correlation ID в логи через Serilog LogContext
        using (LogContext.PushProperty(CorrelationIdLogPropertyName, correlationId))
        {
            var stopwatch = Stopwatch.StartNew();
            
            try
            {
                await _next(context);
            }
            finally
            {
                stopwatch.Stop();
                
                // Логируем информацию о запросе
                var logger = context.RequestServices.GetRequiredService<ILogger<CorrelationIdMiddleware>>();
                logger.LogDebug(
                    "Запрос {Method} {Path} завершен за {Duration}ms со статусом {StatusCode}",
                    context.Request.Method,
                    context.Request.Path,
                    stopwatch.ElapsedMilliseconds,
                    context.Response.StatusCode);
            }
        }
    }
}

