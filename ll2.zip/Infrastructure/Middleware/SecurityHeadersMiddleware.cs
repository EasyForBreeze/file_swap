using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Net.Http.Headers;
using new_assistant.Configuration;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace new_assistant.Infrastructure.Middleware;

/// <summary>
/// Middleware для установки security headers (CSP, X-Frame-Options, и т.д.)
/// </summary>
public class SecurityHeadersMiddleware
{
    private const string PermissionsPolicy = "camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()";
    private const string FallbackHost = "localhost";

    private readonly RequestDelegate _next;
    private readonly KeycloakAuthenticationSettings _keycloakSettings;
    private readonly ILogger<SecurityHeadersMiddleware> _logger;
    private readonly string _authority;
    
    // Кэшируем статические директивы для оптимизации производительности
    private readonly List<string> _staticDirectives;

    public SecurityHeadersMiddleware(
        RequestDelegate next,
        IOptions<KeycloakAuthenticationSettings> keycloakSettings,
        ILogger<SecurityHeadersMiddleware> logger)
    {
        _next = next;
        _keycloakSettings = keycloakSettings.Value;
        _logger = logger;

        // Валидация и нормализация Authority
        if (string.IsNullOrWhiteSpace(_keycloakSettings.Authority))
        {
            throw new InvalidOperationException("Keycloak Authority is not configured.");
        }

        if (!Uri.TryCreate(_keycloakSettings.Authority, UriKind.Absolute, out var authorityUri))
        {
            throw new InvalidOperationException($"Keycloak Authority has invalid format: {_keycloakSettings.Authority}");
        }

        _authority = authorityUri.ToString().TrimEnd('/');
        
        // Инициализируем статические директивы один раз при создании middleware
        _staticDirectives = new List<string>
        {
            "default-src 'self'",
            "base-uri 'self'",
            "frame-ancestors 'none'",
            "form-action 'self'",
            "object-src 'none'",
            "manifest-src 'self'",
            "media-src 'self'",
            "img-src 'self' data: blob:",
            "font-src 'self' data: https://fonts.gstatic.com https://fonts.googleapis.com",
            "style-src-attr 'unsafe-inline'",
            "script-src-attr 'none'",
            "worker-src 'self' blob:"
        };
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // Установка базовых заголовков
        SetBasicSecurityHeaders(context);

        // Генерация CSP nonce для HTML ответов
        var cspNonce = GenerateCspNonceIfNeeded(context);

        // Настройка CSP заголовка
        context.Response.OnStarting(() =>
        {
            SetCspHeader(context, cspNonce);
            return Task.CompletedTask;
        });

        await _next(context).ConfigureAwait(false);
    }

    /// <summary>
    /// Устанавливает базовые security headers для всех ответов
    /// </summary>
    private static void SetBasicSecurityHeaders(HttpContext context)
    {
        context.Response.Headers[HeaderNames.XContentTypeOptions] = "nosniff";
        context.Response.Headers[HeaderNames.XFrameOptions] = "DENY";
        context.Response.Headers["Referrer-Policy"] = "no-referrer";
        context.Response.Headers["Permissions-Policy"] = PermissionsPolicy;
    }

    /// <summary>
    /// Генерирует CSP nonce для HTML запросов
    /// </summary>
    /// <param name="context">HTTP контекст запроса</param>
    /// <returns>CSP nonce или null, если запрос не является HTML</returns>
    private static string? GenerateCspNonceIfNeeded(HttpContext context)
    {
        var isHtmlRequest = IsHtmlRequest(context);
        if (!isHtmlRequest)
        {
            return null;
        }

        var cspNonce = Convert.ToBase64String(RandomNumberGenerator.GetBytes(16));
        context.Items[CspExtensions.CspNonceHttpContextItemKey] = cspNonce;
        return cspNonce;
    }

    /// <summary>
    /// Определяет, является ли запрос потенциально HTML запросом
    /// </summary>
    /// <param name="context">HTTP контекст запроса</param>
    /// <returns>true, если запрос может быть HTML, иначе false</returns>
    private static bool IsHtmlRequest(HttpContext context)
    {
        var path = context.Request.Path.Value ?? string.Empty;
        return !path.StartsWith("/api", StringComparison.OrdinalIgnoreCase) &&
               !path.StartsWith("/css", StringComparison.OrdinalIgnoreCase) &&
               !path.StartsWith("/js", StringComparison.OrdinalIgnoreCase) &&
               !path.StartsWith("/_", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Устанавливает Content-Security-Policy заголовок для HTML ответов
    /// </summary>
    /// <param name="context">HTTP контекст запроса</param>
    /// <param name="cspNonce">CSP nonce для использования в директивах</param>
    private void SetCspHeader(HttpContext context, string? cspNonce)
    {
        if (context.Response.ContentType is not { Length: > 0 } contentType ||
            !contentType.StartsWith("text/html", StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        // Используем уже сгенерированный nonce или генерируем новый при необходимости
        if (cspNonce == null)
        {
            cspNonce = context.Items.TryGetValue(CspExtensions.CspNonceHttpContextItemKey, out var nonceObj) &&
                      nonceObj is string nonce
                ? nonce
                : Convert.ToBase64String(RandomNumberGenerator.GetBytes(16));
        }

        var directives = BuildCspDirectives(context, cspNonce);
        var csp = string.Join("; ", directives);
        context.Response.Headers[HeaderNames.ContentSecurityPolicy] = csp;
    }

    /// <summary>
    /// Строит список CSP директив на основе контекста запроса
    /// </summary>
    /// <param name="context">HTTP контекст запроса</param>
    /// <param name="cspNonce">CSP nonce для использования в директивах</param>
    /// <returns>Список CSP директив</returns>
    private List<string> BuildCspDirectives(HttpContext context, string? cspNonce)
    {
        var websocketScheme = context.Request.IsHttps ? "wss" : "ws";
        var host = context.Request.Host;

        // Валидация host для websocket endpoint
        if (!host.HasValue || string.IsNullOrEmpty(host.Host))
        {
            _logger?.LogWarning("Invalid request host for WebSocket endpoint, using fallback");
            host = new HostString(FallbackHost);
        }

        var websocketEndpoint = $"{websocketScheme}://{host}";
        
        // Создаем новый список на основе статического для оптимизации производительности
        var directives = new List<string>(_staticDirectives)
        {
            $"connect-src 'self' {websocketEndpoint} {_authority}"
        };

        if (cspNonce != null)
        {
            directives.Add($"style-src 'self' 'nonce-{cspNonce}' https://fonts.googleapis.com");
            directives.Add($"script-src 'self' 'nonce-{cspNonce}' 'wasm-unsafe-eval'");
        }
        else
        {
            directives.Add("style-src 'self' https://fonts.googleapis.com");
            directives.Add("script-src 'self' 'wasm-unsafe-eval'");
        }

        if (context.Request.IsHttps)
        {
            directives.Add("upgrade-insecure-requests");
        }

        return directives;
    }
}

