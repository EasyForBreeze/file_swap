using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Hosting;
using Microsoft.AspNetCore.Components.Server.Circuits;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;
using new_assistant.Infrastructure.Services;
using new_assistant.Infrastructure.Services.KeycloakAdmin;
using new_assistant.Infrastructure.Services.UsersManagement;
using new_assistant.Infrastructure.Services.Confluence;
using new_assistant.Infrastructure.Data;
using new_assistant.Infrastructure.Middleware;
using new_assistant.Infrastructure.HealthChecks;
using FluentValidation;
using FluentValidation.AspNetCore;
using Polly;
using Polly.Extensions.Http;
using System.Linq;
using System.Net;
using System.Net.Http;

namespace new_assistant.Infrastructure.Extensions;

/// <summary>
/// Extension методы для регистрации сервисов в DI контейнере
/// </summary>
public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Регистрация всех настроек через IOptions<T>
    /// </summary>
    /// <remarks>
    /// <para>Все настройки автоматически доступны через IOptionsMonitor<T> для динамического обновления.</para>
    /// <para>Для настроек, которые могут изменяться во время выполнения, сервисы должны использовать IOptionsMonitor<T> вместо IOptions<T>.</para>
    /// <para>IOptionsMonitor<T> автоматически отслеживает изменения в конфигурации (если reloadOnChange: true) и уведомляет сервисы через OnChange callback.</para>
    /// <para>Настройки с reloadOnChange: true будут автоматически обновляться при изменении конфигурационного файла.</para>
    /// </remarks>
    public static IServiceCollection AddApplicationSettings(this IServiceCollection services, IConfiguration configuration)
    {
        // Критические настройки с валидацией при старте (обычно не изменяются во время выполнения)
        services.AddOptions<KeycloakAuthenticationSettings>()
            .Bind(configuration.GetSection("Authentication:Keycloak"))
            .ValidateOnStart();
        services.AddOptions<KeycloakAdminSettings>()
            .Bind(configuration.GetSection("KeycloakAdmin"))
            .ValidateOnStart();
        services.AddOptions<KeycloakStageSettings>()
            .Bind(configuration.GetSection("KeycloakStage"))
            .ValidateOnStart();
        services.AddOptions<TokenExchangeSettings>()
            .Bind(configuration.GetSection("TokenExchange"))
            .ValidateOnStart();
        services.AddOptions<ConfluenceSettings>()
            .Bind(configuration.GetSection("Confluence"))
            .ValidateOnStart();
        
        // Настройки, которые могут изменяться во время выполнения
        // Для этих настроек рекомендуется использовать IOptionsMonitor<T> в сервисах для получения обновлений
        // IOptionsMonitor<T> автоматически отслеживает изменения, если конфигурация настроена с reloadOnChange: true
        // Пример использования в сервисе:
        //   public class MyService(IOptionsMonitor<KeycloakCacheSettings> settingsMonitor)
        //   {
        //       var currentSettings = settingsMonitor.CurrentValue;
        //       settingsMonitor.OnChange(newSettings => { /* обработка изменений */ });
        //   }
        services.Configure<KeycloakCacheSettings>(configuration.GetSection("KeycloakCache"));
        services.Configure<RateLimitingSettings>(configuration.GetSection("RateLimiting"));
        services.Configure<AuditLoggingSettings>(configuration.GetSection("AuditLogging"));
        services.Configure<ArchiveCleanupSettings>(configuration.GetSection("ArchiveCleanup"));
        services.Configure<AuditLogCleanupSettings>(configuration.GetSection("AuditLogCleanup"));
        services.Configure<PerformanceStatsResetSettings>(configuration.GetSection(PerformanceStatsResetSettings.SectionName));
        services.Configure<SearchStateServiceSettings>(configuration.GetSection("SearchStateService"));
        
        // Остальные настройки (обычно не изменяются во время выполнения)
        services.Configure<EnhancedTokenValidationSettings>(configuration.GetSection("TokenValidation"));
        services.Configure<ConfluenceTemplateSettings>(configuration.GetSection("ConfluenceTemplate"));
        services.Configure<ForwardedHeadersSettings>(configuration.GetSection("ForwardedHeaders"));
        services.Configure<ForbiddenSettings>(configuration.GetSection("Forbidden"));
        services.Configure<DataPathsSettings>(configuration.GetSection("DataPaths"));
        services.Configure<MemoryCacheSettings>(configuration.GetSection("MemoryCache"));

        // Инициализация DataPathsSettings для создания директорий при старте
        // Регистрируем как Singleton для прямого использования сервисами (не через IOptions)
        // НЕ регистрируем через IOptions, чтобы избежать рассинхронизации значений
        var dataPathsSettings = configuration.GetSection("DataPaths").Get<DataPathsSettings>() ?? new DataPathsSettings();
        dataPathsSettings.EnsureDirectoriesExist();
        services.AddSingleton(dataPathsSettings);
        
        // Синхронизируем IOptions с Singleton экземпляром для обратной совместимости
        services.AddSingleton<IOptions<DataPathsSettings>>(sp => 
            Options.Create(sp.GetRequiredService<DataPathsSettings>()));

        return services;
    }

    /// <summary>
    /// Регистрация базовых сервисов приложения
    /// </summary>
    public static IServiceCollection AddBaseServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddExceptionHandler<GlobalExceptionHandler>();
        services.AddProblemDetails();

        // Настройка MemoryCache из конфигурации (если указано) или значения по умолчанию
        services.AddMemoryCache(options =>
        {
            // Получаем настройки из конфигурации (если доступны)
            var cacheSettings = configuration.GetSection("MemoryCache").Get<MemoryCacheSettings>();
            
            if (cacheSettings?.SizeLimit.HasValue == true)
            {
                options.SizeLimit = cacheSettings.SizeLimit.Value;
            }
            else
            {
                options.SizeLimit = 1000; // Значение по умолчанию
            }
            
            if (cacheSettings?.CompactionPercentage.HasValue == true)
            {
                options.CompactionPercentage = cacheSettings.CompactionPercentage.Value;
            }
            else
            {
                options.CompactionPercentage = 0.20; // Значение по умолчанию
            }
            
            if (cacheSettings?.ExpirationScanFrequencyMinutes.HasValue == true)
            {
                options.ExpirationScanFrequency = TimeSpan.FromMinutes(cacheSettings.ExpirationScanFrequencyMinutes.Value);
            }
            else
            {
                options.ExpirationScanFrequency = TimeSpan.FromMinutes(2); // Значение по умолчанию
            }
        });

        services.AddHttpContextAccessor();
        services.AddAuthorization();

        // Регистрация ValidationService
        // DI контейнер автоматически разрешит ILogger<ValidationService> и IOptions<KeycloakAdminSettings>
        services.AddScoped<IValidationService, ValidationService>();
        
        // Регистрация ClientEventsService
        services.AddScoped<IClientEventsService, ClientEventsService>();

        return services;
    }

    /// <summary>
    /// Регистрация Keycloak сервисов
    /// </summary>
    public static IServiceCollection AddKeycloakServices(this IServiceCollection services, IConfiguration configuration)
    {
        var ignoreSslErrors = configuration.GetValue<bool>("KeycloakAdmin:IgnoreSslErrors", defaultValue: false);
        
        // Логирование предупреждения через ILoggerFactory, если SSL validation отключена
        if (ignoreSslErrors)
        {
            // Регистрируем временный logger для предупреждения
            // В production это должно быть отключено
            try
            {
                using var tempServiceProvider = services.BuildServiceProvider();
                var loggerFactory = tempServiceProvider.GetService<ILoggerFactory>();
                var logger = loggerFactory?.CreateLogger("ServiceCollectionExtensions");
                logger?.LogWarning("SSL certificate validation is DISABLED for KeycloakAdmin. This should only be used in development environments!");
            }
            catch
            {
                // Игнорируем ошибки при создании временного ServiceProvider
                // Предупреждение не критично для работы приложения
            }
        }

        // KeycloakAdmin HttpClient
        // BaseAddress и Timeout настраиваются в KeycloakHttpClientBase.ConfigureHttpClient()
        // Здесь оставляем только общие настройки, которые не зависят от конкретного экземпляра
        services.AddHttpClient("KeycloakAdmin")
            .ConfigureHttpClient((sp, client) =>
            {
                // Добавляем Accept header, если его еще нет
                if (!client.DefaultRequestHeaders.Contains("Accept"))
                {
                    client.DefaultRequestHeaders.Add("Accept", "application/json");
                }
            })
            .AddPolicyHandler(GetRetryPolicy())
            .AddPolicyHandler(GetCircuitBreakerPolicy());

        // KeycloakCacheService (используем TryAdd для предотвращения дублирования)
        // TryAddSingleton не поддерживает фабрику, используем проверку и AddSingleton
        if (!services.Any(s => s.ServiceType == typeof(IKeycloakCacheService)))
        {
            services.AddSingleton<IKeycloakCacheService, KeycloakCacheService>(sp =>
            {
                try
                {
                    var cache = sp.GetRequiredService<IMemoryCache>();
                    var logger = sp.GetRequiredService<ILogger<KeycloakCacheService>>();
                    var settings = sp.GetRequiredService<IOptions<KeycloakCacheSettings>>();
                    return new KeycloakCacheService(cache, logger, settings);
                }
                catch (Exception ex)
                {
                    var logger = sp.GetRequiredService<ILogger<KeycloakCacheService>>();
                    logger.LogError(ex, "Failed to create KeycloakCacheService");
                    throw;
                }
            });
        }

        // KeycloakHttpClient (Singleton)
        // Использует IHttpClientFactory для правильного управления жизненным циклом HttpClient
        services.AddSingleton<KeycloakHttpClient>(sp =>
        {
            try
            {
                var settings = sp.GetRequiredService<IOptions<KeycloakAdminSettings>>().Value 
                    ?? throw new InvalidOperationException("KeycloakAdminSettings is not configured");
                var logger = sp.GetRequiredService<ILogger<KeycloakHttpClient>>();
                var cacheService = sp.GetRequiredService<KeycloakCacheService>();
                var metricsService = sp.GetRequiredService<IPerformanceMetricsService>();
                var httpClientFactory = sp.GetRequiredService<IHttpClientFactory>();
                var loggerFactory = sp.GetRequiredService<ILoggerFactory>();

                return new KeycloakHttpClient(settings, logger, cacheService, metricsService, httpClientFactory, loggerFactory);
            }
            catch (Exception ex)
            {
                var logger = sp.GetRequiredService<ILogger<KeycloakHttpClient>>();
                logger.LogError(ex, "Failed to create KeycloakHttpClient");
                throw;
            }
        });

        // Регистрация специализированных Keycloak Admin сервисов
        // Важно: они должны быть зарегистрированы перед KeycloakAdminService (фасадом)
        services.AddScoped<IKeycloakRealmService>(sp =>
        {
            var httpClient = sp.GetRequiredService<KeycloakHttpClient>();
            return new KeycloakRealmService(httpClient);
        });
        
        services.AddScoped<IKeycloakUsersService>(sp =>
        {
            var httpClient = sp.GetRequiredService<KeycloakHttpClient>();
            var logger = sp.GetRequiredService<ILogger<KeycloakUsersService>>();
            return new KeycloakUsersService(httpClient, logger);
        });
        
        services.AddScoped<IKeycloakTokenExamplesService>(sp =>
        {
            var httpClient = sp.GetRequiredService<KeycloakHttpClient>();
            return new KeycloakTokenExamplesService(httpClient);
        });
        
        services.AddScoped<IKeycloakClientManagementService>(sp =>
        {
            var httpClient = sp.GetRequiredService<KeycloakHttpClient>();
            var settings = sp.GetRequiredService<IOptions<KeycloakAdminSettings>>();
            var logger = sp.GetRequiredService<ILogger<KeycloakClientManagementService>>();
            var forbiddenService = sp.GetRequiredService<IForbiddenClientService>();
            var metricsService = sp.GetRequiredService<IPerformanceMetricsService>();
            return new KeycloakClientManagementService(httpClient, settings, logger, forbiddenService, metricsService);
        });
        
        services.AddScoped<IKeycloakClientSearchService>(sp =>
        {
            var httpClient = sp.GetRequiredService<KeycloakHttpClient>();
            var settings = sp.GetRequiredService<IOptions<KeycloakAdminSettings>>();
            var logger = sp.GetRequiredService<ILogger<KeycloakClientSearchService>>();
            var realmService = sp.GetRequiredService<IKeycloakRealmService>();
            return new KeycloakClientSearchService(httpClient, settings, logger, realmService);
        });
        
        services.AddScoped<IKeycloakClientDetailsService>(sp =>
        {
            var httpClient = sp.GetRequiredService<KeycloakHttpClient>();
            var settings = sp.GetRequiredService<IOptions<KeycloakAdminSettings>>();
            var logger = sp.GetRequiredService<ILogger<KeycloakClientDetailsService>>();
            var httpClientFactory = sp.GetRequiredService<IHttpClientFactory>();
            var cacheService = sp.GetRequiredService<KeycloakCacheService>();
            var metricsService = sp.GetRequiredService<IPerformanceMetricsService>();
            return new KeycloakClientDetailsService(httpClient, settings, logger, httpClientFactory, cacheService, metricsService);
        });
        
        services.AddScoped<IKeycloakClientEventsService>(sp =>
        {
            var httpClient = sp.GetRequiredService<KeycloakHttpClient>();
            var logger = sp.GetRequiredService<ILogger<KeycloakClientEventsService>>();
            return new KeycloakClientEventsService(httpClient, logger);
        });
        
        services.AddScoped<IKeycloakRolesService>(sp =>
        {
            var httpClient = sp.GetRequiredService<KeycloakHttpClient>();
            var logger = sp.GetRequiredService<ILogger<KeycloakRolesService>>();
            var forbiddenService = sp.GetRequiredService<IForbiddenClientService>();
            var metricsService = sp.GetRequiredService<IPerformanceMetricsService>();
            return new KeycloakRolesService(httpClient, logger, forbiddenService, metricsService);
        });

        // KeycloakAdminService (фасад, делегирует вызовы специализированным сервисам)
        services.AddScoped<IKeycloakAdminService>(sp =>
        {
            try
            {
                var clientManagementService = sp.GetRequiredService<IKeycloakClientManagementService>();
                var clientSearchService = sp.GetRequiredService<IKeycloakClientSearchService>();
                var clientDetailsService = sp.GetRequiredService<IKeycloakClientDetailsService>();
                var clientEventsService = sp.GetRequiredService<IKeycloakClientEventsService>();
                var rolesService = sp.GetRequiredService<IKeycloakRolesService>();
                var usersService = sp.GetRequiredService<IKeycloakUsersService>();
                var realmService = sp.GetRequiredService<IKeycloakRealmService>();
                var tokenExamplesService = sp.GetRequiredService<IKeycloakTokenExamplesService>();
                var metricsService = sp.GetRequiredService<IPerformanceMetricsService>();
                
                return new KeycloakAdminService(
                    clientManagementService,
                    clientSearchService,
                    clientDetailsService,
                    clientEventsService,
                    rolesService,
                    usersService,
                    realmService,
                    tokenExamplesService,
                    metricsService);
            }
            catch (Exception ex)
            {
                var logger = sp.GetRequiredService<ILogger<KeycloakAdminService>>();
                logger.LogError(ex, "Failed to create KeycloakAdminService");
                throw;
            }
        });

        // PerformanceMetricsService (используем TryAdd для предотвращения дублирования)
        services.TryAddSingleton<IPerformanceMetricsService, PerformanceMetricsService>();
        
        // SqlitePerformanceMonitor (используем TryAdd для предотвращения дублирования)
        services.TryAddSingleton<ISqlitePerformanceMonitor, SqlitePerformanceMonitorService>();

        return services;
    }

    /// <summary>
    /// Регистрация Keycloak Stage сервисов
    /// </summary>
    public static IServiceCollection AddKeycloakStageServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddHttpClient("KeycloakStage")
            .ConfigureHttpClient((sp, client) =>
            {
                var settings = sp.GetRequiredService<IOptions<KeycloakStageSettings>>().Value 
                    ?? throw new InvalidOperationException("KeycloakStageSettings is not configured");
                
                var logger = sp.GetService<ILoggerFactory>()?.CreateLogger("ServiceCollectionExtensions");
                ConfigureKeycloakStageHttpClient(client, settings, logger);
            })
            .AddPolicyHandler(GetRetryPolicy())
            .AddPolicyHandler(GetCircuitBreakerPolicy());

        services.AddSingleton<IKeycloakStageHttpClient, KeycloakStageHttpClient>(sp =>
        {
            try
            {
                var httpClientFactory = sp.GetRequiredService<IHttpClientFactory>();
                var httpClient = httpClientFactory.CreateClient("KeycloakStage");
                var settings = sp.GetRequiredService<IOptions<KeycloakStageSettings>>().Value 
                    ?? throw new InvalidOperationException("KeycloakStageSettings is not configured");
                var logger = sp.GetRequiredService<ILogger<KeycloakStageHttpClient>>();
                var metricsService = sp.GetService<IPerformanceMetricsService>();
                
                // Логирование предупреждения, если метрики не доступны
                if (metricsService == null)
                {
                    logger.LogWarning("IPerformanceMetricsService is not registered. Metrics will not be collected for KeycloakStageHttpClient.");
                }

                return new KeycloakStageHttpClient(httpClient, settings, logger, metricsService, skipConfigure: true);
            }
            catch (Exception ex)
            {
                var logger = sp.GetRequiredService<ILogger<KeycloakStageHttpClient>>();
                logger.LogError(ex, "Failed to create KeycloakStageHttpClient");
                throw;
            }
        });

        services.AddScoped<IKeycloakStageService>(sp =>
        {
            try
            {
                var httpClient = sp.GetRequiredService<IKeycloakStageHttpClient>();
                var settings = sp.GetRequiredService<IOptions<KeycloakStageSettings>>();
                var logger = sp.GetRequiredService<ILogger<KeycloakStageService>>();
                return new KeycloakStageService(httpClient, settings, logger);
            }
            catch (Exception ex)
            {
                var logger = sp.GetRequiredService<ILogger<KeycloakStageService>>();
                logger.LogError(ex, "Failed to create KeycloakStageService");
                throw;
            }
        });

        // Регистрация сервисов миграции клиентов
        services.AddScoped<IKeycloakUrlBuilderService, KeycloakUrlBuilderService>();
        services.AddScoped<IClientMigrationValidationService, ClientMigrationValidationService>();
        services.AddScoped<IClientMigrationRolesService, ClientMigrationRolesService>();
        services.AddScoped<IClientMigrationWikiService, ClientMigrationWikiService>();
        services.AddScoped<IClientMigrationService, ClientMigrationService>();

        return services;
    }

    /// <summary>
    /// Регистрация User Management сервисов
    /// </summary>
    public static IServiceCollection AddUserManagementServices(this IServiceCollection services, IConfiguration configuration)
    {
        var ignoreSslErrors = configuration.GetValue<bool>("KeycloakAdmin:IgnoreSslErrors", defaultValue: false);
        
        // Логирование предупреждения, если SSL validation отключена
        if (ignoreSslErrors)
        {
            try
            {
                using var tempServiceProvider = services.BuildServiceProvider();
                var loggerFactory = tempServiceProvider.GetService<ILoggerFactory>();
                var logger = loggerFactory?.CreateLogger("ServiceCollectionExtensions");
                logger?.LogWarning("SSL certificate validation is DISABLED for UserManagement services. This should only be used in development environments!");
            }
            catch
            {
                // Игнорируем ошибки при создании временного ServiceProvider
            }
        }
        
        // Явно захватываем значение в локальную переменную для избежания проблем с замыканием
        var sslErrorsIgnored = ignoreSslErrors;

        // Регистрация специализированных сервисов users-management
        // Настраиваем HttpClient с полной конфигурацией (BaseAddress, Timeout, headers, resilience policies)
        ConfigureTypedHttpClient<IUsersSearchService, UsersSearchService>(services, sslErrorsIgnored, "UsersSearchService");
        ConfigureTypedHttpClient<IUsersInfoService, UsersInfoService>(services, sslErrorsIgnored, "UsersInfoService");
        ConfigureTypedHttpClient<IUsersRolesService, UsersRolesService>(services, sslErrorsIgnored, "UsersRolesService");
        ConfigureTypedHttpClient<IUsersActionsService, UsersActionsService>(services, sslErrorsIgnored, "UsersActionsService");
        ConfigureTypedHttpClient<IUsersCertificateService, UsersCertificateService>(services, sslErrorsIgnored, "UsersCertificateService");

        // Регистрация основного сервиса UsersManagementService
        services.AddScoped<IUsersManagementService, UsersManagementService>();

        services.AddScoped<IUserRoleService, UserRoleService>();
        services.AddScoped<IUserMenuService, UserMenuService>();

        // CircuitTokenService для обновления токенов в Blazor Server
        // Используем TryAdd для предотвращения дублирования регистрации
        services.TryAddScoped<CircuitTokenService>();
        services.TryAddScoped<CircuitHandler>(sp => sp.GetRequiredService<CircuitTokenService>());
        services.TryAddScoped<ITokenRefreshService>(sp => sp.GetRequiredService<CircuitTokenService>());

        services.AddScoped<ISearchStateService, SearchStateService>();
        services.AddScoped<IClientOwnershipService, ClientOwnershipService>();

        return services;
    }
    
    private static HttpClientHandler CreateHttpMessageHandler(bool ignoreSslErrors, string serviceName)
    {
        var handler = new HttpClientHandler();

        if (ignoreSslErrors)
        {
            handler.ServerCertificateCustomValidationCallback = (message, cert, chain, sslPolicyErrors) =>
            {
                if (sslPolicyErrors != System.Net.Security.SslPolicyErrors.None)
                {
                    // Используем Debug для логирования, так как ILogger недоступен в этом контексте
                    // В production это должно быть отключено
                    System.Diagnostics.Debug.WriteLine($"SSL ошибка игнорирована для {serviceName}: {sslPolicyErrors}");
                }
                return true;
            };
        }

        return handler;
    }

    /// <summary>
    /// Регистрация Token Exchange сервисов
    /// </summary>
    public static IServiceCollection AddTokenExchangeServices(this IServiceCollection services, IConfiguration configuration)
    {
        var ignoreSslErrors = configuration.GetValue<bool>("KeycloakAdmin:IgnoreSslErrors", defaultValue: false);
        
        // Логирование предупреждения, если SSL validation отключена
        if (ignoreSslErrors)
        {
            try
            {
                using var tempServiceProvider = services.BuildServiceProvider();
                var loggerFactory = tempServiceProvider.GetService<ILoggerFactory>();
                var logger = loggerFactory?.CreateLogger("ServiceCollectionExtensions");
                logger?.LogWarning("SSL certificate validation is DISABLED for TokenExchange. This should only be used in development environments!");
            }
            catch
            {
                // Игнорируем ошибки при создании временного ServiceProvider
            }
        }
        
        // Используем единый метод CreateHttpMessageHandler для устранения дублирования
        var sslErrorsIgnored = ignoreSslErrors;
        var tokenExchangeSettings = configuration.GetSection("TokenExchange").Get<TokenExchangeSettings>();
        var timeoutSeconds = tokenExchangeSettings?.RequestTimeoutSeconds ?? 30;

        services.AddHttpClient("TokenExchange")
            .ConfigurePrimaryHttpMessageHandler(() => CreateHttpMessageHandler(sslErrorsIgnored, "TokenExchange"))
            .ConfigureHttpClient(client =>
            {
                client.Timeout = TimeSpan.FromSeconds(timeoutSeconds);
            })
            .AddPolicyHandler(GetRetryPolicy())
            .AddPolicyHandler(GetCircuitBreakerPolicy());

        services.AddScoped<ITokenExchangeService, TokenExchangeService>();

        return services;
    }

    /// <summary>
    /// Регистрация Confluence сервисов
    /// </summary>
    public static IServiceCollection AddConfluenceServices(this IServiceCollection services)
    {
        // Регистрация провайдера шаблонов (настройки уже зарегистрированы в AddApplicationSettings)
        services.AddSingleton<IConfluenceTemplateProvider, ConfluenceTemplateProvider>();
        services.AddScoped<IWikiPageRepository, WikiPageRepository>();
        
        // Регистрация HTTP клиента для Confluence с полной настройкой
        services.AddHttpClient("Confluence")
            .ConfigureHttpClient((sp, client) =>
            {
                var settings = sp.GetRequiredService<IOptions<ConfluenceSettings>>().Value 
                    ?? throw new InvalidOperationException("ConfluenceSettings is not configured");
                
                var loggerFactory = sp.GetService<ILoggerFactory>();
                var logger = loggerFactory?.CreateLogger("ServiceCollectionExtensions");
                ConfigureHttpClientBase(client, settings.BaseUrl, settings.RequestTimeoutSeconds, logger);
            })
            .AddPolicyHandler(GetRetryPolicy())
            .AddPolicyHandler(GetCircuitBreakerPolicy());
        
        // Регистрация компонентов Confluence
        services.AddScoped<IConfluencePageParser, ConfluencePageParser>();
        services.AddScoped<IConfluencePageBuilder, ConfluencePageBuilder>();
        services.AddScoped<IConfluenceApiClient, ConfluenceApiClient>();
        services.AddScoped<ConfluenceLabelsService>();
        
        // Регистрация основного сервиса
        services.AddScoped<IConfluenceService, ConfluenceService>();

        return services;
    }

    /// <summary>
    /// Регистрация Forbidden Client сервисов
    /// </summary>
    public static IServiceCollection AddForbiddenClientServices(this IServiceCollection services)
    {
        services.AddScoped<IForbiddenClientRepository, ForbiddenClientRepository>();
        services.AddScoped<IForbiddenClientService, ForbiddenClientService>();

        return services;
    }

    /// <summary>
    /// Регистрация Audit сервисов
    /// </summary>
    public static IServiceCollection AddAuditServices(this IServiceCollection services)
    {
        services.AddScoped<IAuditService, AuditService>();

        return services;
    }

    /// <summary>
    /// Регистрация дополнительных сервисов приложения
    /// </summary>
    public static IServiceCollection AddApplicationServices(this IServiceCollection services)
    {
        services.AddScoped<IModalService, ModalService>();
        services.AddScoped<IClientCreationService, ClientCreationService>();
        services.AddScoped<INotificationService, NotificationService>();
        services.AddScoped<IClientArchiveService, ClientArchiveService>();
        services.AddScoped<IEmailService, EmailService>();

        return services;
    }

    /// <summary>
    /// Регистрация фоновых сервисов
    /// </summary>
    public static IServiceCollection AddBackgroundServices(this IServiceCollection services)
    {
        services.AddHostedService<ArchiveCleanupService>();
        services.AddHostedService<PerformanceStatsResetService>();
        services.AddHostedService<AuditLogCleanupService>();

        return services;
    }

    /// <summary>
    /// Регистрация FluentValidation
    /// </summary>
    public static IServiceCollection AddValidationServices(this IServiceCollection services)
    {
        services.AddFluentValidationAutoValidation();
        services.AddValidatorsFromAssemblyContaining<Program>();

        return services;
    }

    /// <summary>
    /// Регистрация Blazor Server и Razor Pages
    /// </summary>
    public static IServiceCollection AddBlazorServices(this IServiceCollection services, IHostEnvironment environment)
    {
        services.AddControllers();
        services.AddRazorPages();
        services.AddServerSideBlazor();

        // БЕЗОПАСНОСТЬ: CSRF защита для Blazor Server
        services.AddAntiforgery(options =>
        {
            options.HeaderName = "X-CSRF-TOKEN";
            options.Cookie.Name = ".AspNetCore.Antiforgery";
            options.Cookie.SameSite = Microsoft.AspNetCore.Http.SameSiteMode.Strict;
            options.Cookie.SecurePolicy = environment.IsProduction()
                ? Microsoft.AspNetCore.Http.CookieSecurePolicy.Always
                : Microsoft.AspNetCore.Http.CookieSecurePolicy.SameAsRequest;
            options.Cookie.HttpOnly = true;
        });

        return services;
    }

    /// <summary>
    /// Регистрация Health Checks
    /// </summary>
    public static IServiceCollection AddHealthCheckServices(this IServiceCollection services)
    {
        services.AddHealthChecks()
            .AddCheck<KeycloakHealthCheck>(
                "keycloak",
                failureStatus: Microsoft.Extensions.Diagnostics.HealthChecks.HealthStatus.Unhealthy,
                tags: new[] { "external", "keycloak" })
            .AddCheck<SqliteHealthCheck>(
                "sqlite",
                failureStatus: Microsoft.Extensions.Diagnostics.HealthChecks.HealthStatus.Unhealthy,
                tags: new[] { "database", "sqlite" })
            .AddCheck<ConfluenceHealthCheck>(
                "confluence",
                failureStatus: Microsoft.Extensions.Diagnostics.HealthChecks.HealthStatus.Degraded,
                tags: new[] { "external", "confluence" });

        return services;
    }

    /// <summary>
    /// Регистрация Cookie Policy
    /// </summary>
    public static IServiceCollection AddCookiePolicyConfiguration(this IServiceCollection services, IHostEnvironment environment)
    {
        services.Configure<Microsoft.AspNetCore.Builder.CookiePolicyOptions>(options =>
        {
            options.MinimumSameSitePolicy = Microsoft.AspNetCore.Http.SameSiteMode.Unspecified;
            options.HttpOnly = Microsoft.AspNetCore.CookiePolicy.HttpOnlyPolicy.Always;
            options.Secure = environment.IsProduction()
                ? Microsoft.AspNetCore.Http.CookieSecurePolicy.Always
                : Microsoft.AspNetCore.Http.CookieSecurePolicy.None; // Для HTTP в разработке
        });

        return services;
    }

    /// <summary>
    /// Настроить типизированный HttpClient для User Management сервисов
    /// </summary>
    private static void ConfigureTypedHttpClient<TClient, TImplementation>(
        IServiceCollection services, 
        bool ignoreSslErrors, 
        string serviceName)
        where TClient : class
        where TImplementation : class, TClient
    {
        services.AddHttpClient<TClient, TImplementation>()
            .ConfigurePrimaryHttpMessageHandler(() => CreateHttpMessageHandler(ignoreSslErrors, serviceName))
            .ConfigureHttpClient((sp, client) =>
            {
                var settings = sp.GetRequiredService<IOptions<KeycloakAdminSettings>>().Value;
                if (settings != null)
                {
                    var logger = sp.GetService<ILoggerFactory>()?.CreateLogger("ServiceCollectionExtensions");
                    ConfigureHttpClientBase(client, settings.BaseUrl, settings.RequestTimeoutSeconds, logger);
                }
            })
            .AddPolicyHandler(GetRetryPolicy())
            .AddPolicyHandler(GetCircuitBreakerPolicy());
    }

    /// <summary>
    /// Настроить базовые параметры HttpClient (BaseAddress, Timeout, Accept header)
    /// </summary>
    private static void ConfigureHttpClientBase(HttpClient client, string? baseUrl, int timeoutSeconds, ILogger? logger = null)
    {
        if (!string.IsNullOrEmpty(baseUrl))
        {
            if (Uri.TryCreate(baseUrl, UriKind.Absolute, out var baseUri))
            {
                client.BaseAddress = baseUri;
            }
            else
            {
                logger?.LogWarning("Invalid BaseUrl: {BaseUrl}", baseUrl);
            }
        }
        
        client.Timeout = TimeSpan.FromSeconds(timeoutSeconds);
        
        if (!client.DefaultRequestHeaders.Contains("Accept"))
        {
            client.DefaultRequestHeaders.Add("Accept", "application/json");
        }
    }

    /// <summary>
    /// Настроить HttpClient для Keycloak Stage с учетом legacy auth path
    /// </summary>
    private static void ConfigureKeycloakStageHttpClient(HttpClient client, KeycloakStageSettings settings, ILogger? logger = null)
    {
        var baseUrl = settings.BaseUrl?.TrimEnd('/') 
            ?? throw new InvalidOperationException("KeycloakStageSettings.BaseUrl is required");

        var adminApiBaseUrl = settings.UseLegacyAuthPath && !baseUrl.EndsWith("/auth", StringComparison.OrdinalIgnoreCase)
            ? $"{baseUrl}/auth/"
            : (baseUrl.EndsWith("/") ? baseUrl : baseUrl + "/");

        // Валидация URI перед использованием
        if (!Uri.TryCreate(adminApiBaseUrl, UriKind.Absolute, out var baseUri))
        {
            throw new InvalidOperationException($"Invalid BaseUrl in KeycloakStageSettings: {adminApiBaseUrl}");
        }
        
        client.BaseAddress = baseUri;
        client.Timeout = TimeSpan.FromSeconds(settings.RequestTimeoutSeconds);
        
        if (!client.DefaultRequestHeaders.Contains("Accept"))
        {
            client.DefaultRequestHeaders.Add("Accept", "application/json");
        }
    }

    /// <summary>
    /// Получить политику retry для HTTP клиентов
    /// </summary>
    private static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy()
    {
        return Policy
            .HandleResult<HttpResponseMessage>(r => 
                r.StatusCode >= HttpStatusCode.InternalServerError || 
                r.StatusCode == HttpStatusCode.RequestTimeout ||
                r.StatusCode == HttpStatusCode.TooManyRequests)
            .Or<TaskCanceledException>()
            .Or<HttpRequestException>()
            .WaitAndRetryAsync(
                retryCount: 3,
                sleepDurationProvider: retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                onRetry: (outcome, timespan, retryCount, context) =>
                {
                    // Логирование retry будет выполнено через ILogger в вызывающем коде
                    // Здесь можно добавить дополнительное логирование или метрики при необходимости
                });
    }

    /// <summary>
    /// Получить политику circuit breaker для HTTP клиентов
    /// </summary>
    private static IAsyncPolicy<HttpResponseMessage> GetCircuitBreakerPolicy()
    {
        return Policy
            .HandleResult<HttpResponseMessage>(r => 
                r.StatusCode >= HttpStatusCode.InternalServerError || 
                r.StatusCode == HttpStatusCode.RequestTimeout)
            .Or<TaskCanceledException>()
            .Or<HttpRequestException>()
            .CircuitBreakerAsync(
                handledEventsAllowedBeforeBreaking: 5,
                durationOfBreak: TimeSpan.FromSeconds(30));
    }
}

