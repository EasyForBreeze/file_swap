using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using System;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Net;
using System.Threading.RateLimiting;

namespace new_assistant.Infrastructure.Extensions;

/// <summary>
/// Extension методы для настройки Rate Limiting
/// </summary>
public static class RateLimitingExtensions
{
    private static readonly Meter Meter = new("RateLimiting");
    private static readonly Counter<long> RateLimitExceededCounter = 
        Meter.CreateCounter<long>("rate_limit_exceeded_total", "count", "Total number of rate limit exceeded events");

    /// <summary>
    /// Добавление Rate Limiting для защиты от брутфорса и DDoS атак.
    /// 
    /// Реализует три политики:
    /// 1. "auth" - для аутентификации (SlidingWindow, строгие лимиты)
    /// 2. "api" - для обычных API запросов (SlidingWindow, средние лимиты)
    /// 3. "admin" - для администраторов (TokenBucket, высокие лимиты)
    /// 4. "health" - для health checks (SlidingWindow, высокие лимиты)
    /// 
    /// Поддерживает:
    /// - Разделение по IP адресам и пользователям через PartitionedRateLimiter
    /// - Белый список для исключений
    /// - Логирование и метрики
    /// - Валидацию конфигурации
    /// - Нормализацию IP адресов
    /// </summary>
    /// <param name="services">Коллекция сервисов</param>
    /// <param name="configuration">Конфигурация приложения</param>
    /// <returns>Коллекция сервисов для цепочки вызовов</returns>
    /// <exception cref="InvalidOperationException">Выбрасывается при некорректной конфигурации</exception>
    public static IServiceCollection AddRateLimitingConfiguration(this IServiceCollection services, IConfiguration configuration)
    {
        // Регистрация настроек через IOptions (уже должна быть зарегистрирована в AddApplicationSettings)
        services.Configure<RateLimitingSettings>(configuration.GetSection("RateLimiting"));

        try
        {
            // Получаем настройки напрямую из конфигурации для валидации
            var rateLimitingSettings = configuration.GetSection("RateLimiting").Get<RateLimitingSettings>() 
                ?? new RateLimitingSettings();

            // Валидация конфигурации
            ValidateRateLimitingSettings(rateLimitingSettings);

            if (rateLimitingSettings.Enabled)
            {
                services.AddRateLimiter(options =>
                {
                    // Настройка обработчика отклоненных запросов (общий для всех политик)
                    ConfigureRejectionHandler(options, rateLimitingSettings);

                    // Политики с разделением по IP/пользователям
                    ConfigureAuthPolicy(options, rateLimitingSettings);
                    ConfigureApiPolicy(options, rateLimitingSettings);
                    ConfigureAdminPolicy(options, rateLimitingSettings);
                    ConfigureHealthPolicy(options, rateLimitingSettings);
                });
            }
        }
        catch (InvalidOperationException)
        {
            // Пробрасываем ошибки валидации дальше
            throw;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                $"Failed to configure rate limiting: {ex.Message}. Check configuration and logs for details.", ex);
        }

        return services;
    }

    /// <summary>
    /// Политика для аутентификации - Sliding Window для более точного контроля.
    /// 
    /// SlidingWindow выбран потому что:
    /// 1. Обеспечивает более плавное распределение запросов во времени
    /// 2. Предотвращает "burst" атаки в начале временного окна
    /// 3. Дает более предсказуемое поведение для защиты от брутфорса
    /// 
    /// Сегменты: 6 сегментов по 10 секунд дают баланс между точностью и производительностью.
    /// </summary>
    private static void ConfigureAuthPolicy(RateLimiterOptions options, RateLimitingSettings settings)
    {
        // Используем AddPolicy с кастомным PartitionedRateLimiter для разделения по IP/пользователям
        // В .NET 9 AddPolicy принимает функцию, которая возвращает RateLimitPartition
        // Создаем функцию напрямую, используя логику из CreatePartitionedLimiterCore
        options.AddPolicy<string>("auth", CreatePartitionedLimiterFunction(
            settings, 
            settings.AuthRequestsPerMinute, 
            (limit) => new SlidingWindowRateLimiterOptions
            {
                PermitLimit = limit,
                Window = TimeSpan.FromMinutes(1),
                SegmentsPerWindow = settings.SegmentsPerWindow,
                QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                QueueLimit = 3
            },
            options => new SlidingWindowRateLimiter(options)));
    }

    /// <summary>
    /// Политика для обычных API запросов - Sliding Window.
    /// 
    /// Использует те же принципы, что и auth политика, но с более высокими лимитами
    /// и большей очередью для обработки легитимных всплесков трафика.
    /// </summary>
    private static void ConfigureApiPolicy(RateLimiterOptions options, RateLimitingSettings settings)
    {
        // Создаем функцию напрямую, используя логику из CreatePartitionedLimiterCore
        options.AddPolicy<string>("api", CreatePartitionedLimiterFunction(
            settings, 
            settings.ApiRequestsPerMinute, 
            (limit) => new SlidingWindowRateLimiterOptions
            {
                PermitLimit = limit,
                Window = TimeSpan.FromMinutes(1),
                SegmentsPerWindow = settings.SegmentsPerWindow,
                QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                QueueLimit = 10
            },
            options => new SlidingWindowRateLimiter(options)));
    }

    /// <summary>
    /// Политика для администраторов - Token Bucket для плавного контроля.
    /// 
    /// TokenBucket выбран потому что:
    /// 1. Позволяет накапливать токены при низкой нагрузке
    /// 2. Обеспечивает более гибкое использование лимитов
    /// 3. Подходит для административных операций, которые могут быть пакетными
    /// 
    /// AutoReplenishment включен для автоматического пополнения токенов.
    /// </summary>
    private static void ConfigureAdminPolicy(RateLimiterOptions options, RateLimitingSettings settings)
    {
        // Создаем функцию напрямую, используя логику из CreatePartitionedLimiterCore
        options.AddPolicy<string>("admin", CreatePartitionedLimiterFunction(
            settings, 
            settings.AdminApiRequestsPerMinute, 
            (limit) => new TokenBucketRateLimiterOptions
            {
                TokenLimit = limit,
                ReplenishmentPeriod = TimeSpan.FromMinutes(1),
                TokensPerPeriod = limit,
                QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                QueueLimit = 20,
                AutoReplenishment = true
            },
            options => new TokenBucketRateLimiter(options)));
    }

    /// <summary>
    /// Политика для health checks - Sliding Window с высокими лимитами.
    /// 
    /// Health checks должны быть доступны, но с разумными лимитами для защиты от DDoS.
    /// </summary>
    private static void ConfigureHealthPolicy(RateLimiterOptions options, RateLimitingSettings settings)
    {
        // Высокий лимит для health checks, но все же ограниченный
        const int healthCheckLimit = 1000;
        
        // Создаем функцию напрямую, используя логику из CreatePartitionedLimiterCore
        options.AddPolicy<string>("health", CreatePartitionedLimiterFunction(
            settings, 
            healthCheckLimit, 
            (limit) => new SlidingWindowRateLimiterOptions
            {
                PermitLimit = limit,
                Window = TimeSpan.FromMinutes(1),
                SegmentsPerWindow = settings.SegmentsPerWindow,
                QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                QueueLimit = 50
            },
            options => new SlidingWindowRateLimiter(options)));
    }

    /// <summary>
    /// Создает PartitionedRateLimiter с разделением по IP/пользователям и поддержкой белого списка.
    /// Использует SlidingWindowRateLimiterOptions.
    /// </summary>
    private static PartitionedRateLimiter<HttpContext> CreatePartitionedLimiter(
        RateLimitingSettings settings,
        int defaultLimit,
        Func<int, SlidingWindowRateLimiterOptions> createLimiterOptions)
    {
        return CreatePartitionedLimiterCore(
            settings,
            defaultLimit,
            createLimiterOptions,
            options => new SlidingWindowRateLimiter(options));
    }

    /// <summary>
    /// Создает PartitionedRateLimiter с разделением по IP/пользователям и поддержкой белого списка.
    /// Использует TokenBucketRateLimiterOptions.
    /// </summary>
    private static PartitionedRateLimiter<HttpContext> CreatePartitionedLimiter(
        RateLimitingSettings settings,
        int defaultLimit,
        Func<int, TokenBucketRateLimiterOptions> createLimiterOptions)
    {
        return CreatePartitionedLimiterCore(
            settings,
            defaultLimit,
            createLimiterOptions,
            options => new TokenBucketRateLimiter(options));
    }

    /// <summary>
    /// Базовая реализация создания PartitionedRateLimiter с разделением по IP/пользователям.
    /// Вынесена в отдельный метод для устранения дублирования кода.
    /// </summary>
    private static PartitionedRateLimiter<HttpContext> CreatePartitionedLimiterCore<TOptions>(
        RateLimitingSettings settings,
        int defaultLimit,
        Func<int, TOptions> createLimiterOptions,
        Func<TOptions, RateLimiter> createRateLimiter)
    {
        return PartitionedRateLimiter.Create<HttpContext, string>(context =>
        {
            // Нормализация IP адреса
            var normalizedIp = NormalizeIpAddress(context.Connection.RemoteIpAddress);
            
            // Проверка белого списка IP
            if (!string.IsNullOrEmpty(normalizedIp) && settings.BypassIpAddresses.Contains(normalizedIp))
            {
                return RateLimitPartition.GetNoLimiter("bypass-ip");
            }

            // Проверка белого списка пользователей
            var userName = context.User?.Identity?.Name;
            if (!string.IsNullOrEmpty(userName) && settings.BypassUserNames.Contains(userName))
            {
                return RateLimitPartition.GetNoLimiter("bypass-user");
            }

            // Приоритет: аутентифицированный пользователь > IP адрес
            if (!string.IsNullOrEmpty(userName))
            {
                // Для аутентифицированных пользователей используем имя пользователя как ключ
                return RateLimitPartition.Get($"user:{userName}", _ =>
                {
                    var options = createLimiterOptions(defaultLimit);
                    return createRateLimiter(options);
                });
            }

            // Для неаутентифицированных пользователей используем IP адрес
            var ipKey = $"ip:{normalizedIp ?? "unknown"}";
            return RateLimitPartition.Get(ipKey, _ =>
            {
                var options = createLimiterOptions(defaultLimit);
                return createRateLimiter(options);
            });
        });
    }

    /// <summary>
    /// Создает функцию для AddPolicy, которая возвращает RateLimitPartition.
    /// Используется вместо создания PartitionedRateLimiter, так как AddPolicy принимает Func напрямую.
    /// </summary>
    private static Func<HttpContext, RateLimitPartition<string>> CreatePartitionedLimiterFunction<TOptions>(
        RateLimitingSettings settings,
        int defaultLimit,
        Func<int, TOptions> createLimiterOptions,
        Func<TOptions, RateLimiter> createRateLimiter)
    {
        return context =>
        {
            // Нормализация IP адреса
            var normalizedIp = NormalizeIpAddress(context.Connection.RemoteIpAddress);
            
            // Проверка белого списка IP
            if (!string.IsNullOrEmpty(normalizedIp) && settings.BypassIpAddresses.Contains(normalizedIp))
            {
                return RateLimitPartition.GetNoLimiter("bypass-ip");
            }

            // Проверка белого списка пользователей
            var userName = context.User?.Identity?.Name;
            if (!string.IsNullOrEmpty(userName) && settings.BypassUserNames.Contains(userName))
            {
                return RateLimitPartition.GetNoLimiter("bypass-user");
            }

            // Приоритет: аутентифицированный пользователь > IP адрес
            if (!string.IsNullOrEmpty(userName))
            {
                // Для аутентифицированных пользователей используем имя пользователя как ключ
                return RateLimitPartition.Get($"user:{userName}", _ =>
                {
                    var options = createLimiterOptions(defaultLimit);
                    return createRateLimiter(options);
                });
            }

            // Для неаутентифицированных пользователей используем IP адрес
            var ipKey = $"ip:{normalizedIp ?? "unknown"}";
            return RateLimitPartition.Get(ipKey, _ =>
            {
                var options = createLimiterOptions(defaultLimit);
                return createRateLimiter(options);
            });
        };
    }

    /// <summary>
    /// Нормализует IP адрес для консистентного сравнения.
    /// Обрабатывает IPv4-mapped IPv6 адреса и приводит к единому формату.
    /// </summary>
    private static string? NormalizeIpAddress(IPAddress? ipAddress)
    {
        if (ipAddress == null) return null;
        
        // Для IPv4-mapped IPv6 адресов, извлекаем IPv4
        if (ipAddress.IsIPv4MappedToIPv6)
        {
            return ipAddress.MapToIPv4().ToString();
        }
        
        return ipAddress.ToString();
    }

    /// <summary>
    /// Определяет имя политики rate limiting на основе пути запроса.
    /// </summary>
    /// <param name="path">Путь HTTP запроса</param>
    /// <returns>Имя политики или "unknown" если не удалось определить</returns>
    private static string DeterminePolicyNameFromPath(PathString path)
    {
        var pathValue = path.Value ?? string.Empty;
        
        // Определяем политику по пути запроса
        if (pathValue.StartsWith("/api/auth", StringComparison.OrdinalIgnoreCase) ||
            pathValue.StartsWith("/signin-oidc", StringComparison.OrdinalIgnoreCase) ||
            pathValue.StartsWith("/signout-callback-oidc", StringComparison.OrdinalIgnoreCase))
        {
            return "auth";
        }
        
        if (pathValue.StartsWith("/api/admin", StringComparison.OrdinalIgnoreCase))
        {
            return "admin";
        }
        
        if (pathValue.StartsWith("/health", StringComparison.OrdinalIgnoreCase))
        {
            return "health";
        }
        
        if (pathValue.StartsWith("/api", StringComparison.OrdinalIgnoreCase))
        {
            return "api";
        }
        
        return "unknown";
    }

    /// <summary>
    /// Настройка обработчика отклоненных запросов с логированием и метриками.
    /// </summary>
    private static void ConfigureRejectionHandler(RateLimiterOptions options, RateLimitingSettings settings)
    {
        options.RejectionStatusCode = 429;

        options.OnRejected = async (context, token) =>
        {
            var httpContext = context.HttpContext;
            var loggerFactory = httpContext.RequestServices.GetService<ILoggerFactory>();
            var logger = loggerFactory?.CreateLogger("RateLimitingExtensions");
            
            // Получаем актуальные настройки через IOptions для поддержки hot-reload
            var currentSettings = httpContext.RequestServices
                .GetService<IOptions<RateLimitingSettings>>()?.Value ?? settings;
            
            // В .NET 9 OnRejectedContext может не иметь свойства PolicyName
            // Используем альтернативный способ получения имени политики на основе пути запроса
            // Это более надежный способ, чем полагаться на RouteValues
            var policyName = DeterminePolicyNameFromPath(httpContext.Request.Path);
            var remoteIp = NormalizeIpAddress(httpContext.Connection.RemoteIpAddress) ?? "unknown";
            var path = httpContext.Request.Path.Value ?? "unknown";
            var method = httpContext.Request.Method;
            var userName = httpContext.User?.Identity?.Name ?? "anonymous";

            // Логирование
            logger?.LogWarning(
                "Rate limit exceeded: Policy={Policy}, IP={IP}, User={User}, Path={Path}, Method={Method}",
                policyName, remoteIp, userName, path, method);

            // Метрики
            RateLimitExceededCounter.Add(1, 
                new("policy", policyName),
                new("ip", remoteIp),
                new("path", path),
                new("method", method));

            // Установка статуса и заголовков
            httpContext.Response.StatusCode = 429;
            
            // Безопасное добавление заголовка Retry-After
            if (!httpContext.Response.Headers.ContainsKey("Retry-After"))
            {
                httpContext.Response.Headers["Retry-After"] = currentSettings.RetryAfterSeconds.ToString();
            }

            // Сообщение об ошибке
            var errorMessage = currentSettings.ErrorMessage ?? "Too many requests. Please try again later.";
            await httpContext.Response.WriteAsync(errorMessage, token);
        };
    }

    /// <summary>
    /// Валидация настроек rate limiting.
    /// Проверяет, что все параметры находятся в допустимых диапазонах.
    /// </summary>
    /// <param name="settings">Настройки для валидации</param>
    /// <exception cref="InvalidOperationException">Выбрасывается при некорректных значениях</exception>
    private static void ValidateRateLimitingSettings(RateLimitingSettings settings)
    {
        if (settings == null)
        {
            throw new InvalidOperationException("RateLimitingSettings cannot be null");
        }

        if (settings.AuthRequestsPerMinute <= 0 || settings.AuthRequestsPerMinute > 1000)
        {
            throw new InvalidOperationException(
                $"AuthRequestsPerMinute must be between 1 and 1000, got {settings.AuthRequestsPerMinute}");
        }

        if (settings.ApiRequestsPerMinute <= 0 || settings.ApiRequestsPerMinute > 10000)
        {
            throw new InvalidOperationException(
                $"ApiRequestsPerMinute must be between 1 and 10000, got {settings.ApiRequestsPerMinute}");
        }

        if (settings.AdminApiRequestsPerMinute <= 0 || settings.AdminApiRequestsPerMinute > 100000)
        {
            throw new InvalidOperationException(
                $"AdminApiRequestsPerMinute must be between 1 and 100000, got {settings.AdminApiRequestsPerMinute}");
        }

        if (settings.BlockDurationMinutes < 0 || settings.BlockDurationMinutes > 1440)
        {
            throw new InvalidOperationException(
                $"BlockDurationMinutes must be between 0 and 1440 (24 hours), got {settings.BlockDurationMinutes}");
        }

        // Валидация SegmentsPerWindow относительно размера окна (1 минута = 60 секунд)
        const int windowSeconds = 60;
        if (settings.SegmentsPerWindow <= 0 || settings.SegmentsPerWindow > windowSeconds)
        {
            throw new InvalidOperationException(
                $"SegmentsPerWindow must be between 1 and {windowSeconds} (window size in seconds), got {settings.SegmentsPerWindow}");
        }

        if (settings.RetryAfterSeconds <= 0 || settings.RetryAfterSeconds > 3600)
        {
            throw new InvalidOperationException(
                $"RetryAfterSeconds must be between 1 and 3600 (1 hour), got {settings.RetryAfterSeconds}");
        }

        // Валидация IP адресов в белом списке
        foreach (var ip in settings.BypassIpAddresses)
        {
            if (string.IsNullOrWhiteSpace(ip))
            {
                throw new InvalidOperationException(
                    "BypassIpAddresses cannot contain empty or whitespace values");
            }
            
            if (!IPAddress.TryParse(ip, out _))
            {
                throw new InvalidOperationException(
                    $"Invalid IP address in BypassIpAddresses: {ip}");
            }
        }

        // Валидация имен пользователей в белом списке
        foreach (var userName in settings.BypassUserNames)
        {
            if (string.IsNullOrWhiteSpace(userName))
            {
                throw new InvalidOperationException(
                    "BypassUserNames cannot contain empty or whitespace values");
            }
        }
    }
}
