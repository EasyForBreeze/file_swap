using Microsoft.Data.Sqlite;
using new_assistant.Configuration;
using new_assistant.Core.Entities;
using new_assistant.Core.Interfaces;
using new_assistant.Infrastructure.Services;

namespace new_assistant.Infrastructure.Data;

/// <summary>
/// Репозиторий для работы с запрещенными клиентами в SQLite
/// </summary>
public class ForbiddenClientRepository : IForbiddenClientRepository
{
    private readonly string _connectionString;
    private readonly ILogger<ForbiddenClientRepository> _logger;
    private readonly Lazy<Task> _initializeTask;
    
    private const string DatabaseName = "forbidden_clients";
    
    /// <summary>
    /// Получить статистику производительности SQLite
    /// </summary>
    public (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetPerformanceStats()
    {
        return SqlitePerformanceMonitor.GetTotalStats();
    }
    
    /// <summary>
    /// Сбросить статистику производительности SQLite
    /// </summary>
    public void ResetPerformanceStats()
    {
        SqlitePerformanceMonitor.ResetAllStats();
    }

    public ForbiddenClientRepository(DataPathsSettings dataPathsSettings, ILogger<ForbiddenClientRepository> logger)
    {
        _logger = logger;
        var dbPath = dataPathsSettings.GetForbiddenClientsDbPath();
        
        _connectionString = $"Data Source={dbPath};Mode=ReadWriteCreate;Cache=Shared;Pooling=True";
        
        // Lazy initialization - БД инициализируется только при первом использовании
        _initializeTask = new Lazy<Task>(() => InitializeDatabaseAsync());
    }

    /// <summary>
    /// Асинхронная инициализация базы данных (вызывается автоматически при первом использовании)
    /// </summary>
    private async Task InitializeDatabaseAsync()
    {
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);

            await using var command = connection.CreateCommand();
            command.CommandText = @"
                CREATE TABLE IF NOT EXISTS ForbiddenClients (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ClientId TEXT NOT NULL,
                    Realm TEXT NOT NULL,
                    AddedBy TEXT NOT NULL,
                    AddedAt TEXT NOT NULL,
                    UNIQUE(ClientId, Realm)
                );
                
                CREATE INDEX IF NOT EXISTS idx_forbidden_client_realm ON ForbiddenClients(ClientId, Realm);
                CREATE INDEX IF NOT EXISTS idx_forbidden_realm ON ForbiddenClients(Realm);
            ";
            await command.ExecuteNonQueryAsync().ConfigureAwait(false);
            
            _logger.LogDebug("База данных forbidden_clients успешно инициализирована");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка инициализации базы данных forbidden_clients");
            throw;
        }
    }

    /// <summary>
    /// Гарантирует, что БД инициализирована перед выполнением операции
    /// </summary>
    private async Task EnsureInitializedAsync()
    {
        await _initializeTask.Value.ConfigureAwait(false);
    }

    public async Task<List<ForbiddenClient>> GetAllAsync()
    {
        // Гарантируем инициализацию БД перед использованием
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        var clients = new List<ForbiddenClient>();
        
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync().ConfigureAwait(false);

        var command = connection.CreateCommand();
        command.CommandText = "SELECT Id, ClientId, Realm, AddedBy, AddedAt FROM ForbiddenClients ORDER BY AddedAt DESC";

        using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            clients.Add(new ForbiddenClient
            {
                Id = reader.GetInt32(0),
                ClientId = reader.GetString(1),
                Realm = reader.GetString(2),
                AddedBy = reader.GetString(3),
                AddedAt = DateTime.Parse(reader.GetString(4))
            });
        }

        stopwatch.Stop();
        SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        return clients;
    }

    public async Task<List<ForbiddenClient>> GetByRealmAsync(string realm)
    {
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        var clients = new List<ForbiddenClient>();
        
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync().ConfigureAwait(false);

        var command = connection.CreateCommand();
        command.CommandText = "SELECT Id, ClientId, Realm, AddedBy, AddedAt FROM ForbiddenClients WHERE Realm = @realm ORDER BY AddedAt DESC";
        command.Parameters.AddWithValue("@realm", realm);

        using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            clients.Add(new ForbiddenClient
            {
                Id = reader.GetInt32(0),
                ClientId = reader.GetString(1),
                Realm = reader.GetString(2),
                AddedBy = reader.GetString(3),
                AddedAt = DateTime.Parse(reader.GetString(4))
            });
        }

        stopwatch.Stop();
        SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        return clients;
    }

    public async Task<bool> IsForbiddenAsync(string clientId, string realm, CancellationToken cancellationToken = default)
    {
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken).ConfigureAwait(false);

        var command = connection.CreateCommand();
        command.CommandText = "SELECT COUNT(*) FROM ForbiddenClients WHERE ClientId = @clientId AND Realm = @realm";
        command.Parameters.AddWithValue("@clientId", clientId);
        command.Parameters.AddWithValue("@realm", realm);

        var count = (long)(await command.ExecuteScalarAsync(cancellationToken) ?? 0L);
        
        stopwatch.Stop();
        SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        return count > 0;
    }

    public async Task<bool> AddAsync(string clientId, string realm, string addedBy)
    {
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);

            var command = connection.CreateCommand();
            command.CommandText = @"
                INSERT INTO ForbiddenClients (ClientId, Realm, AddedBy, AddedAt)
                VALUES (@clientId, @realm, @addedBy, @addedAt)
            ";
            command.Parameters.AddWithValue("@clientId", clientId);
            command.Parameters.AddWithValue("@realm", realm);
            command.Parameters.AddWithValue("@addedBy", addedBy);
            command.Parameters.AddWithValue("@addedAt", DateTime.UtcNow.ToString("O"));

            var rowsAffected = await command.ExecuteNonQueryAsync();
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            if (rowsAffected > 0)
            {
                _logger.LogWarning("Добавление запрещенного клиента - {Time}мс", stopwatch.ElapsedMilliseconds);
            }
            else
            {
                _logger.LogWarning("Добавление запрещенного клиента (0 строк) - {Time}мс", stopwatch.ElapsedMilliseconds);
            }
            
            return rowsAffected > 0;
        }
        catch (SqliteException ex) when (ex.SqliteErrorCode == 19) // UNIQUE constraint violation
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogWarning("Добавление запрещенного клиента (уже существует) - {Time}мс", stopwatch.ElapsedMilliseconds);
            return false;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка добавления запрещенного клиента - {Time}мс", stopwatch.ElapsedMilliseconds);
            return false;
        }
    }

    public async Task<bool> RemoveAsync(string clientId, string realm)
    {
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);

            var command = connection.CreateCommand();
            command.CommandText = "DELETE FROM ForbiddenClients WHERE ClientId = @clientId AND Realm = @realm";
            command.Parameters.AddWithValue("@clientId", clientId);
            command.Parameters.AddWithValue("@realm", realm);

            var rowsAffected = await command.ExecuteNonQueryAsync();
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            if (rowsAffected > 0)
            {
                _logger.LogWarning("Удаление запрещенного клиента - {Time}мс", stopwatch.ElapsedMilliseconds);
            }
            else
            {
                _logger.LogWarning("Удаление запрещенного клиента (не найден) - {Time}мс", stopwatch.ElapsedMilliseconds);
            }
            
            return rowsAffected > 0;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка удаления запрещенного клиента - {Time}мс", stopwatch.ElapsedMilliseconds);
            return false;
        }
    }

    public async Task<List<string>> GetForbiddenClientIdsAsync(string realm)
    {
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        var clientIds = new List<string>();
        
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync().ConfigureAwait(false);

        var command = connection.CreateCommand();
        command.CommandText = "SELECT ClientId FROM ForbiddenClients WHERE Realm = @realm";
        command.Parameters.AddWithValue("@realm", realm);

        using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            clientIds.Add(reader.GetString(0));
        }

        stopwatch.Stop();
        SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        return clientIds;
    }

    public async Task<List<(string ClientId, string Realm)>> GetAllForbiddenClientIdsAsync(CancellationToken cancellationToken = default)
    {
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        var clients = new List<(string ClientId, string Realm)>();
        
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken).ConfigureAwait(false);

        var command = connection.CreateCommand();
        command.CommandText = "SELECT ClientId, Realm FROM ForbiddenClients";

        using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            clients.Add((reader.GetString(0), reader.GetString(1)));
        }

        stopwatch.Stop();
        SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        return clients;
    }
}

