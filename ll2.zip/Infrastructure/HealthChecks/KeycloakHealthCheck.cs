using Microsoft.Extensions.Diagnostics.HealthChecks;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.HealthChecks;

/// <summary>
/// Health check для проверки доступности Keycloak
/// </summary>
public class KeycloakHealthCheck : IHealthCheck
{
    private readonly IKeycloakAdminService _keycloakService;
    private readonly ILogger<KeycloakHealthCheck> _logger;

    public KeycloakHealthCheck(IKeycloakAdminService keycloakService, ILogger<KeycloakHealthCheck> logger)
    {
        _keycloakService = keycloakService;
        _logger = logger;
    }

    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            // Пытаемся получить список реалмов (быстрая операция)
            var realms = await _keycloakService.GetRealmsListAsync(cancellationToken);
            
            if (realms == null || !realms.Any())
            {
                return HealthCheckResult.Degraded(
                    "Keycloak доступен, но не вернул список реалмов",
                    data: new Dictionary<string, object>
                    {
                        { "realmsCount", 0 },
                        { "timestamp", DateTime.UtcNow }
                    });
            }

            var stats = _keycloakService.GetPerformanceStats();
            
            return HealthCheckResult.Healthy(
                $"Keycloak работает нормально. Реалмов: {realms.Count()}",
                data: new Dictionary<string, object>
                {
                    { "realmsCount", realms.Count() },
                    { "totalRequests", stats.RequestCount },
                    { "averageResponseTime", $"{stats.AverageTimeMs:F2}ms" },
                    { "timestamp", DateTime.UtcNow }
                });
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Keycloak недоступен: HTTP ошибка");
            return HealthCheckResult.Unhealthy(
                $"Keycloak недоступен: {ex.Message}",
                ex,
                data: new Dictionary<string, object>
                {
                    { "error", ex.Message },
                    { "timestamp", DateTime.UtcNow }
                });
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogWarning(ex, "Keycloak health check timeout");
            return HealthCheckResult.Unhealthy(
                "Keycloak не отвечает (timeout)",
                ex,
                data: new Dictionary<string, object>
                {
                    { "error", "Timeout" },
                    { "timestamp", DateTime.UtcNow }
                });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при проверке Keycloak");
            return HealthCheckResult.Unhealthy(
                $"Ошибка проверки Keycloak: {ex.Message}",
                ex,
                data: new Dictionary<string, object>
                {
                    { "error", ex.GetType().Name },
                    { "message", ex.Message },
                    { "timestamp", DateTime.UtcNow }
                });
        }
    }
}

