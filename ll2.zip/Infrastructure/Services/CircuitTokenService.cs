using System;
using System.Collections.Concurrent;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components.Server.Circuits;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для хранения и обновления токенов в рамках Blazor Circuit
/// </summary>
public class CircuitTokenService : CircuitHandler, ITokenRefreshService, IDisposable
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IConfiguration _configuration;
    private readonly ILogger<CircuitTokenService> _logger;
    private readonly IDataProtector _dataProtector;
    private readonly ConcurrentDictionary<string, TokenInfo> _circuitTokens = new();
    private readonly ConcurrentDictionary<string, SemaphoreSlim> _refreshSemaphores = new();
    
    // Используем AsyncLocal для потокобезопасного хранения circuit ID в контексте выполнения
    private static readonly AsyncLocal<string?> _currentCircuitId = new();
    
    // Статический экземпляр JwtSecurityTokenHandler для переиспользования
    private static readonly JwtSecurityTokenHandler _tokenHandler = new();
    
    // Таймаут для HTTP запросов (30 секунд)
    private static readonly TimeSpan HttpClientTimeout = TimeSpan.FromSeconds(30);
    
    // Параметры retry логики (настраиваются через конфигурацию)
    private readonly int _maxRetries;
    private readonly TimeSpan _initialRetryDelay;
    
    // Время кэширования результата проверки истечения токена (настраивается через конфигурацию)
    private readonly TimeSpan _expirationCheckCacheDuration;
    
    // Запас времени для проверки истечения токена (настраивается через конфигурацию)
    private readonly int _tokenExpirationBufferSeconds;
    
    // Параметры для периодической очистки старых токенов
    private readonly TimeSpan _tokenMaxAge;
    private readonly TimeSpan _cleanupInterval;
    private Timer? _cleanupTimer;
    
    // Метрики
    private long _tokenRefreshCount = 0;
    private long _tokenRefreshSuccesses = 0;
    private long _tokenRefreshFailures = 0;
    
    // Флаг для отслеживания состояния Dispose (volatile для потокобезопасности)
    private volatile bool _disposed = false;

    public CircuitTokenService(
        IHttpClientFactory httpClientFactory,
        IConfiguration configuration,
        ILogger<CircuitTokenService> logger,
        IDataProtectionProvider dataProtectionProvider)
    {
        _httpClientFactory = httpClientFactory ?? throw new ArgumentNullException(nameof(httpClientFactory));
        _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _dataProtector = dataProtectionProvider?.CreateProtector("CircuitTokenService.Tokens") 
            ?? throw new ArgumentNullException(nameof(dataProtectionProvider));
        
        // Получаем запас времени из конфигурации (по умолчанию 30 секунд)
        _tokenExpirationBufferSeconds = configuration.GetValue<int>(
            "TokenRefresh:ExpirationBufferSeconds", 
            defaultValue: 30);
        
        // Получаем параметры retry логики из конфигурации
        _maxRetries = configuration.GetValue<int>(
            "TokenRefresh:MaxRetries",
            defaultValue: 3);
        var initialRetryDelaySeconds = configuration.GetValue<int>(
            "TokenRefresh:InitialRetryDelaySeconds",
            defaultValue: 1);
        _initialRetryDelay = TimeSpan.FromSeconds(initialRetryDelaySeconds);
        
        // Получаем время кэширования проверки истечения (по умолчанию 30 секунд)
        var cacheDurationSeconds = configuration.GetValue<int>(
            "TokenRefresh:ExpirationCheckCacheDurationSeconds",
            defaultValue: 30);
        _expirationCheckCacheDuration = TimeSpan.FromSeconds(cacheDurationSeconds);
        
        // Параметры периодической очистки старых токенов
        var tokenMaxAgeHours = configuration.GetValue<int>(
            "TokenRefresh:TokenMaxAgeHours",
            defaultValue: 24);
        _tokenMaxAge = TimeSpan.FromHours(tokenMaxAgeHours);
        
        var cleanupIntervalHours = configuration.GetValue<int>(
            "TokenRefresh:CleanupIntervalHours",
            defaultValue: 1);
        _cleanupInterval = TimeSpan.FromHours(cleanupIntervalHours);
        
        // Проверяем конфигурацию при инициализации
        ValidateConfiguration();
        
        // Запускаем периодическую очистку старых токенов
        StartCleanupTimer();
    }
    
    /// <summary>
    /// Запускает таймер для периодической очистки старых токенов
    /// </summary>
    private void StartCleanupTimer()
    {
        if (_cleanupInterval <= TimeSpan.Zero)
        {
            _logger.LogDebug("Периодическая очистка токенов отключена");
            return;
        }
        
        _cleanupTimer = new Timer(CleanupExpiredTokens, null, _cleanupInterval, _cleanupInterval);
        _logger.LogDebug(
            "Запущена периодическая очистка токенов. Интервал: {CleanupInterval}, Максимальный возраст токена: {TokenMaxAge}",
            _cleanupInterval, _tokenMaxAge);
    }
    
    /// <summary>
    /// Очищает старые токены, которые не использовались длительное время
    /// </summary>
    private void CleanupExpiredTokens(object? state)
    {
        if (_disposed)
        {
            return;
        }
        
        try
        {
            var now = DateTimeOffset.UtcNow;
            var cutoffTime = now - _tokenMaxAge;
            var removedCount = 0;
            var removedCircuitIds = new List<string>();
            
            foreach (var kvp in _circuitTokens.ToArray())
            {
                if (kvp.Value.StoredAt < cutoffTime)
                {
                    if (_circuitTokens.TryRemove(kvp.Key, out _))
                    {
                        removedCircuitIds.Add(kvp.Key);
                        removedCount++;
                    }
                }
            }
            
            // Очищаем семафоры для удалённых circuits
            foreach (var circuitId in removedCircuitIds)
            {
                if (_refreshSemaphores.TryRemove(circuitId, out var semaphore))
                {
                    try
                    {
                        semaphore.Dispose();
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Ошибка при освобождении семафора для Circuit {CircuitId} при очистке", circuitId);
                    }
                }
            }
            
            if (removedCount > 0)
            {
                _logger.LogInformation(
                    "Очищено {RemovedCount} старых токенов (старше {TokenMaxAge})",
                    removedCount, _tokenMaxAge);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при периодической очистке токенов");
        }
    }
    
    /// <summary>
    /// Проверяет корректность конфигурации Keycloak
    /// </summary>
    private void ValidateConfiguration()
    {
        var authority = _configuration["Authentication:Keycloak:Authority"];
        var clientId = _configuration["Authentication:Keycloak:ClientId"];
        
        if (string.IsNullOrEmpty(authority))
        {
            throw new InvalidOperationException(
                "Не указан Authentication:Keycloak:Authority в конфигурации");
        }
        
        if (string.IsNullOrEmpty(clientId))
        {
            throw new InvalidOperationException(
                "Не указан Authentication:Keycloak:ClientId в конфигурации");
        }
        
        if (!Uri.TryCreate(authority, UriKind.Absolute, out _))
        {
            throw new InvalidOperationException(
                $"Некорректный формат Authority: {authority}");
        }
        
        if (_tokenExpirationBufferSeconds < 0)
        {
            throw new InvalidOperationException(
                $"TokenRefresh:ExpirationBufferSeconds не может быть отрицательным. Текущее значение: {_tokenExpirationBufferSeconds}");
        }
        
        if (_maxRetries < 1)
        {
            throw new InvalidOperationException(
                $"TokenRefresh:MaxRetries должен быть >= 1. Текущее значение: {_maxRetries}");
        }
        
        if (_initialRetryDelay <= TimeSpan.Zero)
        {
            throw new InvalidOperationException(
                $"TokenRefresh:InitialRetryDelaySeconds должен быть > 0. Текущее значение: {_initialRetryDelay.TotalSeconds}");
        }
        
        if (_expirationCheckCacheDuration <= TimeSpan.Zero)
        {
            throw new InvalidOperationException(
                $"TokenRefresh:ExpirationCheckCacheDurationSeconds должен быть > 0. Текущее значение: {_expirationCheckCacheDuration.TotalSeconds}");
        }
        
        _logger.LogDebug(
            "CircuitTokenService инициализирован с параметрами: Authority={Authority}, ClientId={ClientId}, " +
            "ExpirationBufferSeconds={ExpirationBufferSeconds}, MaxRetries={MaxRetries}, " +
            "InitialRetryDelay={InitialRetryDelay}, ExpirationCheckCacheDuration={ExpirationCheckCacheDuration}",
            authority, clientId, _tokenExpirationBufferSeconds, _maxRetries, _initialRetryDelay, _expirationCheckCacheDuration);
    }

    public override Task OnCircuitOpenedAsync(Circuit circuit, CancellationToken cancellationToken)
    {
        _currentCircuitId.Value = circuit.Id;
        return base.OnCircuitOpenedAsync(circuit, cancellationToken);
    }

    public override Task OnCircuitClosedAsync(Circuit circuit, CancellationToken cancellationToken)
    {
        _circuitTokens.TryRemove(circuit.Id, out _);
        
        // Очищаем семафор для этого circuit
        if (_refreshSemaphores.TryRemove(circuit.Id, out var semaphore))
        {
            try
            {
                semaphore.Dispose();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при освобождении семафора для Circuit {CircuitId}", circuit.Id);
            }
        }
        
        return base.OnCircuitClosedAsync(circuit, cancellationToken);
    }

    public override Task OnConnectionUpAsync(Circuit circuit, CancellationToken cancellationToken)
    {
        _currentCircuitId.Value = circuit.Id;
        return base.OnConnectionUpAsync(circuit, cancellationToken);
    }

    public override Task OnConnectionDownAsync(Circuit circuit, CancellationToken cancellationToken)
    {
        // При разрыве соединения не очищаем _currentCircuitId - он останется для повторного подключения
        return base.OnConnectionDownAsync(circuit, cancellationToken);
    }

    /// <summary>
    /// Сохранить токены для текущего circuit
    /// </summary>
    public void StoreTokens(string accessToken, string? refreshToken)
    {
        if (_disposed)
        {
            throw new ObjectDisposedException(nameof(CircuitTokenService));
        }
        
        // Валидация access token
        if (string.IsNullOrWhiteSpace(accessToken))
        {
            _logger.LogError("Попытка сохранить пустой access token");
            throw new ArgumentException("Access token не может быть пустым", nameof(accessToken));
        }

        if (!IsValidJwtToken(accessToken))
        {
            _logger.LogError("Попытка сохранить некорректный JWT токен");
            throw new ArgumentException("Access token имеет некорректный формат", nameof(accessToken));
        }

        var circuitId = _currentCircuitId.Value;
        if (string.IsNullOrEmpty(circuitId))
        {
            _logger.LogWarning("Нет активного Circuit ID для сохранения токенов");
            return;
        }

        var tokenInfo = new TokenInfo(_dataProtector)
        {
            AccessToken = accessToken,
            RefreshToken = refreshToken,
            StoredAt = DateTimeOffset.UtcNow
        };

        _circuitTokens[circuitId] = tokenInfo;
    }

    /// <summary>
    /// Получить актуальный access token (обновит если истёк)
    /// </summary>
    public async Task<string?> GetValidAccessTokenAsync(CancellationToken cancellationToken = default)
    {
        if (_disposed)
        {
            throw new ObjectDisposedException(nameof(CircuitTokenService));
        }
        
        var circuitId = _currentCircuitId.Value;
        if (string.IsNullOrEmpty(circuitId))
        {
            _logger.LogWarning("Нет активного Circuit ID");
            return null;
        }

        if (!_circuitTokens.TryGetValue(circuitId, out var tokenInfo))
        {
            _logger.LogWarning("Токены не найдены для Circuit {CircuitId}", circuitId);
            return null;
        }

        // Проверяем срок действия с учётом кэширования
        if (IsTokenExpired(tokenInfo.AccessToken, tokenInfo))
        {
            // Проверяем, есть ли refresh token
            if (string.IsNullOrEmpty(tokenInfo.RefreshToken))
            {
                _logger.LogWarning(
                    "Access token истёк, но refresh token отсутствует для Circuit {CircuitId}. " +
                    "Очищаем токены, так как восстановление невозможно.", 
                    circuitId);
                _circuitTokens.TryRemove(circuitId, out _);
                return null;
            }
            
            // Проверяем, не истёк ли refresh token
            // Примечание: refresh token может быть непрозрачным (не JWT), 
            // поэтому проверяем только если это JWT токен
            if (IsRefreshTokenExpired(tokenInfo.RefreshToken))
            {
                _logger.LogWarning(
                    "Refresh token также истёк для Circuit {CircuitId}. Очищаем токены.", 
                    circuitId);
                _circuitTokens.TryRemove(circuitId, out _);
                return null;
            }
            
            var refreshed = await RefreshTokenAsync(tokenInfo, circuitId, cancellationToken);
            if (!refreshed)
            {
                _logger.LogError("Не удалось обновить токен для Circuit {CircuitId}", circuitId);
                // Не очищаем токены сразу - может быть временная ошибка сети
                return null;
            }

            // Получаем обновлённый токен
            if (!_circuitTokens.TryGetValue(circuitId, out tokenInfo))
            {
                return null;
            }
        }

        return tokenInfo.AccessToken;
    }

    private bool IsTokenExpired(string token, TokenInfo tokenInfo)
    {
        var now = DateTimeOffset.UtcNow;
        
        // Проверяем кэш только если последняя проверка была недавно
        if (tokenInfo.LastExpirationCheck.HasValue &&
            now - tokenInfo.LastExpirationCheck.Value < _expirationCheckCacheDuration &&
            tokenInfo.LastExpirationResult.HasValue)
        {
            // Важно: даже если кэш говорит, что токен валиден, проверяем,
            // не приближается ли срок истечения. Если кэш скоро устареет и токен близок к истечению,
            // лучше перепроверить сейчас
            if (!tokenInfo.LastExpirationResult.Value)
            {
                // Токен валиден по кэшу, но проверяем, не истекает ли он в ближайшее время
                try
                {
                    var jwtToken = _tokenHandler.ReadJwtToken(token);
                    var expirationTime = jwtToken.ValidTo.AddSeconds(-_tokenExpirationBufferSeconds);
                    var timeUntilExpiration = expirationTime - DateTime.UtcNow;
                    
                    // Если токен истекает в течение времени кэширования, перепроверяем сейчас
                    if (timeUntilExpiration <= _expirationCheckCacheDuration)
                    {
                        // Инвалидируем кэш и проверяем заново
                        tokenInfo.LastExpirationCheck = null;
                        tokenInfo.LastExpirationResult = null;
                    }
                    else
                    {
                        // Используем кэшированный результат
                        return false;
                    }
                }
                catch
                {
                    // В случае ошибки продолжаем с обычной проверкой
                }
            }
            else
            {
                // Используем кэшированный результат (токен истёк)
                return true;
            }
        }
        
        try
        {
            var jwtToken = _tokenHandler.ReadJwtToken(token);
            
            // Добавляем запас времени (настраивается через конфигурацию)
            var expirationTime = jwtToken.ValidTo.AddSeconds(-_tokenExpirationBufferSeconds);
            var isExpired = expirationTime <= DateTime.UtcNow;
            
            // Сохраняем результат в кэш
            tokenInfo.LastExpirationCheck = now;
            tokenInfo.LastExpirationResult = isExpired;
            
            return isExpired;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при проверке срока действия токена");
            // В случае ошибки считаем токен истёкшим
            tokenInfo.LastExpirationCheck = now;
            tokenInfo.LastExpirationResult = true;
            return true;
        }
    }

    /// <summary>
    /// Проверяет, не истёк ли refresh token (если он является JWT)
    /// </summary>
    private bool IsRefreshTokenExpired(string? refreshToken)
    {
        if (string.IsNullOrEmpty(refreshToken))
        {
            return true;
        }
        
        try
        {
            // Проверяем, является ли токен JWT (три части, разделённые точками)
            var parts = refreshToken.Split('.');
            if (parts.Length != 3)
            {
                // Не JWT токен (непрозрачный) - считаем, что он не истёк
                // Срок действия будет проверен сервером при обновлении
                return false;
            }
            
            // Проверяем срок действия JWT refresh token
            var jwtToken = _tokenHandler.ReadJwtToken(refreshToken);
            if (jwtToken.ValidTo == default)
            {
                // Нет срока действия - считаем валидным
                return false;
            }
            
            var expirationTime = jwtToken.ValidTo.AddSeconds(-_tokenExpirationBufferSeconds);
            return expirationTime <= DateTime.UtcNow;
        }
        catch
        {
            // Если не удалось прочитать как JWT, считаем, что токен валиден
            // (может быть непрозрачный токен)
            return false;
        }
    }

    /// <summary>
    /// Проверяет, является ли строка валидным JWT токеном
    /// </summary>
    private bool IsValidJwtToken(string token)
    {
        try
        {
            // Проверяем базовую структуру JWT (три части, разделённые точками)
            var parts = token.Split('.');
            if (parts.Length != 3)
            {
                return false;
            }

            // Проверяем, что можем прочитать токен
            var jwtToken = _tokenHandler.ReadJwtToken(token);
            
            // Проверяем наличие обязательных полей
            if (jwtToken.ValidTo == default)
            {
                return false;
            }

            return true;
        }
        catch
        {
            return false;
        }
    }

    private async Task<bool> RefreshTokenAsync(TokenInfo tokenInfo, string circuitId, CancellationToken cancellationToken)
    {
        if (string.IsNullOrEmpty(tokenInfo.RefreshToken))
        {
            _logger.LogWarning("Refresh token отсутствует");
            return false;
        }

        // Создаём семафор для конкретного circuit для предотвращения одновременных обновлений
        var semaphore = _refreshSemaphores.GetOrAdd(circuitId, _ => new SemaphoreSlim(1, 1));
        
        await semaphore.WaitAsync(cancellationToken);
        try
        {
            // Проверяем, не обновил ли токен другой поток пока мы ждали
            if (_circuitTokens.TryGetValue(circuitId, out var currentTokenInfo) &&
                !IsTokenExpired(currentTokenInfo.AccessToken, currentTokenInfo))
            {
                return true; // Токен уже обновлён другим потоком
            }

            // Выполняем обновление с retry логикой
            return await RefreshTokenInternalAsync(tokenInfo, circuitId, cancellationToken);
        }
        finally
        {
            semaphore.Release();
            // Не удаляем семафор здесь - он будет очищен в OnCircuitClosedAsync
            // Автоматическое удаление может привести к race condition
        }
    }

    private async Task<bool> RefreshTokenInternalAsync(TokenInfo tokenInfo, string circuitId, CancellationToken cancellationToken)
    {
        Interlocked.Increment(ref _tokenRefreshCount);
        
        var delay = _initialRetryDelay;
        var originalRefreshToken = tokenInfo.RefreshToken; // Сохраняем оригинальный refresh token
        
        for (int attempt = 1; attempt <= _maxRetries; attempt++)
        {
            try
            {
                // Конфигурация уже проверена при инициализации, но для безопасности
                // можно добавить проверку (хотя это не должно произойти)
                var authority = _configuration["Authentication:Keycloak:Authority"];
                var clientId = _configuration["Authentication:Keycloak:ClientId"];
                var clientSecret = _configuration["Authentication:Keycloak:ClientSecret"];

                if (string.IsNullOrEmpty(authority) || string.IsNullOrEmpty(clientId))
                {
                    _logger.LogError("Отсутствуют параметры Keycloak в конфигурации (это не должно происходить после валидации)");
                    Interlocked.Increment(ref _tokenRefreshFailures);
                    return false;
                }

                var tokenEndpoint = $"{authority}/protocol/openid-connect/token";
                var httpClient = _httpClientFactory.CreateClient();
                
                if (httpClient == null)
                {
                    _logger.LogError("HttpClientFactory.CreateClient() вернул null");
                    Interlocked.Increment(ref _tokenRefreshFailures);
                    return false;
                }
                
                // Устанавливаем таймаут для HTTP запроса
                httpClient.Timeout = HttpClientTimeout;

                // Используем текущий refresh token (может быть обновлён предыдущей попыткой)
                var requestContent = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("grant_type", "refresh_token"),
                    new KeyValuePair<string, string>("refresh_token", tokenInfo.RefreshToken ?? originalRefreshToken ?? string.Empty),
                    new KeyValuePair<string, string>("client_id", clientId),
                    new KeyValuePair<string, string>("client_secret", clientSecret ?? string.Empty)
                });

                _logger.LogDebug("Отправка запроса на обновление токена к {TokenEndpoint}, попытка {Attempt}/{MaxRetries}", 
                    tokenEndpoint, attempt, _maxRetries);
                
                // Создаём комбинированный CancellationToken
                using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                cts.CancelAfter(HttpClientTimeout);
                
                var response = await httpClient.PostAsync(tokenEndpoint, requestContent, cts.Token);
                
                if (response.IsSuccessStatusCode)
                {
                    var tokenResponse = await response.Content.ReadFromJsonAsync<TokenResponse>(cancellationToken: cts.Token);
                    if (tokenResponse == null || string.IsNullOrEmpty(tokenResponse.AccessToken))
                    {
                        _logger.LogError("Некорректный ответ от сервера токенов");
                        return false;
                    }

                    // Обработка refresh token rotation
                    var newRefreshToken = tokenResponse.RefreshToken;
                    if (string.IsNullOrEmpty(newRefreshToken))
                    {
                        // Если сервер не вернул новый refresh token, используем старый
                        newRefreshToken = tokenInfo.RefreshToken ?? originalRefreshToken;
                        _logger.LogWarning(
                            "Сервер не вернул новый refresh token для Circuit {CircuitId} (попытка {Attempt}). " +
                            "Используется существующий. Это может быть проблемой, если сервер инвалидирует старые токены.",
                            circuitId, attempt);
                    }
                    else
                    {
                        // Обновляем refresh token для следующих попыток (если будут)
                        tokenInfo.RefreshToken = newRefreshToken;
                        _logger.LogDebug("Получен новый refresh token для Circuit {CircuitId}", circuitId);
                    }

                    // Сохраняем новые токены
                    StoreTokens(tokenResponse.AccessToken, newRefreshToken);
                    
                    Interlocked.Increment(ref _tokenRefreshSuccesses);
                    return true;
                }
                
                // Обрабатываем HTTP ошибки
                var errorContent = await response.Content.ReadAsStringAsync();
                var sanitizedError = SanitizeErrorContent(errorContent);
                
                // Для некоторых ошибок не имеет смысла повторять
                if (response.StatusCode == HttpStatusCode.Unauthorized || 
                    response.StatusCode == HttpStatusCode.BadRequest ||
                    response.StatusCode == HttpStatusCode.Forbidden)
                {
                    _logger.LogError("Ошибка обновления токена (неповторяемая): {StatusCode}, {Error}", 
                        response.StatusCode, sanitizedError);
                    Interlocked.Increment(ref _tokenRefreshFailures);
                    return false;
                }
                
                // Для других ошибок пытаемся повторить
                if (attempt < _maxRetries)
                {
                    _logger.LogWarning("Ошибка обновления токена: {StatusCode}, {Error}. Попытка {Attempt}/{MaxRetries}", 
                        response.StatusCode, sanitizedError, attempt, _maxRetries);
                    await Task.Delay(delay, cancellationToken);
                    delay = TimeSpan.FromMilliseconds(delay.TotalMilliseconds * 2); // Exponential backoff
                    continue;
                }
                
                _logger.LogError("Ошибка обновления токена после {MaxRetries} попыток: {StatusCode}, {Error}", 
                    _maxRetries, response.StatusCode, sanitizedError);
                Interlocked.Increment(ref _tokenRefreshFailures);
                return false;
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                _logger.LogWarning("Обновление токена отменено для Circuit {CircuitId}", circuitId);
                Interlocked.Increment(ref _tokenRefreshFailures);
                return false;
            }
            catch (TaskCanceledException ex) when (attempt < _maxRetries)
            {
                _logger.LogWarning(ex, "Таймаут при обновлении токена, попытка {Attempt}/{MaxRetries} для Circuit {CircuitId}", 
                    attempt, _maxRetries, circuitId);
                await Task.Delay(delay, cancellationToken);
                delay = TimeSpan.FromMilliseconds(delay.TotalMilliseconds * 2);
                continue;
            }
            catch (HttpRequestException ex) when (attempt < _maxRetries)
            {
                _logger.LogWarning(ex, "Ошибка сети при обновлении токена, попытка {Attempt}/{MaxRetries} для Circuit {CircuitId}", 
                    attempt, _maxRetries, circuitId);
                await Task.Delay(delay, cancellationToken);
                delay = TimeSpan.FromMilliseconds(delay.TotalMilliseconds * 2);
                continue;
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogError(ex, "Таймаут при обновлении токена после {MaxRetries} попыток для Circuit {CircuitId}", 
                    _maxRetries, circuitId);
                Interlocked.Increment(ref _tokenRefreshFailures);
                return false;
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "Ошибка сети при обновлении токена после {MaxRetries} попыток для Circuit {CircuitId}", 
                    _maxRetries, circuitId);
                Interlocked.Increment(ref _tokenRefreshFailures);
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Неожиданная ошибка при обновлении токена для Circuit {CircuitId}", circuitId);
                Interlocked.Increment(ref _tokenRefreshFailures);
                return false;
            }
        }
        
        Interlocked.Increment(ref _tokenRefreshFailures);
        return false;
    }

    /// <summary>
    /// Удаляет чувствительные данные из сообщения об ошибке перед логированием
    /// </summary>
    private string SanitizeErrorContent(string errorContent)
    {
        if (string.IsNullOrEmpty(errorContent))
        {
            return errorContent;
        }

        // Удаляем токены из JSON ответа
        var sanitized = Regex.Replace(errorContent, @"""refresh_token""\s*:\s*""[^""]+""", 
            "\"refresh_token\":\"***\"", RegexOptions.IgnoreCase);
        sanitized = Regex.Replace(sanitized, @"""access_token""\s*:\s*""[^""]+""", 
            "\"access_token\":\"***\"", RegexOptions.IgnoreCase);
        sanitized = Regex.Replace(sanitized, @"""client_secret""\s*:\s*""[^""]+""", 
            "\"client_secret\":\"***\"", RegexOptions.IgnoreCase);
        
        return sanitized;
    }

    /// <summary>
    /// Получить метрики работы сервиса
    /// </summary>
    public (long Total, long Successes, long Failures) GetMetrics()
    {
        return (
            Interlocked.Read(ref _tokenRefreshCount),
            Interlocked.Read(ref _tokenRefreshSuccesses),
            Interlocked.Read(ref _tokenRefreshFailures)
        );
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }
        
        // Останавливаем таймер очистки
        _cleanupTimer?.Dispose();
        _cleanupTimer = null;
        
        // Очищаем семафоры
        foreach (var semaphore in _refreshSemaphores.Values)
        {
            try
            {
                semaphore.Dispose();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при освобождении семафора");
            }
        }
        _refreshSemaphores.Clear();
        
        // Очищаем токены (зашифрованные данные)
        foreach (var tokenInfo in _circuitTokens.Values)
        {
            try
            {
                // Очистка чувствительных данных
                tokenInfo.AccessToken = string.Empty;
                tokenInfo.RefreshToken = null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при очистке токенов");
            }
        }
        _circuitTokens.Clear();
        
        _disposed = true;
    }
    
    public async ValueTask DisposeAsync()
    {
        if (_disposed)
        {
            return;
        }
        
        // Останавливаем таймер очистки
        _cleanupTimer?.Dispose();
        _cleanupTimer = null;
        
        // Очищаем семафоры асинхронно
        var semaphoreTasks = _refreshSemaphores.Values
            .Select(semaphore => Task.Run(() =>
            {
                try
                {
                    semaphore.Dispose();
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Ошибка при асинхронном освобождении семафора");
                }
            }));
        await Task.WhenAll(semaphoreTasks);
        _refreshSemaphores.Clear();
        
        // Очищаем токены (зашифрованные данные)
        foreach (var tokenInfo in _circuitTokens.Values)
        {
            try
            {
                // Очистка чувствительных данных
                tokenInfo.AccessToken = string.Empty;
                tokenInfo.RefreshToken = null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при очистке токенов");
            }
        }
        _circuitTokens.Clear();
        
        _disposed = true;
    }

    private class TokenInfo
    {
        private readonly IDataProtector _dataProtector;
        private string _encryptedAccessToken = string.Empty;
        private string? _encryptedRefreshToken;
        
        public TokenInfo(IDataProtector dataProtector)
        {
            _dataProtector = dataProtector ?? throw new ArgumentNullException(nameof(dataProtector));
        }
        
        public string AccessToken
        {
            get
            {
                if (string.IsNullOrEmpty(_encryptedAccessToken))
                {
                    return string.Empty;
                }
                
                try
                {
                    return _dataProtector.Unprotect(_encryptedAccessToken);
                }
                catch (Exception)
                {
                    // Если не удалось расшифровать (например, ключ защиты изменился),
                    // возвращаем пустую строку
                    return string.Empty;
                }
            }
            set => _encryptedAccessToken = string.IsNullOrEmpty(value) ? string.Empty : _dataProtector.Protect(value);
        }
        
        public string? RefreshToken
        {
            get
            {
                if (string.IsNullOrEmpty(_encryptedRefreshToken))
                {
                    return null;
                }
                
                try
                {
                    return _dataProtector.Unprotect(_encryptedRefreshToken);
                }
                catch (Exception)
                {
                    // Если не удалось расшифровать (например, ключ защиты изменился),
                    // возвращаем null
                    return null;
                }
            }
            set => _encryptedRefreshToken = string.IsNullOrEmpty(value) ? null : _dataProtector.Protect(value);
        }
        
        public DateTimeOffset StoredAt { get; set; }
        
        // Кэширование результата проверки истечения токена
        public DateTimeOffset? LastExpirationCheck { get; set; }
        public bool? LastExpirationResult { get; set; }
    }

    private class TokenResponse
    {
        [System.Text.Json.Serialization.JsonPropertyName("access_token")]
        public string AccessToken { get; set; } = string.Empty;
        
        [System.Text.Json.Serialization.JsonPropertyName("refresh_token")]
        public string? RefreshToken { get; set; }
        
        [System.Text.Json.Serialization.JsonPropertyName("expires_in")]
        public int ExpiresIn { get; set; }
    }
}

