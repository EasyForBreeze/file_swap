using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Фоновый сервис для автоматического сброса статистики производительности
/// </summary>
public class PerformanceStatsResetService : BackgroundService
{
    private readonly ILogger<PerformanceStatsResetService> _logger;
    private readonly IPerformanceMetricsService _metricsService;
    private readonly ISqlitePerformanceMonitor _sqliteMonitor;
    private readonly PerformanceStatsResetSettings _settings;
    private readonly TimeSpan _resetInterval;
    
    private int _consecutiveErrors = 0;
    private long _successfulResets = 0;
    private long _failedResets = 0;
    
    private const int MaxConsecutiveErrors = 5;
    private static readonly TimeSpan BaseErrorDelay = TimeSpan.FromSeconds(30);
    private static readonly TimeSpan MaxErrorDelay = TimeSpan.FromMinutes(5);
    private const int MaxErrorMessagesInLog = 5;

    public PerformanceStatsResetService(
        ILogger<PerformanceStatsResetService> logger,
        IPerformanceMetricsService metricsService,
        ISqlitePerformanceMonitor sqliteMonitor,
        IOptions<PerformanceStatsResetSettings> settings)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _metricsService = metricsService ?? throw new ArgumentNullException(nameof(metricsService));
        _sqliteMonitor = sqliteMonitor ?? throw new ArgumentNullException(nameof(sqliteMonitor));
        
        var settingsValue = settings?.Value ?? throw new ArgumentNullException(nameof(settings));
        _settings = settingsValue;
        
        // Валидация интервала
        var interval = _settings.ResetInterval;
        if (interval <= TimeSpan.Zero)
            throw new ArgumentException("Reset interval must be positive", nameof(settings));
        if (interval > TimeSpan.FromHours(24))
            throw new ArgumentException("Reset interval cannot exceed 24 hours", nameof(settings));
        
        _resetInterval = interval;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // Примечание: Изменение настройки Enabled требует перезапуска приложения для вступления в силу
        if (!_settings.Enabled)
        {
            _logger.LogInformation("Сервис сброса статистики производительности отключен в конфигурации");
            return;
        }
        
        _logger.LogInformation(
            "Фоновый сервис сброса статистики производительности запущен. Интервал: {Interval}",
            _resetInterval);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await Task.Delay(_resetInterval, stoppingToken);
                
                if (!stoppingToken.IsCancellationRequested)
                {
                    await ResetPerformanceStatsAsync();
                    Interlocked.Exchange(ref _consecutiveErrors, 0); // Сброс счетчика при успехе
                }
            }
            catch (TaskCanceledException)
            {
                _logger.LogInformation("Фоновый сервис сброса статистики производительности остановлен по запросу.");
                break;
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("Фоновый сервис сброса статистики производительности отменен.");
                break;
            }
            catch (Exception ex)
            {
                var errorCount = Interlocked.Increment(ref _consecutiveErrors);
                _logger.LogError(ex, 
                    "Ошибка при сбросе статистики производительности. Последовательных ошибок: {ErrorCount}", 
                    errorCount);
                
                // Экспоненциальная задержка при ошибках
                if (errorCount <= MaxConsecutiveErrors)
                {
                    // Используем битовый сдвиг вместо Math.Pow для степеней двойки (оптимизация производительности)
                    var power = errorCount > 1 ? (1L << (errorCount - 1)) : 1;
                    var delaySeconds = Math.Min(
                        BaseErrorDelay.TotalSeconds * power, 
                        MaxErrorDelay.TotalSeconds);
                    var delay = TimeSpan.FromSeconds(delaySeconds);
                    
                    _logger.LogWarning(
                        "Ожидание {Delay} секунд перед следующей попыткой из-за ошибок",
                        delay.TotalSeconds);
                    
                    try
                    {
                        await Task.Delay(delay, stoppingToken);
                    }
                    catch (TaskCanceledException)
                    {
                        break;
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }
                }
                else
                {
                    _logger.LogCritical(
                        "Достигнуто максимальное количество последовательных ошибок ({MaxErrors}). " +
                        "Сервис продолжит работу с обычным интервалом.",
                        MaxConsecutiveErrors);
                    Interlocked.Exchange(ref _consecutiveErrors, 0); // Сброс для следующего цикла
                }
            }
        }

        var successful = Interlocked.Read(ref _successfulResets);
        var failed = Interlocked.Read(ref _failedResets);
        
        _logger.LogInformation(
            "Фоновый сервис сброса статистики производительности завершил работу. " +
            "Итоговая статистика: Успешно: {Success}, Ошибок: {Failed}",
            successful, failed);
    }

    private Task ResetPerformanceStatsAsync()
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            var resetResults = new List<(string Service, bool Success, string? Error)>();
            
            // Сброс IPerformanceMetricsService
            try
            {
                _metricsService.Reset();
                resetResults.Add(("IPerformanceMetricsService", true, null));
                _logger.LogDebug("IPerformanceMetricsService statistics reset successfully");
            }
            catch (Exception ex)
            {
                resetResults.Add(("IPerformanceMetricsService", false, ex.Message));
                _logger.LogError(ex, "Failed to reset IPerformanceMetricsService statistics");
            }
            
            // Сброс SqlitePerformanceMonitor
            try
            {
                _sqliteMonitor.ResetAllStats();
                resetResults.Add(("SqlitePerformanceMonitor", true, null));
                _logger.LogDebug("SqlitePerformanceMonitor statistics reset successfully");
            }
            catch (Exception ex)
            {
                resetResults.Add(("SqlitePerformanceMonitor", false, ex.Message));
                _logger.LogError(ex, "Failed to reset SqlitePerformanceMonitor statistics");
            }
            
            // Логирование результата
            var successCount = resetResults.Count(r => r.Success);
            var totalCount = resetResults.Count;
            
            if (successCount == totalCount)
            {
                Interlocked.Increment(ref _successfulResets);
                _logger.LogInformation(
                    "Performance statistics reset completed successfully at {ResetTime:yyyy-MM-dd HH:mm:ss} UTC. " +
                    "All {Count} services reset.",
                    DateTime.UtcNow, totalCount);
            }
            else
            {
                Interlocked.Increment(ref _failedResets);
                
                // Ограничиваем количество ошибок в логе для предотвращения переполнения
                var errorMessages = resetResults
                    .Where(r => !r.Success)
                    .Select(r => $"{r.Service}: {r.Error}")
                    .Take(MaxErrorMessagesInLog)
                    .ToList();
                
                var totalErrors = resetResults.Count(r => !r.Success);
                if (totalErrors > MaxErrorMessagesInLog)
                {
                    errorMessages.Add($"... и еще {totalErrors - MaxErrorMessagesInLog} ошибок");
                }
                
                var errors = string.Join("; ", errorMessages);
                
                _logger.LogWarning(
                    "Performance statistics reset completed with errors at {ResetTime:yyyy-MM-dd HH:mm:ss} UTC. " +
                    "Success: {SuccessCount}/{TotalCount}. Errors: {Errors}",
                    DateTime.UtcNow, successCount, totalCount, errors);
            }
            
            // Периодическое логирование статистики (каждые 10 сбросов)
            var successful = Interlocked.Read(ref _successfulResets);
            var failed = Interlocked.Read(ref _failedResets);
            var totalOperations = successful + failed;
            
            if (totalOperations > 0 && totalOperations % 10 == 0)
            {
                _logger.LogInformation(
                    "Статистика работы сервиса сброса: Успешно: {Success}, Ошибок: {Failed}",
                    successful, failed);
            }
        }
        finally
        {
            stopwatch.Stop();
            _logger.LogDebug("Операция сброса статистики заняла {ElapsedMs} мс", stopwatch.ElapsedMilliseconds);
        }
        
        return Task.CompletedTask;
    }
}
