using System.Data;
using Microsoft.Data.Sqlite;
using new_assistant.Configuration;
using new_assistant.Core.Entities;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Репозиторий для управления связями клиентов и Wiki страниц в SQLite
/// </summary>
public class WikiPageRepository : IWikiPageRepository
{
    private readonly string _connectionString;
    private readonly ILogger<WikiPageRepository> _logger;
    private readonly Lazy<Task> _initializeTask;
    private const string DatabaseName = "wiki_pages";

    public WikiPageRepository(DataPathsSettings dataPathsSettings, ILogger<WikiPageRepository> logger)
    {
        var dbPath = dataPathsSettings.GetWikiPagesDbPath();
        _connectionString = $"Data Source={dbPath};Mode=ReadWriteCreate;Cache=Shared;Pooling=True";
        _logger = logger;
        
        // Lazy initialization - БД инициализируется только при первом использовании
        _initializeTask = new Lazy<Task>(() => InitializeDatabaseAsync());
    }

    /// <summary>
    /// Асинхронная инициализация базы данных (вызывается автоматически при первом использовании)
    /// </summary>
    private async Task InitializeDatabaseAsync()
    {
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);

            await using var command = connection.CreateCommand();
            command.CommandText = @"
                CREATE TABLE IF NOT EXISTS client_wiki_pages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    client_id TEXT NOT NULL,
                    realm TEXT NOT NULL DEFAULT 'GLOBAL',
                    wiki_page_id TEXT NOT NULL,
                    wiki_page_title TEXT NOT NULL,
                    wiki_page_url TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'Active',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    created_by TEXT NOT NULL,
                    page_version INTEGER NOT NULL DEFAULT 1,
                    UNIQUE(client_id, realm)
                );

                CREATE INDEX IF NOT EXISTS idx_wiki_client_realm ON client_wiki_pages(client_id, realm);
                CREATE INDEX IF NOT EXISTS idx_wiki_page_id ON client_wiki_pages(wiki_page_id);
                CREATE INDEX IF NOT EXISTS idx_wiki_status ON client_wiki_pages(status);
                CREATE INDEX IF NOT EXISTS idx_wiki_updated_at ON client_wiki_pages(updated_at DESC);
            ";
            await command.ExecuteNonQueryAsync().ConfigureAwait(false);
            
            _logger.LogDebug("База данных wiki_pages успешно инициализирована");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка инициализации базы данных wiki_pages");
            throw;
        }
    }

    /// <summary>
    /// Гарантирует, что БД инициализирована перед выполнением операции
    /// </summary>
    private async Task EnsureInitializedAsync()
    {
        await _initializeTask.Value.ConfigureAwait(false);
    }

    /// <summary>
    /// Нормализует значение realm (пустое значение заменяется на "GLOBAL")
    /// </summary>
    private static string NormalizeRealm(string? realm) => 
        string.IsNullOrWhiteSpace(realm) ? "GLOBAL" : realm;

    /// <summary>
    /// Допустимые значения статуса Wiki страницы
    /// </summary>
    private static readonly HashSet<string> ValidStatuses = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
    {
        "Active",
        "Archived",
        "Failed"
    };

    /// <summary>
    /// Валидация объекта ClientWikiPage перед операциями с БД
    /// </summary>
    private void ValidateWikiPage(ClientWikiPage wikiPage)
    {
        ArgumentNullException.ThrowIfNull(wikiPage);
        
        if (string.IsNullOrWhiteSpace(wikiPage.ClientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(wikiPage));
        
        if (string.IsNullOrWhiteSpace(wikiPage.WikiPageId))
            throw new ArgumentException("WikiPageId cannot be null or empty", nameof(wikiPage));
        
        if (string.IsNullOrWhiteSpace(wikiPage.WikiPageTitle))
            throw new ArgumentException("WikiPageTitle cannot be null or empty", nameof(wikiPage));
        
        if (string.IsNullOrWhiteSpace(wikiPage.WikiPageUrl))
            throw new ArgumentException("WikiPageUrl cannot be null or empty", nameof(wikiPage));
        
        if (string.IsNullOrWhiteSpace(wikiPage.CreatedBy))
            throw new ArgumentException("CreatedBy cannot be null or empty", nameof(wikiPage));
        
        // Проверка длины строк согласно атрибутам Entity
        if (wikiPage.ClientId.Length > 255)
            throw new ArgumentException("ClientId exceeds maximum length of 255", nameof(wikiPage));
        
        if (wikiPage.Realm.Length > 255)
            throw new ArgumentException("Realm exceeds maximum length of 255", nameof(wikiPage));
        
        if (wikiPage.WikiPageId.Length > 50)
            throw new ArgumentException("WikiPageId exceeds maximum length of 50", nameof(wikiPage));
        
        if (wikiPage.WikiPageTitle.Length > 500)
            throw new ArgumentException("WikiPageTitle exceeds maximum length of 500", nameof(wikiPage));
        
        if (wikiPage.WikiPageUrl.Length > 1000)
            throw new ArgumentException("WikiPageUrl exceeds maximum length of 1000", nameof(wikiPage));
        
        if (wikiPage.CreatedBy.Length > 255)
            throw new ArgumentException("CreatedBy exceeds maximum length of 255", nameof(wikiPage));
        
        // Валидация статуса
        ValidateStatus(wikiPage.Status);
    }

    /// <summary>
    /// Валидация статуса Wiki страницы
    /// </summary>
    private void ValidateStatus(string status)
    {
        if (string.IsNullOrWhiteSpace(status))
            throw new ArgumentException("Status cannot be null or empty", nameof(status));
        
        if (status.Length > 50)
            throw new ArgumentException("Status exceeds maximum length of 50", nameof(status));
        
        if (!ValidStatuses.Contains(status))
        {
            throw new ArgumentException(
                $"Status '{status}' is not valid. Valid values are: {string.Join(", ", ValidStatuses)}", 
                nameof(status));
        }
    }

    /// <summary>
    /// Добавляет строковый параметр к команде SQLite
    /// </summary>
    private static void AddStringParameter(SqliteCommand command, string name, string? value)
    {
        var param = command.CreateParameter();
        param.ParameterName = name;
        param.Value = string.IsNullOrWhiteSpace(value) ? (object)DBNull.Value : value;
        param.DbType = DbType.String;
        command.Parameters.Add(param);
    }

    /// <summary>
    /// Добавляет целочисленный параметр к команде SQLite
    /// </summary>
    private static void AddIntParameter(SqliteCommand command, string name, int value)
    {
        var param = command.CreateParameter();
        param.ParameterName = name;
        param.Value = value;
        param.DbType = DbType.Int32;
        command.Parameters.Add(param);
    }

    /// <summary>
    /// Безопасное чтение DateTime из reader с обработкой ошибок
    /// </summary>
    private DateTime SafeParseDateTime(SqliteDataReader reader, int ordinal, string clientId, string fieldName)
    {
        if (reader.IsDBNull(ordinal))
        {
            _logger.LogWarning(
                "Null {FieldName} for client {ClientId}, using current UTC time as fallback", 
                fieldName, clientId);
            return DateTime.UtcNow;
        }

        var dateTimeStr = reader.GetString(ordinal);
        if (DateTime.TryParse(dateTimeStr, null, System.Globalization.DateTimeStyles.RoundtripKind, out var dateTime))
        {
            return dateTime;
        }

        _logger.LogWarning(
            "Invalid {FieldName} format for client {ClientId}: {Value}, using current UTC time as fallback", 
            fieldName, clientId, dateTimeStr);
        return DateTime.UtcNow;
    }

    /// <summary>
    /// Безопасное чтение строки из reader с обработкой null
    /// </summary>
    private static string SafeGetString(SqliteDataReader reader, int ordinal) => 
        reader.IsDBNull(ordinal) ? string.Empty : reader.GetString(ordinal);

    /// <summary>
    /// Безопасное чтение int из reader с обработкой null
    /// </summary>
    private static int SafeGetInt32(SqliteDataReader reader, int ordinal, int defaultValue = 0)
    {
        if (reader.IsDBNull(ordinal))
        {
            return defaultValue;
        }
        return reader.GetInt32(ordinal);
    }

    /// <summary>
    /// Создает объект ClientWikiPage из SqliteDataReader
    /// </summary>
    private ClientWikiPage MapReaderToWikiPage(SqliteDataReader reader)
    {
        var clientIdValue = SafeGetString(reader, 1);
        return new ClientWikiPage
        {
            Id = SafeGetInt32(reader, 0, 0),
            ClientId = clientIdValue,
            Realm = SafeGetString(reader, 2),
            WikiPageId = SafeGetString(reader, 3),
            WikiPageTitle = SafeGetString(reader, 4),
            WikiPageUrl = SafeGetString(reader, 5),
            Status = SafeGetString(reader, 6),
            CreatedAt = SafeParseDateTime(reader, 7, clientIdValue, "CreatedAt"),
            UpdatedAt = SafeParseDateTime(reader, 8, clientIdValue, "UpdatedAt"),
            CreatedBy = SafeGetString(reader, 9),
            PageVersion = SafeGetInt32(reader, 10, 1)
        };
    }

    /// <summary>
    /// Безопасное преобразование результата ExecuteScalarAsync в int с проверкой на переполнение
    /// </summary>
    private int SafeConvertToInt32(object? result, string context)
    {
        if (result == null || result == DBNull.Value)
        {
            _logger.LogError("{Context} returned null value", context);
            throw new InvalidOperationException($"{context} returned null value");
        }

        if (result is int intResult)
            return intResult;

        if (result is long longResult)
        {
            if (longResult > int.MaxValue || longResult < int.MinValue)
            {
                _logger.LogError("{Context} value overflow: {Value}", context, longResult);
                throw new OverflowException($"{context} value {longResult} exceeds int range");
            }
            return (int)longResult;
        }

        _logger.LogError("{Context} unexpected return type: {Type}", context, result.GetType());
        throw new InvalidOperationException($"{context} unexpected return type: {result.GetType()}");
    }

    public async Task<int> SaveWikiPageAsync(ClientWikiPage wikiPage)
    {
        // Пункт 2: Валидация входных параметров
        ValidateWikiPage(wikiPage);
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        
        try
        {
            // Пункт 8: Использование транзакции для атомарности операции
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            await using var transaction = (SqliteTransaction)await connection.BeginTransactionAsync();
            try
            {
                var command = connection.CreateCommand();
                command.Transaction = transaction;
                command.CommandText = @"
                    INSERT INTO client_wiki_pages 
                    (client_id, realm, wiki_page_id, wiki_page_title, wiki_page_url, status, created_at, updated_at, created_by, page_version)
                    VALUES 
                    (@clientId, @realm, @wikiPageId, @wikiPageTitle, @wikiPageUrl, @status, @createdAt, @updatedAt, @createdBy, @pageVersion)
                    RETURNING id";

                // Пункт 6: Типизированные параметры вместо AddWithValue
                AddStringParameter(command, "@clientId", wikiPage.ClientId);
                AddStringParameter(command, "@realm", NormalizeRealm(wikiPage.Realm));
                AddStringParameter(command, "@wikiPageId", wikiPage.WikiPageId);
                AddStringParameter(command, "@wikiPageTitle", wikiPage.WikiPageTitle);
                AddStringParameter(command, "@wikiPageUrl", wikiPage.WikiPageUrl);
                AddStringParameter(command, "@status", wikiPage.Status);
                AddStringParameter(command, "@createdAt", DateTime.UtcNow.ToString("O"));
                AddStringParameter(command, "@updatedAt", DateTime.UtcNow.ToString("O"));
                AddStringParameter(command, "@createdBy", wikiPage.CreatedBy);
                AddIntParameter(command, "@pageVersion", wikiPage.PageVersion);

                var result = await command.ExecuteScalarAsync();
                
                // Использование SafeConvertToInt32 вместо дублирования логики
                var id = SafeConvertToInt32(result, "SaveWikiPageAsync");

                await transaction.CommitAsync();
                return id;
            }
            catch
            {
                // Улучшенная обработка ошибок транзакции
                try
                {
                    await transaction.RollbackAsync();
                }
                catch (Exception rollbackEx)
                {
                    _logger.LogWarning(rollbackEx, "Error during transaction rollback in SaveWikiPageAsync");
                }
                throw;
            }
        }
        catch (SqliteException ex) when (ex.SqliteErrorCode == 19) // UNIQUE constraint
        {
            // Пункт 3: Обработка специфичных исключений SQLite
            _logger.LogWarning(ex, 
                "Attempted to insert duplicate wiki page for client {ClientId} in realm {Realm}", 
                wikiPage.ClientId, NormalizeRealm(wikiPage.Realm));
            throw new InvalidOperationException(
                $"Wiki page already exists for client {wikiPage.ClientId} in realm {NormalizeRealm(wikiPage.Realm)}", ex);
        }
        catch (SqliteException ex)
        {
            _logger.LogError(ex, 
                "SQLite error while saving wiki page for client {ClientId}: {ErrorCode}", 
                wikiPage.ClientId, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, 
                "Unexpected error while saving wiki page for client {ClientId}", 
                wikiPage.ClientId);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    public Task<ClientWikiPage?> GetWikiPageByClientAsync(string clientId, string realm)
    {
        // realm игнорируется — ссылка уникальна для клиента
        return GetWikiPageAnyRealmAsync(clientId);
    }

    public async Task<ClientWikiPage?> GetWikiPageAnyRealmAsync(string clientId)
    {
        // Пункт 2: Валидация входных параметров
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        // Пункт 1: Исправление stopwatch - использование try-finally
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);

            var command = connection.CreateCommand();
            command.CommandText = @"
                SELECT id, client_id, realm, wiki_page_id, wiki_page_title, wiki_page_url, 
                       status, created_at, updated_at, created_by, page_version
                FROM client_wiki_pages
                WHERE client_id = @clientId
                ORDER BY updated_at DESC
                LIMIT 1";

            AddStringParameter(command, "@clientId", clientId);

            await using var reader = await command.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                // Использование MapReaderToWikiPage для устранения дублирования
                return MapReaderToWikiPage(reader);
            }
            
            return null;
        }
        catch (SqliteException ex)
        {
            // Пункт 3: Обработка исключений
            _logger.LogError(ex, 
                "SQLite error while getting wiki page for client {ClientId}: {ErrorCode}", 
                clientId, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, 
                "Unexpected error while getting wiki page for client {ClientId}", 
                clientId);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    public async Task UpdateWikiPageAsync(ClientWikiPage wikiPage)
    {
        // Пункт 2: Валидация входных параметров
        ValidateWikiPage(wikiPage);
        
        if (wikiPage.Id <= 0)
            throw new ArgumentException("WikiPage Id must be greater than 0", nameof(wikiPage));
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);

            var command = connection.CreateCommand();
            command.CommandText = @"
                UPDATE client_wiki_pages
                SET realm = @realm,
                    wiki_page_id = @wikiPageId,
                    wiki_page_title = @wikiPageTitle,
                    wiki_page_url = @wikiPageUrl,
                    status = @status,
                    updated_at = @updatedAt,
                    page_version = @pageVersion
                WHERE id = @id";

            // Пункт 6: Типизированные параметры
            AddIntParameter(command, "@id", wikiPage.Id);
            AddStringParameter(command, "@realm", NormalizeRealm(wikiPage.Realm));
            AddStringParameter(command, "@wikiPageId", wikiPage.WikiPageId);
            AddStringParameter(command, "@wikiPageTitle", wikiPage.WikiPageTitle);
            AddStringParameter(command, "@wikiPageUrl", wikiPage.WikiPageUrl);
            AddStringParameter(command, "@status", wikiPage.Status);
            AddStringParameter(command, "@updatedAt", DateTime.UtcNow.ToString("O"));
            AddIntParameter(command, "@pageVersion", wikiPage.PageVersion);

            var rowsAffected = await command.ExecuteNonQueryAsync();
            
            // Пункт 5: Проверка существования записи перед обновлением
            if (rowsAffected == 0)
            {
                _logger.LogWarning(
                    "No wiki page found with id {Id} to update", 
                    wikiPage.Id);
                throw new InvalidOperationException(
                    $"Wiki page with id {wikiPage.Id} not found");
            }
        }
        catch (SqliteException ex)
        {
            // Пункт 3: Обработка исключений
            _logger.LogError(ex, 
                "SQLite error while updating wiki page with id {Id}: {ErrorCode}", 
                wikiPage.Id, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, 
                "Unexpected error while updating wiki page with id {Id}", 
                wikiPage.Id);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    public async Task UpdateWikiPageStatusAsync(string clientId, string realm, string status)
    {
        // Пункт 2: Валидация входных параметров
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        
        // Валидация статуса
        ValidateStatus(status);
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);

            var command = connection.CreateCommand();
            // Пункт 4: Исправление использования параметра realm
            command.CommandText = @"
                UPDATE client_wiki_pages
                SET status = @status,
                    updated_at = @updatedAt
                WHERE client_id = @clientId AND realm = @realm";

            var normalizedRealm = NormalizeRealm(realm);
            AddStringParameter(command, "@realm", normalizedRealm);
            AddStringParameter(command, "@status", status);
            AddStringParameter(command, "@updatedAt", DateTime.UtcNow.ToString("O"));
            AddStringParameter(command, "@clientId", clientId);

            var rowsAffected = await command.ExecuteNonQueryAsync();
            
            if (rowsAffected == 0)
            {
                _logger.LogWarning(
                    "No wiki page found to update for client {ClientId} in realm {Realm}", 
                    clientId, normalizedRealm);
            }
        }
        catch (SqliteException ex)
        {
            // Пункт 3: Обработка исключений
            _logger.LogError(ex, 
                "SQLite error while updating wiki page status for client {ClientId}: {ErrorCode}", 
                clientId, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, 
                "Unexpected error while updating wiki page status for client {ClientId}", 
                clientId);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    public async Task DeleteWikiPageAsync(string clientId, string realm)
    {
        // Пункт 2: Валидация входных параметров
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);

            var command = connection.CreateCommand();
            // Пункт 4: Исправление использования параметра realm
            command.CommandText = @"
                DELETE FROM client_wiki_pages
                WHERE client_id = @clientId AND realm = @realm";

            var normalizedRealm = NormalizeRealm(realm);
            AddStringParameter(command, "@clientId", clientId);
            AddStringParameter(command, "@realm", normalizedRealm);

            var rowsAffected = await command.ExecuteNonQueryAsync();
            
            if (rowsAffected == 0)
            {
                _logger.LogWarning(
                    "No wiki page found to delete for client {ClientId} in realm {Realm}", 
                    clientId, normalizedRealm);
            }
        }
        catch (SqliteException ex)
        {
            // Пункт 3: Обработка исключений
            _logger.LogError(ex, 
                "SQLite error while deleting wiki page for client {ClientId}: {ErrorCode}", 
                clientId, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, 
                "Unexpected error while deleting wiki page for client {ClientId}", 
                clientId);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    public async Task<bool> WikiPageExistsAsync(string clientId, string realm)
    {
        // Пункт 2: Валидация входных параметров
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);

            var command = connection.CreateCommand();
            // Пункт 4: Исправление использования параметра realm
            command.CommandText = @"
                SELECT COUNT(1)
                FROM client_wiki_pages
                WHERE client_id = @clientId AND realm = @realm";

            var normalizedRealm = NormalizeRealm(realm);
            AddStringParameter(command, "@clientId", clientId);
            AddStringParameter(command, "@realm", normalizedRealm);

            var result = await command.ExecuteScalarAsync();
            // Пункт 11: Безопасное преобразование с проверкой на переполнение
            return SafeConvertToInt32(result, "WikiPageExistsAsync") > 0;
        }
        catch (SqliteException ex)
        {
            // Пункт 3: Обработка исключений
            _logger.LogError(ex, 
                "SQLite error while checking wiki page existence for client {ClientId}: {ErrorCode}", 
                clientId, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, 
                "Unexpected error while checking wiki page existence for client {ClientId}", 
                clientId);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Проверить, существует ли Wiki страница по id
    /// </summary>
    /// <param name="id">Идентификатор записи</param>
    /// <returns>True, если запись существует</returns>
    public async Task<bool> WikiPageExistsByIdAsync(int id)
    {
        // Пункт 13: Метод для проверки существования по id
        if (id <= 0)
            return false;
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);

            var command = connection.CreateCommand();
            command.CommandText = "SELECT COUNT(1) FROM client_wiki_pages WHERE id = @id";
            AddIntParameter(command, "@id", id);

            var result = await command.ExecuteScalarAsync();
            return SafeConvertToInt32(result, "WikiPageExistsByIdAsync") > 0;
        }
        catch (SqliteException ex)
        {
            _logger.LogError(ex, 
                "SQLite error while checking wiki page existence by id {Id}: {ErrorCode}", 
                id, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error checking wiki page existence by id {Id}", id);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Получить все Wiki страницы для указанного realm
    /// </summary>
    /// <param name="realm">Realm для поиска</param>
    /// <returns>Список Wiki страниц</returns>
    public async Task<List<ClientWikiPage>> GetWikiPagesByRealmAsync(string realm)
    {
        // Пункт 14: Метод для получения всех записей по realm
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        var pages = new List<ClientWikiPage>();
        
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);

            var command = connection.CreateCommand();
            command.CommandText = @"
                SELECT id, client_id, realm, wiki_page_id, wiki_page_title, wiki_page_url, 
                       status, created_at, updated_at, created_by, page_version
                FROM client_wiki_pages
                WHERE realm = @realm
                ORDER BY updated_at DESC";
            
            AddStringParameter(command, "@realm", realm);

            await using var reader = await command.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                // Использование MapReaderToWikiPage для устранения дублирования
                pages.Add(MapReaderToWikiPage(reader));
            }
            
            return pages;
        }
        catch (SqliteException ex)
        {
            _logger.LogError(ex, 
                "SQLite error while getting wiki pages for realm {Realm}: {ErrorCode}", 
                realm, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting wiki pages for realm {Realm}", realm);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Массовое обновление статуса Wiki страниц для указанного realm
    /// </summary>
    /// <param name="realm">Realm для обновления</param>
    /// <param name="status">Новый статус</param>
    /// <returns>Количество обновленных записей</returns>
    public async Task<int> UpdateWikiPagesStatusByRealmAsync(string realm, string status)
    {
        // Пункт 15: Метод для массового обновления статуса
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        // Валидация статуса
        ValidateStatus(status);
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);

            var command = connection.CreateCommand();
            command.CommandText = @"
                UPDATE client_wiki_pages
                SET status = @status,
                    updated_at = @updatedAt
                WHERE realm = @realm";

            AddStringParameter(command, "@realm", realm);
            AddStringParameter(command, "@status", status);
            AddStringParameter(command, "@updatedAt", DateTime.UtcNow.ToString("O"));

            var rowsAffected = await command.ExecuteNonQueryAsync();
            
            _logger.LogInformation(
                "Updated status to {Status} for {Count} wiki pages in realm {Realm}", 
                status, rowsAffected, realm);
            
            return rowsAffected;
        }
        catch (SqliteException ex)
        {
            _logger.LogError(ex, 
                "SQLite error while updating wiki pages status for realm {Realm}: {ErrorCode}", 
                realm, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating wiki pages status for realm {Realm}", realm);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Получить Wiki страницу по id
    /// </summary>
    /// <param name="id">Идентификатор записи</param>
    /// <returns>Wiki страница или null, если не найдена</returns>
    public async Task<ClientWikiPage?> GetWikiPageByIdAsync(int id)
    {
        if (id <= 0)
            throw new ArgumentException("Id must be greater than 0", nameof(id));
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);

            var command = connection.CreateCommand();
            command.CommandText = @"
                SELECT id, client_id, realm, wiki_page_id, wiki_page_title, wiki_page_url, 
                       status, created_at, updated_at, created_by, page_version
                FROM client_wiki_pages
                WHERE id = @id
                LIMIT 1";

            AddIntParameter(command, "@id", id);

            await using var reader = await command.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                return MapReaderToWikiPage(reader);
            }
            
            return null;
        }
        catch (SqliteException ex)
        {
            _logger.LogError(ex, 
                "SQLite error while getting wiki page by id {Id}: {ErrorCode}", 
                id, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting wiki page by id {Id}", id);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Получить все Wiki страницы
    /// </summary>
    /// <returns>Список всех Wiki страниц</returns>
    public async Task<List<ClientWikiPage>> GetAllWikiPagesAsync()
    {
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        var pages = new List<ClientWikiPage>();
        
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);

            var command = connection.CreateCommand();
            command.CommandText = @"
                SELECT id, client_id, realm, wiki_page_id, wiki_page_title, wiki_page_url, 
                       status, created_at, updated_at, created_by, page_version
                FROM client_wiki_pages
                ORDER BY updated_at DESC";

            await using var reader = await command.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                pages.Add(MapReaderToWikiPage(reader));
            }
            
            return pages;
        }
        catch (SqliteException ex)
        {
            _logger.LogError(ex, "SQLite error while getting all wiki pages: {ErrorCode}", ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting all wiki pages");
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }
}
