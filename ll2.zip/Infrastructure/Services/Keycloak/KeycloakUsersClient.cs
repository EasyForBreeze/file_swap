using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using new_assistant.Core.DTOs;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services.Keycloak;

/// <summary>
/// Клиент для работы с пользователями Keycloak
/// </summary>
public class KeycloakUsersClient : KeycloakHttpClientBase
{
    // Константы для JSON свойств
    private const string IdProperty = "id";
    private const string UsernameProperty = "username";
    private const string EmailProperty = "email";
    private const string FirstNameProperty = "firstName";
    private const string LastNameProperty = "lastName";
    private const string EnabledProperty = "enabled";
    
    // Константы для query параметров
    private const string ExactParam = "exact";
    private const string MaxParam = "max";
    private const string SearchParam = "search";
    
    // Константы для значений параметров
    private const int DefaultMaxResults = 10;
    private const int ExtendedMaxResults = 20;
    
    // Константы для валидации длины параметров (Проблема 1)
    private const int MaxUsernameLength = 200;
    private const int MaxSearchTermLength = 200;
    
    // Константы для ограничения размера ответов (Проблема 2, 5)
    private const int MaxResponseContentLength = 10 * 1024 * 1024; // 10 MB
    private const int MaxJsonContentLength = 10 * 1024 * 1024; // 10 MB
    
    // Константы для кэширования (Проблема 14)
    private static readonly TimeSpan UserCacheDuration = TimeSpan.FromMinutes(5);
    
    // Константы для сообщений об ошибках (Пункт 13)
    private const string ErrorSemaphoreDisposed = "Semaphore disposed, cannot execute operation: {Operation}";
    private const string ErrorTokenNotObtained = "Не удалось получить токен администратора для операции {Operation}: {Parameter}";
    private const string ErrorResponseContentNull = "Response.Content is null при операции {Operation}";
    private const string ErrorResponseContentEmpty = "Response content is empty при операции {Operation}";
    private const string ErrorHttpRequestFailed = "HTTP запрос завершился с ошибкой при операции {Operation}. StatusCode: {StatusCode}, ReasonPhrase: {ReasonPhrase}, ErrorContent: {ErrorContent}, Headers: {Headers}, ErrorType: {ErrorType}";
    private const string ErrorOperationCancelled = "Операция {Operation} была отменена. Время выполнения: {ElapsedMs}мс";
    private const string ErrorHttpRequestException = "HTTP ошибка при выполнении операции {Operation}. Время выполнения: {ElapsedMs}мс";
    private const string ErrorGeneralException = "Ошибка при выполнении операции {Operation}. Время выполнения: {ElapsedMs}мс";
    private const string ErrorEmptyJsonParsing = "Попытка парсинга пустого или null JSON";
    private const string ErrorEmptyJsonElementParsing = "Попытка парсинга пустого или null JSON в JsonElement массив";
    private const string ErrorParsingJsonElement = "Ошибка парсинга элемента {ElementIndex} JSON массива. Элемент будет пропущен. Error: {ErrorMessage}";
    private const string ErrorParsingJson = "Ошибка парсинга JSON ответа от Keycloak. Message: {ErrorMessage}, JSON Preview: {JsonPreview}, Path: {Path}, BytePosition: {BytePosition}";
    private const string ErrorParsingJsonUnexpected = "Неожиданная ошибка при парсинге JSON ответа от Keycloak. ErrorType: {ErrorType}, Message: {ErrorMessage}, JSON Preview: {JsonPreview}";
    private const string ErrorParsingJsonElements = "Ошибка парсинга JSON ответа от Keycloak в JsonElement массив. Message: {ErrorMessage}, JSON Preview: {JsonPreview}, Path: {Path}";
    private const string ErrorParsingJsonElementsUnexpected = "Неожиданная ошибка при парсинге JSON ответа от Keycloak в JsonElement массив. ErrorType: {ErrorType}, Message: {ErrorMessage}, JSON Preview: {JsonPreview}";
    private const string LogOperationSuccess = "Операция {Operation} завершена успешно. Realm: {Realm}, Username: {Username}, Результатов: {Count}";
    private const string LogOperationSuccessSearch = "Операция {Operation} завершена успешно. Realm: {Realm}, SearchTerm: {SearchTerm}, Результатов: {Count}";
    private const string LogOperationUserNotFound = "Операция {Operation} завершена: пользователь {Username} не найден в реалме {Realm}";
    private const string LogOperationMultipleUsers = "Операция {Operation}: найдено несколько пользователей ({Count}) с username {Username} в реалме {Realm}, возвращаем первого";
    private const string LogOperationUserFound = "Операция {Operation} завершена успешно: найден пользователь {Username} в реалме {Realm}";
    private const string LogParsedElementsCount = "Успешно распарсено {ParsedCount} из {TotalCount} элементов JSON массива";
    
    // Константы для магических чисел (Пункт 13, 14)
    private const int MaxErrorContentLength = 500;
    private const int MaxJsonPreviewLength = 200;
    private const string UnknownReasonPhrase = "Unknown";
    
    // Используем JsonSerializerOptions из базового класса (исправление проблемы #6)
    // Это обеспечивает консистентность и уменьшает потребление памяти
    private static JsonSerializerOptions DefaultJsonOptions => KeycloakHttpClientBase.DefaultJsonSerializerOptions;
    
    public KeycloakUsersClient(
        System.Net.Http.HttpClient httpClient,
        new_assistant.Configuration.KeycloakAdminSettings settings,
        ILogger logger,
        new_assistant.Core.Interfaces.IKeycloakCacheService cacheService,
        new_assistant.Core.Interfaces.IPerformanceMetricsService metricsService)
        : base(httpClient, settings, logger, cacheService, metricsService)
    {
    }
    
    #region Helper Methods - Валидация
    
    // Используем KeycloakParameterValidator для унификации валидации (исправление проблемы #2)
    // Все методы валидации удалены и заменены на использование KeycloakParameterValidator
    
    #endregion
    
    #region Helper Methods - HTTP обработка
    
    /// <summary>
    /// Типы ошибок HTTP ответа (Проблема 10)
    /// </summary>
    private enum ResponseErrorType
    {
        NotFound,
        ServerError,
        ClientError,
        RateLimit,
        Unknown
    }
    
    /// <summary>
    /// Выполняет HTTP запрос с обработкой rate limiting (Пункт 7)
    /// </summary>
    private async Task<HttpResponseMessage> ExecuteHttpRequestWithRateLimitAsync(
        HttpRequestMessage request,
        string endpoint,
        CancellationToken cancellationToken = default)
    {
        var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
        
        // Обработка rate limiting
        response = await HandleRateLimitAsync(response,
            async () =>
            {
                using var retryRequest = await CreateAuthorizedRequestAsync(request.Method, endpoint, cancellationToken).ConfigureAwait(false);
                return await HttpClient.SendAsync(retryRequest, cancellationToken).ConfigureAwait(false);
            },
            cancellationToken).ConfigureAwait(false);
        
        return response;
    }
    
    /// <summary>
    /// Читает содержимое HTTP ответа с проверкой на ошибки, ограничением размера и различением типов ошибок (Проблема 2, 10)
    /// </summary>
    private async Task<string?> ReadResponseContentAsync(
        HttpResponseMessage response, 
        string operationName,
        CancellationToken cancellationToken = default)
    {
        if (!response.IsSuccessStatusCode)
        {
            // Определяем тип ошибки (Проблема 10, Исправление проблемы 2)
            var errorType = response.StatusCode switch
            {
                HttpStatusCode.NotFound => ResponseErrorType.NotFound,
                HttpStatusCode.TooManyRequests => ResponseErrorType.RateLimit,
                >= HttpStatusCode.InternalServerError => ResponseErrorType.ServerError,
                >= HttpStatusCode.BadRequest => ResponseErrorType.ClientError,
                _ => ResponseErrorType.Unknown
            };
            
            var errorContent = response.Content != null
                ? await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false)
                : string.Empty;
            
            // Улучшенное логирование ошибок с большей информацией, включая тип ошибки (Исправление проблемы 2)
            var headers = string.Join("; ", response.Headers.Select(h => $"{h.Key}={string.Join(",", h.Value)}"));
            var truncatedError = errorContent.Length > MaxErrorContentLength ? errorContent.Substring(0, MaxErrorContentLength) + "..." : errorContent;
            
            Logger.LogError(
                ErrorHttpRequestFailed,
                operationName,
                response.StatusCode,
                response.ReasonPhrase ?? UnknownReasonPhrase,
                truncatedError,
                headers,
                errorType);
            return null;
        }
        
        if (response.Content == null)
        {
            Logger.LogWarning(ErrorResponseContentNull, operationName);
            return null;
        }
        
        // Проверяем Content-Length заголовок (Проблема 2)
        var contentLength = response.Content.Headers.ContentLength;
        if (contentLength.HasValue && contentLength.Value > MaxResponseContentLength)
        {
            Logger.LogError(
                "Response content length ({ContentLength} bytes) exceeds maximum allowed ({MaxLength} bytes) for operation {Operation}",
                contentLength.Value, MaxResponseContentLength, operationName);
            return null;
        }
        
        // Читаем с ограничением размера (Проблема 2)
        using var contentStream = await response.Content.ReadAsStreamAsync(cancellationToken).ConfigureAwait(false);
        using var reader = new StreamReader(contentStream);
        var buffer = new char[Math.Min(8192, MaxResponseContentLength)];
        var contentBuilder = new StringBuilder();
        var totalRead = 0;
        
        int read;
        while ((read = await reader.ReadAsync(buffer, 0, buffer.Length).ConfigureAwait(false)) > 0)
        {
            totalRead += read;
            if (totalRead > MaxResponseContentLength)
            {
                Logger.LogError(
                    "Response content exceeds maximum allowed length ({MaxLength} bytes) for operation {Operation}",
                    MaxResponseContentLength, operationName);
                return null;
            }
            contentBuilder.Append(buffer, 0, read);
        }
        
        var content = contentBuilder.ToString();
        
        if (string.IsNullOrWhiteSpace(content))
        {
            Logger.LogWarning(ErrorResponseContentEmpty, operationName);
            return null;
        }
        
        return content;
    }
    
    #endregion
    
    #region Helper Methods - Маппинг
    
    /// <summary>
    /// Маппинг JsonElement в UserSearchResultDto (Проблема 8)
    /// </summary>
    private UserSearchResultDto? MapToUserSearchResultDto(JsonElement userElement)
    {
        // Проверка на null или невалидный тип (Проблема 8)
        if (userElement.ValueKind == JsonValueKind.Null || userElement.ValueKind == JsonValueKind.Undefined)
            return null;
        
        if (userElement.ValueKind != JsonValueKind.Object)
        {
            Logger.LogWarning("Expected JsonValueKind.Object, but got {ValueKind}", userElement.ValueKind);
            return null;
        }
        
        var userId = userElement.TryGetProperty(IdProperty, out var idProp) && idProp.ValueKind == JsonValueKind.String
            ? idProp.GetString() 
            : null;
        var userName = userElement.TryGetProperty(UsernameProperty, out var usernameProp) && usernameProp.ValueKind == JsonValueKind.String
            ? usernameProp.GetString() 
            : null;
        
        // Пропускаем пользователей без обязательных полей
        if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(userName))
            return null;
        
        return new UserSearchResultDto
        {
            Id = userId,
            Username = userName,
            Email = userElement.TryGetProperty(EmailProperty, out var emailProp) && emailProp.ValueKind == JsonValueKind.String
                ? emailProp.GetString() 
                : null,
            FirstName = userElement.TryGetProperty(FirstNameProperty, out var firstNameProp) && firstNameProp.ValueKind == JsonValueKind.String
                ? firstNameProp.GetString() 
                : null,
            LastName = userElement.TryGetProperty(LastNameProperty, out var lastNameProp) && lastNameProp.ValueKind == JsonValueKind.String
                ? lastNameProp.GetString() 
                : null
        };
    }
    
    /// <summary>
    /// Маппинг JsonElement в UserSearchResult (для контроллера) (Проблема 8)
    /// </summary>
    private Controllers.UserSearchResult? MapToUserSearchResult(JsonElement userElement)
    {
        // Проверка на null или невалидный тип (Проблема 8)
        if (userElement.ValueKind == JsonValueKind.Null || userElement.ValueKind == JsonValueKind.Undefined)
            return null;
        
        if (userElement.ValueKind != JsonValueKind.Object)
        {
            Logger.LogWarning("Expected JsonValueKind.Object, but got {ValueKind}", userElement.ValueKind);
            return null;
        }
        
        var username = userElement.TryGetProperty(UsernameProperty, out var usernameEl) && usernameEl.ValueKind == JsonValueKind.String
            ? usernameEl.GetString() 
            : null;
        
        if (string.IsNullOrEmpty(username))
            return null;
        
        return new Controllers.UserSearchResult
        {
            Username = username,
            Email = userElement.TryGetProperty(EmailProperty, out var emailEl) && emailEl.ValueKind == JsonValueKind.String
                ? emailEl.GetString() 
                : null,
            FirstName = userElement.TryGetProperty(FirstNameProperty, out var fnEl) && fnEl.ValueKind == JsonValueKind.String
                ? fnEl.GetString() 
                : null,
            LastName = userElement.TryGetProperty(LastNameProperty, out var lnEl) && lnEl.ValueKind == JsonValueKind.String
                ? lnEl.GetString() 
                : null,
            Enabled = userElement.TryGetProperty(EnabledProperty, out var enabledEl)
                ? (enabledEl.ValueKind == JsonValueKind.True ? true :
                   enabledEl.ValueKind == JsonValueKind.False ? false : false)
                : false // По умолчанию false, если свойство отсутствует (Исправление проблемы 4)
        };
    }
    
    /// <summary>
    /// Маппинг JsonElement в UserDto (Проблема 8)
    /// </summary>
    private UserDto? MapToUserDto(JsonElement userElement)
    {
        // Проверка на null или невалидный тип (Проблема 8)
        if (userElement.ValueKind == JsonValueKind.Null || userElement.ValueKind == JsonValueKind.Undefined)
            return null;
        
        if (userElement.ValueKind != JsonValueKind.Object)
        {
            Logger.LogWarning("Expected JsonValueKind.Object, but got {ValueKind}", userElement.ValueKind);
            return null;
        }
        
        var userId = userElement.TryGetProperty(IdProperty, out var idProp) && idProp.ValueKind == JsonValueKind.String
            ? idProp.GetString() 
            : null;
        var userName = userElement.TryGetProperty(UsernameProperty, out var usernameProp) && usernameProp.ValueKind == JsonValueKind.String
            ? usernameProp.GetString() 
            : null;
        
        if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(userName))
            return null;
        
        return new UserDto
        {
            Id = userId,
            Username = userName,
            Email = userElement.TryGetProperty(EmailProperty, out var emailProp) && emailProp.ValueKind == JsonValueKind.String
                ? emailProp.GetString() 
                : null,
            FirstName = userElement.TryGetProperty(FirstNameProperty, out var firstNameProp) && firstNameProp.ValueKind == JsonValueKind.String
                ? firstNameProp.GetString() 
                : null,
            LastName = userElement.TryGetProperty(LastNameProperty, out var lastNameProp) && lastNameProp.ValueKind == JsonValueKind.String
                ? lastNameProp.GetString() 
                : null,
            Enabled = userElement.TryGetProperty(EnabledProperty, out var enabledEl)
                ? (enabledEl.ValueKind == JsonValueKind.True ? true :
                   enabledEl.ValueKind == JsonValueKind.False ? false : false)
                : false // По умолчанию false, если свойство отсутствует (Исправление проблемы 4)
        };
    }
    
    #endregion
    
    #region Helper Methods - JSON парсинг
    
    /// <summary>
    /// Парсит JSON массив в список объектов через маппер (Проблема 5, 7)
    /// </summary>
    private List<T> ParseJsonArray<T>(string json, Func<JsonElement, T?> mapper) where T : class
    {
        if (string.IsNullOrWhiteSpace(json))
        {
            Logger.LogWarning(ErrorEmptyJsonParsing);
            return new List<T>();
        }
        
        // Проверка размера перед парсингом (Проблема 5)
        if (json.Length > MaxJsonContentLength)
        {
            Logger.LogError(
                "JSON content length ({Length} bytes) exceeds maximum allowed ({MaxLength} bytes)",
                json.Length, MaxJsonContentLength);
            return new List<T>();
        }
        
        JsonDocument? document = null;
        try
        {
            document = JsonDocument.Parse(json);
            
            if (document.RootElement.ValueKind != JsonValueKind.Array)
            {
                Logger.LogWarning("JSON root element is not an array, got {ValueKind}", document.RootElement.ValueKind);
                return new List<T>();
            }
            
            // Используем один проход с динамическим увеличением capacity (Исправление проблемы 3)
            // List<T> автоматически увеличивает capacity при необходимости, что эффективнее двойного прохода
            var results = new List<T>();
            var elementCount = 0;
            
            foreach (var element in document.RootElement.EnumerateArray())
            {
                elementCount++;
                try
                {
                    var mapped = mapper(element);
                    if (mapped != null)
                        results.Add(mapped);
                }
                catch (Exception ex)
                {
                    // Улучшенная обработка ошибок парсинга отдельных элементов (Пункт 12)
                    Logger.LogWarning(ex, ErrorParsingJsonElement, elementCount, ex.Message);
                }
            }
            
            if (results.Count < elementCount)
            {
                Logger.LogDebug(LogParsedElementsCount, results.Count, elementCount);
            }
            
            return results;
        }
        catch (JsonException ex)
        {
            // Улучшенная обработка ошибок парсинга JSON (Пункт 12, 13)
            var jsonPreview = json.Length > MaxJsonPreviewLength ? json.Substring(0, MaxJsonPreviewLength) + "..." : json;
            Logger.LogError(ex, ErrorParsingJson, ex.Message, jsonPreview, ex.Path, ex.BytePositionInLine);
            return new List<T>();
        }
        catch (Exception ex)
        {
            // Улучшенная обработка неожиданных ошибок (Пункт 12, 13)
            var jsonPreview = json.Length > MaxJsonPreviewLength ? json.Substring(0, MaxJsonPreviewLength) + "..." : json;
            Logger.LogError(ex, ErrorParsingJsonUnexpected, ex.GetType().Name, ex.Message, jsonPreview);
            return new List<T>();
        }
        finally
        {
            document?.Dispose();
        }
    }
    
    /// <summary>
    /// Парсит JSON массив в список JsonElement с созданием независимых копий (Исправление проблемы 1)
    /// Создает независимые копии элементов для предотвращения утечек памяти
    /// </summary>
    private List<JsonElement> ParseJsonArrayToElements(string json)
    {
        if (string.IsNullOrWhiteSpace(json))
        {
            Logger.LogWarning(ErrorEmptyJsonElementParsing);
            return new List<JsonElement>();
        }
        
        // Проверка размера перед парсингом (Проблема 5)
        if (json.Length > MaxJsonContentLength)
        {
            Logger.LogError(
                "JSON content length ({Length} bytes) exceeds maximum allowed ({MaxLength} bytes)",
                json.Length, MaxJsonContentLength);
            return new List<JsonElement>();
        }
        
        JsonDocument? document = null;
        try
        {
            document = JsonDocument.Parse(json);
            
            if (document.RootElement.ValueKind != JsonValueKind.Array)
            {
                Logger.LogWarning("JSON root element is not an array, got {ValueKind}", document.RootElement.ValueKind);
                return new List<JsonElement>();
            }
            
            // Создаем независимые копии элементов для предотвращения утечек памяти (исправление проблемы #3)
            // Используем более эффективный метод через JsonDocument.Clone() для каждого элемента
            // Это быстрее и использует меньше памяти чем сериализация/десериализация
            var elements = new List<JsonElement>();
            foreach (var element in document.RootElement.EnumerateArray())
            {
                // Создаем независимую копию через клонирование JSON строки элемента
                // Это более эффективно чем полная сериализация/десериализация
                var elementJson = element.GetRawText();
                using var elementDoc = JsonDocument.Parse(elementJson, new JsonDocumentOptions 
                { 
                    AllowTrailingCommas = false,
                    CommentHandling = JsonCommentHandling.Skip,
                    MaxDepth = 64
                });
                elements.Add(elementDoc.RootElement.Clone());
            }
            
            return elements;
        }
        catch (JsonException ex)
        {
            // Улучшенная обработка ошибок парсинга JSON (Пункт 12, 13)
            var jsonPreview = json.Length > MaxJsonPreviewLength ? json.Substring(0, MaxJsonPreviewLength) + "..." : json;
            Logger.LogError(ex, ErrorParsingJsonElements, ex.Message, jsonPreview, ex.Path);
            return new List<JsonElement>();
        }
        catch (Exception ex)
        {
            // Улучшенная обработка неожиданных ошибок (Пункт 12, 13)
            var jsonPreview = json.Length > MaxJsonPreviewLength ? json.Substring(0, MaxJsonPreviewLength) + "..." : json;
            Logger.LogError(ex, ErrorParsingJsonElementsUnexpected, ex.GetType().Name, ex.Message, jsonPreview);
            return new List<JsonElement>();
        }
        finally
        {
            // Теперь можно безопасно освободить документ, так как элементы независимы
            document?.Dispose();
        }
    }
    
    #endregion
    
    #region Общий метод-обертка для устранения дублирования (Проблема 4, 9)
    
    /// <summary>
    /// Унифицированный метод для выполнения операций с метриками, обработкой ошибок и управлением семафором (Проблема 4, 9)
    /// </summary>
    private async Task<TResult> ExecuteWithMetricsAsync<TResult>(
        string operationName,
        Func<CancellationToken, Task<TResult>> operation,
        TResult defaultValue,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
            
            if (!acquired)
            {
                Logger.LogWarning(ErrorSemaphoreDisposed, operationName);
                return defaultValue;
            }
            
            try
            {
                var result = await operation(cancellationToken).ConfigureAwait(false);
                return result;
            }
            finally
            {
                SafeReleaseSemaphore();
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
        }
        catch (OperationCanceledException)
        {
            stopwatch.Stop();
            Logger.LogWarning(ErrorOperationCancelled, operationName, stopwatch.ElapsedMilliseconds);
            throw;
        }
        catch (HttpRequestException ex)
        {
            stopwatch.Stop();
            Logger.LogError(ex, ErrorHttpRequestException, operationName, stopwatch.ElapsedMilliseconds);
            return defaultValue;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            Logger.LogError(ex, ErrorGeneralException, operationName, stopwatch.ElapsedMilliseconds);
            return defaultValue;
        }
    }
    
    #endregion
    
    #region Публичные методы
    
    /// <summary>
    /// Общий приватный метод для получения пользователей по username (Проблема 6)
    /// </summary>
    private async Task<List<JsonElement>> GetUsersByUsernameInternalAsync(
        string realm, 
        string username, 
        string operationName,
        CancellationToken cancellationToken)
    {
        var endpoint = $"admin/realms/{realm}/users?username={Uri.EscapeDataString(username)}&{ExactParam}=true";
        
        using var request = await CreateAuthorizedRequestAsync(HttpMethod.Get, endpoint, cancellationToken).ConfigureAwait(false);
        using var response = await ExecuteHttpRequestWithRateLimitAsync(request, endpoint, cancellationToken).ConfigureAwait(false);
        
        var content = await ReadResponseContentAsync(response, operationName, cancellationToken).ConfigureAwait(false);
        if (content == null)
            return new List<JsonElement>();
        
        var users = ParseJsonArrayToElements(content);
        
        if (users == null || users.Count == 0)
        {
            Logger.LogInformation(LogOperationUserNotFound, operationName, username, realm);
            return new List<JsonElement>();
        }
        
        if (users.Count > 1)
        {
            Logger.LogWarning(LogOperationMultipleUsers, operationName, users.Count, username, realm);
        }
        
        Logger.LogDebug(LogOperationUserFound, operationName, username, realm);
        return users;
    }
    
    /// <summary>
    /// Поиск пользователей по username в конкретном реалме (Проблема 11)
    /// </summary>
    /// <param name="realm">Название реалма Keycloak</param>
    /// <param name="username">Username для поиска (частичное совпадение)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список найденных пользователей или пустой список в случае ошибки</returns>
    public async Task<IReadOnlyList<UserSearchResultDto>> SearchUsersByUsernameAsync(string realm, string username, CancellationToken cancellationToken = default)
    {
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUsername(username);
        cancellationToken.ThrowIfCancellationRequested();
        
        const string operationName = "SearchUsersByUsername";
        
        return await ExecuteWithMetricsAsync(operationName, async (ct) =>
        {
            var endpoint = $"admin/realms/{realm}/users?username={Uri.EscapeDataString(username)}&{ExactParam}=false&{MaxParam}={DefaultMaxResults}";
            
            using var request = await CreateAuthorizedRequestAsync(HttpMethod.Get, endpoint, ct).ConfigureAwait(false);
            using var response = await ExecuteHttpRequestWithRateLimitAsync(request, endpoint, ct).ConfigureAwait(false);
            
            var content = await ReadResponseContentAsync(response, operationName, ct).ConfigureAwait(false);
            if (content == null)
                return (IReadOnlyList<UserSearchResultDto>)new List<UserSearchResultDto>();
            
            // Унифицированный подход к десериализации JSON (Пункт 4)
            var results = ParseJsonArray(content, MapToUserSearchResultDto);
            
            // Унифицированное логирование успешных операций (Пункт 11, 13)
            Logger.LogInformation(LogOperationSuccess, operationName, realm, username, results.Count);
            
            // Возвращаем как IReadOnlyList (Проблема 11)
            return results;
        }, (IReadOnlyList<UserSearchResultDto>)new List<UserSearchResultDto>(), cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Поиск пользователей в KeyCloak по username (Проблема 11)
    /// </summary>
    /// <param name="searchTerm">Поисковый запрос</param>
    /// <param name="realm">Название реалма Keycloak</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список найденных пользователей или пустой список в случае ошибки</returns>
    public async Task<IReadOnlyList<Controllers.UserSearchResult>> SearchUsersAsync(string searchTerm, string realm, CancellationToken cancellationToken = default)
    {
        KeycloakParameterValidator.ValidateSearchTerm(searchTerm);
        KeycloakParameterValidator.ValidateRealm(realm);
        cancellationToken.ThrowIfCancellationRequested();
        
        const string operationName = "SearchUsers";
        
        return await ExecuteWithMetricsAsync(operationName, async (ct) =>
        {
            var endpoint = $"admin/realms/{realm}/users?{SearchParam}={Uri.EscapeDataString(searchTerm)}&{MaxParam}={ExtendedMaxResults}";
            
            using var request = await CreateAuthorizedRequestAsync(HttpMethod.Get, endpoint, ct).ConfigureAwait(false);
            using var response = await ExecuteHttpRequestWithRateLimitAsync(request, endpoint, ct).ConfigureAwait(false);
            
            var content = await ReadResponseContentAsync(response, operationName, ct).ConfigureAwait(false);
            if (content == null)
                return (IReadOnlyList<Controllers.UserSearchResult>)new List<Controllers.UserSearchResult>();
            
            var results = ParseJsonArray(content, MapToUserSearchResult);
            
            // Унифицированное логирование успешных операций (Пункт 11, 13)
            Logger.LogInformation(LogOperationSuccessSearch, operationName, realm, searchTerm, results.Count);
            
            // Возвращаем как IReadOnlyList (Проблема 11)
            return results;
        }, (IReadOnlyList<Controllers.UserSearchResult>)new List<Controllers.UserSearchResult>(), cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Найти пользователя по username в конкретном реалме (для обратной совместимости - возвращает JsonElement) (Проблема 6)
    /// </summary>
    /// <param name="realm">Название реалма Keycloak</param>
    /// <param name="username">Username для поиска (точное совпадение)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>JsonElement пользователя или null если не найден</returns>
    public async Task<JsonElement?> GetUserByUsernameAsync(string realm, string username, CancellationToken cancellationToken = default)
    {
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUsername(username);
        cancellationToken.ThrowIfCancellationRequested();
        
        const string operationName = "GetUserByUsername";
        
        return await ExecuteWithMetricsAsync(operationName, async (ct) =>
        {
            var users = await GetUsersByUsernameInternalAsync(realm, username, operationName, ct).ConfigureAwait(false);
            return users.Count > 0 ? users[0] : (JsonElement?)null;
        }, default(JsonElement?), cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Найти пользователя по username в конкретном реалме (возвращает DTO) (Проблема 6, 14)
    /// </summary>
    /// <param name="realm">Название реалма Keycloak</param>
    /// <param name="username">Username для поиска (точное совпадение)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>UserDto пользователя или null если не найден</returns>
    public async Task<UserDto?> GetUserDtoByUsernameAsync(string realm, string username, CancellationToken cancellationToken = default)
    {
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateUsername(username);
        cancellationToken.ThrowIfCancellationRequested();
        
        const string operationName = "GetUserDtoByUsername";
        var cacheKey = $"user:{realm}:{username}";
        
        // Проверяем кэш (Проблема 14)
        var cachedUser = await CacheService.GetAsync<UserDto>(cacheKey, cancellationToken).ConfigureAwait(false);
        if (cachedUser != null)
        {
            RecordCacheHit(cacheKey);
            return cachedUser;
        }
        
        RecordCacheMiss(cacheKey);
        
        return await ExecuteWithMetricsAsync(operationName, async (ct) =>
        {
            var users = await GetUsersByUsernameInternalAsync(realm, username, operationName, ct).ConfigureAwait(false);
            if (users.Count == 0)
                return null;
            
            var userDto = MapToUserDto(users[0]);
            
            // Сохраняем в кэш (Проблема 14)
            if (userDto != null)
            {
                await CacheService.SetAsync(cacheKey, userDto, UserCacheDuration, cancellationToken).ConfigureAwait(false);
            }
            
            return userDto;
        }, default(UserDto?), cancellationToken).ConfigureAwait(false);
    }
    
    #endregion
}
