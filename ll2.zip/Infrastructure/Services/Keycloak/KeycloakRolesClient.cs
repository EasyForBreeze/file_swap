using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;
using new_assistant.Core.Models;

namespace new_assistant.Infrastructure.Services.Keycloak;

/// <summary>
/// Facade клиент для работы с ролями Keycloak (client roles, realm roles, назначение ролей пользователям)
/// Использует паттерн Facade для упрощения интерфейса и делегирует вызовы в специализированные клиенты:
/// - KeycloakClientRolesClient - для работы с client roles
/// - KeycloakRealmRolesClient - для работы с realm roles
/// - KeycloakRoleMappingClient - для назначения и удаления ролей пользователям
/// - KeycloakRoleBatchOperationsClient - для массовых операций с ролями
/// 
/// Все специализированные клиенты должны быть зарегистрированы в DI контейнере и переданы через конструктор.
/// </summary>
public class KeycloakRolesClient : KeycloakHttpClientBase
{
    // Используем JsonSerializerOptions из базового класса (исправление проблемы #6)
    private static JsonSerializerOptions DefaultJsonOptions => KeycloakHttpClientBase.DefaultJsonSerializerOptions;
    
    // Константы для HTTP заголовков
    // BearerScheme определен в базовом классе KeycloakHttpClientBase как protected const
    private const string AcceptHeader = "Accept";
    private const string ApplicationJsonContentType = "application/json";
    
    // Константы для JSON свойств (используются только для валидации)
    private const string NameProperty = "name";
    private const string IdProperty = "id";
    
    // Константы для логирования
    private new const int MaxContentLengthForLogging = 500;
    private const int MaxErrorContentLengthForLogging = 500;
    
    // Константы для валидации параметров
    // Используем константы MaxRealmLength и MaxEndpointLength из базового класса KeycloakHttpClientBase
    private const int MaxClientInternalIdLength = 100;
    private const int MaxUserIdLength = 100;
    private const int MaxSearchTermLength = 100;
    
    // Константы для размеров и лимитов (используются из конфигурации)
    // Значения по умолчанию задаются в KeycloakRolesSettings
    private int MaxRoleNameLength
    {
        get
        {
            if (Settings.Roles != null)
                return Settings.Roles.MaxRoleNameLength;
            
            Logger.LogWarning("Settings.Roles is null, using default value {DefaultValue} for MaxRoleNameLength", 255);
            return 255;
        }
    }
    
    private int MaxRoleIdLength
    {
        get
        {
            if (Settings.Roles != null)
                return Settings.Roles.MaxRoleIdLength;
            
            Logger.LogWarning("Settings.Roles is null, using default value {DefaultValue} for MaxRoleIdLength", 100);
            return 100;
        }
    }
    
    private int MaxRoleDescriptionLength
    {
        get
        {
            if (Settings.Roles != null)
                return Settings.Roles.MaxRoleDescriptionLength;
            
            Logger.LogWarning("Settings.Roles is null, using default value {DefaultValue} for MaxRoleDescriptionLength", 1000);
            return 1000;
        }
    }
    
    private int MaxJsonContentSizeBytes
    {
        get
        {
            if (Settings.Roles != null)
                return Settings.Roles.MaxJsonContentSizeBytes;
            
            Logger.LogWarning("Settings.Roles is null, using default value {DefaultValue} for MaxJsonContentSizeBytes", 1048576);
            return 1048576;
        }
    }
    
    private int DefaultMaxRolesPerRequest
    {
        get
        {
            if (Settings.Roles != null)
                return Settings.Roles.DefaultMaxRolesPerRequest;
            
            Logger.LogWarning("Settings.Roles is null, using default value {DefaultValue} for DefaultMaxRolesPerRequest", 101);
            return 101;
        }
    }
    
    private TimeSpan RolesCacheDuration
    {
        get
        {
            if (Settings.Roles != null)
                return Settings.Roles.CacheDuration;
            
            var defaultValue = TimeSpan.FromMinutes(30);
            Logger.LogWarning("Settings.Roles is null, using default value {DefaultValue} for CacheDuration", defaultValue);
            return defaultValue;
        }
    }
    
    private int MaxBatchSize
    {
        get
        {
            if (Settings.Roles != null)
                return Settings.Roles.MaxBatchSize;
            
            Logger.LogWarning("Settings.Roles is null, using default value {DefaultValue} for MaxBatchSize", 100);
            return 100;
        }
    }
    
    /// <summary>
    /// Читает errorContent из HttpResponseMessage с ограничением длины для логирования
    /// </summary>
    private async Task<string> ReadErrorContentAsync(HttpResponseMessage response, CancellationToken cancellationToken)
    {
        if (response.Content == null)
            return string.Empty;
        
        var errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
        
        if (errorContent.Length > MaxErrorContentLengthForLogging)
        {
            return string.Concat(errorContent.AsSpan(0, MaxErrorContentLengthForLogging), "...");
        }
        
        return errorContent;
    }
    
    /// <summary>
    /// Проверяет валидность endpoint перед использованием (исправление проблемы #10)
    /// Использует whitelist подход для безопасности
    /// </summary>
    private bool ValidateEndpoint(string endpoint, out string? errorMessage)
    {
        errorMessage = null;
        
        if (endpoint.Length > MaxEndpointLength)
        {
            errorMessage = $"Endpoint too long: {endpoint.Length} characters";
            return false;
        }
        
        if (string.IsNullOrEmpty(endpoint))
        {
            errorMessage = "Endpoint cannot be null or empty";
            return false;
        }
        
        // Whitelist подход: разрешаем только безопасные символы для URL пути
        // Разрешенные символы: буквы (a-z, A-Z), цифры (0-9), дефис (-), подчеркивание (_), 
        // точка (.), слэш (/), двоеточие (:), знак равенства (=), амперсанд (&), знак вопроса (?)
        // Это безопасные символы для относительных URL путей
        var allowedChars = new HashSet<char>();
        for (char c = 'a'; c <= 'z'; c++) allowedChars.Add(c);
        for (char c = 'A'; c <= 'Z'; c++) allowedChars.Add(c);
        for (char c = '0'; c <= '9'; c++) allowedChars.Add(c);
        allowedChars.Add('-');
        allowedChars.Add('_');
        allowedChars.Add('.');
        allowedChars.Add('/');
        allowedChars.Add(':');
        allowedChars.Add('=');
        allowedChars.Add('&');
        allowedChars.Add('?');
        allowedChars.Add('%'); // Для URL-encoded символов
        allowedChars.Add(' '); // Пробел (будет закодирован)
        
        // Проверяем каждый символ на наличие в whitelist
        foreach (var c in endpoint)
        {
            // Разрешаем URL-encoded символы (формат %XX)
            if (c == '%')
            {
                // Пропускаем проверку для % символа, так как он используется для encoding
                continue;
            }
            
            if (!allowedChars.Contains(c) && !char.IsLetterOrDigit(c))
            {
                errorMessage = $"Endpoint contains invalid character: '{c}' (ASCII: {(int)c})";
                return false;
            }
        }
        
        // Дополнительные проверки безопасности
        if (endpoint.Contains("..") || endpoint.Contains("//"))
        {
            errorMessage = $"Endpoint contains invalid path sequences";
            return false;
        }
        
        // Защита от абсолютных URL (должен быть только относительный путь)
        if (Uri.TryCreate(endpoint, UriKind.Absolute, out _))
        {
            errorMessage = $"Endpoint must be relative, not absolute";
            return false;
        }
        
        if (!Uri.IsWellFormedUriString(endpoint, UriKind.Relative))
        {
            errorMessage = $"Invalid endpoint format";
            return false;
        }
        
        return true;
    }
    
    // Метод CreateAuthorizedRequestAsync уже определен в базовом классе KeycloakHttpClientBase
    // Используем его напрямую через наследование
    
    /// <summary>
    /// Создает HttpRequestMessage с Bearer токеном авторизации и Accept header
    /// </summary>
    private async Task<HttpRequestMessage> CreateAuthorizedRequestWithAcceptAsync(HttpMethod method, string endpoint, CancellationToken cancellationToken = default)
    {
        var request = await CreateAuthorizedRequestAsync(method, endpoint, cancellationToken).ConfigureAwait(false);
        request.Headers.Add(AcceptHeader, ApplicationJsonContentType);
        return request;
    }
    
    #region Validation Methods
    
    /// <summary>
    /// Валидация параметра realm
    /// </summary>
    protected void ValidateRealm(string realm)
    {
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        if (realm.Length > MaxRealmLength)
            throw new ArgumentException($"Realm cannot exceed {MaxRealmLength} characters", nameof(realm));
    }
    
    /// <summary>
    /// Валидация параметра clientInternalId
    /// </summary>
    protected void ValidateClientInternalId(string clientInternalId)
    {
        if (string.IsNullOrWhiteSpace(clientInternalId))
            throw new ArgumentException("ClientInternalId cannot be null or empty", nameof(clientInternalId));
        if (clientInternalId.Length > MaxClientInternalIdLength)
            throw new ArgumentException($"ClientInternalId cannot exceed {MaxClientInternalIdLength} characters", nameof(clientInternalId));
    }
    
    /// <summary>
    /// Валидация параметра userId
    /// </summary>
    protected void ValidateUserId(string userId)
    {
        if (string.IsNullOrWhiteSpace(userId))
            throw new ArgumentException("UserId cannot be null or empty", nameof(userId));
        if (userId.Length > MaxUserIdLength)
            throw new ArgumentException($"UserId cannot exceed {MaxUserIdLength} characters", nameof(userId));
    }
    
    /// <summary>
    /// Валидация параметра roleName
    /// </summary>
    protected void ValidateRoleName(string roleName)
    {
        if (string.IsNullOrWhiteSpace(roleName))
            throw new ArgumentException("RoleName cannot be null or empty", nameof(roleName));
        if (roleName.Length > MaxRoleNameLength)
            throw new ArgumentException($"RoleName cannot exceed {MaxRoleNameLength} characters", nameof(roleName));
    }
    
    /// <summary>
    /// Валидация параметра roleId
    /// </summary>
    protected void ValidateRoleId(string roleId)
    {
        if (string.IsNullOrWhiteSpace(roleId))
            throw new ArgumentException("RoleId cannot be null or empty", nameof(roleId));
        if (roleId.Length > MaxRoleIdLength)
            throw new ArgumentException($"RoleId cannot exceed {MaxRoleIdLength} characters", nameof(roleId));
    }
    
    /// <summary>
    /// Валидация параметра description роли
    /// </summary>
    protected void ValidateRoleDescription(string? description)
    {
        if (description != null && description.Length > MaxRoleDescriptionLength)
        {
            throw new ArgumentException($"Role description cannot exceed {MaxRoleDescriptionLength} characters", nameof(description));
        }
    }
    
    /// <summary>
    /// Валидация параметра searchTerm
    /// </summary>
    protected void ValidateSearchTerm(string searchTerm)
    {
        if (searchTerm == null)
            return; // searchTerm может быть null (опциональный параметр)
        
        if (searchTerm.Length > MaxSearchTermLength)
            throw new ArgumentException($"SearchTerm cannot exceed {MaxSearchTermLength} characters", nameof(searchTerm));
    }
    
    #endregion
    
    #region Request Execution Helpers
    
    // Используем ErrorHandlingStrategy из базового класса KeycloakHttpClientBase
    
    /// <summary>
    /// Выполняет HTTP запрос с общей обработкой ошибок, semaphore и метриками
    /// </summary>
    protected async Task<Result<T>> ExecuteRequestAsync<T>(
        string endpoint,
        HttpMethod method,
        ErrorHandlingStrategy errorStrategy = ErrorHandlingStrategy.ReturnEmpty,
        object? requestBody = null,
        CancellationToken cancellationToken = default)
        where T : class
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        if (Logger.IsEnabled(LogLevel.Debug))
        {
            Logger.LogDebug("Выполнение запроса {Method} {Endpoint}", method, endpoint);
        }
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation {Method} {Endpoint}", method, endpoint);
            return errorStrategy switch
            {
                ErrorHandlingStrategy.ReturnEmpty => Result<T>.Success(default(T)!), // Используем null для reference types
                ErrorHandlingStrategy.ReturnNull => Result<T>.Failure("Semaphore disposed"),
                _ => Result<T>.Failure("Semaphore disposed")
            };
        }
        
        try
        {
            if (!ValidateEndpoint(endpoint, out var endpointError))
            {
                Logger.LogError("Invalid endpoint: {EndpointError}", endpointError);
                return Result<T>.Failure(endpointError ?? "Invalid endpoint");
            }
            
            // Используем асинхронный метод для получения токена и создания запроса
            using var request = await CreateAuthorizedRequestWithAcceptAsync(method, endpoint, cancellationToken).ConfigureAwait(false);
            
            if (requestBody != null && (method == HttpMethod.Post || method == HttpMethod.Put || method == HttpMethod.Patch))
            {
                request.Content = JsonContent.Create(requestBody);
                
                if (Logger.IsEnabled(LogLevel.Trace))
                {
                    var bodySize = request.Content.Headers.ContentLength ?? 0;
                    Logger.LogTrace("Request body size: {Size} bytes for {Method} {Endpoint}", bodySize, method, endpoint);
                }
            }
            
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await ReadErrorContentAsync(response, cancellationToken).ConfigureAwait(false);
                
                // Записываем метрику ошибки
                RecordHttpRequest(method.Method, endpoint, false);
                RecordError($"{method.Method}.{endpoint}", response.StatusCode.ToString());
                
                if (Logger.IsEnabled(LogLevel.Warning))
                {
                    Logger.LogWarning("Ошибка выполнения запроса {Method} {Endpoint}: {StatusCode} - {ErrorContent}", 
                        method, endpoint, response.StatusCode, errorContent);
                }
                
                if (errorStrategy == ErrorHandlingStrategy.ThrowException)
                {
                    throw new HttpRequestException($"Не удалось выполнить запрос: {response.StatusCode} - {errorContent}");
                }
                
                return Result<T>.FromHttpError(response.StatusCode, errorContent);
            }
            
            // Записываем метрику успешного запроса
            RecordHttpRequest(method.Method, endpoint, true);
            
            // Проверка размера ответа перед чтением
            var contentLength = response.Content?.Headers.ContentLength;
            if (contentLength.HasValue && contentLength.Value > MaxJsonContentSizeBytes)
            {
                Logger.LogError("Response content size ({Size} bytes) exceeds maximum allowed size ({MaxSize} bytes) for {Endpoint}",
                    contentLength.Value, MaxJsonContentSizeBytes, endpoint);
                throw new InvalidOperationException($"Response content too large: {contentLength.Value} bytes");
            }
            
            if (response.Content == null)
            {
                Logger.LogWarning("Response.Content is null для {Method} {Endpoint}", method, endpoint);
                return errorStrategy switch
                {
                    ErrorHandlingStrategy.ReturnEmpty => Result<T>.Success(default(T)!), // Используем null для reference types
                    ErrorHandlingStrategy.ReturnNull => Result<T>.Failure("Response content is null"),
                    _ => Result<T>.Failure("Response content is null")
                };
            }
            
            var content = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            if (string.IsNullOrWhiteSpace(content))
            {
                if (Logger.IsEnabled(LogLevel.Debug))
                {
                    Logger.LogDebug("Empty response content for {Method} {Endpoint}", method, endpoint);
                }
                return errorStrategy switch
                {
                    ErrorHandlingStrategy.ReturnEmpty => Result<T>.Success(default(T)!), // Используем null для reference types
                    ErrorHandlingStrategy.ReturnNull => Result<T>.Failure("Empty response content"),
                    _ => Result<T>.Failure("Empty response content")
                };
            }
            
            try
            {
                var result = JsonSerializer.Deserialize<T>(content, DefaultJsonOptions);
                if (result == null)
                {
                    Logger.LogWarning("Deserialization returned null for {Method} {Endpoint}", method, endpoint);
                    return errorStrategy switch
                    {
                        ErrorHandlingStrategy.ReturnEmpty => Result<T>.Success(default(T)!), // Используем null для reference types
                        ErrorHandlingStrategy.ReturnNull => Result<T>.Failure("Deserialization returned null"),
                        _ => Result<T>.Failure("Deserialization returned null")
                    };
                }
                
                if (Logger.IsEnabled(LogLevel.Debug))
                {
                    Logger.LogDebug("Успешно выполнен запрос {Method} {Endpoint} за {ElapsedMs}ms", 
                        method, endpoint, stopwatch.ElapsedMilliseconds);
                }
                
                return Result<T>.Success(result);
            }
            catch (JsonException ex)
            {
                Logger.LogError(ex, "Ошибка десериализации для {Method} {Endpoint}. Content length: {ContentLength}", 
                    method, endpoint, content.Length);
                
                if (Logger.IsEnabled(LogLevel.Trace))
                {
                    var contentPreview = content.Length > MaxContentLengthForLogging 
                        ? string.Concat(content.AsSpan(0, MaxContentLengthForLogging), "...") 
                        : content;
                    Logger.LogTrace("Content preview: {Content}", contentPreview);
                }
                
                return Result<T>.Failure($"Ошибка десериализации: {ex.Message}", ex);
            }
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при выполнении запроса {Method} {Endpoint} за {ElapsedMs}ms", 
                method, endpoint, stopwatch.ElapsedMilliseconds);
            throw;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция {Method} {Endpoint} была отменена (TaskCanceledException)", method, endpoint);
            throw;
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning("Операция {Method} {Endpoint} была отменена", method, endpoint);
            throw;
        }
        catch (HttpRequestException)
        {
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при выполнении запроса {Method} {Endpoint}", method, endpoint);
            if (errorStrategy == ErrorHandlingStrategy.ThrowException)
            {
                throw;
            }
            return Result<T>.Failure($"Неожиданная ошибка: {ex.Message}", ex);
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Выполняет HTTP запрос для получения списка объектов
    /// </summary>
    protected async Task<Result<List<T>>> GetListAsync<T>(
        string endpoint,
        CancellationToken cancellationToken = default)
        where T : class
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        if (Logger.IsEnabled(LogLevel.Debug))
        {
            Logger.LogDebug("Получение списка {Type} из {Endpoint}", typeof(T).Name, endpoint);
        }
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot get list from {Endpoint}", endpoint);
            return Result<List<T>>.Success(new List<T>());
        }
        
        try
        {
            if (!ValidateEndpoint(endpoint, out var endpointError))
            {
                Logger.LogError("Invalid endpoint: {EndpointError}", endpointError);
                return Result<List<T>>.Success(new List<T>());
            }
            
            // Используем асинхронный метод для получения токена и создания запроса
            using var request = await CreateAuthorizedRequestWithAcceptAsync(HttpMethod.Get, endpoint, cancellationToken).ConfigureAwait(false);
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            
            // Проверка размера ответа перед чтением
            var contentLength = response.Content?.Headers.ContentLength;
            if (contentLength.HasValue && contentLength.Value > MaxJsonContentSizeBytes)
            {
                Logger.LogError("Response content size ({Size} bytes) exceeds maximum allowed size ({MaxSize} bytes) for {Endpoint}",
                    contentLength.Value, MaxJsonContentSizeBytes, endpoint);
                return Result<List<T>>.Success(new List<T>());
            }
            
            if (!response.IsSuccessStatusCode)
            {
                if (Logger.IsEnabled(LogLevel.Warning))
                {
                    Logger.LogWarning("Ошибка получения списка {Type} из {Endpoint}: {StatusCode}", 
                        typeof(T).Name, endpoint, response.StatusCode);
                }
                return Result<List<T>>.Success(new List<T>());
            }
            
            if (response.Content == null)
            {
                Logger.LogWarning("Response.Content is null для {Endpoint}", endpoint);
                return Result<List<T>>.Success(new List<T>());
            }
            
            var content = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            if (string.IsNullOrWhiteSpace(content))
            {
                if (Logger.IsEnabled(LogLevel.Debug))
                {
                    Logger.LogDebug("Empty response content for {Endpoint}", endpoint);
                }
                return Result<List<T>>.Success(new List<T>());
            }
            
            try
            {
                var result = JsonSerializer.Deserialize<List<T>>(content, DefaultJsonOptions);
                var list = result ?? new List<T>();
                
                if (Logger.IsEnabled(LogLevel.Debug))
                {
                    Logger.LogDebug("Получено {Count} элементов типа {Type} из {Endpoint} за {ElapsedMs}ms", 
                        list.Count, typeof(T).Name, endpoint, stopwatch.ElapsedMilliseconds);
                }
                
                return Result<List<T>>.Success(list);
            }
            catch (JsonException ex)
            {
                Logger.LogError(ex, "Ошибка десериализации списка {Type} для {Endpoint}. Content length: {ContentLength}", 
                    typeof(T).Name, endpoint, content.Length);
                
                if (Logger.IsEnabled(LogLevel.Trace))
                {
                    var contentPreview = content.Length > MaxContentLengthForLogging 
                        ? string.Concat(content.AsSpan(0, MaxContentLengthForLogging), "...") 
                        : content;
                    Logger.LogTrace("Content preview: {Content}", contentPreview);
                }
                
                return Result<List<T>>.Success(new List<T>());
            }
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при получении списка {Type} из {Endpoint} за {ElapsedMs}ms", 
                typeof(T).Name, endpoint, stopwatch.ElapsedMilliseconds);
            throw;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция получения списка {Type} из {Endpoint} была отменена (TaskCanceledException)", 
                typeof(T).Name, endpoint);
            throw;
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning("Операция получения списка {Type} из {Endpoint} была отменена", 
                typeof(T).Name, endpoint);
            throw;
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, "HTTP ошибка при получении списка {Type} из {Endpoint}", 
                typeof(T).Name, endpoint);
            return Result<List<T>>.Success(new List<T>());
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при получении списка {Type} из {Endpoint}", 
                typeof(T).Name, endpoint);
            return Result<List<T>>.Success(new List<T>());
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Выполняет HTTP запрос для операций без возвращаемого значения (POST, PUT, DELETE)
    /// </summary>
    protected async Task<Result> ExecuteOperationAsync(
        string endpoint,
        HttpMethod method,
        object? requestBody = null,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation");
            return Result.Failure("Semaphore disposed");
        }
        
        try
        {
            if (!ValidateEndpoint(endpoint, out var endpointError))
            {
                Logger.LogError(endpointError);
                return Result.Failure(endpointError ?? "Invalid endpoint");
            }
            
            using var request = await CreateAuthorizedRequestWithAcceptAsync(method, endpoint, cancellationToken).ConfigureAwait(false);
            
            if (requestBody != null)
            {
                request.Content = JsonContent.Create(requestBody);
            }
            
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await ReadErrorContentAsync(response, cancellationToken).ConfigureAwait(false);
                Logger.LogError("Ошибка выполнения операции {Method} {Endpoint}: {StatusCode} - {ErrorContent}", 
                    method, endpoint, response.StatusCode, errorContent);
                throw new HttpRequestException($"Не удалось выполнить операцию: {response.StatusCode} - {errorContent}");
            }
            
            return Result.Success();
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при выполнении операции {Method} {Endpoint}", method, endpoint);
            throw;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция {Method} {Endpoint} была отменена (TaskCanceledException)", method, endpoint);
            throw;
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning("Операция {Method} {Endpoint} была отменена", method, endpoint);
            throw;
        }
        catch (HttpRequestException)
        {
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при выполнении операции {Method} {Endpoint}", method, endpoint);
            throw;
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    #endregion
    
        private readonly IKeycloakClientRolesClient _clientRolesClient;
        private readonly IKeycloakRealmRolesClient _realmRolesClient;
        private readonly IKeycloakRoleMappingClient _roleMappingClient;
        private readonly IKeycloakRoleBatchOperationsClient _batchOperationsClient;
    
    /// <summary>
    /// Facade клиент для работы с ролями Keycloak
    /// Делегирует вызовы в специализированные клиенты, которые должны быть зарегистрированы в DI контейнере
    /// </summary>
    public KeycloakRolesClient(
        System.Net.Http.HttpClient httpClient,
        new_assistant.Configuration.KeycloakAdminSettings settings,
        ILogger logger,
        new_assistant.Core.Interfaces.IKeycloakCacheService cacheService,
        new_assistant.Core.Interfaces.IPerformanceMetricsService metricsService,
        IKeycloakClientRolesClient clientRolesClient,
        IKeycloakRealmRolesClient realmRolesClient,
        IKeycloakRoleMappingClient roleMappingClient,
        IKeycloakRoleBatchOperationsClient batchOperationsClient)
        : base(httpClient, settings, logger, cacheService, metricsService)
    {
        _clientRolesClient = clientRolesClient ?? throw new ArgumentNullException(nameof(clientRolesClient));
        _realmRolesClient = realmRolesClient ?? throw new ArgumentNullException(nameof(realmRolesClient));
        _roleMappingClient = roleMappingClient ?? throw new ArgumentNullException(nameof(roleMappingClient));
        _batchOperationsClient = batchOperationsClient ?? throw new ArgumentNullException(nameof(batchOperationsClient));
    }
    
    /// <summary>
    /// Получение ролей клиента
    /// </summary>
    public Task<List<KeycloakRoleDto>> GetClientRolesAsync(string realm, string clientInternalId, CancellationToken cancellationToken = default)
    {
        return _clientRolesClient.GetClientRolesAsync(realm, clientInternalId, cancellationToken);
    }
    
    /// <summary>
    /// Получение client scopes клиента (default или optional)
    /// </summary>
    public Task<List<string>> GetClientScopesAsync(string realm, string clientInternalId, bool isDefault, CancellationToken cancellationToken = default)
    {
        return _clientRolesClient.GetClientScopesAsync(realm, clientInternalId, isDefault, cancellationToken);
    }
    
    /// <summary>
    /// Получение service account пользователя для клиента
    /// </summary>
    public Task<string?> GetServiceAccountUserIdAsync(string realm, string clientInternalId, CancellationToken cancellationToken = default)
    {
        return _clientRolesClient.GetServiceAccountUserIdAsync(realm, clientInternalId, cancellationToken);
    }
    
    /// <summary>
    /// Создать роль клиента
    /// </summary>
    public Task CreateClientRoleAsync(string realm, string clientInternalId, string roleName, string? description = null, CancellationToken cancellationToken = default)
    {
        return _clientRolesClient.CreateClientRoleAsync(realm, clientInternalId, roleName, description, cancellationToken);
    }

    /// <summary>
    /// Удалить роль клиента
    /// </summary>
    public Task DeleteClientRoleAsync(string realm, string clientInternalId, string roleName, CancellationToken cancellationToken = default)
    {
        return _clientRolesClient.DeleteClientRoleAsync(realm, clientInternalId, roleName, cancellationToken);
    }

    /// <summary>
    /// Получить доступные realm роли для назначения пользователю
    /// </summary>
    public Task<List<KeycloakRoleDto>> GetAvailableRealmRolesAsync(string realm, CancellationToken cancellationToken = default)
    {
        return _realmRolesClient.GetAvailableRealmRolesAsync(realm, cancellationToken);
    }
    
    /// <summary>
    /// Получить доступные роли для назначения пользователю (через ui-ext endpoint, оптимизированный метод)
    /// </summary>
    public Task<List<KeycloakRoleDto>> GetAvailableRolesForUserAsync(
        string realm, 
        string userId, 
        string searchTerm = "", 
        int first = 0, 
        int? max = null, 
        CancellationToken cancellationToken = default)
    {
        return _realmRolesClient.GetAvailableRolesForUserAsync(realm, userId, searchTerm, first, max, cancellationToken);
    }
    
    /// <summary>
    /// Получить все доступные роли для пользователя (с автоматической пагинацией)
    /// </summary>
    public Task<List<KeycloakRoleDto>> GetAllAvailableRolesForUserAsync(
        string realm, 
        string userId, 
        string searchTerm = "", 
        CancellationToken cancellationToken = default)
    {
        return _realmRolesClient.GetAllAvailableRolesForUserAsync(realm, userId, searchTerm, cancellationToken);
    }
    
    // ========================================================================
    // Методы Role Mapping - делегируются в KeycloakRoleMappingClient
    // ========================================================================
    
    /// <summary>
    /// Получение role mappings для пользователя
    /// </summary>
    public Task<List<KeycloakClientRoleDto>> GetUserRoleMappingsAsync(string realm, string userId, CancellationToken cancellationToken = default)
    {
        return _roleMappingClient.GetUserRoleMappingsAsync(realm, userId, cancellationToken);
    }
    
    /// <summary>
    /// Получить роли клиента для пользователя
    /// </summary>
    public Task<List<string>> GetUserClientRolesAsync(string realm, string userId, string clientUuid, CancellationToken cancellationToken = default)
    {
        return _roleMappingClient.GetUserClientRolesAsync(realm, userId, clientUuid, cancellationToken);
    }
    
    /// <summary>
    /// Назначить realm роль пользователю
    /// </summary>
    public Task AssignRealmRoleToUserAsync(string realm, string userId, string roleName, CancellationToken cancellationToken = default)
    {
        return _roleMappingClient.AssignRealmRoleToUserAsync(realm, userId, roleName, cancellationToken);
    }
    
    /// <summary>
    /// Удалить любую роль у пользователя (realm или client role)
    /// </summary>
    public Task RemoveRoleFromUserAsync(string realm, string userId, string roleName, CancellationToken cancellationToken = default)
    {
        return _roleMappingClient.RemoveRoleFromUserAsync(realm, userId, roleName, cancellationToken);
    }
    
    /// <summary>
    /// Назначает client роль пользователю
    /// </summary>
    public Task AssignClientRoleToUserAsync(string realm, string userId, string clientInternalId, string roleId, string roleName, CancellationToken cancellationToken = default)
    {
        return _roleMappingClient.AssignClientRoleToUserAsync(realm, userId, clientInternalId, roleId, roleName, cancellationToken);
    }
    
    /// <summary>
    /// Удаляет client роль у пользователя
    /// </summary>
    public Task RemoveClientRoleFromUserAsync(string realm, string userId, string clientInternalId, string roleId, string roleName, CancellationToken cancellationToken = default)
    {
        return _roleMappingClient.RemoveClientRoleFromUserAsync(realm, userId, clientInternalId, roleId, roleName, cancellationToken);
    }
    
    // ========================================================================
    // Batch операции - делегируются в KeycloakRoleBatchOperationsClient
    // ========================================================================
    
    /// <summary>
    /// Назначить несколько realm ролей пользователю одним запросом (batch)
    /// </summary>
    public Task AssignMultipleRealmRolesToUserAsync(string realm, string userId, IReadOnlyList<string> roleNames, CancellationToken cancellationToken = default)
    {
        return _batchOperationsClient.AssignMultipleRealmRolesToUserAsync(realm, userId, roleNames, cancellationToken);
    }
    
    /// <summary>
    /// Назначить несколько client ролей пользователю одним запросом (batch)
    /// </summary>
    public Task AssignMultipleClientRolesToUserAsync(string realm, string userId, string clientInternalId, 
        IReadOnlyList<(string roleId, string roleName)> roles, CancellationToken cancellationToken = default)
    {
        return _batchOperationsClient.AssignMultipleClientRolesToUserAsync(realm, userId, clientInternalId, roles, cancellationToken);
    }
    
    /// <summary>
    /// Удалить несколько client ролей у пользователя одним запросом (batch)
    /// </summary>
    public Task RemoveMultipleClientRolesFromUserAsync(string realm, string userId, string clientInternalId, 
        IReadOnlyList<(string roleId, string roleName)> roles, CancellationToken cancellationToken = default)
    {
        return _batchOperationsClient.RemoveMultipleClientRolesFromUserAsync(realm, userId, clientInternalId, roles, cancellationToken);
    }
    
    /// <summary>
    /// Удалить несколько realm ролей у пользователя одним запросом (batch)
    /// </summary>
    public Task RemoveMultipleRealmRolesFromUserAsync(string realm, string userId, IReadOnlyList<string> roleNames, CancellationToken cancellationToken = default)
    {
        return _batchOperationsClient.RemoveMultipleRealmRolesFromUserAsync(realm, userId, roleNames, cancellationToken);
    }
}

