using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using new_assistant.Core.DTOs;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services.Keycloak;

/// <summary>
/// Клиент для работы с клиентами Keycloak
/// </summary>
public class KeycloakClientsClient : KeycloakHttpClientBase
{
    // Константы для валидации параметров
    // MaxRealmLength, MaxEndpointLength, MaxContentLengthForLogging, MaxClientIdLength наследуются из базового класса
    private const int MaxSearchTermLength = 200;
    private const int MaxInternalIdLength = 200;
    private const int MaxContentLength = 10 * 1024 * 1024; // 10 MB
    private const int MaxNameLength = 500;
    private const int MaxDescriptionLength = 1000;
    
    // Ограничение количества реалмов для параллельного поиска (оптимизация памяти)
    // Если реалмов слишком много, обрабатываем их частями
    // Исправление проблемы #22: вынесено в именованную константу с комментарием
    // Значение 20 выбрано эмпирически для баланса между производительностью и потреблением памяти
    private const int MaxRealmsForParallelSearch = 20;
    
    // Используем JsonSerializerOptions из базового класса (исправление проблемы #6)
    private static JsonSerializerOptions DefaultJsonOptions => KeycloakHttpClientBase.DefaultJsonSerializerOptions;
    private static JsonSerializerOptions SerializeJsonOptions => KeycloakHttpClientBase.SerializeJsonSerializerOptions;
    
    // Статические пустые списки для переиспользования (оптимизация производительности)
    // ВАЖНО: Эти списки используются ТОЛЬКО для чтения (возврата из методов).
    // Они никогда не изменяются в коде, что обеспечивает thread-safety.
    // Для полной thread-safety можно использовать Array.Empty<T>().ToList().AsReadOnly(),
    // но текущая реализация безопасна, так как списки используются только для чтения.
    private static readonly List<JsonElement> EmptyJsonElementList = new();
    private static readonly List<ClientSearchResult> EmptyClientSearchResultList = new();
    private static readonly List<Controllers.ClientSearchResult> EmptyControllersClientSearchResultList = new();
    
    /// <summary>
    /// Выполняет HTTP-запрос к Keycloak API и возвращает десериализованный список клиентов
    /// </summary>
    private async Task<List<JsonElement>> ExecuteClientsSearchRequestAsync(
        string endpoint,
        string realm,
        CancellationToken cancellationToken)
    {
        try
        {
            using var request = await CreateAuthorizedRequestAsync(HttpMethod.Get, endpoint, cancellationToken).ConfigureAwait(false);
            
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            
            // Унифицированная проверка response == null через ValidateResponse
            // Для методов поиска возвращаем пустой список вместо исключения
            if (response == null)
            {
                Logger.LogError("HttpClient.SendAsync returned null response");
                return EmptyJsonElementList;
            }
            
            if (!response.IsSuccessStatusCode)
            {
                // Выносим объявление reasonPhrase на уровень выше для устранения дублирования
                var reasonPhrase = response.ReasonPhrase ?? "Unknown";
                
                if (response.StatusCode == HttpStatusCode.NotFound)
                {
                    // Реалм не найден - это нормально, просто возвращаем пустой список
                    Logger.LogDebug("Реалм {Realm} не найден при поиске клиентов", realm);
                    return EmptyJsonElementList;
                }
                
                // Критические ошибки авторизации логируем как Error
                if (response.StatusCode == HttpStatusCode.Unauthorized || 
                    response.StatusCode == HttpStatusCode.Forbidden)
                {
                    Logger.LogError("Ошибка авторизации при поиске в реалме {Realm}: {StatusCode} {ReasonPhrase}", 
                        realm, response.StatusCode, reasonPhrase);
                    return EmptyJsonElementList;
                }
                
                // Для 5xx ошибок пробрасываем исключение, так как это критическая ошибка сервера
                if ((int)response.StatusCode >= 500)
                {
                    Logger.LogError("Критическая ошибка сервера при поиске в реалме {Realm}: {StatusCode} {ReasonPhrase}", 
                        realm, response.StatusCode, reasonPhrase);
                    throw new HttpRequestException($"Server error when searching clients in realm {realm}: {response.StatusCode}");
                }
                
                // Для других ошибок логируем как предупреждение, но все равно возвращаем пустой список
                // (для методов поиска это приемлемое поведение)
                Logger.LogWarning("Ошибка поиска в реалме {Realm}: {StatusCode} {ReasonPhrase}", 
                    realm, response.StatusCode, reasonPhrase);
                return EmptyJsonElementList;
            }
            
            // Используем ReadResponseContentAsync для чтения и валидации контента
            var content = await ReadResponseContentAsync(response, cancellationToken).ConfigureAwait(false);
            
            if (string.IsNullOrEmpty(content))
            {
                return EmptyJsonElementList;
            }
            
            try
            {
                return JsonSerializer.Deserialize<List<JsonElement>>(content, DefaultJsonOptions) 
                    ?? EmptyJsonElementList;
            }
            catch (JsonException ex)
            {
                Logger.LogError(ex, "Ошибка десериализации JSON при поиске клиентов. Content: {Content}", 
                    TruncateForLogging(content, MaxContentLengthForLogging));
                return EmptyJsonElementList;
            }
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при поиске клиентов в реалме {Realm}", realm);
            return EmptyJsonElementList;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция поиска клиентов была отменена (TaskCanceledException)");
            return EmptyJsonElementList;
        }
        catch (OperationCanceledException)
        {
            return EmptyJsonElementList;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при поиске клиентов в реалме {Realm}", realm);
            return EmptyJsonElementList;
        }
    }
    
    public KeycloakClientsClient(
        System.Net.Http.HttpClient httpClient,
        new_assistant.Configuration.KeycloakAdminSettings settings,
        ILogger logger,
        new_assistant.Core.Interfaces.IKeycloakCacheService cacheService,
        new_assistant.Core.Interfaces.IPerformanceMetricsService metricsService)
        : base(httpClient, settings, logger, cacheService, metricsService)
    {
        // settings уже проверен в базовом классе
        
        if (settings.MaxSearchResults <= 0 || settings.MaxSearchResults > 1000)
        {
            throw new ArgumentException(
                $"MaxSearchResults must be between 1 and 1000, but was {settings.MaxSearchResults}", 
                nameof(settings));
        }
    }
    
    // Используем KeycloakParameterValidator для унификации валидации (исправление проблемы #2)
    // Все методы валидации удалены и заменены на использование KeycloakParameterValidator
    
    /// <summary>
    /// Валидация endpoint (исправление проблемы #10)
    /// Использует whitelist подход для безопасности
    /// </summary>
    private void ValidateEndpoint(string endpoint)
    {
        if (string.IsNullOrEmpty(endpoint))
            throw new InvalidOperationException("Endpoint cannot be null or empty");
        
        if (endpoint.Length > MaxEndpointLength)
            throw new InvalidOperationException($"Endpoint length ({endpoint.Length}) exceeds maximum allowed length ({MaxEndpointLength})");
        
        // Дополнительные проверки безопасности
        if (endpoint.Contains("..") || endpoint.Contains("//"))
            throw new InvalidOperationException("Endpoint contains invalid path sequences");
        
        // Защита от абсолютных URL
        if (Uri.TryCreate(endpoint, UriKind.Absolute, out _))
            throw new InvalidOperationException("Endpoint must be relative, not absolute");
        
        if (!Uri.IsWellFormedUriString(endpoint, UriKind.Relative))
            throw new InvalidOperationException($"Invalid endpoint format: {endpoint}");
    }
    
    /// <summary>
    /// Обрезка строки для логирования с использованием AsSpan для оптимизации
    /// </summary>
    private static string TruncateForLogging(string? text, int maxLength)
    {
        if (text == null)
            return string.Empty;
        
        if (text.Length <= maxLength)
            return text;
        
        return string.Concat(text.AsSpan(0, maxLength), "...");
    }
    
    /// <summary>
    /// Обрезка строки до указанной длины без добавления суффикса (для данных)
    /// </summary>
    private static string TruncateString(string? text, int maxLength)
    {
        if (text == null)
            return string.Empty;
        
        if (text.Length <= maxLength)
            return text;
        
        return new string(text.AsSpan(0, maxLength));
    }
    
    /// <summary>
    /// Извлечение значения enabled из JsonElement с безопасной обработкой типов
    /// </summary>
    /// <param name="element">JsonElement для извлечения значения enabled</param>
    /// <param name="defaultValue">Значение по умолчанию, если свойство отсутствует или невалидно</param>
    /// <returns>Значение enabled (true/false)</returns>
    private static bool ExtractEnabledValue(JsonElement element, bool defaultValue = true)
    {
        if (!element.TryGetProperty("enabled", out var enabledProp))
            return defaultValue;
        
        if (enabledProp.ValueKind == JsonValueKind.True)
            return true;
        
        if (enabledProp.ValueKind == JsonValueKind.False)
            return false;
        
        // Для других типов пытаемся получить boolean
        try
        {
            return enabledProp.GetBoolean();
        }
        catch
        {
            // Если не удалось получить boolean, используем значение по умолчанию
            return defaultValue;
        }
    }
    
    /// <summary>
    /// Выполнение операции с унифицированной обработкой исключений
    /// </summary>
    /// <remarks>
    /// TODO: Применить к методам для унификации обработки исключений и устранения дублирования кода.
    /// В настоящее время метод создан, но не используется, так как требует рефакторинга всех публичных методов.
    /// </remarks>
    private async Task<T> ExecuteWithExceptionHandlingAsync<T>(
        Func<CancellationToken, Task<T>> operation,
        string operationName,
        string? contextId,
        CancellationToken cancellationToken,
        T defaultValue,
        bool throwOnException = false)
    {
        try
        {
            return await operation(cancellationToken).ConfigureAwait(false);
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            if (string.IsNullOrEmpty(contextId))
                Logger.LogError("Timeout при {OperationName}", operationName);
            else
                Logger.LogError("Timeout при {OperationName} {ContextId}", operationName, contextId);
            throw;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция {OperationName} была отменена (TaskCanceledException)", operationName);
            throw;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (HttpRequestException)
        {
            throw;
        }
        catch (Exception ex)
        {
            if (string.IsNullOrEmpty(contextId))
                Logger.LogError(ex, "Неожиданная ошибка при {OperationName}", operationName);
            else
                Logger.LogError(ex, "Неожиданная ошибка при {OperationName} {ContextId}", operationName, contextId);
            
            if (throwOnException)
                throw new HttpRequestException($"Неожиданная ошибка при {operationName}: {ex.Message}", ex);
            
            return defaultValue;
        }
    }
    
    /// <summary>
    /// Валидация HTTP-ответа (проверка на null)
    /// </summary>
    private void ValidateResponse(HttpResponseMessage response)
    {
        if (response == null)
        {
            // Logger инициализируется в конструкторе базового класса и не может быть null
            // Но для дополнительной защиты можно использовать null-conditional operator,
            // хотя это избыточно и может скрыть реальные проблемы
            Logger.LogError("HttpClient.SendAsync returned null response");
            throw new HttpRequestException("HttpClient.SendAsync returned null response");
        }
    }
    
    /// <summary>
    /// Чтение и валидация содержимого HTTP-ответа
    /// </summary>
    private async Task<string> ReadResponseContentAsync(
        HttpResponseMessage response, 
        CancellationToken cancellationToken)
    {
        if (response == null)
        {
            Logger.LogError("HttpClient.SendAsync returned null response");
            return string.Empty;
        }
        
        if (!response.IsSuccessStatusCode)
        {
            var reasonPhrase = response.ReasonPhrase ?? "Unknown";
            Logger.LogWarning("HTTP request failed: {StatusCode} {ReasonPhrase}", 
                response.StatusCode, reasonPhrase);
            return string.Empty;
        }
        
        if (response.Content == null)
        {
            Logger.LogWarning("Response.Content is null");
            return string.Empty;
        }
        
        // Проверяем Content-Length header перед чтением контента (оптимизация для больших ответов)
        if (response.Content.Headers?.ContentLength.HasValue == true)
        {
            var contentLength = response.Content.Headers.ContentLength.Value;
            if (contentLength > MaxContentLength)
            {
                Logger.LogWarning("Response content length ({ContentLength}) exceeds maximum allowed length ({MaxLength})", 
                    contentLength, MaxContentLength);
                return string.Empty;
            }
        }
        
        // response.Content уже проверен на null выше, поэтому безопасно использовать
        var content = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
        
        if (string.IsNullOrWhiteSpace(content))
            return string.Empty;
        
        // Fallback проверка после чтения (на случай, если Content-Length не был предоставлен)
        if (content.Length > MaxContentLength)
        {
            Logger.LogWarning("Response content length ({ContentLength}) exceeds maximum allowed length ({MaxLength})", 
                content.Length, MaxContentLength);
            return string.Empty;
        }
        
        return content;
    }
    
    /// <summary>
    /// Десериализация JSON списка из HTTP-ответа
    /// </summary>
    private async Task<List<JsonElement>?> DeserializeJsonListAsync(
        HttpResponseMessage response,
        string operationContext,
        CancellationToken cancellationToken)
    {
        var content = await ReadResponseContentAsync(response, cancellationToken).ConfigureAwait(false);
        
        if (string.IsNullOrEmpty(content))
            return null;
        
        try
        {
            var result = JsonSerializer.Deserialize<List<JsonElement>>(content, DefaultJsonOptions);
            // Проверяем, что десериализованный список не пустой
            if (result == null || result.Count == 0)
                return null;
            return result;
        }
        catch (JsonException ex)
        {
            Logger.LogError(ex, "Ошибка десериализации JSON при {OperationContext}. Content: {Content}", 
                operationContext,
                TruncateForLogging(content, MaxContentLengthForLogging));
            return null;
        }
    }
    
    // Константы для имен метрик (оптимизация производительности)
    private const string CreateClientMetric = "CreateClient";
    private const string UpdateClientMetric = "UpdateClient";
    private const string DeleteClientMetric = "DeleteClient";
    
    /// <summary>
    /// Нормализация имени операции для метрик (удаление пробелов)
    /// </summary>
    private static string NormalizeMetricName(string operationName)
    {
        if (string.IsNullOrEmpty(operationName))
            return "Unknown";
        
        return operationName.Replace(" ", "", StringComparison.Ordinal);
    }
    
    /// <summary>
    /// Обработка ошибок HTTP-ответа
    /// </summary>
    /// <remarks>
    /// Упрощенная логика обработки ошибок: формирование сообщений об ошибках вынесено в отдельные переменные
    /// для улучшения читаемости и поддержки кода.
    /// </remarks>
    private async Task HandleHttpErrorAsync(
        HttpResponseMessage response,
        string operationName,
        string contextId,
        CancellationToken cancellationToken,
        long? elapsedMilliseconds = null)
    {
        // Оптимизация: нормализуем имя операции один раз
        var metricName = NormalizeMetricName(operationName);
        
        if (response.Content == null)
        {
            // Упрощенная логика: формируем сообщение об ошибке в одной переменной
            var message = string.IsNullOrEmpty(contextId)
                ? $"Ошибка {operationName}: {response.StatusCode}"
                : $"Ошибка {operationName} {contextId}: {response.StatusCode}";
            
            if (elapsedMilliseconds.HasValue)
                message += $" - {elapsedMilliseconds.Value}мс";
            
            Logger.LogError("{Message} - Response.Content is null", message);
            RecordError(metricName, "NoContent");
            throw new HttpRequestException($"Ошибка {operationName}: {response.StatusCode}");
        }
        
        var errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
        var truncatedError = TruncateForLogging(errorContent, MaxContentLengthForLogging);
        
        // Упрощенная логика: формируем сообщение для логирования в одной переменной
        var logMessage = string.IsNullOrEmpty(contextId)
            ? $"Ошибка {operationName}: {response.StatusCode} - {truncatedError}"
            : $"Ошибка {operationName} {contextId}: {response.StatusCode} - {truncatedError}";
        
        if (elapsedMilliseconds.HasValue)
            logMessage += $" - {elapsedMilliseconds.Value}мс";
        
        Logger.LogError(logMessage);
        RecordError(metricName, response.StatusCode.ToString());
        throw new HttpRequestException($"Ошибка {operationName}: {response.StatusCode} - {errorContent}");
    }
    
    /// <summary>
    /// Поиск клиентов в конкретном реалме
    /// </summary>
    /// <returns>Список найденных клиентов. Возвращает пустой список, если клиенты не найдены или произошла ошибка.</returns>
    /// <param name="cancellationToken">Токен отмены операции. CancellationToken - это структура, поэтому проверка на null не требуется. default(CancellationToken) является валидным значением.</param>
    public async Task<List<ClientSearchResult>> SearchClientsInRealmAsync(
        string realm, 
        string searchTerm, 
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров (исправление проблемы #2)
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateSearchTerm(searchTerm);
        
        // Settings.MaxSearchResults уже валидируется в конструкторе
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation");
            return EmptyClientSearchResultList;
        }
        try
        {
            // Keycloak Admin API endpoint для поиска клиентов по аналогии:
            // .../clients?first=0&max={Max}&clientId={term}&search=true
            // Uri.EscapeDataString безопасно кодирует searchTerm, предотвращая инъекции
            // ValidateSearchTerm уже ограничивает длину searchTerm, а ValidateEndpoint проверяет длину endpoint
            var encodedSearchTerm = Uri.EscapeDataString(searchTerm);
            
            // Проверяем, что закодированная строка не превышает разумный лимит
            // Uri.EscapeDataString может увеличить длину строки (кодирование специальных символов)
            if (encodedSearchTerm.Length > MaxSearchTermLength * 3)
            {
                throw new ArgumentException($"Encoded search term length ({encodedSearchTerm.Length}) exceeds maximum allowed length ({MaxSearchTermLength * 3})", nameof(searchTerm));
            }
            
            var endpoint = $"admin/realms/{realm}/clients?first=0&max={Settings.MaxSearchResults}&clientId={encodedSearchTerm}&search=true";
            
            ValidateEndpoint(endpoint);
            
            var clients = await ExecuteClientsSearchRequestAsync(endpoint, realm, cancellationToken).ConfigureAwait(false);
            
            // Keycloak API уже фильтрует по clientId с параметром search=true, поэтому локальная фильтрация не требуется
            // Это оптимизирует производительность, избегая двойной фильтрации
            // Оптимизация: используем foreach с предварительным размером вместо LINQ Select().ToList()
            var results = new List<ClientSearchResult>(clients.Count);
            foreach (var client in clients)
            {
                results.Add(ParseClientFromJson(client, realm));
            }
            
            Logger.LogInformation("Поиск клиентов {SearchTerm} в реалме {Realm} - {Time}мс, найдено: {Count}", 
                searchTerm, realm, stopwatch.ElapsedMilliseconds, results.Count);
            RecordSuccess("SearchClientsInRealm");
            
            return results;
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при поиске клиентов {SearchTerm} в реалме {Realm}", searchTerm, realm);
            throw;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция поиска клиентов была отменена (TaskCanceledException)");
            throw;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка поиска клиентов {SearchTerm} - {Time}мс", searchTerm, stopwatch.ElapsedMilliseconds);
            return EmptyClientSearchResultList;
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Создать нового клиента в Keycloak
    /// </summary>
    public async Task<string> CreateClientAsync(string realm, JsonElement clientData, CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров (исправление проблемы #2)
        KeycloakParameterValidator.ValidateRealm(realm);
        if (clientData.ValueKind == JsonValueKind.Null || clientData.ValueKind == JsonValueKind.Undefined)
        {
            throw new ArgumentException("Client data cannot be null or undefined", nameof(clientData));
        }
        
        // Проверить, что это объект, а не массив или примитив
        if (clientData.ValueKind != JsonValueKind.Object)
        {
            throw new ArgumentException($"Client data must be a JSON object, but was {clientData.ValueKind}", nameof(clientData));
        }
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation");
            throw new InvalidOperationException("Semaphore disposed, cannot execute create operation");
        }
        try
        {
            var endpoint = $"admin/realms/{realm}/clients";
            ValidateEndpoint(endpoint);

            string rawText;
            try
            {
                rawText = clientData.GetRawText();
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Ошибка при получении raw text из clientData");
                throw new ArgumentException("Failed to get raw text from client data", nameof(clientData), ex);
            }
            
            if (rawText.Length > MaxContentLength)
            {
                throw new ArgumentException($"Client data size ({rawText.Length}) exceeds maximum allowed length ({MaxContentLength})", nameof(clientData));
            }

            using var request = await CreateAuthorizedRequestAsync(HttpMethod.Post, endpoint, cancellationToken).ConfigureAwait(false);
            request.Content = new StringContent(rawText, Encoding.UTF8, "application/json");

            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            ValidateResponse(response);
            
            if (response.IsSuccessStatusCode)
            {
                // Получаем ID созданного клиента из заголовка Location
                var locationHeader = response.Headers.Location?.ToString();
                if (string.IsNullOrEmpty(locationHeader))
                {
                    Logger.LogInformation("Создание клиента (без Location header) - {Time}мс", stopwatch.ElapsedMilliseconds);
                    RecordSuccess("CreateClient");
                    return string.Empty;
                }
                
                // Валидация формата Location header
                if (!Uri.IsWellFormedUriString(locationHeader, UriKind.Absolute) && 
                    !Uri.IsWellFormedUriString(locationHeader, UriKind.Relative))
                {
                    var locationForLogging = TruncateForLogging(locationHeader, MaxContentLengthForLogging);
                    Logger.LogWarning("Location header имеет невалидный формат: {LocationHeader}", locationForLogging);
                    Logger.LogInformation("Создание клиента (без ID) - {Time}мс", stopwatch.ElapsedMilliseconds);
                    RecordSuccess("CreateClient");
                    return string.Empty;
                }
                
                // Извлекаем clientId из Location header (последний сегмент URL)
                var parts = locationHeader.Split('/', StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length == 0)
                {
                    var locationForLogging = TruncateForLogging(locationHeader, MaxContentLengthForLogging);
                    Logger.LogWarning("Location header не содержит сегментов: {LocationHeader}", locationForLogging);
                    Logger.LogInformation("Создание клиента (без ID) - {Time}мс", stopwatch.ElapsedMilliseconds);
                    RecordSuccess("CreateClient");
                    return string.Empty;
                }
                
                var clientId = parts[parts.Length - 1];
                if (string.IsNullOrEmpty(clientId))
                {
                    var locationForLogging = TruncateForLogging(locationHeader, MaxContentLengthForLogging);
                    Logger.LogWarning("Не удалось извлечь clientId из Location header: {LocationHeader}", locationForLogging);
                    Logger.LogInformation("Создание клиента (без ID) - {Time}мс", stopwatch.ElapsedMilliseconds);
                    RecordSuccess("CreateClient");
                    return string.Empty;
                }
                
                Logger.LogInformation("Создание клиента {ClientId} - {Time}мс", clientId, stopwatch.ElapsedMilliseconds);
                RecordSuccess("CreateClient");
                return clientId;
            }
            
            // Обработка ошибок
            // HandleHttpErrorAsync всегда выбрасывает исключение, поэтому код после него недостижим
            await HandleHttpErrorAsync(response, "создания клиента", "", cancellationToken, stopwatch.ElapsedMilliseconds).ConfigureAwait(false);
            // Этот код недостижим, так как HandleHttpErrorAsync всегда выбрасывает исключение
            return string.Empty; // Нужно для компилятора, но никогда не выполнится
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при создании клиента");
            throw;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция создания клиента была отменена (TaskCanceledException)");
            throw;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (HttpRequestException)
        {
            // Пробрасываем HttpRequestException дальше
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при создании клиента - {Time}мс", stopwatch.ElapsedMilliseconds);
            throw new HttpRequestException($"Неожиданная ошибка при создании клиента: {ex.Message}", ex);
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }

    /// <summary>
    /// Получение полной информации о клиенте по clientId
    /// </summary>
    /// <returns>JsonElement с данными клиента, если найден. Возвращает null, если клиент не найден или произошла ошибка.</returns>
    public async Task<JsonElement?> GetClientFullInfoAsync(string realm, string clientId, CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров (исправление проблемы #2)
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientId(clientId);
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation");
            return null;
        }
        try
        {
            // Сначала получаем список клиентов с фильтром по clientId
            // Uri.EscapeDataString безопасно кодирует clientId, предотвращая инъекции
            // ValidateClientId уже ограничивает длину clientId, а ValidateEndpoint проверяет длину endpoint
            var encodedClientId = Uri.EscapeDataString(clientId);
            
            // Проверяем, что закодированная строка не превышает разумный лимит
            if (encodedClientId.Length > MaxClientIdLength * 3)
            {
                throw new ArgumentException($"Encoded client ID length ({encodedClientId.Length}) exceeds maximum allowed length ({MaxClientIdLength * 3})", nameof(clientId));
            }
            
            var endpoint = $"admin/realms/{realm}/clients?clientId={encodedClientId}";
            ValidateEndpoint(endpoint);
            
            using var request = await CreateAuthorizedRequestAsync(HttpMethod.Get, endpoint, cancellationToken).ConfigureAwait(false);
            
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            
            // KeyCloak возвращает массив клиентов
            var clients = await DeserializeJsonListAsync(response, "получении информации о клиенте", cancellationToken).ConfigureAwait(false);
            
            if (clients == null || clients.Count == 0)
            {
                Logger.LogWarning("Клиент {ClientId} не найден в реалме {Realm}", clientId, realm);
                return null;
            }
            
            // ВАЖНО: Keycloak API с ?clientId= ищет по ЧАСТИЧНОМУ совпадению!
            // Нужно найти ТОЧНОЕ совпадение по clientId
            // Оптимизация: используем foreach вместо FirstOrDefault для раннего выхода
            JsonElement? exactMatch = null;
            foreach (var client in clients)
            {
                if (!client.TryGetProperty("clientId", out var clientIdProperty))
                    continue;
                
                var currentClientId = clientIdProperty.GetString();
                if (!string.IsNullOrEmpty(currentClientId) && currentClientId == clientId)
                {
                    exactMatch = client;
                    break; // Найдено точное совпадение, прекращаем поиск
                }
            }
            
            if (!exactMatch.HasValue || exactMatch.Value.ValueKind == JsonValueKind.Undefined)
            {
                Logger.LogWarning("Клиент с точным совпадением {ClientId} не найден в реалме {Realm}. Найдено клиентов: {Count}", 
                    clientId, realm, clients.Count);
                return null;
            }
            
            Logger.LogInformation("Получение информации о клиенте {ClientId} - {Time}мс", clientId, stopwatch.ElapsedMilliseconds);
            RecordSuccess("GetClientFullInfo");
            return exactMatch.Value;
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при получении информации о клиенте {ClientId}", clientId);
            throw;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция получения информации о клиенте была отменена (TaskCanceledException)");
            throw;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка получения информации о клиенте {ClientId} - {Time}мс", clientId, stopwatch.ElapsedMilliseconds);
            return null;
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }

    /// <summary>
    /// Обновить клиента в Keycloak
    /// </summary>
    public async Task UpdateClientAsync(string realm, string internalId, object clientData, CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров (исправление проблемы #2)
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientInternalId(internalId);
        if (clientData == null)
        {
            throw new ArgumentNullException(nameof(clientData));
        }
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation");
            throw new InvalidOperationException("Semaphore disposed, cannot execute update operation");
        }
        try
        {
            var endpoint = $"admin/realms/{realm}/clients/{internalId}";
            ValidateEndpoint(endpoint);

            using var request = await CreateAuthorizedRequestAsync(HttpMethod.Put, endpoint, cancellationToken).ConfigureAwait(false);
            // Accept header уже устанавливается в базовом классе через DefaultRequestHeaders

            string payloadJson;
            try
            {
                payloadJson = JsonSerializer.Serialize(clientData, SerializeJsonOptions);
            }
            catch (NotSupportedException ex)
            {
                Logger.LogError(ex, "Объект clientData не может быть сериализован в JSON");
                throw new ArgumentException("Client data cannot be serialized to JSON", nameof(clientData), ex);
            }
            catch (JsonException ex)
            {
                Logger.LogError(ex, "Ошибка сериализации clientData в JSON");
                throw new ArgumentException("Failed to serialize client data to JSON", nameof(clientData), ex);
            }
            
            if (payloadJson.Length > MaxContentLength)
            {
                throw new ArgumentException($"Client data size ({payloadJson.Length}) exceeds maximum allowed length ({MaxContentLength})", nameof(clientData));
            }
            
            // Обрезка payload для логирования (безопасность)
            var payloadForLogging = TruncateForLogging(payloadJson, MaxContentLengthForLogging);
            Logger.LogDebug("[KeycloakAdmin] UpdateClient payload: {Payload}", payloadForLogging);

            request.Content = new StringContent(payloadJson, Encoding.UTF8, "application/json");
            
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            ValidateResponse(response);
            
            if (!response.IsSuccessStatusCode)
            {
                await HandleHttpErrorAsync(response, "обновления клиента", internalId, cancellationToken, stopwatch.ElapsedMilliseconds).ConfigureAwait(false);
            }
            else
            {
                Logger.LogInformation("Обновление клиента {InternalId} - {Time}мс", internalId, stopwatch.ElapsedMilliseconds);
                RecordSuccess("UpdateClient");
            }
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при обновлении клиента {InternalId}", internalId);
            throw;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция обновления клиента была отменена (TaskCanceledException)");
            throw;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (HttpRequestException)
        {
            // Пробрасываем HttpRequestException дальше
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при обновлении клиента {InternalId}", internalId);
            throw new HttpRequestException($"Неожиданная ошибка при обновлении клиента: {ex.Message}", ex);
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }

    /// <summary>
    /// Удалить клиента из реалма
    /// </summary>
    public async Task DeleteClientAsync(string realm, string internalId, CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров (исправление проблемы #2)
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientInternalId(internalId);
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation");
            throw new InvalidOperationException("Semaphore disposed, cannot execute delete operation");
        }
        try
        {
            var endpoint = $"admin/realms/{realm}/clients/{internalId}";
            ValidateEndpoint(endpoint);

            using var request = await CreateAuthorizedRequestAsync(HttpMethod.Delete, endpoint, cancellationToken).ConfigureAwait(false);
            // Accept header уже устанавливается в базовом классе через DefaultRequestHeaders
            
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            ValidateResponse(response);
            
            if (!response.IsSuccessStatusCode)
            {
                await HandleHttpErrorAsync(response, "удаления клиента", internalId, cancellationToken, stopwatch.ElapsedMilliseconds).ConfigureAwait(false);
            }
            else
            {
                Logger.LogInformation("Удаление клиента {InternalId} - {Time}мс", internalId, stopwatch.ElapsedMilliseconds);
                RecordSuccess("DeleteClient");
            }
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при удалении клиента {InternalId}", internalId);
            throw;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция удаления клиента была отменена (TaskCanceledException)");
            throw;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (HttpRequestException)
        {
            // Пробрасываем HttpRequestException дальше
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при удалении клиента {InternalId}", internalId);
            throw new HttpRequestException($"Неожиданная ошибка при удалении клиента: {ex.Message}", ex);
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Получить всех клиентов реалма в виде JsonElement для доступа к Internal ID
    /// </summary>
    /// <returns>Список всех клиентов реалма. Возвращает пустой список, если клиенты не найдены или произошла ошибка.</returns>
    public async Task<List<JsonElement>> GetAllClientsAsJsonAsync(string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров (исправление проблемы #2)
        KeycloakParameterValidator.ValidateRealm(realm);
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot get clients for realm {Realm}", realm);
            return EmptyJsonElementList;
        }
        
        try
        {
            var endpoint = $"admin/realms/{realm}/clients";
            ValidateEndpoint(endpoint);
            
            using var request = await CreateAuthorizedRequestAsync(HttpMethod.Get, endpoint, cancellationToken).ConfigureAwait(false);
            
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            
            var clients = await DeserializeJsonListAsync(response, "получении клиентов", cancellationToken).ConfigureAwait(false);
            
            if (clients == null)
            {
                Logger.LogWarning("Response content is null or empty for realm {Realm}", realm);
                return EmptyJsonElementList;
            }
            
            Logger.LogInformation("Получение клиентов для реалма {Realm} - {Time}мс, найдено: {Count}", 
                realm, stopwatch.ElapsedMilliseconds, clients.Count);
            RecordSuccess("GetAllClientsAsJson");
            
            return clients;
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при получении клиентов для реалма {Realm}", realm);
            throw;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция получения клиентов была отменена (TaskCanceledException)");
            throw;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при получении клиентов для реалма {Realm}", realm);
            return EmptyJsonElementList;
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Поиск клиентов по Client ID (с опциональной фильтрацией по realm)
    /// </summary>
    public async Task<List<Controllers.ClientSearchResult>> SearchClientsByIdAsync(
        string searchTerm, 
        string? realm, 
        List<string>? realmsList = null,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        KeycloakParameterValidator.ValidateSearchTerm(searchTerm);
        
        // Settings.MaxSearchResults уже валидируется в конструкторе
        
        // Определяем реалмы для поиска
        List<string> realmsToSearch;
        if (!string.IsNullOrEmpty(realm))
        {
            KeycloakParameterValidator.ValidateRealm(realm);
            realmsToSearch = new List<string>(1) { realm };
        }
        else if (realmsList != null && realmsList.Count > 0)
        {
            // Валидируем все реалмы в списке
            var validRealms = new List<string>();
            foreach (var r in realmsList)
            {
                cancellationToken.ThrowIfCancellationRequested();
                
                if (string.IsNullOrWhiteSpace(r))
                {
                    Logger.LogWarning("Пропущен пустой или null realm в списке");
                    continue;
                }
                try
                {
                    KeycloakParameterValidator.ValidateRealm(r);
                    validRealms.Add(r);
                }
                catch (ArgumentException ex)
                {
                    Logger.LogWarning("Пропущен невалидный realm в списке: {Error}", ex.Message);
                }
            }
            
            if (validRealms.Count == 0)
            {
                throw new ArgumentException("RealmsList must contain at least one valid realm", nameof(realmsList));
            }
            
            realmsToSearch = validRealms;
        }
        else
        {
            throw new ArgumentException("Either realm or realmsList must be provided", nameof(realm));
        }
        
        // Консервативная оценка: половина от максимального для оптимизации памяти
        // Если реальное количество результатов больше, список будет расширяться динамически
        // Используем long для промежуточных вычислений, чтобы избежать переполнения
        var estimatedCapacity = (int)Math.Min((long)realmsToSearch.Count * Settings.MaxSearchResults / 2, 1000L);
        
        // Вычисляем maxTotalResults один раз для всех путей (батчинг и обычный) для консистентности
        // Исправление проблемы #37: проверка на переполнение при умножении
        long maxTotalResults;
        try
        {
            maxTotalResults = checked((long)Settings.MaxSearchResults * realmsToSearch.Count);
        }
        catch (OverflowException)
        {
            Logger.LogWarning("Переполнение при вычислении maxTotalResults. Используется int.MaxValue.");
            maxTotalResults = int.MaxValue;
        }
        
        if (maxTotalResults > int.MaxValue)
        {
            Logger.LogWarning("Максимальное количество результатов ({MaxTotalResults}) превышает int.MaxValue. Используется ограничение.", maxTotalResults);
            maxTotalResults = int.MaxValue;
        }
        
        List<Controllers.ClientSearchResult> results;
        
        if (realmsToSearch.Count > MaxRealmsForParallelSearch)
        {
            Logger.LogWarning("Количество реалмов ({Count}) превышает лимит для параллельного поиска ({Max}). Обработка будет выполнена частями.", 
                realmsToSearch.Count, MaxRealmsForParallelSearch);
            
            // Обрабатываем частями
            results = new List<Controllers.ClientSearchResult>(estimatedCapacity);
            for (int i = 0; i < realmsToSearch.Count; i += MaxRealmsForParallelSearch)
            {
                cancellationToken.ThrowIfCancellationRequested();
                
                // Оптимизация: используем цикл вместо Skip().Take().ToList() для избежания промежуточных коллекций
                var batch = new List<string>(MaxRealmsForParallelSearch);
                for (int j = i; j < Math.Min(i + MaxRealmsForParallelSearch, realmsToSearch.Count); j++)
                {
                    batch.Add(realmsToSearch[j]);
                }
                
                var batchTasks = batch.Select(realmName => 
                    SearchClientsInRealmByIdAsync(realmName, searchTerm, cancellationToken));
                
                var batchResults = await Task.WhenAll(batchTasks).ConfigureAwait(false);
                
                foreach (var realmResult in batchResults)
                {
                    if (realmResult == null) continue;
                    
                    // Проверка на переполнение при батчинге для консистентности с обычным путем
                    if (results.Count + realmResult.Count > (int)maxTotalResults)
                    {
                        var remaining = (int)maxTotalResults - results.Count;
                        if (remaining > 0)
                        {
                            results.AddRange(realmResult.Take(remaining));
                        }
                        Logger.LogWarning("Достигнут лимит результатов поиска при батчинге: {Count}", results.Count);
                        break;
                    }
                    
                    // Оптимизация: резервируем место для предотвращения переаллокаций
                    var newSize = results.Count + realmResult.Count;
                    if (newSize > results.Capacity)
                    {
                        var maxCapacity = (int)Math.Min(maxTotalResults, int.MaxValue);
                        results.Capacity = Math.Min(newSize * 2, maxCapacity);
                    }
                    
                    results.AddRange(realmResult);
                }
                
                // Проверка на достижение лимита после обработки батча
                if (results.Count >= (int)maxTotalResults)
                    break;
            }
        }
        else
        {
            // Параллельное выполнение запросов для всех реалмов с ограничением через semaphore
            // Semaphore уже ограничивает параллелизм, поэтому все задачи могут быть запущены одновременно
            results = new List<Controllers.ClientSearchResult>(estimatedCapacity);
            
            try
            {
                var tasks = realmsToSearch.Select(realmName => 
                    SearchClientsInRealmByIdAsync(realmName, searchTerm, cancellationToken));
            
                var realmResults = await Task.WhenAll(tasks).ConfigureAwait(false);
                
                // Проверяем, что хотя бы один реалм вернул результаты
                // Валидация на пустой список после Task.WhenAll для улучшения логирования
                if (realmResults.All(r => r == null || r.Count == 0))
                {
                    Logger.LogInformation("Клиенты с ID {SearchTerm} не найдены ни в одном из {Count} реалмов", 
                        searchTerm, realmsToSearch.Count);
                    return EmptyControllersClientSearchResultList;
                }
                
                // Объединяем результаты из всех реалмов
                // maxTotalResults уже вычислен на уровне выше для консистентности
                
                // Оптимизация проверки cancellation token (исправление проблемы #8)
                // Проверяем cancellation token реже - раз в N итераций для улучшения производительности
                const int CancellationCheckInterval = 10;
                int iterationCount = 0;
                
                foreach (var realmResult in realmResults)
                {
                    // Проверяем cancellation token раз в N итераций
                    if (++iterationCount % CancellationCheckInterval == 0)
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                    
                    if (realmResult == null)
                        continue;
                        
                    int clientIterationCount = 0;
                    foreach (var client in realmResult)
                    {
                        // Проверяем cancellation token раз в N итераций
                        if (++clientIterationCount % CancellationCheckInterval == 0)
                        {
                            cancellationToken.ThrowIfCancellationRequested();
                        }
                        
                        if (results.Count >= (int)maxTotalResults)
                        {
                            Logger.LogWarning("Достигнут лимит результатов поиска: {Count}", results.Count);
                            break;
                        }
                        results.Add(client);
                    }
                    
                    if (results.Count >= (int)maxTotalResults)
                        break;
                }
            }
            catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
            {
                Logger.LogError("Timeout при поиске клиентов по ID {SearchTerm}", searchTerm);
                throw;
            }
            catch (TaskCanceledException)
            {
                Logger.LogWarning("Операция поиска клиентов по ID была отменена (TaskCanceledException)");
                throw;
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Ошибка при поиске клиентов по ID {SearchTerm}", searchTerm);
                return EmptyControllersClientSearchResultList;
            }
        }
        
        // Оптимизация: используем Sort() вместо OrderBy().ToList() для сортировки на месте
        // Это эффективнее для полной сортировки всех результатов, так как не создает промежуточных коллекций
        // Для очень больших списков (>10000 элементов) можно рассмотреть частичную сортировку,
        // но в данном случае количество результатов ограничено через maxTotalResults
        results.Sort((a, b) => string.Compare(a.ClientId, b.ClientId, StringComparison.OrdinalIgnoreCase));
        
        if (results.Count > 0)
        {
            RecordSuccess("SearchClientsById");
        }
        
        return results;
    }
    
    /// <summary>
    /// Поиск клиентов по ID в одном реалме (вспомогательный метод для параллелизации)
    /// </summary>
    private async Task<List<Controllers.ClientSearchResult>?> SearchClientsInRealmByIdAsync(
        string realmName,
        string searchTerm,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot search in realm {RealmName}", realmName);
            return null;
        }
        
        try
        {
            // Uri.EscapeDataString безопасно кодирует searchTerm, предотвращая инъекции
            // ValidateSearchTerm уже ограничивает длину searchTerm, а ValidateEndpoint проверяет длину endpoint
            var encodedSearchTerm = Uri.EscapeDataString(searchTerm);
            
            // Проверяем, что закодированная строка не превышает разумный лимит
            if (encodedSearchTerm.Length > MaxSearchTermLength * 3)
            {
                Logger.LogWarning("Encoded search term length ({Length}) exceeds maximum ({MaxLength}), skipping realm {RealmName}", 
                    encodedSearchTerm.Length, MaxSearchTermLength * 3, realmName);
                return null;
            }
            
            var endpoint = $"admin/realms/{realmName}/clients?first=0&max={Settings.MaxSearchResults}&clientId={encodedSearchTerm}&search=true";
            
            // Упрощенная обработка ошибок: ValidateEndpoint может выбросить InvalidOperationException,
            // но это обрабатывается в общем catch-блоке, что упрощает структуру кода
            ValidateEndpoint(endpoint);
            
            var clients = await ExecuteClientsSearchRequestAsync(endpoint, realmName, cancellationToken).ConfigureAwait(false);
            
            var results = new List<Controllers.ClientSearchResult>();
            
            foreach (var clientElement in clients)
            {
                cancellationToken.ThrowIfCancellationRequested();
                
                var clientId = clientElement.TryGetProperty("clientId", out var clientIdEl) ? clientIdEl.GetString() : null;
                
                if (string.IsNullOrEmpty(clientId))
                    continue;
                
                // Валидация длины clientId для безопасности
                if (clientId.Length > MaxClientIdLength)
                {
                    Logger.LogWarning("ClientId length ({Length}) exceeds maximum ({MaxLength}), skipping", 
                        clientId.Length, MaxClientIdLength);
                    continue;
                }
                
                // Фильтруем по подстроке
                if (!clientId.Contains(searchTerm, StringComparison.OrdinalIgnoreCase))
                    continue;
                
                // Валидация и обрезка name и description
                var name = clientElement.TryGetProperty("name", out var nameEl) ? nameEl.GetString() : null;
                if (name != null && name.Length > MaxNameLength)
                {
                    Logger.LogWarning("Name length ({Length}) exceeds maximum ({MaxLength}), truncating", 
                        name.Length, MaxNameLength);
                    name = TruncateString(name, MaxNameLength);
                }
                
                var description = clientElement.TryGetProperty("description", out var descEl) ? descEl.GetString() : null;
                if (description != null && description.Length > MaxDescriptionLength)
                {
                    Logger.LogWarning("Description length ({Length}) exceeds maximum ({MaxLength}), truncating", 
                        description.Length, MaxDescriptionLength);
                    description = TruncateString(description, MaxDescriptionLength);
                }
                
                // Извлечение значения enabled с использованием общего метода для устранения дублирования
                var enabled = ExtractEnabledValue(clientElement, defaultValue: false);
                    
                results.Add(new Controllers.ClientSearchResult
                {
                    ClientId = clientId,
                    Realm = realmName,
                    Name = name,
                    Description = description,
                    Enabled = enabled
                });
            }
            
            return results;
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при поиске клиентов по ID {SearchTerm} в реалме {RealmName}", searchTerm, realmName);
            throw;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция поиска клиентов была отменена (TaskCanceledException)");
            throw;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (InvalidOperationException ex)
        {
            // Обработка ошибок валидации endpoint (например, слишком длинный endpoint)
            Logger.LogWarning("Invalid endpoint for realm {RealmName}: {Error}, skipping", realmName, ex.Message);
            return null;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при поиске клиентов по ID {SearchTerm} в реалме {RealmName}", searchTerm, realmName);
            return null;
        }
        finally
        {
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Парсинг клиента из JsonElement с валидацией данных
    /// </summary>
    private ClientSearchResult ParseClientFromJson(JsonElement element, string realm)
    {
        var clientId = element.TryGetProperty("clientId", out var cidProp) ? cidProp.GetString() ?? "" : "";
        var name = element.TryGetProperty("name", out var nameProp) ? nameProp.GetString() ?? clientId : clientId;
        var description = element.TryGetProperty("description", out var descProp) ? descProp.GetString() : null;
        
        // Извлечение значения enabled с использованием общего метода для устранения дублирования
        var enabled = ExtractEnabledValue(element, defaultValue: true);
        
        // Валидация и обрезка длинных строк для безопасности
        if (clientId.Length > MaxClientIdLength)
        {
            Logger.LogWarning("ClientId length ({Length}) exceeds maximum ({MaxLength}), truncating", 
                clientId.Length, MaxClientIdLength);
            clientId = TruncateString(clientId, MaxClientIdLength);
        }
        
        if (name.Length > MaxNameLength)
        {
            Logger.LogWarning("Name length ({Length}) exceeds maximum ({MaxLength}), truncating", 
                name.Length, MaxNameLength);
            name = TruncateString(name, MaxNameLength);
        }
        
        if (description != null && description.Length > MaxDescriptionLength)
        {
            Logger.LogWarning("Description length ({Length}) exceeds maximum ({MaxLength}), truncating", 
                description.Length, MaxDescriptionLength);
            description = TruncateString(description, MaxDescriptionLength);
        }
        
        return new ClientSearchResult
        {
            ClientId = clientId,
            Name = name,
            Description = description,
            Enabled = enabled,
            Realm = realm,
            CreatedDate = DateTime.MinValue, // Keycloak API не возвращает даты в кратком представлении
            LastModified = DateTime.MinValue
        };
    }

}

