using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using new_assistant.Configuration;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;
using new_assistant.Core.Models;

namespace new_assistant.Infrastructure.Services.Keycloak;

/// <summary>
/// Клиент для массовых операций с ролями (batch operations)
/// </summary>
public class KeycloakRoleBatchOperationsClient : KeycloakRolesClientBase, IKeycloakRoleBatchOperationsClient
{
    private readonly KeycloakRealmRolesClient _realmRolesClient;
    private readonly KeycloakRoleMappingClient _roleMappingClient;
    
    private int MaxBatchSize
    {
        get
        {
            if (Settings.Roles != null)
                return Settings.Roles.MaxBatchSize;
            
            var defaultValue = 1000;
            Logger.LogWarning("Settings.Roles is null, using default value {DefaultValue} for MaxBatchSize", defaultValue);
            return defaultValue;
        }
    }
    
    public KeycloakRoleBatchOperationsClient(
        HttpClient httpClient,
        KeycloakAdminSettings settings,
        ILogger logger,
        IKeycloakCacheService cacheService,
        IPerformanceMetricsService metricsService,
        KeycloakRealmRolesClient realmRolesClient,
        KeycloakRoleMappingClient roleMappingClient)
        : base(httpClient, settings, logger, cacheService, metricsService)
    {
        _realmRolesClient = realmRolesClient ?? throw new ArgumentNullException(nameof(realmRolesClient));
        _roleMappingClient = roleMappingClient ?? throw new ArgumentNullException(nameof(roleMappingClient));
        
        if (settings.Roles == null)
        {
            Logger.LogWarning("Settings.Roles is null. Default values will be used for all role-related settings.");
        }
    }
    
    // Все методы валидации, выполнения запросов и вспомогательные методы теперь в базовом классе KeycloakRolesClientBase
    
    private int EstimateJsonSize(int itemCount, int bytesPerItem = 100, int overhead = 200)
    {
        if (itemCount < 0)
            throw new ArgumentException("ItemCount cannot be negative", nameof(itemCount));
        if (bytesPerItem < 0)
            throw new ArgumentException("BytesPerItem cannot be negative", nameof(bytesPerItem));
        if (overhead < 0)
            throw new ArgumentException("Overhead cannot be negative", nameof(overhead));
        
        long estimated = (long)itemCount * bytesPerItem + overhead;
        
        if (estimated > int.MaxValue)
        {
            Logger?.LogWarning("Estimated JSON size ({Estimated} bytes) exceeds int.MaxValue, returning int.MaxValue", estimated);
            return int.MaxValue;
        }
        
        return (int)estimated;
    }
    
    private (List<T> uniqueItems, int duplicatesCount) DeduplicateItems<T>(
        IReadOnlyList<T> items,
        Func<T, string> getKey,
        string operationName)
    {
        var uniqueItems = items
            .GroupBy(getKey, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.First())
            .ToList();
        
        var duplicatesCount = items.Count - uniqueItems.Count;
        if (duplicatesCount > 0)
        {
            Logger.LogWarning("Обнаружены дубликаты в списке {OperationName}. Удалено {Count} дубликатов", 
                operationName, duplicatesCount);
        }
        
        return (uniqueItems, duplicatesCount);
    }
    
    private void ValidateBatchSize<T>(IReadOnlyList<T> items, string paramName)
    {
        if (items == null || items.Count == 0)
            throw new ArgumentException("Items cannot be null or empty", paramName);
        
        if (items.Count > MaxBatchSize)
        {
            throw new ArgumentException($"Cannot process more than {MaxBatchSize} items at once", paramName);
        }
    }
    
    /// <summary>
    /// Назначить несколько realm ролей пользователю одним запросом (batch)
    /// </summary>
    public async Task AssignMultipleRealmRolesToUserAsync(string realm, string userId, IReadOnlyList<string> roleNames, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateUserId(userId);
        
        if (roleNames == null || roleNames.Count == 0)
            return;
        
        ValidateBatchSize(roleNames, nameof(roleNames));
        
        var (uniqueRoleNames, _) = DeduplicateItems(roleNames, r => r ?? string.Empty, "realm roles");
        
        if (uniqueRoleNames.Count == 0)
        {
            Logger.LogWarning("После дедупликации список ролей стал пустым");
            return;
        }
        
        if (uniqueRoleNames.Any(string.IsNullOrWhiteSpace))
        {
            throw new ArgumentException("RoleNames cannot contain null or empty values", nameof(roleNames));
        }
        
        cancellationToken.ThrowIfCancellationRequested();
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation");
            return;
        }
        try
        {
            var currentMappings = await _roleMappingClient.GetUserRoleMappingsAsync(realm, userId, cancellationToken).ConfigureAwait(false);
            var existingRoleNames = new HashSet<string>(
                currentMappings
                    .Where(r => !r.ClientRole && !string.IsNullOrWhiteSpace(r.Name))
                    .Select(r => r.Name!),
                StringComparer.OrdinalIgnoreCase);
            
            var allRealmRolesResult = await _realmRolesClient.GetAvailableRealmRolesAsync(realm, cancellationToken).ConfigureAwait(false);
            if (!allRealmRolesResult.Any())
            {
                Logger.LogWarning("Не найдено ни одной realm роли в реалме {Realm}", realm);
                return;
            }
            
            var roleNamesSet = new HashSet<string>(uniqueRoleNames, StringComparer.Ordinal);
            var roleDataList = new List<KeycloakRoleDto>(uniqueRoleNames.Count);
            
            foreach (var role in allRealmRolesResult)
            {
                if (roleNamesSet.Contains(role.Name))
                {
                    roleDataList.Add(role);
                    roleNamesSet.Remove(role.Name);
                }
            }
            
            var rolesToAssign = roleDataList
                .Where(r => !existingRoleNames.Contains(r.Name))
                .ToList();
            
            if (rolesToAssign.Count == 0)
            {
                Logger.LogInformation("Все указанные роли уже назначены пользователю {UserId} в реалме {Realm}", userId, realm);
                return;
            }
            
            if (rolesToAssign.Count < roleDataList.Count)
            {
                var alreadyAssigned = roleDataList
                    .Where(r => existingRoleNames.Contains(r.Name))
                    .Select(r => r.Name)
                    .ToList();
                Logger.LogInformation("Следующие роли уже назначены пользователю {UserId}: {Roles}", userId, string.Join(", ", alreadyAssigned));
            }
            
            if (roleNamesSet.Count > 0)
            {
                var notFoundRoles = string.Join(", ", roleNamesSet);
                Logger.LogWarning("Следующие роли не найдены в реалме {Realm}: {NotFoundRoles}", realm, notFoundRoles);
                throw new KeyNotFoundException($"Следующие роли не найдены в реалме {realm}: {notFoundRoles}");
            }
            
            if (roleDataList.Count == 0)
            {
                Logger.LogWarning("Не найдено ни одной валидной роли для назначения");
                throw new InvalidOperationException("Не найдено ни одной валидной роли для назначения");
            }
            
            var estimatedSize = EstimateJsonSize(rolesToAssign.Count, 100, 200);
            if (estimatedSize > MaxJsonContentSizeBytes)
            {
                Logger.LogWarning("Estimated JSON size ({EstimatedSize} bytes) exceeds maximum allowed size ({MaxSize} bytes)", 
                    estimatedSize, MaxJsonContentSizeBytes);
                throw new InvalidOperationException($"Request payload too large (estimated): {estimatedSize} bytes");
            }
            
            var endpoint = $"admin/realms/{realm}/users/{userId}/role-mappings/realm";
            if (!ValidateEndpoint(endpoint, out var endpointError))
            {
                Logger.LogError(endpointError);
                return;
            }

            var jsonContent = JsonContent.Create(rolesToAssign);
            
            var actualContentLength = jsonContent.Headers.ContentLength ?? 0;
            if (actualContentLength > MaxJsonContentSizeBytes)
            {
                Logger.LogWarning("Actual JSON size ({Size} bytes) exceeds maximum allowed size ({MaxSize} bytes)", 
                    actualContentLength, MaxJsonContentSizeBytes);
                throw new InvalidOperationException($"Request payload too large: {actualContentLength} bytes");
            }

            using var assignRequest = await CreateAuthorizedRequestWithAcceptAsync(HttpMethod.Post, endpoint, cancellationToken).ConfigureAwait(false);
            assignRequest.Content = jsonContent;
            
            using var response = await HttpClient.SendAsync(assignRequest, cancellationToken).ConfigureAwait(false);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await ReadErrorContentAsync(response, cancellationToken).ConfigureAwait(false);
                Logger.LogError("Ошибка batch назначения ролей: {StatusCode} - {ErrorContent}", response.StatusCode, errorContent);
                throw new HttpRequestException($"Не удалось назначить роли: {response.StatusCode} - {errorContent}");
            }
            
            RecordHttpRequest(HttpMethod.Post.Method, endpoint, true);
            RecordSuccess($"{nameof(AssignMultipleRealmRolesToUserAsync)}.BatchSize.{rolesToAssign.Count}");
            RecordRequestTime(stopwatch.ElapsedMilliseconds);
            
            if (rolesToAssign.Count > 0)
            {
                var avgTimePerRole = stopwatch.ElapsedMilliseconds / (double)rolesToAssign.Count;
                MetricsService?.RecordOperationTime($"{MetricsOperationName}.{nameof(AssignMultipleRealmRolesToUserAsync)}.AvgTimePerRole", (long)avgTimePerRole);
            }
            
            if (Logger.IsEnabled(LogLevel.Debug))
            {
                var assignedRoles = await _roleMappingClient.GetUserRoleMappingsAsync(realm, userId, cancellationToken).ConfigureAwait(false);
                var assignedRoleNames = new HashSet<string>(
                    assignedRoles.Where(r => !r.ClientRole && !string.IsNullOrWhiteSpace(r.Name)).Select(r => r.Name!),
                    StringComparer.OrdinalIgnoreCase);
                
                var notAssigned = rolesToAssign
                    .Where(r => !assignedRoleNames.Contains(r.Name))
                    .Select(r => r.Name)
                    .ToList();
                
                if (notAssigned.Any())
                {
                    Logger.LogWarning("Следующие роли не были назначены пользователю {UserId}: {Roles}", 
                        userId, string.Join(", ", notAssigned));
                }
            }
            
            // Инвалидируем связанные ключи кэша
            await InvalidateUserRoleCacheAsync(realm, userId, cancellationToken).ConfigureAwait(false);

        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при batch назначении realm ролей");
            throw;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция batch назначения realm ролей была отменена (TaskCanceledException)");
            throw;
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning("Операция batch назначения realm ролей была отменена");
            throw;
        }
        catch (HttpRequestException)
        {
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при batch назначении realm ролей пользователю {UserId} в реалме {Realm}", userId, realm);
            throw;
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Назначить несколько client ролей пользователю одним запросом (batch)
    /// </summary>
    public async Task AssignMultipleClientRolesToUserAsync(string realm, string userId, string clientInternalId, 
        IReadOnlyList<(string roleId, string roleName)> roles, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateUserId(userId);
        ValidateClientInternalId(clientInternalId);
        
        if (roles == null || roles.Count == 0)
            return;
        
        ValidateBatchSize(roles, nameof(roles));
        
        var (uniqueRoles, _) = DeduplicateItems(roles, r => r.roleId ?? string.Empty, "client roles");
        
        if (uniqueRoles.Count == 0)
        {
            Logger.LogWarning("После дедупликации список client ролей стал пустым");
            return;
        }
        
        if (uniqueRoles.Any(r => string.IsNullOrWhiteSpace(r.roleId) || string.IsNullOrWhiteSpace(r.roleName)))
        {
            throw new ArgumentException("Roles cannot contain null or empty roleId or roleName", nameof(roles));
        }
        
        cancellationToken.ThrowIfCancellationRequested();
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation");
            return;
        }
        try
        {
            var endpoint = $"admin/realms/{realm}/users/{userId}/role-mappings/clients/{clientInternalId}";
            if (!ValidateEndpoint(endpoint, out var endpointError))
            {
                Logger.LogError(endpointError);
                return;
            }
            
            var roleMappings = new RoleMappingRequest[uniqueRoles.Count];
            for (int i = 0; i < uniqueRoles.Count; i++)
            {
                roleMappings[i] = new RoleMappingRequest
                {
                    Id = uniqueRoles[i].roleId,
                    Name = uniqueRoles[i].roleName
                };
            }
            
            var estimatedSize = EstimateJsonSize(uniqueRoles.Count, 80, 200);
            if (estimatedSize > MaxJsonContentSizeBytes)
            {
                Logger.LogWarning("Estimated JSON size ({EstimatedSize} bytes) exceeds maximum allowed size ({MaxSize} bytes)", 
                    estimatedSize, MaxJsonContentSizeBytes);
                throw new InvalidOperationException($"Request payload too large (estimated): {estimatedSize} bytes");
            }
            
            var jsonContent = JsonContent.Create(roleMappings);
            
            var actualContentLength = jsonContent.Headers.ContentLength ?? 0;
            if (actualContentLength > MaxJsonContentSizeBytes)
            {
                Logger.LogWarning("Actual JSON size ({Size} bytes) exceeds maximum allowed size ({MaxSize} bytes)", 
                    actualContentLength, MaxJsonContentSizeBytes);
                throw new InvalidOperationException($"Request payload too large: {actualContentLength} bytes");
            }

            using var request = await CreateAuthorizedRequestWithAcceptAsync(HttpMethod.Post, endpoint, cancellationToken).ConfigureAwait(false);
            request.Content = jsonContent;
            
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await ReadErrorContentAsync(response, cancellationToken).ConfigureAwait(false);
                Logger.LogError("Ошибка batch назначения client ролей: {StatusCode} - {ErrorContent}", response.StatusCode, errorContent);
                throw new HttpRequestException($"Не удалось назначить client роли: {response.StatusCode}");
            }
            
            RecordHttpRequest(HttpMethod.Post.Method, endpoint, true);
            RecordSuccess($"{nameof(AssignMultipleClientRolesToUserAsync)}.BatchSize.{uniqueRoles.Count}");
            RecordRequestTime(stopwatch.ElapsedMilliseconds);
            
            if (uniqueRoles.Count > 0)
            {
                var avgTimePerRole = stopwatch.ElapsedMilliseconds / (double)uniqueRoles.Count;
                MetricsService?.RecordOperationTime($"{MetricsOperationName}.{nameof(AssignMultipleClientRolesToUserAsync)}.AvgTimePerRole", (long)avgTimePerRole);
            }
            
            var userRoleMappingsCacheKey = $"user-role-mappings:{realm}:{userId}";
            await CacheService.RemoveAsync(userRoleMappingsCacheKey, cancellationToken).ConfigureAwait(false);
            
            var availableRolesCacheKey = $"available-roles:{realm}:{userId}";
            await CacheService.RemoveAsync(availableRolesCacheKey, cancellationToken).ConfigureAwait(false);
            
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при batch назначении client ролей");
            throw;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция batch назначения client ролей была отменена (TaskCanceledException)");
            throw;
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning("Операция batch назначения client ролей была отменена");
            throw;
        }
        catch (HttpRequestException)
        {
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при batch назначении client ролей пользователю {UserId} в реалме {Realm}", userId, realm);
            throw;
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Удалить несколько client ролей у пользователя одним запросом (batch)
    /// </summary>
    public async Task RemoveMultipleClientRolesFromUserAsync(string realm, string userId, string clientInternalId, 
        IReadOnlyList<(string roleId, string roleName)> roles, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateUserId(userId);
        ValidateClientInternalId(clientInternalId);
        
        if (roles == null || roles.Count == 0)
            return;
        
        ValidateBatchSize(roles, nameof(roles));
        
        var (uniqueRoles, _) = DeduplicateItems(roles, r => r.roleId ?? string.Empty, "client roles for removal");
        
        if (uniqueRoles.Count == 0)
        {
            Logger.LogWarning("После дедупликации список client ролей для удаления стал пустым");
            return;
        }
        
        if (uniqueRoles.Any(r => string.IsNullOrWhiteSpace(r.roleId) || string.IsNullOrWhiteSpace(r.roleName)))
        {
            throw new ArgumentException("Roles cannot contain null or empty roleId or roleName", nameof(roles));
        }
        
        cancellationToken.ThrowIfCancellationRequested();
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation");
            return;
        }
        try
        {
            var endpoint = $"admin/realms/{realm}/users/{userId}/role-mappings/clients/{clientInternalId}";
            if (!ValidateEndpoint(endpoint, out var endpointError))
            {
                Logger.LogError(endpointError);
                return;
            }
            
            var roleMappings = new RoleMappingRequest[uniqueRoles.Count];
            for (int i = 0; i < uniqueRoles.Count; i++)
            {
                roleMappings[i] = new RoleMappingRequest
                {
                    Id = uniqueRoles[i].roleId,
                    Name = uniqueRoles[i].roleName
                };
            }
            
            var estimatedSize = EstimateJsonSize(uniqueRoles.Count, 80, 200);
            if (estimatedSize > MaxJsonContentSizeBytes)
            {
                Logger.LogWarning("Estimated JSON size ({EstimatedSize} bytes) exceeds maximum allowed size ({MaxSize} bytes)", 
                    estimatedSize, MaxJsonContentSizeBytes);
                throw new InvalidOperationException($"Request payload too large (estimated): {estimatedSize} bytes");
            }
            
            var jsonContent = JsonContent.Create(roleMappings);
            
            var actualContentLength = jsonContent.Headers.ContentLength ?? 0;
            if (actualContentLength > MaxJsonContentSizeBytes)
            {
                Logger.LogWarning("Actual JSON size ({Size} bytes) exceeds maximum allowed size ({MaxSize} bytes)", 
                    actualContentLength, MaxJsonContentSizeBytes);
                throw new InvalidOperationException($"Request payload too large: {actualContentLength} bytes");
            }

            using var request = await CreateAuthorizedRequestWithAcceptAsync(HttpMethod.Delete, endpoint, cancellationToken).ConfigureAwait(false);
            request.Content = jsonContent;
            
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await ReadErrorContentAsync(response, cancellationToken).ConfigureAwait(false);
                Logger.LogError("Ошибка batch удаления client ролей: {StatusCode} - {ErrorContent}", response.StatusCode, errorContent);
                throw new HttpRequestException($"Не удалось удалить client роли: {response.StatusCode}");
            }
            
            RecordHttpRequest(HttpMethod.Delete.Method, endpoint, true);
            RecordSuccess($"{nameof(RemoveMultipleClientRolesFromUserAsync)}.BatchSize.{uniqueRoles.Count}");
            RecordRequestTime(stopwatch.ElapsedMilliseconds);
            
            if (uniqueRoles.Count > 0)
            {
                var avgTimePerRole = stopwatch.ElapsedMilliseconds / (double)uniqueRoles.Count;
                MetricsService?.RecordOperationTime($"{MetricsOperationName}.{nameof(RemoveMultipleClientRolesFromUserAsync)}.AvgTimePerRole", (long)avgTimePerRole);
            }
            
            var userRoleMappingsCacheKey = $"user-role-mappings:{realm}:{userId}";
            await CacheService.RemoveAsync(userRoleMappingsCacheKey, cancellationToken).ConfigureAwait(false);
            
            var availableRolesCacheKey = $"available-roles:{realm}:{userId}";
            await CacheService.RemoveAsync(availableRolesCacheKey, cancellationToken).ConfigureAwait(false);
            
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при batch удалении client ролей");
            throw;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция batch удаления client ролей была отменена (TaskCanceledException)");
            throw;
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning("Операция batch удаления client ролей была отменена");
            throw;
        }
        catch (HttpRequestException)
        {
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при batch удалении client ролей у пользователя {UserId} в реалме {Realm}", userId, realm);
            throw;
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Удалить несколько realm ролей у пользователя одним запросом (batch)
    /// </summary>
    public async Task RemoveMultipleRealmRolesFromUserAsync(string realm, string userId, IReadOnlyList<string> roleNames, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateUserId(userId);
        
        if (roleNames == null || roleNames.Count == 0)
            return;
        
        ValidateBatchSize(roleNames, nameof(roleNames));
        
        var (uniqueRoleNames, _) = DeduplicateItems(roleNames, r => r ?? string.Empty, "realm roles for removal");
        
        if (uniqueRoleNames.Count == 0)
        {
            Logger.LogWarning("После дедупликации список ролей для удаления стал пустым");
            return;
        }
        
        if (uniqueRoleNames.Any(string.IsNullOrWhiteSpace))
        {
            throw new ArgumentException("RoleNames cannot contain null or empty values", nameof(roleNames));
        }
        
        var mappingsEndpoint = $"admin/realms/{realm}/users/{userId}/role-mappings";
        var mappingsResult = await ExecuteRequestAsync<KeycloakRoleMappingsDto>(
            mappingsEndpoint, 
            HttpMethod.Get, 
            ErrorHandlingStrategy.ThrowException, 
            null, 
            cancellationToken);
        
        if (mappingsResult.Value == null)
        {
            throw new InvalidOperationException("Role mappings returned null");
        }
        
        var roleNamesSet = new HashSet<string>(uniqueRoleNames, StringComparer.Ordinal);
        var rolesToDelete = new List<KeycloakRoleDto>();
        
        if (mappingsResult.Value.RealmMappings != null)
        {
            foreach (var role in mappingsResult.Value.RealmMappings)
            {
                if (!string.IsNullOrWhiteSpace(role.Name) && roleNamesSet.Contains(role.Name))
                {
                    rolesToDelete.Add(role);
                }
            }
        }
        
        if (rolesToDelete.Count == 0)
        {
            Logger.LogWarning("Не найдено ни одной роли для удаления");
            return;
        }
        
        var estimatedSize = EstimateJsonSize(rolesToDelete.Count, 100, 200);
        if (estimatedSize > MaxJsonContentSizeBytes)
        {
            Logger.LogWarning("Estimated JSON size ({EstimatedSize} bytes) exceeds maximum allowed size ({MaxSize} bytes)", 
                estimatedSize, MaxJsonContentSizeBytes);
            throw new InvalidOperationException($"Request payload too large (estimated): {estimatedSize} bytes");
        }
        
        var endpoint = $"admin/realms/{realm}/users/{userId}/role-mappings/realm";
        
        var stopwatch = Stopwatch.StartNew();
        await ExecuteOperationAsync(endpoint, HttpMethod.Delete, rolesToDelete, cancellationToken);
        stopwatch.Stop();
        
        RecordHttpRequest(HttpMethod.Delete.Method, endpoint, true);
        RecordSuccess($"{nameof(RemoveMultipleRealmRolesFromUserAsync)}.BatchSize.{rolesToDelete.Count}");
        RecordRequestTime(stopwatch.ElapsedMilliseconds);
        
        if (rolesToDelete.Count > 0)
        {
            var avgTimePerRole = stopwatch.ElapsedMilliseconds / (double)rolesToDelete.Count;
            MetricsService?.RecordOperationTime($"{MetricsOperationName}.{nameof(RemoveMultipleRealmRolesFromUserAsync)}.AvgTimePerRole", (long)avgTimePerRole);
        }
        
        // Инвалидируем связанные ключи кэша
        await InvalidateUserRoleCacheAsync(realm, userId, cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Инвалидирует связанные ключи кэша для пользователя (user-role-mappings и available-roles)
    /// </summary>
    private async Task InvalidateUserRoleCacheAsync(string realm, string userId, CancellationToken cancellationToken)
    {
        var userRoleMappingsCacheKey = $"user-role-mappings:{realm}:{userId}";
        var availableRolesCacheKey = $"available-roles:{realm}:{userId}";
        
        // Выполняем инвалидацию параллельно для лучшей производительности
        await Task.WhenAll(
            CacheService.RemoveAsync(userRoleMappingsCacheKey, cancellationToken),
            CacheService.RemoveAsync(availableRolesCacheKey, cancellationToken)
        ).ConfigureAwait(false);
    }
}

