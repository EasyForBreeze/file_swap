using System.Buffers;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using new_assistant.Core.DTOs;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services.Keycloak;

/// <summary>
/// Клиент для работы с реалмами Keycloak
/// </summary>
public class KeycloakRealmsClient : KeycloakHttpClientBase
{
    // Используем JsonSerializerOptions из базового класса (исправление проблемы #6)
    private static JsonSerializerOptions DefaultJsonOptions => KeycloakHttpClientBase.DefaultJsonSerializerOptions;
    
    // Константы для JSON свойств реалмов
    private const string RealmProperty = "realm";
    private const string IdProperty = "id";
    private const string NameProperty = "name";
    private const string DisplayNameProperty = "displayName";
    private const string EnabledProperty = "enabled";
    
    // Константы для endpoints
    private const string RealmsDetailsEndpoint = "admin/realms";
    private const string RealmsListEndpoint = "admin/realms?briefRepresentation=true";
    
    // Константа для максимальной длины контента в логах
    private new const int MaxContentLengthForLogging = 200;
    
    // Константа для максимального размера ответа (10 MB)
    private const int MaxResponseSize = 10 * 1024 * 1024;
    
    // Константа для максимального количества реалмов
    private const int MaxRealmsCount = 10000;
    
    // Константы для сообщений логирования
    private const string LogOperationStarted = "Операция {Operation} начата";
    private const string LogOperationCompleted = "Операция {Operation} завершена успешно. Результатов: {Count}";
    private const string LogOperationCompletedEmpty = "Операция {Operation} завершена успешно. Результатов: 0";
    private const string LogOperationTiming = "Операция {Operation} - {Time}мс";
    private const string LogSemaphoreDisposed = "Semaphore disposed, cannot execute operation: {Operation}";
    private const string LogResponseContentNull = "Response.Content is null при операции {Operation}";
    private const string LogEmptyResponse = "Получен пустой ответ при операции {Operation}";
    private const string LogDeserializationNull = "Deserialized realms list is null при операции {Operation}";
    private const string LogJsonDeserializationError = "Ошибка десериализации JSON при операции {Operation}. Content: {Content}";
    private const string LogTimeout = "Timeout при операции {Operation}";
    private const string LogOperationCanceled = "Операция {Operation} была отменена";
    private const string LogOperationCanceledTaskCanceled = "Операция {Operation} была отменена (TaskCanceledException)";
    private const string LogHttpRequestError = "Ошибка HTTP запроса при операции {Operation}";
    private const string LogUnexpectedError = "Неожиданная ошибка при операции {Operation}";
    private const string LogErrorReadingResponseBody = "Не удалось прочитать тело ответа при ошибке";
    private const string LogAuthorizationError = "Ошибка авторизации при {Operation}: {StatusCode}. Error: {ErrorContent}";
    private const string LogEndpointNotFound = "Endpoint {Endpoint} не найден при {Operation}: {StatusCode}. Error: {ErrorContent}";
    private const string LogEndpointNotFoundNoEndpoint = "Endpoint не найден при {Operation}: {StatusCode}. Error: {ErrorContent}";
    private const string LogHttpOperationFailed = "Не удалось выполнить {Operation}: {StatusCode} {ReasonPhrase}. Error: {ErrorContent}";
    private const string LogResponseTooLarge = "Response too large: {Size} bytes при операции {Operation}";
    
    /// <summary>
    /// Обрабатывает HTTP ошибки и логирует их с метриками
    /// </summary>
    /// <param name="response">HTTP ответ с ошибкой</param>
    /// <param name="operationName">Название операции для логирования</param>
    /// <param name="endpoint">Endpoint для логирования (опционально)</param>
    /// <param name="throwOnCriticalError">Если true, выбрасывает исключения для критических ошибок (401, 403, 5xx)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    private async Task HandleHttpErrorAsync(
        HttpResponseMessage response, 
        string operationName, 
        string endpoint = "",
        bool throwOnCriticalError = false,
        CancellationToken cancellationToken = default)
    {
        string? errorContent = null;
        if (response.Content != null)
        {
            try
            {
                errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                if (errorContent.Length > MaxContentLengthForLogging)
                {
                    errorContent = string.Concat(errorContent.AsSpan(0, MaxContentLengthForLogging), "...");
                }
            }
            catch (Exception ex)
            {
                Logger.LogWarning(ex, LogErrorReadingResponseBody);
            }
        }
        
        // Оптимизация: используем switch expression для более эффективной проверки статусов
        var statusCode = response.StatusCode;
        var statusCodeString = statusCode.ToString();
        
        switch (statusCode)
        {
            case HttpStatusCode.Unauthorized:
            case HttpStatusCode.Forbidden:
                RecordError(operationName, statusCodeString);
                Logger.LogError(LogAuthorizationError, operationName, statusCode, errorContent);
                
                if (throwOnCriticalError)
                {
                    throw new UnauthorizedAccessException($"Authorization failed for {operationName}: {statusCode}");
                }
                return;
            
            case HttpStatusCode.NotFound:
                RecordError(operationName, statusCodeString);
                if (!string.IsNullOrEmpty(endpoint))
                {
                    Logger.LogWarning(LogEndpointNotFound, endpoint, operationName, statusCode, errorContent);
                }
                else
                {
                    Logger.LogWarning(LogEndpointNotFoundNoEndpoint, operationName, statusCode, errorContent);
                }
                return;
        }
        
        RecordError(operationName, statusCodeString);
        Logger.LogError(LogHttpOperationFailed, operationName, statusCode, response.ReasonPhrase, errorContent);
        
        if (throwOnCriticalError && (int)statusCode >= 500)
        {
            throw new HttpRequestException($"HTTP operation failed: {statusCode} {response.ReasonPhrase}");
        }
    }
    
    /// <summary>
    /// Выполняет HTTP запрос с обработкой rate limiting и метриками
    /// </summary>
    private async Task<HttpResponseMessage> ExecuteRequestWithRateLimitAsync(
        HttpRequestMessage request,
        string endpoint,
        string operationName,
        CancellationToken cancellationToken = default)
    {
        // Сохраняем информацию о запросе для возможного повтора
        var method = request.Method;
        
        var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
        var responseDisposed = false;
        
        try
        {
            // Обработка rate limiting - если получили 429, создаем новый запрос для повтора
            var finalResponse = await HandleRateLimitAsync(
                response,
                async () =>
                {
                    // Создаем новый запрос для повтора (HttpRequestMessage нельзя использовать повторно)
                    using var retryRequest = await CreateAuthorizedRequestAsync(method, endpoint, cancellationToken).ConfigureAwait(false);
                    return await HttpClient.SendAsync(retryRequest, cancellationToken).ConfigureAwait(false);
                },
                cancellationToken).ConfigureAwait(false);
            
            // Записываем метрику HTTP запроса
            // Оптимизация: кэшируем строковое представление метода
            var methodString = method.ToString();
            RecordHttpRequest(methodString, endpoint, finalResponse.IsSuccessStatusCode);
            
            // Dispose только если это другой response
            if (finalResponse != response)
            {
                response.Dispose();
                responseDisposed = true;
            }
            
            return finalResponse;
        }
        catch
        {
            if (!responseDisposed)
            {
                response.Dispose();
            }
            throw;
        }
    }
    
    /// <summary>
    /// Парсит JSON ответ и возвращает список JsonElement
    /// </summary>
    private async Task<List<JsonElement>> ParseRealmsResponseAsync(
        HttpResponseMessage response,
        string operationName,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        if (response.Content == null)
        {
            Logger.LogWarning(LogResponseContentNull, operationName);
            RecordError(operationName, "ResponseContentNull");
            return new List<JsonElement>();
        }
        
        // Проверяем Content-Length до чтения
        var contentLength = response.Content.Headers.ContentLength;
        if (contentLength.HasValue && contentLength.Value > MaxResponseSize)
        {
            Logger.LogError(LogResponseTooLarge, contentLength.Value, operationName);
            RecordError(operationName, "ResponseTooLarge");
            return new List<JsonElement>();
        }
        
        cancellationToken.ThrowIfCancellationRequested();
        
        // Упрощенная логика обработки ответов (исправление проблемы #7)
        // Используем единый подход с ReadAsStreamAsync для всех размеров ответов
        string content;
        try
        {
            using var contentStream = await response.Content.ReadAsStreamAsync(cancellationToken).ConfigureAwait(false);
            using var reader = new System.IO.StreamReader(contentStream, System.Text.Encoding.UTF8, detectEncodingFromByteOrderMarks: true, bufferSize: 8192, leaveOpen: false);
            
            var contentBuilder = new StringBuilder(Math.Min((int)(contentLength ?? 8192), MaxResponseSize));
            var buffer = new char[8192];
            var totalRead = 0;
            int read;
            
            while ((read = await reader.ReadAsync(buffer, 0, buffer.Length).ConfigureAwait(false)) > 0)
            {
                totalRead += read;
                if (totalRead > MaxResponseSize)
                {
                    Logger.LogError(LogResponseTooLarge, totalRead, operationName);
                    RecordError(operationName, "ResponseTooLarge");
                    return new List<JsonElement>();
                }
                contentBuilder.Append(buffer, 0, read);
            }
            
            content = contentBuilder.ToString();
            
            if (string.IsNullOrWhiteSpace(content))
            {
                Logger.LogWarning(LogEmptyResponse, operationName);
                RecordError(operationName, "EmptyResponse");
                return new List<JsonElement>();
            }
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при чтении содержимого ответа при операции {Operation}", operationName);
            RecordError(operationName, "ContentReadError");
            return new List<JsonElement>();
        }
        
        cancellationToken.ThrowIfCancellationRequested();
        
        List<JsonElement> realms;
        try
        {
            realms = JsonSerializer.Deserialize<List<JsonElement>>(content, DefaultJsonOptions) 
                ?? new List<JsonElement>();
            
            // Проверка на максимальное количество реалмов
            if (realms.Count > MaxRealmsCount)
            {
                Logger.LogError(
                    "Превышено максимальное количество реалмов: {Count} > {MaxCount} при операции {Operation}",
                    realms.Count, MaxRealmsCount, operationName);
                RecordError(operationName, "TooManyRealms");
                return new List<JsonElement>();
            }
            
            return realms;
        }
        catch (JsonException ex)
        {
            // Оптимизация: используем ReadOnlySpan для создания preview без аллокации
            string contentPreview = content!.Length > MaxContentLengthForLogging
                ? string.Concat(content.AsSpan(0, MaxContentLengthForLogging), "...")
                : content;
            
            Logger.LogError(ex, LogJsonDeserializationError, operationName, contentPreview);
            RecordError(operationName, "JsonDeserializationError");
            return new List<JsonElement>();
        }
    }
    
    // Кэширование HashSet исключенных реалмов для оптимизации (исправление проблемы #40)
    // Используем Lazy<T> для thread-safe инициализации вместо double-checked locking
    private readonly Lazy<HashSet<string>> _cachedExcludedRealmsSet;
    
    /// <summary>
    /// Получает HashSet исключенных реалмов для оптимизации проверок
    /// Использует кэширование для избежания повторного создания HashSet
    /// </summary>
    private HashSet<string> GetExcludedRealmsSet()
    {
        return _cachedExcludedRealmsSet.Value;
    }
    
    /// <summary>
    /// Парсит JsonElement в RealmDto с правильной обработкой всех свойств
    /// Оптимизированная версия с использованием TryGetProperty для прямого доступа к свойствам
    /// </summary>
    private RealmDto? ParseRealmDto(JsonElement realm, HashSet<string> excludedRealmsSet)
    {
        // Используем TryGetProperty для прямого доступа к свойствам
        // Это быстрее чем EnumerateObject для небольшого количества свойств
        string? realmName = null;
        
        if (realm.TryGetProperty(RealmProperty, out var realmProp))
        {
            realmName = realmProp.GetString();
        }
        else if (realm.TryGetProperty(IdProperty, out var idProp))
        {
            realmName = idProp.GetString();
        }
        else if (realm.TryGetProperty(NameProperty, out var nameProp))
        {
            realmName = nameProp.GetString();
        }
        
        // Оптимизация: используем string.IsNullOrEmpty для более быстрой проверки
        // IsNullOrWhiteSpace делает дополнительную проверку на whitespace
        if (string.IsNullOrEmpty(realmName))
            return null;
        
        // Проверка на исключенные реалмы используя переданный HashSet
        if (excludedRealmsSet.Contains(realmName))
            return null;
        
        // Получаем остальные свойства только если они нужны
        string? displayName = null;
        if (realm.TryGetProperty(DisplayNameProperty, out var displayNameProp))
        {
            displayName = displayNameProp.GetString();
        }
        
        // Оптимизация: упрощаем логику для enabled - используем прямое сравнение ValueKind
        bool enabled = true;
        if (realm.TryGetProperty(EnabledProperty, out var enabledProp))
        {
            enabled = enabledProp.ValueKind == JsonValueKind.True;
        }
        
        return new RealmDto
        {
            Realm = realmName,
            DisplayName = displayName,
            Enabled = enabled
        };
    }
    
    /// <summary>
    /// Парсит JsonElement в строку имени реалма
    /// </summary>
    private string? ParseRealmName(JsonElement realm)
    {
        if (realm.TryGetProperty(RealmProperty, out var realmProp))
        {
            return realmProp.GetString();
        }
        if (realm.TryGetProperty(IdProperty, out var idProp))
        {
            return idProp.GetString();
        }
        if (realm.TryGetProperty(NameProperty, out var nameProp))
        {
            return nameProp.GetString();
        }
        return null;
    }
    
    /// <summary>
    /// Инициализирует новый экземпляр KeycloakRealmsClient
    /// </summary>
    /// <param name="httpClient">HTTP клиент для выполнения запросов</param>
    /// <param name="settings">Настройки Keycloak Admin API</param>
    /// <param name="logger">Логгер для записи событий</param>
    /// <param name="cacheService">Сервис кэширования</param>
    /// <param name="metricsService">Сервис метрик производительности</param>
    /// <exception cref="ArgumentNullException">Выбрасывается если любой из параметров null</exception>
    /// <exception cref="ArgumentException">Выбрасывается если ExcludedRealms содержит невалидные значения</exception>
    public KeycloakRealmsClient(
        System.Net.Http.HttpClient httpClient,
        new_assistant.Configuration.KeycloakAdminSettings settings,
        ILogger logger,
        new_assistant.Core.Interfaces.IKeycloakCacheService cacheService,
        new_assistant.Core.Interfaces.IPerformanceMetricsService metricsService)
        : base(httpClient, settings, logger, cacheService, metricsService)
    {
        // Дополнительная валидация специфичная для KeycloakRealmsClient
        // Оптимизация: используем ReadOnlySpan для сравнения и избегаем лишних аллокаций
        if (settings.ExcludedRealms != null)
        {
            foreach (var realm in settings.ExcludedRealms)
            {
                if (string.IsNullOrEmpty(realm))
                {
                    throw new ArgumentException("ExcludedRealms cannot contain null or empty strings", nameof(settings));
                }
                if (realm.Length > MaxRealmLength)
                {
                    throw new ArgumentException($"ExcludedRealm '{realm}' exceeds maximum length ({MaxRealmLength})", nameof(settings));
                }
            }
        }
        
        // Инициализация Lazy для thread-safe кэширования (исправление проблемы #40)
        _cachedExcludedRealmsSet = new Lazy<HashSet<string>>(
            () => settings.ExcludedRealms?.ToHashSet(StringComparer.OrdinalIgnoreCase) 
                ?? new HashSet<string>(StringComparer.OrdinalIgnoreCase),
            System.Threading.LazyThreadSafetyMode.ExecutionAndPublication);
    }
    
    /// <summary>
    /// Получение списка реалмов (с кэшированием)
    /// </summary>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список названий реалмов</returns>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса</exception>
    /// <example>
    /// <code>
    /// var realms = await client.GetRealmsListAsync(cancellationToken);
    /// foreach (var realm in realms)
    /// {
    ///     Console.WriteLine(realm);
    /// }
    /// </code>
    /// </example>
    public async Task<List<string>> GetRealmsListAsync(CancellationToken cancellationToken = default)
    {
        // Используем кэш с фабричной функцией
        return await CacheService.GetOrCreateRealmsListAsync(
            async () => await LoadRealmsListFromKeycloakAsync(cancellationToken).ConfigureAwait(false),
            cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Выполняет запрос к Keycloak и возвращает список JsonElement
    /// </summary>
    private async Task<List<JsonElement>> ExecuteRealmsRequestAsync(
        string endpoint,
        string operationName,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        Logger.LogDebug(LogOperationStarted, operationName);
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning(LogSemaphoreDisposed, operationName);
            RecordError(operationName, "SemaphoreDisposed");
            return new List<JsonElement>();
        }
        
        try
        {
            using var request = await CreateAuthorizedRequestAsync(HttpMethod.Get, endpoint, cancellationToken).ConfigureAwait(false);
            using var response = await ExecuteRequestWithRateLimitAsync(request, endpoint, operationName, cancellationToken).ConfigureAwait(false);
            
            if (response.IsSuccessStatusCode)
            {
                var realms = await ParseRealmsResponseAsync(response, operationName, cancellationToken).ConfigureAwait(false);
                RecordSuccess(operationName);
                return realms;
            }
            
            await HandleHttpErrorAsync(response, operationName, endpoint, throwOnCriticalError: false, cancellationToken).ConfigureAwait(false);
            return new List<JsonElement>();
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError(LogTimeout, operationName);
            RecordError(operationName, "Timeout");
            return new List<JsonElement>();
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning(LogOperationCanceledTaskCanceled, operationName);
            RecordError(operationName, "TaskCanceled");
            return new List<JsonElement>();
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning(LogOperationCanceled, operationName);
            RecordError(operationName, "OperationCanceled");
            return new List<JsonElement>();
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, LogHttpRequestError, operationName);
            RecordError(operationName, "HttpRequestException");
            return new List<JsonElement>();
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, LogUnexpectedError, operationName);
            RecordError(operationName, "UnexpectedException");
            return new List<JsonElement>();
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
                Logger.LogInformation(LogOperationTiming, operationName, stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Получить детальную информацию о всех реалмах в виде потока (IAsyncEnumerable)
    /// Полезно для больших списков реалмов, так как не требует загрузки всех данных в память сразу
    /// </summary>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Асинхронная последовательность реалмов с детальной информацией</returns>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса</exception>
    /// <example>
    /// <code>
    /// await foreach (var realm in client.GetRealmsWithDetailsStreamAsync(cancellationToken))
    /// {
    ///     Console.WriteLine($"{realm.Realm}: {realm.DisplayName} (Enabled: {realm.Enabled})");
    /// }
    /// </code>
    /// </example>
    public async IAsyncEnumerable<RealmDto> GetRealmsWithDetailsStreamAsync(
        [System.Runtime.CompilerServices.EnumeratorCancellation] 
        CancellationToken cancellationToken = default)
    {
        const string operationName = nameof(GetRealmsWithDetailsStreamAsync);
        var realms = await ExecuteRealmsRequestAsync(RealmsDetailsEndpoint, operationName, cancellationToken).ConfigureAwait(false);
        
        if (realms == null || realms.Count == 0)
        {
            Logger.LogInformation(
                "Операция {Operation} завершена успешно. Результатов: 0",
                operationName);
            yield break;
        }
        
        var excludedRealmsSet = GetExcludedRealmsSet();
        int count = 0;
        int totalCount = realms.Count;
        
        // Оптимизация проверки cancellation token (исправление проблемы #8)
        const int CancellationCheckInterval = 10;
        int iterationCount = 0;
        
        foreach (var realm in realms)
        {
            // Проверяем cancellation token раз в N итераций
            if (++iterationCount % CancellationCheckInterval == 0)
            {
                cancellationToken.ThrowIfCancellationRequested();
            }
            
            var realmDto = ParseRealmDto(realm, excludedRealmsSet);
            if (realmDto != null)
            {
                count++;
                yield return realmDto;
            }
        }
        
        // Логируем только если обработали реалмы
        if (count > 0)
        {
            Logger.LogInformation(
                "Операция {Operation} завершена успешно. Результатов: {Count}",
                operationName, count);
        }
        else if (totalCount > 0)
        {
            Logger.LogInformation("Операция {Operation} завершена. Все реалмы были исключены. Всего: {TotalCount}", 
                operationName, totalCount);
        }
    }
    
    /// <summary>
    /// Получить детальную информацию о всех реалмах (с Display Name)
    /// </summary>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список реалмов с детальной информацией</returns>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса</exception>
    /// <example>
    /// <code>
    /// var realms = await client.GetRealmsWithDetailsAsync(cancellationToken);
    /// foreach (var realm in realms)
    /// {
    ///     Console.WriteLine($"{realm.Realm}: {realm.DisplayName} (Enabled: {realm.Enabled})");
    /// }
    /// </code>
    /// </example>
    public async Task<List<RealmDto>> GetRealmsWithDetailsAsync(CancellationToken cancellationToken = default)
    {
        const string operationName = nameof(GetRealmsWithDetailsAsync);
        var realms = await ExecuteRealmsRequestAsync(RealmsDetailsEndpoint, operationName, cancellationToken).ConfigureAwait(false);
        
        if (realms == null || realms.Count == 0)
        {
            Logger.LogInformation(
                "Операция {Operation} завершена успешно. Результатов: 0",
                operationName);
            return new List<RealmDto>();
        }
        
        var excludedRealmsSet = GetExcludedRealmsSet();
        var realmDtos = new List<RealmDto>(realms.Count);
        
        // Оптимизация проверки cancellation token (исправление проблемы #8)
        const int CancellationCheckInterval = 10;
        int iterationCount = 0;
        
        foreach (var realm in realms)
        {
            // Проверяем cancellation token раз в N итераций
            if (++iterationCount % CancellationCheckInterval == 0)
            {
                cancellationToken.ThrowIfCancellationRequested();
            }
            
            var realmDto = ParseRealmDto(realm, excludedRealmsSet);
            if (realmDto != null)
            {
                realmDtos.Add(realmDto);
            }
        }
        
        Logger.LogInformation(
            "Операция {Operation} завершена успешно. Результатов: {Count}",
            operationName, realmDtos.Count);
        return realmDtos;
    }
    
    /// <summary>
    /// Загрузка списка реалмов непосредственно из Keycloak (без кэша)
    /// </summary>
    private async Task<List<string>> LoadRealmsListFromKeycloakAsync(CancellationToken cancellationToken = default)
    {
        const string operationName = nameof(LoadRealmsListFromKeycloakAsync);
        cancellationToken.ThrowIfCancellationRequested();
        
        // Используем endpoint с briefRepresentation для получения списка реалмов
        var endpoint = RealmsListEndpoint;
        
        var realms = await ExecuteRealmsRequestAsync(endpoint, operationName, cancellationToken).ConfigureAwait(false);
        
        if (realms.Count == 0)
        {
            Logger.LogInformation(
                "Операция {Operation} завершена успешно. Результатов: 0",
                operationName);
            return new List<string>();
        }
        
        // Кэшируем HashSet для исключенных реалмов для O(1) поиска
        var excludedRealmsSet = GetExcludedRealmsSet();
        
        // Парсим и фильтруем реалмы одновременно - оптимизация: избегаем создания промежуточной коллекции
        // С briefRepresentation=true может быть только id
        var filteredRealms = new List<string>(realms.Count);
        
        // Оптимизация проверки cancellation token (исправление проблемы #8)
        const int CancellationCheckInterval = 10;
        int iterationCount = 0;
        
        foreach (var realm in realms)
        {
            // Проверяем cancellation token раз в N итераций
            if (++iterationCount % CancellationCheckInterval == 0)
            {
                cancellationToken.ThrowIfCancellationRequested();
            }
            
            var realmName = ParseRealmName(realm);
            
            // Фильтруем при добавлении: проверяем на пустоту и исключенные реалмы
            // Оптимизация: используем string.IsNullOrEmpty для более быстрой проверки
            if (!string.IsNullOrEmpty(realmName) && !excludedRealmsSet.Contains(realmName))
            {
                filteredRealms.Add(realmName);
            }
        }
        
        Logger.LogInformation(
            "Операция {Operation} завершена успешно. Результатов: {Count}",
            operationName, filteredRealms.Count);
        return filteredRealms;
    }
}

