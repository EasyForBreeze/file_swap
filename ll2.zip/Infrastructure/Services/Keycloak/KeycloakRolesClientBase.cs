using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;
using new_assistant.Core.Models;

namespace new_assistant.Infrastructure.Services.Keycloak;

/// <summary>
/// Базовый класс для всех клиентов, работающих с ролями Keycloak
/// Содержит общие методы валидации, выполнения запросов и вспомогательные методы
/// </summary>
public abstract class KeycloakRolesClientBase : KeycloakHttpClientBase
{
    protected static readonly JsonSerializerOptions DefaultJsonOptions = new JsonSerializerOptions
    {
        PropertyNameCaseInsensitive = true
    };
    
    // Константы для HTTP заголовков
    protected const string AcceptHeader = "Accept";
    protected const string ApplicationJsonContentType = "application/json";
    protected const int MaxErrorContentLengthForLogging = 500;
    
    // Константы для валидации (используем из базового класса)
    // MaxRealmLength, MaxEndpointLength определены в KeycloakHttpClientBase
    protected const int MaxClientInternalIdLength = 100;
    protected const int MaxUserIdLength = 100;
    protected const int MaxRoleNameLength = 255;
    protected const int MaxRoleIdLength = 100;
    protected const int MaxRoleDescriptionLength = 1000;
    protected const int MaxSearchTermLength = 100;
    
    protected KeycloakRolesClientBase(
        HttpClient httpClient,
        KeycloakAdminSettings settings,
        ILogger logger,
        IKeycloakCacheService cacheService,
        IPerformanceMetricsService metricsService)
        : base(httpClient, settings, logger, cacheService, metricsService)
    {
    }
    
    // Свойства для доступа к настройкам ролей (должны быть переопределены в наследниках при необходимости)
    protected virtual int MaxJsonContentSizeBytes
    {
        get
        {
            if (Settings.Roles != null)
                return Settings.Roles.MaxJsonContentSizeBytes;
            
            var defaultValue = 1048576; // 1 MB
            Logger.LogWarning("Settings.Roles is null, using default value {DefaultValue} for MaxJsonContentSizeBytes", defaultValue);
            return defaultValue;
        }
    }
    
    #region Validation Methods
    
    /// <summary>
    /// Валидация параметра realm
    /// </summary>
    protected void ValidateRealm(string realm)
    {
        if (string.IsNullOrWhiteSpace(realm))
        {
            if (Logger.IsEnabled(LogLevel.Warning))
            {
                Logger.LogWarning("Валидация не пройдена: Realm is null or empty");
            }
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        }
        if (realm.Length > MaxRealmLength)
        {
            if (Logger.IsEnabled(LogLevel.Warning))
            {
                Logger.LogWarning("Валидация не пройдена: Realm length ({Length}) exceeds maximum allowed length ({MaxLength})", 
                    realm.Length, MaxRealmLength);
            }
            throw new ArgumentException($"Realm cannot exceed {MaxRealmLength} characters", nameof(realm));
        }
        
        if (Logger.IsEnabled(LogLevel.Trace))
        {
            Logger.LogTrace("Валидация пройдена: Realm = {Realm} (length: {Length})", realm, realm.Length);
        }
    }
    
    /// <summary>
    /// Валидация параметра clientInternalId
    /// </summary>
    protected void ValidateClientInternalId(string clientInternalId)
    {
        if (string.IsNullOrWhiteSpace(clientInternalId))
        {
            if (Logger.IsEnabled(LogLevel.Warning))
            {
                Logger.LogWarning("Валидация не пройдена: ClientInternalId is null or empty");
            }
            throw new ArgumentException("ClientInternalId cannot be null or empty", nameof(clientInternalId));
        }
        if (clientInternalId.Length > MaxClientInternalIdLength)
        {
            if (Logger.IsEnabled(LogLevel.Warning))
            {
                Logger.LogWarning("Валидация не пройдена: ClientInternalId length ({Length}) exceeds maximum allowed length ({MaxLength})", 
                    clientInternalId.Length, MaxClientInternalIdLength);
            }
            throw new ArgumentException($"ClientInternalId cannot exceed {MaxClientInternalIdLength} characters", nameof(clientInternalId));
        }
        
        if (Logger.IsEnabled(LogLevel.Trace))
        {
            Logger.LogTrace("Валидация пройдена: ClientInternalId = {ClientInternalId} (length: {Length})", clientInternalId, clientInternalId.Length);
        }
    }
    
    /// <summary>
    /// Валидация параметра userId
    /// </summary>
    protected void ValidateUserId(string userId)
    {
        if (string.IsNullOrWhiteSpace(userId))
        {
            if (Logger.IsEnabled(LogLevel.Warning))
            {
                Logger.LogWarning("Валидация не пройдена: UserId is null or empty");
            }
            throw new ArgumentException("UserId cannot be null or empty", nameof(userId));
        }
        if (userId.Length > MaxUserIdLength)
        {
            if (Logger.IsEnabled(LogLevel.Warning))
            {
                Logger.LogWarning("Валидация не пройдена: UserId length ({Length}) exceeds maximum allowed length ({MaxLength})", 
                    userId.Length, MaxUserIdLength);
            }
            throw new ArgumentException($"UserId cannot exceed {MaxUserIdLength} characters", nameof(userId));
        }
        
        if (Logger.IsEnabled(LogLevel.Trace))
        {
            Logger.LogTrace("Валидация пройдена: UserId = {UserId} (length: {Length})", userId, userId.Length);
        }
    }
    
    /// <summary>
    /// Валидация параметра roleName
    /// </summary>
    protected virtual void ValidateRoleName(string roleName)
    {
        if (string.IsNullOrWhiteSpace(roleName))
        {
            if (Logger.IsEnabled(LogLevel.Warning))
            {
                Logger.LogWarning("Валидация не пройдена: RoleName is null or empty");
            }
            throw new ArgumentException("RoleName cannot be null or empty", nameof(roleName));
        }
        
        var maxLength = GetMaxRoleNameLength();
        if (roleName.Length > maxLength)
        {
            if (Logger.IsEnabled(LogLevel.Warning))
            {
                Logger.LogWarning("Валидация не пройдена: RoleName length ({Length}) exceeds maximum allowed length ({MaxLength})", 
                    roleName.Length, maxLength);
            }
            throw new ArgumentException($"RoleName cannot exceed {maxLength} characters", nameof(roleName));
        }
        
        if (Logger.IsEnabled(LogLevel.Trace))
        {
            Logger.LogTrace("Валидация пройдена: RoleName = {RoleName} (length: {Length})", roleName, roleName.Length);
        }
    }
    
    /// <summary>
    /// Валидация параметра roleId
    /// </summary>
    protected virtual void ValidateRoleId(string roleId)
    {
        if (string.IsNullOrWhiteSpace(roleId))
        {
            if (Logger.IsEnabled(LogLevel.Warning))
            {
                Logger.LogWarning("Валидация не пройдена: RoleId is null or empty");
            }
            throw new ArgumentException("RoleId cannot be null or empty", nameof(roleId));
        }
        
        var maxLength = GetMaxRoleIdLength();
        if (roleId.Length > maxLength)
        {
            if (Logger.IsEnabled(LogLevel.Warning))
            {
                Logger.LogWarning("Валидация не пройдена: RoleId length ({Length}) exceeds maximum allowed length ({MaxLength})", 
                    roleId.Length, maxLength);
            }
            throw new ArgumentException($"RoleId cannot exceed {maxLength} characters", nameof(roleId));
        }
        
        if (Logger.IsEnabled(LogLevel.Trace))
        {
            Logger.LogTrace("Валидация пройдена: RoleId = {RoleId} (length: {Length})", roleId, roleId.Length);
        }
    }
    
    /// <summary>
    /// Валидация параметра description роли
    /// </summary>
    protected virtual void ValidateRoleDescription(string? description)
    {
        if (description != null)
        {
            var maxLength = GetMaxRoleDescriptionLength();
            if (description.Length > maxLength)
            {
                if (Logger.IsEnabled(LogLevel.Warning))
                {
                    Logger.LogWarning("Валидация не пройдена: RoleDescription length ({Length}) exceeds maximum allowed length ({MaxLength})", 
                        description.Length, maxLength);
                }
                throw new ArgumentException($"Role description cannot exceed {maxLength} characters", nameof(description));
            }
            
            if (Logger.IsEnabled(LogLevel.Trace))
            {
                Logger.LogTrace("Валидация пройдена: RoleDescription (length: {Length})", description.Length);
            }
        }
        else if (Logger.IsEnabled(LogLevel.Trace))
        {
            Logger.LogTrace("Валидация пройдена: RoleDescription is null (опциональный параметр)");
        }
    }
    
    /// <summary>
    /// Валидация параметра searchTerm
    /// </summary>
    protected void ValidateSearchTerm(string searchTerm)
    {
        if (searchTerm == null)
        {
            if (Logger.IsEnabled(LogLevel.Trace))
            {
                Logger.LogTrace("Валидация пройдена: SearchTerm is null (опциональный параметр)");
            }
            return; // searchTerm может быть null (опциональный параметр)
        }
        
        if (searchTerm.Length > MaxSearchTermLength)
        {
            if (Logger.IsEnabled(LogLevel.Warning))
            {
                Logger.LogWarning("Валидация не пройдена: SearchTerm length ({Length}) exceeds maximum allowed length ({MaxLength})", 
                    searchTerm.Length, MaxSearchTermLength);
            }
            throw new ArgumentException($"SearchTerm cannot exceed {MaxSearchTermLength} characters", nameof(searchTerm));
        }
        
        if (Logger.IsEnabled(LogLevel.Trace))
        {
            Logger.LogTrace("Валидация пройдена: SearchTerm = {SearchTerm} (length: {Length})", searchTerm, searchTerm.Length);
        }
    }
    
    /// <summary>
    /// Получить максимальную длину имени роли (может быть переопределено в наследниках)
    /// </summary>
    protected virtual int GetMaxRoleNameLength() => MaxRoleNameLength;
    
    /// <summary>
    /// Получить максимальную длину ID роли (может быть переопределено в наследниках)
    /// </summary>
    protected virtual int GetMaxRoleIdLength() => MaxRoleIdLength;
    
    /// <summary>
    /// Получить максимальную длину описания роли (может быть переопределено в наследниках)
    /// </summary>
    protected virtual int GetMaxRoleDescriptionLength() => MaxRoleDescriptionLength;
    
    #endregion
    
    #region Helper Methods
    
    /// <summary>
    /// Создает HttpRequestMessage с Bearer токеном авторизации и Accept header
    /// </summary>
    protected async Task<HttpRequestMessage> CreateAuthorizedRequestWithAcceptAsync(HttpMethod method, string endpoint, CancellationToken cancellationToken = default)
    {
        var request = await CreateAuthorizedRequestAsync(method, endpoint, cancellationToken).ConfigureAwait(false);
        request.Headers.Add(AcceptHeader, ApplicationJsonContentType);
        return request;
    }
    
    /// <summary>
    /// Читает errorContent из HttpResponseMessage с ограничением длины для логирования
    /// </summary>
    protected async Task<string> ReadErrorContentAsync(HttpResponseMessage response, CancellationToken cancellationToken)
    {
        if (response.Content == null)
            return string.Empty;
        
        var errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
        
        if (errorContent.Length > MaxErrorContentLengthForLogging)
        {
            return string.Concat(errorContent.AsSpan(0, MaxErrorContentLengthForLogging), "...");
        }
        
        return errorContent;
    }
    
    /// <summary>
    /// Проверяет валидность endpoint перед использованием
    /// </summary>
    protected bool ValidateEndpoint(string endpoint, out string? errorMessage)
    {
        errorMessage = null;
        
        if (endpoint.Length > MaxEndpointLength)
        {
            errorMessage = $"Endpoint too long: {endpoint.Length} characters";
            return false;
        }
        
        if (string.IsNullOrWhiteSpace(endpoint))
        {
            errorMessage = "Endpoint cannot be null or empty";
            return false;
        }
        
        if (!Uri.IsWellFormedUriString(endpoint, UriKind.Relative))
        {
            errorMessage = $"Invalid endpoint format: {endpoint}";
            return false;
        }
        
        // Защита от path traversal атак
        if (endpoint.Contains("..") || endpoint.Contains("//"))
        {
            errorMessage = $"Endpoint contains invalid characters: {endpoint}";
            return false;
        }
        
        // Защита от абсолютных URL (должен быть только относительный путь)
        if (Uri.TryCreate(endpoint, UriKind.Absolute, out _))
        {
            errorMessage = $"Endpoint must be relative, not absolute: {endpoint}";
            return false;
        }
        
        // Защита от опасных символов
        var dangerousChars = new[] { '\0', '\r', '\n', '\t' };
        if (endpoint.IndexOfAny(dangerousChars) >= 0)
        {
            errorMessage = $"Endpoint contains dangerous characters: {endpoint}";
            return false;
        }
        
        return true;
    }
    
    #endregion
    
    #region Request Execution Methods
    
    /// <summary>
    /// Выполняет HTTP запрос с общей обработкой ошибок, semaphore и метриками
    /// </summary>
    protected async Task<Result<T>> ExecuteRequestAsync<T>(
        string endpoint,
        HttpMethod method,
        ErrorHandlingStrategy errorStrategy = ErrorHandlingStrategy.ReturnEmpty,
        object? requestBody = null,
        CancellationToken cancellationToken = default)
        where T : class
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        if (Logger.IsEnabled(LogLevel.Debug))
        {
            Logger.LogDebug("Выполнение запроса {Method} {Endpoint}", method, endpoint);
        }
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation {Method} {Endpoint}", method, endpoint);
            return errorStrategy switch
            {
                ErrorHandlingStrategy.ReturnEmpty => Result<T>.Success(default(T)!),
                ErrorHandlingStrategy.ReturnNull => Result<T>.Failure("Semaphore disposed"),
                _ => Result<T>.Failure("Semaphore disposed")
            };
        }
        
        try
        {
            if (!ValidateEndpoint(endpoint, out var endpointError))
            {
                Logger.LogError("Invalid endpoint: {EndpointError}", endpointError);
                return Result<T>.Failure(endpointError ?? "Invalid endpoint");
            }
            
            using var request = await CreateAuthorizedRequestWithAcceptAsync(method, endpoint, cancellationToken).ConfigureAwait(false);
            
            if (requestBody != null && (method == HttpMethod.Post || method == HttpMethod.Put || method == HttpMethod.Patch))
            {
                request.Content = JsonContent.Create(requestBody);
                
                if (Logger.IsEnabled(LogLevel.Trace))
                {
                    var bodySize = request.Content.Headers.ContentLength ?? 0;
                    Logger.LogTrace("Request body size: {Size} bytes for {Method} {Endpoint}", bodySize, method, endpoint);
                }
            }
            
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await ReadErrorContentAsync(response, cancellationToken).ConfigureAwait(false);
                
                // Записываем метрику ошибки
                RecordHttpRequest(method.Method, endpoint, false);
                RecordError($"{method.Method}.{endpoint}", response.StatusCode.ToString());
                
                if (Logger.IsEnabled(LogLevel.Warning))
                {
                    Logger.LogWarning("Ошибка выполнения запроса {Method} {Endpoint}: {StatusCode} - {ErrorContent}", 
                        method, endpoint, response.StatusCode, errorContent);
                }
                
                if (errorStrategy == ErrorHandlingStrategy.ThrowException)
                {
                    throw new HttpRequestException($"Не удалось выполнить запрос: {response.StatusCode} - {errorContent}");
                }
                
                return Result<T>.FromHttpError(response.StatusCode, errorContent);
            }
            
            // Записываем метрику успешного запроса
            RecordHttpRequest(method.Method, endpoint, true);
            
            // Проверка размера ответа перед чтением
            var contentLength = response.Content?.Headers.ContentLength;
            if (contentLength.HasValue && contentLength.Value > MaxJsonContentSizeBytes)
            {
                Logger.LogError("Response content size ({Size} bytes) exceeds maximum allowed size ({MaxSize} bytes) for {Endpoint}",
                    contentLength.Value, MaxJsonContentSizeBytes, endpoint);
                throw new InvalidOperationException($"Response content too large: {contentLength.Value} bytes");
            }
            
            if (response.Content == null)
            {
                Logger.LogWarning("Response.Content is null для {Method} {Endpoint}", method, endpoint);
                return errorStrategy switch
                {
                    ErrorHandlingStrategy.ReturnEmpty => Result<T>.Success(default(T)!),
                    ErrorHandlingStrategy.ReturnNull => Result<T>.Failure("Response content is null"),
                    _ => Result<T>.Failure("Response content is null")
                };
            }
            
            var content = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            if (string.IsNullOrWhiteSpace(content))
            {
                if (Logger.IsEnabled(LogLevel.Debug))
                {
                    Logger.LogDebug("Empty response content for {Method} {Endpoint}", method, endpoint);
                }
                return errorStrategy switch
                {
                    ErrorHandlingStrategy.ReturnEmpty => Result<T>.Success(default(T)!),
                    ErrorHandlingStrategy.ReturnNull => Result<T>.Failure("Empty response content"),
                    _ => Result<T>.Failure("Empty response content")
                };
            }
            
            try
            {
                var result = JsonSerializer.Deserialize<T>(content, DefaultJsonOptions);
                if (result == null)
                {
                    Logger.LogWarning("Deserialization returned null for {Method} {Endpoint}", method, endpoint);
                    return errorStrategy switch
                    {
                        ErrorHandlingStrategy.ReturnEmpty => Result<T>.Success(default(T)!),
                        ErrorHandlingStrategy.ReturnNull => Result<T>.Failure("Deserialization returned null"),
                        _ => Result<T>.Failure("Deserialization returned null")
                    };
                }
                
                if (Logger.IsEnabled(LogLevel.Debug))
                {
                    Logger.LogDebug("Успешно выполнен запрос {Method} {Endpoint} за {ElapsedMs}ms", 
                        method, endpoint, stopwatch.ElapsedMilliseconds);
                }
                
                return Result<T>.Success(result);
            }
            catch (JsonException ex)
            {
                Logger.LogError(ex, "Ошибка десериализации для {Method} {Endpoint}. Content length: {ContentLength}", 
                    method, endpoint, content.Length);
                
                if (Logger.IsEnabled(LogLevel.Trace))
                {
                    const int maxContentLengthForLogging = 500;
                    var contentPreview = content.Length > maxContentLengthForLogging 
                        ? string.Concat(content.AsSpan(0, maxContentLengthForLogging), "...") 
                        : content;
                    Logger.LogTrace("Content preview: {Content}", contentPreview);
                }
                
                return Result<T>.Failure($"Ошибка десериализации: {ex.Message}", ex);
            }
        }
        catch (System.Threading.Tasks.TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при выполнении запроса {Method} {Endpoint} за {ElapsedMs}ms", 
                method, endpoint, stopwatch.ElapsedMilliseconds);
            throw;
        }
        catch (System.Threading.Tasks.TaskCanceledException)
        {
            Logger.LogWarning("Операция {Method} {Endpoint} была отменена (TaskCanceledException)", method, endpoint);
            throw;
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning("Операция {Method} {Endpoint} была отменена", method, endpoint);
            throw;
        }
        catch (HttpRequestException)
        {
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при выполнении запроса {Method} {Endpoint}", method, endpoint);
            if (errorStrategy == ErrorHandlingStrategy.ThrowException)
            {
                throw;
            }
            return Result<T>.Failure($"Неожиданная ошибка: {ex.Message}", ex);
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Выполняет операцию (POST, PUT, DELETE, PATCH) с общей обработкой ошибок
    /// </summary>
    protected async Task<Result> ExecuteOperationAsync(string endpoint, HttpMethod method, object? requestBody = null, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation");
            return Result.Failure("Semaphore disposed");
        }
        
        try
        {
            if (!ValidateEndpoint(endpoint, out var endpointError))
            {
                Logger.LogError("Invalid endpoint: {EndpointError}", endpointError);
                return Result.Failure(endpointError ?? "Invalid endpoint");
            }
            
            using var request = await CreateAuthorizedRequestWithAcceptAsync(method, endpoint, cancellationToken).ConfigureAwait(false);
            
            if (requestBody != null)
            {
                request.Content = JsonContent.Create(requestBody);
            }
            
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await ReadErrorContentAsync(response, cancellationToken).ConfigureAwait(false);
                Logger.LogError("Ошибка выполнения операции {Method} {Endpoint}: {StatusCode} - {ErrorContent}", 
                    method, endpoint, response.StatusCode, errorContent);
                throw new HttpRequestException($"Не удалось выполнить операцию: {response.StatusCode} - {errorContent}");
            }
            
            return Result.Success();
        }
        catch (HttpRequestException)
        {
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при выполнении операции {Method} {Endpoint}", method, endpoint);
            throw;
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Получает список объектов типа T из endpoint
    /// </summary>
    protected async Task<Result<List<T>>> GetListAsync<T>(string endpoint, CancellationToken cancellationToken = default) where T : class
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot get list from {Endpoint}", endpoint);
            return Result<List<T>>.Success(new List<T>());
        }
        
        try
        {
            if (!ValidateEndpoint(endpoint, out var endpointError))
            {
                Logger.LogError("Invalid endpoint: {EndpointError}", endpointError);
                return Result<List<T>>.Success(new List<T>());
            }
            
            using var request = await CreateAuthorizedRequestWithAcceptAsync(HttpMethod.Get, endpoint, cancellationToken).ConfigureAwait(false);
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            
            // Проверка размера ответа перед чтением
            var contentLength = response.Content?.Headers.ContentLength;
            if (contentLength.HasValue && contentLength.Value > MaxJsonContentSizeBytes)
            {
                Logger.LogError("Response content size ({Size} bytes) exceeds maximum allowed size ({MaxSize} bytes) for {Endpoint}",
                    contentLength.Value, MaxJsonContentSizeBytes, endpoint);
                return Result<List<T>>.Success(new List<T>());
            }
            
            if (!response.IsSuccessStatusCode)
            {
                if (Logger.IsEnabled(LogLevel.Warning))
                {
                    Logger.LogWarning("Ошибка получения списка {Type} из {Endpoint}: {StatusCode}", 
                        typeof(T).Name, endpoint, response.StatusCode);
                }
                return Result<List<T>>.Success(new List<T>());
            }
            
            if (response.Content == null)
            {
                Logger.LogWarning("Response.Content is null для {Endpoint}", endpoint);
                return Result<List<T>>.Success(new List<T>());
            }
            
            var content = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            if (string.IsNullOrWhiteSpace(content))
            {
                if (Logger.IsEnabled(LogLevel.Debug))
                {
                    Logger.LogDebug("Empty response content for {Endpoint}", endpoint);
                }
                return Result<List<T>>.Success(new List<T>());
            }
            
            try
            {
                var result = JsonSerializer.Deserialize<List<T>>(content, DefaultJsonOptions);
                var list = result ?? new List<T>();
                return Result<List<T>>.Success(list);
            }
            catch (JsonException ex)
            {
                Logger.LogError(ex, "Ошибка десериализации списка {Type} для {Endpoint}. Content length: {ContentLength}", 
                    typeof(T).Name, endpoint, content.Length);
                return Result<List<T>>.Success(new List<T>());
            }
        }
        catch (System.Threading.Tasks.TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при получении списка {Type} из {Endpoint} за {ElapsedMs}ms", 
                typeof(T).Name, endpoint, stopwatch.ElapsedMilliseconds);
            throw;
        }
        catch (System.Threading.Tasks.TaskCanceledException)
        {
            Logger.LogWarning("Операция получения списка {Type} из {Endpoint} была отменена (TaskCanceledException)", 
                typeof(T).Name, endpoint);
            throw;
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning("Операция получения списка {Type} из {Endpoint} была отменена", 
                typeof(T).Name, endpoint);
            throw;
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, "HTTP ошибка при получении списка {Type} из {Endpoint}", 
                typeof(T).Name, endpoint);
            return Result<List<T>>.Success(new List<T>());
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при получении списка {Type} из {Endpoint}", typeof(T).Name, endpoint);
            return Result<List<T>>.Success(new List<T>());
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    #endregion
}

