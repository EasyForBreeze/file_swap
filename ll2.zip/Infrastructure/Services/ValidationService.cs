using new_assistant.Core.Interfaces;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для валидации данных клиентов Keycloak
/// </summary>
public class ValidationService : IValidationService
{
    // Константы для валидации
    private const int MaxRoleNameLength = 255; // Keycloak ограничение (также настраивается через конфигурацию)
    private const int MaxRedirectUriLength = 2048; // Разумное ограничение для браузеров
    private const int MaxRoleNameLengthForRegex = 1000; // Защита от ReDoS атак
    
    private readonly ILogger<ValidationService> _logger;
    private readonly int _maxRoleNameLength;
    
    /// <summary>
    /// Зарезервированные имена ролей Keycloak, которые нельзя использовать
    /// </summary>
    private static readonly HashSet<string> ReservedRoleNames = new(StringComparer.OrdinalIgnoreCase)
    {
        "offline_access",
        "uma_authorization",
        "uma_protection"
    };
    
    /// <summary>
    /// Регулярное выражение для валидации имени роли
    /// Разрешает: латинские буквы (a-z, A-Z), цифры (0-9), дефисы (-), подчёркивания (_) и точки (.)
    /// </summary>
    private static readonly Regex RoleNameRegex = 
        new(@"^[a-zA-Z0-9_.-]+$", 
            RegexOptions.Compiled | RegexOptions.CultureInvariant);

    /// <summary>
    /// Конструктор сервиса валидации
    /// </summary>
    /// <param name="logger">Логгер для записи событий</param>
    /// <param name="keycloakSettings">Настройки Keycloak (опционально, может быть null)</param>
    public ValidationService(
        ILogger<ValidationService> logger,
        IOptions<KeycloakAdminSettings>? keycloakSettings = null)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        
        // Используем значение из конфигурации, если доступно, иначе константу
        _maxRoleNameLength = keycloakSettings?.Value?.Roles?.MaxRoleNameLength ?? MaxRoleNameLength;
    }

    /// <inheritdoc />
    /// <remarks>
    /// Валидные примеры: "admin", "user_role", "my.role", "role-123"
    /// Невалидные примеры: "role name" (пробелы), "role@admin" (спецсимволы), "" (пустая строка)
    /// Максимальная длина: 255 символов (настраивается через KeycloakAdminSettings.Roles.MaxRoleNameLength)
    /// </remarks>
    public bool IsValidRoleName(string? roleName)
    {
        try
        {
            // Пустая строка невалидна (для консистентности с остальным кодом)
            // Проверка IsNullOrWhiteSpace уже гарантирует, что длина >= 1, если строка прошла
            if (string.IsNullOrWhiteSpace(roleName))
                return false;
            
            // Проверка максимальной длины
            if (roleName.Length > _maxRoleNameLength)
            {
                _logger.LogDebug("Имя роли отклонено: превышена максимальная длина. Длина: {Length}, Максимум: {MaxLength}", 
                    roleName.Length, _maxRoleNameLength);
                return false;
            }
            
            // Защита от ReDoS: не проверяем слишком длинные строки через Regex
            if (roleName.Length > MaxRoleNameLengthForRegex)
                return false;
            
            // Проверка на зарезервированные имена ролей Keycloak
            if (ReservedRoleNames.Contains(roleName))
            {
                _logger.LogDebug("Имя роли отклонено: зарезервированное имя Keycloak. Роль: {RoleName}", roleName);
                return false;
            }
            
            return RoleNameRegex.IsMatch(roleName);
        }
        catch (RegexMatchTimeoutException ex)
        {
            // При таймауте Regex считаем невалидным
            _logger.LogWarning(ex, "Таймаут Regex при валидации имени роли: {RoleName}", roleName);
            return false;
        }
        catch (Exception ex)
        {
            // Логирование неожиданных исключений
            _logger.LogError(ex, "Неожиданная ошибка при валидации имени роли: {RoleName}", roleName);
            return false;
        }
    }

    /// <inheritdoc />
    /// <remarks>
    /// Валидные примеры: "https://example.com/callback", "http://localhost:3000/callback", "urn:ietf:wg:oauth:2.0:oob"
    /// Невалидные примеры: "*" (wildcard небезопасен), "javascript:alert(1)" (опасная схема), "" (пустая строка)
    /// Максимальная длина: 2048 символов
    /// </remarks>
    public bool IsValidRedirectUri(string? uri)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(uri))
                return false;
            
            // Проверка максимальной длины
            if (uri.Length > MaxRedirectUriLength)
            {
                _logger.LogDebug("Redirect URI отклонен: превышена максимальная длина. Длина: {Length}, Максимум: {MaxLength}", 
                    uri.Length, MaxRedirectUriLength);
                return false;
            }
            
            // Блокируем опасные схемы (case-insensitive, без создания промежуточной строки)
            if (uri.StartsWith("javascript:", StringComparison.OrdinalIgnoreCase) ||
                uri.StartsWith("data:", StringComparison.OrdinalIgnoreCase) ||
                uri.StartsWith("vbscript:", StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogDebug("Redirect URI отклонен: опасная схема. URI: {Uri}", uri);
                return false;
            }
            
            // Разрешаем URN схемы (для OAuth 2.0)
            if (uri.StartsWith("urn:", StringComparison.OrdinalIgnoreCase))
                return true;
            
            // Wildcard удален - это небезопасно (Open Redirect уязвимость)
            // if (uri == "*")
            //     return true;
            
            // Проверяем, что URI является абсолютным
            if (!Uri.TryCreate(uri, UriKind.Absolute, out var uriResult))
                return false;
            
            // Разрешаем только HTTP и HTTPS схемы
            return uriResult.Scheme == Uri.UriSchemeHttp || 
                   uriResult.Scheme == Uri.UriSchemeHttps;
        }
        catch (Exception ex)
        {
            // Логирование неожиданных исключений
            _logger.LogError(ex, "Неожиданная ошибка при валидации Redirect URI: {Uri}", uri);
            return false;
        }
    }
}

