using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;
using Microsoft.Extensions.Logging;
using System.Linq;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для работы с событиями клиента
/// </summary>
public class ClientEventsService : IClientEventsService
{
    private readonly ILogger<ClientEventsService> _logger;
    
    private const int MaxPageSize = 1000;
    private const int MaxEventsToProcess = 1_000_000;
    
    public ClientEventsService(ILogger<ClientEventsService> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }
    
    /// <summary>
    /// Получить уникальные типы событий из списка событий
    /// </summary>
    /// <param name="events">Коллекция событий клиента. Может быть null.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Отсортированный список уникальных типов событий. Возвращает пустую коллекцию, если events равен null или не содержит событий.</returns>
    public IReadOnlyList<string> GetUniqueEventTypes(IEnumerable<ClientEventDto> events, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        if (events == null)
        {
            _logger.LogWarning("GetUniqueEventTypes called with null events collection");
            return Array.Empty<string>();
        }

        // Используем HashSet для уникальности и лучшей производительности
        var uniqueTypes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var processedCount = 0;
        
        foreach (var evt in events)
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            if (++processedCount > MaxEventsToProcess)
            {
                _logger.LogWarning("GetUniqueEventTypes: processed {Count} events, stopping to prevent memory issues", processedCount);
                break;
            }
            
            if (evt != null && !string.IsNullOrWhiteSpace(evt.Type))
            {
                uniqueTypes.Add(evt.Type);
            }
        }
        
        var result = uniqueTypes
            .OrderBy(t => t)
            .ToList();
        
        _logger.LogDebug("GetUniqueEventTypes: found {Count} unique types", result.Count);
        
        return result;
    }

    /// <summary>
    /// Применить фильтры к событиям
    /// </summary>
    /// <param name="events">Коллекция событий для фильтрации. Может быть null.</param>
    /// <param name="eventType">Тип события для фильтрации. Если null, пустая строка или "all", фильтр не применяется.</param>
    /// <param name="userFilter">Фильтр по пользователю. Если null или пустая строка, фильтр не применяется. Значение "system" фильтрует события без UserId.</param>
    /// <param name="dateFrom">Начальная дата диапазона. Если null, фильтр не применяется.</param>
    /// <param name="dateTo">Конечная дата диапазона. Если null, фильтр не применяется.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Отсортированный по времени (от новых к старым) список отфильтрованных событий.</returns>
    /// <exception cref="ArgumentException">Выбрасывается, если dateFrom больше dateTo или если даты невалидны.</exception>
    public IReadOnlyList<ClientEventDto> ApplyFilters(
        IEnumerable<ClientEventDto> events,
        string? eventType,
        string? userFilter,
        DateTime? dateFrom,
        DateTime? dateTo,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        if (events == null)
        {
            _logger.LogWarning("ApplyFilters called with null events collection");
            return Array.Empty<ClientEventDto>();
        }
        
        ValidateFilters(dateFrom, dateTo);

        // Один проход с применением всех фильтров
        var filtered = events
            .Where(e => e != null)
            .Where(e => string.IsNullOrWhiteSpace(eventType) || 
                        eventType == "all" || 
                        (!string.IsNullOrWhiteSpace(e.Type) && 
                         e.Type.Equals(eventType, StringComparison.OrdinalIgnoreCase)))
            .Where(e => string.IsNullOrWhiteSpace(userFilter) ||
                        (!string.IsNullOrEmpty(e.UserId) && 
                         e.UserId.Contains(userFilter, StringComparison.OrdinalIgnoreCase)) ||
                        (string.IsNullOrEmpty(e.UserId) && 
                         userFilter.Equals("system", StringComparison.OrdinalIgnoreCase)))
            .Where(e => !dateFrom.HasValue || e.Time >= dateFrom.Value)
            .Where(e => !dateTo.HasValue || e.Time <= dateTo.Value)
            .OrderByDescending(e => e.Time)
            .ToList();
        
        _logger.LogDebug("ApplyFilters: filtered {FilteredCount} events from input collection", filtered.Count);
        
        return filtered;
    }

    /// <summary>
    /// Получить отфильтрованные события для страницы
    /// </summary>
    /// <param name="events">Коллекция событий для пагинации. Может быть null.</param>
    /// <param name="page">Номер страницы (начиная с 1). Должен быть больше 0.</param>
    /// <param name="pageSize">Размер страницы. Должен быть больше 0.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список событий для указанной страницы.</returns>
    /// <exception cref="ArgumentException">Выбрасывается, если page или pageSize меньше или равны 0.</exception>
    public IReadOnlyList<ClientEventDto> GetPageEvents(
        IEnumerable<ClientEventDto> events,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        if (events == null)
        {
            _logger.LogWarning("GetPageEvents called with null events collection");
            return Array.Empty<ClientEventDto>();
        }
        
        ValidatePagination(page, pageSize);
        
        // Проверка на переполнение
        if (page > int.MaxValue / pageSize + 1)
        {
            var message = $"Page {page} with page size {pageSize} would cause overflow";
            _logger.LogError(message);
            throw new ArgumentException(message, nameof(page));
        }
        
        var skip = checked((page - 1) * pageSize);
        
        // Для IEnumerable оптимизируем: берем только необходимую страницу
        // Если нужна точная информация о количестве страниц, используйте IQueryable версию
        var result = events
            .Skip(skip)
            .Take(pageSize)
            .ToList();
        
        // Приблизительная оценка: если получили меньше pageSize, значит это последняя страница
        var estimatedTotalPages = result.Count < pageSize ? page : page + 1;
        
        _logger.LogDebug("GetPageEvents: returning {Count} events for page {Page} (estimated total: {EstimatedTotalPages})", 
            result.Count, page, estimatedTotalPages);
        
        return result;
    }

    /// <summary>
    /// Получить общее количество страниц
    /// </summary>
    /// <param name="totalEvents">Общее количество событий. Не может быть отрицательным.</param>
    /// <param name="pageSize">Размер страницы. Должен быть больше 0.</param>
    /// <returns>Количество страниц. Возвращает 0, если totalEvents равен 0.</returns>
    /// <exception cref="ArgumentException">Выбрасывается, если totalEvents отрицательное или pageSize меньше или равен 0.</exception>
    public int GetTotalPages(int totalEvents, int pageSize)
    {
        if (totalEvents < 0)
        {
            var message = "Total events cannot be negative";
            _logger.LogError(message);
            throw new ArgumentException(message, nameof(totalEvents));
        }
        
        if (pageSize < 1)
        {
            var message = "Page size must be greater than 0";
            _logger.LogError(message);
            throw new ArgumentException(message, nameof(pageSize));
        }
        
        if (pageSize > MaxPageSize)
        {
            var message = $"Page size cannot exceed {MaxPageSize}";
            _logger.LogWarning(message);
            throw new ArgumentException(message, nameof(pageSize));
        }
        
        if (totalEvents == 0) return 0;
        
        var totalPages = (int)Math.Ceiling((double)totalEvents / pageSize);
        _logger.LogDebug("GetTotalPages: {TotalEvents} events with page size {PageSize} = {TotalPages} pages", 
            totalEvents, pageSize, totalPages);
        
        return totalPages;
    }
    
    /// <summary>
    /// Получить уникальные типы событий из IQueryable (для оптимизации работы с БД)
    /// </summary>
    /// <param name="events">Queryable коллекция событий клиента</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Отсортированный список уникальных типов событий</returns>
    public Task<IReadOnlyList<string>> GetUniqueEventTypesAsync(
        IQueryable<ClientEventDto> events,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        if (events == null)
        {
            _logger.LogWarning("GetUniqueEventTypesAsync called with null events collection");
            return Task.FromResult<IReadOnlyList<string>>(Array.Empty<string>());
        }

        // Выполняем запрос синхронно, но возвращаем Task для совместимости
        // Фильтрация выполняется на уровне БД через IQueryable
        var uniqueTypes = events
            .Where(e => e != null && !string.IsNullOrWhiteSpace(e.Type))
            .Select(e => e.Type)
            .Distinct()
            .OrderBy(t => t)
            .ToList();
        
        _logger.LogDebug("GetUniqueEventTypesAsync: found {Count} unique types", uniqueTypes.Count);
        
        return Task.FromResult<IReadOnlyList<string>>(uniqueTypes);
    }

    /// <summary>
    /// Применить фильтры к событиям из IQueryable (для оптимизации работы с БД)
    /// </summary>
    /// <param name="events">Queryable коллекция событий для фильтрации</param>
    /// <param name="eventType">Тип события для фильтрации. Если null, пустая строка или "all", фильтр не применяется.</param>
    /// <param name="userFilter">Фильтр по пользователю. Если null или пустая строка, фильтр не применяется. Значение "system" фильтрует события без UserId.</param>
    /// <param name="dateFrom">Начальная дата диапазона. Если null, фильтр не применяется.</param>
    /// <param name="dateTo">Конечная дата диапазона. Если null, фильтр не применяется.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Отсортированный по времени (от новых к старым) список отфильтрованных событий.</returns>
    /// <exception cref="ArgumentException">Выбрасывается, если dateFrom больше dateTo или если даты невалидны.</exception>
    /// <exception cref="InvalidOperationException">Выбрасывается, если провайдер запросов не поддерживает операцию.</exception>
    public Task<IReadOnlyList<ClientEventDto>> ApplyFiltersAsync(
        IQueryable<ClientEventDto> events,
        string? eventType,
        string? userFilter,
        DateTime? dateFrom,
        DateTime? dateTo,
        CancellationToken cancellationToken = default)
    {
        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            if (events == null)
            {
                _logger.LogWarning("ApplyFiltersAsync called with null events collection");
                return Task.FromResult<IReadOnlyList<ClientEventDto>>(Array.Empty<ClientEventDto>());
            }
            
            ValidateFilters(dateFrom, dateTo);

            // Применяем фильтры, которые можно выполнить на уровне БД
            var query = events.Where(e => e != null);
            
            // Фильтры по датам можно применить на уровне БД
            if (dateFrom.HasValue)
            {
                query = query.Where(e => e.Time >= dateFrom.Value);
            }
            
            if (dateTo.HasValue)
            {
                query = query.Where(e => e.Time <= dateTo.Value);
            }
            
            // Для регистронезависимого сравнения в IQueryable нужно материализовать данные
            // Материализуем один раз после применения фильтров по датам
            var materialized = query.ToList();
            
            // Применяем фильтры по типу события и пользователю в памяти
            var isSystemFilter = !string.IsNullOrWhiteSpace(userFilter) && 
                                 userFilter.Equals("system", StringComparison.OrdinalIgnoreCase);
            
            var filtered = materialized.AsEnumerable();
            
            if (!string.IsNullOrWhiteSpace(eventType) && eventType != "all")
            {
                var lowerEventType = eventType.ToLower();
                filtered = filtered.Where(e => !string.IsNullOrWhiteSpace(e.Type) && 
                                               e.Type.ToLower() == lowerEventType);
            }
            
            if (!string.IsNullOrWhiteSpace(userFilter))
            {
                if (isSystemFilter)
                {
                    filtered = filtered.Where(e => string.IsNullOrEmpty(e.UserId));
                }
                else
                {
                    var lowerFilter = userFilter.ToLower();
                    filtered = filtered.Where(e => !string.IsNullOrEmpty(e.UserId) && 
                                                   e.UserId.ToLower().Contains(lowerFilter));
                }
            }
            
            // Сортировка и финальная материализация
            var result = filtered
                .OrderByDescending(e => e.Time)
                .ToList();
            
            _logger.LogDebug("ApplyFiltersAsync: filtered {FilteredCount} events from query", result.Count);
            
            return Task.FromResult<IReadOnlyList<ClientEventDto>>(result);
        }
        catch (NotSupportedException ex)
        {
            _logger.LogError(ex, "Query provider does not support the requested operation");
            throw new InvalidOperationException("The query cannot be executed with the current provider", ex);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing query in ApplyFiltersAsync");
            throw;
        }
    }

    /// <summary>
    /// Получить отфильтрованные события для страницы из IQueryable (для оптимизации работы с БД)
    /// </summary>
    /// <param name="events">Queryable коллекция событий для пагинации</param>
    /// <param name="page">Номер страницы (начиная с 1). Должен быть больше 0.</param>
    /// <param name="pageSize">Размер страницы. Должен быть больше 0.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список событий для указанной страницы.</returns>
    /// <exception cref="ArgumentException">Выбрасывается, если page или pageSize меньше или равны 0.</exception>
    /// <exception cref="InvalidOperationException">Выбрасывается, если провайдер запросов не поддерживает операцию.</exception>
    public Task<IReadOnlyList<ClientEventDto>> GetPageEventsAsync(
        IQueryable<ClientEventDto> events,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default)
    {
        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            if (events == null)
            {
                _logger.LogWarning("GetPageEventsAsync called with null events collection");
                return Task.FromResult<IReadOnlyList<ClientEventDto>>(Array.Empty<ClientEventDto>());
            }
            
            ValidatePagination(page, pageSize);
            
            // Проверка на переполнение
            if (page > int.MaxValue / pageSize + 1)
            {
                var message = $"Page {page} with page size {pageSize} would cause overflow";
                _logger.LogError(message);
                throw new ArgumentException(message, nameof(page));
            }
            
            var skip = checked((page - 1) * pageSize);
            
            // Фильтрация и пагинация выполняются на уровне БД через IQueryable
            var totalCount = events.Count();
            var totalPages = GetTotalPages(totalCount, pageSize);
            
            if (page > totalPages && totalPages > 0)
            {
                _logger.LogDebug("GetPageEventsAsync: requested page {Page} is greater than total pages {TotalPages}, returning empty collection", 
                    page, totalPages);
                return Task.FromResult<IReadOnlyList<ClientEventDto>>(Array.Empty<ClientEventDto>());
            }
            
            var result = events
                .Skip(skip)
                .Take(pageSize)
                .ToList();
            
            _logger.LogDebug("GetPageEventsAsync: returning {Count} events for page {Page} of {TotalPages}", 
                result.Count, page, totalPages);
            
            return Task.FromResult<IReadOnlyList<ClientEventDto>>(result);
        }
        catch (NotSupportedException ex)
        {
            _logger.LogError(ex, "Query provider does not support the requested operation");
            throw new InvalidOperationException("The query cannot be executed with the current provider", ex);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing query in GetPageEventsAsync");
            throw;
        }
    }
    
    /// <summary>
    /// Проверяет, является ли DateTime валидным значением
    /// </summary>
    /// <param name="dateTime">Дата для проверки</param>
    /// <returns>true, если дата валидна, иначе false</returns>
    private static bool IsValidDateTime(DateTime dateTime)
    {
        return dateTime != DateTime.MinValue && 
               dateTime != DateTime.MaxValue &&
               dateTime.Year >= 1900 && 
               dateTime.Year <= 2100;
    }
    
    /// <summary>
    /// Валидирует параметры фильтрации дат
    /// </summary>
    /// <param name="dateFrom">Начальная дата диапазона</param>
    /// <param name="dateTo">Конечная дата диапазона</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    private void ValidateFilters(DateTime? dateFrom, DateTime? dateTo)
    {
        if (dateFrom.HasValue && dateTo.HasValue && dateFrom.Value > dateTo.Value)
        {
            var message = "DateFrom cannot be greater than DateTo";
            _logger.LogError(message);
            throw new ArgumentException(message, nameof(dateFrom));
        }
        
        if (dateFrom.HasValue && !IsValidDateTime(dateFrom.Value))
        {
            var message = "Invalid DateFrom value";
            _logger.LogError(message);
            throw new ArgumentException(message, nameof(dateFrom));
        }
        
        if (dateTo.HasValue && !IsValidDateTime(dateTo.Value))
        {
            var message = "Invalid DateTo value";
            _logger.LogError(message);
            throw new ArgumentException(message, nameof(dateTo));
        }
    }
    
    /// <summary>
    /// Валидирует параметры пагинации
    /// </summary>
    /// <param name="page">Номер страницы</param>
    /// <param name="pageSize">Размер страницы</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    private void ValidatePagination(int page, int pageSize)
    {
        if (page < 1)
        {
            var message = "Page must be greater than 0";
            _logger.LogError(message);
            throw new ArgumentException(message, nameof(page));
        }
        
        if (pageSize < 1)
        {
            var message = "Page size must be greater than 0";
            _logger.LogError(message);
            throw new ArgumentException(message, nameof(pageSize));
        }
        
        if (pageSize > MaxPageSize)
        {
            var message = $"Page size cannot exceed {MaxPageSize}";
            _logger.LogWarning(message);
            throw new ArgumentException(message, nameof(pageSize));
        }
    }
}

