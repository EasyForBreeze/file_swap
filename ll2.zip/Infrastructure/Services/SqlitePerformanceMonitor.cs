using System.Collections.Concurrent;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Централизованный мониторинг производительности всех SQLite операций.
/// Этот класс является потокобезопасным и может использоваться из любого количества потоков одновременно.
/// Все операции используют lock-free алгоритмы для максимальной производительности.
/// </summary>
/// <remarks>
/// <para>
/// Thread-safety гарантируется через использование:
/// - <see cref="ConcurrentDictionary{TKey, TValue}"/> для хранения статистики
/// - <see cref="Interlocked"/> операций для атомарного обновления счетчиков
/// - Lock-free алгоритмы для чтения статистики
/// - Версионирование для обеспечения консистентности данных при одновременных операциях чтения и сброса
/// </para>
/// <para>
/// Внимание: Методы Reset* могут привести к временной рассинхронизации общей статистики
/// во время высоких нагрузок. Используйте их с осторожностью.
/// </para>
/// <para>
/// Все методы являются thread-safe и могут вызываться из любого количества потоков одновременно.
/// Операции записи (RecordOperation) не блокируют операции чтения (GetTotalStats, GetDatabaseStats, GetAllDatabaseStats).
/// </para>
/// </remarks>
public static class SqlitePerformanceMonitor
{
    private static readonly ConcurrentDictionary<string, DatabaseStats> _databaseStats = new();
    
    // Общая статистика по всем БД (используем long вместо int для защиты от переполнения)
    private static long _totalResponseTimeMs = 0;
    private static long _totalRequestCount = 0;
    
    // Проблема #14: Версионирование для атомарных снимков
    private static long _version = 0;
    
    // Проблема #10: Логирование ошибок
    private static Action<string, Exception>? _errorLogger;
    
    // Проблема #11: Защита от слишком больших значений
    private const long MaxReasonableElapsedMs = 3600000; // 1 час (3,600,000 мс)
    
    // Проблема #12: События для мониторинга
    private const long SlowOperationThresholdMs = 1000; // 1 секунда
    
    // Проблема #16: Производительность самого мониторинга
    private static long _isEnabled = 1; // 1 = enabled, 0 = disabled (используем long для Interlocked.Read)
    
    // Проблема #17: Защита от DoS через большое количество уникальных БД
    private const int MaxTrackedDatabases = 1000;
    
    // Проблема #26: Счетчик отслеживаемых БД для оптимизации производительности
    private static long _trackedDatabasesCount = 0;
    
    // Проблема #18: Метрики производительности самого мониторинга
    private static long _monitorOverheadMs = 0;
    private static long _monitorOperationsCount = 0;
    
    /// <summary>
    /// Событие, возникающее при записи операции
    /// </summary>
    public static event Action<string, long>? OperationRecorded;
    
    /// <summary>
    /// Событие, возникающее при превышении порогового времени выполнения
    /// </summary>
    public static event Action<string, long>? SlowOperationDetected;
    
    /// <summary>
    /// Включить или отключить мониторинг производительности
    /// Проблема #16: Возможность отключения мониторинга для повышения производительности
    /// </summary>
    /// <param name="enabled">true для включения, false для отключения</param>
    public static void SetEnabled(bool enabled)
    {
        Interlocked.Exchange(ref _isEnabled, enabled ? 1L : 0L);
    }
    
    /// <summary>
    /// Проверить, включен ли мониторинг
    /// </summary>
    public static bool IsEnabled => Interlocked.Read(ref _isEnabled) == 1;
    
    /// <summary>
    /// Установить логгер для ошибок
    /// Проблема #10: Решение проблемы отсутствия логирования
    /// </summary>
    /// <param name="logger">Callback для логирования ошибок (message, exception)</param>
    public static void SetErrorLogger(Action<string, Exception> logger)
    {
        _errorLogger = logger;
    }
    
    /// <summary>
    /// Логирование ошибки
    /// </summary>
    private static void LogError(string message, Exception? exception = null)
    {
        _errorLogger?.Invoke(message, exception ?? new InvalidOperationException(message));
    }
    
    /// <summary>
    /// Статистика по конкретной БД
    /// </summary>
    private class DatabaseStats
    {
        private long _totalTimeMs = 0;
        private long _requestCount = 0; // Изменено с int на long для защиты от переполнения
        
        // Проблема #15: Отслеживание времени последнего использования
        private long _lastAccessTimeTicks = DateTime.UtcNow.Ticks;
        
        public string DatabaseName { get; init; } = string.Empty;
        
        /// <summary>
        /// Получить текущее значение общего времени (без блокировок)
        /// </summary>
        public long TotalTimeMs => _totalTimeMs;
        
        /// <summary>
        /// Получить текущее значение количества запросов (без блокировок)
        /// </summary>
        public long RequestCount => _requestCount;
        
        /// <summary>
        /// Добавить время атомарно
        /// </summary>
        public void AddTime(long elapsedMs)
        {
            Interlocked.Add(ref _totalTimeMs, elapsedMs);
        }
        
        /// <summary>
        /// Увеличить счетчик запросов атомарно
        /// </summary>
        public void IncrementCount()
        {
            Interlocked.Increment(ref _requestCount);
        }
        
        /// <summary>
        /// Сбросить статистику атомарно
        /// </summary>
        public (long TotalTimeMs, long RequestCount) Reset()
        {
            var totalTime = Interlocked.Exchange(ref _totalTimeMs, 0);
            var requestCount = Interlocked.Exchange(ref _requestCount, 0);
            return (totalTime, requestCount);
        }
        
        /// <summary>
        /// Получить снимок статистики (атомарное чтение)
        /// </summary>
        public (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetSnapshot()
        {
            // Атомарное чтение long значений через Interlocked
            var count = _requestCount;
            var total = _totalTimeMs;
            var average = count > 0 ? (double)total / count : 0;
            return (total, count, average);
        }
        
        /// <summary>
        /// Обновить время последнего доступа
        /// Проблема #15: Отслеживание времени последнего использования
        /// </summary>
        public void UpdateAccessTime()
        {
            Interlocked.Exchange(ref _lastAccessTimeTicks, DateTime.UtcNow.Ticks);
        }
        
        /// <summary>
        /// Получить время последнего доступа
        /// </summary>
        public DateTime LastAccessTime => new DateTime(Interlocked.Read(ref _lastAccessTimeTicks));
        
        /// <summary>
        /// Получить снимок со временем последнего доступа
        /// </summary>
        public (long TotalTimeMs, long RequestCount, double AverageTimeMs, DateTime LastAccessTime) GetSnapshotWithAccessTime()
        {
            var snapshot = GetSnapshot();
            return (snapshot.TotalTimeMs, snapshot.RequestCount, snapshot.AverageTimeMs, LastAccessTime);
        }
    }
    
    /// <summary>
    /// Записать время выполнения операции в статистику
    /// </summary>
    /// <param name="databaseName">Название БД (например, "audit", "wiki_pages", "forbidden_clients")</param>
    /// <param name="elapsedMs">Время выполнения в миллисекундах</param>
    /// <exception cref="ArgumentException">Когда databaseName null или пустая строка</exception>
    /// <exception cref="ArgumentOutOfRangeException">Когда elapsedMs отрицательное</exception>
    public static void RecordOperation(string databaseName, long elapsedMs)
    {
        // Проблема #16, #20: Быстрый выход, если мониторинг отключен (до создания Stopwatch)
        if (Interlocked.Read(ref _isEnabled) == 0)
            return;
        
        // Проблема #18: Измерение производительности самого мониторинга (создается только если мониторинг включен)
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        
        try
        {
            // Проблема #5: Валидация входных данных
            if (string.IsNullOrWhiteSpace(databaseName))
                throw new ArgumentException("Database name cannot be null or whitespace.", nameof(databaseName));
            
            if (elapsedMs < 0)
                throw new ArgumentOutOfRangeException(nameof(elapsedMs), "Elapsed time cannot be negative.");
            
            // Проблема #19, #26: Атомарная проверка лимита БД с использованием собственного счетчика
            var currentCount = Interlocked.Read(ref _trackedDatabasesCount);
            if (currentCount >= MaxTrackedDatabases)
            {
                // Проверяем, существует ли уже эта БД
                if (!_databaseStats.ContainsKey(databaseName))
                {
                    LogError($"Maximum number of tracked databases ({MaxTrackedDatabases}) reached. Ignoring '{databaseName}'.");
                    return;
                }
                // Если БД уже существует, продолжаем работу
            }
            
            // Проблема #11: Защита от слишком больших значений
            if (elapsedMs > MaxReasonableElapsedMs)
            {
                LogError($"Suspiciously large elapsed time: {elapsedMs}ms for database '{databaseName}'. Limiting to {MaxReasonableElapsedMs}ms.");
                elapsedMs = MaxReasonableElapsedMs; // Ограничиваем значение
            }
            
            // Проблема #4: Проверка на переполнение счетчика
            if (_totalRequestCount == long.MaxValue)
            {
                LogError("Total request count reached maximum value. Resetting all statistics.");
                // Автоматический сброс при переполнении
                ResetAllStats();
            }
            
            // Проблема #1, #2, #26: Используем lock-free подход с Interlocked операциями
            var dbStats = _databaseStats.GetOrAdd(databaseName, _ =>
            {
                // Увеличиваем счетчик только при создании новой записи
                Interlocked.Increment(ref _trackedDatabasesCount);
                return new DatabaseStats 
                { 
                    DatabaseName = databaseName 
                };
            });
            
            // Проблема #15: Обновление времени последнего доступа
            dbStats.UpdateAccessTime();
            
            // Lock-free операции для обновления статистики БД
            dbStats.AddTime(elapsedMs);
            dbStats.IncrementCount();
            
            // Lock-free операции для обновления общей статистики
            Interlocked.Add(ref _totalResponseTimeMs, elapsedMs);
            Interlocked.Increment(ref _totalRequestCount);
            Interlocked.Increment(ref _version);
            
            // Проблема #12: События для мониторинга в реальном времени
            OnOperationRecorded(databaseName, elapsedMs);
        }
        finally
        {
            // Проблема #18, #21: Учет накладных расходов мониторинга (используем Ticks для точности)
            stopwatch.Stop();
            var overheadTicks = stopwatch.ElapsedTicks;
            if (overheadTicks > 0)
            {
                // Конвертируем в миллисекунды для более точного измерения
                var overheadMs = (long)(overheadTicks * 1000.0 / System.Diagnostics.Stopwatch.Frequency);
                Interlocked.Add(ref _monitorOverheadMs, overheadMs);
                Interlocked.Increment(ref _monitorOperationsCount);
            }
        }
    }
    
    /// <summary>
    /// Обработка события записи операции
    /// Проблема #23: Обработка исключений в обработчиках событий
    /// </summary>
    private static void OnOperationRecorded(string databaseName, long elapsedMs)
    {
        try
        {
            OperationRecorded?.Invoke(databaseName, elapsedMs);
        }
        catch (Exception ex)
        {
            LogError($"Error in OperationRecorded event handler: {ex.Message}", ex);
        }
        
        if (elapsedMs > SlowOperationThresholdMs)
        {
            try
            {
                SlowOperationDetected?.Invoke(databaseName, elapsedMs);
            }
            catch (Exception ex)
            {
                LogError($"Error in SlowOperationDetected event handler: {ex.Message}", ex);
            }
        }
    }
    
    /// <summary>
    /// Получить общую статистику по всем SQLite БД
    /// Проблема #14, #22, #27: Атомарное чтение с версионированием и защитой от бесконечного цикла
    /// </summary>
    public static (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetTotalStats()
    {
        long version;
        long totalTime;
        long requestCount;
        const int maxRetries = 100;
        int retries = 0;
        
        // Атомарное чтение с версионированием для защиты от race condition
        // Проблема #27: Используем Interlocked.Read() для явной атомарности
        do
        {
            version = Interlocked.Read(ref _version);
            totalTime = Interlocked.Read(ref _totalResponseTimeMs);
            requestCount = Interlocked.Read(ref _totalRequestCount);
            retries++;
        } while (version != Interlocked.Read(ref _version) && retries < maxRetries);
        
        // Проблема #22: Если превышено количество попыток, используем последние прочитанные значения
        if (retries >= maxRetries)
        {
            LogError("GetTotalStats: exceeded maximum retries, using last read values");
        }
        
        var averageTime = requestCount > 0 ? (double)totalTime / requestCount : 0;
        return (totalTime, requestCount, averageTime);
    }
    
    /// <summary>
    /// Получить статистику по конкретной БД
    /// </summary>
    /// <param name="databaseName">Название БД</param>
    /// <exception cref="ArgumentException">Когда databaseName null или пустая строка</exception>
    public static (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetDatabaseStats(string databaseName)
    {
        // Проблема #5: Валидация входных данных
        if (string.IsNullOrWhiteSpace(databaseName))
            throw new ArgumentException("Database name cannot be null or whitespace.", nameof(databaseName));
        
        if (_databaseStats.TryGetValue(databaseName, out var stats))
        {
            return stats.GetSnapshot(); // Lock-free атомарное чтение
        }
        
        return (0, 0, 0);
    }
    
    /// <summary>
    /// Получить статистику по всем БД
    /// </summary>
    public static Dictionary<string, (long TotalTimeMs, long RequestCount, double AverageTimeMs)> GetAllDatabaseStats()
    {
        var result = new Dictionary<string, (long TotalTimeMs, long RequestCount, double AverageTimeMs)>();
        
        // Проблема #6: Используем снимок ключей для безопасной итерации
        var keys = _databaseStats.Keys.ToArray();
        
        foreach (var key in keys)
        {
            if (_databaseStats.TryGetValue(key, out var stats))
            {
                // Атомарное чтение через snapshot
                result[key] = stats.GetSnapshot();
            }
        }
        
        return result;
    }
    
    /// <summary>
    /// Сбросить всю статистику
    /// </summary>
    public static void ResetAllStats()
    {
        // Атомарный сброс общей статистики
        Interlocked.Exchange(ref _totalResponseTimeMs, 0);
        Interlocked.Exchange(ref _totalRequestCount, 0);
        Interlocked.Increment(ref _version);
        
        // Сброс статистики каждой БД
        var keys = _databaseStats.Keys.ToArray();
        foreach (var key in keys)
        {
            if (_databaseStats.TryGetValue(key, out var stats))
            {
                stats.Reset();
            }
        }
        
        // Проблема #26: Счетчик отслеживаемых БД не сбрасываем, так как записи остаются в словаре
        // Если нужно сбросить счетчик, нужно очистить словарь через RemoveDatabaseStats
    }
    
    /// <summary>
    /// Сбросить статистику конкретной БД
    /// </summary>
    /// <param name="databaseName">Название БД</param>
    /// <exception cref="ArgumentException">Когда databaseName null или пустая строка</exception>
    public static void ResetDatabaseStats(string databaseName)
    {
        // Проблема #5: Валидация входных данных
        if (string.IsNullOrWhiteSpace(databaseName))
            throw new ArgumentException("Database name cannot be null or whitespace.", nameof(databaseName));
        
        // Проблема #7: Синхронизация сброса с общей статистикой
        if (_databaseStats.TryGetValue(databaseName, out var stats))
        {
            var (totalTime, requestCount) = stats.Reset();
            
            // Вычитаем из общей статистики для синхронизации
            Interlocked.Add(ref _totalResponseTimeMs, -totalTime);
            Interlocked.Add(ref _totalRequestCount, -requestCount);
            Interlocked.Increment(ref _version);
        }
    }
    
    /// <summary>
    /// Удалить статистику конкретной БД из словаря
    /// Проблема #3: Решение проблемы утечки памяти
    /// </summary>
    /// <param name="databaseName">Название БД</param>
    /// <returns>true если статистика была удалена, false если БД не найдена</returns>
    /// <exception cref="ArgumentException">Когда databaseName null или пустая строка</exception>
    public static bool RemoveDatabaseStats(string databaseName)
    {
        if (string.IsNullOrWhiteSpace(databaseName))
            throw new ArgumentException("Database name cannot be null or whitespace.", nameof(databaseName));
        
        if (_databaseStats.TryRemove(databaseName, out var removedStats))
        {
            // Вычитаем из общей статистики перед удалением
            var snapshot = removedStats.GetSnapshot();
            Interlocked.Add(ref _totalResponseTimeMs, -snapshot.TotalTimeMs);
            Interlocked.Add(ref _totalRequestCount, -snapshot.RequestCount);
            Interlocked.Increment(ref _version);
            
            // Проблема #26: Уменьшаем счетчик отслеживаемых БД
            Interlocked.Decrement(ref _trackedDatabasesCount);
            
            return true;
        }
        
        return false;
    }
    
    /// <summary>
    /// Получить статистику в формате JSON
    /// Проблема #13: Экспорт статистики для анализа или мониторинга
    /// </summary>
    /// <returns>JSON строка со всей статистикой</returns>
    public static string ToJson()
    {
        var stats = new
        {
            Total = GetTotalStats(),
            Databases = GetAllDatabaseStats(),
            Timestamp = DateTime.UtcNow,
            Version = Interlocked.Read(ref _version)
        };
        
        return JsonSerializer.Serialize(stats, new JsonSerializerOptions 
        { 
            WriteIndented = true 
        });
    }
    
    /// <summary>
    /// Получить статистику в формате JSON (асинхронно)
    /// </summary>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>JSON строка со всей статистикой</returns>
    public static async Task<string> ToJsonAsync(CancellationToken cancellationToken = default)
    {
        // Для больших объемов данных можно использовать асинхронную сериализацию
        return await Task.Run(() => ToJson(), cancellationToken);
    }
    
    /// <summary>
    /// Получить метрики производительности самого мониторинга
    /// Проблема #18, #25: Метрики производительности мониторинга с улучшенной проверкой
    /// </summary>
    /// <returns>Общее время накладных расходов, количество операций и среднее время</returns>
    public static (long OverheadMs, long OperationsCount, double AverageOverheadMs) GetMonitorStats()
    {
        var operationsCount = _monitorOperationsCount;
        var overheadMs = _monitorOverheadMs;
        
        // Проблема #25: Более явная проверка на нулевые значения
        if (operationsCount <= 0)
        {
            return (0, 0, 0);
        }
        
        var average = (double)overheadMs / operationsCount;
        return (overheadMs, operationsCount, average);
    }
    
    /// <summary>
    /// Очистить статистику для БД, которые не использовались длительное время
    /// Проблема #15, #24: Использование информации о времени последнего доступа с атомарным удалением
    /// </summary>
    /// <param name="inactivityThreshold">Порог неактивности (БД не использовалась дольше этого времени)</param>
    /// <returns>Количество удаленных записей</returns>
    public static int CleanupInactiveDatabases(TimeSpan inactivityThreshold)
    {
        if (inactivityThreshold <= TimeSpan.Zero)
            throw new ArgumentException("Inactivity threshold must be positive.", nameof(inactivityThreshold));
        
        var cutoffTime = DateTime.UtcNow - inactivityThreshold;
        int removedCount = 0;
        
        // Проблема #24: Удаляем сразу при обнаружении, чтобы избежать race condition
        var keys = _databaseStats.Keys.ToArray();
        foreach (var key in keys)
        {
            if (_databaseStats.TryGetValue(key, out var stats))
            {
                // Атомарная проверка и удаление
                if (stats.LastAccessTime < cutoffTime)
                {
                    if (RemoveDatabaseStats(key))
                    {
                        removedCount++;
                    }
                }
            }
        }
        
        return removedCount;
    }
    
    /// <summary>
    /// Получить статистику по всем БД с информацией о времени последнего доступа
    /// Проблема #15: Расширенная статистика с временем доступа
    /// </summary>
    public static Dictionary<string, (long TotalTimeMs, long RequestCount, double AverageTimeMs, DateTime LastAccessTime)> GetAllDatabaseStatsWithAccessTime()
    {
        var result = new Dictionary<string, (long TotalTimeMs, long RequestCount, double AverageTimeMs, DateTime LastAccessTime)>();
        
        var keys = _databaseStats.Keys.ToArray();
        foreach (var key in keys)
        {
            if (_databaseStats.TryGetValue(key, out var stats))
            {
                result[key] = stats.GetSnapshotWithAccessTime();
            }
        }
        
        return result;
    }
    
    /// <summary>
    /// Получить статистику по конкретной БД с информацией о времени последнего доступа
    /// </summary>
    public static (long TotalTimeMs, long RequestCount, double AverageTimeMs, DateTime LastAccessTime)? GetDatabaseStatsWithAccessTime(string databaseName)
    {
        if (string.IsNullOrWhiteSpace(databaseName))
            throw new ArgumentException("Database name cannot be null or whitespace.", nameof(databaseName));
        
        if (_databaseStats.TryGetValue(databaseName, out var stats))
        {
            return stats.GetSnapshotWithAccessTime();
        }
        
        return null;
    }
}
