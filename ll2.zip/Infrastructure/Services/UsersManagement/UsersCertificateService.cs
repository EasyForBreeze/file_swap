using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services.UsersManagement;

/// <summary>
/// Сервис для работы с сертификатами пользователей через users-management API
/// </summary>
public class UsersCertificateService : UsersManagementBaseService, IUsersCertificateService
{
    // Константы для валидации
    private const long MaxCertificateSizeBytes = 10 * 1024 * 1024; // 10 MB
    private const int MaxRealmLength = 100;
    private const int MaxUserIdLength = 200;
    private const int MaxFileNameLength = 255;
    private const int CertificateUploadTimeoutMinutes = 5;
    private const int MaxErrorContentLength = 1000; // Максимальная длина сообщения об ошибке

    // Регулярное выражение для валидации realm
    private static readonly Regex RealmNameRegex = new(
        @"^[a-zA-Z0-9_-]+$",
        RegexOptions.Compiled);

    // Блокировки для предотвращения дублирования операций
    private static readonly ConcurrentDictionary<string, SemaphoreSlim> _operationLocks = new();

    /// <summary>
    /// Константы для событий аудита
    /// </summary>
    private static class AuditEventTypes
    {
        public const string UserCertificateAdded = "UserCertificateAdded";
        public const string UserCertificateDeleted = "UserCertificateDeleted";
        public const string UserCertificateRetrieved = "UserCertificateRetrieved";
    }

    public UsersCertificateService(
        HttpClient httpClient,
        Microsoft.Extensions.Options.IOptions<new_assistant.Configuration.KeycloakAdminSettings> settings,
        new_assistant.Core.Interfaces.IAuditService auditService,
        Microsoft.AspNetCore.Http.IHttpContextAccessor httpContextAccessor,
        new_assistant.Core.Interfaces.ITokenExchangeService tokenExchangeService,
        new_assistant.Core.Interfaces.IPerformanceMetricsService metricsService,
        ILogger<UsersCertificateService> logger)
        : base(httpClient, settings, auditService, httpContextAccessor, tokenExchangeService, metricsService, logger)
    {
    }

    /// <summary>
    /// Валидация формата realm
    /// </summary>
    private void ValidateRealmFormat(string realm)
    {
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));

        if (realm.Length > MaxRealmLength)
            throw new ArgumentException($"Realm length ({realm.Length}) exceeds maximum allowed length ({MaxRealmLength})", nameof(realm));

        if (!RealmNameRegex.IsMatch(realm))
            throw new ArgumentException(
                "Realm name contains invalid characters. Only letters, numbers, underscores and hyphens are allowed",
                nameof(realm));

        // Проверка на control characters
        if (realm.Any(c => char.IsControl(c)))
            throw new ArgumentException("Realm cannot contain control characters", nameof(realm));
    }

    /// <summary>
    /// Валидация формата userId
    /// </summary>
    private void ValidateUserIdFormat(string userId)
    {
        if (string.IsNullOrWhiteSpace(userId))
            throw new ArgumentException("User ID cannot be null or empty", nameof(userId));

        if (userId.Length > MaxUserIdLength)
            throw new ArgumentException($"User ID length ({userId.Length}) exceeds maximum allowed length ({MaxUserIdLength})", nameof(userId));

        // Проверка на control characters
        if (userId.Any(c => char.IsControl(c)))
            throw new ArgumentException("User ID cannot contain control characters", nameof(userId));

        // Проверка на опасные символы для URL
        if (userId.Contains("/") || userId.Contains("\\") || userId.Contains("?") ||
            userId.Contains("#") || userId.Contains("&") || userId.Contains("="))
        {
            throw new ArgumentException("User ID contains invalid characters for URL", nameof(userId));
        }
    }

    /// <summary>
    /// Валидация имени файла
    /// </summary>
    private static void ValidateFileName(string fileName)
    {
        if (string.IsNullOrWhiteSpace(fileName))
            throw new ArgumentException("File name cannot be null or empty", nameof(fileName));

        // Защита от path traversal
        if (fileName.Contains("..") || fileName.Contains("/") || fileName.Contains("\\"))
        {
            throw new ArgumentException("File name contains invalid characters", nameof(fileName));
        }

        // Проверка длины
        if (fileName.Length > MaxFileNameLength)
        {
            throw new ArgumentException($"File name is too long (max {MaxFileNameLength} characters)", nameof(fileName));
        }

        // Проверка на недопустимые символы для имен файлов
        var invalidChars = Path.GetInvalidFileNameChars();
        if (fileName.IndexOfAny(invalidChars) >= 0)
        {
            throw new ArgumentException("File name contains invalid characters", nameof(fileName));
        }
    }

    /// <summary>
    /// Валидация размера сертификата
    /// </summary>
    private void ValidateCertificateSize(Stream certificateStream)
    {
        if (certificateStream == null)
            throw new ArgumentNullException(nameof(certificateStream));

        if (!certificateStream.CanRead)
            throw new ArgumentException("Stream is not readable", nameof(certificateStream));

        if (certificateStream.CanSeek)
        {
            certificateStream.Seek(0, SeekOrigin.Begin);
            if (certificateStream.Length > MaxCertificateSizeBytes)
            {
                Logger.LogWarning("Попытка загрузки сертификата превышающего максимальный размер: {Size} bytes", certificateStream.Length);
                throw new ArgumentException($"Размер сертификата превышает максимально допустимый ({MaxCertificateSizeBytes / 1024 / 1024} MB)", nameof(certificateStream));
            }
            certificateStream.Seek(0, SeekOrigin.Begin);
        }
        // Для не-seekable потоков валидация размера будет происходить во время чтения
    }

    /// <summary>
    /// Валидация формата сертификата
    /// </summary>
    private async Task<bool> ValidateCertificateFormatAsync(Stream certificateStream)
    {
        try
        {
            if (certificateStream.CanSeek)
            {
                certificateStream.Seek(0, SeekOrigin.Begin);
            }

            // Преобразуем Stream в byte[] для конструктора X509Certificate2
            byte[] certificateBytes;
            using (var memoryStream = new MemoryStream())
            {
                await certificateStream.CopyToAsync(memoryStream).ConfigureAwait(false);
                certificateBytes = memoryStream.ToArray();
            }

            // Пытаемся загрузить как X.509 сертификат
#pragma warning disable SYSLIB0057 // X509Certificate2 constructor is obsolete, but still functional
            using var certificate = new X509Certificate2(certificateBytes);
#pragma warning restore SYSLIB0057

            // Дополнительная проверка: сертификат должен быть валидным
            // X509Certificate2 не может быть null, проверяем только Thumbprint и другие свойства
            if (string.IsNullOrEmpty(certificate.Thumbprint) ||
                certificate.Subject == null ||
                certificate.Issuer == null)
            {
                return false;
            }

            return true;
        }
        catch (Exception ex)
        {
            Logger.LogWarning(ex, "Не удалось валидировать формат сертификата");
            return false;
        }
        finally
        {
            if (certificateStream.CanSeek)
            {
                certificateStream.Seek(0, SeekOrigin.Begin);
            }
        }
    }

    /// <summary>
    /// Прочитать содержимое ошибки из HTTP ответа с ограничением размера
    /// </summary>
    private async Task<string> ReadErrorContentAsync(HttpResponseMessage response, CancellationToken cancellationToken)
    {
        if (response.Content == null)
            return string.Empty;

        try
        {
            var content = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            // Ограничиваем размер ошибки для предотвращения проблем с памятью
            if (content.Length > MaxErrorContentLength)
            {
                return content.Substring(0, MaxErrorContentLength) + "...";
            }
            return content;
        }
        catch (Exception ex)
        {
            Logger.LogWarning(ex, "Не удалось прочитать содержимое ошибки");
            return string.Empty;
        }
    }

    /// <summary>
    /// Валидация Base64 строки
    /// </summary>
    private static bool IsValidBase64(string base64String)
    {
        if (string.IsNullOrWhiteSpace(base64String))
            return false;

        try
        {
            Convert.FromBase64String(base64String);
            return true;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Обработка и санитизация имени файла для безопасной передачи
    /// </summary>
    private static string SanitizeFileName(string fileName)
    {
        // Убрать путь, если есть
        var sanitized = Path.GetFileName(fileName);
        
        // Убрать любые оставшиеся небезопасные символы
        var invalidChars = Path.GetInvalidFileNameChars();
        foreach (var invalidChar in invalidChars)
        {
            sanitized = sanitized.Replace(invalidChar, '_');
        }
        
        // Ограничить длину
        if (sanitized.Length > MaxFileNameLength)
        {
            var extension = Path.GetExtension(sanitized);
            var nameWithoutExt = Path.GetFileNameWithoutExtension(sanitized);
            var maxNameLength = MaxFileNameLength - extension.Length;
            sanitized = nameWithoutExt.Substring(0, Math.Min(nameWithoutExt.Length, maxNameLength)) + extension;
        }
        
        return sanitized;
    }

    /// <summary>
    /// Получить сертификат пользователя в формате Base64 (X.509)
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации</param>
    /// <param name="realm">Название реалма Keycloak</param>
    /// <param name="userId">Идентификатор пользователя</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Сертификат в формате Base64 или null, если сертификат не найден</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибке HTTP запроса</exception>
    public async Task<string?> GetUserCertificateAsync(
        string accessToken,
        string realm,
        string userId,
        CancellationToken cancellationToken = default)
    {
        ValidateCommonParameters(accessToken, realm, "GetUserCertificate");
        ValidateRealmFormat(realm);
        ValidateUserIdFormat(userId);

        try
        {
            var endpoint = $"auth/realms/{realm}/users-management/{ApiVersionV1}/users/{userId}/certificate";
            
            Logger.LogDebug("Запрос сертификата пользователя: Realm={Realm}, UserId={UserId}", realm, userId);

            using var request = await CreateRequestAsync(HttpMethod.Get, endpoint, accessToken, realm, cancellationToken).ConfigureAwait(false);

            var stopwatch = Stopwatch.StartNew();
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            stopwatch.Stop();
            MetricsService.RecordOperationTime(MetricsOperationName, stopwatch.ElapsedMilliseconds);

            if (response.StatusCode == HttpStatusCode.NotFound)
            {
                Logger.LogInformation("Сертификат пользователя не найден: Realm={Realm}, UserId={UserId}", realm, userId);
                return null;
            }

            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await ReadErrorContentAsync(response, cancellationToken).ConfigureAwait(false);
                Logger.LogError("Ошибка получения сертификата пользователя: StatusCode={StatusCode}, Error={Error}, Realm={Realm}, UserId={UserId}",
                    response.StatusCode, errorContent, realm, userId);
                return null;
            }

            // Проверка на пустой контент перед чтением
            if (response.Content == null ||
                (response.Content.Headers.ContentLength.HasValue && response.Content.Headers.ContentLength.Value == 0))
            {
                Logger.LogWarning("Получен пустой ответ при успешном статусе: Realm={Realm}, UserId={UserId}", realm, userId);
                return null;
            }

            // Проверка Content-Type ответа (опционально, для логирования)
            var contentType = response.Content.Headers.ContentType?.MediaType;
            if (!string.IsNullOrEmpty(contentType) &&
                !contentType.Contains("text", StringComparison.OrdinalIgnoreCase) &&
                !contentType.Contains("application/json", StringComparison.OrdinalIgnoreCase) &&
                !contentType.Contains("application/octet-stream", StringComparison.OrdinalIgnoreCase))
            {
                Logger.LogWarning("Неожиданный Content-Type при получении сертификата: {ContentType}, Realm={Realm}, UserId={UserId}",
                    contentType, realm, userId);
            }

            var certificateBase64 = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            if (string.IsNullOrWhiteSpace(certificateBase64))
            {
                Logger.LogWarning("Получен пустой сертификат пользователя: Realm={Realm}, UserId={UserId}", realm, userId);
                return null;
            }

            // Валидация Base64 формата
            if (!IsValidBase64(certificateBase64))
            {
                Logger.LogWarning("Получен невалидный Base64 сертификат: Realm={Realm}, UserId={UserId}", realm, userId);
                return null;
            }

            Logger.LogInformation("Сертификат пользователя успешно получен: Realm={Realm}, UserId={UserId}", realm, userId);
            return certificateBase64;
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogWarning("Таймаут при получении сертификата пользователя в реалме {Realm}, UserId={UserId}", realm, userId);
            throw new TimeoutException("Превышено время ожидания операции", ex);
        }
        catch (OperationCanceledException)
        {
            Logger.LogInformation("Операция получения сертификата отменена: Realm={Realm}, UserId={UserId}", realm, userId);
            throw;
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, "HTTP ошибка при получении сертификата пользователя в реалме {Realm}, UserId={UserId}", realm, userId);
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при получении сертификата пользователя в реалме {Realm}, UserId={UserId}", realm, userId);
            throw;
        }
    }

    /// <summary>
    /// Загрузить (обновить) сертификат пользователя
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации</param>
    /// <param name="realm">Название реалма Keycloak</param>
    /// <param name="userId">Идентификатор пользователя</param>
    /// <param name="certificateStream">Поток с данными сертификата. Поток не должен быть закрыт до завершения метода. Метод не владеет потоком и не закрывает его.</param>
    /// <param name="fileName">Имя файла сертификата</param>
    /// <param name="targetUsername">Имя пользователя (опционально, для аудита)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>true, если сертификат успешно загружен, иначе false</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="ArgumentNullException">Выбрасывается если certificateStream равен null</exception>
    public async Task<bool> UploadUserCertificateAsync(
        string accessToken,
        string realm,
        string userId,
        Stream certificateStream,
        string fileName,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        ValidateCommonParameters(accessToken, realm, "UploadUserCertificate");
        ValidateRealmFormat(realm);
        ValidateUserIdFormat(userId);
        ValidateFileName(fileName);
        
        if (certificateStream == null)
            throw new ArgumentNullException(nameof(certificateStream));

        // Валидация размера и формата сертификата
        ValidateCertificateSize(certificateStream);
        
        // Логирование размера файла
        if (certificateStream.CanSeek)
        {
            var fileSize = certificateStream.Length;
            Logger.LogDebug("Размер загружаемого сертификата: {Size} bytes, Realm={Realm}, UserId={UserId}", fileSize, realm, userId);
        }
        
        if (!await ValidateCertificateFormatAsync(certificateStream).ConfigureAwait(false))
        {
            Logger.LogWarning("Попытка загрузки невалидного сертификата: Realm={Realm}, UserId={UserId}, FileName={FileName}", realm, userId, fileName);
            throw new ArgumentException("Загружаемый файл не является валидным X.509 сертификатом", nameof(certificateStream));
        }

        // Создание CancellationTokenSource с таймаутом для операций загрузки
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        cts.CancelAfter(TimeSpan.FromMinutes(CertificateUploadTimeoutMinutes));

        // Блокировка для предотвращения дублирования операций для одного пользователя
        var lockKey = $"{realm}:{userId}";
        var semaphore = _operationLocks.GetOrAdd(lockKey, _ => new SemaphoreSlim(1, 1));

        await semaphore.WaitAsync(cts.Token).ConfigureAwait(false);
        try
        {
            var endpoint = $"auth/realms/{realm}/users-management/{ApiVersionV1}/users/{userId}/certificate";
            
            // Убедиться, что поток в начале
            if (certificateStream.CanSeek)
            {
                certificateStream.Seek(0, SeekOrigin.Begin);
            }

            // Убедиться, что fileName правильно экранирован и обработан
            var sanitizedFileName = SanitizeFileName(fileName);

            using var content = new MultipartFormDataContent();
            using var streamContent = new StreamContent(certificateStream);
            streamContent.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
            content.Add(streamContent, "cert", sanitizedFileName);

            Logger.LogDebug("Загрузка сертификата пользователя: Realm={Realm}, UserId={UserId}, FileName={FileName}", realm, userId, sanitizedFileName);

            using var request = await CreateRequestAsync(HttpMethod.Post, endpoint, accessToken, realm, cts.Token).ConfigureAwait(false);
            request.Content = content;

            var stopwatch = Stopwatch.StartNew();
            using var response = await HttpClient.SendAsync(request, cts.Token).ConfigureAwait(false);
            stopwatch.Stop();
            MetricsService.RecordOperationTime(MetricsOperationName, stopwatch.ElapsedMilliseconds);

            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await ReadErrorContentAsync(response, cts.Token).ConfigureAwait(false);
                Logger.LogError("Ошибка загрузки сертификата пользователя: StatusCode={StatusCode}, Error={Error}, Realm={Realm}, UserId={UserId}, FileName={FileName}",
                    response.StatusCode, errorContent, realm, userId, sanitizedFileName);
                return false;
            }

            Logger.LogInformation("Сертификат пользователя успешно загружен: Realm={Realm}, UserId={UserId}, FileName={FileName}",
                realm, userId, sanitizedFileName);

            var actingUser = GetActingUsername();
            var targetDisplay = FormatTargetDisplay(targetUsername, userId);
            var metadata = new Dictionary<string, string>
            {
                ["fileName"] = sanitizedFileName
            };

            var description = $"Пользователь {actingUser} загрузил сертификат для пользователя {targetDisplay} (файл {sanitizedFileName}).";
            await AuditService.LogUserManagementActionAsync(
                actingUser,
                AuditEventTypes.UserCertificateAdded,
                userId,
                targetUsername,
                realm,
                description,
                metadata);
            return true;
        }
        catch (OperationCanceledException) when (cts.Token.IsCancellationRequested && !cancellationToken.IsCancellationRequested)
        {
            Logger.LogWarning("Таймаут при загрузке сертификата: Realm={Realm}, UserId={UserId}", realm, userId);
            return false;
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, "HTTP ошибка при загрузке сертификата пользователя в реалме {Realm}, UserId={UserId}", realm, userId);
            return false;
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogWarning("Таймаут при загрузке сертификата пользователя в реалме {Realm}, UserId={UserId}", realm, userId);
            return false;
        }
        catch (ArgumentException ex)
        {
            Logger.LogError(ex, "Ошибка валидации при загрузке сертификата пользователя в реалме {Realm}, UserId={UserId}", realm, userId);
            return false;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при загрузке сертификата пользователя в реалме {Realm}, UserId={UserId}", realm, userId);
            return false;
        }
        finally
        {
            semaphore.Release();
            // Очистка неиспользуемых семафоров для предотвращения утечки памяти
            // Удаляем семафор, если он свободен (CurrentCount == 1 означает, что никто не использует)
            if (semaphore.CurrentCount == 1)
            {
                if (_operationLocks.TryRemove(lockKey, out var removedSemaphore))
                {
                    removedSemaphore.Dispose();
                }
            }
        }
    }

    /// <summary>
    /// Удалить сертификат пользователя
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации</param>
    /// <param name="realm">Название реалма Keycloak</param>
    /// <param name="userId">Идентификатор пользователя</param>
    /// <param name="targetUsername">Имя пользователя (опционально, для аудита)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>true, если сертификат успешно удален или уже отсутствует, иначе false</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    public async Task<bool> DeleteUserCertificateAsync(
        string accessToken,
        string realm,
        string userId,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        ValidateCommonParameters(accessToken, realm, "DeleteUserCertificate");
        ValidateRealmFormat(realm);
        ValidateUserIdFormat(userId);

        try
        {
            var endpoint = $"auth/realms/{realm}/users-management/{ApiVersionV1}/users/{userId}/certificate";
            
            Logger.LogDebug("Удаление сертификата пользователя: Realm={Realm}, UserId={UserId}", realm, userId);

            using var request = await CreateRequestAsync(HttpMethod.Delete, endpoint, accessToken, realm, cancellationToken).ConfigureAwait(false);

            var stopwatch = Stopwatch.StartNew();
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            stopwatch.Stop();
            MetricsService.RecordOperationTime(MetricsOperationName, stopwatch.ElapsedMilliseconds);

            if (response.StatusCode == HttpStatusCode.NotFound)
            {
                Logger.LogInformation("Сертификат пользователя уже отсутствует: Realm={Realm}, UserId={UserId}", realm, userId);
                return true;
            }

            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await ReadErrorContentAsync(response, cancellationToken).ConfigureAwait(false);
                Logger.LogError("Ошибка удаления сертификата пользователя: StatusCode={StatusCode}, Error={Error}, Realm={Realm}, UserId={UserId}",
                    response.StatusCode, errorContent, realm, userId);
                return false;
            }

            Logger.LogInformation("Сертификат пользователя успешно удалён: Realm={Realm}, UserId={UserId}", realm, userId);

            var actingUser = GetActingUsername();
            var targetDisplay = FormatTargetDisplay(targetUsername, userId);
            var description = $"Пользователь {actingUser} удалил сертификат пользователя {targetDisplay}.";
            await AuditService.LogUserManagementActionAsync(
                actingUser,
                AuditEventTypes.UserCertificateDeleted,
                userId,
                targetUsername,
                realm,
                description,
                null);
            return true;
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, "HTTP ошибка при удалении сертификата пользователя в реалме {Realm}, UserId={UserId}", realm, userId);
            return false;
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogWarning("Таймаут при удалении сертификата пользователя в реалме {Realm}, UserId={UserId}", realm, userId);
            return false;
        }
        catch (ArgumentException ex)
        {
            Logger.LogError(ex, "Ошибка валидации при удалении сертификата пользователя в реалме {Realm}, UserId={UserId}", realm, userId);
            return false;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при удалении сертификата пользователя в реалме {Realm}, UserId={UserId}", realm, userId);
            return false;
        }
    }
}

