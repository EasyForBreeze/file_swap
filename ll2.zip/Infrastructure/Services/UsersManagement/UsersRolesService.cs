using System.Diagnostics;
using System.Net.Http.Json;
using Microsoft.Extensions.Logging;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services.UsersManagement;

/// <summary>
/// Сервис для управления ролями пользователей через users-management API
/// </summary>
public class UsersRolesService : UsersManagementBaseService, IUsersRolesService
{
    public UsersRolesService(
        HttpClient httpClient,
        Microsoft.Extensions.Options.IOptions<new_assistant.Configuration.KeycloakAdminSettings> settings,
        new_assistant.Core.Interfaces.IAuditService auditService,
        Microsoft.AspNetCore.Http.IHttpContextAccessor httpContextAccessor,
        new_assistant.Core.Interfaces.ITokenExchangeService tokenExchangeService,
        new_assistant.Core.Interfaces.IPerformanceMetricsService metricsService,
        ILogger<UsersRolesService> logger)
        : base(httpClient, settings, auditService, httpContextAccessor, tokenExchangeService, metricsService, logger)
    {
    }
    
    /// <summary>
    /// Удалить realm роли у пользователя
    /// </summary>
    public async Task<bool> RemoveRealmRolesAsync(
        string accessToken,
        string realm,
        string userId,
        List<UserRealmRoleDto> roles,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        ValidateCommonParameters(accessToken, realm, "RemoveRealmRoles");
        if (string.IsNullOrWhiteSpace(userId))
            throw new ArgumentException("User ID cannot be null or empty", nameof(userId));
        if (roles == null || !roles.Any())
            throw new ArgumentException("Roles list cannot be null or empty", nameof(roles));
        
        try
        {
            // Формируем endpoint для users-management API
            var endpoint = $"auth/realms/{realm}/users-management/{ApiVersionV1}/users/{userId}/role-mappings/realm";
            
            // Формируем тело запроса - массив объектов с id и name
            var rolesData = roles.Select(r => new Dictionary<string, object>
            {
                ["id"] = r.Id,
                ["name"] = r.Name
            }).ToList();
            
            // Создаем JSON из списка
            var jsonContent = JsonContent.Create(rolesData);
            var roleIdentifiers = roles.Select(r => r.Id).ToArray();
            
            Logger.LogDebug("Отправка DELETE запроса на удаление realm ролей: Endpoint={Endpoint}, RoleCount={RoleCount}", endpoint, roleIdentifiers.Length);
            
            // Создаем запрос
            var request = await CreateRequestAsync(HttpMethod.Delete, endpoint, accessToken, realm, cancellationToken).ConfigureAwait(false);
            request.Content = jsonContent;
            request.Headers.Add("Accept", "application/json");
            
            var stopwatch = Stopwatch.StartNew();
            var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            stopwatch.Stop();
            MetricsService.RecordOperationTime(MetricsOperationName, stopwatch.ElapsedMilliseconds);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                Logger.LogError("Ошибка удаления realm ролей: StatusCode={StatusCode}, Error={Error}, Realm={Realm}, UserId={UserId}, RoleCount={RoleCount}", 
                    response.StatusCode, errorContent, realm, userId, roleIdentifiers.Length);
                return false;
            }
            
            var actingUser = GetActingUsername();
            var targetDisplay = FormatTargetDisplay(targetUsername, userId);
            var roleNames = string.Join(", ", roles.Select(r => r.Name));
            var metadata = new Dictionary<string, string>
            {
                ["roleIds"] = string.Join(",", roles.Select(r => r.Id)),
                ["roleNames"] = roleNames
            };

            Logger.LogInformation("Realm роли успешно удалены: Realm={Realm}, UserId={UserId}, Roles={Roles}", 
                realm, userId, roleNames);

            var description = $"Пользователь {actingUser} удалил realm-роль(и) {roleNames} у пользователя {targetDisplay}.";
            await AuditService.LogUserManagementActionAsync(
                actingUser,
                "UserRealmRoleRemoved",
                userId,
                targetUsername,
                realm,
                description,
                metadata);
            return true;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при удалении realm ролей в реалме {Realm}, UserId={UserId}", realm, userId);
            return false;
        }
    }
    
    /// <summary>
    /// Удалить client роль у пользователя
    /// </summary>
    public async Task<bool> RemoveClientRoleAsync(
        string accessToken,
        string realm,
        string userId,
        string clientId,
        UserClientRoleDto role,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        ValidateCommonParameters(accessToken, realm, "RemoveClientRole");
        if (string.IsNullOrWhiteSpace(userId))
            throw new ArgumentException("User ID cannot be null or empty", nameof(userId));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (role == null)
            throw new ArgumentNullException(nameof(role));
        
        try
        {
            // Формируем endpoint для users-management API
            var endpoint = $"auth/realms/{realm}/users-management/{ApiVersionV1}/users/{userId}/role-mappings/clients/{clientId}";
            
            // Формируем тело запроса - массив с объектом id и name (как в KeycloakHttpClient)
            var roleMapping = new
            {
                id = role.Id,
                name = role.Name
            };
            
            // Создаем JSON из массива (даже для одной роли используется массив)
            var jsonContent = JsonContent.Create(new[] { roleMapping });
            
            Logger.LogDebug("Отправка DELETE запроса на удаление client роли: Endpoint={Endpoint}, ClientId={ClientId}, RoleId={RoleId}", endpoint, clientId, role.Id);
            
            // Создаем запрос
            var request = await CreateRequestAsync(HttpMethod.Delete, endpoint, accessToken, realm, cancellationToken).ConfigureAwait(false);
            request.Content = jsonContent;
            request.Headers.Add("Accept", "application/json");
            
            var stopwatch = Stopwatch.StartNew();
            var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            stopwatch.Stop();
            MetricsService.RecordOperationTime(MetricsOperationName, stopwatch.ElapsedMilliseconds);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                Logger.LogError("Ошибка удаления client роли: StatusCode={StatusCode}, Error={Error}, Realm={Realm}, UserId={UserId}, ClientId={ClientId}, RoleId={RoleId}", 
                    response.StatusCode, errorContent, realm, userId, clientId, role.Id);
                return false;
            }
            
            var actingUser = GetActingUsername();
            var targetDisplay = FormatTargetDisplay(targetUsername, userId);
            var metadata = new Dictionary<string, string>
            {
                ["roleId"] = role.Id,
                ["roleName"] = role.Name,
                ["clientId"] = clientId
            };

            Logger.LogInformation("Client роль успешно удалена: Realm={Realm}, UserId={UserId}, ClientId={ClientId}, Role={Role}", 
                realm, userId, clientId, role.Name);

            var description = $"Пользователь {actingUser} удалил client-роль {role.Name} (клиент {clientId}) у пользователя {targetDisplay}.";
            await AuditService.LogUserManagementActionAsync(
                actingUser,
                "UserClientRoleRemoved",
                userId,
                targetUsername,
                realm,
                description,
                metadata);
            return true;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при удалении client роли в реалме {Realm}, UserId={UserId}, ClientId={ClientId}", realm, userId, clientId);
            return false;
        }
    }
    
    /// <summary>
    /// Добавить realm роли пользователю
    /// </summary>
    public async Task<bool> AddRealmRolesAsync(
        string accessToken,
        string realm,
        string userId,
        List<UserRealmRoleDto> roles,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        ValidateCommonParameters(accessToken, realm, "AddRealmRoles");
        if (string.IsNullOrWhiteSpace(userId))
            throw new ArgumentException("User ID cannot be null or empty", nameof(userId));
        if (roles == null || !roles.Any())
            throw new ArgumentException("Roles list cannot be null or empty", nameof(roles));
        
        try
        {
            // Формируем endpoint для users-management API
            var endpoint = $"auth/realms/{realm}/users-management/{ApiVersionV1}/users/{userId}/role-mappings/realm";
            
            // Формируем тело запроса - массив объектов с id и name
            var rolesData = roles.Select(r => new
            {
                id = r.Id,
                name = r.Name
            }).ToArray();
            
            // Создаем JSON из массива
            var jsonContent = JsonContent.Create(rolesData);
            var roleIdentifiers = roles.Select(r => r.Id).ToArray();
            
            Logger.LogDebug("Отправка POST запроса на добавление realm ролей: Endpoint={Endpoint}, RoleCount={RoleCount}", endpoint, roleIdentifiers.Length);
            
            // Создаем запрос
            var request = await CreateRequestAsync(HttpMethod.Post, endpoint, accessToken, realm, cancellationToken).ConfigureAwait(false);
            request.Content = jsonContent;
            request.Headers.Add("Accept", "application/json");
            
            var stopwatch = Stopwatch.StartNew();
            var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            stopwatch.Stop();
            MetricsService.RecordOperationTime(MetricsOperationName, stopwatch.ElapsedMilliseconds);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                Logger.LogError("Ошибка добавления realm ролей: StatusCode={StatusCode}, Error={Error}, Realm={Realm}, UserId={UserId}, RoleCount={RoleCount}", 
                    response.StatusCode, errorContent, realm, userId, roleIdentifiers.Length);
                return false;
            }
            
            var actingUser = GetActingUsername();
            var targetDisplay = FormatTargetDisplay(targetUsername, userId);
            var roleNames = string.Join(", ", roles.Select(r => r.Name));
            var metadata = new Dictionary<string, string>
            {
                ["roleIds"] = string.Join(",", roles.Select(r => r.Id)),
                ["roleNames"] = roleNames
            };

            Logger.LogInformation("Realm роли успешно добавлены: Realm={Realm}, UserId={UserId}, Roles={Roles}", 
                realm, userId, roleNames);

            var description = $"Пользователь {actingUser} добавил realm-роль(и) {roleNames} пользователю {targetDisplay}.";
            await AuditService.LogUserManagementActionAsync(
                actingUser,
                "UserRealmRoleAdded",
                userId,
                targetUsername,
                realm,
                description,
                metadata);
            return true;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при добавлении realm ролей в реалме {Realm}, UserId={UserId}", realm, userId);
            return false;
        }
    }
    
    /// <summary>
    /// Добавить client роль пользователю
    /// </summary>
    public async Task<bool> AddClientRoleAsync(
        string accessToken,
        string realm,
        string userId,
        string clientId,
        UserClientRoleDto role,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        ValidateCommonParameters(accessToken, realm, "AddClientRole");
        if (string.IsNullOrWhiteSpace(userId))
            throw new ArgumentException("User ID cannot be null or empty", nameof(userId));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (role == null)
            throw new ArgumentNullException(nameof(role));
        
        try
        {
            // Формируем endpoint для users-management API
            var endpoint = $"auth/realms/{realm}/users-management/{ApiVersionV1}/users/{userId}/role-mappings/clients/{clientId}";
            
            // Формируем тело запроса - массив с объектом id и name
            var roleMapping = new
            {
                id = role.Id,
                name = role.Name
            };
            
            // Создаем JSON из массива (даже для одной роли используется массив)
            var jsonContent = JsonContent.Create(new[] { roleMapping });
            
            Logger.LogDebug("Отправка POST запроса на добавление client роли: Endpoint={Endpoint}, ClientId={ClientId}, RoleId={RoleId}", 
                endpoint, clientId, role.Id);
            
            // Создаем запрос
            var request = await CreateRequestAsync(HttpMethod.Post, endpoint, accessToken, realm, cancellationToken).ConfigureAwait(false);
            request.Content = jsonContent;
            request.Headers.Add("Accept", "application/json");
            
            var stopwatch = Stopwatch.StartNew();
            var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            stopwatch.Stop();
            MetricsService.RecordOperationTime(MetricsOperationName, stopwatch.ElapsedMilliseconds);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                Logger.LogError("Ошибка добавления client роли: StatusCode={StatusCode}, Error={Error}, Realm={Realm}, UserId={UserId}, ClientId={ClientId}, RoleId={RoleId}", 
                    response.StatusCode, errorContent, realm, userId, clientId, role.Id);
                return false;
            }
            
            var actingUser = GetActingUsername();
            var targetDisplay = FormatTargetDisplay(targetUsername, userId);
            var metadata = new Dictionary<string, string>
            {
                ["roleId"] = role.Id,
                ["roleName"] = role.Name,
                ["clientId"] = clientId
            };

            Logger.LogInformation("Client роль успешно добавлена: Realm={Realm}, UserId={UserId}, ClientId={ClientId}, Role={Role}", 
                realm, userId, clientId, role.Name);

            var description = $"Пользователь {actingUser} добавил client-роль {role.Name} (клиент {clientId}) пользователю {targetDisplay}.";
            await AuditService.LogUserManagementActionAsync(
                actingUser,
                "UserClientRoleAdded",
                userId,
                targetUsername,
                realm,
                description,
                metadata);
            return true;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при добавлении client роли в реалме {Realm}, UserId={UserId}, ClientId={ClientId}", realm, userId, clientId);
            return false;
        }
    }
}

