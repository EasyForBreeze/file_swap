using System.Collections.Concurrent;
using System.Reflection;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Менеджер для безопасной работы с событиями, предотвращающий утечки памяти
/// Использует слабые ссылки для автоматической очистки подписчиков
/// </summary>
internal class WeakEventManager
{
    private readonly ConcurrentDictionary<object, WeakReference<Action>> _handlers = new();
    private long _handlerCounter = 0;
    private long _operationCount = 0;
    private const int CleanupInterval = 100; // Очистка каждые 100 операций
    private readonly ILogger<WeakEventManager>? _logger;

    /// <summary>
    /// Инициализирует новый экземпляр WeakEventManager
    /// </summary>
    /// <param name="logger">Опциональный логгер для записи ошибок</param>
    public WeakEventManager(ILogger<WeakEventManager>? logger = null)
    {
        _logger = logger;
    }

    /// <summary>
    /// Добавляет обработчик события
    /// </summary>
    public void AddEventHandler(Action? handler)
    {
        if (handler == null) return;

        // Используем уникальные ключи для всех обработчиков, чтобы избежать потери при множественных подписках
        // Проверка на переполнение счетчика после инкремента
        var newCounter = Interlocked.Increment(ref _handlerCounter);
        
        // Обработка переполнения: после переполнения long.MaxValue значение становится отрицательным (long.MinValue)
        // Используем атомарную операцию CompareExchange для безопасного сброса счетчика
        if (newCounter <= 0)
        {
            // Атомарно сбрасываем счетчик, если он еще не был сброшен другим потоком
            Interlocked.CompareExchange(ref _handlerCounter, 0, newCounter);
            // Получаем актуальное значение после возможного сброса другим потоком
            newCounter = Interlocked.Read(ref _handlerCounter);
            // Если счетчик все еще отрицательный или равен 0, инкрементируем его
            if (newCounter <= 0)
            {
                newCounter = Interlocked.Increment(ref _handlerCounter);
            }
        }
        
        var uniqueKey = new HandlerKey(handler, newCounter);

        _handlers.TryAdd(uniqueKey, new WeakReference<Action>(handler));

        // Очищаем мертвые ссылки периодически (каждые CleanupInterval операций)
        // Используем модуль для циклического счетчика (переполнение не критично)
        var operationCount = Interlocked.Increment(ref _operationCount);
        // Обрабатываем переполнение operationCount: используем модуль, который работает корректно даже при переполнении
        if (operationCount % CleanupInterval == 0)
        {
            CleanupDeadReferences();
        }
    }

    /// <summary>
    /// Удаляет обработчик события
    /// </summary>
    /// <remarks>
    /// Удаляет все обработчики с одинаковым методом и target.
    /// Если один и тот же метод был подписан несколько раз, все подписки будут удалены.
    /// </remarks>
    public void RemoveEventHandler(Action? handler)
    {
        if (handler == null) return;

        // Создаем snapshot для безопасной итерации без блокировок
        var keysToRemove = new List<object>();
        
        foreach (var kvp in _handlers.ToArray())
        {
            if (kvp.Key is HandlerKey handlerKey && 
                handlerKey.Method == handler.Method &&
                handlerKey.Target == handler.Target)
            {
                keysToRemove.Add(kvp.Key);
            }
        }
        
        // Удаляем найденные ключи
        foreach (var key in keysToRemove)
        {
            _handlers.TryRemove(key, out _);
        }
    }

    /// <summary>
    /// Вызывает все активные обработчики
    /// </summary>
    public void RaiseEvent()
    {
        CleanupDeadReferences();

        // Создаем snapshot для безопасной итерации
        var handlersToInvoke = new List<Action>();
        
        // Используем ToArray() для создания snapshot и избежания race conditions
        foreach (var kvp in _handlers.ToArray())
        {
            if (kvp.Value.TryGetTarget(out var handler))
            {
                handlersToInvoke.Add(handler);
            }
        }

        // Вызываем обработчики вне итерации по словарю
        foreach (var handler in handlersToInvoke)
        {
            try
            {
                handler.Invoke();
            }
            catch (Exception ex)
            {
                // Логируем ошибки для отладки
                _logger?.LogError(ex, "Ошибка при вызове обработчика события в WeakEventManager");
                // Игнорируем ошибки в обработчиках, чтобы не прерывать выполнение других
            }
        }
    }

    /// <summary>
    /// Очищает все обработчики событий
    /// </summary>
    public void Clear()
    {
        _handlers.Clear();
        Interlocked.Exchange(ref _handlerCounter, 0);
        Interlocked.Exchange(ref _operationCount, 0);
    }

    /// <summary>
    /// Очищает мертвые ссылки
    /// </summary>
    private void CleanupDeadReferences()
    {
        // Используем ToArray() для создания snapshot и избежания блокировок
        var keysToRemove = new List<object>();
        
        foreach (var kvp in _handlers.ToArray())
        {
            if (!kvp.Value.TryGetTarget(out _))
            {
                keysToRemove.Add(kvp.Key);
            }
        }
        
        // Удаляем вне итерации
        foreach (var key in keysToRemove)
        {
            _handlers.TryRemove(key, out _);
        }
    }

    /// <summary>
    /// Ключ для обработчиков, обеспечивающий уникальность и предотвращающий утечки памяти
    /// Хранит информацию о методе и target вместо самого делегата
    /// </summary>
    private class HandlerKey
    {
        public MethodInfo Method { get; }
        public object? Target { get; }
        public long Id { get; }

        public HandlerKey(Action handler, long id)
        {
            Method = handler.Method ?? throw new ArgumentNullException(nameof(handler.Method));
            Target = handler.Target;
            Id = id;
        }

        public override bool Equals(object? obj)
        {
            if (obj is not HandlerKey other)
                return false;
            
            // Дополнительная проверка на null для безопасности (хотя Method не может быть null)
            if (Method == null || other.Method == null)
                return false;
            
            return Method == other.Method &&
                   Target == other.Target &&
                   Id == other.Id;
        }

        public override int GetHashCode()
        {
            // Method никогда не может быть null (проверяется в конструкторе)
            // Target может быть null для статических методов
            // Добавляем проверку для консистентности с Equals
            if (Method == null)
                return HashCode.Combine(0, Target?.GetHashCode() ?? 0, Id);
            
            return HashCode.Combine(Method.GetHashCode(), Target?.GetHashCode() ?? 0, Id);
        }
    }
}
