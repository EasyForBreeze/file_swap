using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Logging;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для работы с users-management API.
/// Обеспечивает взаимодействие с Keycloak users-management API для управления пользователями.
/// Поддерживает token exchange для работы с разными реалмами.
/// Использует специализированные сервисы для разделения ответственности.
/// </summary>
public class UsersManagementService : IUsersManagementService
{
    // Константы для валидации
    private const int MaxRealmLength = 100;
    private const int MaxUserIdLength = 200;
    private const int MaxClientIdLength = 200;
    private const int MaxUsernameLength = 100;
    private const int MaxFirstNameLength = 100;
    private const int MaxLastNameLength = 100;
    private const int MaxEmailLength = 255;
    private const int MaxFileNameLength = 255;
    private const int MaxReasonLength = 500;
    private const int MaxSearchTermLength = 500;
    private const int MaxPaginationSize = 1000;
    private const int MaxAccessTokenLength = 10000; // JWT токены обычно до 8KB, но оставляем запас
    private const int MaxTargetUsernameLength = 100;
    private const long MaxCertificateSize = 10 * 1024 * 1024; // 10 MB
    
    private static readonly string[] AllowedCertificateExtensions = { ".cer", ".crt", ".pem", ".p12", ".pfx" };
    private static readonly char[] InvalidFileNameChars = Path.GetInvalidFileNameChars();
    private static readonly char[] InvalidSearchTermChars = { '\0', '\r', '\n' };
    private static readonly char[] InvalidUsernameChars = { '/', '\\', ':', '*', '?', '"', '<', '>', '|' };
    private static readonly char[] InvalidNameChars = { '\0', '\r', '\n' };
    private static readonly char[] InvalidReasonChars = { '\0', '\r', '\n' };
    
    // Допустимые значения actions (согласно Keycloak API)
    private static readonly HashSet<string> ValidActions = new(StringComparer.OrdinalIgnoreCase)
    {
        "UPDATE_PASSWORD",
        "CONFIGURE_TOTP",
        "VERIFY_EMAIL",
        "UPDATE_PROFILE"
    };
    private static readonly string ValidActionsString = string.Join(", ", ValidActions);
    
    private readonly IUsersSearchService _searchService;
    private readonly IUsersInfoService _infoService;
    private readonly IUsersRolesService _rolesService;
    private readonly IUsersActionsService _actionsService;
    private readonly IUsersCertificateService _certificateService;
    private readonly ILogger<UsersManagementService> _logger;

    public UsersManagementService(
        IUsersSearchService searchService,
        IUsersInfoService infoService,
        IUsersRolesService rolesService,
        IUsersActionsService actionsService,
        IUsersCertificateService certificateService,
        ILogger<UsersManagementService> logger)
    {
        _searchService = searchService ?? throw new ArgumentNullException(nameof(searchService));
        _infoService = infoService ?? throw new ArgumentNullException(nameof(infoService));
        _rolesService = rolesService ?? throw new ArgumentNullException(nameof(rolesService));
        _actionsService = actionsService ?? throw new ArgumentNullException(nameof(actionsService));
        _certificateService = certificateService ?? throw new ArgumentNullException(nameof(certificateService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }
    
    /// <summary>
    /// Поиск пользователей в указанном реалме по username, имени, фамилии или email
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса. Не может быть null или пустым.</param>
    /// <param name="realm">Название реалма для поиска пользователей. Не может быть null или пустым, должен содержать только буквы, цифры, дефисы, подчеркивания и точки.</param>
    /// <param name="searchTerm">Поисковый запрос (username, имя, фамилия или email). Если null или пустой, возвращаются все пользователи с учетом пагинации. Максимальная длина: 500 символов.</param>
    /// <param name="exact">Если true, выполняется точный поиск. По умолчанию false.</param>
    /// <param name="first">Индекс первого результата для пагинации (0-based). По умолчанию 0. Должен быть >= 0.</param>
    /// <param name="max">Максимальное количество результатов. По умолчанию 100. Должен быть в диапазоне [1, 1000].</param>
    /// <param name="cancellationToken">Токен отмены операции.</param>
    /// <returns>Список найденных пользователей (только для чтения). Пустой список возвращается только если пользователи не найдены.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах (null, пустые строки, недопустимые значения).</exception>
    /// <exception cref="ArgumentOutOfRangeException">Выбрасывается если first < 0, max не в диапазоне [1, 1000] или searchTerm превышает максимальную длину.</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса.</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции через cancellationToken.</exception>
    public async Task<IReadOnlyList<UserSearchResultDto>> SearchUsersAsync(
        string accessToken,
        string realm,
        string? searchTerm = null,
        bool exact = false,
        int first = 0,
        int max = 100,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        // Валидация обязательных параметров
        ValidateCommonParameters(accessToken, realm);
        
        // Валидация пагинации
        if (first < 0)
            throw new ArgumentOutOfRangeException(nameof(first), "First must be non-negative");
        
        if (max <= 0 || max > MaxPaginationSize)
            throw new ArgumentOutOfRangeException(nameof(max), $"Max must be between 1 and {MaxPaginationSize}");
        
        // Валидация searchTerm
        if (!string.IsNullOrEmpty(searchTerm))
        {
            if (searchTerm.Length > MaxSearchTermLength)
                throw new ArgumentOutOfRangeException(nameof(searchTerm), $"Search term cannot exceed {MaxSearchTermLength} characters");
            
            // Валидация на опасные символы
            if (searchTerm.IndexOfAny(InvalidSearchTermChars) >= 0)
                throw new ArgumentException("Search term contains invalid characters", nameof(searchTerm));
        }
        
        _logger.LogDebug("Searching users in realm {Realm}, searchTerm: {SearchTerm}, exact: {Exact}, first: {First}, max: {Max}", 
            realm, searchTerm, exact, first, max);
        
        return await ExecuteWithMetricsAsync(
            async ct =>
            {
                var result = await _searchService.SearchUsersAsync(accessToken, realm, searchTerm, exact, first, max, ct)
                    .ConfigureAwait(false);
                // Логируем только специфичную информацию (количество найденных пользователей)
                _logger.LogDebug("Found {Count} users in realm {Realm}", result.Count, realm);
                return result;
            },
            "SearchUsers",
            realm,
            cancellationToken: cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Получить детальную информацию о пользователе по его ID
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса. Не может быть null или пустым.</param>
    /// <param name="realm">Название реалма. Не может быть null или пустым.</param>
    /// <param name="userId">ID пользователя. Не может быть null или пустым, максимальная длина: 200 символов.</param>
    /// <param name="cancellationToken">Токен отмены операции.</param>
    /// <returns>Детальная информация о пользователе или null, если пользователь не найден.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах.</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса.</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции.</exception>
    public async Task<UserDetailedInfoDto?> GetUserInfoAsync(
        string accessToken,
        string realm,
        string userId,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        ValidateCommonParameters(accessToken, realm);
        ValidateUserId(userId);
        
        _logger.LogDebug("Getting user info for userId {UserId} in realm {Realm}", userId, realm);
        
        return await ExecuteWithMetricsAsync(
            async ct =>
            {
                var result = await _infoService.GetUserInfoAsync(accessToken, realm, userId, ct)
                    .ConfigureAwait(false);
                
                if (result != null)
                {
                    _logger.LogInformation("Successfully retrieved user info for userId {UserId} in realm {Realm}", userId, realm);
                }
                else
                {
                    _logger.LogWarning("User not found: userId {UserId} in realm {Realm}", userId, realm);
                }
                
                return result;
            },
            "GetUserInfo",
            realm,
            userId,
            cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Обновить информацию о пользователе (имя, фамилия, email)
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса. Не может быть null или пустым.</param>
    /// <param name="realm">Название реалма. Не может быть null или пустым.</param>
    /// <param name="userId">ID пользователя. Не может быть null или пустым.</param>
    /// <param name="firstName">Имя пользователя (может быть null). Максимальная длина: 100 символов.</param>
    /// <param name="lastName">Фамилия пользователя (может быть null). Максимальная длина: 100 символов.</param>
    /// <param name="email">Email пользователя (может быть null). Максимальная длина: 255 символов, должен быть валидным форматом email.</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null).</param>
    /// <param name="cancellationToken">Токен отмены операции.</param>
    /// <returns>true, если обновление выполнено успешно, иначе false.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах.</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса.</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции.</exception>
    public async Task<bool> UpdateUserAsync(
        string accessToken,
        string realm,
        string userId,
        string? firstName,
        string? lastName,
        string? email,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        ValidateCommonParameters(accessToken, realm);
        ValidateUserId(userId);
        ValidateTargetUsername(targetUsername);
        
        // Валидация опциональных параметров, если они указаны
        if (firstName != null)
        {
            firstName = firstName.Trim();
            if (string.IsNullOrWhiteSpace(firstName))
                throw new ArgumentException("First name cannot be empty or whitespace", nameof(firstName));
            
            if (firstName.Length > MaxFirstNameLength)
                throw new ArgumentException($"First name cannot exceed {MaxFirstNameLength} characters", nameof(firstName));
            
            if (firstName.IndexOfAny(InvalidNameChars) >= 0)
                throw new ArgumentException("First name contains invalid control characters", nameof(firstName));
        }
        
        if (lastName != null)
        {
            lastName = lastName.Trim();
            if (string.IsNullOrWhiteSpace(lastName))
                throw new ArgumentException("Last name cannot be empty or whitespace", nameof(lastName));
            
            if (lastName.Length > MaxLastNameLength)
                throw new ArgumentException($"Last name cannot exceed {MaxLastNameLength} characters", nameof(lastName));
            
            if (lastName.IndexOfAny(InvalidNameChars) >= 0)
                throw new ArgumentException("Last name contains invalid control characters", nameof(lastName));
        }
        
        if (email != null)
        {
            email = email.Trim();
            if (string.IsNullOrWhiteSpace(email))
                throw new ArgumentException("Email cannot be empty or whitespace", nameof(email));
            
            if (email.Length > MaxEmailLength)
                throw new ArgumentException($"Email cannot exceed {MaxEmailLength} characters", nameof(email));
            
            if (!IsValidEmail(email))
                throw new ArgumentException("Invalid email format", nameof(email));
        }
        
        _logger.LogInformation("Updating user {UserId} in realm {Realm}", userId, realm);
        
        return await ExecuteWithMetricsAsync(
            async ct =>
            {
                var result = await _infoService.UpdateUserAsync(accessToken, realm, userId, firstName, lastName, email, targetUsername, ct)
                    .ConfigureAwait(false);
                
                // Логируем только результат операции (успех/неудача)
                if (!result)
                {
                    _logger.LogWarning("Failed to update user {UserId} in realm {Realm}", userId, realm);
                }
                
                return result;
            },
            "UpdateUser",
            realm,
            userId,
            cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Создать нового пользователя в указанном реалме
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса. Не может быть null или пустым.</param>
    /// <param name="realm">Название реалма. Не может быть null или пустым.</param>
    /// <param name="username">Имя пользователя. Не может быть null или пустым, максимальная длина: 100 символов.</param>
    /// <param name="firstName">Имя. Не может быть null или пустым, максимальная длина: 100 символов.</param>
    /// <param name="lastName">Фамилия. Не может быть null или пустым, максимальная длина: 100 символов.</param>
    /// <param name="email">Email. Не может быть null или пустым, максимальная длина: 255 символов, должен быть валидным форматом email.</param>
    /// <param name="cancellationToken">Токен отмены операции.</param>
    /// <returns>true, если создание выполнено успешно, иначе false.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах.</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса.</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции.</exception>
    public async Task<bool> CreateUserAsync(
        string accessToken,
        string realm,
        string username,
        string firstName,
        string lastName,
        string email,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        ValidateCommonParameters(accessToken, realm);
        ValidateUsername(username);
        ValidateFirstName(firstName);
        ValidateLastName(lastName);
        ValidateEmail(email);
        
        _logger.LogInformation("Creating user {Username} in realm {Realm}", username, realm);
        
        return await ExecuteWithMetricsAsync(
            async ct =>
            {
                var result = await _infoService.CreateUserAsync(accessToken, realm, username, firstName, lastName, email, ct)
                    .ConfigureAwait(false);
                
                // Логируем только результат операции (успех/неудача)
                if (!result)
                {
                    _logger.LogWarning("Failed to create user {Username} in realm {Realm}", username, realm);
                }
                
                return result;
            },
            "CreateUser",
            realm,
            cancellationToken: cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Удалить realm роли у пользователя
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса. Не может быть null или пустым.</param>
    /// <param name="realm">Название реалма. Не может быть null или пустым.</param>
    /// <param name="userId">ID пользователя. Не может быть null или пустым.</param>
    /// <param name="roles">Список realm ролей для удаления. Не может быть null или пустым.</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null).</param>
    /// <param name="cancellationToken">Токен отмены операции.</param>
    /// <returns>true, если удаление выполнено успешно, иначе false.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах.</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса.</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции.</exception>
    public async Task<bool> RemoveRealmRolesAsync(
        string accessToken,
        string realm,
        string userId,
        List<UserRealmRoleDto> roles,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        ValidateCommonParameters(accessToken, realm);
        ValidateUserId(userId);
        ValidateRolesList(roles, nameof(roles));
        ValidateTargetUsername(targetUsername);
        
        _logger.LogInformation("Removing {Count} realm roles from user {UserId} in realm {Realm}", 
            roles.Count, userId, realm);
        
        return await ExecuteWithMetricsAsync(
            async ct =>
            {
                var result = await _rolesService.RemoveRealmRolesAsync(accessToken, realm, userId, roles, targetUsername, ct)
                    .ConfigureAwait(false);
                
                // Логируем только результат операции (успех/неудача)
                if (!result)
                {
                    _logger.LogWarning("Failed to remove realm roles from user {UserId} in realm {Realm}", userId, realm);
                }
                
                return result;
            },
            "RemoveRealmRoles",
            realm,
            userId,
            cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Удалить client роль у пользователя
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса. Не может быть null или пустым.</param>
    /// <param name="realm">Название реалма. Не может быть null или пустым.</param>
    /// <param name="userId">ID пользователя. Не может быть null или пустым.</param>
    /// <param name="clientId">ID клиента. Не может быть null или пустым, максимальная длина: 200 символов.</param>
    /// <param name="role">Client роль для удаления. Не может быть null.</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null).</param>
    /// <param name="cancellationToken">Токен отмены операции.</param>
    /// <returns>true, если удаление выполнено успешно, иначе false.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах.</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса.</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции.</exception>
    public async Task<bool> RemoveClientRoleAsync(
        string accessToken,
        string realm,
        string userId,
        string clientId,
        UserClientRoleDto role,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        ValidateCommonParameters(accessToken, realm);
        ValidateUserId(userId);
        ValidateClientId(clientId);
        ValidateClientRole(role);
        ValidateTargetUsername(targetUsername);
        
        _logger.LogInformation("Removing client role {RoleName} (client: {ClientId}) from user {UserId} in realm {Realm}", 
            role.Name ?? role.Id, clientId, userId, realm);
        
        return await ExecuteWithMetricsAsync(
            async ct =>
            {
                var result = await _rolesService.RemoveClientRoleAsync(accessToken, realm, userId, clientId, role, targetUsername, ct)
                    .ConfigureAwait(false);
                
                // Логируем только результат операции (успех/неудача)
                if (!result)
                {
                    _logger.LogWarning("Failed to remove client role {RoleName} from user {UserId} in realm {Realm}", 
                        role.Name ?? role.Id, userId, realm);
                }
                
                return result;
            },
            "RemoveClientRole",
            realm,
            userId,
            cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Добавить realm роли пользователю
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса. Не может быть null или пустым.</param>
    /// <param name="realm">Название реалма. Не может быть null или пустым.</param>
    /// <param name="userId">ID пользователя. Не может быть null или пустым.</param>
    /// <param name="roles">Список realm ролей для добавления. Не может быть null или пустым.</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null).</param>
    /// <param name="cancellationToken">Токен отмены операции.</param>
    /// <returns>true, если добавление выполнено успешно, иначе false.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах.</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса.</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции.</exception>
    public async Task<bool> AddRealmRolesAsync(
        string accessToken,
        string realm,
        string userId,
        List<UserRealmRoleDto> roles,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        ValidateCommonParameters(accessToken, realm);
        ValidateUserId(userId);
        ValidateRolesList(roles, nameof(roles));
        ValidateTargetUsername(targetUsername);
        
        _logger.LogInformation("Adding {Count} realm roles to user {UserId} in realm {Realm}", 
            roles.Count, userId, realm);
        
        return await ExecuteWithMetricsAsync(
            async ct =>
            {
                var result = await _rolesService.AddRealmRolesAsync(accessToken, realm, userId, roles, targetUsername, ct)
                    .ConfigureAwait(false);
                
                // Логируем только результат операции (успех/неудача)
                if (!result)
                {
                    _logger.LogWarning("Failed to add realm roles to user {UserId} in realm {Realm}", userId, realm);
                }
                
                return result;
            },
            "AddRealmRoles",
            realm,
            userId,
            cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Добавить client роль пользователю
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса. Не может быть null или пустым.</param>
    /// <param name="realm">Название реалма. Не может быть null или пустым.</param>
    /// <param name="userId">ID пользователя. Не может быть null или пустым.</param>
    /// <param name="clientId">ID клиента. Не может быть null или пустым, максимальная длина: 200 символов.</param>
    /// <param name="role">Client роль для добавления. Не может быть null.</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null).</param>
    /// <param name="cancellationToken">Токен отмены операции.</param>
    /// <returns>true, если добавление выполнено успешно, иначе false.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах.</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса.</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции.</exception>
    public async Task<bool> AddClientRoleAsync(
        string accessToken,
        string realm,
        string userId,
        string clientId,
        UserClientRoleDto role,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        ValidateCommonParameters(accessToken, realm);
        ValidateUserId(userId);
        ValidateClientId(clientId);
        ValidateClientRole(role);
        ValidateTargetUsername(targetUsername);
        
        _logger.LogInformation("Adding client role {RoleName} (client: {ClientId}) to user {UserId} in realm {Realm}", 
            role.Name ?? role.Id, clientId, userId, realm);
        
        return await ExecuteWithMetricsAsync(
            async ct =>
            {
                var result = await _rolesService.AddClientRoleAsync(accessToken, realm, userId, clientId, role, targetUsername, ct)
                    .ConfigureAwait(false);
                
                // Логируем только результат операции (успех/неудача)
                if (!result)
                {
                    _logger.LogWarning("Failed to add client role {RoleName} to user {UserId} in realm {Realm}", 
                        role.Name ?? role.Id, userId, realm);
                }
                
                return result;
            },
            "AddClientRole",
            realm,
            userId,
            cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Снять блокировку брутфорса для пользователя
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса. Не может быть null или пустым.</param>
    /// <param name="realm">Название реалма. Не может быть null или пустым.</param>
    /// <param name="userId">ID пользователя. Не может быть null или пустым.</param>
    /// <param name="cancellationToken">Токен отмены операции.</param>
    /// <returns>true, если операция выполнена успешно, иначе false.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах.</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса.</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции.</exception>
    public async Task<bool> RemoveBruteForceStatusAsync(
        string accessToken,
        string realm,
        string userId,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        ValidateCommonParameters(accessToken, realm);
        ValidateUserId(userId);
        
        _logger.LogInformation("Removing brute force status for user {UserId} in realm {Realm}", userId, realm);
        
        return await ExecuteWithMetricsAsync(
            async ct =>
            {
                var result = await _actionsService.RemoveBruteForceStatusAsync(accessToken, realm, userId, ct)
                    .ConfigureAwait(false);
                
                // Логируем только результат операции (успех/неудача)
                if (!result)
                {
                    _logger.LogWarning("Failed to remove brute force status for user {UserId} in realm {Realm}", userId, realm);
                }
                
                return result;
            },
            "RemoveBruteForceStatus",
            realm,
            userId,
            cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Выполнить действия через email для пользователя (например, обновление пароля, конфигурация OTP)
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса. Не может быть null или пустым.</param>
    /// <param name="realm">Название реалма. Не может быть null или пустым.</param>
    /// <param name="userId">ID пользователя. Не может быть null или пустым.</param>
    /// <param name="actions">Список действий для выполнения. Не может быть null или пустым. Допустимые значения: "UPDATE_PASSWORD", "CONFIGURE_TOTP", "VERIFY_EMAIL", "UPDATE_PROFILE". Неизвестные действия логируются как предупреждение, но не вызывают исключение.</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null).</param>
    /// <param name="cancellationToken">Токен отмены операции.</param>
    /// <returns>true, если операция выполнена успешно, иначе false.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах (null, пустые строки, пустая коллекция).</exception>
    /// <exception cref="ArgumentNullException">Выбрасывается если actions равен null.</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса.</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции.</exception>
    public async Task<bool> ExecuteActionsEmailAsync(
        string accessToken,
        string realm,
        string userId,
        List<string> actions,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        ValidateCommonParameters(accessToken, realm);
        ValidateUserId(userId);
        ValidateActionsList(actions);
        ValidateTargetUsername(targetUsername);
        
        _logger.LogInformation("Executing {Count} email actions for user {UserId} in realm {Realm}", 
            actions.Count, userId, realm);
        
        return await ExecuteWithMetricsAsync(
            async ct =>
            {
                var result = await _actionsService.ExecuteActionsEmailAsync(accessToken, realm, userId, actions, targetUsername, ct)
                    .ConfigureAwait(false);
                
                // Логируем только результат операции (успех/неудача)
                if (!result)
                {
                    _logger.LogWarning("Failed to execute email actions for user {UserId} in realm {Realm}", userId, realm);
                }
                
                return result;
            },
            "ExecuteActionsEmail",
            realm,
            userId,
            cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Заблокировать пользователя
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса. Не может быть null или пустым.</param>
    /// <param name="realm">Название реалма. Не может быть null или пустым.</param>
    /// <param name="userId">ID пользователя. Не может быть null или пустым.</param>
    /// <param name="reason">Причина блокировки. Не может быть null или пустым, максимальная длина: 500 символов.</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null).</param>
    /// <param name="cancellationToken">Токен отмены операции.</param>
    /// <returns>true, если блокировка выполнена успешно, иначе false.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах.</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса.</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции.</exception>
    public async Task<bool> BlockUserAsync(
        string accessToken,
        string realm,
        string userId,
        string reason,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        ValidateCommonParameters(accessToken, realm);
        ValidateUserId(userId);
        ValidateReason(reason);
        ValidateTargetUsername(targetUsername);
        
        _logger.LogWarning("Blocking user {UserId} in realm {Realm}, reason: {Reason}", userId, realm, reason);
        
        return await ExecuteWithMetricsAsync(
            async ct =>
            {
                var result = await _actionsService.BlockUserAsync(accessToken, realm, userId, reason, targetUsername, ct)
                    .ConfigureAwait(false);
                
                // Логируем только результат операции (успех/неудача)
                if (!result)
                {
                    _logger.LogError("Failed to block user {UserId} in realm {Realm}", userId, realm);
                }
                
                return result;
            },
            "BlockUser",
            realm,
            userId,
            cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Разблокировать пользователя
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса. Не может быть null или пустым.</param>
    /// <param name="realm">Название реалма. Не может быть null или пустым.</param>
    /// <param name="userId">ID пользователя. Не может быть null или пустым.</param>
    /// <param name="reason">Причина разблокировки. Не может быть null или пустым, максимальная длина: 500 символов.</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null).</param>
    /// <param name="cancellationToken">Токен отмены операции.</param>
    /// <returns>true, если разблокировка выполнена успешно, иначе false.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах.</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса.</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции.</exception>
    public async Task<bool> UnblockUserAsync(
        string accessToken,
        string realm,
        string userId,
        string reason,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        ValidateCommonParameters(accessToken, realm);
        ValidateUserId(userId);
        ValidateReason(reason);
        ValidateTargetUsername(targetUsername);
        
        _logger.LogInformation("Unblocking user {UserId} in realm {Realm}, reason: {Reason}", userId, realm, reason);
        
        return await ExecuteWithMetricsAsync(
            async ct =>
            {
                var result = await _actionsService.UnblockUserAsync(accessToken, realm, userId, reason, targetUsername, ct)
                    .ConfigureAwait(false);
                
                // Логируем только результат операции (успех/неудача)
                if (!result)
                {
                    _logger.LogWarning("Failed to unblock user {UserId} in realm {Realm}", userId, realm);
                }
                
                return result;
            },
            "UnblockUser",
            realm,
            userId,
            cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Получить сертификат пользователя в формате Base64 (X.509)
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса. Не может быть null или пустым.</param>
    /// <param name="realm">Название реалма. Не может быть null или пустым.</param>
    /// <param name="userId">ID пользователя. Не может быть null или пустым.</param>
    /// <param name="cancellationToken">Токен отмены операции.</param>
    /// <returns>Базовое64 представление сертификата или null, если сертификат отсутствует.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах.</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса.</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции.</exception>
    public async Task<string?> GetUserCertificateAsync(
        string accessToken,
        string realm,
        string userId,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        ValidateCommonParameters(accessToken, realm);
        ValidateUserId(userId);
        
        _logger.LogDebug("Getting certificate for user {UserId} in realm {Realm}", userId, realm);
        
        return await ExecuteWithMetricsAsync(
            async ct =>
            {
                var result = await _certificateService.GetUserCertificateAsync(accessToken, realm, userId, ct)
                    .ConfigureAwait(false);
                
                // Логируем только специфичную информацию (наличие сертификата)
                if (result == null)
                {
                    _logger.LogDebug("No certificate found for user {UserId} in realm {Realm}", userId, realm);
                }
                
                return result;
            },
            "GetUserCertificate",
            realm,
            userId,
            cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Загрузить (обновить) сертификат пользователя
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса. Не может быть null или пустым.</param>
    /// <param name="realm">Название реалма. Не может быть null или пустым.</param>
    /// <param name="userId">ID пользователя. Не может быть null или пустым.</param>
    /// <param name="certificateStream">Поток с данными сертификата. Не может быть null, должен быть читаемым.</param>
    /// <param name="fileName">Имя файла сертификата. Не может быть null или пустым, максимальная длина: 255 символов, должен иметь допустимое расширение.</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null).</param>
    /// <param name="cancellationToken">Токен отмены операции.</param>
    /// <returns>true, если загрузка выполнена успешно, иначе false.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах.</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса.</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции.</exception>
    public async Task<bool> UploadUserCertificateAsync(
        string accessToken,
        string realm,
        string userId,
        Stream certificateStream,
        string fileName,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        ValidateCommonParameters(accessToken, realm);
        ValidateUserId(userId);
        ValidateCertificateStream(certificateStream);
        ValidateFileName(fileName);
        ValidateTargetUsername(targetUsername);
        
        _logger.LogInformation("Uploading certificate {FileName} for user {UserId} in realm {Realm}", 
            fileName, userId, realm);
        
        return await ExecuteWithMetricsAsync(
            async ct =>
            {
                var result = await _certificateService.UploadUserCertificateAsync(accessToken, realm, userId, certificateStream, fileName, targetUsername, ct)
                    .ConfigureAwait(false);
                
                // Логируем только результат операции (успех/неудача)
                if (!result)
                {
                    _logger.LogWarning("Failed to upload certificate {FileName} for user {UserId} in realm {Realm}", 
                        fileName, userId, realm);
                }
                
                return result;
            },
            "UploadUserCertificate",
            realm,
            userId,
            cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Удалить сертификат пользователя
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса. Не может быть null или пустым.</param>
    /// <param name="realm">Название реалма. Не может быть null или пустым.</param>
    /// <param name="userId">ID пользователя. Не может быть null или пустым.</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null).</param>
    /// <param name="cancellationToken">Токен отмены операции.</param>
    /// <returns>true, если удаление выполнено успешно, иначе false.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах.</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса.</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции.</exception>
    public async Task<bool> DeleteUserCertificateAsync(
        string accessToken,
        string realm,
        string userId,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        ValidateCommonParameters(accessToken, realm);
        ValidateUserId(userId);
        ValidateTargetUsername(targetUsername);
        
        _logger.LogInformation("Deleting certificate for user {UserId} in realm {Realm}", userId, realm);
        
        return await ExecuteWithMetricsAsync(
            async ct =>
            {
                var result = await _certificateService.DeleteUserCertificateAsync(accessToken, realm, userId, targetUsername, ct)
                    .ConfigureAwait(false);
                
                // Логируем только результат операции (успех/неудача)
                if (!result)
                {
                    _logger.LogWarning("Failed to delete certificate for user {UserId} in realm {Realm}", userId, realm);
                }
                
                return result;
            },
            "DeleteUserCertificate",
            realm,
            userId,
            cancellationToken).ConfigureAwait(false);
    }
    
    #region Вспомогательные методы выполнения операций
    
    /// <summary>
    /// Выполнить операцию с метриками производительности и обработкой исключений
    /// </summary>
    /// <typeparam name="T">Тип результата операции</typeparam>
    /// <param name="operation">Асинхронная операция для выполнения</param>
    /// <param name="operationName">Имя операции для логирования</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя (опционально)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Результат операции</returns>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса</exception>
    /// <exception cref="Exception">Выбрасывается при других ошибках</exception>
    private async Task<T> ExecuteWithMetricsAsync<T>(
        Func<CancellationToken, Task<T>> operation,
        string operationName,
        string realm,
        string? userId = null,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        var userIdSuffix = userId != null ? $", userId: {userId}" : "";
        
        try
        {
            var result = await operation(cancellationToken).ConfigureAwait(false);
            stopwatch.Stop();
            _logger.LogInformation("{Operation} completed successfully in {ElapsedMs}ms for realm {Realm}{UserId}", 
                operationName, stopwatch.ElapsedMilliseconds, realm, userIdSuffix);
            return result;
        }
        catch (OperationCanceledException)
        {
            stopwatch.Stop();
            _logger.LogWarning("{Operation} was cancelled after {ElapsedMs}ms for realm {Realm}{UserId}", 
                operationName, stopwatch.ElapsedMilliseconds, realm, userIdSuffix);
            throw;
        }
        catch (HttpRequestException ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "{Operation} HTTP error after {ElapsedMs}ms for realm {Realm}{UserId}", 
                operationName, stopwatch.ElapsedMilliseconds, realm, userIdSuffix);
            throw;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "{Operation} unexpected error after {ElapsedMs}ms for realm {Realm}{UserId}", 
                operationName, stopwatch.ElapsedMilliseconds, realm, userIdSuffix);
            throw;
        }
    }
    
    #endregion
    
    #region Вспомогательные методы валидации
    
    /// <summary>
    /// Валидация общих параметров запроса (accessToken и realm)
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации. Не может быть null или пустым, максимальная длина: 10000 символов</param>
    /// <param name="realm">Название реалма. Не может быть null или пустым, максимальная длина: 100 символов, должен содержать только буквы, цифры, дефисы, подчеркивания и точки</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    private void ValidateCommonParameters(string? accessToken, string? realm)
    {
        if (string.IsNullOrWhiteSpace(accessToken))
            throw new ArgumentException("Access token cannot be null or empty", nameof(accessToken));
        
        if (accessToken.Length > MaxAccessTokenLength)
            throw new ArgumentException($"Access token cannot exceed {MaxAccessTokenLength} characters", nameof(accessToken));
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        // Валидация realm на инъекции
        if (!IsValidRealm(realm))
            throw new ArgumentException("Realm contains invalid characters", nameof(realm));
        
        if (realm.Length > MaxRealmLength)
            throw new ArgumentException($"Realm cannot exceed {MaxRealmLength} characters", nameof(realm));
    }
    
    /// <summary>
    /// Валидация ID пользователя
    /// </summary>
    /// <param name="userId">ID пользователя для валидации</param>
    /// <param name="paramName">Имя параметра для сообщений об ошибках</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидном userId</exception>
    private void ValidateUserId(string userId, string paramName = "userId")
    {
        if (string.IsNullOrWhiteSpace(userId))
            throw new ArgumentException($"{paramName} cannot be null or empty", paramName);
        
        if (userId.Length > MaxUserIdLength)
            throw new ArgumentException($"{paramName} cannot exceed {MaxUserIdLength} characters", paramName);
        
        // Валидация на опасные символы (GUID обычно содержит только hex символы и дефисы)
        if (!IsValidUserId(userId))
            throw new ArgumentException($"{paramName} contains invalid characters", paramName);
    }
    
    /// <summary>
    /// Валидация имени пользователя
    /// </summary>
    /// <param name="username">Имя пользователя для валидации</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидном username</exception>
    private void ValidateUsername(string username)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        
        if (username.Length > MaxUsernameLength)
            throw new ArgumentException($"Username cannot exceed {MaxUsernameLength} characters", nameof(username));
        
        // Валидация на опасные символы
        if (username.IndexOfAny(InvalidUsernameChars) >= 0)
            throw new ArgumentException("Username contains invalid characters", nameof(username));
    }
    
    /// <summary>
    /// Валидация имени
    /// </summary>
    /// <param name="firstName">Имя для валидации</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидном firstName</exception>
    private void ValidateFirstName(string firstName)
    {
        if (string.IsNullOrWhiteSpace(firstName))
            throw new ArgumentException("First name cannot be null or empty", nameof(firstName));
        
        if (firstName.Length > MaxFirstNameLength)
            throw new ArgumentException($"First name cannot exceed {MaxFirstNameLength} characters", nameof(firstName));
        
        // Валидация на управляющие символы
        if (firstName.IndexOfAny(InvalidNameChars) >= 0)
            throw new ArgumentException("First name contains invalid control characters", nameof(firstName));
    }
    
    /// <summary>
    /// Валидация фамилии
    /// </summary>
    /// <param name="lastName">Фамилия для валидации</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидном lastName</exception>
    private void ValidateLastName(string lastName)
    {
        if (string.IsNullOrWhiteSpace(lastName))
            throw new ArgumentException("Last name cannot be null or empty", nameof(lastName));
        
        if (lastName.Length > MaxLastNameLength)
            throw new ArgumentException($"Last name cannot exceed {MaxLastNameLength} characters", nameof(lastName));
        
        // Валидация на управляющие символы
        if (lastName.IndexOfAny(InvalidNameChars) >= 0)
            throw new ArgumentException("Last name contains invalid control characters", nameof(lastName));
    }
    
    /// <summary>
    /// Валидация email адреса
    /// </summary>
    /// <param name="email">Email адрес для валидации</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидном email</exception>
    private void ValidateEmail(string email)
    {
        if (string.IsNullOrWhiteSpace(email))
            throw new ArgumentException("Email cannot be null or empty", nameof(email));
        
        if (email.Length > MaxEmailLength)
            throw new ArgumentException($"Email cannot exceed {MaxEmailLength} characters", nameof(email));
        
        if (!IsValidEmail(email))
            throw new ArgumentException("Invalid email format", nameof(email));
    }
    
    /// <summary>
    /// Валидация ID клиента
    /// </summary>
    /// <param name="clientId">ID клиента для валидации</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидном clientId</exception>
    private void ValidateClientId(string clientId)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        
        if (clientId.Length > MaxClientIdLength)
            throw new ArgumentException($"Client ID cannot exceed {MaxClientIdLength} characters", nameof(clientId));
        
        // Валидация на опасные символы
        if (!IsValidClientId(clientId))
            throw new ArgumentException("Client ID contains invalid characters", nameof(clientId));
    }
    
    /// <summary>
    /// Валидация client роли
    /// </summary>
    /// <param name="role">Client роль для валидации</param>
    /// <exception cref="ArgumentNullException">Выбрасывается если role равен null</exception>
    /// <exception cref="ArgumentException">Выбрасывается если роль не имеет ни Id, ни Name</exception>
    private void ValidateClientRole(UserClientRoleDto role)
    {
        if (role == null)
            throw new ArgumentNullException(nameof(role));
        
        if (string.IsNullOrWhiteSpace(role.Id) && string.IsNullOrWhiteSpace(role.Name))
            throw new ArgumentException("Role must have either Id or Name", nameof(role));
    }
    
    /// <summary>
    /// Валидация списка ролей
    /// </summary>
    /// <typeparam name="T">Тип роли (UserRealmRoleDto или UserClientRoleDto)</typeparam>
    /// <param name="roles">Список ролей для валидации</param>
    /// <param name="paramName">Имя параметра для сообщений об ошибках</param>
    /// <exception cref="ArgumentNullException">Выбрасывается если roles равен null</exception>
    /// <exception cref="ArgumentException">Выбрасывается если список пуст или содержит невалидные элементы</exception>
    private void ValidateRolesList<T>(IList<T> roles, string paramName) where T : class
    {
        if (roles == null)
            throw new ArgumentNullException(paramName);
        
        if (roles.Count == 0)
            throw new ArgumentException($"{paramName} cannot be empty", paramName);
        
        // Валидация каждого элемента коллекции
        for (int i = 0; i < roles.Count; i++)
        {
            var role = roles[i];
            if (role == null)
                throw new ArgumentException($"{paramName} at index {i} cannot be null", paramName);
            
            // Для UserRealmRoleDto проверяем наличие Id или Name
            if (role is UserRealmRoleDto realmRole)
            {
                if (string.IsNullOrWhiteSpace(realmRole.Id) && string.IsNullOrWhiteSpace(realmRole.Name))
                    throw new ArgumentException($"{paramName} at index {i} must have either Id or Name", paramName);
            }
        }
    }
    
    /// <summary>
    /// Валидация списка действий
    /// </summary>
    /// <param name="actions">Список действий для валидации</param>
    /// <exception cref="ArgumentNullException">Выбрасывается если actions равен null</exception>
    /// <exception cref="ArgumentException">Выбрасывается если список пуст или содержит невалидные элементы</exception>
    private void ValidateActionsList(List<string> actions)
    {
        if (actions == null)
            throw new ArgumentNullException(nameof(actions));
        
        if (actions.Count == 0)
            throw new ArgumentException("Actions list cannot be empty", nameof(actions));
        
        // Валидация каждого действия
        for (int i = 0; i < actions.Count; i++)
        {
            var action = actions[i];
            if (string.IsNullOrWhiteSpace(action))
                throw new ArgumentException($"Action at index {i} cannot be null or empty", nameof(actions));
            
            // Предупреждение о неизвестных действиях (не выбрасываем исключение, так как Keycloak может поддерживать дополнительные действия)
            if (!ValidActions.Contains(action))
            {
                _logger.LogWarning("Unknown action '{Action}' at index {Index}. Valid actions are: {ValidActions}", 
                    action, i, ValidActionsString);
            }
        }
    }
    
    /// <summary>
    /// Валидация причины (для блокировки/разблокировки)
    /// </summary>
    /// <param name="reason">Причина для валидации</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидном reason</exception>
    private void ValidateReason(string reason)
    {
        if (string.IsNullOrWhiteSpace(reason))
            throw new ArgumentException("Reason cannot be null or empty", nameof(reason));
        
        if (reason.Length > MaxReasonLength)
            throw new ArgumentException($"Reason cannot exceed {MaxReasonLength} characters", nameof(reason));
        
        // Валидация на управляющие символы
        if (reason.IndexOfAny(InvalidReasonChars) >= 0)
            throw new ArgumentException("Reason contains invalid control characters", nameof(reason));
    }
    
    /// <summary>
    /// Валидация имени целевого пользователя для аудита
    /// </summary>
    /// <param name="targetUsername">Имя целевого пользователя для валидации. Может быть null.</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидном targetUsername</exception>
    private void ValidateTargetUsername(string? targetUsername)
    {
        if (targetUsername == null)
            return; // null допустим
        
        if (string.IsNullOrWhiteSpace(targetUsername))
            throw new ArgumentException("Target username cannot be empty or whitespace", nameof(targetUsername));
        
        if (targetUsername.Length > MaxTargetUsernameLength)
            throw new ArgumentException($"Target username cannot exceed {MaxTargetUsernameLength} characters", nameof(targetUsername));
        
        // Валидация на опасные символы
        if (targetUsername.IndexOfAny(InvalidUsernameChars) >= 0)
            throw new ArgumentException("Target username contains invalid characters", nameof(targetUsername));
    }
    
    /// <summary>
    /// Валидация потока сертификата
    /// </summary>
    /// <param name="certificateStream">Поток сертификата для валидации</param>
    /// <exception cref="ArgumentNullException">Выбрасывается если certificateStream равен null</exception>
    /// <exception cref="ArgumentException">Выбрасывается если поток не читаемый или превышает максимальный размер</exception>
    private void ValidateCertificateStream(Stream certificateStream)
    {
        if (certificateStream == null)
            throw new ArgumentNullException(nameof(certificateStream));
        
        if (!certificateStream.CanRead)
            throw new ArgumentException("Certificate stream must be readable", nameof(certificateStream));
        
        // Проверка размера потока (если доступен)
        if (certificateStream.CanSeek && certificateStream.Length > MaxCertificateSize)
            throw new ArgumentException($"Certificate size cannot exceed {MaxCertificateSize / (1024 * 1024)} MB", nameof(certificateStream));
    }
    
    /// <summary>
    /// Валидация имени файла
    /// </summary>
    /// <param name="fileName">Имя файла для валидации</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидном fileName</exception>
    private void ValidateFileName(string fileName)
    {
        if (string.IsNullOrWhiteSpace(fileName))
            throw new ArgumentException("File name cannot be null or empty", nameof(fileName));
        
        if (fileName.Length > MaxFileNameLength)
            throw new ArgumentException($"File name cannot exceed {MaxFileNameLength} characters", nameof(fileName));
        
        // Валидация имени файла на опасные символы
        if (fileName.IndexOfAny(InvalidFileNameChars) >= 0)
            throw new ArgumentException("File name contains invalid characters", nameof(fileName));
        
        // Проверка расширения файла
        var extension = Path.GetExtension(fileName).ToLowerInvariant();
        if (!AllowedCertificateExtensions.Contains(extension))
            throw new ArgumentException($"File extension '{extension}' is not allowed. Allowed extensions: {string.Join(", ", AllowedCertificateExtensions)}", nameof(fileName));
    }
    
    /// <summary>
    /// Проверка валидности realm (только буквы, цифры, дефисы, подчеркивания, точки)
    /// </summary>
    /// <param name="value">Значение для проверки</param>
    /// <returns>true, если значение валидно, иначе false</returns>
    private static bool IsValidRealm(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return false;
        
        return value.All(c => char.IsLetterOrDigit(c) || c == '-' || c == '_' || c == '.');
    }
    
    /// <summary>
    /// Проверка валидности userId (только буквы, цифры, дефисы, подчеркивания)
    /// </summary>
    /// <param name="value">Значение для проверки</param>
    /// <returns>true, если значение валидно, иначе false</returns>
    private static bool IsValidUserId(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return false;
        
        // GUID формат: 8-4-4-4-12 hex символов с дефисами
        // Или просто hex символы, буквы, цифры, дефисы, подчеркивания
        return value.All(c => char.IsLetterOrDigit(c) || c == '-' || c == '_');
    }
    
    /// <summary>
    /// Проверка валидности email адреса
    /// </summary>
    /// <param name="email">Email адрес для проверки</param>
    /// <returns>true, если email валиден, иначе false</returns>
    private static bool IsValidEmail(string email)
    {
        if (string.IsNullOrWhiteSpace(email))
            return false;
        
        // Быстрая проверка формата перед использованием MailAddress
        if (email.Length > MaxEmailLength)
            return false;
        
        if (!email.Contains('@', StringComparison.Ordinal) || email.Count(c => c == '@') != 1)
            return false;
        
        var parts = email.Split('@');
        if (parts.Length != 2 || string.IsNullOrWhiteSpace(parts[0]) || string.IsNullOrWhiteSpace(parts[1]))
            return false;
        
        try
        {
            var addr = new MailAddress(email);
            return addr.Address == email;
        }
        catch
        {
            return false;
        }
    }
    
    /// <summary>
    /// Проверка валидности client ID (только буквы, цифры, дефисы, подчеркивания)
    /// </summary>
    /// <param name="value">Значение для проверки</param>
    /// <returns>true, если значение валидно, иначе false</returns>
    private static bool IsValidClientId(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return false;
        
        // Client ID обычно содержит только буквы, цифры, дефисы, подчеркивания
        return value.All(c => char.IsLetterOrDigit(c) || c == '-' || c == '_');
    }
    
    #endregion
}
