using System.Net;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.DTOs;
using new_assistant.Core.Entities;
using new_assistant.Core.Interfaces;
using new_assistant.Infrastructure.Services.Confluence;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для работы с Confluence Wiki API
/// </summary>
public class ConfluenceService : IConfluenceService
{
    private readonly IConfluenceApiClient _apiClient;
    private readonly IConfluencePageBuilder _pageBuilder;
    private readonly IConfluencePageParser _pageParser;
    private readonly ConfluenceSettings _settings;
    private readonly IWikiPageRepository _wikiPageRepository;
    private readonly IConfluenceTemplateProvider _templateProvider;
    private readonly ConfluenceLabelsService _labelsService;
    private readonly ILogger<ConfluenceService> _logger;
    private readonly IAuditService? _auditService;
    private readonly IPerformanceMetricsService? _metricsService;

    private const int MaxClientIdLength = 255;
    private const string DefaultRealm = "GLOBAL";
    private const int HealthCheckTimeoutSeconds = 5;

    public ConfluenceService(
        IConfluenceApiClient apiClient,
        IConfluencePageBuilder pageBuilder,
        IConfluencePageParser pageParser,
        IOptions<ConfluenceSettings> settings,
        IWikiPageRepository wikiPageRepository,
        IConfluenceTemplateProvider templateProvider,
        ConfluenceLabelsService labelsService,
        ILogger<ConfluenceService> logger,
        IAuditService? auditService = null,
        IPerformanceMetricsService? metricsService = null)
    {
        _apiClient = apiClient;
        _pageBuilder = pageBuilder;
        _pageParser = pageParser;
        _settings = settings.Value;
        _wikiPageRepository = wikiPageRepository;
        _templateProvider = templateProvider;
        _labelsService = labelsService;
        _logger = logger;
        _auditService = auditService;
        _metricsService = metricsService;
    }


    public async Task<string?> CreateClientPageAsync(
        ClientCreationData clientData,
        string createdBy,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        if (clientData == null)
            throw new ArgumentNullException(nameof(clientData));
        
        if (string.IsNullOrWhiteSpace(clientData.ClientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientData));
        
        if (string.IsNullOrWhiteSpace(createdBy))
            throw new ArgumentException("CreatedBy cannot be null or empty", nameof(createdBy));
        
        // Валидация длины
        if (clientData.ClientId.Length > MaxClientIdLength)
            throw new ArgumentException($"Client ID exceeds maximum length of {MaxClientIdLength} characters", nameof(clientData));
        
        if (!_settings.Enabled || !_settings.CreatePageOnClientCreation)
        {
            return null;
        }

        try
        {
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            var publicationStatus = clientData.PublicationStatus ?? "TEST";

            // Проверить, не существует ли уже страница
            var existingPage = await _wikiPageRepository.GetWikiPageAnyRealmAsync(clientData.ClientId).ConfigureAwait(false);
            if (existingPage != null)
            {
                _logger.LogWarning("Wiki page already exists for client {ClientId} in realm {Realm}", 
                    clientData.ClientId, clientData.Realm);
                return existingPage.WikiPageUrl;
            }

            // Заполнить шаблон
            var pageContent = _pageBuilder.BuildPageContent(clientData);
            var realmPrefix = _pageBuilder.BuildRealmPrefix(clientData.Realm);
            
            // Безопасное формирование заголовка страницы
            var pageTitle = _templateProvider.GetTitle(realmPrefix, clientData.ClientId);

            // Создать страницу через API
            var confluencePageResponse = await _apiClient.CreatePageAsync(
                pageTitle,
                pageContent,
                _settings.SpaceKey,
                _settings.ParentPageId,
                cancellationToken).ConfigureAwait(false);

            if (confluencePageResponse == null)
            {
                _logger.LogError("Failed to create Confluence page for client {ClientId}", clientData.ClientId);
                _metricsService?.RecordError("Confluence.CreateClientPage", "CreatePageFailed");
                return null;
            }

            // Добавить метки к созданной странице (не критично, ошибки логируем)
            try
            {
                var labels = _labelsService.BuildDefaultLabels(clientData.Realm);
                await _labelsService.AddLabelsAsync(confluencePageResponse.Id, labels, cancellationToken).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Не удалось добавить метки для страницы Confluence {PageId}", confluencePageResponse.Id);
            }

            // Сохранить связь в БД
            var wikiPage = new ClientWikiPage
            {
                ClientId = clientData.ClientId,
                Realm = clientData.Realm ?? DefaultRealm,
                WikiPageId = confluencePageResponse.Id,
                WikiPageTitle = pageTitle,
                WikiPageUrl = confluencePageResponse.Url,
                Status = "Active",
                CreatedBy = createdBy,
                PageVersion = confluencePageResponse.Version
            };

            await _wikiPageRepository.SaveWikiPageAsync(wikiPage).ConfigureAwait(false);

            // Логирование в аудит
            if (_auditService != null)
            {
                await _auditService.LogClientCreatedAsync(
                    createdBy,
                    clientData.ClientId,
                    clientData.Realm ?? string.Empty,
                    $"Wiki page created: {confluencePageResponse.Url}");
            }

            stopwatch.Stop();
            _metricsService?.RecordOperationTime("Confluence.CreateClientPage", stopwatch.ElapsedMilliseconds);
            _metricsService?.RecordSuccess("Confluence.CreateClientPage");
            _logger.LogInformation("Wiki страница успешно создана для клиента {ClientId} - {Time}мс", 
                clientData.ClientId, stopwatch.ElapsedMilliseconds);

            return confluencePageResponse.Url;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP error creating Confluence page for client {ClientId}", clientData.ClientId);
            return null;
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogWarning(ex, "Request timeout creating Confluence page for client {ClientId}", clientData.ClientId);
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error creating Confluence page for client {ClientId}", clientData.ClientId);
            // Для неожиданных ошибок возвращаем null, чтобы не прерывать основной процесс создания клиента
            return null;
        }
    }

    public async Task<string?> UpdateClientPageAsync(
        ClientDetailsDto clientDetails,
        string updatedBy,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        if (clientDetails == null)
            throw new ArgumentNullException(nameof(clientDetails));
        
        if (string.IsNullOrWhiteSpace(clientDetails.ClientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientDetails));
        
        if (string.IsNullOrWhiteSpace(updatedBy))
            throw new ArgumentException("UpdatedBy cannot be null or empty", nameof(updatedBy));
        
        if (clientDetails.ClientId.Length > MaxClientIdLength)
            throw new ArgumentException($"Client ID exceeds maximum length of {MaxClientIdLength} characters", nameof(clientDetails));
        
        if (!_settings.Enabled || !_settings.UpdatePageOnClientUpdate)
        {
            return null;
        }

        try
        {
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            // Получить существующую страницу
            var wikiPage = await _wikiPageRepository.GetWikiPageAnyRealmAsync(clientDetails.ClientId);
            if (wikiPage == null)
            {
                _logger.LogWarning("No Wiki page found for client {ClientId} in realm {Realm}",
                    clientDetails.ClientId, clientDetails.Realm);
                return null;
            }

            // Получить текущую версию страницы из Confluence
            var currentPage = await _apiClient.GetPageAsync(wikiPage.WikiPageId, cancellationToken);
            if (currentPage == null)
            {
                _logger.LogError("Failed to get current page from Confluence for page ID {PageId}", wikiPage.WikiPageId);
                _metricsService?.RecordError("Confluence.UpdateClientPage", "GetPageFailed");
                return null;
            }

            // Заполнить шаблон (передаём текущий контент для извлечения полей владельца)
            var pageContent = await _pageBuilder.UpdatePageContent(clientDetails, currentPage.Body).ConfigureAwait(false);

            // Обновить страницу через API
            var updatedPage = await _apiClient.UpdatePageAsync(
                wikiPage.WikiPageId,
                wikiPage.WikiPageTitle,
                pageContent,
                currentPage.Version,
                cancellationToken).ConfigureAwait(false);

            if (updatedPage == null)
            {
                _logger.LogError("Failed to update Confluence page for client {ClientId}", clientDetails.ClientId);
                _metricsService?.RecordError("Confluence.UpdateClientPage", "UpdatePageFailed");
                return null;
            }

            // Обновить версию в БД
            wikiPage.PageVersion = updatedPage.Version;
            wikiPage.UpdatedAt = DateTime.UtcNow;
            await _wikiPageRepository.UpdateWikiPageAsync(wikiPage).ConfigureAwait(false);

            stopwatch.Stop();
            _metricsService?.RecordOperationTime("Confluence.UpdateClientPage", stopwatch.ElapsedMilliseconds);
            _metricsService?.RecordSuccess("Confluence.UpdateClientPage");
            _logger.LogInformation("Wiki страница успешно обновлена для клиента {ClientId} - {Time}мс", 
                clientDetails.ClientId, stopwatch.ElapsedMilliseconds);

            return wikiPage.WikiPageUrl;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP error updating Confluence page for client {ClientId}", clientDetails.ClientId);
            return null;
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogWarning(ex, "Request timeout updating Confluence page for client {ClientId}", clientDetails.ClientId);
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error updating Confluence page for client {ClientId}", clientDetails.ClientId);
            return null;
        }
    }

    public async Task<(string Id, string Title, string Url, int Version)?> ResolvePageAsync(string spaceKey, string title, CancellationToken cancellationToken = default)
    {
        return await _apiClient.ResolvePageAsync(spaceKey, title, cancellationToken).ConfigureAwait(false);
    }

    public async Task<(string Id, string Title, string Url)?> GetPageMetadataAsync(string pageId, CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        if (string.IsNullOrWhiteSpace(pageId))
            throw new ArgumentException("Page ID cannot be null or empty", nameof(pageId));

        var page = await _apiClient.GetPageAsync(pageId, cancellationToken).ConfigureAwait(false);
        if (page == null)
        {
            return null;
        }

        return (page.Id, page.Title, page.Url);
    }

    public async Task<bool> ArchiveClientPageAsync(
        string clientId,
        string realm,
        string archivedBy,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        
        if (string.IsNullOrWhiteSpace(archivedBy))
            throw new ArgumentException("ArchivedBy cannot be null or empty", nameof(archivedBy));
        
        var archived = false;

        try
        {
            if (_settings.Enabled && _settings.ArchivePageOnClientDeletion)
            {
                var stopwatch = System.Diagnostics.Stopwatch.StartNew();
                var wikiPage = await _wikiPageRepository.GetWikiPageAnyRealmAsync(clientId).ConfigureAwait(false);
                
                if (wikiPage == null)
                {
                    _logger.LogWarning("No Wiki page found for client {ClientId} in realm {Realm}", clientId, realm);
                }
                else
                {
                    // Получить текущую версию страницы
                    var currentPage = await _apiClient.GetPageAsync(wikiPage.WikiPageId, cancellationToken).ConfigureAwait(false);
                    if (currentPage == null)
                    {
                        _logger.LogError("Failed to get current page from Confluence for page ID {PageId}", wikiPage.WikiPageId);
                    }
                    else
                    {
                        // Добавить маркер архивации в начало страницы
                        var archiveNotice = $@"<ac:structured-macro ac:name=""panel"" ac:schema-version=""1"">
<ac:parameter ac:name=""bgColor"">#FFF3CD</ac:parameter>
<ac:parameter ac:name=""borderColor"">#FFC107</ac:parameter>
<ac:rich-text-body>
<p><strong>⚠️ АРХИВИРОВАНО</strong></p>
<p>Этот клиент был удалён из Keycloak. Страница сохранена для истории.</p>
<p>Дата архивации: {DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} UTC</p>
<p>Архивировал: {WebUtility.HtmlEncode(archivedBy)}</p>
</ac:rich-text-body>
</ac:structured-macro>
<br/>";

                        var archivedContent = archiveNotice + currentPage.Body;
                        var archivedTitle = $"[ARCHIVED] {wikiPage.WikiPageTitle}";

                        // Обновить страницу с маркером архивации
                        var updatedPage = await _apiClient.UpdatePageAsync(
                            wikiPage.WikiPageId,
                            archivedTitle,
                            archivedContent,
                            currentPage.Version,
                            cancellationToken).ConfigureAwait(false);

                        if (updatedPage == null)
                        {
                            _logger.LogError("Failed to archive Confluence page for client {ClientId}", clientId);
                        }
                        else
                        {
                            archived = true;
                            stopwatch.Stop();
                            _logger.LogInformation("Wiki страница успешно архивирована для клиента {ClientId} - {Time}мс", 
                                clientId, stopwatch.ElapsedMilliseconds);
                        }
                    }
                }
            }
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP error archiving Confluence page for client {ClientId}", clientId);
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogWarning(ex, "Request timeout archiving Confluence page for client {ClientId}", clientId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error archiving Confluence page for client {ClientId}", clientId);
        }
        finally
        {
            await RemoveWikiRecordAsync(clientId, realm).ConfigureAwait(false);
        }

        return archived;
    }

    public async Task<string?> GetWikiPageUrlAsync(string clientId, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        
        try
        {
            var wikiPage = await _wikiPageRepository.GetWikiPageAnyRealmAsync(clientId).ConfigureAwait(false);
            return wikiPage?.WikiPageUrl;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting Wiki page URL for client {ClientId}", clientId);
            return null;
        }
    }

    public async Task<bool> IsAvailableAsync()
    {
        if (!_settings.Enabled)
            return false;

        try
        {
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(HealthCheckTimeoutSeconds));
            return await _apiClient.IsAvailableAsync(cts.Token).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Confluence API is not available");
            return false;
        }
    }

    #region Private Helper Methods

    private async Task RemoveWikiRecordAsync(string clientId, string realm)
    {
        try
        {
            await _wikiPageRepository.DeleteWikiPageAsync(clientId, realm).ConfigureAwait(false);
            _logger.LogInformation("Wiki page record removed for client {ClientId}", clientId);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to remove Wiki page record for client {ClientId}", clientId);
        }
    }

    #endregion
}

