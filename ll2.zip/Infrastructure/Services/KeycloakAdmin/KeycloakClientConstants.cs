namespace new_assistant.Infrastructure.Services.KeycloakAdmin;

/// <summary>
/// Константы для работы с клиентами Keycloak
/// </summary>
internal static class KeycloakClientConstants
{
    public const string ProtocolOpenIdConnect = "openid-connect";
    public const string AccessTypePublic = "public";
    public const string AccessTypeBearerOnly = "bearer-only";
    public const string AccessTypeConfidential = "confidential";
    public const string EventTypeUnknown = "UNKNOWN";
    
    // Константы для магических чисел
    public const int DefaultEventsLimit = 10;
    public const int MaxEventsLimit = 1000;
    public const int MaxRoleSearchResults = 500;
    public const int MaxParallelSearchRequests = 5;
    public const int MaxAllEventsLimit = 10000;
}

