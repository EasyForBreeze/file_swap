using System.Text.Json;
using new_assistant.Core.Interfaces;
using new_assistant.Core.DTOs;
using Microsoft.Extensions.Logging;
using static new_assistant.Infrastructure.Services.KeycloakAdmin.KeycloakClientConstants;

namespace new_assistant.Infrastructure.Services.KeycloakAdmin;

/// <summary>
/// Сервис для работы с событиями клиентов Keycloak
/// </summary>
public class KeycloakClientEventsService : IKeycloakClientEventsService
{
    private readonly KeycloakHttpClient _httpClient;
    private readonly ILogger<KeycloakClientEventsService> _logger;

    public KeycloakClientEventsService(
        KeycloakHttpClient httpClient,
        ILogger<KeycloakClientEventsService> logger)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Загружает события клиента (для ленивой загрузки)
    /// </summary>
    public async Task<List<ClientEventDto>> LoadClientEventsAsync(string clientId, string realm, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId не может быть пустым", nameof(clientId));
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        try
        {
            // GetClientEventsAsync использует фильтр на уровне API, поэтому эффективно получает именно события этого клиента
            var events = await GetClientEventsAsync(clientId, realm, DefaultEventsLimit, cancellationToken);
            return events.ToList();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при загрузке событий клиента {ClientId} в реалме {Realm}", clientId, realm);
            return new List<ClientEventDto>();
        }
    }

    /// <summary>
    /// Получить события клиента
    /// </summary>
    public async Task<IEnumerable<ClientEventDto>> GetClientEventsAsync(string clientId, string realm, CancellationToken cancellationToken = default)
    {
        return await GetClientEventsAsync(clientId, realm, DefaultEventsLimit, cancellationToken);
    }

    /// <summary>
    /// Получить события клиента (перегрузка с maxEvents)
    /// </summary>
    public async Task<IEnumerable<ClientEventDto>> GetClientEventsAsync(string clientId, string realm, int maxEvents, CancellationToken cancellationToken = default)
    {
        return await GetClientEventsAsync(clientId, realm, first: 0, maxEvents, cancellationToken);
    }

    /// <summary>
    /// Получение событий клиента с пагинацией (first и max)
    /// </summary>
    public async Task<IEnumerable<ClientEventDto>> GetClientEventsAsync(string clientId, string realm, int first, int maxEvents, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId не может быть пустым", nameof(clientId));
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        if (maxEvents <= 0)
            throw new ArgumentException("maxEvents должен быть больше 0", nameof(maxEvents));
        
        try
        {
            // Получаем события из реалма с фильтром по clientId и пагинацией на уровне API
            var eventsJson = await _httpClient.GetRealmEventsWithPaginationAsync(realm, first, maxEvents, clientId, cancellationToken);
            
            var clientEvents = new List<ClientEventDto>();
            
            foreach (var eventJson in eventsJson)
            {
                var evt = ParseEventFromJson(eventJson, clientId);
                if (evt != null)
                {
                    clientEvents.Add(evt);
                }
            }
            
            // События уже отсортированы на стороне Keycloak (новые сначала), возвращаем как есть
            return clientEvents;
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("Операция получения событий была отменена для клиента {ClientId} в реалме {Realm}", clientId, realm);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при получении событий клиента {ClientId} в реалме {Realm}", clientId, realm);
            return new List<ClientEventDto>();
        }
    }

    /// <summary>
    /// Получить все события клиента для фильтрации
    /// </summary>
    public async Task<IEnumerable<ClientEventDto>> GetAllClientEventsAsync(string clientId, string realm, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId не может быть пустым", nameof(clientId));
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        try
        {
            // Получаем больше событий с фильтром по clientId на уровне API
            var eventsJson = await _httpClient.GetRealmEventsWithLimitAsync(realm, MaxAllEventsLimit, clientId, cancellationToken);
            
            var clientEvents = new List<ClientEventDto>();
            
            foreach (var eventJson in eventsJson)
            {
                var evt = ParseEventFromJson(eventJson, clientId);
                if (evt != null)
                {
                    clientEvents.Add(evt);
                }
            }
            
            // Сортируем по времени (новые сначала)
            return clientEvents.OrderByDescending(e => e.Time).ToList();
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("Операция получения всех событий была отменена для клиента {ClientId} в реалме {Realm}", clientId, realm);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при получении всех событий клиента {ClientId} в реалме {Realm}", clientId, realm);
            return new List<ClientEventDto>();
        }
    }

    /// <summary>
    /// Получить все возможные типы событий из реалма
    /// </summary>
    public async Task<IEnumerable<string>> GetAllEventTypesAsync(string realm, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        try
        {
            // Используем правильный API endpoint для получения всех доступных типов событий
            var eventTypes = await _httpClient.GetEventTypesAsync(realm, cancellationToken);
            
            return eventTypes;
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("Операция получения типов событий была отменена для реалма {Realm}", realm);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при получении типов событий из реалма {Realm}", realm);
            return new List<string>();
        }
    }

    /// <summary>
    /// Парсинг события из JSON элемента
    /// </summary>
    private ClientEventDto? ParseEventFromJson(JsonElement eventJson, string expectedClientId)
    {
        var eventClientId = eventJson.TryGetProperty("clientId", out var clientIdProp) 
            ? clientIdProp.GetString() 
            : null;
        
        if (eventClientId != expectedClientId)
            return null;
        
        return new ClientEventDto
        {
            Id = eventJson.TryGetProperty("id", out var idProp) && idProp.ValueKind == JsonValueKind.String
                ? idProp.GetString() ?? string.Empty
                : string.Empty,
            Time = eventJson.TryGetProperty("time", out var timeProp) && timeProp.ValueKind == JsonValueKind.Number
                ? DateTimeOffset.FromUnixTimeMilliseconds(timeProp.GetInt64()).DateTime
                : DateTime.UtcNow,
            Type = eventJson.TryGetProperty("type", out var typeProp) 
                ? typeProp.GetString() ?? EventTypeUnknown 
                : EventTypeUnknown,
            Details = eventJson.TryGetProperty("details", out var detailsProp) 
                ? detailsProp.ToString() 
                : null,
            UserId = eventJson.TryGetProperty("userId", out var userIdProp) 
                ? userIdProp.GetString() 
                : null,
            IpAddress = eventJson.TryGetProperty("ipAddress", out var ipProp) 
                ? ipProp.GetString() 
                : null
        };
    }
}

