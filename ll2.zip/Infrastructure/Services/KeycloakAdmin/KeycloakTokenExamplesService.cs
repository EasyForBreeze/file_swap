using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services.KeycloakAdmin;

/// <summary>
/// Сервис для генерации примеров токенов Keycloak
/// </summary>
public class KeycloakTokenExamplesService : IKeycloakTokenExamplesService
{
    private readonly KeycloakHttpClient _httpClient;

    public KeycloakTokenExamplesService(KeycloakHttpClient httpClient)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
    }

    /// <summary>
    /// Генерация example access token для пользователя
    /// </summary>
    public async Task<string> GenerateExampleAccessTokenAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        if (string.IsNullOrWhiteSpace(clientInternalId))
            throw new ArgumentException("ClientInternalId не может быть пустым", nameof(clientInternalId));
        
        if (string.IsNullOrWhiteSpace(userId))
            throw new ArgumentException("UserId не может быть пустым", nameof(userId));
        
        return await _httpClient.GenerateExampleAccessTokenAsync(realm, clientInternalId, userId, scope, cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Генерация example ID token для пользователя
    /// </summary>
    public async Task<string> GenerateExampleIdTokenAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        if (string.IsNullOrWhiteSpace(clientInternalId))
            throw new ArgumentException("ClientInternalId не может быть пустым", nameof(clientInternalId));
        
        if (string.IsNullOrWhiteSpace(userId))
            throw new ArgumentException("UserId не может быть пустым", nameof(userId));
        
        return await _httpClient.GenerateExampleIdTokenAsync(realm, clientInternalId, userId, scope, cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Генерация example userinfo для пользователя
    /// </summary>
    public async Task<string> GenerateExampleUserInfoAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        if (string.IsNullOrWhiteSpace(clientInternalId))
            throw new ArgumentException("ClientInternalId не может быть пустым", nameof(clientInternalId));
        
        if (string.IsNullOrWhiteSpace(userId))
            throw new ArgumentException("UserId не может быть пустым", nameof(userId));
        
        return await _httpClient.GenerateExampleUserInfoAsync(realm, clientInternalId, userId, scope, cancellationToken).ConfigureAwait(false);
    }
}

