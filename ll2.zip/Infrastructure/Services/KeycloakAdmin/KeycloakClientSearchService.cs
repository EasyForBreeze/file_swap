using System.Diagnostics;
using System.Collections.Concurrent;
using new_assistant.Core.Interfaces;
using new_assistant.Core.DTOs;
using System.Linq;
using new_assistant.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace new_assistant.Infrastructure.Services.KeycloakAdmin;

/// <summary>
/// Сервис для поиска клиентов Keycloak
/// </summary>
public class KeycloakClientSearchService : IKeycloakClientSearchService
{
    private const int MaxParallelSearchRequests = 5;
    
    private readonly KeycloakHttpClient _httpClient;
    private readonly KeycloakAdminSettings _settings;
    private readonly ILogger<KeycloakClientSearchService> _logger;
    private readonly IKeycloakRealmService _realmService;

    public KeycloakClientSearchService(
        KeycloakHttpClient httpClient,
        IOptions<KeycloakAdminSettings> settings,
        ILogger<KeycloakClientSearchService> logger,
        IKeycloakRealmService realmService)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _settings = settings?.Value ?? throw new ArgumentNullException(nameof(settings));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _realmService = realmService ?? throw new ArgumentNullException(nameof(realmService));
    }

    /// <summary>
    /// Поиск клиентов с отслеживанием прогресса
    /// </summary>
    public async Task<ClientsSearchResponse> SearchClientsWithProgressAsync(
        string searchTerm, 
        IProgress<SearchProgress> progress, 
        CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        var response = new ClientsSearchResponse();
        SemaphoreSlim? searchSemaphore = null;

        try
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                response.Status = SearchStatus.Waiting;
                return response;
            }

            
            response.Status = SearchStatus.InProgress;
            
            // 1. Получаем список реалмов
            progress?.Report(new SearchProgress 
            { 
                Status = "Получение списка реалмов...",
                TotalRealms = 0,
                CompletedRealms = 0
            });

            var realms = (await _realmService.GetRealmsListAsync(cancellationToken)).ToList();
            
            progress?.Report(new SearchProgress 
            { 
                Status = $"Найдено {realms.Count} реалмов для поиска",
                TotalRealms = realms.Count,
                CompletedRealms = 0,
                CurrentRealm = null
            });

            if (realms.Count == 0)
            {
                _logger.LogWarning("Не найдено доступных реалмов для поиска");
                response.Status = SearchStatus.Completed;
                response.ErrorMessage = "Нет доступных реалмов для поиска";
                return response;
            }

            // 2. ОПТИМИЗАЦИЯ: Параллельный поиск по реалмам с ограничением конкурентности
            searchSemaphore = new SemaphoreSlim(MaxParallelSearchRequests, MaxParallelSearchRequests);
            
            var realmErrors = new ConcurrentDictionary<string, string>();
            
            var searchTasks = realms.Select(async realm =>
            {
                await searchSemaphore.WaitAsync(cancellationToken);
                try
                {
                    progress?.Report(new SearchProgress 
                    { 
                        Status = $"Поиск в реалме '{realm}'...",
                        TotalRealms = realms.Count,
                        CurrentRealm = realm
                    });

                    var realmResults = await _httpClient.SearchClientsInRealmAsync(realm, searchTerm, cancellationToken);
                    
                    // Помечаем каждому результату реалм
                    foreach (var result in realmResults)
                    {
                        result.Realm = realm;
                    }

                    progress?.Report(new SearchProgress 
                    { 
                        Status = $"Поиск в реалме '{realm}' завершен",
                        TotalRealms = realms.Count,
                        CurrentRealm = null
                    });

                    return realmResults;
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Ошибка поиска в реалме {Realm}", realm);
                    realmErrors.TryAdd(realm, ex.Message);
                    return new List<ClientSearchResult>();
                }
                finally
                {
                    searchSemaphore.Release();
                }
            });

            // 3. Собираем результаты
            var allResults = await Task.WhenAll(searchTasks);
            
            response.Clients = allResults
                .SelectMany(results => results)
                .OrderBy(c => c.Name)
                .Take(_settings.MaxSearchResults)
                .ToList();
                
            response.TotalFound = response.Clients.Count;
            response.RealmsSearched = realms.Count;
            response.Status = SearchStatus.Completed;
            
            progress?.Report(new SearchProgress 
            { 
                Status = $"Поиск завершен. Найдено {response.TotalFound} клиентов",
                TotalRealms = realms.Count,
                CompletedRealms = realms.Count,
                ResultsFound = response.TotalFound,
                IsComplete = true
            });

            if (realmErrors.Any())
            {
                _logger.LogWarning("Поиск завершен с ошибками в {ErrorCount} реалмах: {Realms}", 
                    realmErrors.Count, string.Join(", ", realmErrors.Keys));
            }
        }
        catch (OperationCanceledException)
        {
            response.Status = SearchStatus.Completed;
            response.ErrorMessage = "Поиск отменен";
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка во время поиска клиентов");
            response.Status = SearchStatus.Error;
            response.ErrorMessage = ex.Message;
        }
        finally
        {
            searchSemaphore?.Dispose();
            stopwatch.Stop();
            response.SearchTime = stopwatch.Elapsed;
        }

        return response;
    }

    /// <summary>
    /// Простой поиск клиентов без прогресса
    /// </summary>
    public async Task<ClientsSearchResponse> SearchClientsAsync(
        string searchTerm, 
        CancellationToken cancellationToken = default)
    {
        var progress = new Progress<SearchProgress>();
        return await SearchClientsWithProgressAsync(searchTerm, progress, cancellationToken);
    }

    /// <summary>
    /// Поиск клиентов по Client ID (с опциональной фильтрацией по realm)
    /// </summary>
    public async Task<List<Controllers.ClientSearchResult>> SearchClientsByIdAsync(string searchTerm, string? realm = null, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(searchTerm))
            throw new ArgumentException("SearchTerm не может быть пустым", nameof(searchTerm));
        
        var stopwatch = Stopwatch.StartNew();
        try
        {
            var clients = await _httpClient.SearchClientsByIdAsync(searchTerm, realm, cancellationToken);
            
            stopwatch.Stop();
            _logger.LogInformation("Поиск клиентов по ID '{SearchTerm}' в реалме {Realm} - {Time}мс", 
                searchTerm, realm ?? "все", stopwatch.ElapsedMilliseconds);
            
            return clients;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "Ошибка поиска клиентов '{SearchTerm}' в реалме {Realm} - {Time}мс", 
                searchTerm, realm ?? "все", stopwatch.ElapsedMilliseconds);
            throw;
        }
    }
}

