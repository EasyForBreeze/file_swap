using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using System.Diagnostics;
using System.Security;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Фоновый сервис для автоматической очистки старых архивов
/// </summary>
public class ArchiveCleanupService : BackgroundService
{
    private readonly ILogger<ArchiveCleanupService> _logger;
    private readonly string _archivesDirectory;
    private readonly TimeSpan _cleanupInterval;
    private readonly int _archiveRetentionDays;
    private readonly TimeSpan? _initialDelay;

    public ArchiveCleanupService(
        IOptions<DataPathsSettings> dataPathsSettingsOptions,
        IOptions<ArchiveCleanupSettings> cleanupSettingsOptions,
        ILogger<ArchiveCleanupService> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        var dataPathsSettings = dataPathsSettingsOptions?.Value 
            ?? throw new ArgumentNullException(nameof(dataPathsSettingsOptions));
        
        var cleanupSettings = cleanupSettingsOptions?.Value 
            ?? throw new ArgumentNullException(nameof(cleanupSettingsOptions));

        _archivesDirectory = dataPathsSettings.GetArchivesDirectoryPath();
        
        if (string.IsNullOrWhiteSpace(_archivesDirectory))
            throw new ArgumentException("Путь к директории архивов не может быть пустым", nameof(dataPathsSettings));

        ValidatePath(_archivesDirectory);
        ValidateSettings(cleanupSettings);

        _cleanupInterval = cleanupSettings.CleanupInterval;
        _archiveRetentionDays = cleanupSettings.ArchiveRetentionDays;
        _initialDelay = cleanupSettings.InitialDelay;
    }

    private void ValidateSettings(ArchiveCleanupSettings settings)
    {
        if (settings.CleanupInterval <= TimeSpan.Zero)
            throw new ArgumentException("Интервал очистки должен быть больше нуля", nameof(settings));

        if (settings.ArchiveRetentionDays < 0)
            throw new ArgumentException("Количество дней хранения не может быть отрицательным", nameof(settings));

        if (settings.ArchiveRetentionDays > 3650) // 10 лет
            throw new ArgumentException("Количество дней хранения слишком большое (максимум 3650 дней)", nameof(settings));

        if (settings.InitialDelay.HasValue && settings.InitialDelay.Value < TimeSpan.Zero)
            throw new ArgumentException("Начальная задержка не может быть отрицательной", nameof(settings));
    }

    private void ValidatePath(string path)
    {
        try
        {
            var fullPath = Path.GetFullPath(path);
            if (fullPath.Length > 260) // Windows MAX_PATH
                throw new PathTooLongException($"Путь слишком длинный: {fullPath.Length} символов");
        }
        catch (PathTooLongException ex)
        {
            _logger.LogError(ex, "Путь к директории архивов слишком длинный: {ArchivesDirectory}", path);
            throw;
        }
        catch (ArgumentException ex)
        {
            _logger.LogError(ex, "Некорректный путь к директории архивов: {ArchivesDirectory}", path);
            throw;
        }
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Сервис очистки архивов запущен. Очистка каждые {Interval} дней, хранение {RetentionDays} дней, директория: {ArchivesDirectory}", 
            _cleanupInterval.TotalDays, _archiveRetentionDays, _archivesDirectory);

        // Опциональная задержка перед первой очисткой
        if (_initialDelay.HasValue && _initialDelay.Value > TimeSpan.Zero)
        {
            _logger.LogInformation("Ожидание {InitialDelay} перед первой очисткой", _initialDelay.Value);
            try
            {
                await Task.Delay(_initialDelay.Value, stoppingToken);
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("Сервис очистки архивов остановлен до первой очистки");
                return;
            }
        }

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await PerformCleanupAsync(stoppingToken);
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("Операция очистки архивов отменена");
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при выполнении очистки архивов");
            }

            // Ждем до следующей очистки
            try
            {
                await Task.Delay(_cleanupInterval, stoppingToken);
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("Сервис очистки архивов остановлен");
                break;
            }
        }
    }

    private async Task PerformCleanupAsync(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();

        _logger.LogInformation("Начало очистки архивов. Директория: {ArchivesDirectory}, Retention: {RetentionDays} дней", 
            _archivesDirectory, _archiveRetentionDays);

        var stopwatch = Stopwatch.StartNew();
        var cutoffDate = DateTime.UtcNow.AddDays(-_archiveRetentionDays);
        
        if (!Directory.Exists(_archivesDirectory))
        {
            _logger.LogDebug("Папка архивов не существует: {ArchivesDirectory}", _archivesDirectory);
            return;
        }

        // Получаем список файлов один раз (материализуем для избежания двойного перечисления)
        List<string> archiveFiles;
        try
        {
            archiveFiles = Directory.EnumerateFiles(_archivesDirectory, "*.zip", SearchOption.TopDirectoryOnly)
                .ToList();
            
            if (archiveFiles.Count == 0)
            {
                _logger.LogDebug("В директории архивов нет файлов для обработки");
                return;
            }
        }
        catch (DirectoryNotFoundException ex)
        {
            _logger.LogWarning(ex, "Директория архивов стала недоступна: {ArchivesDirectory}", _archivesDirectory);
            return;
        }
        catch (DriveNotFoundException ex)
        {
            _logger.LogWarning(ex, "Диск с директорией архивов недоступен: {ArchivesDirectory}", _archivesDirectory);
            return;
        }
        catch (UnauthorizedAccessException ex)
        {
            _logger.LogError(ex, "Нет доступа к директории архивов: {ArchivesDirectory}", _archivesDirectory);
            return;
        }
        catch (SecurityException ex)
        {
            _logger.LogError(ex, "Нет прав безопасности для доступа к директории архивов: {ArchivesDirectory}", _archivesDirectory);
            return;
        }
        catch (IOException ex)
        {
            _logger.LogWarning(ex, "Ошибка доступа к директории архивов: {ArchivesDirectory}", _archivesDirectory);
            return;
        }

        var deletedCount = 0;
        var totalSize = 0L;
        var errorCount = 0;
        var processedCount = 0;

        foreach (var filePath in archiveFiles)
        {
            cancellationToken.ThrowIfCancellationRequested();

            // Проверяем, что директория все еще существует
            if (!Directory.Exists(_archivesDirectory))
            {
                _logger.LogWarning("Директория архивов была удалена во время обработки: {ArchivesDirectory}", _archivesDirectory);
                break;
            }

            processedCount++;

            try
            {
                if (!File.Exists(filePath))
                {
                    _logger.LogDebug("Файл уже не существует: {FilePath}", filePath);
                    continue;
                }

                var fileInfo = new FileInfo(filePath);
                
                if (!fileInfo.Exists)
                    continue;

                // Используем UTC время для консистентности
                if (fileInfo.CreationTimeUtc < cutoffDate)
                {
                    var fileSize = fileInfo.Length;
                    
                    try
                    {
                        // Снимаем атрибут только для чтения, если он установлен
                        if (fileInfo.IsReadOnly)
                        {
                            try
                            {
                                fileInfo.IsReadOnly = false;
                            }
                            catch (Exception ex)
                            {
                                _logger.LogWarning(ex, "Не удалось снять атрибут только для чтения с файла: {FilePath}", filePath);
                                errorCount++;
                                continue;
                            }
                        }
                        
                        File.Delete(filePath);
                        
                        deletedCount++;
                        
                        // Защита от переполнения при подсчете размера
                        try
                        {
                            checked
                            {
                                totalSize += fileSize;
                            }
                        }
                        catch (OverflowException ex)
                        {
                            _logger.LogError(ex, "Переполнение при подсчете размера файлов. Текущий размер: {TotalSize}, размер файла: {FileSize}", 
                                totalSize, fileSize);
                            // Продолжаем работу, но не добавляем к totalSize
                        }
                        
                        _logger.LogInformation("Удален старый архив: {FileName} (создан: {CreatedAt}, размер: {Size} байт)", 
                            fileInfo.Name, fileInfo.CreationTimeUtc, fileSize);
                    }
                    catch (FileNotFoundException)
                    {
                        // Файл уже удален, это нормально
                        _logger.LogDebug("Файл уже был удален: {FilePath}", filePath);
                    }
                    catch (IOException ex) when (IsFileLockedException(ex))
                    {
                        _logger.LogWarning(ex, "Файл заблокирован другим процессом, пропускаем: {FilePath}", filePath);
                        errorCount++;
                    }
                    catch (UnauthorizedAccessException ex)
                    {
                        _logger.LogWarning(ex, "Нет прав на удаление файла: {FilePath}", filePath);
                        errorCount++;
                    }
                    catch (SecurityException ex)
                    {
                        _logger.LogWarning(ex, "Нет прав безопасности на удаление файла: {FilePath}", filePath);
                        errorCount++;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Не удалось обработать архив: {FilePath}", filePath);
                errorCount++;
            }
        }

        stopwatch.Stop();

        if (deletedCount > 0)
        {
            var totalSizeMB = totalSize / 1024.0 / 1024.0;
            var elapsedSeconds = stopwatch.Elapsed.TotalSeconds;
            var filesPerSecond = elapsedSeconds > 0 ? processedCount / elapsedSeconds : 0;
            
            _logger.LogInformation(
                "Очистка архивов завершена за {ElapsedMs}ms ({ElapsedSeconds:F2}s): " +
                "обработано {ProcessedCount} файлов, удалено {DeletedCount} файлов, " +
                "освобождено {TotalSizeBytes} байт ({TotalSizeMB:F2} MB), " +
                "ошибок: {ErrorCount}, скорость: {FilesPerSecond:F2} файлов/сек",
                stopwatch.ElapsedMilliseconds,
                elapsedSeconds,
                processedCount,
                deletedCount,
                totalSize,
                totalSizeMB,
                errorCount,
                filesPerSecond);
        }
        else if (errorCount > 0)
        {
            _logger.LogWarning("Очистка архивов завершена с ошибками: обработано {ProcessedCount} файлов, ошибок: {ErrorCount}", 
                processedCount, errorCount);
        }
        else
        {
            _logger.LogDebug("Очистка архивов: обработано {ProcessedCount} файлов, файлов для удаления не найдено", processedCount);
        }

        await Task.CompletedTask;
    }

    private static bool IsFileLockedException(IOException ex)
    {
        var message = ex.Message;
        return message.Contains("being used by another process", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("used by another process", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("процессом", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("используется", StringComparison.OrdinalIgnoreCase) ||
               ex.HResult == -2147024864; // HRESULT для ERROR_SHARING_VIOLATION
    }

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("Сервис очистки архивов остановлен");
        await base.StopAsync(cancellationToken);
    }
}
