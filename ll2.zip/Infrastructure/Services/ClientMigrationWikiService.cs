using System.Globalization;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.WebUtilities;
using new_assistant.Core.Constants;
using new_assistant.Core.DTOs;
using new_assistant.Core.Entities;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для работы с Wiki страницами при миграции клиентов
/// </summary>
public class ClientMigrationWikiService : IClientMigrationWikiService
{
    private readonly IWikiPageRepository _wikiPageRepository;
    private readonly IConfluenceService _confluenceService;
    private readonly ILogger<ClientMigrationWikiService> _logger;

    public ClientMigrationWikiService(
        IWikiPageRepository wikiPageRepository,
        IConfluenceService confluenceService,
        ILogger<ClientMigrationWikiService> logger)
    {
        _wikiPageRepository = wikiPageRepository ?? throw new ArgumentNullException(nameof(wikiPageRepository));
        _confluenceService = confluenceService ?? throw new ArgumentNullException(nameof(confluenceService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Извлечь метаданные из Wiki URL
    /// </summary>
    public async Task<(string PageId, string Title, string Url, bool IsValid)> ExtractWikiMetadataAsync(
        string wikiUrl, 
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(wikiUrl))
        {
            var fallbackId = $"{MigrationConstants.ManualPageIdPrefix}{Guid.NewGuid():N}"
                .Substring(0, MigrationConstants.ManualPageIdLength);
            return (fallbackId, "Wiki Page", string.Empty, false);
        }

        var trimmedUrl = wikiUrl.Trim();
        
        // Валидация URL формата
        if (!Uri.TryCreate(trimmedUrl, UriKind.Absolute, out var uri))
        {
            _logger.LogWarning("Некорректный формат Wiki URL: {Url}", trimmedUrl);
            var fallbackId = $"{MigrationConstants.ManualPageIdPrefix}{Guid.NewGuid():N}"
                .Substring(0, MigrationConstants.ManualPageIdLength);
            return (fallbackId, "Wiki Page", trimmedUrl, false);
        }
        
        // Проверка схемы (должен быть http или https)
        if (uri.Scheme != "http" && uri.Scheme != "https")
        {
            _logger.LogWarning("Неподдерживаемая схема URL: {Scheme} для {Url}", uri.Scheme, trimmedUrl);
            var fallbackId = $"{MigrationConstants.ManualPageIdPrefix}{Guid.NewGuid():N}"
                .Substring(0, MigrationConstants.ManualPageIdLength);
            return (fallbackId, "Wiki Page", trimmedUrl, false);
        }
        
        string pageId = string.Empty;
        string title = "Wiki Page";
        string? spaceKey = null;
        string? friendlyTitle = null;
        var isValid = true;
        
        try
        {
            var query = QueryHelpers.ParseQuery(uri.Query);
            if (query.TryGetValue("pageId", out var pageIdValue) && !string.IsNullOrWhiteSpace(pageIdValue))
            {
                pageId = pageIdValue.ToString();
            }
        }
        catch
        {
            // ignore malformed query
        }

        if (string.IsNullOrWhiteSpace(pageId))
        {
            var lastSegment = uri.Segments.Length > 0 ? uri.Segments[^1] : string.Empty;
            var match = Regex.Match(lastSegment ?? string.Empty, @"(\d+)");
            if (match.Success)
            {
                pageId = match.Groups[1].Value;
            }
        }

        // Attempt to extract space/title from friendly URLs like /display/SPACE/Title
        var segments = uri.AbsolutePath.Split('/', StringSplitOptions.RemoveEmptyEntries);
        if (segments.Length >= 3 && string.Equals(segments[0], "display", StringComparison.OrdinalIgnoreCase))
        {
            spaceKey = segments[1];
            var titleSegments = segments.Skip(2);
            var rawTitle = string.Join("/", titleSegments);
            friendlyTitle = DecodeUrlSegment(rawTitle.Replace('+', ' '));
        }

        var pathSegment = uri.Segments.Length > 0 ? uri.Segments[^1] : string.Empty;
        if (!string.IsNullOrWhiteSpace(pathSegment))
        {
            var cleaned = pathSegment.Trim('/');
            cleaned = Regex.Replace(cleaned, @"-\d+(\.\w+)?$", string.Empty);
            cleaned = cleaned.Replace('-', ' ');
            cleaned = DecodeUrlSegment(cleaned);
            if (!string.IsNullOrWhiteSpace(cleaned))
            {
                title = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(cleaned);
            }
        }

        if (string.IsNullOrWhiteSpace(pageId) && !string.IsNullOrWhiteSpace(spaceKey) && !string.IsNullOrWhiteSpace(friendlyTitle))
        {
            var resolved = await _confluenceService.ResolvePageAsync(spaceKey, friendlyTitle, cancellationToken).ConfigureAwait(false);
            if (resolved.HasValue)
            {
                var resolvedPage = resolved.Value;
                pageId = resolvedPage.Id;
                title = resolvedPage.Title;
                trimmedUrl = string.IsNullOrWhiteSpace(resolvedPage.Url) ? trimmedUrl : resolvedPage.Url;
            }
            else
            {
                _logger.LogWarning(
                    "Wiki: не удалось получить pageId по friendly URL. Space={Space}, Title={Title}, Url={Url}",
                    spaceKey,
                    friendlyTitle,
                    trimmedUrl);
            }
        }

        if (string.IsNullOrWhiteSpace(pageId))
        {
            pageId = $"{MigrationConstants.ManualPageIdPrefix}{Guid.NewGuid():N}"
                .Substring(0, MigrationConstants.ManualPageIdLength);
        }

        if (pageId.Length > MigrationConstants.MaxPageIdLength)
        {
            // Использовать SHA256 для более надежного хеша вместо GetHashCode
            using var sha256 = SHA256.Create();
            var hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(pageId));
            var hashString = BitConverter.ToString(hashBytes).Replace("-", "");
            // Защита от IndexOutOfRangeException: проверяем длину перед Substring
            var hash = hashString.Length >= 8 
                ? hashString.Substring(0, 8) 
                : hashString.PadRight(8, '0');
            
            var maxHashLength = MigrationConstants.MaxPageIdLength - hash.Length - 1;
            if (maxHashLength < 0)
            {
                _logger.LogError("PageId слишком длинный для обрезки. Length: {Length}, Max: {Max}", 
                    pageId.Length, MigrationConstants.MaxPageIdLength);
                pageId = pageId.Substring(0, MigrationConstants.MaxPageIdLength);
            }
            else
            {
                pageId = pageId.Substring(0, maxHashLength) + "-" + hash;
            }
            
            _logger.LogWarning(
                "PageId обрезан и добавлен хеш из-за превышения длины. Original length: {Length}, Final length: {FinalLength}",
                pageId.Length + hash.Length + 1, pageId.Length);
        }

        if (!string.IsNullOrWhiteSpace(pageId) && isValid)
        {
            var metadata = await _confluenceService.GetPageMetadataAsync(pageId, cancellationToken).ConfigureAwait(false);
            if (metadata.HasValue)
            {
                title = metadata.Value.Title;
                if (!string.IsNullOrWhiteSpace(metadata.Value.Url))
                {
                    trimmedUrl = metadata.Value.Url;
                }
            }
        }

        return (pageId, title, trimmedUrl, isValid);
    }

    /// <summary>
    /// Обновить или создать Wiki страницу в репозитории
    /// </summary>
    public async Task<string?> UpdateWikiPageInRepositoryAsync(
        string clientId,
        string? wikiUrl,
        string migratedBy,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        
        if (string.IsNullOrWhiteSpace(migratedBy))
            throw new ArgumentException("MigratedBy cannot be null or empty", nameof(migratedBy));
        
        try
        {
            _logger.LogInformation(
                "Wiki: старт обновления записи в репозитории для клиента {ClientId}. CandidateUrl={CandidateUrl}",
                clientId,
                wikiUrl ?? "<null>");

            var existingWikiPage = await _wikiPageRepository.GetWikiPageAnyRealmAsync(clientId).ConfigureAwait(false);

            _logger.LogInformation(
                "Wiki: текущая запись в БД для клиента {ClientId}: Exists={Exists}, PageId={PageId}, Url={Url}, Status={Status}",
                clientId,
                existingWikiPage != null,
                existingWikiPage?.WikiPageId ?? "<null>",
                existingWikiPage?.WikiPageUrl ?? "<null>",
                existingWikiPage?.Status ?? "<null>");

            if (!string.IsNullOrWhiteSpace(wikiUrl))
            {
                var metadata = await ExtractWikiMetadataAsync(wikiUrl, cancellationToken).ConfigureAwait(false);
                var finalUrl = metadata.Url;
                
                if (!metadata.IsValid)
                {
                    _logger.LogWarning(
                        "Wiki: ссылка указана в нестандартном формате для клиента {ClientId}. Original={OriginalUrl}, ParsedPageId={PageId}",
                        clientId,
                        wikiUrl,
                        metadata.PageId);
                }

                if (existingWikiPage == null)
                {
                    var newWikiPage = new ClientWikiPage
                    {
                        ClientId = clientId,
                        Realm = MigrationConstants.RealmGlobal,
                        WikiPageId = metadata.PageId,
                        WikiPageTitle = metadata.Title,
                        WikiPageUrl = finalUrl,
                        Status = MigrationConstants.StatusStage,
                        CreatedBy = migratedBy,
                        PageVersion = 1
                    };

                    await _wikiPageRepository.SaveWikiPageAsync(newWikiPage).ConfigureAwait(false);

                    _logger.LogInformation(
                        "Wiki: создана новая запись в БД для клиента {ClientId}. PageId={PageId}, Url={Url}",
                        clientId,
                        newWikiPage.WikiPageId,
                        newWikiPage.WikiPageUrl);
                    
                    return finalUrl;
                }
                else
                {
                    existingWikiPage.Realm = MigrationConstants.RealmGlobal;
                    existingWikiPage.WikiPageId = metadata.PageId;
                    existingWikiPage.WikiPageTitle = metadata.Title;
                    existingWikiPage.WikiPageUrl = finalUrl;
                    existingWikiPage.Status = MigrationConstants.StatusStage;
                    if (existingWikiPage.PageVersion <= 0)
                    {
                        existingWikiPage.PageVersion = 1;
                    }

                    await _wikiPageRepository.UpdateWikiPageAsync(existingWikiPage).ConfigureAwait(false);

                    _logger.LogInformation(
                        "Wiki: обновлена существующая запись в БД для клиента {ClientId}. PageId={PageId}, Url={Url}, Status={Status}",
                        clientId,
                        existingWikiPage.WikiPageId,
                        existingWikiPage.WikiPageUrl,
                        existingWikiPage.Status);
                    
                    return finalUrl;
                }
            }
            else if (existingWikiPage != null)
            {
                existingWikiPage.Realm = MigrationConstants.RealmGlobal;
                existingWikiPage.Status = MigrationConstants.StatusStage;
                await _wikiPageRepository.UpdateWikiPageAsync(existingWikiPage).ConfigureAwait(false);

                _logger.LogInformation(
                    "Wiki: ссылка не указана, обновили статус существующей записи для клиента {ClientId} на {Status}",
                    clientId,
                    existingWikiPage.Status);

                return existingWikiPage.WikiPageUrl;
            }
            else
            {
                _logger.LogWarning(
                    "Wiki: ссылка не указана и запись не найдена для клиента {ClientId}.", clientId);
                return null;
            }
        }
        catch (Exception ex)
        {
            var errorContext = new
            {
                ClientId = clientId,
                WikiUrl = wikiUrl,
                Operation = "UpdateWikiPage",
                ErrorType = ex.GetType().Name,
                ErrorMessage = ex.Message
            };
            
            _logger.LogWarning(ex, 
                "Не удалось обновить Wiki страницу для клиента {ClientId}. Context: {@Context}", 
                clientId, errorContext);
            throw;
        }
    }

    /// <summary>
    /// Обновить Wiki страницу в Confluence
    /// </summary>
    public async Task<string?> UpdateWikiPageInConfluenceAsync(
        ClientDetailsDto clientDetails,
        string migratedBy,
        CancellationToken cancellationToken = default)
    {
        if (clientDetails == null)
            throw new ArgumentNullException(nameof(clientDetails));
        
        if (string.IsNullOrWhiteSpace(migratedBy))
            throw new ArgumentException("MigratedBy cannot be null or empty", nameof(migratedBy));
        
        try
        {
            _logger.LogInformation(
                "Wiki: попытка обновления страницы в Confluence для клиента {ClientId}. Realm={Realm}",
                clientDetails.ClientId,
                clientDetails.Realm);

            var updatedWikiUrl = await _confluenceService.UpdateClientPageAsync(
                clientDetails,
                migratedBy,
                cancellationToken).ConfigureAwait(false);

            if (!string.IsNullOrWhiteSpace(updatedWikiUrl))
            {
                _logger.LogInformation(
                    "Wiki: страница Confluence обновлена для клиента {ClientId}. Итоговый URL={Url}",
                    clientDetails.ClientId,
                    updatedWikiUrl);
                return updatedWikiUrl;
            }
            else
            {
                _logger.LogWarning(
                    "Wiki: Confluence вернул пустой URL при обновлении клиента {ClientId}.", clientDetails.ClientId);
                return null;
            }
        }
        catch (Exception ex)
        {
            var errorContext = new
            {
                ClientId = clientDetails.ClientId,
                Realm = clientDetails.Realm,
                Operation = "UpdateConfluencePage",
                ErrorType = ex.GetType().Name,
                ErrorMessage = ex.Message
            };
            
            _logger.LogWarning(ex, 
                "Не удалось синхронизировать Wiki страницу в Confluence для клиента {ClientId}. Context: {@Context}", 
                clientDetails.ClientId, errorContext);
            throw;
        }
    }

    /// <summary>
    /// Декодирование URL сегмента с обработкой различных кодировок
    /// </summary>
    private string DecodeUrlSegment(string segment)
    {
        // Улучшенная проверка на null для большей ясности
        if (segment == null)
            return string.Empty;
        
        if (string.IsNullOrWhiteSpace(segment))
            return string.Empty;
        
        try
        {
            // Попробовать стандартную декодировку
            var decoded = Uri.UnescapeDataString(segment);
            
            // Если результат содержит недопустимые управляющие символы, попробовать другую кодировку
            if (decoded.Any(c => char.IsControl(c) && !char.IsWhiteSpace(c)))
            {
                // Попробовать декодировать через WebUtility (более надежно)
                try
                {
                    decoded = WebUtility.UrlDecode(segment);
                }
                catch
                {
                    // Если и это не помогло, вернуть исходное значение
                    _logger.LogWarning("Не удалось декодировать URL сегмент: {Segment}", segment);
                    return segment;
                }
            }
            
            return decoded;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка декодирования URL сегмента: {Segment}", segment);
            return segment; // Вернуть исходное значение при ошибке
        }
    }
}

