using System.Collections.Concurrent;
using System.Linq;
using System.Security.Claims;
using System.Threading;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.Constants;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services
{
    /// <summary>
    /// Сервис для управления состоянием поиска клиентов и кэширования данных
    /// </summary>
    /// <remarks>
    /// Сервис обеспечивает потокобезопасность, защиту от утечек памяти и изоляцию данных по пользователям.
    /// Все операции логируются для мониторинга и отладки.
    /// </remarks>
    public class SearchStateService : ISearchStateService, IDisposable
    {
        // Потокобезопасные блокировки
        private readonly ReaderWriterLockSlim _stateLock = new ReaderWriterLockSlim();
        private readonly ReaderWriterLockSlim _cacheLock = new ReaderWriterLockSlim();

        // Состояние поиска (изолировано по пользователям)
        private readonly ConcurrentDictionary<string, UserSearchState> _userStates = new();

        // Кэш клиентов пользователя (изолирован по пользователям)
        private readonly ConcurrentDictionary<string, UserCacheState> _userCaches = new();

        // Событие для запроса обновления списка клиентов (защита от утечек памяти)
        private readonly WeakEventManager _refreshEventManager = new WeakEventManager();

        // Метрики кэша
        private long _cacheHits = 0;
        private long _cacheMisses = 0;

        // Зависимости
        private readonly ILogger<SearchStateService> _logger;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly SearchStateServiceSettings _settings;
        private bool _disposed = false;

        /// <summary>
        /// Событие запроса на обновление списка клиентов
        /// </summary>
        /// <remarks>
        /// Использует WeakEventManager для автоматической очистки подписчиков и предотвращения утечек памяти.
        /// </remarks>
        public event Action? OnUserClientsRefreshRequested
        {
            add => _refreshEventManager.AddEventHandler(value);
            remove => _refreshEventManager.RemoveEventHandler(value);
        }

        /// <summary>
        /// Инициализирует новый экземпляр SearchStateService
        /// </summary>
        /// <param name="logger">Логгер для записи операций</param>
        /// <param name="httpContextAccessor">Доступ к HttpContext для получения текущего пользователя</param>
        /// <param name="options">Настройки сервиса</param>
        /// <exception cref="ArgumentNullException">Когда любой из параметров равен null</exception>
        public SearchStateService(
            ILogger<SearchStateService> logger, 
            IHttpContextAccessor httpContextAccessor,
            IOptions<SearchStateServiceSettings> options)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
            _settings = options?.Value ?? throw new ArgumentNullException(nameof(options));

            // Валидация настроек
            if (_settings.MaxCacheSize <= 0)
            {
                throw new ArgumentException("MaxCacheSize must be greater than 0", nameof(options));
            }

            if (_settings.DefaultCacheExpiration <= TimeSpan.Zero)
            {
                throw new ArgumentException("DefaultCacheExpiration must be greater than TimeSpan.Zero", nameof(options));
            }
        }

        /// <summary>
        /// Получает идентификатор текущего пользователя
        /// </summary>
        /// <returns>Идентификатор пользователя или "anonymous" если пользователь не аутентифицирован</returns>
        private string GetCurrentUserId()
        {
            try
            {
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext?.User?.Identity?.IsAuthenticated == true)
                {
                    // Приоритет: Subject (sub) > Name (preferred_username) > Identity.Name
                    var userId = httpContext.User.FindFirstValue(Claims.Subject)
                        ?? httpContext.User.FindFirstValue(Claims.Name)
                        ?? httpContext.User.Identity.Name
                        ?? "anonymous";
                    
                    return userId;
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Не удалось получить идентификатор пользователя из HttpContext");
            }

            return "anonymous";
        }

        /// <summary>
        /// Сохраняет состояние поиска для текущего пользователя
        /// </summary>
        /// <param name="searchQuery">Поисковый запрос. Не может быть null.</param>
        /// <param name="searchResponse">Результат поиска. Может быть null.</param>
        /// <param name="currentPage">Номер текущей страницы. Должен быть больше 0.</param>
        /// <param name="lastSearchTime">Время последнего поиска в UTC. Не может быть в будущем.</param>
        /// <exception cref="ArgumentNullException">Когда searchQuery равен null.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Когда currentPage меньше 1.</exception>
        /// <exception cref="ArgumentException">Когда lastSearchTime в будущем.</exception>
        /// <remarks>
        /// Все временные метки должны быть в UTC. Если передано локальное время, оно будет обработано как UTC.
        /// </remarks>
        public void SaveSearchState(string searchQuery, ClientsSearchResponse? searchResponse, int currentPage, DateTime? lastSearchTime)
        {
            ThrowIfDisposed();

            // Валидация параметров
            ArgumentNullException.ThrowIfNull(searchQuery);

            if (currentPage < 1)
            {
                throw new ArgumentOutOfRangeException(nameof(currentPage), "Page number must be greater than 0");
            }

            DateTime? normalizedLastSearchTime = null;
            if (lastSearchTime.HasValue)
            {
                // Нормализуем время в UTC для корректного сравнения
                var utcTime = lastSearchTime.Value.Kind == DateTimeKind.Unspecified
                    ? DateTime.SpecifyKind(lastSearchTime.Value, DateTimeKind.Utc)
                    : lastSearchTime.Value.ToUniversalTime();

                if (utcTime > DateTime.UtcNow)
                {
                    throw new ArgumentException("Last search time cannot be in the future", nameof(lastSearchTime));
                }

                normalizedLastSearchTime = utcTime;
            }

            try
            {
                var userId = GetCurrentUserId();

                _stateLock.EnterWriteLock();
                try
                {
                    var state = _userStates.GetOrAdd(userId, _ => new UserSearchState());
                    state.SearchQuery = searchQuery;
                    state.SearchResponse = searchResponse;
                    state.CurrentPage = currentPage;
                    state.LastSearchTime = normalizedLastSearchTime;
                    state.HasState = true;

                    _logger.LogDebug(
                        "Search state saved for user {UserId}: Query={Query}, Page={Page}, Results={Results}",
                        userId, searchQuery, currentPage, searchResponse?.TotalFound ?? 0);
                }
                finally
                {
                    _stateLock.ExitWriteLock();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to save search state");
                throw;
            }
        }

        /// <summary>
        /// Получает сохраненное состояние поиска для текущего пользователя
        /// </summary>
        /// <returns>Состояние поиска или null, если состояние не сохранено</returns>
        /// <remarks>
        /// Все временные метки используют UTC время.
        /// </remarks>
        public SearchState? GetSearchState()
        {
            ThrowIfDisposed();

            try
            {
                var userId = GetCurrentUserId();

                _stateLock.EnterReadLock();
                try
                {
                    if (_userStates.TryGetValue(userId, out var state) && state.HasState)
                    {
                        return new SearchState
                        {
                            SearchQuery = state.SearchQuery,
                            SearchResponse = state.SearchResponse,
                            CurrentPage = state.CurrentPage,
                            LastSearchTime = state.LastSearchTime
                        };
                    }
                }
                finally
                {
                    _stateLock.ExitReadLock();
                }

                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to get search state");
                return null;
            }
        }

        /// <summary>
        /// Получает сохраненное состояние поиска для текущего пользователя (асинхронная версия)
        /// </summary>
        /// <param name="cancellationToken">Токен отмены операции</param>
        /// <returns>Состояние поиска или null, если состояние не сохранено</returns>
        /// <remarks>
        /// Все временные метки используют UTC время.
        /// </remarks>
        public Task<SearchState?> GetSearchStateAsync(CancellationToken cancellationToken = default)
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            return Task.FromResult(GetSearchState());
        }

        /// <summary>
        /// Очищает сохраненное состояние поиска для текущего пользователя
        /// </summary>
        public void ClearSearchState()
        {
            ThrowIfDisposed();

            try
            {
                var userId = GetCurrentUserId();

                _stateLock.EnterWriteLock();
                try
                {
                    if (_userStates.TryGetValue(userId, out var state))
                    {
                        state.SearchQuery = string.Empty;
                        state.SearchResponse = null;
                        state.CurrentPage = 1;
                        state.LastSearchTime = null;
                        state.HasState = false;

                        _logger.LogDebug("Search state cleared for user {UserId}", userId);
                    }
                }
                finally
                {
                    _stateLock.ExitWriteLock();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to clear search state");
            }
        }

        /// <summary>
        /// Проверяет, есть ли сохраненное состояние поиска для текущего пользователя
        /// </summary>
        /// <returns>true если состояние сохранено, иначе false</returns>
        public bool HasSavedState()
        {
            ThrowIfDisposed();

            try
            {
                var userId = GetCurrentUserId();

                _stateLock.EnterReadLock();
                try
                {
                    return _userStates.TryGetValue(userId, out var state) && state.HasState;
                }
                finally
                {
                    _stateLock.ExitReadLock();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to check saved state");
                return false;
            }
        }

        /// <summary>
        /// Сохраняет список клиентов пользователя в кэш
        /// </summary>
        /// <param name="clients">Список клиентов для кэширования. Не может быть null.</param>
        /// <exception cref="ArgumentNullException">Когда clients равен null.</exception>
        public void CacheUserClients(List<ClientDetailsDto> clients)
        {
            ThrowIfDisposed();
            ArgumentNullException.ThrowIfNull(clients);

            try
            {
                var userId = GetCurrentUserId();

                // Ограничение размера кэша
                var clientsToCache = clients.Count > _settings.MaxCacheSize
                    ? clients.OrderByDescending(c => c.UpdatedAt).Take(_settings.MaxCacheSize).ToList()
                    : clients;

                _cacheLock.EnterWriteLock();
                try
                {
                    var cacheState = _userCaches.GetOrAdd(userId, _ => new UserCacheState());
                    cacheState.CachedClients = clientsToCache.Select(c => c).ToList(); // Создаем копию
                    cacheState.CacheTimestamp = DateTime.UtcNow;

                    _logger.LogDebug(
                        "User clients cached for user {UserId}: Count={Count}",
                        userId, cacheState.CachedClients.Count);
                }
                finally
                {
                    _cacheLock.ExitWriteLock();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to cache user clients");
                throw;
            }
        }

        /// <summary>
        /// Получает кэшированные клиенты пользователя (возвращает копию для защиты от модификации)
        /// </summary>
        /// <returns>Копия списка кэшированных клиентов или null если кэш пуст</returns>
        public List<ClientDetailsDto>? GetCachedUserClients()
        {
            ThrowIfDisposed();

            try
            {
                var userId = GetCurrentUserId();

                _cacheLock.EnterReadLock();
                try
                {
                    if (_userCaches.TryGetValue(userId, out var cacheState) && cacheState.CachedClients != null)
                    {
                        Interlocked.Increment(ref _cacheHits);
                        // Возвращаем копию для защиты от модификации
                        return cacheState.CachedClients.Select(c => c).ToList();
                    }
                }
                finally
                {
                    _cacheLock.ExitReadLock();
                }

                Interlocked.Increment(ref _cacheMisses);
                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to get cached user clients");
                Interlocked.Increment(ref _cacheMisses);
                return null;
            }
        }

        /// <summary>
        /// Проверяет, актуален ли кэш клиентов для текущего пользователя (не старше указанного времени)
        /// </summary>
        /// <param name="maxAge">Максимальный возраст кэша</param>
        /// <returns>true если кэш валиден, иначе false</returns>
        public bool IsUserClientsCacheValid(TimeSpan maxAge)
        {
            ThrowIfDisposed();

            try
            {
                var userId = GetCurrentUserId();

                _cacheLock.EnterReadLock();
                try
                {
                    if (!_userCaches.TryGetValue(userId, out var cacheState) || 
                        cacheState.CachedClients == null || 
                        cacheState.CacheTimestamp == null)
                    {
                        return false;
                    }

                    var age = DateTime.UtcNow - cacheState.CacheTimestamp.Value;
                    return age < maxAge;
                }
                finally
                {
                    _cacheLock.ExitReadLock();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to check cache validity");
                return false;
            }
        }

        /// <summary>
        /// Инвалидирует (очищает) кэш клиентов для текущего пользователя
        /// </summary>
        public void InvalidateUserClientsCache()
        {
            ThrowIfDisposed();

            try
            {
                var userId = GetCurrentUserId();

                _cacheLock.EnterWriteLock();
                try
                {
                    if (_userCaches.TryGetValue(userId, out var cacheState))
                    {
                        cacheState.CachedClients = null;
                        cacheState.CacheTimestamp = null;

                        _logger.LogDebug("User clients cache invalidated for user {UserId}", userId);
                    }
                }
                finally
                {
                    _cacheLock.ExitWriteLock();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to invalidate user clients cache");
            }
        }

        /// <summary>
        /// Запрашивает принудительное обновление списка клиентов
        /// </summary>
        public void RequestUserClientsRefresh()
        {
            ThrowIfDisposed();

            try
            {
                var userId = GetCurrentUserId();

                // Инвалидируем кэш
                InvalidateUserClientsCache();

                // Вызываем событие через WeakEventManager
                _refreshEventManager.RaiseEvent();

                _logger.LogDebug("User clients refresh requested for user {UserId}", userId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to request user clients refresh");
            }
        }

        /// <summary>
        /// Сохраняет состояние поиска для текущего пользователя (асинхронная версия)
        /// </summary>
        /// <param name="searchQuery">Поисковый запрос. Не может быть null.</param>
        /// <param name="searchResponse">Результат поиска. Может быть null.</param>
        /// <param name="currentPage">Номер текущей страницы. Должен быть больше 0.</param>
        /// <param name="lastSearchTime">Время последнего поиска в UTC. Не может быть в будущем.</param>
        /// <param name="cancellationToken">Токен отмены операции</param>
        /// <exception cref="ArgumentNullException">Когда searchQuery равен null.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Когда currentPage меньше 1.</exception>
        /// <exception cref="ArgumentException">Когда lastSearchTime в будущем.</exception>
        /// <remarks>
        /// Все временные метки должны быть в UTC. Если передано локальное время, оно будет обработано как UTC.
        /// </remarks>
        public Task SaveSearchStateAsync(string searchQuery, ClientsSearchResponse? searchResponse, int currentPage, DateTime? lastSearchTime, CancellationToken cancellationToken = default)
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            SaveSearchState(searchQuery, searchResponse, currentPage, lastSearchTime);
            return Task.CompletedTask;
        }

        /// <summary>
        /// Получает метрики использования кэша
        /// </summary>
        /// <returns>Кортеж с количеством попаданий, промахов и процентом попаданий</returns>
        public (long Hits, long Misses, double HitRate) GetCacheMetrics()
        {
            ThrowIfDisposed();

            var hits = Interlocked.Read(ref _cacheHits);
            var misses = Interlocked.Read(ref _cacheMisses);
            var total = hits + misses;
            var hitRate = total > 0 ? (double)hits / total : 0.0;

            return (hits, misses, hitRate);
        }

        /// <summary>
        /// Очищает устаревшие состояния пользователей для освобождения памяти
        /// </summary>
        /// <param name="maxAge">Максимальный возраст состояния. Состояния старше этого возраста будут удалены.</param>
        /// <returns>Количество удаленных состояний</returns>
        /// <remarks>
        /// Этот метод следует вызывать периодически (например, через фоновый сервис) для предотвращения утечек памяти.
        /// </remarks>
        public int CleanupOldStates(TimeSpan maxAge)
        {
            ThrowIfDisposed();

            var removedCount = 0;
            var cutoffTime = DateTime.UtcNow - maxAge;

            try
            {
                // Очистка состояний поиска
                _stateLock.EnterWriteLock();
                try
                {
                    var statesToRemove = new List<string>();
                    foreach (var kvp in _userStates)
                    {
                        if (kvp.Value.LastSearchTime.HasValue && 
                            kvp.Value.LastSearchTime.Value < cutoffTime)
                        {
                            statesToRemove.Add(kvp.Key);
                        }
                    }

                    foreach (var key in statesToRemove)
                    {
                        if (_userStates.TryRemove(key, out _))
                        {
                            removedCount++;
                        }
                    }
                }
                finally
                {
                    _stateLock.ExitWriteLock();
                }

                // Очистка кэшей
                _cacheLock.EnterWriteLock();
                try
                {
                    var cachesToRemove = new List<string>();
                    foreach (var kvp in _userCaches)
                    {
                        if (kvp.Value.CacheTimestamp.HasValue && 
                            kvp.Value.CacheTimestamp.Value < cutoffTime)
                        {
                            cachesToRemove.Add(kvp.Key);
                        }
                    }

                    foreach (var key in cachesToRemove)
                    {
                        if (_userCaches.TryRemove(key, out _))
                        {
                            removedCount++;
                        }
                    }
                }
                finally
                {
                    _cacheLock.ExitWriteLock();
                }

                if (removedCount > 0)
                {
                    _logger.LogInformation(
                        "Cleaned up {Count} old user states older than {MaxAge}",
                        removedCount, maxAge);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to cleanup old states");
            }

            return removedCount;
        }

        /// <summary>
        /// Проверяет, не был ли объект освобожден
        /// </summary>
        /// <exception cref="ObjectDisposedException">Когда объект уже освобожден</exception>
        private void ThrowIfDisposed()
        {
            if (_disposed)
            {
                throw new ObjectDisposedException(nameof(SearchStateService));
            }
        }

        /// <summary>
        /// Освобождает ресурсы
        /// </summary>
        public void Dispose()
        {
            if (!_disposed)
            {
                _stateLock?.Dispose();
                _cacheLock?.Dispose();
                
                // Очищаем состояния пользователей для освобождения памяти
                _userStates.Clear();
                _userCaches.Clear();
                
                _disposed = true;
            }
        }

        /// <summary>
        /// Внутренний класс для хранения состояния поиска пользователя
        /// </summary>
        private class UserSearchState
        {
            public string SearchQuery { get; set; } = string.Empty;
            public ClientsSearchResponse? SearchResponse { get; set; }
            public int CurrentPage { get; set; } = 1;
            public DateTime? LastSearchTime { get; set; }
            public bool HasState { get; set; } = false;
        }

        /// <summary>
        /// Внутренний класс для хранения кэша клиентов пользователя
        /// </summary>
        private class UserCacheState
        {
            public List<ClientDetailsDto>? CachedClients { get; set; }
            public DateTime? CacheTimestamp { get; set; }
        }
    }
}
