using Microsoft.Extensions.Logging;
using new_assistant.Core.Extensions;
using new_assistant.Core.Interfaces;
using Polly;
using Polly.Retry;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для работы с ролями при миграции клиентов
/// </summary>
public class ClientMigrationRolesService : IClientMigrationRolesService
{
    private readonly IKeycloakStageService _stageKeycloak;
    private readonly ILogger<ClientMigrationRolesService> _logger;
    private readonly AsyncRetryPolicy _retryPolicy;
    
    private const int RetryCount = 3;
    private const int ExponentialBackoffBase = 2;

    public ClientMigrationRolesService(
        IKeycloakStageService stageKeycloak,
        ILogger<ClientMigrationRolesService> logger)
    {
        _stageKeycloak = stageKeycloak ?? throw new ArgumentNullException(nameof(stageKeycloak));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        
        // Настроить retry политику для сетевых операций
        _retryPolicy = Policy
            .Handle<HttpRequestException>()
            .Or<TaskCanceledException>()
            .Or<TimeoutException>()
            .WaitAndRetryAsync(
                retryCount: RetryCount,
                sleepDurationProvider: retryAttempt => TimeSpan.FromSeconds(Math.Pow(ExponentialBackoffBase, retryAttempt)),
                onRetry: (exception, timeSpan, retryCount, context) =>
                {
                    _logger.LogWarning(exception, 
                        "Повторная попытка {RetryCount} через {Delay} секунд", 
                        retryCount, timeSpan.TotalSeconds);
                });
    }

    /// <summary>
    /// Создать локальные роли клиента
    /// </summary>
    public async Task<int> CreateLocalRolesAsync(
        string internalId,
        IEnumerable<string> roles,
        string targetRealm,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(internalId))
            throw new ArgumentException("InternalId cannot be null or empty", nameof(internalId));
        
        if (string.IsNullOrWhiteSpace(targetRealm))
            throw new ArgumentException("TargetRealm cannot be null or empty", nameof(targetRealm));
        
        var localRoles = roles ?? Enumerable.Empty<string>();
        var uniqueRoles = localRoles
            .Where(r => !string.IsNullOrWhiteSpace(r))
            .Distinct()
            .ToList();
        
        if (uniqueRoles.IsNullOrEmpty())
            return 0;
        
        try
        {
            await _retryPolicy.ExecuteAsync(async () =>
                await _stageKeycloak.CreateClientRolesAsync(
                    internalId, uniqueRoles, targetRealm, cancellationToken).ConfigureAwait(false));
            
            _logger.LogInformation("Создано {Count} локальных ролей для клиента {InternalId}", 
                uniqueRoles.Count, internalId);
            
            return uniqueRoles.Count;
        }
        catch (Exception ex)
        {
            var errorContext = new
            {
                InternalId = internalId,
                Operation = "CreateLocalRoles",
                ErrorType = ex.GetType().Name,
                ErrorMessage = ex.Message,
                RolesCount = uniqueRoles.Count
            };
            
            _logger.LogWarning(ex, 
                "Не все локальные роли были созданы для клиента {InternalId}. Context: {@Context}", 
                internalId, errorContext);
            throw;
        }
    }

    /// <summary>
    /// Назначить realm roles для service account
    /// </summary>
    public async Task<int> AssignRealmRolesToServiceAccountAsync(
        string internalId,
        IEnumerable<string> realmRoles,
        string targetRealm,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(internalId))
            throw new ArgumentException("InternalId cannot be null or empty", nameof(internalId));
        
        if (string.IsNullOrWhiteSpace(targetRealm))
            throw new ArgumentException("TargetRealm cannot be null or empty", nameof(targetRealm));
        
        var uniqueRealmRoles = (realmRoles ?? Enumerable.Empty<string>())
            .Where(r => !string.IsNullOrWhiteSpace(r))
            .Distinct()
            .ToList();
        
        if (uniqueRealmRoles.IsNullOrEmpty())
            return 0;
        
        try
        {
            await _retryPolicy.ExecuteAsync(async () =>
                await _stageKeycloak.AssignRealmRolesToServiceAccountAsync(
                    internalId, uniqueRealmRoles, targetRealm, cancellationToken).ConfigureAwait(false));
            
            _logger.LogInformation("Назначено {Count} realm roles для service account {InternalId}", 
                uniqueRealmRoles.Count, internalId);
            
            return uniqueRealmRoles.Count;
        }
        catch (Exception ex)
        {
            var errorContext = new
            {
                InternalId = internalId,
                Operation = "AssignRealmRoles",
                ErrorType = ex.GetType().Name,
                ErrorMessage = ex.Message,
                RolesCount = uniqueRealmRoles.Count
            };
            
            _logger.LogWarning(ex, 
                "Не все realm roles назначены для service account {InternalId}. Context: {@Context}", 
                internalId, errorContext);
            throw;
        }
    }

    /// <summary>
    /// Назначить client roles для service account
    /// </summary>
    public async Task<int> AssignClientRolesToServiceAccountAsync(
        string internalId,
        Dictionary<string, List<string>> clientRolesByClient,
        string targetRealm,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(internalId))
            throw new ArgumentException("InternalId cannot be null or empty", nameof(internalId));
        
        if (string.IsNullOrWhiteSpace(targetRealm))
            throw new ArgumentException("TargetRealm cannot be null or empty", nameof(targetRealm));
        
        if (clientRolesByClient.IsNullOrEmpty())
            return 0;
        
        var totalRolesAssigned = 0;
        var errors = new List<string>();
        
        foreach (var (targetClientId, roles) in clientRolesByClient)
        {
            if (roles == null || roles.Count == 0)
                continue;
            
            try
            {
                await _retryPolicy.ExecuteAsync(async () =>
                    await _stageKeycloak.AssignClientRolesToServiceAccountAsync(
                        internalId, targetClientId, roles, targetRealm, cancellationToken).ConfigureAwait(false));
                
                totalRolesAssigned += roles.Count;
                _logger.LogInformation("Назначено {Count} client roles от '{ClientId}' для service account {InternalId}", 
                    roles.Count, targetClientId, internalId);
            }
            catch (Exception ex)
            {
                var errorContext = new
                {
                    InternalId = internalId,
                    TargetClientId = targetClientId,
                    Operation = "AssignClientRoles",
                    ErrorType = ex.GetType().Name,
                    ErrorMessage = ex.Message,
                    RolesCount = roles.Count
                };
                
                _logger.LogWarning(ex, 
                    "Не все client roles назначены для {InternalId} от клиента {TargetClientId}. Context: {@Context}", 
                    internalId, targetClientId, errorContext);
                errors.Add($"Client roles от '{targetClientId}': {ex.Message}");
            }
        }
        
        // Логируем все ошибки, но не выбрасываем исключение, если хотя бы одна роль назначена
        if (errors.IsNotNullOrEmpty())
        {
            if (totalRolesAssigned == 0)
            {
                // Если не назначено ни одной роли - выбрасываем исключение
                throw new InvalidOperationException(
                    $"Не удалось назначить ни одной client role. Ошибки: {string.Join("; ", errors)}");
            }
            else
            {
                // Если назначена хотя бы одна роль - логируем предупреждение
                _logger.LogWarning(
                    "Частичное назначение client roles для {InternalId}. Назначено: {Assigned}, Ошибки: {Errors}",
                    internalId, totalRolesAssigned, string.Join("; ", errors));
            }
        }
        
        return totalRolesAssigned;
    }

    /// <summary>
    /// Назначить client scopes клиенту
    /// </summary>
    public async Task AssignClientScopesAsync(
        string internalId,
        IEnumerable<string> defaultScopes,
        IEnumerable<string> optionalScopes,
        string targetRealm,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(internalId))
            throw new ArgumentException("InternalId cannot be null or empty", nameof(internalId));
        
        if (string.IsNullOrWhiteSpace(targetRealm))
            throw new ArgumentException("TargetRealm cannot be null or empty", nameof(targetRealm));
        
        var defaultScopesList = (defaultScopes ?? Enumerable.Empty<string>()).ToList();
        var optionalScopesList = (optionalScopes ?? Enumerable.Empty<string>()).ToList();
        
        // Назначить default scopes
        if (defaultScopesList.IsNotNullOrEmpty())
        {
            try
            {
                await _retryPolicy.ExecuteAsync(async () =>
                    await _stageKeycloak.AssignClientScopesAsync(
                        internalId,
                        defaultScopesList,
                        targetRealm,
                        isDefault: true,
                        cancellationToken).ConfigureAwait(false));
                
                _logger.LogInformation("Назначено {Count} default client scopes для клиента {InternalId}", 
                    defaultScopesList.Count, internalId);
            }
            catch (Exception ex)
            {
                var errorContext = new
                {
                    InternalId = internalId,
                    Operation = "AssignDefaultScopes",
                    ErrorType = ex.GetType().Name,
                    ErrorMessage = ex.Message,
                    ScopesCount = defaultScopesList.Count
                };
                
                _logger.LogWarning(ex, 
                    "Не удалось назначить default client scopes для клиента {InternalId}. Context: {@Context}", 
                    internalId, errorContext);
                throw;
            }
        }
        
        // Назначить optional scopes
        if (optionalScopesList.IsNotNullOrEmpty())
        {
            try
            {
                await _retryPolicy.ExecuteAsync(async () =>
                    await _stageKeycloak.AssignClientScopesAsync(
                        internalId,
                        optionalScopesList,
                        targetRealm,
                        isDefault: false,
                        cancellationToken).ConfigureAwait(false));
                
                _logger.LogInformation("Назначено {Count} optional client scopes для клиента {InternalId}", 
                    optionalScopesList.Count, internalId);
            }
            catch (Exception ex)
            {
                var errorContext = new
                {
                    InternalId = internalId,
                    Operation = "AssignOptionalScopes",
                    ErrorType = ex.GetType().Name,
                    ErrorMessage = ex.Message,
                    ScopesCount = optionalScopesList.Count
                };
                
                _logger.LogWarning(ex, 
                    "Не удалось назначить optional client scopes для клиента {InternalId}. Context: {@Context}", 
                    internalId, errorContext);
                throw;
            }
        }
    }
}

