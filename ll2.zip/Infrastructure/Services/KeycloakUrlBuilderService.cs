using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.Constants;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для формирования URL для Keycloak
/// </summary>
public class KeycloakUrlBuilderService : IKeycloakUrlBuilderService
{
    private readonly KeycloakStageSettings _stageSettings;
    private readonly IConfiguration _configuration;
    private readonly ILogger<KeycloakUrlBuilderService> _logger;

    public KeycloakUrlBuilderService(
        IOptions<KeycloakStageSettings> stageSettings,
        IConfiguration configuration,
        ILogger<KeycloakUrlBuilderService> logger)
    {
        _stageSettings = stageSettings?.Value ?? throw new ArgumentNullException(nameof(stageSettings));
        _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Получить базовый URL для STAGE окружения
    /// </summary>
    public string GetStageBaseUrl()
    {
        var baseUrl = _stageSettings.BaseUrl;
        var useLegacy = _stageSettings.UseLegacyAuthPath;
        
        if (string.IsNullOrWhiteSpace(baseUrl))
        {
            baseUrl = _configuration.GetValue<string>("KeycloakStage:BaseUrl") ?? string.Empty;
            useLegacy = _configuration.GetValue<bool>("KeycloakStage:UseLegacyAuthPath");
        }
        
        if (string.IsNullOrWhiteSpace(baseUrl))
        {
            _logger.LogError("KeycloakStage:BaseUrl не настроен");
            throw new InvalidOperationException("KeycloakStage:BaseUrl не настроен в конфигурации");
        }
        
        if (useLegacy && !baseUrl.EndsWith("/auth", StringComparison.OrdinalIgnoreCase))
        {
            baseUrl = baseUrl.TrimEnd('/') + "/auth";
        }
        
        return baseUrl;
    }

    /// <summary>
    /// Получить URL для realm в STAGE окружении
    /// </summary>
    public string GetStageRealmUrl(string realm)
    {
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        if (realm.Length > MigrationConstants.MaxRealmLength)
            throw new ArgumentException($"Realm length exceeds maximum {MigrationConstants.MaxRealmLength}", nameof(realm));
        
        var baseUrl = GetStageBaseUrl();
        return $"{baseUrl}/realms/{realm}";
    }

    /// <summary>
    /// Получить URL для endpoints в STAGE окружении
    /// </summary>
    public string GetStageEndpointsUrl(string realm)
    {
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        if (realm.Length > MigrationConstants.MaxRealmLength)
            throw new ArgumentException($"Realm length exceeds maximum {MigrationConstants.MaxRealmLength}", nameof(realm));
        
        var baseUrl = GetStageBaseUrl();
        return $"{baseUrl}/realms/{realm}/.well-known/openid-configuration";
    }
}

