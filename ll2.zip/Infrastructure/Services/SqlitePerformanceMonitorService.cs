using System.Collections.Generic;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис-обертка для статического класса SqlitePerformanceMonitor
/// Позволяет использовать DI вместо статических вызовов
/// </summary>
public class SqlitePerformanceMonitorService : ISqlitePerformanceMonitor
{
    public void RecordOperation(string databaseName, long elapsedMs)
    {
        SqlitePerformanceMonitor.RecordOperation(databaseName, elapsedMs);
    }

    public (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetTotalStats()
    {
        return SqlitePerformanceMonitor.GetTotalStats();
    }

    public (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetDatabaseStats(string databaseName)
    {
        return SqlitePerformanceMonitor.GetDatabaseStats(databaseName);
    }

    public Dictionary<string, (long TotalTimeMs, long RequestCount, double AverageTimeMs)> GetAllDatabaseStats()
    {
        return SqlitePerformanceMonitor.GetAllDatabaseStats();
    }

    public void ResetAllStats()
    {
        SqlitePerformanceMonitor.ResetAllStats();
    }

    public void ResetDatabaseStats(string databaseName)
    {
        SqlitePerformanceMonitor.ResetDatabaseStats(databaseName);
    }
}

