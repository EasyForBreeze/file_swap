using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using new_assistant.Core.Interfaces;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для сбора метрик производительности (thread-safe)
/// Исправленная версия с устранением всех выявленных проблем
/// </summary>
public class PerformanceMetricsService : IPerformanceMetricsService, IDisposable
{
    private class MetricsInternal
    {
        public long TotalCalls;
        public long SuccessfulCalls;
        public long FailedCalls;
        public long TotalTimeMs;
        public long MinTimeMs = long.MaxValue;
        public long MaxTimeMs;
        // Используем ConcurrentDictionary вместо обычного Dictionary + lock
        public readonly ConcurrentDictionary<string, int> ErrorCounts = new();
        // Thread-safe хранение времени последнего обновления через ticks
        private long _lastUpdateTimeTicks = DateTime.UtcNow.Ticks;
        
        public DateTime LastUpdateTime
        {
            get => new DateTime(Volatile.Read(ref _lastUpdateTimeTicks));
            set => Volatile.Write(ref _lastUpdateTimeTicks, value.Ticks);
        }
    }

    private readonly ConcurrentDictionary<string, MetricsInternal> _metrics = new();
    private readonly ILogger<PerformanceMetricsService> _logger;
    private readonly Timer? _cleanupTimer;
    private readonly TimeSpan _metricsRetentionPeriod = TimeSpan.FromHours(24);
    private bool _disposed;

    public PerformanceMetricsService(ILogger<PerformanceMetricsService> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        
        // Периодическая очистка старых метрик для предотвращения утечки памяти
        _cleanupTimer = new Timer(CleanupOldMetrics, null, TimeSpan.FromHours(1), TimeSpan.FromHours(1));
    }

    public void RecordOperationTime(string operationName, long elapsedMilliseconds)
    {
        if (_disposed)
            return;
            
        ValidateOperationName(operationName);
        
        if (elapsedMilliseconds < 0)
        {
            throw new ArgumentOutOfRangeException(
                nameof(elapsedMilliseconds), 
                "Elapsed time cannot be negative");
        }

        // Защита от неразумно больших значений (например, > 1 года)
        const long MaxReasonableTimeMs = 365L * 24 * 60 * 60 * 1000; // 1 год в миллисекундах
        if (elapsedMilliseconds > MaxReasonableTimeMs)
        {
            _logger.LogWarning(
                "Unusually large elapsed time {ElapsedMs}ms for operation {OperationName}. " +
                "This might indicate a problem with time measurement.",
                elapsedMilliseconds, operationName);
        }

        var metrics = _metrics.GetOrAdd(operationName, _ => new MetricsInternal());
        metrics.LastUpdateTime = DateTime.UtcNow;

        try
        {
            checked
            {
                Interlocked.Increment(ref metrics.TotalCalls);
                Interlocked.Add(ref metrics.TotalTimeMs, elapsedMilliseconds);
            }
        }
        catch (OverflowException ex)
        {
            _logger.LogError(ex, 
                "Overflow detected for operation {OperationName}. Resetting metrics for this operation.", 
                operationName);
            // Сбрасываем только метрики для конкретной операции, а не все метрики
            if (_metrics.TryRemove(operationName, out _))
            {
                _logger.LogInformation("Removed metrics for operation {OperationName} due to overflow", operationName);
            }
            throw;
        }

        // Update min/max (thread-safe, оптимизированная версия)
        UpdateMin(ref metrics.MinTimeMs, elapsedMilliseconds);
        UpdateMax(ref metrics.MaxTimeMs, elapsedMilliseconds);
    }

    public void RecordSuccess(string operationName)
    {
        if (_disposed)
            return;
            
        ValidateOperationName(operationName);

        var metrics = _metrics.GetOrAdd(operationName, _ => new MetricsInternal());
        metrics.LastUpdateTime = DateTime.UtcNow;

        try
        {
            checked
            {
                Interlocked.Increment(ref metrics.SuccessfulCalls);
            }
        }
        catch (OverflowException ex)
        {
            _logger.LogError(ex, 
                "Overflow detected for operation {OperationName} success counter.", 
                operationName);
            throw;
        }
    }

    public void RecordError(string operationName, string errorType)
    {
        if (_disposed)
            return;
            
        ValidateOperationName(operationName);
        
        if (string.IsNullOrWhiteSpace(errorType))
        {
            throw new ArgumentException(
                "Error type cannot be null or empty", 
                nameof(errorType));
        }

        var metrics = _metrics.GetOrAdd(operationName, _ => new MetricsInternal());
        metrics.LastUpdateTime = DateTime.UtcNow;

        try
        {
            checked
            {
                Interlocked.Increment(ref metrics.FailedCalls);
            }
        }
        catch (OverflowException ex)
        {
            _logger.LogError(ex, 
                "Overflow detected for operation {OperationName} failed counter.", 
                operationName);
            throw;
        }

        // Thread-safe без lock, используя ConcurrentDictionary
        metrics.ErrorCounts.AddOrUpdate(errorType, 1, (key, oldValue) => oldValue + 1);

        // Логирование при достижении порога ошибок
        var failedCount = Volatile.Read(ref metrics.FailedCalls);
        if (failedCount > 0 && failedCount % 100 == 0)
        {
            _logger.LogWarning(
                "Operation {OperationName} has reached {ErrorCount} errors", 
                operationName, failedCount);
        }
    }

    public OperationMetrics GetMetrics(string operationName)
    {
        if (_disposed)
            throw new ObjectDisposedException(nameof(PerformanceMetricsService));
            
        ValidateOperationName(operationName);

        if (!_metrics.TryGetValue(operationName, out var internalMetrics))
        {
            return new OperationMetrics { OperationName = operationName };
        }

        return ConvertToOperationMetrics(operationName, internalMetrics);
    }

    public Dictionary<string, OperationMetrics> GetAllMetrics()
    {
        if (_disposed)
            throw new ObjectDisposedException(nameof(PerformanceMetricsService));
            
        // Создаем snapshot для консистентности данных
        var snapshot = _metrics.ToArray();
        return snapshot.ToDictionary(
            kvp => kvp.Key,
            kvp => ConvertToOperationMetrics(kvp.Key, kvp.Value));
    }

    public void Reset()
    {
        var count = _metrics.Count;
        _metrics.Clear();
        _logger.LogInformation(
            "Метрики производительности сброшены. Удалено {Count} операций.", 
            count);
    }

    public void Dispose()
    {
        if (_disposed)
            return;

        _cleanupTimer?.Dispose();
        _disposed = true;
    }

    private static void ValidateOperationName(string? operationName)
    {
        if (string.IsNullOrWhiteSpace(operationName))
        {
            throw new ArgumentException(
                "Operation name cannot be null or empty", 
                nameof(operationName));
        }
    }

    private static OperationMetrics ConvertToOperationMetrics(
        string operationName, 
        MetricsInternal internalMetrics)
    {
        // Безопасное копирование ErrorCounts (ConcurrentDictionary уже thread-safe)
        var errorCountsCopy = new Dictionary<string, int>(internalMetrics.ErrorCounts);
        
        // Исправление MinTimeMs: если значение не было установлено, возвращаем 0
        var minTime = internalMetrics.MinTimeMs == long.MaxValue 
            ? 0 
            : internalMetrics.MinTimeMs;

        // Примечание: значения могут быть немного несогласованными из-за многопоточности,
        // но это приемлемо для метрик производительности (снимок состояния)
        return new OperationMetrics
        {
            OperationName = operationName,
            TotalCalls = internalMetrics.TotalCalls,
            SuccessfulCalls = internalMetrics.SuccessfulCalls,
            FailedCalls = internalMetrics.FailedCalls,
            TotalTimeMs = internalMetrics.TotalTimeMs,
            MinTimeMs = minTime,
            MaxTimeMs = internalMetrics.MaxTimeMs,
            ErrorCounts = errorCountsCopy
        };
    }

    /// <summary>
    /// Оптимизированная версия UpdateMin с быстрой проверкой
    /// </summary>
    private static void UpdateMin(ref long currentMin, long newValue)
    {
        long initialValue, computedValue;
        do
        {
            // Читаем актуальное значение в каждой итерации для thread-safety
            initialValue = Volatile.Read(ref currentMin);
            if (newValue >= initialValue)
                return;
            
            computedValue = Math.Min(initialValue, newValue);
        }
        while (initialValue != Interlocked.CompareExchange(ref currentMin, computedValue, initialValue));
    }

    /// <summary>
    /// Оптимизированная версия UpdateMax с быстрой проверкой
    /// </summary>
    private static void UpdateMax(ref long currentMax, long newValue)
    {
        long initialValue, computedValue;
        do
        {
            // Читаем актуальное значение в каждой итерации для thread-safety
            initialValue = Volatile.Read(ref currentMax);
            if (newValue <= initialValue)
                return;
            
            computedValue = Math.Max(initialValue, newValue);
        }
        while (initialValue != Interlocked.CompareExchange(ref currentMax, computedValue, initialValue));
    }

    /// <summary>
    /// Очистка метрик, которые не обновлялись более указанного периода
    /// </summary>
    private void CleanupOldMetrics(object? state)
    {
        if (_disposed)
            return;

        try
        {
            var cutoffTime = DateTime.UtcNow - _metricsRetentionPeriod;
            var keysToRemove = new List<string>();

            foreach (var kvp in _metrics)
            {
                if (kvp.Value.LastUpdateTime < cutoffTime)
                {
                    keysToRemove.Add(kvp.Key);
                }
            }

            foreach (var key in keysToRemove)
            {
                // Повторная проверка перед удалением - метрика могла обновиться между проверкой и удалением
                if (_metrics.TryGetValue(key, out var metrics))
                {
                    if (metrics.LastUpdateTime < cutoffTime)
                    {
                        if (_metrics.TryRemove(key, out _))
                        {
                            _logger.LogDebug(
                                "Removed stale metrics for operation {OperationName}", 
                                key);
                        }
                    }
                }
            }

            if (keysToRemove.Count > 0)
            {
                _logger.LogInformation(
                    "Cleaned up {Count} stale metric entries", 
                    keysToRemove.Count);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during metrics cleanup");
        }
    }
}
