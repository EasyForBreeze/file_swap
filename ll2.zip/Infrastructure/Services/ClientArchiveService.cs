using System.Collections.Concurrent;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using ICSharpCode.SharpZipLib.Zip;
using new_assistant.Configuration;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для создания архивов с учетными данными клиентов
/// </summary>
public class ClientArchiveService : IClientArchiveService, IDisposable
{
    private readonly ILogger<ClientArchiveService> _logger;
    private readonly string _archivesDirectory;
    private readonly string _normalizedArchivesDirectory;
    private readonly string _tempDirectoryName;
    private bool _disposed = false;
    
    // Константы для валидации и ограничений
    private static readonly char[] InvalidFileNameChars = Path.GetInvalidFileNameChars();
    private const int DefaultPasswordLength = 16;
    private const int MinPasswordLength = 8;
    private const int MaxPasswordLength = 128;
    private const int CompressionLevel = 9;
    private const int BufferSize = 4096;
    private const long MaxFileSizeBytes = 10 * 1024 * 1024; // 10 MB
    private const int MaxClientIdLength = 255;
    private const int MaxClientSecretLength = 4096;
    private const int MaxConcurrentOperations = 10;
    private const string TempDirectoryBaseName = ".temp";
    
    // Блокировки для предотвращения race conditions
    private static readonly ConcurrentDictionary<string, SemaphoreSlim> _clientLocks = new();
    private static readonly SemaphoreSlim _globalOperationLimit = new SemaphoreSlim(MaxConcurrentOperations, MaxConcurrentOperations);

    public ClientArchiveService(DataPathsSettings dataPathsSettings, ILogger<ClientArchiveService> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        
        if (dataPathsSettings == null)
            throw new ArgumentNullException(nameof(dataPathsSettings));
        
        _archivesDirectory = dataPathsSettings.GetArchivesDirectoryPath();
        
        if (string.IsNullOrWhiteSpace(_archivesDirectory))
            throw new InvalidOperationException("Путь к директории архивов не может быть пустым");
        
        // Кэшируем нормализованный путь
        _normalizedArchivesDirectory = NormalizePath(_archivesDirectory);
        
        // Создаем уникальное имя временной директории с ProcessId для избежания конфликтов
        _tempDirectoryName = $"{TempDirectoryBaseName}_{Environment.ProcessId}";
        
        // Дополнительная проверка, что директория существует или может быть создана
        try
        {
            if (!Directory.Exists(_archivesDirectory))
            {
                Directory.CreateDirectory(_archivesDirectory);
                _logger.LogInformation("Создана директория архивов: {ArchivesDirectory}", _archivesDirectory);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Не удалось создать директорию архивов: {ArchivesDirectory}", _archivesDirectory);
            throw;
        }
    }
    
    /// <summary>
    /// Валидирует Client ID на безопасность и корректность
    /// </summary>
    private void ValidateClientId(string clientId)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID не может быть пустым", nameof(clientId));
        
        if (clientId.IndexOfAny(InvalidFileNameChars) >= 0)
            throw new ArgumentException($"Client ID содержит недопустимые символы: {clientId}", nameof(clientId));
        
        // Защита от path traversal
        if (clientId.Contains("..") || clientId.Contains("/") || clientId.Contains("\\"))
            throw new ArgumentException($"Client ID содержит недопустимые символы: {clientId}", nameof(clientId));
        
        // Ограничение длины для предотвращения переполнения
        if (clientId.Length > MaxClientIdLength)
            throw new ArgumentException($"Client ID слишком длинный (максимум {MaxClientIdLength} символов)", nameof(clientId));
    }
    
    /// <summary>
    /// Валидирует Client Secret на корректность
    /// </summary>
    private void ValidateClientSecret(string clientSecret)
    {
        if (string.IsNullOrWhiteSpace(clientSecret))
            throw new ArgumentException("Client Secret не может быть пустым", nameof(clientSecret));
        
        if (clientSecret.Length > MaxClientSecretLength)
            throw new ArgumentException($"Client Secret слишком длинный (максимум {MaxClientSecretLength} символов)", nameof(clientSecret));
    }
    
    /// <summary>
    /// Нормализует путь к файлу, преобразуя относительные пути в абсолютные и разрешая все символы пути
    /// </summary>
    /// <param name="path">Путь к файлу или директории для нормализации</param>
    /// <returns>Нормализованный абсолютный путь</returns>
    /// <exception cref="ArgumentException">Если путь пустой или содержит только пробелы, либо если путь невалиден</exception>
    /// <remarks>
    /// Метод использует Path.GetFullPath для нормализации пути, что включает:
    /// - Преобразование относительных путей в абсолютные
    /// - Разрешение символов '.' и '..'
    /// - Нормализацию разделителей пути
    /// - Проверку валидности пути
    /// </remarks>
    private string NormalizePath(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
            throw new ArgumentException("Путь не может быть пустым", nameof(path));
        
        try
        {
            var normalizedPath = Path.GetFullPath(path);
            _logger.LogTrace("Нормализован путь: {OriginalPath} -> {NormalizedPath}", path, normalizedPath);
            return normalizedPath;
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Недопустимый путь: {Path}", path);
            throw new ArgumentException($"Недопустимый путь: {path}", nameof(path), ex);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Неожиданная ошибка при нормализации пути: {Path}", path);
            throw new ArgumentException($"Ошибка при нормализации пути: {path}", nameof(path), ex);
        }
    }

    /// <summary>
    /// Генерирует случайный пароль для архива
    /// </summary>
    /// <param name="length">Длина пароля (по умолчанию 16)</param>
    /// <returns>Сгенерированный пароль</returns>
    /// <exception cref="ArgumentException">Если длина пароля вне допустимого диапазона</exception>
    /// <remarks>
    /// ВАЖНО: Пароли хранятся в обычных строках. Для критичных приложений рекомендуется
    /// использовать пароли сразу после генерации и не хранить их в памяти дольше необходимого.
    /// В .NET Core SecureString имеет ограниченную эффективность, поэтому используется обычная строка.
    /// </remarks>
    public string GeneratePassword(int length = DefaultPasswordLength)
    {
        // Валидация параметра
        if (length < MinPasswordLength)
            throw new ArgumentException($"Длина пароля должна быть не менее {MinPasswordLength} символов", nameof(length));
        
        if (length > MaxPasswordLength)
            throw new ArgumentException($"Длина пароля не должна превышать {MaxPasswordLength} символов", nameof(length));
        
        const string validChars = "ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz0123456789!@#$%^&*";
        var password = new char[length];
        var validCharsLength = (uint)validChars.Length;
        
        using (var rng = RandomNumberGenerator.Create())
        {
            for (int i = 0; i < length; i++)
            {
                // Используем rejection sampling для равномерного распределения
                uint randomValue;
                do
                {
                    byte[] randomBytes = new byte[4];
                    rng.GetBytes(randomBytes);
                    randomValue = BitConverter.ToUInt32(randomBytes, 0);
                } while (randomValue >= uint.MaxValue - (uint.MaxValue % validCharsLength));
                
                password[i] = validChars[(int)(randomValue % validCharsLength)];
            }
        }
        
        var result = new string(password);
        _logger.LogDebug("Сгенерирован пароль длиной {Length} символов", length);
        
        return result;
    }

    /// <summary>
    /// Создает текстовый файл с учетными данными клиента
    /// </summary>
    /// <param name="clientId">Client ID</param>
    /// <param name="clientSecret">Client Secret</param>
    /// <returns>Путь к созданному файлу</returns>
    /// <exception cref="ArgumentException">Если параметры невалидны</exception>
    public string CreateCredentialsFile(string clientId, string clientSecret)
    {
        ValidateClientId(clientId);
        ValidateClientSecret(clientSecret);
        
        var fileName = $"{clientId}_credentials.txt";
        var filePath = Path.Combine(_archivesDirectory, fileName);
        
        // Дополнительная проверка безопасности пути
        var normalizedFilePath = NormalizePath(filePath);
        
        if (!normalizedFilePath.StartsWith(_normalizedArchivesDirectory, StringComparison.OrdinalIgnoreCase))
            throw new UnauthorizedAccessException($"Доступ к файлу вне директории архивов запрещен: {filePath}");
        
        var content = $"Client ID: {clientId}\nClient Secret: {clientSecret}";
        
        File.WriteAllText(normalizedFilePath, content, Encoding.UTF8);
        _logger.LogDebug("Создан файл с учетными данными для клиента {ClientId}", clientId);
        
        return normalizedFilePath;
    }

    /// <summary>
    /// Создает защищенный паролем ZIP архив
    /// </summary>
    /// <param name="sourceFilePath">Путь к файлу для архивации</param>
    /// <param name="password">Пароль для архива (не может быть пустым)</param>
    /// <returns>Путь к созданному архиву</returns>
    /// <exception cref="ArgumentException">Если параметры невалидны</exception>
    /// <exception cref="FileNotFoundException">Если исходный файл не найден</exception>
    /// <exception cref="UnauthorizedAccessException">Если доступ к файлу запрещен</exception>
    /// <exception cref="IOException">Если произошла ошибка ввода-вывода</exception>
    public string CreatePasswordProtectedArchive(string sourceFilePath, string password)
    {
        if (string.IsNullOrWhiteSpace(sourceFilePath))
            throw new ArgumentException("Путь к исходному файлу не может быть пустым", nameof(sourceFilePath));
        
        if (string.IsNullOrWhiteSpace(password))
            throw new ArgumentException("Пароль не может быть пустым", nameof(password));
        
        if (!File.Exists(sourceFilePath))
            throw new FileNotFoundException($"Исходный файл не найден: {sourceFilePath}", sourceFilePath);
        
        // Проверка, что файл находится в допустимой директории
        var normalizedSourcePath = NormalizePath(sourceFilePath);
        
        if (!normalizedSourcePath.StartsWith(_normalizedArchivesDirectory, StringComparison.OrdinalIgnoreCase))
            throw new UnauthorizedAccessException($"Доступ к файлу вне директории архивов запрещен: {sourceFilePath}");
        
        var fileInfo = new FileInfo(normalizedSourcePath);
        
        // Проверка размера файла
        if (fileInfo.Length > MaxFileSizeBytes)
            throw new ArgumentException($"Размер файла ({fileInfo.Length} байт) превышает максимально допустимый ({MaxFileSizeBytes} байт)", nameof(sourceFilePath));
        
        if (fileInfo.Length == 0)
            throw new ArgumentException("Файл пуст", nameof(sourceFilePath));
        
        // Проверка доступного места на диске (минимум в 2 раза больше размера файла)
        // Только на Windows, так как DriveInfo не поддерживается на Unix системах
        try
        {
            var rootPath = Path.GetPathRoot(_normalizedArchivesDirectory);
            if (!string.IsNullOrEmpty(rootPath) && RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                var driveInfo = new DriveInfo(rootPath);
                if (driveInfo.AvailableFreeSpace < fileInfo.Length * 2)
                    throw new IOException($"Недостаточно места на диске для создания архива. Требуется: {fileInfo.Length * 2} байт, доступно: {driveInfo.AvailableFreeSpace} байт");
            }
            else
            {
                _logger.LogDebug("Проверка доступного места на диске пропущена (не Windows система или не удалось определить корневой путь)");
            }
        }
        catch (PlatformNotSupportedException ex)
        {
            _logger.LogWarning(ex, "Проверка доступного места на диске не поддерживается на данной платформе");
            // Продолжаем без проверки
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при проверке доступного места на диске, продолжаем без проверки");
            // Продолжаем без проверки
        }
        
        var sourceFileName = Path.GetFileNameWithoutExtension(normalizedSourcePath);
        var archiveFileName = $"{sourceFileName}.zip";
        var archivePath = Path.Combine(_archivesDirectory, archiveFileName);
        
        try
        {
            using (var fsOut = File.Create(archivePath))
            using (var zipStream = new ZipOutputStream(fsOut))
            {
                zipStream.SetLevel(CompressionLevel); // Максимальный уровень сжатия
                zipStream.Password = password; // Устанавливаем пароль
                
                var entry = new ZipEntry(Path.GetFileName(normalizedSourcePath))
                {
                    DateTime = fileInfo.LastWriteTimeUtc,
                    Size = fileInfo.Length
                };
                
                zipStream.PutNextEntry(entry);
                
                using (var fsIn = File.OpenRead(normalizedSourcePath))
                {
                    var buffer = new byte[BufferSize];
                    int bytesRead;
                    while ((bytesRead = fsIn.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        zipStream.Write(buffer, 0, bytesRead);
                    }
                }
                
                zipStream.CloseEntry();
            }
            
            _logger.LogInformation("Создан защищенный архив: {ArchivePath}", archivePath);
            return archivePath;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при создании архива для файла {SourceFile}", sourceFilePath);
            throw;
        }
    }

    /// <summary>
    /// Удаляет временные файлы (оригинальный файл и архив)
    /// </summary>
    /// <param name="filePaths">Пути к файлам для удаления</param>
    /// <remarks>
    /// Метод безопасно удаляет указанные файлы, логируя все операции.
    /// Ошибки при удалении отдельных файлов не прерывают процесс удаления остальных.
    /// </remarks>
    public void CleanupFiles(params string[] filePaths)
    {
        if (filePaths == null || filePaths.Length == 0)
        {
            _logger.LogDebug("Нет файлов для удаления");
            return;
        }
        
        var deletedCount = 0;
        var failedCount = 0;
        
        foreach (var filePath in filePaths)
        {
            if (string.IsNullOrWhiteSpace(filePath))
                continue;
                
            try
            {
                if (File.Exists(filePath))
                {
                    var fileInfo = new FileInfo(filePath);
                    var fileSize = fileInfo.Length;
                    
                    File.Delete(filePath);
                    deletedCount++;
                    
                    _logger.LogInformation("Удален файл: {FilePath} (размер: {Size} байт)", filePath, fileSize);
                }
                else
                {
                    _logger.LogDebug("Файл не существует, пропуск: {FilePath}", filePath);
                }
            }
            catch (Exception ex)
            {
                failedCount++;
                _logger.LogWarning(ex, "Не удалось удалить файл: {FilePath}", filePath);
            }
        }
        
        if (deletedCount > 0 || failedCount > 0)
        {
            _logger.LogInformation("Очистка файлов завершена: удалено {DeletedCount}, ошибок {FailedCount}", 
                deletedCount, failedCount);
        }
    }

    /// <summary>
    /// Создает полный пакет: файл с учетными данными + защищенный архив
    /// Использует транзакционный подход: создает файлы во временной директории, затем атомарно перемещает в финальное место
    /// </summary>
    /// <param name="clientId">Client ID клиента</param>
    /// <param name="clientSecret">Client Secret клиента</param>
    /// <returns>Tuple с путем к архиву и паролем для доступа к архиву</returns>
    /// <exception cref="ArgumentException">Если параметры невалидны (пустые строки, недопустимые символы и т.д.)</exception>
    /// <exception cref="UnauthorizedAccessException">Если доступ к файлу или директории запрещен</exception>
    /// <exception cref="IOException">Если произошла ошибка ввода-вывода при создании файлов или архива</exception>
    /// <remarks>
    /// Метод проверяет существование архива перед созданием. Если архив уже существует, он будет перезаписан с предупреждением в логах.
    /// Все операции логируются для аудита безопасности.
    /// </remarks>
    public (string ArchivePath, string Password) CreateClientCredentialsPackage(string clientId, string clientSecret)
    {
        var stopwatch = Stopwatch.StartNew();
        ValidateClientId(clientId);
        ValidateClientSecret(clientSecret);
        
        // Глобальное ограничение на количество одновременных операций
        // Исправление: используем Wait с таймаутом вместо бесконечного ожидания (защита от deadlock)
        const int timeoutMs = 30000; // 30 секунд таймаут
        if (!_globalOperationLimit.Wait(timeoutMs))
        {
            throw new TimeoutException($"Не удалось получить глобальную блокировку в течение {timeoutMs}мс. Возможно, слишком много одновременных операций.");
        }
        
        try
        {
            // Получаем или создаем семафор для конкретного клиента (защита от race condition)
            var semaphore = _clientLocks.GetOrAdd(clientId, _ => new SemaphoreSlim(1, 1));
            
            // Исправление: используем Wait с таймаутом вместо бесконечного ожидания
            if (!semaphore.Wait(timeoutMs))
            {
                throw new TimeoutException($"Не удалось получить блокировку для клиента {clientId} в течение {timeoutMs}мс.");
            }
            try
            {
                // Проверка на существование архива перед созданием
                var existingArchivePath = GetArchivePath(clientId);
                FileInfo? existingFileInfo = null;
                if (existingArchivePath != null)
                {
                    existingFileInfo = new FileInfo(existingArchivePath);
                    _logger.LogWarning("Архив для клиента {ClientId} уже существует (размер: {Size} байт, создан: {CreatedAt}). Будет перезаписан.", 
                        clientId, existingFileInfo.Length, existingFileInfo.CreationTimeUtc);
                }
                
                _logger.LogInformation("Начало создания пакета учетных данных для клиента {ClientId}", clientId);
                
                string? tempCredentialsPath = null;
                string? tempArchivePath = null;
                string? finalArchivePath = null;
                string? password = null;
                string? tempDir = null;
                
                try
                {
                    // Очищаем старые временные файлы перед началом работы
                    CleanupTempDirectory();
                    
                    // Создаем временную директорию для транзакционной работы
                    tempDir = Path.Combine(_archivesDirectory, _tempDirectoryName);
                    Directory.CreateDirectory(tempDir);
                    _logger.LogDebug("Создана временная директория: {TempDir}", tempDir);
            
            // 1. Генерируем пароль
            password = GeneratePassword();
            _logger.LogDebug("Сгенерирован пароль для архива клиента {ClientId}", clientId);
            
            // 2. Создаем файл с учетными данными во временной директории
            tempCredentialsPath = Path.Combine(tempDir, $"{Guid.NewGuid()}_credentials.txt");
            var content = $"Client ID: {clientId}\nClient Secret: {clientSecret}";
            File.WriteAllText(tempCredentialsPath, content, Encoding.UTF8);
            _logger.LogDebug("Создан временный файл с учетными данными для клиента {ClientId}: {FilePath}", clientId, tempCredentialsPath);
            
            // 3. Создаем архив во временной директории
            tempArchivePath = Path.Combine(tempDir, $"{Guid.NewGuid()}.zip");
            CreatePasswordProtectedArchiveInternal(tempCredentialsPath, tempArchivePath, password);
            _logger.LogDebug("Создан временный архив для клиента {ClientId}: {ArchivePath}", clientId, tempArchivePath);
            
                    // 4. Атомарно перемещаем архив в финальное место
                    finalArchivePath = Path.Combine(_archivesDirectory, $"{clientId}_credentials.zip");
                    
                    // Удаляем существующий файл, если он есть (для совместимости с разными платформами)
                    if (File.Exists(finalArchivePath))
                    {
                        File.Delete(finalArchivePath);
                        _logger.LogDebug("Удален существующий архив перед перемещением: {FinalArchivePath}", finalArchivePath);
                    }
                    
                    File.Move(tempArchivePath, finalArchivePath);
                    tempArchivePath = null; // Помечаем как обработанный
                    _logger.LogInformation("Архив перемещен в финальное место: {FinalArchivePath}", finalArchivePath);
            
            // 5. Удаляем временный текстовый файл
            CleanupFiles(tempCredentialsPath);
            tempCredentialsPath = null;
            
                    var finalFileInfo = new FileInfo(finalArchivePath);
                    stopwatch.Stop();
                    _logger.LogInformation("Пакет учетных данных для клиента {ClientId} успешно создан. Архив: {ArchivePath} (размер: {Size} байт, время: {ElapsedMs} мс)", 
                        clientId, finalArchivePath, finalFileInfo.Length, stopwatch.ElapsedMilliseconds);
                    
                    return (finalArchivePath, password);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Ошибка при создании пакета учетных данных для клиента {ClientId}", clientId);
                    
                    // Гарантированная очистка всех временных файлов
                    if (tempCredentialsPath != null)
                    {
                        try
                        {
                            CleanupFiles(tempCredentialsPath);
                        }
                        catch (Exception cleanupEx)
                        {
                            _logger.LogWarning(cleanupEx, "Не удалось очистить временный файл: {FilePath}", tempCredentialsPath);
                        }
                    }
                    
                    if (tempArchivePath != null)
                    {
                        try
                        {
                            CleanupFiles(tempArchivePath);
                        }
                        catch (Exception cleanupEx)
                        {
                            _logger.LogWarning(cleanupEx, "Не удалось очистить временный архив: {FilePath}", tempArchivePath);
                        }
                    }
                    
                    // Если финальный архив был создан, но произошла ошибка, удаляем его
                    if (finalArchivePath != null && File.Exists(finalArchivePath))
                    {
                        try
                        {
                            CleanupFiles(finalArchivePath);
                        }
                        catch (Exception cleanupEx)
                        {
                            _logger.LogWarning(cleanupEx, "Не удалось очистить финальный архив: {FilePath}", finalArchivePath);
                        }
                    }
                    
                    throw;
                }
            }
            finally
            {
                semaphore.Release();
                // Очищаем семафор, если больше нет ожидающих потоков
                if (semaphore.CurrentCount == 1)
                {
                    _clientLocks.TryRemove(clientId, out _);
                    semaphore.Dispose();
                }
            }
        }
        finally
        {
            _globalOperationLimit.Release();
        }
    }
    
    /// <summary>
    /// Очищает старые временные файлы из временной директории
    /// </summary>
    private void CleanupTempDirectory()
    {
        var tempDir = Path.Combine(_archivesDirectory, _tempDirectoryName);
        if (!Directory.Exists(tempDir))
            return;
        
        try
        {
            var tempFiles = Directory.EnumerateFiles(tempDir);
            var deletedCount = 0;
            
            foreach (var file in tempFiles)
            {
                try
                {
                    var fileInfo = new FileInfo(file);
                    // Удаляем файлы старше 1 часа
                    if (fileInfo.CreationTimeUtc < DateTime.UtcNow.AddHours(-1))
                    {
                        File.Delete(file);
                        deletedCount++;
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Не удалось удалить временный файл: {FilePath}", file);
                }
            }
            
            if (deletedCount > 0)
            {
                _logger.LogInformation("Очищено {Count} старых временных файлов из директории {TempDir}", deletedCount, _tempDirectoryName);
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при очистке временной директории: {TempDir}", tempDir);
        }
    }
    
    /// <summary>
    /// Внутренний метод для создания защищенного архива без дополнительной валидации путей
    /// (используется для работы с временными файлами в транзакционных операциях)
    /// </summary>
    /// <param name="sourceFilePath">Путь к исходному файлу для архивации</param>
    /// <param name="archivePath">Путь к создаваемому архиву</param>
    /// <param name="password">Пароль для защиты архива</param>
    /// <exception cref="ArgumentException">Если параметры невалидны или файл пуст/слишком большой</exception>
    /// <exception cref="FileNotFoundException">Если исходный файл не найден</exception>
    /// <exception cref="IOException">Если произошла ошибка ввода-вывода при создании архива</exception>
    private void CreatePasswordProtectedArchiveInternal(string sourceFilePath, string archivePath, string password)
    {
        if (string.IsNullOrWhiteSpace(password))
            throw new ArgumentException("Пароль не может быть пустым", nameof(password));
        
        if (!File.Exists(sourceFilePath))
            throw new FileNotFoundException($"Исходный файл не найден: {sourceFilePath}", sourceFilePath);
        
        var fileInfo = new FileInfo(sourceFilePath);
        
        // Проверка размера файла
        if (fileInfo.Length > MaxFileSizeBytes)
            throw new ArgumentException($"Размер файла ({fileInfo.Length} байт) превышает максимально допустимый ({MaxFileSizeBytes} байт)", nameof(sourceFilePath));
        
        if (fileInfo.Length == 0)
            throw new ArgumentException("Файл пуст", nameof(sourceFilePath));
        
        try
        {
            using (var fsOut = File.Create(archivePath))
            using (var zipStream = new ZipOutputStream(fsOut))
            {
                zipStream.SetLevel(CompressionLevel);
                zipStream.Password = password;
                
                var entry = new ZipEntry(Path.GetFileName(sourceFilePath))
                {
                    DateTime = fileInfo.LastWriteTimeUtc,
                    Size = fileInfo.Length
                };
                
                zipStream.PutNextEntry(entry);
                
                using (var fsIn = File.OpenRead(sourceFilePath))
                {
                    var buffer = new byte[BufferSize];
                    int bytesRead;
                    while ((bytesRead = fsIn.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        zipStream.Write(buffer, 0, bytesRead);
                    }
                }
                
                zipStream.CloseEntry();
            }
            
            _logger.LogDebug("Создан временный защищенный архив: {ArchivePath}", archivePath);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при создании архива для файла {SourceFile}", sourceFilePath);
            throw;
        }
    }

    /// <summary>
    /// Получает путь к архиву по Client ID
    /// </summary>
    /// <param name="clientId">Client ID</param>
    /// <returns>Путь к архиву или null если не найден</returns>
    /// <exception cref="ArgumentException">Если Client ID невалиден</exception>
    /// <exception cref="UnauthorizedAccessException">Если доступ к файлу запрещен</exception>
    public string? GetArchivePath(string clientId)
    {
        ValidateClientId(clientId);
        
        var archiveFileName = $"{clientId}_credentials.zip";
        var archivePath = Path.Combine(_archivesDirectory, archiveFileName);
        
        // Дополнительная проверка безопасности пути
        var normalizedArchivePath = NormalizePath(archivePath);
        
        if (!normalizedArchivePath.StartsWith(_normalizedArchivesDirectory, StringComparison.OrdinalIgnoreCase))
            throw new UnauthorizedAccessException($"Доступ к файлу вне директории архивов запрещен: {archivePath}");
        
        var exists = File.Exists(normalizedArchivePath);
        
        if (exists)
        {
            var fileInfo = new FileInfo(normalizedArchivePath);
            _logger.LogInformation("Найден архив для клиента {ClientId}: {ArchivePath} (размер: {Size} байт, создан: {CreatedAt})", 
                clientId, normalizedArchivePath, fileInfo.Length, fileInfo.CreationTimeUtc);
        }
        else
        {
            _logger.LogDebug("Архив для клиента {ClientId} не найден", clientId);
        }
        
        return exists ? normalizedArchivePath : null;
    }

    /// <summary>
    /// Очищает старые архивы, удаляя файлы старше указанного количества дней
    /// </summary>
    /// <param name="retentionDays">Количество дней хранения архивов (по умолчанию 1 день)</param>
    /// <returns>Tuple с количеством удаленных файлов и общим размером удаленных файлов в байтах</returns>
    /// <exception cref="ArgumentException">Если количество дней вне допустимого диапазона (0-365)</exception>
    /// <remarks>
    /// Метод удаляет все архивы, созданные раньше чем (текущая дата - retentionDays).
    /// Все операции логируются для аудита. Ошибки при удалении отдельных файлов не прерывают процесс.
    /// </remarks>
    public (int DeletedCount, long TotalSizeBytes) CleanupOldArchives(int retentionDays = 1)
    {
        if (retentionDays < 0)
            throw new ArgumentException("Количество дней хранения не может быть отрицательным", nameof(retentionDays));
        
        if (retentionDays > 365)
            throw new ArgumentException("Количество дней хранения не должно превышать 365", nameof(retentionDays));
        
        var cutoffDate = DateTime.UtcNow.AddDays(-retentionDays);
        _logger.LogInformation("Начало очистки архивов старше {CutoffDate} (retention: {RetentionDays} дней)", 
            cutoffDate.ToString("yyyy-MM-dd HH:mm:ss"), retentionDays);
        
        var deletedCount = 0;
        var totalSize = 0L;

        if (!Directory.Exists(_archivesDirectory))
        {
            _logger.LogDebug("Папка архивов не существует: {ArchivesDirectory}", _archivesDirectory);
            return (0, 0);
        }

        var archiveFiles = Directory.EnumerateFiles(_archivesDirectory, "*.zip", SearchOption.TopDirectoryOnly);
        var fileList = archiveFiles.ToList();
        _logger.LogDebug("Найдено {FileCount} архивных файлов для проверки", fileList.Count);

        foreach (var filePath in fileList)
        {
            try
            {
                var fileInfo = new FileInfo(filePath);
                
                // Проверяем возраст файла
                if (fileInfo.CreationTimeUtc < cutoffDate)
                {
                    var fileSize = fileInfo.Length;
                    
                    // Проверка на отрицательный размер
                    if (fileSize < 0)
                    {
                        _logger.LogWarning("Обнаружен файл с отрицательным размером: {FilePath}", filePath);
                        continue; // Пропускаем такой файл
                    }
                    
                    // Проверка на переполнение
                    if (totalSize > long.MaxValue - fileSize)
                    {
                        _logger.LogWarning("Превышен максимальный размер для подсчета. Остановка подсчета размера.");
                        totalSize = long.MaxValue;
                        break; // Прекращаем подсчет
                    }
                    else
                    {
                        totalSize += fileSize;
                    }
                    
                    File.Delete(filePath);
                    deletedCount++;
                    
                    _logger.LogInformation("Удален старый архив: {FileName} (создан: {CreatedAt}, размер: {Size} байт)", 
                        fileInfo.Name, fileInfo.CreationTimeUtc, fileSize);
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Не удалось удалить архив: {FilePath}", filePath);
            }
        }

        if (deletedCount > 0)
        {
            _logger.LogInformation("Очистка архивов завершена: удалено {DeletedCount} файлов, освобождено {TotalSize} байт", 
                deletedCount, totalSize);
        }
        else
        {
            _logger.LogDebug("Очистка архивов: файлов для удаления не найдено");
        }

        return (deletedCount, totalSize);
    }

    /// <summary>
    /// Получает статистику по архивам
    /// </summary>
    /// <returns>Tuple с количеством файлов, общим размером в байтах и датой создания самого старого файла</returns>
    /// <remarks>
    /// Метод сканирует директорию архивов и собирает статистику. 
    /// Если директория не существует, возвращает нулевые значения.
    /// Ошибки при обработке отдельных файлов логируются, но не прерывают процесс.
    /// </remarks>
    public (int FileCount, long TotalSizeBytes, DateTime? OldestFileDate) GetArchiveStats()
    {
        _logger.LogDebug("Начало сбора статистики по архивам в директории: {ArchivesDirectory}", _archivesDirectory);
        
        if (!Directory.Exists(_archivesDirectory))
        {
            _logger.LogDebug("Директория архивов не существует: {ArchivesDirectory}", _archivesDirectory);
            return (0, 0, null);
        }

        var archiveFiles = Directory.EnumerateFiles(_archivesDirectory, "*.zip", SearchOption.TopDirectoryOnly);
        
        var totalSize = 0L;
        DateTime? oldestDate = null;
        var fileCount = 0;
        var errorCount = 0;

        foreach (var filePath in archiveFiles)
        {
            try
            {
                var fileInfo = new FileInfo(filePath);
                
                // Проверка на отрицательный размер
                if (fileInfo.Length < 0)
                {
                    _logger.LogWarning("Обнаружен файл с отрицательным размером: {FilePath}", filePath);
                    continue; // Пропускаем такой файл
                }
                
                // Проверка на переполнение
                if (totalSize > long.MaxValue - fileInfo.Length)
                {
                    _logger.LogWarning("Превышен максимальный размер при подсчете статистики архивов");
                    totalSize = long.MaxValue;
                    break; // Прекращаем подсчет
                }
                else
                {
                    totalSize += fileInfo.Length;
                }
                
                if (oldestDate == null || fileInfo.CreationTimeUtc < oldestDate)
                {
                    oldestDate = fileInfo.CreationTimeUtc;
                }
                
                fileCount++;
            }
            catch (Exception ex)
            {
                errorCount++;
                _logger.LogWarning(ex, "Ошибка при получении информации о файле: {FilePath}", filePath);
            }
        }

        _logger.LogInformation("Статистика архивов собрана: файлов {FileCount}, общий размер {TotalSize} байт, самый старый архив от {OldestDate}, ошибок {ErrorCount}", 
            fileCount, totalSize, oldestDate?.ToString("yyyy-MM-dd HH:mm:ss") ?? "N/A", errorCount);

        return (fileCount, totalSize, oldestDate);
    }
    
    /// <summary>
    /// Освобождает ресурсы, используемые сервисом
    /// </summary>
    public void Dispose()
    {
        if (_disposed) return;
        
        try
        {
            // Очищаем семафоры для клиентов
            foreach (var kvp in _clientLocks)
            {
                try
                {
                    kvp.Value?.Dispose();
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Ошибка при освобождении семафора для клиента {ClientId}", kvp.Key);
                }
            }
            _clientLocks.Clear();
            
            // Очищаем временную директорию
            CleanupTempDirectory();
            
            _logger.LogDebug("ClientArchiveService успешно освобожден");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при освобождении ресурсов ClientArchiveService");
        }
        finally
        {
            _disposed = true;
        }
    }
}

