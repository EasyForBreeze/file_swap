using new_assistant.Core.Interfaces;
using new_assistant.Core.DTOs;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Реализация сервиса для управления модальными окнами.
/// Потокобезопасный сервис с поддержкой множественных модальных окон.
/// </summary>
public class ModalService : IModalService, IDisposable
{
    // Пункт 1: Потокобезопасность - объект для синхронизации
    private readonly object _lockObject = new object();
    private readonly ILogger<ModalService>? _logger;
    private bool _disposed = false;
    
    // Пункт 1: Приватные поля для потокобезопасного доступа
    private bool _isCreateClientModalVisible;
    private bool _isDeleteConfirmationModalVisible;
    private string? _deleteClientName;
    private bool _isClientCreatedInfoModalVisible;
    private ClientCreationResultDto? _creationResult;
    
    /// <summary>
    /// Событие, возникающее при изменении состояния любого модального окна.
    /// Подписчики должны вызывать StateHasChanged() для обновления UI.
    /// </summary>
    public event Action? OnModalStateChanged;
    
    /// <summary>
    /// Событие, возникающее при подтверждении удаления клиента.
    /// </summary>
    public event Action<string>? OnDeleteConfirmed;
    
    /// <summary>
    /// Инициализирует новый экземпляр ModalService.
    /// </summary>
    /// <param name="logger">Логгер для записи событий и ошибок. Если не указан, логирование не выполняется.</param>
    public ModalService(ILogger<ModalService>? logger = null)
    {
        _logger = logger;
    }
    
    /// <summary>
    /// Получает значение, указывающее, видимо ли модальное окно создания клиента.
    /// </summary>
    /// <value><c>true</c> если модальное окно видимо; иначе <c>false</c>.</value>
    /// <remarks>
    /// Для boolean операций чтение атомарно на большинстве платформ, но блокировка используется
    /// для обеспечения полной потокобезопасности и согласованности состояния.
    /// </remarks>
    public bool IsCreateClientModalVisible
    {
        get
        {
            lock (_lockObject)
            {
                return _isCreateClientModalVisible;
            }
        }
        private set
        {
            lock (_lockObject)
            {
                _isCreateClientModalVisible = value;
            }
        }
    }
    
    /// <summary>
    /// Получает значение, указывающее, видимо ли модальное окно подтверждения удаления.
    /// </summary>
    /// <value><c>true</c> если модальное окно видимо; иначе <c>false</c>.</value>
    /// <remarks>
    /// Для boolean операций чтение атомарно на большинстве платформ, но блокировка используется
    /// для обеспечения полной потокобезопасности и согласованности состояния.
    /// </remarks>
    public bool IsDeleteConfirmationModalVisible
    {
        get
        {
            lock (_lockObject)
            {
                return _isDeleteConfirmationModalVisible;
            }
        }
        private set
        {
            lock (_lockObject)
            {
                _isDeleteConfirmationModalVisible = value;
            }
        }
    }
    
    /// <summary>
    /// Получает имя клиента, для которого отображается модальное окно подтверждения удаления.
    /// </summary>
    /// <value>Имя клиента или <c>null</c>, если модальное окно не отображается.</value>
    public string? DeleteClientName
    {
        get
        {
            lock (_lockObject)
            {
                return _deleteClientName;
            }
        }
        private set
        {
            lock (_lockObject)
            {
                _deleteClientName = value;
            }
        }
    }
    
    /// <summary>
    /// Получает значение, указывающее, видимо ли модальное окно с информацией о созданном клиенте.
    /// </summary>
    /// <value><c>true</c> если модальное окно видимо; иначе <c>false</c>.</value>
    /// <remarks>
    /// Для boolean операций чтение атомарно на большинстве платформ, но блокировка используется
    /// для обеспечения полной потокобезопасности и согласованности состояния.
    /// </remarks>
    public bool IsClientCreatedInfoModalVisible
    {
        get
        {
            lock (_lockObject)
            {
                return _isClientCreatedInfoModalVisible;
            }
        }
        private set
        {
            lock (_lockObject)
            {
                _isClientCreatedInfoModalVisible = value;
            }
        }
    }
    
    /// <summary>
    /// Получает результат создания клиента, отображаемый в модальном окне.
    /// </summary>
    /// <value>Результат создания клиента или <c>null</c>, если модальное окно не отображается.</value>
    public ClientCreationResultDto? CreationResult
    {
        get
        {
            lock (_lockObject)
            {
                return _creationResult;
            }
        }
        private set
        {
            lock (_lockObject)
            {
                _creationResult = value;
            }
        }
    }
    
    /// <summary>
    /// Показывает модальное окно создания клиента.
    /// Автоматически закрывает все другие открытые модальные окна.
    /// </summary>
    /// <exception cref="ObjectDisposedException">Выбрасывается, если сервис был удален.</exception>
    public void ShowCreateClientModal()
    {
        ThrowIfDisposed();
        _logger?.LogDebug("Showing create client modal");
        
        Action? handler = null;
        lock (_lockObject)
        {
            // Дополнительная проверка внутри lock для защиты от Dispose во время выполнения
            ThrowIfDisposed();
            
            // Контроль состояния - закрываем все модалки перед открытием новой
            CloseAllModalsInternal();
            _isCreateClientModalVisible = true;
            
            // Получаем snapshot события для безопасного вызова вне lock
            handler = OnModalStateChanged;
        }
        
        // Вызываем вне lock, чтобы избежать deadlock при вызове обработчиков
        InvokeHandler(handler);
        _logger?.LogInformation("Create client modal is now visible");
    }
    
    /// <summary>
    /// Скрывает модальное окно создания клиента.
    /// </summary>
    /// <exception cref="ObjectDisposedException">Выбрасывается, если сервис был удален.</exception>
    public void HideCreateClientModal()
    {
        ThrowIfDisposed();
        _logger?.LogDebug("Hiding create client modal");
        
        Action? handler = null;
        lock (_lockObject)
        {
            ThrowIfDisposed(); // Дополнительная проверка внутри lock
            _isCreateClientModalVisible = false;
            handler = OnModalStateChanged;
        }
        
        InvokeHandler(handler);
    }

    /// <summary>
    /// Показывает модальное окно подтверждения удаления клиента.
    /// </summary>
    /// <param name="clientName">Имя клиента для удаления. Не может быть null или пустой строкой.</param>
    /// <exception cref="ArgumentNullException">Выбрасывается, если <paramref name="clientName"/> равен null.</exception>
    /// <exception cref="ArgumentException">Выбрасывается, если <paramref name="clientName"/> является пустой строкой или содержит только пробелы.</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается, если сервис был удален.</exception>
    public void ShowDeleteConfirmationModal(string clientName)
    {
        ThrowIfDisposed();
        
        // Валидация входных параметров - оптимизированная версия
        ArgumentNullException.ThrowIfNull(clientName);
        
        if (string.IsNullOrWhiteSpace(clientName))
        {
            throw new ArgumentException("Client name cannot be empty or whitespace.", nameof(clientName));
        }
        
        _logger?.LogDebug("Showing delete confirmation modal for client: {ClientName}", clientName);
        
        Action? handler = null;
        lock (_lockObject)
        {
            // Дополнительная проверка внутри lock для защиты от Dispose во время выполнения
            ThrowIfDisposed();
            
            // Контроль состояния - закрываем все модалки перед открытием новой
            CloseAllModalsInternal();
            _deleteClientName = clientName;
            _isDeleteConfirmationModalVisible = true;
            
            // Получаем snapshot события для безопасного вызова вне lock
            handler = OnModalStateChanged;
        }
        
        // Вызываем вне lock, чтобы избежать deadlock при вызове обработчиков
        InvokeHandler(handler);
        _logger?.LogInformation("Delete confirmation modal is now visible for client: {ClientName}", clientName);
    }
    
    /// <summary>
    /// Скрывает модальное окно подтверждения удаления.
    /// </summary>
    /// <exception cref="ObjectDisposedException">Выбрасывается, если сервис был удален.</exception>
    public void HideDeleteConfirmationModal()
    {
        ThrowIfDisposed();
        _logger?.LogDebug("Hiding delete confirmation modal");
        
        Action? handler = null;
        lock (_lockObject)
        {
            ThrowIfDisposed(); // Дополнительная проверка внутри lock
            _isDeleteConfirmationModalVisible = false;
            _deleteClientName = null;
            handler = OnModalStateChanged;
        }
        
        InvokeHandler(handler);
    }
    
    /// <summary>
    /// Подтверждает удаление клиента и вызывает событие OnDeleteConfirmed.
    /// </summary>
    /// <param name="clientName">Имя клиента для удаления. Не может быть null или пустой строкой.</param>
    /// <exception cref="ArgumentNullException">Выбрасывается, если <paramref name="clientName"/> равен null.</exception>
    /// <exception cref="ArgumentException">Выбрасывается, если <paramref name="clientName"/> является пустой строкой или содержит только пробелы.</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается, если сервис был удален.</exception>
    public void ConfirmDelete(string clientName)
    {
        ThrowIfDisposed();
        
        // Валидация входных параметров
        ArgumentNullException.ThrowIfNull(clientName);
        
        if (string.IsNullOrWhiteSpace(clientName))
        {
            throw new ArgumentException("Client name cannot be empty or whitespace.", nameof(clientName));
        }
        
        // Проверка соответствия текущему состоянию для безопасности
        lock (_lockObject)
        {
            ThrowIfDisposed(); // Дополнительная проверка внутри lock
            
            if (!_isDeleteConfirmationModalVisible)
            {
                throw new InvalidOperationException("Delete confirmation modal is not visible.");
            }
            
            if (!string.Equals(_deleteClientName, clientName, StringComparison.Ordinal))
            {
                throw new ArgumentException(
                    $"Client name '{clientName}' does not match the current delete confirmation client '{_deleteClientName}'.", 
                    nameof(clientName));
            }
        }
        
        _logger?.LogInformation("Delete confirmed for client: {ClientName}", clientName);
        
        // Безопасный вызов события с обработкой исключений
        InvokeDeleteConfirmed(clientName);
        HideDeleteConfirmationModal();
    }
    
    /// <summary>
    /// Показывает модальное окно с информацией о созданном клиенте.
    /// </summary>
    /// <param name="result">Результат создания клиента. Не может быть null.</param>
    /// <exception cref="ArgumentNullException">Выбрасывается, если <paramref name="result"/> равен null.</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается, если сервис был удален.</exception>
    public void ShowClientCreatedInfoModal(ClientCreationResultDto result)
    {
        ThrowIfDisposed();
        
        // Валидация входных параметров
        ArgumentNullException.ThrowIfNull(result);
        
        _logger?.LogDebug("Showing client created info modal for client: {ClientId}", result.ClientId);
        
        Action? handler = null;
        lock (_lockObject)
        {
            // Дополнительная проверка внутри lock для защиты от Dispose во время выполнения
            ThrowIfDisposed();
            
            // Контроль состояния - закрываем все модалки перед открытием новой
            CloseAllModalsInternal();
            _creationResult = result;
            _isClientCreatedInfoModalVisible = true;
            
            // Получаем snapshot события для безопасного вызова вне lock
            handler = OnModalStateChanged;
        }
        
        // Вызываем вне lock, чтобы избежать deadlock при вызове обработчиков
        InvokeHandler(handler);
        _logger?.LogInformation("Client created info modal is now visible for client: {ClientId}", result.ClientId);
    }
    
    /// <summary>
    /// Скрывает модальное окно с информацией о созданном клиенте.
    /// </summary>
    /// <exception cref="ObjectDisposedException">Выбрасывается, если сервис был удален.</exception>
    public void HideClientCreatedInfoModal()
    {
        ThrowIfDisposed();
        _logger?.LogDebug("Hiding client created info modal");
        
        Action? handler = null;
        lock (_lockObject)
        {
            ThrowIfDisposed(); // Дополнительная проверка внутри lock
            _isClientCreatedInfoModalVisible = false;
            _creationResult = null;
            handler = OnModalStateChanged;
        }
        
        InvokeHandler(handler);
    }
    
    /// <summary>
    /// Закрывает все открытые модальные окна.
    /// </summary>
    /// <exception cref="ObjectDisposedException">Выбрасывается, если сервис был удален.</exception>
    public void CloseAllModals()
    {
        ThrowIfDisposed();
        _logger?.LogDebug("Closing all modals");
        
        Action? handler = null;
        lock (_lockObject)
        {
            ThrowIfDisposed(); // Дополнительная проверка внутри lock
            CloseAllModalsInternal();
            handler = OnModalStateChanged;
        }
        
        InvokeHandler(handler);
    }
    
    /// <summary>
    /// Внутренний метод для закрытия всех модальных окон.
    /// Должен вызываться только внутри lock (_lockObject).
    /// </summary>
    private void CloseAllModalsInternal()
    {
        _isCreateClientModalVisible = false;
        _isDeleteConfirmationModalVisible = false;
        _isClientCreatedInfoModalVisible = false;
        _deleteClientName = null;
        _creationResult = null;
    }
    
    /// <summary>
    /// Безопасный вызов обработчика события с обработкой исключений.
    /// </summary>
    /// <param name="handler">Обработчик события или null.</param>
    private void InvokeHandler(Action? handler)
    {
        if (handler != null)
        {
            foreach (Action? singleHandler in handler.GetInvocationList())
            {
                try
                {
                    singleHandler?.Invoke();
                }
                catch (Exception ex)
                {
                    _logger?.LogError(ex, "Error invoking OnModalStateChanged handler");
                    // Не прерываем выполнение других обработчиков
                }
            }
        }
    }
    
    /// <summary>
    /// Безопасный вызов события OnModalStateChanged с обработкой исключений для каждого подписчика.
    /// Получает snapshot события внутри lock и вызывает обработчики вне lock для предотвращения deadlock.
    /// </summary>
    private void InvokeModalStateChanged()
    {
        Action? handler;
        lock (_lockObject)
        {
            // Получаем snapshot события для безопасного вызова вне lock
            handler = OnModalStateChanged;
        }
        
        // Вызываем вне lock, чтобы избежать deadlock при вызове обработчиков
        InvokeHandler(handler);
    }
    
    /// <summary>
    /// Безопасный вызов события OnDeleteConfirmed с обработкой исключений для каждого подписчика.
    /// Получает snapshot события внутри lock и вызывает обработчики вне lock для предотвращения deadlock.
    /// </summary>
    /// <param name="clientName">Имя клиента для передачи в обработчики.</param>
    private void InvokeDeleteConfirmed(string clientName)
    {
        Action<string>? handler;
        lock (_lockObject)
        {
            // Получаем snapshot события для безопасного вызова вне lock
            handler = OnDeleteConfirmed;
        }
        
        // Вызываем вне lock, чтобы избежать deadlock при вызове обработчиков
        if (handler != null)
        {
            foreach (Action<string>? singleHandler in handler.GetInvocationList())
            {
                try
                {
                    singleHandler?.Invoke(clientName);
                }
                catch (Exception ex)
                {
                    _logger?.LogError(ex, "Error invoking OnDeleteConfirmed handler for client: {ClientName}", clientName);
                    // Не прерываем выполнение других обработчиков
                }
            }
        }
    }
    
    // Пункт 2: Проверка на disposed состояние
    private void ThrowIfDisposed()
    {
        if (_disposed)
        {
            throw new ObjectDisposedException(nameof(ModalService));
        }
    }
    
    // Пункт 2: Реализация IDisposable для защиты от утечек памяти
    protected virtual void Dispose(bool disposing)
    {
        if (!_disposed)
        {
            if (disposing)
            {
                lock (_lockObject)
                {
                    // Очистка событий для предотвращения утечек памяти
                    OnModalStateChanged = null;
                    OnDeleteConfirmed = null;
                    CloseAllModalsInternal();
                }
                
                _logger?.LogDebug("ModalService disposed");
            }
            
            _disposed = true;
        }
    }
    
    /// <summary>
    /// Получает имя клиента для удаления или пустую строку, если модальное окно не видимо.
    /// Безопасный метод для использования в UI компонентах.
    /// </summary>
    /// <returns>Имя клиента для удаления или пустая строка, если модальное окно не видимо.</returns>
    public string GetDeleteClientNameSafe()
    {
        lock (_lockObject)
        {
            return _isDeleteConfirmationModalVisible ? (_deleteClientName ?? string.Empty) : string.Empty;
        }
    }
    
    /// <summary>
    /// Получает текущее состояние всех модальных окон атомарно.
    /// Полезно для отладки и логирования.
    /// </summary>
    /// <returns>Текущее состояние всех модальных окон.</returns>
    public ModalState GetCurrentState()
    {
        lock (_lockObject)
        {
            return new ModalState(
                _isCreateClientModalVisible,
                _isDeleteConfirmationModalVisible,
                _isClientCreatedInfoModalVisible,
                _deleteClientName,
                _creationResult
            );
        }
    }
    
    /// <summary>
    /// Проверяет, открыто ли хотя бы одно модальное окно.
    /// </summary>
    /// <returns><c>true</c> если открыто хотя бы одно модальное окно; иначе <c>false</c>.</returns>
    public bool HasAnyModalOpen()
    {
        lock (_lockObject)
        {
            return _isCreateClientModalVisible || 
                   _isDeleteConfirmationModalVisible || 
                   _isClientCreatedInfoModalVisible;
        }
    }
    
    /// <summary>
    /// Освобождает все ресурсы, используемые ModalService.
    /// </summary>
    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}
