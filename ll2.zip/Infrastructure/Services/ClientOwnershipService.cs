using Microsoft.Data.Sqlite;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;
using System.Linq;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для управления владением клиентами с использованием SQLite
/// </summary>
public class ClientOwnershipService : IClientOwnershipService, IDisposable
{
    private readonly string _connectionString;
    private readonly ILogger<ClientOwnershipService> _logger;
    private readonly IAuditService? _auditService;
    private readonly SemaphoreSlim _initSemaphore = new SemaphoreSlim(1, 1);
    private readonly SemaphoreSlim _transferLock = new SemaphoreSlim(1, 1);
    private volatile bool _isInitialized = false;
    private const string DatabaseName = "ownership";
    private bool _disposed = false;
    
    /// <summary>
    /// Максимальная длина username (255 символов - стандартный предел для большинства систем)
    /// </summary>
    private const int MaxUsernameLength = 255;
    
    /// <summary>
    /// Максимальная длина client_id (255 символов - достаточный предел для идентификаторов клиентов)
    /// </summary>
    private const int MaxClientIdLength = 255;
    
    /// <summary>
    /// Максимальная длина realm (255 символов - стандартный предел для реалмов Keycloak)
    /// </summary>
    private const int MaxRealmLength = 255;
    
    /// <summary>
    /// Timeout для команд SQLite в секундах
    /// </summary>
    private const int CommandTimeoutSeconds = 30;
    
    /// <summary>
    /// Размер батча для массовых операций (обработка больших коллекций)
    /// </summary>
    private const int BatchSize = 500;

    public ClientOwnershipService(DataPathsSettings dataPathsSettings, ILogger<ClientOwnershipService> logger, IAuditService? auditService = null)
    {
        try
        {
            _logger = logger;
            _auditService = auditService;
            var dbPath = dataPathsSettings.GetOwnershipDbPath();
            
            // Проверка и создание директории для БД
            var directory = Path.GetDirectoryName(dbPath);
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
                _logger.LogInformation("Создана директория для БД владения клиентами: {Directory}", directory);
            }
            
            _connectionString = $"Data Source={dbPath};Mode=ReadWriteCreate;Cache=Shared;Pooling=True";
        }
        catch
        {
            // Освобождаем ресурсы при ошибке в конструкторе
            _initSemaphore?.Dispose();
            _transferLock?.Dispose();
            throw;
        }
    }
    
    /// <summary>
    /// Проверка, не освобожден ли сервис
    /// </summary>
    private void ThrowIfDisposed()
    {
        if (_disposed)
            throw new ObjectDisposedException(nameof(ClientOwnershipService));
    }

    /// <summary>
    /// Асинхронная инициализация базы данных (вызывается автоматически при первом использовании)
    /// </summary>
    private async Task InitializeDatabaseAsync()
    {
        try
        {
            // Проверка прав доступа к БД
            try
            {
                var testConnection = new SqliteConnection(_connectionString);
                await testConnection.OpenAsync().ConfigureAwait(false);
                await testConnection.CloseAsync().ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                var builder = new SqliteConnectionStringBuilder(_connectionString);
                _logger.LogError(ex, "Невозможно создать или открыть БД владения клиентами по пути: {DbPath}", 
                    builder.DataSource);
                throw;
            }
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            await using var createTableCommand = connection.CreateCommand();
            createTableCommand.CommandTimeout = CommandTimeoutSeconds;
            createTableCommand.CommandText = @"
                CREATE TABLE IF NOT EXISTS user_client_ownership (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL,
                    client_id TEXT NOT NULL,
                    realm TEXT NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(username, client_id, realm)
                );
                
                CREATE INDEX IF NOT EXISTS idx_username_realm 
                ON user_client_ownership(username, realm);
                
                CREATE INDEX IF NOT EXISTS idx_client_realm 
                ON user_client_ownership(client_id, realm);
                
                CREATE INDEX IF NOT EXISTS idx_username_client_realm 
                ON user_client_ownership(username, client_id, realm);
                
                CREATE INDEX IF NOT EXISTS idx_created_at 
                ON user_client_ownership(created_at DESC);
                ";
            
            await createTableCommand.ExecuteNonQueryAsync().ConfigureAwait(false);
            
            _logger.LogDebug("База данных ownership успешно инициализирована");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка инициализации базы данных владения клиентами");
            throw;
        }
    }

    /// <summary>
    /// Гарантирует, что БД инициализирована перед выполнением операции
    /// </summary>
    private async Task EnsureInitializedAsync()
    {
        if (_isInitialized) return;
        
        await _initSemaphore.WaitAsync().ConfigureAwait(false);
        try
        {
            if (_isInitialized) return;
            
            await InitializeDatabaseAsync().ConfigureAwait(false);
            _isInitialized = true;
        }
        finally
        {
            _initSemaphore.Release();
        }
    }

    /// <summary>
    /// Валидация строкового параметра с проверкой на null, whitespace и максимальную длину
    /// </summary>
    private static void ValidateStringParameter(string value, string paramName, int maxLength, string fieldName)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(value, paramName);
        if (value.Length > maxLength)
            throw new ArgumentException($"{fieldName} не может быть длиннее {maxLength} символов", paramName);
    }
    
    /// <summary>
    /// Валидация входных параметров
    /// </summary>
    private static void ValidateParameters(string username, string clientId, string realm)
    {
        ValidateStringParameter(username, nameof(username), MaxUsernameLength, "Username");
        ValidateStringParameter(clientId, nameof(clientId), MaxClientIdLength, "ClientId");
        ValidateStringParameter(realm, nameof(realm), MaxRealmLength, "Realm");
    }
    
    /// <summary>
    /// Валидация параметров для методов с двумя параметрами (clientId, realm)
    /// </summary>
    private static void ValidateClientRealmParameters(string clientId, string realm)
    {
        ValidateStringParameter(clientId, nameof(clientId), MaxClientIdLength, "ClientId");
        ValidateStringParameter(realm, nameof(realm), MaxRealmLength, "Realm");
    }
    
    /// <summary>
    /// Валидация параметров для методов с username и realm
    /// </summary>
    private static void ValidateUsernameRealmParameters(string username, string realm)
    {
        ValidateStringParameter(username, nameof(username), MaxUsernameLength, "Username");
        ValidateStringParameter(realm, nameof(realm), MaxRealmLength, "Realm");
    }

    public async Task<bool> IsOwnerAsync(string username, string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateParameters(username, clientId, realm);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                SELECT COUNT(*) FROM user_client_ownership 
                WHERE username = @username AND client_id = @clientId AND realm = @realm";
            
            command.Parameters.AddWithValue("@username", username);
            command.Parameters.AddWithValue("@clientId", clientId);
            command.Parameters.AddWithValue("@realm", realm);
            
            var count = await command.ExecuteScalarAsync().ConfigureAwait(false);
            var result = Convert.ToInt32(count) > 0;
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            
            return result;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка проверки владения клиентом {ClientId} пользователем {Username}", clientId, username);
            throw;
        }
    }

    public async Task GrantOwnershipAsync(string username, string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateParameters(username, clientId, realm);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                INSERT OR IGNORE INTO user_client_ownership (username, client_id, realm) 
                VALUES (@username, @clientId, @realm)";
            
            command.Parameters.AddWithValue("@username", username);
            command.Parameters.AddWithValue("@clientId", clientId);
            command.Parameters.AddWithValue("@realm", realm);
            
            var rowsAffected = await command.ExecuteNonQueryAsync().ConfigureAwait(false);
            
            if (rowsAffected == 0)
            {
                _logger.LogDebug(
                    "Попытка предоставить владение клиентом {ClientId} пользователю {Username}, но запись уже существует",
                    clientId, username);
            }
            else
            {
                _logger.LogDebug(
                    "Владение клиентом {ClientId} предоставлено пользователю {Username} в реалме {Realm}",
                    clientId, username, realm);
            }
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка предоставления владения клиентом {ClientId} пользователю {Username}", clientId, username);
            throw;
        }
    }

    public async Task RevokeOwnershipAsync(string username, string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateParameters(username, clientId, realm);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                DELETE FROM user_client_ownership 
                WHERE username = @username AND client_id = @clientId AND realm = @realm";
            
            command.Parameters.AddWithValue("@username", username);
            command.Parameters.AddWithValue("@clientId", clientId);
            command.Parameters.AddWithValue("@realm", realm);
            
            await command.ExecuteNonQueryAsync().ConfigureAwait(false);
            
            _logger.LogDebug(
                "Владение клиентом {ClientId} отозвано у пользователя {Username} в реалме {Realm}",
                clientId, username, realm);
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка отзыва владения клиентом {ClientId} у пользователя {Username}", clientId, username);
            throw;
        }
    }

    public async Task<List<string>> GetUserClientsAsync(string username, string realm)
    {
        ThrowIfDisposed();
        ValidateUsernameRealmParameters(username, realm);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                SELECT client_id FROM user_client_ownership 
                WHERE username = @username AND realm = @realm 
                ORDER BY created_at DESC";
            
            command.Parameters.AddWithValue("@username", username);
            command.Parameters.AddWithValue("@realm", realm);
            
            var clients = new List<string>();
            await using var reader = await command.ExecuteReaderAsync().ConfigureAwait(false);
            var clientIdOrdinal = reader.GetOrdinal("client_id");
            while (await reader.ReadAsync().ConfigureAwait(false))
            {
                clients.Add(reader.GetString(clientIdOrdinal));
            }
            
            _logger.LogDebug(
                "Получено {Count} клиентов для пользователя {Username} в реалме {Realm}",
                clients.Count, username, realm);
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            
            return clients;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка получения клиентов пользователя {Username}", username);
            throw;
        }
    }

    public async Task<string?> GetClientOwnerAsync(string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateClientRealmParameters(clientId, realm);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                SELECT username FROM user_client_ownership 
                WHERE client_id = @clientId AND realm = @realm 
                LIMIT 1";
            
            command.Parameters.AddWithValue("@clientId", clientId);
            command.Parameters.AddWithValue("@realm", realm);
            
            var result = await command.ExecuteScalarAsync().ConfigureAwait(false);
            var owner = result?.ToString();
            
            _logger.LogDebug(
                "Получен владелец клиента {ClientId} в реалме {Realm}: {Owner}",
                clientId, realm, owner ?? "не найден");
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            
            return owner;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка получения владельца клиента {ClientId}", clientId);
            throw;
        }
    }

    public async Task TransferOwnershipAsync(string fromUsername, string toUsername, string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateParameters(fromUsername, clientId, realm);
        ValidateStringParameter(toUsername, nameof(toUsername), MaxUsernameLength, "Username");
        
        // Защита от race conditions при параллельных операциях
        await _transferLock.WaitAsync().ConfigureAwait(false);
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            await using var transaction = (Microsoft.Data.Sqlite.SqliteTransaction)await connection.BeginTransactionAsync().ConfigureAwait(false);
            
            try
            {
                // Проверка внутри транзакции, что старое владение существует
                var checkFromCommand = connection.CreateCommand();
                checkFromCommand.Transaction = transaction;
                checkFromCommand.CommandTimeout = CommandTimeoutSeconds;
                checkFromCommand.CommandText = @"
                    SELECT COUNT(*) FROM user_client_ownership 
                    WHERE username = @fromUsername AND client_id = @clientId AND realm = @realm";
                
                checkFromCommand.Parameters.AddWithValue("@fromUsername", fromUsername);
                checkFromCommand.Parameters.AddWithValue("@clientId", clientId);
                checkFromCommand.Parameters.AddWithValue("@realm", realm);
                
                var fromCount = Convert.ToInt32(await checkFromCommand.ExecuteScalarAsync().ConfigureAwait(false));
                if (fromCount == 0)
                {
                    throw new InvalidOperationException(
                        $"Пользователь {fromUsername} не является владельцем клиента {clientId} в реалме {realm}");
                }
                
                // Проверка внутри транзакции, что новое владение не существует (если передаем другому пользователю)
                if (fromUsername != toUsername)
                {
                    var checkToCommand = connection.CreateCommand();
                    checkToCommand.Transaction = transaction;
                    checkToCommand.CommandTimeout = CommandTimeoutSeconds;
                    checkToCommand.CommandText = @"
                        SELECT COUNT(*) FROM user_client_ownership 
                        WHERE username = @toUsername AND client_id = @clientId AND realm = @realm";
                    
                    checkToCommand.Parameters.AddWithValue("@toUsername", toUsername);
                    checkToCommand.Parameters.AddWithValue("@clientId", clientId);
                    checkToCommand.Parameters.AddWithValue("@realm", realm);
                    
                    var toCount = Convert.ToInt32(await checkToCommand.ExecuteScalarAsync().ConfigureAwait(false));
                    if (toCount > 0)
                    {
                        throw new InvalidOperationException(
                            $"Пользователь {toUsername} уже является владельцем клиента {clientId} в реалме {realm}");
                    }
                }
                
                // Удаляем старое владение
                var deleteCommand = connection.CreateCommand();
                deleteCommand.Transaction = transaction;
                deleteCommand.CommandTimeout = CommandTimeoutSeconds;
                deleteCommand.CommandText = @"
                    DELETE FROM user_client_ownership 
                    WHERE username = @fromUsername AND client_id = @clientId AND realm = @realm";
                
                deleteCommand.Parameters.AddWithValue("@fromUsername", fromUsername);
                deleteCommand.Parameters.AddWithValue("@clientId", clientId);
                deleteCommand.Parameters.AddWithValue("@realm", realm);
                
                var deletedRows = await deleteCommand.ExecuteNonQueryAsync().ConfigureAwait(false);
                
                if (deletedRows == 0)
                {
                    throw new InvalidOperationException(
                        $"Не удалось удалить владение клиентом {clientId} у пользователя {fromUsername} в реалме {realm}");
                }
                
                // Создаем новое владение (только если передаем другому пользователю)
                if (fromUsername != toUsername)
                {
                    var insertCommand = connection.CreateCommand();
                    insertCommand.Transaction = transaction;
                    insertCommand.CommandTimeout = CommandTimeoutSeconds;
                    insertCommand.CommandText = @"
                        INSERT INTO user_client_ownership (username, client_id, realm) 
                        VALUES (@toUsername, @clientId, @realm)";
                    
                    insertCommand.Parameters.AddWithValue("@toUsername", toUsername);
                    insertCommand.Parameters.AddWithValue("@clientId", clientId);
                    insertCommand.Parameters.AddWithValue("@realm", realm);
                    
                    await insertCommand.ExecuteNonQueryAsync().ConfigureAwait(false);
                }
                
                await transaction.CommitAsync().ConfigureAwait(false);
                
                _logger.LogDebug(
                    "Владение клиентом {ClientId} передано от {FromUsername} к {ToUsername} в реалме {Realm}",
                    clientId, fromUsername, toUsername, realm);
            }
            catch
            {
                await transaction.RollbackAsync().ConfigureAwait(false);
                throw;
            }
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка передачи владения клиентом {ClientId} от {FromUsername} к {ToUsername}", clientId, fromUsername, toUsername);
            throw;
        }
        finally
        {
            _transferLock.Release();
        }
    }
    
    /// <summary>
    /// Получить все клиенты пользователя во всех реалмах
    /// </summary>
    public async Task<List<UserClientInfo>> GetAllUserClientsAsync(string username)
    {
        ThrowIfDisposed();
        ValidateStringParameter(username, nameof(username), MaxUsernameLength, "Username");
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                SELECT client_id, realm, created_at 
                FROM user_client_ownership 
                WHERE username = @username
                ORDER BY created_at DESC";
            
            command.Parameters.AddWithValue("@username", username);
            
            var clients = new List<UserClientInfo>();
            
            await using var reader = await command.ExecuteReaderAsync().ConfigureAwait(false);
            var clientIdOrdinal = reader.GetOrdinal("client_id");
            var realmOrdinal = reader.GetOrdinal("realm");
            var createdAtOrdinal = reader.GetOrdinal("created_at");
            while (await reader.ReadAsync().ConfigureAwait(false))
            {
                clients.Add(new UserClientInfo
                {
                    ClientId = reader.GetString(clientIdOrdinal),
                    Realm = reader.GetString(realmOrdinal),
                    GrantedAt = reader.GetDateTime(createdAtOrdinal)
                });
            }
            
            _logger.LogDebug(
                "Получено {Count} клиентов для пользователя {Username} во всех реалмах",
                clients.Count, username);
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            
            return clients;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка получения всех клиентов пользователя {Username}", username);
            throw;
        }
    }
    
    /// <summary>
    /// Предоставить доступ (alias для GrantOwnershipAsync)
    /// </summary>
    public async Task GrantAccessAsync(string username, string clientId, string realm)
    {
        ThrowIfDisposed();
        await GrantOwnershipAsync(username, clientId, realm);
    }
    
    /// <summary>
    /// Отозвать доступ (alias для RevokeOwnershipAsync)
    /// </summary>
    public async Task RevokeAccessAsync(string username, string clientId, string realm)
    {
        ThrowIfDisposed();
        await RevokeOwnershipAsync(username, clientId, realm);
    }
    
    /// <summary>
    /// Предоставить доступ с логированием (для использования администраторами)
    /// </summary>
    public async Task GrantAccessWithAuditAsync(string adminUsername, string targetUsername, string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateParameters(targetUsername, clientId, realm);
        ValidateStringParameter(adminUsername, nameof(adminUsername), MaxUsernameLength, "AdminUsername");
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await GrantOwnershipAsync(targetUsername, clientId, realm).ConfigureAwait(false);
            
            // Логируем только если сервис аудита доступен
            if (_auditService != null)
            {
                try
                {
                    await _auditService.LogAccessGrantedAsync(adminUsername, targetUsername, clientId, realm)
                        .ConfigureAwait(false);
                }
                catch (Exception auditEx)
                {
                    // Компенсирующая транзакция: откатываем изменение владения
                    _logger.LogWarning(auditEx, 
                        "Ошибка аудита при предоставлении доступа. Откатываем изменение владения.");
                    await RevokeOwnershipAsync(targetUsername, clientId, realm).ConfigureAwait(false);
                    throw;
                }
            }
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка предоставления доступа с аудитом");
            throw;
        }
    }
    
    /// <summary>
    /// Отозвать доступ с логированием (для использования администраторами)
    /// </summary>
    public async Task RevokeAccessWithAuditAsync(string adminUsername, string targetUsername, string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateParameters(targetUsername, clientId, realm);
        ValidateStringParameter(adminUsername, nameof(adminUsername), MaxUsernameLength, "AdminUsername");
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            // Сохраняем состояние до отзыва для компенсации
            var wasOwner = await IsOwnerAsync(targetUsername, clientId, realm).ConfigureAwait(false);
            
            await RevokeOwnershipAsync(targetUsername, clientId, realm).ConfigureAwait(false);
            
            // Логируем только если сервис аудита доступен
            if (_auditService != null)
            {
                try
                {
                    await _auditService.LogAccessRevokedAsync(adminUsername, targetUsername, clientId, realm)
                        .ConfigureAwait(false);
                }
                catch (Exception auditEx)
                {
                    // Компенсирующая транзакция: восстанавливаем владение, если оно было
                    _logger.LogWarning(auditEx, 
                        "Ошибка аудита при отзыве доступа. Восстанавливаем изменение владения.");
                    if (wasOwner)
                    {
                        await GrantOwnershipAsync(targetUsername, clientId, realm).ConfigureAwait(false);
                    }
                    throw;
                }
            }
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка отзыва доступа с аудитом");
            throw;
        }
    }
    
    /// <summary>
    /// Удалить все записи владения для клиента (при удалении клиента)
    /// </summary>
    public async Task RemoveAllClientOwnershipsAsync(string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateClientRealmParameters(clientId, realm);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                DELETE FROM user_client_ownership 
                WHERE client_id = @clientId AND realm = @realm";
            
            command.Parameters.AddWithValue("@clientId", clientId);
            command.Parameters.AddWithValue("@realm", realm);
            
            var deletedRows = await command.ExecuteNonQueryAsync().ConfigureAwait(false);
            
            _logger.LogInformation("Удалено {Count} записей владения для клиента {ClientId} в реалме {Realm}", 
                deletedRows, clientId, realm);
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка удаления записей владения для клиента {ClientId} в реалме {Realm}", clientId, realm);
            throw;
        }
    }
    
    /// <summary>
    /// Проверить, есть ли владельцы у клиента
    /// </summary>
    public async Task<bool> HasOwnersAsync(string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateClientRealmParameters(clientId, realm);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                SELECT COUNT(*) FROM user_client_ownership 
                WHERE client_id = @clientId AND realm = @realm";
            
            command.Parameters.AddWithValue("@clientId", clientId);
            command.Parameters.AddWithValue("@realm", realm);
            
            var count = await command.ExecuteScalarAsync().ConfigureAwait(false);
            var result = Convert.ToInt32(count) > 0;
            
            _logger.LogDebug(
                "Проверка владельцев клиента {ClientId} в реалме {Realm}: {HasOwners}",
                clientId, realm, result ? "есть владельцы" : "нет владельцев");
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            
            return result;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка проверки владельцев клиента {ClientId}", clientId);
            throw;
        }
    }
    
    /// <summary>
    /// Получить всех владельцев клиента
    /// </summary>
    public async Task<List<string>> GetClientOwnersAsync(string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateClientRealmParameters(clientId, realm);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                SELECT username FROM user_client_ownership 
                WHERE client_id = @clientId AND realm = @realm 
                ORDER BY created_at ASC";
            
            command.Parameters.AddWithValue("@clientId", clientId);
            command.Parameters.AddWithValue("@realm", realm);
            
            var owners = new List<string>();
            await using var reader = await command.ExecuteReaderAsync().ConfigureAwait(false);
            var usernameOrdinal = reader.GetOrdinal("username");
            while (await reader.ReadAsync().ConfigureAwait(false))
            {
                owners.Add(reader.GetString(usernameOrdinal));
            }
            
            _logger.LogDebug(
                "Получено {Count} владельцев для клиента {ClientId} в реалме {Realm}",
                owners.Count, clientId, realm);
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            
            return owners;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка получения владельцев клиента {ClientId}", clientId);
            throw;
        }
    }
    
    /// <summary>
    /// Массовое предоставление владения
    /// </summary>
    public async Task GrantOwnershipBatchAsync(string username, IEnumerable<string> clientIds, string realm)
    {
        ThrowIfDisposed();
        ValidateUsernameRealmParameters(username, realm);
        ArgumentNullException.ThrowIfNull(clientIds);
        
        var clientIdsList = clientIds.ToList();
        if (clientIdsList.Count == 0)
        {
            _logger.LogWarning("Попытка массового предоставления владения с пустым списком клиентов для пользователя {Username}", username);
            return;
        }
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            var totalAffected = 0;
            var skipped = 0;
            
            // Обработка больших коллекций батчами
            for (int i = 0; i < clientIdsList.Count; i += BatchSize)
            {
                var batch = clientIdsList.Skip(i).Take(BatchSize).ToList();
                
                await using var connection = new SqliteConnection(_connectionString);
                await connection.OpenAsync().ConfigureAwait(false);
                
                await using var transaction = (Microsoft.Data.Sqlite.SqliteTransaction)await connection.BeginTransactionAsync().ConfigureAwait(false);
                
                try
                {
                    var command = connection.CreateCommand();
                    command.Transaction = transaction;
                    command.CommandTimeout = CommandTimeoutSeconds;
                    command.CommandText = @"
                        INSERT OR IGNORE INTO user_client_ownership (username, client_id, realm) 
                        VALUES (@username, @clientId, @realm)";
                    
                    command.Parameters.Add("@username", SqliteType.Text);
                    command.Parameters.Add("@clientId", SqliteType.Text);
                    command.Parameters.Add("@realm", SqliteType.Text);
                    
                    foreach (var clientId in batch)
                    {
                        ValidateStringParameter(clientId, nameof(clientIds), MaxClientIdLength, "ClientId");
                        
                        command.Parameters["@username"].Value = username;
                        command.Parameters["@clientId"].Value = clientId;
                        command.Parameters["@realm"].Value = realm;
                        
                        var rowsAffected = await command.ExecuteNonQueryAsync().ConfigureAwait(false);
                        if (rowsAffected > 0)
                        {
                            totalAffected++;
                        }
                        else
                        {
                            skipped++;
                        }
                    }
                    
                    await transaction.CommitAsync().ConfigureAwait(false);
                }
                catch
                {
                    await transaction.RollbackAsync().ConfigureAwait(false);
                    throw;
                }
            }
            
            _logger.LogInformation(
                "Массовое предоставление владения: добавлено {Added} клиентов, пропущено {Skipped} (уже существуют) для пользователя {Username} в реалме {Realm}",
                totalAffected, skipped, username, realm);
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка массового предоставления владения для пользователя {Username}", username);
            throw;
        }
    }
    
    /// <summary>
    /// Массовый отзыв владения
    /// </summary>
    public async Task RevokeOwnershipBatchAsync(string username, IEnumerable<string> clientIds, string realm)
    {
        ThrowIfDisposed();
        ValidateUsernameRealmParameters(username, realm);
        ArgumentNullException.ThrowIfNull(clientIds);
        
        var clientIdsList = clientIds.ToList();
        if (clientIdsList.Count == 0)
        {
            _logger.LogWarning("Попытка массового отзыва владения с пустым списком клиентов для пользователя {Username}", username);
            return;
        }
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            var totalDeleted = 0;
            
            // Обработка больших коллекций батчами
            for (int i = 0; i < clientIdsList.Count; i += BatchSize)
            {
                var batch = clientIdsList.Skip(i).Take(BatchSize).ToList();
                
                await using var connection = new SqliteConnection(_connectionString);
                await connection.OpenAsync().ConfigureAwait(false);
                
                await using var transaction = (Microsoft.Data.Sqlite.SqliteTransaction)await connection.BeginTransactionAsync().ConfigureAwait(false);
                
                try
                {
                    var command = connection.CreateCommand();
                    command.Transaction = transaction;
                    command.CommandTimeout = CommandTimeoutSeconds;
                    command.CommandText = @"
                        DELETE FROM user_client_ownership 
                        WHERE username = @username AND client_id = @clientId AND realm = @realm";
                    
                    command.Parameters.Add("@username", SqliteType.Text);
                    command.Parameters.Add("@clientId", SqliteType.Text);
                    command.Parameters.Add("@realm", SqliteType.Text);
                    
                    foreach (var clientId in batch)
                    {
                        ValidateStringParameter(clientId, nameof(clientIds), MaxClientIdLength, "ClientId");
                        
                        command.Parameters["@username"].Value = username;
                        command.Parameters["@clientId"].Value = clientId;
                        command.Parameters["@realm"].Value = realm;
                        
                        var rowsAffected = await command.ExecuteNonQueryAsync().ConfigureAwait(false);
                        if (rowsAffected > 0)
                        {
                            totalDeleted++;
                        }
                    }
                    
                    await transaction.CommitAsync().ConfigureAwait(false);
                }
                catch
                {
                    await transaction.RollbackAsync().ConfigureAwait(false);
                    throw;
                }
            }
            
            _logger.LogInformation(
                "Массовый отзыв владения: удалено {Deleted} клиентов для пользователя {Username} в реалме {Realm}",
                totalDeleted, username, realm);
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка массового отзыва владения для пользователя {Username}", username);
            throw;
        }
    }
    
    /// <summary>
    /// Освобождение ресурсов
    /// </summary>
    public void Dispose()
    {
        if (_disposed)
            return;
        
        _initSemaphore?.Dispose();
        _transferLock?.Dispose();
        _disposed = true;
    }
}
