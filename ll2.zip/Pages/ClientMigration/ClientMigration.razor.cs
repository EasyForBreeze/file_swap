using new_assistant.Core.DTOs;
using new_assistant.Core.Entities;
using new_assistant.Core.Interfaces;
using new_assistant.Controllers;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.JSInterop;

namespace new_assistant.Pages.ClientMigration;

/// <summary>
/// Code-behind для компонента ClientMigration
/// Содержит всю бизнес-логику для миграции клиентов
/// </summary>
public partial class ClientMigration : ComponentBase, IAsyncDisposable
{
    [Inject] private IKeycloakAdminService KeycloakService { get; set; } = null!;
    [Inject] private IClientMigrationService MigrationService { get; set; } = null!;
    [Inject] private IUserRoleService UserRoleService { get; set; } = null!;
    [Inject] private IKeycloakStageService StageKeycloakService { get; set; } = null!;
    [Inject] private IHttpContextAccessor HttpContextAccessor { get; set; } = null!;
    [Inject] private IJSRuntime JSRuntime { get; set; } = null!;
    [Inject] private NavigationManager NavigationManager { get; set; } = null!;
    [Inject] private ILogger<ClientMigration> Logger { get; set; } = null!;
    [Inject] private IKeycloakUrlBuilderService UrlBuilder { get; set; } = null!;
    
    private CancellationTokenSource? _cancellationTokenSource;

    // Состояние поиска клиентов
    private string searchQuery = string.Empty;
    private List<Controllers.ClientSearchResult> searchResults = new();
    private Controllers.ClientSearchResult? selectedClient = null;
    private bool isSearching = false;
    private bool hasSearched = false;

    // Состояние выбора целевого realm
    private List<string> stageRealms = new();
    private string selectedTargetRealm = string.Empty;
    private bool isLoadingStageRealms = false;
    private bool stageRealmsLoaded = false;

    // Состояние валидации
    private MigrationValidationResult? validationResult = null;
    private bool isValidating = false;

    // Дополнительная информация для миграции
    private string ticketNumber = string.Empty;
    private string notificationEmail = string.Empty;
    private string ticketUrl = string.Empty;
    private string _wikiPageUrl = string.Empty;

    // Состояние миграции
    private bool isMigrating = false;
    private ClientMigrationResult? migrationResult = null;
    private bool showMigrationResultModal = false;
    private bool isClosingModal = false;

    protected override async Task OnInitializedAsync()
    {
        // Загружаем реалмы STAGE один раз при инициализации страницы
        await LoadStageRealms();
    }

    private async Task SearchClients()
    {
        if (string.IsNullOrWhiteSpace(searchQuery) || searchQuery.Length < 2)
        {
            return;
        }

        isSearching = true;
        hasSearched = false;
        searchResults.Clear();
        selectedClient = null;
        validationResult = null;
        StateHasChanged();

        try
        {
            Logger.LogWarning("Поиск клиентов для миграции: {SearchQuery}", searchQuery);
            
            // Ищем во всех реалмах TEST
            var clients = await KeycloakService.SearchClientsByIdAsync(searchQuery, null);
            searchResults.AddRange(clients);

            Logger.LogWarning("Найдено клиентов для миграции: {Count}", searchResults.Count);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка поиска клиентов");
        }
        finally
        {
            isSearching = false;
            hasSearched = true;
            StateHasChanged();
        }
    }

    private Task OnSearchKeyDown(KeyboardEventArgs e)
    {
        if (e.Key == "Enter")
        {
            return SearchClients();
        }
        return Task.CompletedTask;
    }

    private Task SelectClient(Controllers.ClientSearchResult client)
    {
        selectedClient = client;
        selectedTargetRealm = string.Empty;
        validationResult = null;
        migrationResult = null;
        ticketNumber = string.Empty;
        notificationEmail = string.Empty;
        ticketUrl = string.Empty;
        _wikiPageUrl = string.Empty;
        
        // Если есть такой же realm в STAGE, выбираем его по умолчанию
        if (stageRealms.Contains(client.Realm))
        {
            selectedTargetRealm = client.Realm;
        }
        
        StateHasChanged();
        return Task.CompletedTask;
    }

    private async Task LoadStageRealms()
    {
        // Загружаем только один раз
        if (stageRealmsLoaded)
            return;

        isLoadingStageRealms = true;
        stageRealms.Clear();
        StateHasChanged();

        try
        {
            Logger.LogInformation("Загрузка реалмов STAGE (один раз при инициализации)");
            var realms = await StageKeycloakService.GetRealmsListAsync();
            stageRealms = realms
                .Where(r => r != "master")
                .ToList();
            
            stageRealmsLoaded = true;
            Logger.LogInformation("Загружено реалмов STAGE: {Count}", stageRealms.Count);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка загрузки реалмов STAGE");
        }
        finally
        {
            isLoadingStageRealms = false;
            StateHasChanged();
        }
    }

    private async Task ValidateMigration()
    {
        if (selectedClient == null || string.IsNullOrEmpty(selectedTargetRealm))
            return;

        isValidating = true;
        validationResult = null;
        StateHasChanged();

        try
        {
            Logger.LogWarning("Валидация миграции: {ClientId} из {Source} в {Target}", 
                selectedClient.ClientId, selectedClient.Realm, selectedTargetRealm);

            var sanitizedWikiUrl = string.IsNullOrWhiteSpace(_wikiPageUrl)
                ? null
                : _wikiPageUrl.Trim();
            _wikiPageUrl = sanitizedWikiUrl ?? string.Empty;

            var sanitizedTicketUrl = string.IsNullOrWhiteSpace(ticketUrl)
                ? null
                : ticketUrl.Trim();
            ticketUrl = sanitizedTicketUrl ?? string.Empty;

            var request = new ClientMigrationRequest
            {
                ClientId = selectedClient.ClientId,
                SourceRealm = selectedClient.Realm,
                TargetRealm = selectedTargetRealm,
                TicketNumber = ticketNumber,
                NotificationEmail = notificationEmail,
                WikiPageUrl = sanitizedWikiUrl,
                TicketUrl = sanitizedTicketUrl
            };

            // Используем сервис напрямую вместо HTTP запроса
            // Создаем CancellationTokenSource для возможности отмены операции
            _cancellationTokenSource ??= new CancellationTokenSource();
            var cancellationToken = _cancellationTokenSource.Token;
            
            validationResult = await MigrationService.ValidateMigrationAsync(request, cancellationToken);

            if (validationResult?.ExistingWikiPageUrl is { Length: > 0 } existingWiki && string.IsNullOrWhiteSpace(_wikiPageUrl))
            {
                _wikiPageUrl = string.IsNullOrWhiteSpace(existingWiki) ? string.Empty : existingWiki.Trim();
            }
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка валидации миграции");
            validationResult = new MigrationValidationResult
            {
                CanMigrate = false,
                Messages = new List<string> { $"Ошибка: {ex.Message}" }
            };
        }
        finally
        {
            isValidating = false;
            StateHasChanged();
            
            // Скроллим к результатам валидации после рендеринга
            await Task.Delay(300);
            await ScrollToValidationResults();
        }
    }
    
    private async Task ScrollToValidationResults()
    {
        try
        {
            await JSRuntime.InvokeVoidAsync("scrollToElementId", "validation-results", 100);
        }
        catch
        {
            try
            {
                await JSRuntime.InvokeVoidAsync("scrollToElement", "validation-results");
            }
            catch (Exception ex)
            {
                Logger.LogWarning(ex, "Не удалось выполнить скролл к результатам валидации");
            }
        }
    }

    private async Task MigrateClient()
    {
        if (selectedClient == null || string.IsNullOrEmpty(selectedTargetRealm) || validationResult?.CanMigrate != true)
            return;

        isMigrating = true;
        StateHasChanged();

        try
        {
            Logger.LogWarning("Начало миграции: {ClientId} из {Source} в {Target}", 
                selectedClient.ClientId, selectedClient.Realm, selectedTargetRealm);

            var sanitizedWikiUrlForMigration = string.IsNullOrWhiteSpace(_wikiPageUrl)
                ? null
                : _wikiPageUrl.Trim();
            _wikiPageUrl = sanitizedWikiUrlForMigration ?? string.Empty;

            var sanitizedTicketUrlForMigration = string.IsNullOrWhiteSpace(ticketUrl)
                ? null
                : ticketUrl.Trim();
            ticketUrl = sanitizedTicketUrlForMigration ?? string.Empty;

            var request = new ClientMigrationRequest
            {
                ClientId = selectedClient.ClientId,
                SourceRealm = selectedClient.Realm,
                TargetRealm = selectedTargetRealm,
                TicketNumber = ticketNumber,
                NotificationEmail = notificationEmail,
                WikiPageUrl = sanitizedWikiUrlForMigration,
                TicketUrl = sanitizedTicketUrlForMigration
            };

            var username = HttpContextAccessor.HttpContext?.User?.Identity?.Name ?? "Unknown";

            // Используем CancellationToken для возможности отмены операции
            _cancellationTokenSource ??= new CancellationTokenSource();
            var cancellationToken = _cancellationTokenSource.Token;
            
            migrationResult = await MigrationService.MigrateClientAsync(request, username, cancellationToken);
            showMigrationResultModal = true;
            try
            {
                await JSRuntime.InvokeVoidAsync("centerModalVertically", "client-migration-modal");
            }
            catch (Exception ex)
            {
                Logger.LogDebug(ex, "Не удалось позиционировать модальное окно");
            }
            if (migrationResult?.Success == true && !string.IsNullOrWhiteSpace(migrationResult.WikiPageUrl))
            {
                _wikiPageUrl = migrationResult.WikiPageUrl!.Trim();
            }
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Критическая ошибка миграции");
            migrationResult = new ClientMigrationResult
            {
                Success = false,
                Errors = new List<string> { $"Критическая ошибка: {ex.Message}" }
            };
            showMigrationResultModal = true;
        }
        finally
        {
            isMigrating = false;
            StateHasChanged();
        }
    }

    private async Task CloseMigrationResultModal()
    {
        isClosingModal = true;
        StateHasChanged();
        
        await Task.Delay(350);
        
        isClosingModal = false;
        showMigrationResultModal = false;
        
        if (migrationResult?.Success == true)
        {
            validationResult = null;
            ticketNumber = string.Empty;
            notificationEmail = string.Empty;
            ticketUrl = string.Empty;
            _wikiPageUrl = string.IsNullOrWhiteSpace(migrationResult.WikiPageUrl)
                ? _wikiPageUrl
                : migrationResult.WikiPageUrl!.Trim();
        }
        
        StateHasChanged();
    }

    private async Task CopyToClipboard(string text)
    {
        try
        {
            await JSRuntime.InvokeVoidAsync("navigator.clipboard.writeText", text);
            Logger.LogInformation("Скопировано в буфер обмена");
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка копирования в буфер обмена");
        }
    }

    private async Task CopyMigrationSummaryToClipboard()
    {
        var summary = BuildMigrationSummaryText();
        await CopyToClipboard(summary);
    }

    private string BuildMigrationSummaryText()
    {
        var baseUrl = GetStageBaseUrl();
        var realm = string.IsNullOrWhiteSpace(selectedTargetRealm) ? "N/A" : selectedTargetRealm;
        var clientId = migrationResult?.ClientId ?? selectedClient?.ClientId ?? "N/A";
        var wiki = string.IsNullOrWhiteSpace(migrationResult?.WikiPageUrl) ? "Не указана" : migrationResult!.WikiPageUrl!;
        var endpoints = GetStageEndpointsUrl();

        var builder = new System.Text.StringBuilder();
        builder.AppendLine("Создана конфигурация в STAGE среде");
        builder.AppendLine($"Base URL: {baseUrl}");
        builder.AppendLine($"Realm: {realm}");
        builder.AppendLine($"ClientID: {clientId}");
        builder.AppendLine("Secret: в архиве, пароль от архива выслан на почту");
        builder.AppendLine($"Ссылка на конфигурацию в реестре: {wiki}");
        builder.AppendLine($"Endpoints: {endpoints}");

        return builder.ToString();
    }

    private async Task DownloadCredentials()
    {
        if (string.IsNullOrEmpty(migrationResult?.ClientId))
            return;

        var downloadUrl = $"/api/client/download-archive?clientId={Uri.EscapeDataString(migrationResult.ClientId)}";
        await JSRuntime.InvokeVoidAsync("open", downloadUrl, "_blank");
        Logger.LogWarning("Скачивание credentials для {ClientId}", migrationResult.ClientId);
    }

    private string GetStageBaseUrl()
    {
        if (string.IsNullOrEmpty(selectedTargetRealm))
            return "N/A";

        try
        {
            return UrlBuilder.GetStageRealmUrl(selectedTargetRealm);
        }
        catch
        {
            return "N/A";
        }
    }

    private string GetStageEndpointsUrl()
    {
        if (string.IsNullOrEmpty(selectedTargetRealm))
            return "N/A";

        try
        {
            return UrlBuilder.GetStageEndpointsUrl(selectedTargetRealm);
        }
        catch
        {
            return "N/A";
        }
    }
    
    /// <summary>
    /// Освобождение ресурсов при размонтировании компонента
    /// </summary>
    public async ValueTask DisposeAsync()
    {
        if (_cancellationTokenSource != null)
        {
            _cancellationTokenSource.Cancel();
            _cancellationTokenSource.Dispose();
            _cancellationTokenSource = null;
        }
        await ValueTask.CompletedTask;
    }
}

