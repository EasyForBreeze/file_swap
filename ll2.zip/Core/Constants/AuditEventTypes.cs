namespace new_assistant.Core.Constants;

/// <summary>
/// Константы типов событий аудита
/// </summary>
public static class AuditEventTypes
{
    public const string ClientCreated = "ClientCreated";
    public const string ClientUpdated = "ClientUpdated";
    public const string ClientDeleted = "ClientDeleted";
    public const string AccessGranted = "AccessGranted";
    public const string AccessRevoked = "AccessRevoked";
    public const string RoleAdded = "RoleAdded";
    public const string RoleRemoved = "RoleRemoved";
    public const string SecretRegenerated = "SecretRegenerated";
    public const string UserLogin = "UserLogin";
    public const string ForbiddenClientAdded = "ForbiddenClientAdded";
    public const string ForbiddenClientRemoved = "ForbiddenClientRemoved";
    public const string ClientMigrated = "ClientMigrated";
    public const string EmailSent = "EmailSent";
    public const string UserInfoUpdated = "UserInfoUpdated";
    public const string UserRealmRoleAdded = "UserRealmRoleAdded";
    public const string UserRealmRoleRemoved = "UserRealmRoleRemoved";
    public const string UserClientRoleAdded = "UserClientRoleAdded";
    public const string UserClientRoleRemoved = "UserClientRoleRemoved";
    public const string UserPasswordUpdate = "UserPasswordUpdate";
    public const string UserOtpConfigured = "UserOtpConfigured";
    public const string UserBlocked = "UserBlocked";
    public const string UserUnblocked = "UserUnblocked";
    public const string UserCertificateAdded = "UserCertificateAdded";
    public const string UserCertificateDeleted = "UserCertificateDeleted";
}

