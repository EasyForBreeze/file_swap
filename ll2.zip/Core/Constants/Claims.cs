namespace new_assistant.Core.Constants;

/// <summary>
/// Константы для названий claims
/// </summary>
public static class Claims
{
    /// <summary>
    /// Claim для ролей пользователя
    /// </summary>
    public const string Role = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
    
    /// <summary>
    /// Claim для subject (ID пользователя)
    /// </summary>
    public const string Subject = "sub";
    
    /// <summary>
    /// Claim для имени пользователя
    /// </summary>
    public const string Name = "preferred_username";
    
    /// <summary>
    /// Claim для доступных realm ролей с правами чтения/записи
    /// </summary>
    public const string AvailableRealmRolesRW = "availableRealmRolesRW";
    
    /// <summary>
    /// Claim для доступных realm ролей только для чтения
    /// </summary>
    public const string AvailableRealmRolesRO = "availableRealmRolesRO";
    
    /// <summary>
    /// Claim для доступных client ролей с правами чтения/записи
    /// </summary>
    public const string AvailableClientRolesRW = "availableClientRolesRW";
    
    /// <summary>
    /// Claim для доступных client ролей только для чтения
    /// </summary>
    public const string AvailableClientRolesRO = "availableClientRolesRO";
    
    /// <summary>
    /// Claim для доступа к ресурсу users-management-api
    /// </summary>
    public const string UsersManagementApiResourceAccess = "resource_access.users-management-api.roles";
    
    /// <summary>
    /// Название клиента users-management-api
    /// </summary>
    public const string UsersManagementApiClient = "users-management-api";
}

/// <summary>
/// Константы для SQL запросов (если используются)
/// </summary>
public static class SqlQueries
{
    // SQL запросы можно добавить сюда, если используются напрямую
}

