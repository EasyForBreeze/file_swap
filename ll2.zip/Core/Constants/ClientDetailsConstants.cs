namespace new_assistant.Core.Constants;

/// <summary>
/// Константы для страницы ClientDetails
/// </summary>
public static class ClientDetailsConstants
{
    /// <summary>
    /// Названия вкладок
    /// </summary>
    public static class Tabs
    {
        public const string Settings = "settings";
        public const string Credentials = "credentials";
        public const string Roles = "roles";
        public const string Endpoints = "endpoints";
        public const string Evaluate = "evaluate";
        public const string Events = "events";
    }

    /// <summary>
    /// Типы токенов для генерации
    /// </summary>
    public static class TokenTypes
    {
        public const string Access = "access";
        public const string Id = "id";
        public const string UserInfo = "userinfo";
    }

    /// <summary>
    /// Значения фильтров событий
    /// </summary>
    public static class EventFilters
    {
        public const string All = "all";
    }
}

