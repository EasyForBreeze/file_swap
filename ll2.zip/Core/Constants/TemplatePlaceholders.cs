namespace new_assistant.Core.Constants;

/// <summary>
/// Константы плейсхолдеров шаблона Confluence
/// </summary>
public static class TemplatePlaceholders
{
    /// <summary>
    /// {{CLIENT_ID}} - Идентификатор клиента Keycloak (обязательный)
    /// Формат: строка, экранируется HTML
    /// Пример: "my-client-id"
    /// </summary>
    public const string ClientId = "{{CLIENT_ID}}";
    
    /// <summary>
    /// {{CLIENT_NAME}} - Отображаемое имя клиента (обязательный)
    /// Формат: строка, экранируется HTML, fallback на CLIENT_ID если не указано
    /// Пример: "My Client Application"
    /// </summary>
    public const string ClientName = "{{CLIENT_NAME}}";
    
    /// <summary>
    /// {{REALM_CELL}} - Ячейка таблицы с информацией о Realm
    /// Формат: HTML ячейка таблицы &lt;td&gt;Realm Name&lt;/td&gt;
    /// Пример: "&lt;td&gt;my-realm&lt;/td&gt;"
    /// </summary>
    public const string RealmCell = "{{REALM_CELL}}";
    
    /// <summary>
    /// {{INFO_SYSTEM_CELL}} - Ячейка таблицы с информацией об информационной системе
    /// Формат: HTML ячейка таблицы, может содержать ссылку
    /// Пример: "&lt;td&gt;&lt;a href="url"&gt;System Name&lt;/a&gt;&lt;/td&gt;"
    /// </summary>
    public const string InfoSystemCell = "{{INFO_SYSTEM_CELL}}";
    
    /// <summary>
    /// {{ACCESS_TYPE}} - Тип доступа (обязательный)
    /// Формат: строка "confidential" или "public"
    /// Значения: "confidential" (для клиентов с секретом), "public" (для публичных клиентов)
    /// </summary>
    public const string AccessType = "{{ACCESS_TYPE}}";
    
    /// <summary>
    /// {{CLIENT_STATUS}} - Статус клиента (обязательный)
    /// Формат: HTML span с цветом, "On" или "Off"
    /// Пример: "&lt;span style="color:..."&gt;On&lt;/span&gt;"
    /// </summary>
    public const string ClientStatus = "{{CLIENT_STATUS}}";
    
    /// <summary>
    /// {{DESCRIPTION}} - Описание клиента
    /// Формат: строка, экранируется HTML
    /// Пример: "Описание клиента для интеграции"
    /// </summary>
    public const string Description = "{{DESCRIPTION}}";
    
    /// <summary>
    /// {{STANDARD_FLOW}} - Стандартный flow (обязательный)
    /// Формат: HTML span с цветом, "On" или "Off"
    /// Определяет, включен ли стандартный OAuth 2.0 Authorization Code Flow
    /// </summary>
    public const string StandardFlow = "{{STANDARD_FLOW}}";
    
    /// <summary>
    /// {{DIRECT_ACCESS_GRANTS}} - Direct Access Grants (обязательный)
    /// Формат: HTML span с цветом, "On" или "Off"
    /// Определяет, разрешена ли авторизация по паролю (Resource Owner Password Credentials)
    /// </summary>
    public const string DirectAccessGrants = "{{DIRECT_ACCESS_GRANTS}}";
    
    /// <summary>
    /// {{SERVICE_ACCOUNTS}} - Service Accounts (обязательный)
    /// Формат: HTML span с цветом, "On" или "Off"
    /// Определяет, включены ли Service Accounts для клиента
    /// </summary>
    public const string ServiceAccounts = "{{SERVICE_ACCOUNTS}}";
    
    /// <summary>
    /// {{DEVICE_AUTHORIZATION}} - OAuth 2.0 Device Authorization Grant (обязательный)
    /// Формат: HTML span с цветом, "On" или "Off"
    /// Определяет, включен ли Device Authorization Grant flow
    /// </summary>
    public const string DeviceAuthorization = "{{DEVICE_AUTHORIZATION}}";
    
    /// <summary>
    /// {{CLIENT_SCOPES}} - Client Scopes (обязательный)
    /// Формат: HTML div с параграфами Default и Optional scopes
    /// Пример: "&lt;div&gt;&lt;p&gt;&lt;strong&gt;Default:&lt;/strong&gt; scope1, scope2&lt;/p&gt;&lt;/div&gt;"
    /// </summary>
    public const string ClientScopes = "{{CLIENT_SCOPES}}";
    
    /// <summary>
    /// {{REDIRECT_TABLE}} - Таблица Valid Redirect URIs (обязательный)
    /// Формат: HTML таблица с колонками TEST, STAGE, PROD
    /// Содержит список разрешенных redirect URIs для каждого контура
    /// </summary>
    public const string RedirectTable = "{{REDIRECT_TABLE}}";
    
    /// <summary>
    /// {{LOCAL_ROLES_TABLE}} - Таблица локальных ролей клиента (обязательный)
    /// Формат: HTML таблица с колонками Название, Описание, Контур
    /// Содержит список локальных ролей клиента с указанием контура (TEST/STAGE/PROD)
    /// </summary>
    public const string LocalRolesTable = "{{LOCAL_ROLES_TABLE}}";
    
    /// <summary>
    /// {{SERVICE_ROLES_TABLE}} - Таблица Service Account ролей (обязательный)
    /// Формат: HTML таблица с колонками Название, ClientID, Контур
    /// Содержит список ролей, назначенных Service Account клиента
    /// </summary>
    public const string ServiceRolesTable = "{{SERVICE_ROLES_TABLE}}";
    
    /// <summary>
    /// {{PUBLICATION_STATUS}} - Статус публикации (обязательный)
    /// Формат: строка, экранируется HTML
    /// Значения: "TEST", "STAGE", "PROD"
    /// Определяет, в каком контуре опубликован клиент
    /// </summary>
    public const string PublicationStatus = "{{PUBLICATION_STATUS}}";
    
    /// <summary>
    /// {{TICKET_FTEST}} - Заявка FTEST
    /// Формат: HTML, может содержать ссылку на заявку
    /// Пример: "&lt;strong&gt;&lt;a href="url"&gt;TICKET-123&lt;/a&gt;&lt;/strong&gt;"
    /// </summary>
    public const string TicketFtest = "{{TICKET_FTEST}}";
    
    /// <summary>
    /// {{TICKET_PREPROD}} - Заявка PrePROD
    /// Формат: HTML, может содержать ссылку на заявку
    /// Пример: "&lt;strong&gt;&lt;a href="url"&gt;TICKET-456&lt;/a&gt;&lt;/strong&gt;"
    /// </summary>
    public const string TicketPreprod = "{{TICKET_PREPROD}}";
    
    /// <summary>
    /// {{TICKET_PROD}} - Заявка PROD
    /// Формат: HTML, может содержать ссылку на заявку
    /// Пример: "&lt;strong&gt;&lt;a href="url"&gt;TICKET-789&lt;/a&gt;&lt;/strong&gt;"
    /// </summary>
    public const string TicketProd = "{{TICKET_PROD}}";
    
    /// <summary>
    /// {{SERVICE_OWNER_CELL}} - Ячейка таблицы с бизнес владельцем
    /// Формат: HTML ячейка таблицы &lt;td&gt;Owner Name&lt;/td&gt;
    /// Пример: "&lt;td&gt;Иван Иванов&lt;/td&gt;"
    /// </summary>
    public const string ServiceOwnerCell = "{{SERVICE_OWNER_CELL}}";
    
    /// <summary>
    /// {{SERVICE_MANAGER_CELL}} - Ячейка таблицы с менеджером поддержки
    /// Формат: HTML ячейка таблицы &lt;td&gt;Manager Name&lt;/td&gt;
    /// Пример: "&lt;td&gt;Петр Петров&lt;/td&gt;"
    /// </summary>
    public const string ServiceManagerCell = "{{SERVICE_MANAGER_CELL}}";

    /// <summary>
    /// Все обязательные плейсхолдеры, которые должны присутствовать в шаблоне
    /// </summary>
    public static readonly HashSet<string> Required = new()
    {
        ClientId, ClientName, RealmCell, InfoSystemCell, AccessType,
        ClientStatus, Description, StandardFlow, DirectAccessGrants,
        ServiceAccounts, DeviceAuthorization, ClientScopes, RedirectTable,
        LocalRolesTable, ServiceRolesTable, PublicationStatus, TicketFtest,
        TicketPreprod, TicketProd, ServiceOwnerCell, ServiceManagerCell
    };
}

