using System;
using System.Collections.Generic;
using System.Security.Claims;

namespace new_assistant.Core.Models;

public class TokenExchangeResult
{
    public string AccessToken { get; set; } = string.Empty;
    public string? RefreshToken { get; set; }
    public DateTime ExpiresAtUtc { get; set; }
    public IReadOnlyCollection<Claim> Claims { get; set; } = Array.Empty<Claim>();
}

