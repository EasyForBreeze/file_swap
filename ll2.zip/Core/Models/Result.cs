namespace new_assistant.Core.Models;

/// <summary>
/// Результат операции с явной обработкой ошибок (Result pattern)
/// </summary>
/// <typeparam name="T">Тип возвращаемого значения</typeparam>
public class Result<T>
{
    /// <summary>
    /// Успешно ли выполнена операция
    /// </summary>
    public bool IsSuccess { get; private set; }

    /// <summary>
    /// Значение результата (доступно только при IsSuccess = true)
    /// </summary>
    public T? Value { get; private set; }

    /// <summary>
    /// Сообщение об ошибке (доступно только при IsSuccess = false)
    /// </summary>
    public string? ErrorMessage { get; private set; }

    /// <summary>
    /// Исключение, если оно было поймано
    /// </summary>
    public Exception? Exception { get; private set; }

    /// <summary>
    /// HTTP статус код, если ошибка связана с HTTP запросом
    /// </summary>
    public System.Net.HttpStatusCode? StatusCode { get; private set; }

    private Result(bool isSuccess, T? value, string? errorMessage, Exception? exception, System.Net.HttpStatusCode? statusCode)
    {
        IsSuccess = isSuccess;
        Value = value;
        ErrorMessage = errorMessage;
        Exception = exception;
        StatusCode = statusCode;
    }

    /// <summary>
    /// Создать успешный результат
    /// </summary>
    public static Result<T> Success(T value)
    {
        return new Result<T>(true, value, null, null, null);
    }

    /// <summary>
    /// Создать результат с ошибкой
    /// </summary>
    public static Result<T> Failure(string errorMessage, Exception? exception = null, System.Net.HttpStatusCode? statusCode = null)
    {
        return new Result<T>(false, default, errorMessage, exception, statusCode);
    }

    /// <summary>
    /// Создать результат с ошибкой из HTTP ответа
    /// </summary>
    public static Result<T> FromHttpError(System.Net.HttpStatusCode statusCode, string errorMessage)
    {
        return new Result<T>(false, default, errorMessage, null, statusCode);
    }

    /// <summary>
    /// Неявное преобразование в bool для удобства проверки
    /// </summary>
    public static implicit operator bool(Result<T> result) => result.IsSuccess;

    /// <summary>
    /// Неявное преобразование в T? для удобства доступа к значению
    /// </summary>
    public static implicit operator T?(Result<T> result) => result.Value;
}

/// <summary>
/// Результат операции без возвращаемого значения
/// </summary>
public class Result
{
    /// <summary>
    /// Успешно ли выполнена операция
    /// </summary>
    public bool IsSuccess { get; private set; }

    /// <summary>
    /// Сообщение об ошибке (доступно только при IsSuccess = false)
    /// </summary>
    public string? ErrorMessage { get; private set; }

    /// <summary>
    /// Исключение, если оно было поймано
    /// </summary>
    public Exception? Exception { get; private set; }

    /// <summary>
    /// HTTP статус код, если ошибка связана с HTTP запросом
    /// </summary>
    public System.Net.HttpStatusCode? StatusCode { get; private set; }

    private Result(bool isSuccess, string? errorMessage, Exception? exception, System.Net.HttpStatusCode? statusCode)
    {
        IsSuccess = isSuccess;
        ErrorMessage = errorMessage;
        Exception = exception;
        StatusCode = statusCode;
    }

    /// <summary>
    /// Создать успешный результат
    /// </summary>
    public static Result Success()
    {
        return new Result(true, null, null, null);
    }

    /// <summary>
    /// Создать результат с ошибкой
    /// </summary>
    public static Result Failure(string errorMessage, Exception? exception = null, System.Net.HttpStatusCode? statusCode = null)
    {
        return new Result(false, errorMessage, exception, statusCode);
    }

    /// <summary>
    /// Создать результат с ошибкой из HTTP ответа
    /// </summary>
    public static Result FromHttpError(System.Net.HttpStatusCode statusCode, string errorMessage)
    {
        return new Result(false, errorMessage, null, statusCode);
    }

    /// <summary>
    /// Неявное преобразование в bool для удобства проверки
    /// </summary>
    public static implicit operator bool(Result result) => result.IsSuccess;
}

