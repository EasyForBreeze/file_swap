namespace new_assistant.Core.DTOs;

/// <summary>
/// Статистика использования кеша токенов.
/// </summary>
public class TokenCacheStatistics
{
    /// <summary>
    /// Количество попаданий в кеш (токен был найден в кеше и использован).
    /// </summary>
    public long CacheHits { get; set; }
    
    /// <summary>
    /// Количество промахов кеша (токен не был найден в кеше и был запрошен заново).
    /// </summary>
    public long CacheMisses { get; set; }
    
    /// <summary>
    /// Общее количество попыток получения токена.
    /// </summary>
    public long TotalRequests => CacheHits + CacheMisses;
    
    /// <summary>
    /// Процент попаданий в кеш (0-100).
    /// </summary>
    public double CacheHitRate => TotalRequests > 0 ? (double)CacheHits / TotalRequests * 100 : 0;
}

