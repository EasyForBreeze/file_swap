namespace new_assistant.Core.DTOs;

/// <summary>
/// Полезная нагрузка шаблона Confluence
/// </summary>
public sealed record TemplatePayload
{
    /// <summary>
    /// Время загрузки шаблона в приложение
    /// </summary>
    public DateTime LoadedAt { get; init; } = DateTime.UtcNow;
    
    /// <summary>
    /// Дата последнего обновления шаблона (извлекается из комментария в шаблоне)
    /// </summary>
    public DateTime? LastUpdated { get; init; }
    
    /// <summary>
    /// Заголовок шаблона (формат для string.Format)
    /// </summary>
    public string Title
    {
        get => _title;
        init => _title = string.IsNullOrWhiteSpace(value)
            ? throw new ArgumentException("Title cannot be null or empty", nameof(Title))
            : value;
    }

    /// <summary>
    /// Тело шаблона (HTML с плейсхолдерами)
    /// </summary>
    public string Body
    {
        get => _body;
        init => _body = string.IsNullOrWhiteSpace(value)
            ? throw new ArgumentException("Body cannot be null or empty", nameof(Body))
            : value;
    }
    
    /// <summary>
    /// Версия шаблона
    /// </summary>
    public string Version { get; init; } = "1.0";

    private readonly string _title = string.Empty;
    private readonly string _body = string.Empty;
    
    /// <summary>
    /// Конструктор для инициализации шаблона
    /// </summary>
    public TemplatePayload(string title, string body, string version = "1.0")
    {
        Title = title;
        Body = body;
        Version = version;
    }
}

