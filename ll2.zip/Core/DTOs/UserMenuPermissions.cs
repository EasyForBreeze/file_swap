namespace new_assistant.Core.DTOs;

/// <summary>
/// Разрешения пользователя для отображения пунктов меню
/// </summary>
public class UserMenuPermissions
{
    /// <summary>
    /// Блокировка/разблокировка пользователя
    /// Требуется: kc-ga-users-management-api.block.user ИЛИ kc-ga-users-management-api.unblock.user
    /// </summary>
    public bool CanBlockUnblockUser { get; set; }
    
    /// <summary>
    /// Роли клиента/реалма
    /// Требуется: kc-ga-users-management-api.add.realm.roles.to.user ИЛИ
    ///            kc-ga-users-management-api.add.client.roles.to.user ИЛИ
    ///            kc-ga-users-management-api.delete.realm.roles.from.user ИЛИ
    ///            kc-ga-users-management-api.delete.client.roles.from.user
    /// </summary>
    public bool CanManageUserRoles { get; set; }
    
    /// <summary>
    /// Добавление пользователя
    /// Требуется: kc-ga-users-management-api.add.user
    /// </summary>
    public bool CanAddUser { get; set; }
    
    /// <summary>
    /// Сертификат пользователя
    /// Требуется: kc-ga-users-management-api.get.user.certificate ИЛИ
    ///            kc-ga-users-management-api.add.user.certificate
    /// </summary>
    public bool CanManageUserCertificate { get; set; }
    
    /// <summary>
    /// Обновление информации пользователя
    /// Требуется: kc-ga-users-management-api.update.user
    /// </summary>
    public bool CanUpdateUser { get; set; }
    
    /// <summary>
    /// Информация о пользователе
    /// Требуется: kc-ga-users-management-api.get.user
    /// </summary>
    public bool CanGetUserInfo { get; set; }
    
    /// <summary>
    /// Поиск пользователей
    /// Требуется: kc-ga-users-management-api.search.users
    /// </summary>
    public bool CanSearchUsers { get; set; }
    
    /// <summary>
    /// Сброс пароля пользователю
    /// Требуется: kc-ga-users-management-api.send.mail.to.user И
    ///            kc-ga-users-management-api.delete.user.credentials
    /// </summary>
    public bool CanResetUserPassword { get; set; }
    
    /// <summary>
    /// Список реалмов, в которых пользователь имеет роли
    /// </summary>
    public List<string> AvailableRealms { get; set; } = new();
    
    /// <summary>
    /// Все роли пользователя с указанием реалмов
    /// </summary>
    public List<UserRoleInfo> UserRoles { get; set; } = new();
}

