namespace new_assistant.Core.DTOs;

/// <summary>
/// Результат создания клиента с дополнительной информацией для администратора
/// </summary>
public class ClientCreationResultDto
{
    /// <summary>
    /// Client ID созданного клиента
    /// </summary>
    public string ClientId { get; set; } = string.Empty;

    /// <summary>
    /// Realm в котором создан клиент
    /// </summary>
    public string Realm { get; set; } = string.Empty;

    /// <summary>
    /// Client Secret созданного клиента
    /// </summary>
    public string ClientSecret { get; set; } = string.Empty;

    /// <summary>
    /// Базовый URL Keycloak
    /// </summary>
    public string BaseUrl { get; set; } = string.Empty;

    /// <summary>
    /// Название окружения (TEST, PROD и т.д.)
    /// </summary>
    public string Environment { get; set; } = string.Empty;

    /// <summary>
    /// URL страницы в Confluence Wiki
    /// </summary>
    public string? WikiPageUrl { get; set; }

    /// <summary>
    /// URL конфигурации OpenID Connect (.well-known endpoint)
    /// </summary>
    public string WellKnownEndpoint { get; set; } = string.Empty;

    /// <summary>
    /// Пароль от архива (для отображения в UI)
    /// </summary>
    public string? ArchivePassword { get; set; }

    /// <summary>
    /// Путь к архиву для скачивания
    /// </summary>
    public string? ArchivePath { get; set; }

    /// <summary>
    /// Сообщение об ошибке (если создание не удалось)
    /// </summary>
    public string? ErrorMessage { get; set; }
}

