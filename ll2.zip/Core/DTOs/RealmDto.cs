namespace new_assistant.Core.DTOs;

/// <summary>
/// Информация о реалме Keycloak
/// </summary>
public class RealmDto
{
    /// <summary>
    /// Уникальный идентификатор реалма
    /// </summary>
    public string Realm { get; set; } = string.Empty;
    
    /// <summary>
    /// Отображаемое имя реалма (Display Name)
    /// </summary>
    public string? DisplayName { get; set; }
    
    /// <summary>
    /// Включен ли реалм
    /// </summary>
    public bool Enabled { get; set; } = true;
}

