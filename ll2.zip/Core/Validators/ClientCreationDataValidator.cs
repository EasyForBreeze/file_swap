using FluentValidation;
using new_assistant.Core.DTOs;

namespace new_assistant.Core.Validators;

/// <summary>
/// Валидатор для данных создания клиента
/// </summary>
public class ClientCreationDataValidator : AbstractValidator<ClientCreationData>
{
    public ClientCreationDataValidator()
    {
        RuleFor(x => x.Realm)
            .NotEmpty().WithMessage("Realm обязателен");

        RuleFor(x => x.ClientId)
            .NotEmpty().WithMessage("Client ID обязателен")
            .Matches(@"^app-[a-z0-9-]+$")
            .WithMessage("Client ID должен начинаться с 'app-' и содержать только буквы, цифры и дефисы")
            .MaximumLength(255).WithMessage("Client ID не должен превышать 255 символов");

        RuleFor(x => x.Name)
            .NotEmpty().WithMessage("Название обязательно")
            .MaximumLength(200).WithMessage("Название не должно превышать 200 символов");

        RuleFor(x => x.Description)
            .MaximumLength(500).WithMessage("Описание не должно превышать 500 символов");

        RuleFor(x => x.OwnerSystemName)
            .NotEmpty().WithMessage("Название системы-владельца обязательно")
            .MaximumLength(200).WithMessage("Название системы не должно превышать 200 символов");

        RuleFor(x => x.OwnerSystemUrl)
            .NotEmpty().WithMessage("URL системы-владельца обязателен")
            .Must(BeValidUrl).WithMessage("URL системы должен быть валидным")
            .When(x => !string.IsNullOrWhiteSpace(x.OwnerSystemUrl));

        RuleFor(x => x.OwnerName)
            .NotEmpty().WithMessage("Имя владельца обязательно")
            .MaximumLength(100).WithMessage("Имя владельца не должно превышать 100 символов");

        RuleFor(x => x.SupportManager)
            .MaximumLength(100).WithMessage("Имя менеджера поддержки не должно превышать 100 символов");

        RuleForEach(x => x.RedirectUris)
            .Must(BeValidUrl).WithMessage("Все Redirect URIs должны быть валидными URL")
            .When(x => x.RedirectUris != null && x.RedirectUris.Any());

        RuleFor(x => x.RedirectUris)
            .Must(list => list == null || list.Count <= 50)
            .WithMessage("Максимум 50 Redirect URIs");

        RuleFor(x => x.LocalRoles)
            .Must(list => list == null || list.Count <= 100)
            .WithMessage("Максимум 100 локальных ролей");

        RuleFor(x => x.NotificationEmail)
            .EmailAddress().When(x => !string.IsNullOrWhiteSpace(x.NotificationEmail))
            .WithMessage("Email уведомлений должен быть валидным");

        RuleFor(x => x.TicketNumber)
            .MaximumLength(50).When(x => !string.IsNullOrWhiteSpace(x.TicketNumber))
            .WithMessage("Номер тикета не должен превышать 50 символов");

        RuleFor(x => x.TicketUrl)
            .Must(BeValidUrl)
            .WithMessage("Ссылка на заявку должна быть валидным URL")
            .When(x => !string.IsNullOrWhiteSpace(x.TicketUrl));
    }

    private bool BeValidUrl(string? url)
    {
        if (string.IsNullOrWhiteSpace(url))
            return false;

        return Uri.TryCreate(url, UriKind.Absolute, out var uri) &&
               (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps);
    }
}

