namespace new_assistant.Core.Extensions;

/// <summary>
/// Extension-методы для работы с коллекциями
/// </summary>
public static class CollectionExtensions
{
    /// <summary>
    /// Проверяет, является ли коллекция null или пустой
    /// </summary>
    public static bool IsNullOrEmpty<T>(this IEnumerable<T>? source) => 
        source == null || !source.Any();
    
    /// <summary>
    /// Проверяет, является ли коллекция не null и не пустой
    /// </summary>
    public static bool IsNotNullOrEmpty<T>(this IEnumerable<T>? source) => 
        source != null && source.Any();
}

