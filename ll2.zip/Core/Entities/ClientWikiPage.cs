using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace new_assistant.Core.Entities;

/// <summary>
/// Связь между клиентом Keycloak и страницей Confluence Wiki
/// </summary>
[Table("client_wiki_pages")]
public sealed class ClientWikiPage
{
    /// <summary>
    /// Уникальный идентификатор записи
    /// </summary>
    [Key]
    [Column("id")]
    public int Id { get; set; }

    /// <summary>
    /// Client ID из Keycloak
    /// </summary>
    [Required]
    [Column("client_id")]
    [MaxLength(255)]
    public string ClientId { get; set; } = string.Empty;

    /// <summary>
    /// Realm клиента
    /// </summary>
    [Required]
    [Column("realm")]
    [MaxLength(255)]
    public string Realm { get; set; } = "GLOBAL";

    /// <summary>
    /// ID страницы в Confluence
    /// </summary>
    [Required]
    [Column("wiki_page_id")]
    [MaxLength(50)]
    public string WikiPageId { get; set; } = string.Empty;

    /// <summary>
    /// Название страницы в Confluence
    /// </summary>
    [Column("wiki_page_title")]
    [MaxLength(500)]
    public string WikiPageTitle { get; set; } = string.Empty;

    /// <summary>
    /// URL страницы в Confluence
    /// </summary>
    [Column("wiki_page_url")]
    [MaxLength(1000)]
    public string WikiPageUrl { get; set; } = string.Empty;

    /// <summary>
    /// Статус страницы (Active, Archived, Failed)
    /// </summary>
    [Column("status")]
    [MaxLength(50)]
    public string Status { get; set; } = "Active";

    /// <summary>
    /// Дата создания записи
    /// </summary>
    [Column("created_at")]
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>
    /// Дата последнего обновления
    /// </summary>
    [Column("updated_at")]
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>
    /// Кто создал страницу
    /// </summary>
    [Column("created_by")]
    [MaxLength(255)]
    public string CreatedBy { get; set; } = string.Empty;

    /// <summary>
    /// Номер версии страницы в Confluence (для оптимистичной блокировки)
    /// </summary>
    [Column("page_version")]
    public int PageVersion { get; set; } = 1;
}

