using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс сервиса для валидации миграции клиентов
/// </summary>
public interface IClientMigrationValidationService
{
    /// <summary>
    /// Валидировать возможность переноса клиента
    /// </summary>
    Task<MigrationValidationResult> ValidateMigrationAsync(
        ClientMigrationRequest request, 
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Валидация длины строковых полей запроса
    /// </summary>
    void ValidateRequestLengths(ClientMigrationRequest request);
    
    /// <summary>
    /// Проверка валидности email адреса
    /// </summary>
    bool IsValidEmail(string email);
}

