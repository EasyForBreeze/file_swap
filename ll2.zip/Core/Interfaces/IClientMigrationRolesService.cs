namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс сервиса для работы с ролями при миграции клиентов
/// </summary>
public interface IClientMigrationRolesService
{
    /// <summary>
    /// Создать локальные роли клиента
    /// </summary>
    Task<int> CreateLocalRolesAsync(
        string internalId,
        IEnumerable<string> roles,
        string targetRealm,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Назначить realm roles для service account
    /// </summary>
    Task<int> AssignRealmRolesToServiceAccountAsync(
        string internalId,
        IEnumerable<string> realmRoles,
        string targetRealm,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Назначить client roles для service account
    /// </summary>
    Task<int> AssignClientRolesToServiceAccountAsync(
        string internalId,
        Dictionary<string, List<string>> clientRolesByClient,
        string targetRealm,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Назначить client scopes клиенту
    /// </summary>
    Task AssignClientScopesAsync(
        string internalId,
        IEnumerable<string> defaultScopes,
        IEnumerable<string> optionalScopes,
        string targetRealm,
        CancellationToken cancellationToken = default);
}

