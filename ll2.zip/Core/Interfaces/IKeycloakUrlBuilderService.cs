namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс сервиса для формирования URL для Keycloak
/// </summary>
public interface IKeycloakUrlBuilderService
{
    /// <summary>
    /// Получить базовый URL для STAGE окружения
    /// </summary>
    string GetStageBaseUrl();
    
    /// <summary>
    /// Получить URL для realm в STAGE окружении
    /// </summary>
    string GetStageRealmUrl(string realm);
    
    /// <summary>
    /// Получить URL для endpoints в STAGE окружении
    /// </summary>
    string GetStageEndpointsUrl(string realm);
}

