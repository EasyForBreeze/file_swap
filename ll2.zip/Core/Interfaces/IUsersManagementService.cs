using System.IO;
using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Сервис для работы с users-management API
/// </summary>
public interface IUsersManagementService
{
    /// <summary>
    /// Поиск пользователей в реалме
    /// </summary>
    /// <param name="accessToken">Access token текущего пользователя</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="searchTerm">Поисковый запрос (username, firstName, lastName или email)</param>
    /// <param name="exact">Строгое совпадение</param>
    /// <param name="first">Pagination offset</param>
    /// <param name="max">Максимальное количество результатов</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Список найденных пользователей (только для чтения)</returns>
    Task<IReadOnlyList<UserSearchResultDto>> SearchUsersAsync(
        string accessToken,
        string realm, 
        string? searchTerm = null,
        bool exact = false,
        int first = 0,
        int max = 100,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить детальную информацию о пользователе
    /// </summary>
    /// <param name="accessToken">Access token текущего пользователя</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Детальная информация о пользователе</returns>
    Task<UserDetailedInfoDto?> GetUserInfoAsync(
        string accessToken,
        string realm,
        string userId,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Обновить информацию о пользователе
    /// </summary>
    /// <param name="accessToken">Access token текущего пользователя</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="firstName">Имя</param>
    /// <param name="lastName">Фамилия</param>
    /// <param name="email">Email</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Успешно ли выполнено обновление</returns>
    Task<bool> UpdateUserAsync(
        string accessToken,
        string realm,
        string userId,
        string? firstName,
        string? lastName,
        string? email,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Создать нового пользователя
    /// </summary>
    /// <param name="accessToken">Access token текущего пользователя</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="username">Имя пользователя</param>
    /// <param name="firstName">Имя</param>
    /// <param name="lastName">Фамилия</param>
    /// <param name="email">Email</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Успешно ли выполнено создание</returns>
    Task<bool> CreateUserAsync(
        string accessToken,
        string realm,
        string username,
        string firstName,
        string lastName,
        string email,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Удалить realm роли у пользователя
    /// </summary>
    /// <param name="accessToken">Access token текущего пользователя</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="roles">Список realm ролей для удаления (содержит id и name)</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Успешно ли выполнено удаление</returns>
    Task<bool> RemoveRealmRolesAsync(
        string accessToken,
        string realm,
        string userId,
        List<UserRealmRoleDto> roles,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Удалить client роли у пользователя
    /// </summary>
    /// <param name="accessToken">Access token текущего пользователя</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="clientId">Внутренний UUID клиента</param>
    /// <param name="role">Client роль для удаления (содержит id и name)</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Успешно ли выполнено удаление</returns>
    Task<bool> RemoveClientRoleAsync(
        string accessToken,
        string realm,
        string userId,
        string clientId,
        UserClientRoleDto role,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Добавить realm роли пользователю
    /// </summary>
    /// <param name="accessToken">Access token текущего пользователя</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="roles">Список realm ролей для добавления (содержит id и name)</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Успешно ли выполнено добавление</returns>
    Task<bool> AddRealmRolesAsync(
        string accessToken,
        string realm,
        string userId,
        List<UserRealmRoleDto> roles,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Добавить client роль пользователю
    /// </summary>
    /// <param name="accessToken">Access token текущего пользователя</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="clientId">Внутренний UUID клиента</param>
    /// <param name="role">Client роль для добавления (содержит id и name)</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Успешно ли выполнено добавление</returns>
    Task<bool> AddClientRoleAsync(
        string accessToken,
        string realm,
        string userId,
        string clientId,
        UserClientRoleDto role,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Снять блокировку брутфорса для пользователя
    /// </summary>
    /// <param name="accessToken">Access token текущего пользователя</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Успешно ли выполнено снятие блокировки</returns>
    Task<bool> RemoveBruteForceStatusAsync(
        string accessToken,
        string realm,
        string userId,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Выполнить действия через email для пользователя (например, обновление пароля, конфигурация OTP)
    /// </summary>
    /// <param name="accessToken">Access token текущего пользователя</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="actions">Список действий для выполнения (например, "UPDATE_PASSWORD", "CONFIGURE_TOTP")</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Успешно ли выполнено действие</returns>
    Task<bool> ExecuteActionsEmailAsync(
        string accessToken,
        string realm,
        string userId,
        List<string> actions,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Заблокировать пользователя
    /// </summary>
    /// <param name="accessToken">Access token текущего пользователя</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="reason">Причина блокировки</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Успешно ли выполнена блокировка</returns>
    Task<bool> BlockUserAsync(
        string accessToken,
        string realm,
        string userId,
        string reason,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Разблокировать пользователя
    /// </summary>
    /// <param name="accessToken">Access token текущего пользователя</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="reason">Причина разблокировки</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Успешно ли выполнена разблокировка</returns>
    Task<bool> UnblockUserAsync(
        string accessToken,
        string realm,
        string userId,
        string reason,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить сертификат пользователя в формате Base64 (X.509)
    /// </summary>
    /// <param name="accessToken">Access token текущего пользователя</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Базовое64 представление сертификата или null, если сертификат отсутствует</returns>
    Task<string?> GetUserCertificateAsync(
        string accessToken,
        string realm,
        string userId,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Загрузить (обновить) сертификат пользователя
    /// </summary>
    /// <param name="accessToken">Access token текущего пользователя</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="certificateStream">Поток с данными сертификата</param>
    /// <param name="fileName">Имя файла сертификата</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Успешно ли выполнено добавление/обновление</returns>
    Task<bool> UploadUserCertificateAsync(
        string accessToken,
        string realm,
        string userId,
        Stream certificateStream,
        string fileName,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Удалить сертификат пользователя
    /// </summary>
    /// <param name="accessToken">Access token текущего пользователя</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Успешно ли выполнено удаление</returns>
    Task<bool> DeleteUserCertificateAsync(
        string accessToken,
        string realm,
        string userId,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
}

