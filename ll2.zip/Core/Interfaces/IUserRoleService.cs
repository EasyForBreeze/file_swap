using System.Collections.Generic;
using System.Security.Claims;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Сервис для работы с ролями пользователей.
/// </summary>
public interface IUserRoleService
{
    /// <summary>
    /// Проверяет, является ли текущий пользователь администратором.
    /// </summary>
    /// <returns>True, если пользователь имеет роль Assistant-Admin</returns>
    bool IsAdmin();
    
    /// <summary>
    /// Проверяет, является ли текущий пользователь обычным пользователем.
    /// </summary>
    /// <returns>True, если пользователь имеет роль Assistant-User</returns>
    bool IsUser();
    
    /// <summary>
    /// Проверяет, является ли текущий пользователь оператором.
    /// </summary>
    /// <returns>True, если пользователь имеет роль Assistant-Operator</returns>
    bool IsOperator();
    
    /// <summary>
    /// Проверяет, имеет ли пользователь хотя бы одну из указанных ролей.
    /// </summary>
    /// <param name="roles">Роли для проверки</param>
    /// <returns>True, если пользователь имеет хотя бы одну из указанных ролей</returns>
    bool HasAnyRole(params string[] roles);
    
    /// <summary>
    /// Проверяет, имеет ли пользователь все указанные роли.
    /// </summary>
    /// <param name="roles">Роли для проверки</param>
    /// <returns>True, если пользователь имеет все указанные роли</returns>
    bool HasAllRoles(params string[] roles);
    
    /// <summary>
    /// Получает роль текущего пользователя.
    /// </summary>
    /// <returns>Роль пользователя или null, если роль не найдена</returns>
    string? GetUserRole();
    
    /// <summary>
    /// Получает имя текущего пользователя.
    /// </summary>
    /// <returns>Имя пользователя или null, если не найдено</returns>
    string? GetUserName();
    
    /// <summary>
    /// Получает ID текущего пользователя.
    /// </summary>
    /// <returns>ID пользователя или null, если не найден</returns>
    string? GetUserId();
    
    /// <summary>
    /// Получает все роли текущего пользователя.
    /// </summary>
    /// <returns>Список ролей пользователя</returns>
    IEnumerable<string> GetRoles();
    
    /// <summary>
    /// Получает все роли текущего пользователя как материализованный список.
    /// Используйте этот метод, если роли будут использоваться несколько раз.
    /// </summary>
    /// <returns>Материализованный список всех ролей пользователя</returns>
    IReadOnlyList<string> GetRolesList();
    
    /// <summary>
    /// Проверяет, имеет ли пользователь доступ к указанной странице.
    /// </summary>
    /// <param name="pagePath">Путь к странице</param>
    /// <returns>True, если доступ разрешен</returns>
    bool HasAccessToPage(string pagePath);
    
    /// <summary>
    /// Получает список всех страниц, к которым у текущего пользователя есть доступ.
    /// </summary>
    /// <returns>Коллекция путей к доступным страницам</returns>
    IReadOnlySet<string> GetAccessiblePages();
}
