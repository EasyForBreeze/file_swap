using System.Threading;
using System.Threading.Tasks;
using new_assistant.Core.Models;

namespace new_assistant.Core.Interfaces;

public interface ITokenExchangeService
{
    Task<TokenExchangeResult?> GetTokenForRealmAsync(string targetRealm, CancellationToken cancellationToken = default);

    bool IsRealmSupported(string targetRealm);

    bool IsRealmAllowed(string targetRealm);
    
    /// <summary>
    /// Получить базовый URL для реалма из TokenEndpoint (всё до первого '/' после домена)
    /// Если реалм не найден в token-exchange.json, возвращает null
    /// </summary>
    string? GetBaseUrlForRealm(string realm);
    
    /// <summary>
    /// Получить метрики работы сервиса.
    /// Метрики включают количество запросов, успешных/неуспешных операций и статистику кэша.
    /// </summary>
    /// <returns>
    /// Кортеж с метриками:
    /// - Requests: общее количество запросов token exchange
    /// - Successes: количество успешных операций
    /// - Failures: количество неуспешных операций
    /// - CacheHits: количество попаданий в кэш
    /// - CacheMisses: количество промахов кэша
    /// </returns>
    /// <exception cref="ObjectDisposedException">Выбрасывается если сервис был освобожден</exception>
    (long Requests, long Successes, long Failures, long CacheHits, long CacheMisses) GetMetrics();
}

