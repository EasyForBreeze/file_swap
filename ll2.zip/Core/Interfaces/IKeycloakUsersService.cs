using System.Text.Json;
using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для работы с пользователями Keycloak
/// </summary>
public interface IKeycloakUsersService
{
    /// <summary>
    /// Получить пользователя по username в указанном реалме
    /// </summary>
    Task<JsonElement?> GetUserByUsernameAsync(string realm, string username, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить client роли пользователя
    /// </summary>
    Task<List<string>> GetUserClientRolesAsync(string realm, string userId, string clientUuid, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Поиск пользователей в KeyCloak по username
    /// </summary>
    Task<List<Controllers.UserSearchResult>> SearchUsersAsync(string searchTerm, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Поиск пользователей по username в конкретном реалме
    /// </summary>
    Task<List<UserSearchResultDto>> SearchUsersByUsernameAsync(string realm, string username, CancellationToken cancellationToken = default);
}

