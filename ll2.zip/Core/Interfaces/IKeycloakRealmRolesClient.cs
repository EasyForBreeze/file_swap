using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс клиента для работы с realm roles (роли реалма)
/// </summary>
public interface IKeycloakRealmRolesClient
{
    /// <summary>
    /// Получить все доступные realm роли
    /// </summary>
    Task<List<KeycloakRoleDto>> GetAvailableRealmRolesAsync(string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить доступные роли для назначения пользователю (через ui-ext endpoint, оптимизированный метод)
    /// </summary>
    Task<List<KeycloakRoleDto>> GetAvailableRolesForUserAsync(
        string realm, 
        string userId, 
        string searchTerm = "", 
        int first = 0, 
        int? max = null, 
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить все доступные роли для назначения пользователю (без пагинации)
    /// </summary>
    Task<List<KeycloakRoleDto>> GetAllAvailableRolesForUserAsync(
        string realm, 
        string userId, 
        string searchTerm = "", 
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получает информацию о realm роли по имени
    /// </summary>
    Task<KeycloakRoleDto> GetRealmRoleByNameAsync(string realm, string roleName, CancellationToken cancellationToken = default);
}

