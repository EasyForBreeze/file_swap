using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс клиента для работы с назначением ролей пользователям
/// </summary>
public interface IKeycloakRoleMappingClient
{
    /// <summary>
    /// Получить все назначенные роли пользователя (realm и client roles)
    /// </summary>
    Task<List<KeycloakClientRoleDto>> GetUserRoleMappingsAsync(string realm, string userId, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить client роли пользователя для конкретного клиента
    /// </summary>
    Task<List<string>> GetUserClientRolesAsync(string realm, string userId, string clientUuid, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Назначить realm роль пользователю
    /// </summary>
    Task AssignRealmRoleToUserAsync(string realm, string userId, string roleName, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Удалить роль у пользователя (realm или client role)
    /// </summary>
    Task RemoveRoleFromUserAsync(string realm, string userId, string roleName, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Назначить client роль пользователю
    /// </summary>
    Task AssignClientRoleToUserAsync(string realm, string userId, string clientInternalId, string roleId, string roleName, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Удалить client роль у пользователя
    /// </summary>
    Task RemoveClientRoleFromUserAsync(string realm, string userId, string clientInternalId, string roleId, string roleName, CancellationToken cancellationToken = default);
}

