using System.Threading;
using System.Threading.Tasks;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Сервис для обновления access token через refresh token
/// </summary>
public interface ITokenRefreshService
{
    /// <summary>
    /// Получить актуальный access token (обновит если истёк)
    /// </summary>
    /// <param name="cancellationToken">Токен отмены операции</param>
    Task<string?> GetValidAccessTokenAsync(CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Сохранить токены для текущего пользователя
    /// </summary>
    void StoreTokens(string accessToken, string? refreshToken);
}

