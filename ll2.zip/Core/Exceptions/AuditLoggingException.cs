namespace new_assistant.Core.Exceptions;

/// <summary>
/// Исключение, возникающее при ошибках логирования аудита
/// </summary>
public class AuditLoggingException : Exception
{
    public AuditLoggingException(string message) : base(message)
    {
    }

    public AuditLoggingException(string message, Exception innerException) : base(message, innerException)
    {
    }
}

