using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using new_assistant.Core.Interfaces;

namespace new_assistant.Controllers;

/// <summary>
/// Контроллер для работы с архивами учетных данных клиентов
/// </summary>
[Authorize(Roles = "assistant-admin")]
[ApiController]
[Route("api/client")]
[EnableRateLimiting("admin")]
public class ClientArchiveController : ControllerBase
{
    private const long MaxFileSizeBytes = 100 * 1024 * 1024; // 100 MB
    
    private readonly IClientArchiveService _archiveService;
    private readonly ILogger<ClientArchiveController> _logger;

    public ClientArchiveController(
        IClientArchiveService archiveService,
        ILogger<ClientArchiveController> logger)
    {
        _archiveService = archiveService ?? throw new ArgumentNullException(nameof(archiveService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Скачивание архива с учетными данными клиента
    /// </summary>
    /// <param name="clientId">Уникальный идентификатор клиента в Keycloak</param>
    /// <returns>Файл архива в формате ZIP</returns>
    /// <response code="200">Архив успешно скачан</response>
    /// <response code="400">Не указан Client ID или размер архива превышает максимально допустимый</response>
    /// <response code="401">Не авторизован</response>
    /// <response code="403">Нет доступа к архиву</response>
    /// <response code="404">Архив не найден</response>
    /// <response code="500">Внутренняя ошибка сервера</response>
    /// <remarks>
    /// Архив содержит учетные данные клиента, включая Client Secret.
    /// Доступ имеют только администраторы.
    /// Максимальный размер архива: 100 MB.
    /// Поддерживается докачка файлов через HTTP Range-запросы.
    /// </remarks>
    [HttpGet("download-archive")]
    public IActionResult DownloadArchive([FromQuery] string clientId)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(clientId))
            {
                _logger.LogWarning("Попытка скачивания архива без указания Client ID");
                return BadRequest("Client ID не указан");
            }

            var archivePath = _archiveService.GetArchivePath(clientId);

            if (string.IsNullOrEmpty(archivePath) || !System.IO.File.Exists(archivePath))
            {
                _logger.LogWarning("Архив для клиента {ClientId} не найден", clientId);
                return NotFound($"Архив для клиента {clientId} не найден");
            }

            // Проверка размера файла
            var fileInfo = new FileInfo(archivePath);
            if (fileInfo.Length > MaxFileSizeBytes)
            {
                _logger.LogWarning(
                    "Попытка скачивания слишком большого архива {ClientId}: {Size} bytes", 
                    clientId, 
                    fileInfo.Length);
                return BadRequest($"Размер архива превышает максимально допустимый ({MaxFileSizeBytes / (1024 * 1024)} MB)");
            }

            // Санитизация имени файла
            var sanitizedClientId = SanitizeFileName(clientId);
            var fileName = $"{sanitizedClientId}_credentials.zip";

            // Установка заголовков для предотвращения кэширования
            Response.Headers["Cache-Control"] = "no-cache, no-store, must-revalidate";
            Response.Headers["Pragma"] = "no-cache";
            Response.Headers["Expires"] = "0";

            _logger.LogWarning(
                "Скачивание архива для клиента {ClientId} пользователем {User}", 
                clientId, 
                User.Identity?.Name ?? "Unknown");

            // Потоковая передача файла с поддержкой Range-запросов
            var fileStream = new FileStream(
                archivePath, 
                FileMode.Open, 
                FileAccess.Read, 
                FileShare.Read, 
                4096, 
                FileOptions.Asynchronous | FileOptions.SequentialScan);

            return File(fileStream, "application/zip", fileName, enableRangeProcessing: true);
        }
        catch (UnauthorizedAccessException ex)
        {
            _logger.LogError(ex, "Нет доступа к архиву клиента {ClientId}", clientId);
            return StatusCode(403, "Нет доступа к архиву");
        }
        catch (FileNotFoundException ex)
        {
            _logger.LogWarning(ex, "Архив для клиента {ClientId} не найден", clientId);
            return NotFound($"Архив для клиента {clientId} не найден");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при скачивании архива для клиента {ClientId}", clientId);
            return StatusCode(500, "Ошибка при скачивании архива");
        }
    }

    /// <summary>
    /// Удаление архива клиента (для очистки после скачивания)
    /// </summary>
    /// <param name="clientId">Уникальный идентификатор клиента в Keycloak</param>
    /// <returns>Результат операции удаления</returns>
    /// <response code="200">Архив успешно удален</response>
    /// <response code="400">Не указан Client ID</response>
    /// <response code="401">Не авторизован</response>
    /// <response code="403">Нет доступа для удаления архива</response>
    /// <response code="404">Архив не найден</response>
    /// <response code="500">Внутренняя ошибка сервера</response>
    /// <remarks>
    /// Удаление архива доступно только администраторам.
    /// Все операции удаления логируются для аудита.
    /// </remarks>
    [HttpDelete("archive/{clientId}")]
    public async Task<IActionResult> DeleteArchive(string clientId)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(clientId))
            {
                _logger.LogWarning("Попытка удаления архива без указания Client ID");
                return BadRequest(new { success = false, message = "Client ID не указан" });
            }

            var archivePath = _archiveService.GetArchivePath(clientId);

            if (string.IsNullOrEmpty(archivePath) || !System.IO.File.Exists(archivePath))
            {
                _logger.LogWarning("Архив для клиента {ClientId} не найден при попытке удаления", clientId);
                return NotFound(new { success = false, message = $"Архив для клиента {clientId} не найден" });
            }

            await Task.Run(() => _archiveService.CleanupFiles(new[] { archivePath }));

            _logger.LogWarning(
                "Архив для клиента {ClientId} удален пользователем {User}", 
                clientId, 
                User.Identity?.Name ?? "Unknown");

            return Ok(new { success = true, message = "Архив успешно удален" });
        }
        catch (UnauthorizedAccessException ex)
        {
            _logger.LogError(ex, "Нет доступа для удаления архива клиента {ClientId}", clientId);
            return StatusCode(403, new { success = false, message = "Нет доступа для удаления архива" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при удалении архива для клиента {ClientId}", clientId);
            return StatusCode(500, new { success = false, message = "Ошибка при удалении архива" });
        }
    }

    /// <summary>
    /// Санитизирует имя файла, удаляя недопустимые символы
    /// </summary>
    /// <param name="clientId">Исходный Client ID</param>
    /// <returns>Санитизированное имя файла</returns>
    private string SanitizeFileName(string clientId)
    {
        if (string.IsNullOrWhiteSpace(clientId))
        {
            return "unknown";
        }

        // Удаляем недопустимые символы для имен файлов
        var invalidChars = Path.GetInvalidFileNameChars();
        var sanitized = string.Join("_", clientId.Split(invalidChars, StringSplitOptions.RemoveEmptyEntries));
        
        // Ограничиваем длину имени файла
        if (sanitized.Length > 100)
        {
            sanitized = sanitized.Substring(0, 100);
        }
        
        // Если после санитизации строка пустая, используем значение по умолчанию
        if (string.IsNullOrWhiteSpace(sanitized))
        {
            sanitized = "unknown";
        }
        
        return sanitized;
    }
}

