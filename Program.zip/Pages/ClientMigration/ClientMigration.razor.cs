using new_assistant.Core.DTOs;
using new_assistant.Core.Entities;
using new_assistant.Core.Interfaces;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.JSInterop;

namespace new_assistant.Pages.ClientMigration;

/// <summary>
/// Code-behind для компонента ClientMigration
/// Содержит всю бизнес-логику для миграции клиентов
/// </summary>
public partial class ClientMigration : ComponentBase, IAsyncDisposable
{
    [Inject] private IKeycloakAdminService KeycloakService { get; set; } = null!;
    [Inject] private IClientMigrationService MigrationService { get; set; } = null!;
    [Inject] private IUserRoleService UserRoleService { get; set; } = null!;
    [Inject] private IKeycloakStageService StageKeycloakService { get; set; } = null!;
    [Inject] private IHttpContextAccessor HttpContextAccessor { get; set; } = null!;
    [Inject] private IJSRuntime JSRuntime { get; set; } = null!;
    [Inject] private NavigationManager NavigationManager { get; set; } = null!;
    [Inject] private ILogger<ClientMigration> Logger { get; set; } = null!;
    [Inject] private IKeycloakUrlBuilderService UrlBuilder { get; set; } = null!;
    
    private CancellationTokenSource? _cancellationTokenSource;
    private readonly ClientMigrationViewModel _viewModel = new();
    private bool _isDisposed;

    protected override async Task OnInitializedAsync()
    {
        // Загружаем реалмы STAGE один раз при инициализации страницы
        await LoadStageRealmsAsync();
    }

    private async Task SearchClients()
    {
        if (!_viewModel.ValidateStep1() || _isDisposed)
        {
            return;
        }

        // Отменяем предыдущий поиск, если он еще выполняется
        _cancellationTokenSource?.Cancel();
        _cancellationTokenSource?.Dispose();
        _cancellationTokenSource = new CancellationTokenSource();
        var cancellationToken = _cancellationTokenSource.Token;

        _viewModel.IsSearching = true;
        _viewModel.HasSearched = false;
        _viewModel.SearchResults.Clear();
        _viewModel.SelectedClient = null;
        _viewModel.ValidationResult = null;
        SafeStateHasChanged();

        try
        {
            Logger.LogWarning("Поиск клиентов для миграции: {SearchQuery}", _viewModel.SearchQuery);
            
            // Ищем во всех реалмах TEST
            var clients = await KeycloakService.SearchClientsByIdAsync(_viewModel.SearchQuery, null, cancellationToken);
            
            // Проверяем, не был ли запрос отменен
            cancellationToken.ThrowIfCancellationRequested();
            
            if (!_isDisposed)
            {
                _viewModel.SearchResults.AddRange(clients);
                Logger.LogWarning("Найдено клиентов для миграции: {Count}", _viewModel.SearchResults.Count);
            }
        }
        catch (OperationCanceledException)
        {
            Logger.LogDebug("Поиск клиентов был отменен");
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка поиска клиентов");
        }
        finally
        {
            if (!_isDisposed)
            {
                _viewModel.IsSearching = false;
                _viewModel.HasSearched = true;
                SafeStateHasChanged();
            }
        }
    }

    private Task OnSearchKeyDown(KeyboardEventArgs e)
    {
        if (e.Key == "Enter")
        {
            return SearchClients();
        }
        return Task.CompletedTask;
    }

    private Task SelectClient(ClientSearchResult client)
    {
        if (_isDisposed)
            return Task.CompletedTask;

        _viewModel.SelectedClient = client;
        _viewModel.ResetOnClientSelection();
        
        // Если есть такой же realm в STAGE, выбираем его по умолчанию
        if (_viewModel.StageRealms.Contains(client.Realm))
        {
            _viewModel.SelectedTargetRealm = client.Realm;
        }
        
        SafeStateHasChanged();
        return Task.CompletedTask;
    }

    private async Task LoadStageRealmsAsync()
    {
        // Загружаем только один раз
        if (_viewModel.StageRealmsLoaded || _isDisposed)
            return;

        _cancellationTokenSource ??= new CancellationTokenSource();
        var cancellationToken = _cancellationTokenSource.Token;

        _viewModel.IsLoadingStageRealms = true;
        _viewModel.StageRealms.Clear();
        SafeStateHasChanged();

        try
        {
            Logger.LogInformation("Загрузка реалмов STAGE (один раз при инициализации)");
            var realms = await StageKeycloakService.GetRealmsListAsync(cancellationToken);
            
            // Проверяем, не был ли запрос отменен
            cancellationToken.ThrowIfCancellationRequested();
            
            if (!_isDisposed)
            {
                _viewModel.StageRealms = realms
                    .Where(r => r != "master")
                    .ToList();
                
                _viewModel.StageRealmsLoaded = true;
                Logger.LogInformation("Загружено реалмов STAGE: {Count}", _viewModel.StageRealms.Count);
            }
        }
        catch (OperationCanceledException)
        {
            Logger.LogDebug("Загрузка реалмов STAGE была отменена");
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка загрузки реалмов STAGE");
        }
        finally
        {
            if (!_isDisposed)
            {
                _viewModel.IsLoadingStageRealms = false;
                SafeStateHasChanged();
            }
        }
    }

    private async Task ValidateMigration()
    {
        if (!_viewModel.ValidateStep2() || _isDisposed)
            return;

        // Отменяем предыдущую валидацию, если она еще выполняется
        _cancellationTokenSource?.Cancel();
        _cancellationTokenSource?.Dispose();
        _cancellationTokenSource = new CancellationTokenSource();
        var cancellationToken = _cancellationTokenSource.Token;

        _viewModel.IsValidating = true;
        _viewModel.ValidationResult = null;
        SafeStateHasChanged();

        try
        {
            Logger.LogWarning("Валидация миграции: {ClientId} из {Source} в {Target}", 
                _viewModel.SelectedClient!.ClientId, _viewModel.SelectedClient.Realm, _viewModel.SelectedTargetRealm);

            var request = BuildMigrationRequest();
            
            _viewModel.ValidationResult = await MigrationService.ValidateMigrationAsync(request, cancellationToken);
            
            // Проверяем, не был ли запрос отменен
            cancellationToken.ThrowIfCancellationRequested();

            if (!_isDisposed)
            {
                UpdateWikiPageUrlFromValidation();
            }
        }
        catch (OperationCanceledException)
        {
            Logger.LogDebug("Валидация миграции была отменена");
        }
        catch (Exception ex)
        {
            if (!_isDisposed)
            {
                Logger.LogError(ex, "Ошибка валидации миграции");
                _viewModel.ValidationResult = new MigrationValidationResult
                {
                    CanMigrate = false,
                    Messages = new List<string> { $"Ошибка: {ex.Message}" }
                };
            }
        }
        finally
        {
            if (!_isDisposed)
            {
                _viewModel.IsValidating = false;
                SafeStateHasChanged();
                
                // Скроллим к результатам валидации после рендеринга
                await Task.Delay(300, cancellationToken);
                await ScrollToValidationResultsAsync();
            }
        }
    }

    private ClientMigrationRequest BuildMigrationRequest()
    {
        var sanitizedWikiUrl = SanitizeUrl(_viewModel.WikiPageUrl);
        var sanitizedTicketUrl = SanitizeUrl(_viewModel.TicketUrl);

        return new ClientMigrationRequest
        {
            ClientId = _viewModel.SelectedClient!.ClientId,
            SourceRealm = _viewModel.SelectedClient.Realm,
            TargetRealm = _viewModel.SelectedTargetRealm,
            TicketNumber = _viewModel.TicketNumber,
            NotificationEmail = _viewModel.NotificationEmail,
            WikiPageUrl = sanitizedWikiUrl,
            TicketUrl = sanitizedTicketUrl
        };
    }

    private static string? SanitizeUrl(string url)
    {
        return string.IsNullOrWhiteSpace(url) ? null : url.Trim();
    }

    private void UpdateWikiPageUrlFromValidation()
    {
        if (_viewModel.ValidationResult?.ExistingWikiPageUrl is { Length: > 0 } existingWiki && 
            string.IsNullOrWhiteSpace(_viewModel.WikiPageUrl))
        {
            _viewModel.WikiPageUrl = string.IsNullOrWhiteSpace(existingWiki) ? string.Empty : existingWiki.Trim();
        }
    }
    
    private async Task ScrollToValidationResultsAsync()
    {
        if (_isDisposed)
            return;

        try
        {
            await JSRuntime.InvokeVoidAsync("scrollToElementId", "validation-results", 100);
        }
        catch (JSDisconnectedException)
        {
            // Компонент уже размонтирован, игнорируем
        }
        catch
        {
            if (!_isDisposed)
            {
                try
                {
                    await JSRuntime.InvokeVoidAsync("scrollToElement", "validation-results");
                }
                catch (JSDisconnectedException)
                {
                    // Компонент уже размонтирован, игнорируем
                }
                catch (Exception ex)
                {
                    Logger.LogWarning(ex, "Не удалось выполнить скролл к результатам валидации");
                }
            }
        }
    }

    private async Task MigrateClient()
    {
        if (!_viewModel.ValidateStep3() || _isDisposed)
            return;

        // Отменяем предыдущую миграцию, если она еще выполняется
        _cancellationTokenSource?.Cancel();
        _cancellationTokenSource?.Dispose();
        _cancellationTokenSource = new CancellationTokenSource();
        var cancellationToken = _cancellationTokenSource.Token;

        _viewModel.IsMigrating = true;
        SafeStateHasChanged();

        try
        {
            Logger.LogWarning("Начало миграции: {ClientId} из {Source} в {Target}", 
                _viewModel.SelectedClient!.ClientId, _viewModel.SelectedClient.Realm, _viewModel.SelectedTargetRealm);

            var request = BuildMigrationRequest();
            var username = HttpContextAccessor.HttpContext?.User?.Identity?.Name ?? "Unknown";
            
            _viewModel.MigrationResult = await MigrationService.MigrateClientAsync(request, username, cancellationToken);
            
            // Проверяем, не был ли запрос отменен
            cancellationToken.ThrowIfCancellationRequested();

            if (!_isDisposed)
            {
                _viewModel.ShowMigrationResultModal = true;
                
                await CenterModalAsync();
                UpdateWikiPageUrlFromMigrationResult();
            }
        }
        catch (OperationCanceledException)
        {
            Logger.LogDebug("Миграция была отменена");
        }
        catch (Exception ex)
        {
            if (!_isDisposed)
            {
                Logger.LogError(ex, "Критическая ошибка миграции");
                _viewModel.MigrationResult = new ClientMigrationResult
                {
                    Success = false,
                    Errors = new List<string> { $"Критическая ошибка: {ex.Message}" }
                };
                _viewModel.ShowMigrationResultModal = true;
            }
        }
        finally
        {
            if (!_isDisposed)
            {
                _viewModel.IsMigrating = false;
                SafeStateHasChanged();
            }
        }
    }

    private async Task CenterModalAsync()
    {
        if (_isDisposed)
            return;

        try
        {
            await JSRuntime.InvokeVoidAsync("centerModalVertically", "client-migration-modal");
        }
        catch (JSDisconnectedException)
        {
            // Компонент уже размонтирован, игнорируем
        }
        catch (Exception ex)
        {
            Logger.LogDebug(ex, "Не удалось позиционировать модальное окно");
        }
    }

    private void UpdateWikiPageUrlFromMigrationResult()
    {
        if (_viewModel.MigrationResult?.Success == true && !string.IsNullOrWhiteSpace(_viewModel.MigrationResult.WikiPageUrl))
        {
            _viewModel.WikiPageUrl = _viewModel.MigrationResult.WikiPageUrl!.Trim();
        }
    }

    private async Task CloseMigrationResultModal()
    {
        if (_isDisposed)
            return;

        _cancellationTokenSource ??= new CancellationTokenSource();
        var cancellationToken = _cancellationTokenSource.Token;

        _viewModel.IsClosingModal = true;
        SafeStateHasChanged();
        
        try
        {
            await Task.Delay(350, cancellationToken);
            
            if (!_isDisposed)
            {
                _viewModel.IsClosingModal = false;
                _viewModel.ShowMigrationResultModal = false;
                
                if (_viewModel.MigrationResult?.Success == true)
                {
                    _viewModel.ResetAfterSuccessfulMigration();
                }
                
                SafeStateHasChanged();
            }
        }
        catch (OperationCanceledException)
        {
            // Операция была отменена, игнорируем
        }
    }

    private async Task CopyToClipboard(string text)
    {
        if (_isDisposed)
            return;

        try
        {
            await JSRuntime.InvokeVoidAsync("navigator.clipboard.writeText", text);
            Logger.LogInformation("Скопировано в буфер обмена");
        }
        catch (JSDisconnectedException)
        {
            // Компонент уже размонтирован, игнорируем
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка копирования в буфер обмена");
        }
    }

    private async Task CopyMigrationSummaryToClipboard()
    {
        var summary = BuildMigrationSummaryText();
        await CopyToClipboard(summary);
    }

    private string BuildMigrationSummaryText()
    {
        var baseUrl = GetStageBaseUrl();
        var realm = string.IsNullOrWhiteSpace(_viewModel.SelectedTargetRealm) ? "N/A" : _viewModel.SelectedTargetRealm;
        var clientId = _viewModel.MigrationResult?.ClientId ?? _viewModel.SelectedClient?.ClientId ?? "N/A";
        var wiki = string.IsNullOrWhiteSpace(_viewModel.MigrationResult?.WikiPageUrl) ? "Не указана" : _viewModel.MigrationResult!.WikiPageUrl!;
        var endpoints = GetStageEndpointsUrl();

        var builder = new System.Text.StringBuilder();
        builder.AppendLine("Создана конфигурация в STAGE среде");
        builder.AppendLine($"Base URL: {baseUrl}");
        builder.AppendLine($"Realm: {realm}");
        builder.AppendLine($"ClientID: {clientId}");
        builder.AppendLine("Secret: в архиве, пароль от архива выслан на почту");
        builder.AppendLine($"Ссылка на конфигурацию в реестре: {wiki}");
        builder.AppendLine($"Endpoints: {endpoints}");

        return builder.ToString();
    }

    private async Task DownloadCredentials()
    {
        if (string.IsNullOrEmpty(_viewModel.MigrationResult?.ClientId) || _isDisposed)
            return;

        try
        {
            var downloadUrl = $"/api/client/download-archive?clientId={Uri.EscapeDataString(_viewModel.MigrationResult.ClientId)}";
            await JSRuntime.InvokeVoidAsync("open", downloadUrl, "_blank");
            Logger.LogWarning("Скачивание credentials для {ClientId}", _viewModel.MigrationResult.ClientId);
        }
        catch (JSDisconnectedException)
        {
            // Компонент уже размонтирован, игнорируем
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка скачивания credentials");
        }
    }

    private string GetStageBaseUrl()
    {
        if (string.IsNullOrEmpty(_viewModel.SelectedTargetRealm))
            return "N/A";

        try
        {
            return UrlBuilder.GetStageRealmUrl(_viewModel.SelectedTargetRealm);
        }
        catch
        {
            return "N/A";
        }
    }

    private string GetStageEndpointsUrl()
    {
        if (string.IsNullOrEmpty(_viewModel.SelectedTargetRealm))
            return "N/A";

        try
        {
            return UrlBuilder.GetStageEndpointsUrl(_viewModel.SelectedTargetRealm);
        }
        catch
        {
            return "N/A";
        }
    }
    
    /// <summary>
    /// Безопасный вызов StateHasChanged с проверкой на размонтирование компонента
    /// </summary>
    private void SafeStateHasChanged()
    {
        if (!_isDisposed)
        {
            try
            {
                StateHasChanged();
            }
            catch (ObjectDisposedException)
            {
                // Компонент уже размонтирован, игнорируем
            }
            catch (InvalidOperationException)
            {
                // Компонент уже размонтирован или находится в процессе размонтирования, игнорируем
            }
        }
    }

    /// <summary>
    /// Освобождение ресурсов при размонтировании компонента
    /// </summary>
    public async ValueTask DisposeAsync()
    {
        if (_isDisposed)
            return;

        _isDisposed = true;

        if (_cancellationTokenSource != null)
        {
            try
            {
                _cancellationTokenSource.Cancel();
                _cancellationTokenSource.Dispose();
            }
            catch (Exception ex)
            {
                Logger.LogWarning(ex, "Ошибка при отмене операций при размонтировании компонента");
            }
            finally
            {
                _cancellationTokenSource = null;
            }
        }
        
        await ValueTask.CompletedTask;
    }
}

