namespace new_assistant.Configuration;

/// <summary>
/// Настройки для MemoryCache
/// </summary>
public class MemoryCacheSettings
{
    /// <summary>
    /// Максимальный размер кэша (количество элементов)
    /// </summary>
    public int? SizeLimit { get; set; }

    /// <summary>
    /// Процент сжатия кэша при достижении лимита (от 0.0 до 1.0)
    /// </summary>
    public double? CompactionPercentage { get; set; }

    /// <summary>
    /// Частота сканирования на истекшие элементы (в минутах)
    /// </summary>
    public int? ExpirationScanFrequencyMinutes { get; set; }
}

