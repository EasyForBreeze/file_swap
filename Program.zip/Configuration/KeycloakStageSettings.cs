namespace new_assistant.Configuration;

/// <summary>
/// Настройки для подключения к Keycloak STAGE контуру
/// </summary>
public class KeycloakStageSettings
{
    /// <summary>
    /// Базовый URL Keycloak STAGE (например, http://stage-keycloak:8080)
    /// </summary>
    public string BaseUrl { get; set; } = string.Empty;
    
    /// <summary>
    /// Realm для административного доступа (обычно master)
    /// </summary>
    public string Realm { get; set; } = "master";
    
    /// <summary>
    /// Client ID для доступа к Admin API
    /// </summary>
    public string ClientId { get; set; } = string.Empty;
    
    /// <summary>
    /// Client Secret для доступа к Admin API
    /// </summary>
    public string ClientSecret { get; set; } = string.Empty;
    
    /// <summary>
    /// Использовать legacy auth path (/auth)
    /// </summary>
    public bool UseLegacyAuthPath { get; set; } = false;
    
    /// <summary>
    /// Таймаут запросов в секундах
    /// </summary>
    public int RequestTimeoutSeconds { get; set; } = 30;
    
    /// <summary>
    /// Максимальное количество одновременных запросов
    /// </summary>
    public int MaxConcurrentRequests { get; set; } = 3;
    
    /// <summary>
    /// Максимальное количество попыток повтора для transient ошибок
    /// </summary>
    public int MaxRetryAttempts { get; set; } = 3;
    
    /// <summary>
    /// Базовая задержка в миллисекундах для exponential backoff при retry
    /// </summary>
    public int RetryBaseDelayMs { get; set; } = 1000;
    
    /// <summary>
    /// Максимальная длина endpoint в символах
    /// </summary>
    public int MaxEndpointLength { get; set; } = 2048;
    
    /// <summary>
    /// Исключенные реалмы (не показывать в списке)
    /// </summary>
    public List<string> ExcludedRealms { get; set; } = new() { "master" };
    
    /// <summary>
    /// Включен ли STAGE контур
    /// </summary>
    public bool Enabled { get; set; } = false;
}

