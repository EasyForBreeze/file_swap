namespace new_assistant.Configuration;

/// <summary>
/// Настройки для страницы управления доступом клиентов
/// </summary>
public sealed class ClientAccessSettings
{
    /// <summary>
    /// Реалм по умолчанию для поиска пользователей
    /// </summary>
    public string DefaultSearchRealm { get; init; } = "internal-bank-idm";
    
    /// <summary>
    /// Минимальная длина поискового запроса
    /// </summary>
    public int MinSearchQueryLength { get; init; } = 2;
    
    /// <summary>
    /// Размер страницы по умолчанию для пагинации
    /// </summary>
    public int DefaultPageSize { get; init; } = 10;
    
    /// <summary>
    /// Максимальный размер страницы для пагинации
    /// </summary>
    public int MaxPageSize { get; init; } = 100;
    
    /// <summary>
    /// Задержка debouncing для поиска (в миллисекундах)
    /// </summary>
    public int SearchDebounceMs { get; init; } = 500;
    
    /// <summary>
    /// Таймаут для операций поиска (в секундах)
    /// </summary>
    public int SearchTimeoutSeconds { get; init; } = 30;
    
    /// <summary>
    /// Время жизни кэша запрещенных клиентов (в минутах)
    /// </summary>
    public int ForbiddenClientsCacheTtlMinutes { get; init; } = 5;
}
