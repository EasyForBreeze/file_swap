namespace new_assistant.Configuration;

/// <summary>
/// Настройки путей к данным приложения
/// </summary>
public class DataPathsSettings
{
    /// <summary>
    /// Корневая директория для всех данных
    /// </summary>
    public string DataDirectory { get; set; } = "Data";
    
    /// <summary>
    /// Директория для архивов с учетными данными клиентов
    /// </summary>
    public string ArchivesDirectory { get; set; } = "Data/Archives";
    
    /// <summary>
    /// Директория для лог-файлов
    /// </summary>
    public string LogsDirectory { get; set; } = "Data/logs";
    
    /// <summary>
    /// Путь к базе данных аудита
    /// </summary>
    public string AuditDbPath { get; set; } = "Data/audit.db";
    
    /// <summary>
    /// Путь к базе данных запрещенных клиентов
    /// </summary>
    public string ForbiddenClientsDbPath { get; set; } = "Data/forbidden_clients.db";
    
    /// <summary>
    /// Путь к базе данных Wiki-страниц
    /// </summary>
    public string WikiPagesDbPath { get; set; } = "Data/wiki_pages.db";
    
    /// <summary>
    /// Путь к базе данных владения клиентами
    /// </summary>
    public string OwnershipDbPath { get; set; } = "Data/ownership.db";
    
    /// <summary>
    /// Получить абсолютный путь относительно текущей директории
    /// </summary>
    public string GetAbsolutePath(string relativePath)
    {
        if (Path.IsPathRooted(relativePath))
        {
            return relativePath;
        }
        
        return Path.Combine(Directory.GetCurrentDirectory(), relativePath);
    }
    
    /// <summary>
    /// Получить абсолютный путь к директории данных
    /// </summary>
    public string GetDataDirectoryPath() => GetAbsolutePath(DataDirectory);
    
    /// <summary>
    /// Получить абсолютный путь к директории архивов
    /// </summary>
    public string GetArchivesDirectoryPath() => GetAbsolutePath(ArchivesDirectory);
    
    /// <summary>
    /// Получить абсолютный путь к директории логов
    /// </summary>
    public string GetLogsDirectoryPath() => GetAbsolutePath(LogsDirectory);
    
    /// <summary>
    /// Получить абсолютный путь к БД аудита
    /// </summary>
    public string GetAuditDbPath() => GetAbsolutePath(AuditDbPath);
    
    /// <summary>
    /// Получить абсолютный путь к БД запрещенных клиентов
    /// </summary>
    public string GetForbiddenClientsDbPath() => GetAbsolutePath(ForbiddenClientsDbPath);
    
    /// <summary>
    /// Получить абсолютный путь к БД Wiki-страниц
    /// </summary>
    public string GetWikiPagesDbPath() => GetAbsolutePath(WikiPagesDbPath);
    
    /// <summary>
    /// Получить абсолютный путь к БД владения
    /// </summary>
    public string GetOwnershipDbPath() => GetAbsolutePath(OwnershipDbPath);
    
    /// <summary>
    /// Создать все необходимые директории
    /// </summary>
    public void EnsureDirectoriesExist()
    {
        var directories = new[]
        {
            GetDataDirectoryPath(),
            GetArchivesDirectoryPath(),
            GetLogsDirectoryPath()
        };
        
        foreach (var dir in directories)
        {
            Directory.CreateDirectory(dir);
        }
    }
}

