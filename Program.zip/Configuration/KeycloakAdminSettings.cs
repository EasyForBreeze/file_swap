namespace new_assistant.Configuration;

/// <summary>
/// Настройки для работы с Keycloak Admin API
/// </summary>
public sealed class KeycloakAdminSettings
{
    /// <summary>
    /// Базовый URL Keycloak сервера
    /// </summary>
    public string BaseUrl { get; init; } = string.Empty;
    
    /// <summary>
    /// Основной реалм для админ операций
    /// </summary>
    public string Realm { get; init; } = string.Empty;
    
    /// <summary>
    /// Client ID для админ клиента
    /// </summary>
    public string ClientId { get; init; } = string.Empty;
    
    /// <summary>
    /// Client Secret для админ клиента
    /// </summary>
    public string ClientSecret { get; init; } = string.Empty;
    
    /// <summary>
    /// Использовать устаревший путь для аутентификации
    /// </summary>
    public bool UseLegacyAuthPath { get; init; } = false;
    
    /// <summary>
    /// Максимальное время ожидания запроса (в секундах)
    /// </summary>
    public int RequestTimeoutSeconds { get; init; } = 30;
    
    /// <summary>
    /// Максимальное количество результатов поиска
    /// </summary>
    public int MaxSearchResults { get; init; } = 10;
    
    /// <summary>
    /// Максимальное количество параллельных запросов
    /// </summary>
    public int MaxConcurrentRequests { get; init; } = 3;
    
    /// <summary>
    /// Реалмы, которые следует исключить из поиска
    /// </summary>
    public List<string> ExcludedRealms { get; } = new() { "master" };
    
    /// <summary>
    /// Настройки для работы с ролями
    /// </summary>
    public KeycloakRolesSettings Roles { get; init; } = new();
}

/// <summary>
/// Настройки для работы с ролями Keycloak
/// </summary>
public sealed class KeycloakRolesSettings
{
    /// <summary>
    /// Время кэширования ролей. Роли редко меняются, поэтому используем кэш на 5 минут по умолчанию.
    /// </summary>
    public TimeSpan CacheDuration { get; init; } = TimeSpan.FromMinutes(5);
    
    /// <summary>
    /// Максимальное количество ролей в одном batch запросе
    /// </summary>
    public int MaxBatchSize { get; init; } = 1000;
    
    /// <summary>
    /// Значение по умолчанию для максимального количества ролей в запросе.
    /// Keycloak UI использует 100, добавляем 1 для проверки наличия следующей страницы (пагинация).
    /// </summary>
    public int DefaultMaxRolesPerRequest { get; init; } = 101;
    
    /// <summary>
    /// Максимальный размер JSON контента в байтах (1 MB - лимит Keycloak API)
    /// </summary>
    public int MaxJsonContentSizeBytes { get; init; } = 1024 * 1024;
    
    /// <summary>
    /// Максимальная длина описания роли в символах
    /// </summary>
    public int MaxRoleDescriptionLength { get; init; } = 1000;
    
    /// <summary>
    /// Максимальная длина названия роли в символах
    /// </summary>
    public int MaxRoleNameLength { get; init; } = 255;
    
    /// <summary>
    /// Максимальная длина ID роли в символах
    /// </summary>
    public int MaxRoleIdLength { get; init; } = 100;
}
