namespace new_assistant.Configuration;

/// <summary>
/// Настройки сервиса управления состоянием поиска и кэширования
/// </summary>
public sealed class SearchStateServiceSettings
{
    /// <summary>
    /// Максимальный размер кэша клиентов пользователя
    /// </summary>
    /// <remarks>
    /// Если количество клиентов превышает это значение, кэш будет ограничен до самых свежих записей.
    /// </remarks>
    public int MaxCacheSize { get; init; } = 1000;

    /// <summary>
    /// Время жизни кэша клиентов пользователя по умолчанию
    /// </summary>
    /// <remarks>
    /// Используется UTC время для всех операций с кэшем.
    /// </remarks>
    public TimeSpan DefaultCacheExpiration { get; init; } = TimeSpan.FromMinutes(10);

    /// <summary>
    /// Включить автоматическую инвалидацию кэша при проверке
    /// </summary>
    public bool EnableAutoInvalidation { get; init; } = true;

    /// <summary>
    /// Интервал очистки устаревших состояний пользователей (в минутах)
    /// </summary>
    /// <remarks>
    /// Если установлено в 0, автоматическая очистка отключена.
    /// </remarks>
    public int CleanupIntervalMinutes { get; init; } = 60;
}

