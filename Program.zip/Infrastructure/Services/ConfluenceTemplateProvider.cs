using System.Collections.Concurrent;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.Constants;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Провайдер шаблонов для страниц Confluence с поддержкой загрузки из файлов,
/// валидации и обработки ошибок
/// </summary>
public sealed class ConfluenceTemplateProvider : IConfluenceTemplateProvider, IDisposable
{
    private readonly ConfluenceTemplateSettings _settings;
    private readonly ILogger<ConfluenceTemplateProvider> _logger;
    private readonly IMemoryCache? _cache;
    private readonly ConcurrentDictionary<string, TemplatePayload> _templates = new(StringComparer.OrdinalIgnoreCase);
    private FileSystemWatcher? _fileWatcher;
    private readonly ReaderWriterLockSlim _rwLock = new(LockRecursionPolicy.NoRecursion);
    private DateTime _lastFileChangeTime = DateTime.MinValue;
    private readonly ConcurrentDictionary<string, string> _keyCache = new(StringComparer.OrdinalIgnoreCase);
    private readonly ConcurrentDictionary<string, bool> _fileExistsCache = new(StringComparer.OrdinalIgnoreCase);
    private volatile bool _isDisposing = false;
    private readonly SemaphoreSlim _fileWatcherSemaphore = new(1, 1);
    
    // Метрики для мониторинга
    private long _templatesLoadedCount = 0;
    private long _templatesLoadedFromCacheCount = 0;
    private long _templatesLoadedFromFileCount = 0;
    private long _templateLoadErrorsCount = 0;
    private long _fileWatcherEventsCount = 0;

    // Кэшированные скомпилированные Regex для производительности
    private static readonly Regex Placeholder0Regex = new(@"\{0\}", RegexOptions.Compiled | RegexOptions.CultureInvariant);
    private static readonly Regex Placeholder1Regex = new(@"\{1\}", RegexOptions.Compiled | RegexOptions.CultureInvariant);
    private static readonly Regex AllPlaceholdersRegex = new(@"\{[^}]*\}", RegexOptions.Compiled | RegexOptions.CultureInvariant);
    private static readonly Regex VersionRegex = new(@"<!--\s*Template Version:\s*(\d+\.\d+)\s*-->", RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
    private static readonly Regex LastUpdatedRegex = new(@"<!--\s*Last Updated:\s*(\d{4}-\d{2}-\d{2}(?:\s+\d{2}:\d{2}:\d{2})?)\s*-->", RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

    // Константы
    private const string DefaultTitleFormat = "{0}-BNK. {1}"; // {0} — префикс из первых 3 символов realm, {1} — ClientID
    private const string DefaultTemplateName = "default";
    private const string CacheKeyPrefix = "ConfluenceTemplate";
    private static readonly TimeSpan CacheExpiration = TimeSpan.FromHours(1);
    private const int MaxTemplateNameLength = 255;
    private const int MaxCultureLength = 50;
    private const int FileExistsCacheTimeoutSeconds = 5;
    private static readonly Encoding Utf8Encoding = Encoding.UTF8;

    // Минимальное значение для CacheExpiration
    private static readonly TimeSpan MinCacheExpiration = TimeSpan.FromMinutes(1);
    private static readonly TimeSpan ValidCacheExpiration = CacheExpiration < MinCacheExpiration ? MinCacheExpiration : CacheExpiration;

    public ConfluenceTemplateProvider(
        IOptions<ConfluenceTemplateSettings> settings,
        ILogger<ConfluenceTemplateProvider> logger,
        IMemoryCache? cache = null)
    {
        _settings = settings?.Value ?? throw new ArgumentNullException(nameof(settings));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _cache = cache;
        
        // Валидация настроек
        ValidateSettings();
        
        // Загружаем все шаблоны из директории, если указана
        LoadAllTemplates();
        
        // Настраиваем file watcher для hot-reload, если указан путь к файлу
        SetupFileWatcher();
    }

    private void ValidateSettings()
    {
        if (string.IsNullOrWhiteSpace(_settings.Version))
        {
            _logger.LogWarning("Template version is empty, using default: 1.0");
            _settings.Version = "1.0";
        }
        
        if (!IsValidVersion(_settings.Version))
        {
            _logger.LogWarning("Invalid template version format: {Version}, using default: 1.0", _settings.Version);
            _settings.Version = "1.0";
        }
    }

    private static bool IsValidVersion(string version)
    {
        if (string.IsNullOrWhiteSpace(version))
            return false;
        
        return System.Version.TryParse(version, out _);
    }

    public TemplatePayload Template => GetTemplate(DefaultTemplateName);

    public TemplatePayload GetTemplate(string? templateName = null, string? culture = null)
    {
        templateName ??= DefaultTemplateName;
        culture ??= _settings.DefaultCulture ?? CultureInfo.CurrentCulture.Name;

        // Валидация параметров
        if (templateName.Length > MaxTemplateNameLength)
        {
            _logger.LogWarning("Template name exceeds maximum length ({Length} > {MaxLength}), truncating", templateName.Length, MaxTemplateNameLength);
            templateName = templateName.Substring(0, MaxTemplateNameLength);
        }

        if (culture.Length > MaxCultureLength)
        {
            _logger.LogWarning("Culture exceeds maximum length ({Length} > {MaxLength}), using default", culture.Length, MaxCultureLength);
            culture = _settings.DefaultCulture ?? CultureInfo.CurrentCulture.Name;
        }

        var cacheKey = GetCacheKey(templateName, culture);
        
        // Проверяем кэш (без блокировки для чтения)
        if (_cache != null && _cache.TryGetValue<TemplatePayload>(cacheKey, out var cached) && cached != null)
        {
            Interlocked.Increment(ref _templatesLoadedFromCacheCount);
            return cached;
        }

        // Используем read lock для чтения из словаря
        _rwLock.EnterReadLock();
        try
        {
            // Double-check locking
            if (_cache != null && _cache.TryGetValue<TemplatePayload>(cacheKey, out cached) && cached != null)
            {
                return cached;
            }

            var templateKey = GetTemplateKey(templateName, culture);
            if (_templates.TryGetValue(templateKey, out var template) && template != null)
            {
                // Обновляем кэш асинхронно (без блокировки)
                UpdateCache(cacheKey, template);
                return template;
            }
        }
        finally
        {
            _rwLock.ExitReadLock();
        }

        // Используем write lock для записи
        _rwLock.EnterWriteLock();
        try
        {
            // Проверяем еще раз после получения write lock
            if (_cache != null && _cache.TryGetValue<TemplatePayload>(cacheKey, out cached) && cached != null)
            {
                return cached;
            }

            var templateKey = GetTemplateKey(templateName, culture);
            if (_templates.TryGetValue(templateKey, out var template) && template != null)
            {
                UpdateCache(cacheKey, template);
                return template;
            }

            // Пытаемся загрузить из файла с учетом локализации
            if (TryLoadTemplateFromFile(templateName, culture, out template) && template != null)
            {
                _templates[templateKey] = template;
                Interlocked.Increment(ref _templatesLoadedFromFileCount);
                Interlocked.Increment(ref _templatesLoadedCount);
                UpdateCache(cacheKey, template);
                return template;
            }

            // Fallback на шаблон по умолчанию для fallback культуры
            if (culture != _settings.FallbackCulture && TryLoadTemplateFromFile(templateName, _settings.FallbackCulture, out template) && template != null)
            {
                _logger.LogInformation(
                    "Template {TemplateName} not found for culture {Culture}, using fallback culture {FallbackCulture}. " +
                    "Template will be cached with key {TemplateKey} for requested culture.",
                    templateName, culture, _settings.FallbackCulture, templateKey);
                // Сохраняем с ключом запрошенной культуры, чтобы последующие запросы использовали кэш
                _templates[templateKey] = template;
                UpdateCache(cacheKey, template);
                return template;
            }

            // Fallback на встроенный шаблон
            _logger.LogWarning("Template {TemplateName} not found for culture {Culture}, using embedded template",
                templateName, culture);
            template = CreateEmbeddedTemplate();
            _templates[templateKey] = template;
            UpdateCache(cacheKey, template);
            return template;
        }
        finally
        {
            _rwLock.ExitWriteLock();
        }
    }

    private void UpdateCache(string cacheKey, TemplatePayload template)
    {
        if (_cache != null && template != null)
        {
            var cacheOptions = new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = ValidCacheExpiration,
                Size = 1 // Указываем размер для MemoryCache с SizeLimit
            };
            _cache.Set(cacheKey, template, cacheOptions);
        }
    }

    public TemplatePayload GetTemplateForCulture(string? culture = null)
    {
        return GetTemplate(DefaultTemplateName, culture);
    }

    public bool TemplateExists(string templateName, string? culture = null)
    {
        if (string.IsNullOrWhiteSpace(templateName))
        {
            return false;
        }

        // Валидация длины
        if (templateName.Length > MaxTemplateNameLength)
        {
            return false;
        }

        culture ??= _settings.DefaultCulture ?? CultureInfo.CurrentCulture.Name;

        if (culture.Length > MaxCultureLength)
        {
            culture = _settings.DefaultCulture ?? CultureInfo.CurrentCulture.Name;
        }

        var templateKey = GetTemplateKey(templateName, culture);

        // Проверяем в загруженных шаблонах (без блокировки для чтения)
        if (_templates.ContainsKey(templateKey))
        {
            return true;
        }

        // Проверяем существование файла с кэшированием
        try
        {
            // Сначала пробуем из TemplatesDirectory
            if (!string.IsNullOrWhiteSpace(_settings.TemplatesDirectory))
            {
                var templatePath = GetTemplateFilePath(templateName, culture);
                return FileExistsCached(templatePath);
            }

            // Fallback на TemplatePath для обратной совместимости
            if (templateName == DefaultTemplateName && !string.IsNullOrWhiteSpace(_settings.TemplatePath))
            {
                return FileExistsCached(_settings.TemplatePath);
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Failed to check template existence: {TemplateName} for culture {Culture}", templateName, culture);
        }

        return false;
    }

    private bool FileExistsCached(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
            return false;

        var cacheKey = $"file_exists:{path}";
        var now = DateTime.UtcNow;

        // Проверяем кэш (упрощенная версия без TTL словаря)
        // В реальности лучше использовать MemoryCache с TTL, но для простоты используем простой подход
        // Кэш будет очищаться при изменении файлов через FileSystemWatcher
        if (_fileExistsCache.TryGetValue(cacheKey, out var cached))
        {
            return cached;
        }

        var exists = File.Exists(path);
        _fileExistsCache[cacheKey] = exists;
        return exists;
    }

    public string GetTitle(string realmPrefix, string clientId, string? templateName = null)
    {
        if (string.IsNullOrWhiteSpace(realmPrefix))
            throw new ArgumentException("Realm prefix cannot be null or empty", nameof(realmPrefix));
        
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));

        // Получаем шаблон для извлечения формата заголовка
        var template = GetTemplate(templateName);
        var titleFormat = template.Title;

        // Валидация формата перед использованием
        if (!IsValidTitleFormat(titleFormat))
        {
            _logger.LogWarning("Title format validation failed: {Format}, using default", titleFormat);
            titleFormat = _settings.TitleFormat ?? DefaultTitleFormat;
        }
        
        try
        {
            // Используем string interpolation вместо string.Format для лучшей производительности
            // Но так как формат динамический, используем string.Format
            return string.Format(CultureInfo.InvariantCulture, titleFormat, realmPrefix, clientId);
        }
        catch (FormatException ex)
        {
            _logger.LogError(ex, "Invalid title format: {Format}", titleFormat);
            // Fallback на безопасный формат
            return $"{realmPrefix}-BNK. {clientId}";
        }
    }

    private bool IsValidTitleFormat(string format)
    {
        if (string.IsNullOrWhiteSpace(format))
        {
            return false;
        }

        // Используем кэшированные скомпилированные Regex
        var placeholder0Matches = Placeholder0Regex.Matches(format);
        var placeholder1Matches = Placeholder1Regex.Matches(format);

        if (placeholder0Matches.Count != 1 || placeholder1Matches.Count != 1)
        {
            _logger.LogWarning("Title format must contain exactly one {{0}} and one {{1}} placeholder. Found: {{0}}={Count0}, {{1}}={Count1}",
                placeholder0Matches.Count, placeholder1Matches.Count);
            return false;
        }

        // Проверяем, что нет других плейсхолдеров
        var allPlaceholders = AllPlaceholdersRegex.Matches(format);
        if (allPlaceholders.Count > 2)
        {
            _logger.LogWarning("Title format contains unexpected placeholders");
            return false;
        }

        return true;
    }

    public bool ValidatePlaceholders(string template)
    {
        if (string.IsNullOrWhiteSpace(template))
        {
            _logger.LogWarning("Template is null or empty");
            return false;
        }

        // Оптимизация: используем IndexOf вместо Contains для больших шаблонов
        var missing = new List<string>();
        foreach (var placeholder in TemplatePlaceholders.Required)
        {
            if (template.IndexOf(placeholder, StringComparison.Ordinal) < 0)
            {
                missing.Add(placeholder);
            }
        }

        if (missing.Count > 0)
        {
            // Оптимизированное создание сообщения об ошибке
            var placeholdersString = missing.Count == 1 
                ? missing[0] 
                : string.Join(", ", missing);
            _logger.LogWarning("Template missing placeholders: {Placeholders}", placeholdersString);
            return false;
        }

        return true;
    }

    private void LoadAllTemplates()
    {
        try
        {
            var templatesDir = _settings.TemplatesDirectory;
            if (string.IsNullOrWhiteSpace(templatesDir))
            {
                _logger.LogDebug("Templates directory not specified");
                return;
            }

            // Безопасная проверка существования директории
            if (!Directory.Exists(templatesDir))
            {
                _logger.LogDebug("Templates directory does not exist: {Directory}", templatesDir);
                return;
            }

            _logger.LogInformation("Loading templates from directory: {Directory}", templatesDir);

            // Оптимизация: используем EnumerateDirectories для лучшей производительности
            var cultureDirs = Directory.EnumerateDirectories(templatesDir);
            var loadedCount = 0;
            var skippedCount = 0;

            foreach (var cultureDir in cultureDirs)
            {
                try
                {
                    // Проверка существования директории перед обработкой
                    if (!Directory.Exists(cultureDir))
                    {
                        continue;
                    }

                    var culture = Path.GetFileName(cultureDir);
                    
                    // Валидация culture
                    if (string.IsNullOrWhiteSpace(culture) || culture.Length > MaxCultureLength || 
                        ContainsInvalidPathChars(culture))
                    {
                        _logger.LogWarning("Invalid culture name in directory: {Directory}", cultureDir);
                        continue;
                    }

                    // Оптимизация: используем EnumerateFiles для лучшей производительности
                    var templateFiles = Directory.EnumerateFiles(cultureDir, "*.html");

                    foreach (var templateFile in templateFiles)
                    {
                        try
                        {
                            var templateName = Path.GetFileNameWithoutExtension(templateFile);
                            
                            // Валидация templateName
                            if (string.IsNullOrWhiteSpace(templateName) || templateName.Length > MaxTemplateNameLength)
                            {
                                _logger.LogWarning("Invalid template name in file: {Path}", templateFile);
                                skippedCount++;
                                continue;
                            }

                            var templateKey = GetTemplateKey(templateName, culture);

                            // Загрузка шаблона из файла
                            if (TryLoadTemplateFromFileInternal(templateFile, templateName, culture, out var template))
                            {
                                _rwLock.EnterWriteLock();
                                try
                                {
                                    _templates[templateKey] = template!;
                                    loadedCount++;
                                    _logger.LogDebug("Template loaded: {TemplateName} for culture {Culture}", templateName, culture);
                                }
                                finally
                                {
                                    _rwLock.ExitWriteLock();
                                }
                            }
                            else
                            {
                                skippedCount++;
                            }
                        }
                        catch (Exception ex)
                        {
                            skippedCount++;
                            Interlocked.Increment(ref _templateLoadErrorsCount);
                            _logger.LogWarning(ex, "Failed to load template from file: {Path}", templateFile);
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Failed to process culture directory: {Directory}", cultureDir);
                }
            }

            _logger.LogInformation("Loaded {LoadedCount} templates from directory, skipped {SkippedCount}", loadedCount, skippedCount);
        }
        catch (Exception ex)
        {
            Interlocked.Increment(ref _templateLoadErrorsCount);
            _logger.LogError(ex, "Failed to load templates from directory");
        }
    }

    private static bool ContainsInvalidPathChars(string path)
    {
        return path.IndexOfAny(Path.GetInvalidPathChars()) >= 0;
    }

    private bool TryLoadTemplateFromFile(string templateName, string culture, out TemplatePayload template)
    {
        template = null!;

        try
        {
            // Сначала пробуем загрузить из TemplatesDirectory
            if (!string.IsNullOrWhiteSpace(_settings.TemplatesDirectory))
            {
                var templatePath = GetTemplateFilePath(templateName, culture);
                if (FileExistsCached(templatePath))
                {
                    return TryLoadTemplateFromFileInternal(templatePath, templateName, culture, out template);
                }
            }

            // Fallback на TemplatePath (для обратной совместимости)
            if (templateName == DefaultTemplateName && !string.IsNullOrWhiteSpace(_settings.TemplatePath))
            {
                if (FileExistsCached(_settings.TemplatePath))
                {
                    return TryLoadTemplateFromFileInternal(_settings.TemplatePath, templateName, culture, out template);
                }
            }

            return false;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to load template {TemplateName} for culture {Culture}", templateName, culture);
            return false;
        }
    }

    private bool TryLoadTemplateFromFileInternal(string templatePath, string templateName, string culture, out TemplatePayload template)
    {
        template = null!;
        
        try
        {
            if (string.IsNullOrWhiteSpace(templatePath))
            {
                return false;
            }

            // Безопасная проверка существования файла
            if (!FileExistsCached(templatePath))
            {
                return false;
            }

            // Оптимизированное чтение файла
            string content;
            try
            {
                content = File.ReadAllText(templatePath, Utf8Encoding);
            }
            catch (IOException ex)
            {
                _logger.LogWarning(ex, "Failed to read template file (IO error): {Path}", templatePath);
                return false;
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogWarning(ex, "Access denied to template file: {Path}", templatePath);
                return false;
            }

            if (string.IsNullOrWhiteSpace(content))
            {
                _logger.LogWarning("Template file is empty: {Path}", templatePath);
                return false;
            }

            // Извлечение версии с валидацией
            var extractedVersion = ExtractVersion(content);
            var version = !string.IsNullOrWhiteSpace(extractedVersion) && IsValidVersion(extractedVersion)
                ? extractedVersion
                : _settings.Version;

            // Извлечение даты последнего обновления с валидацией
            var lastUpdated = ExtractLastUpdated(content);
            
            // Безопасное чтение времени изменения файла
            DateTime fileLastWriteTime;
            try
            {
                fileLastWriteTime = File.GetLastWriteTimeUtc(templatePath);
                
                // Валидация: дата не должна быть в будущем
                var now = DateTime.UtcNow;
                if (fileLastWriteTime > now)
                {
                    _logger.LogWarning("File last write time is in the future: {Time}, using current time", fileLastWriteTime);
                    fileLastWriteTime = now;
                }
            }
            catch (IOException ex)
            {
                _logger.LogWarning(ex, "Failed to get file last write time: {Path}, using current time", templatePath);
                fileLastWriteTime = DateTime.UtcNow;
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogWarning(ex, "Access denied when getting file last write time: {Path}, using current time", templatePath);
                fileLastWriteTime = DateTime.UtcNow;
            }

            // Используем дату из комментария, если она валидна, иначе дату изменения файла
            DateTime? templateLastUpdated = null;
            if (lastUpdated.HasValue)
            {
                var now = DateTime.UtcNow;
                // Валидация: дата не должна быть в будущем
                if (lastUpdated.Value <= now)
                {
                    templateLastUpdated = lastUpdated.Value;
                }
                else
                {
                    _logger.LogWarning("Last updated date from template is in the future: {Time}, using file write time", lastUpdated.Value);
                }
            }
            
            templateLastUpdated ??= fileLastWriteTime;
            
            template = new TemplatePayload(
                _settings.TitleFormat ?? DefaultTitleFormat,
                content,
                version)
            {
                LastUpdated = templateLastUpdated
            };

            // Валидация плейсхолдеров
            if (!ValidatePlaceholders(template.Body))
            {
                _logger.LogWarning("Template validation failed, skipping: {Path}", templatePath);
                return false;
            }
            
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to load template from file: {Path}", templatePath);
            return false;
        }
    }

    private string GetTemplateFilePath(string templateName, string culture)
    {
        if (string.IsNullOrWhiteSpace(_settings.TemplatesDirectory))
        {
            throw new InvalidOperationException(
                $"TemplatesDirectory is not configured. Cannot get file path for template '{templateName}' and culture '{culture}'.");
        }

        // Валидация культуры
        if (string.IsNullOrWhiteSpace(culture))
        {
            throw new ArgumentException("Culture cannot be null or empty", nameof(culture));
        }

        if (culture.Length > MaxCultureLength)
        {
            throw new ArgumentException($"Culture exceeds maximum length: {MaxCultureLength}", nameof(culture));
        }

        // Проверка на недопустимые символы в culture
        if (ContainsInvalidPathChars(culture))
        {
            throw new ArgumentException($"Culture contains invalid characters: {culture}", nameof(culture));
        }

        // Валидация имени шаблона
        if (string.IsNullOrWhiteSpace(templateName))
        {
            throw new ArgumentException("Template name cannot be null or empty", nameof(templateName));
        }

        if (templateName.Length > MaxTemplateNameLength)
        {
            throw new ArgumentException($"Template name exceeds maximum length: {MaxTemplateNameLength}", nameof(templateName));
        }

        // Проверка на небезопасные символы в имени шаблона (защита от path traversal)
        if (templateName.Contains("..", StringComparison.Ordinal) || 
            templateName.Contains(Path.DirectorySeparatorChar) ||
            templateName.Contains(Path.AltDirectorySeparatorChar) ||
            ContainsInvalidPathChars(templateName))
        {
            throw new ArgumentException($"Template name contains invalid characters: {templateName}", nameof(templateName));
        }

        var filePath = Path.Combine(_settings.TemplatesDirectory, culture, $"{templateName}.html");
        
        // Валидация результирующего пути (защита от path traversal)
        var fullPath = Path.GetFullPath(filePath);
        var templatesDirFullPath = Path.GetFullPath(_settings.TemplatesDirectory);
        
        if (!fullPath.StartsWith(templatesDirFullPath, StringComparison.Ordinal))
        {
            throw new ArgumentException($"Invalid file path: resolved path does not start with templates directory", nameof(templateName));
        }

        return filePath;
    }

    private string GetTemplateKey(string templateName, string culture)
    {
        var key = $"{culture}:{templateName}";
        return _keyCache.GetOrAdd(key, k => k);
    }

    private string GetCacheKey(string templateName, string culture)
    {
        var key = $"{CacheKeyPrefix}:{culture}:{templateName}";
        return _keyCache.GetOrAdd(key, k => k);
    }

    private TemplatePayload CreateEmbeddedTemplate()
    {
        return new TemplatePayload(
            _settings.TitleFormat ?? DefaultTitleFormat,
            EmbeddedTemplateBody,
            _settings.Version);
    }

    private string? ExtractVersion(string template)
    {
        try
        {
            // Используем кэшированный скомпилированный Regex
            var match = VersionRegex.Match(template);
            if (match.Success)
            {
                var version = match.Groups[1].Value;
                // Валидация версии
                return IsValidVersion(version) ? version : null;
            }
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Failed to extract version from template");
            return null;
        }
    }

    private DateTime? ExtractLastUpdated(string template)
    {
        try
        {
            // Используем кэшированный скомпилированный Regex
            var match = LastUpdatedRegex.Match(template);
            
            if (match.Success)
            {
                var dateString = match.Groups[1].Value;
                // Используем более строгий парсинг с InvariantCulture
                if (DateTime.TryParse(dateString, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out var date))
                {
                    return date;
                }
            }
            
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Failed to extract last updated date from template");
            return null;
        }
    }

    private int CountPlaceholders(string template)
    {
        // Оптимизация: используем IndexOf вместо Contains для лучшей производительности
        int count = 0;
        foreach (var placeholder in TemplatePlaceholders.Required)
        {
            if (template.IndexOf(placeholder, StringComparison.Ordinal) >= 0)
            {
                count++;
            }
        }
        return count;
    }

    private void SetupFileWatcher()
    {
        try
        {
            // Настраиваем watcher для TemplatesDirectory, если указана
            if (!string.IsNullOrWhiteSpace(_settings.TemplatesDirectory))
            {
                // Безопасная проверка существования директории
                string templatesDir;
                try
                {
                    templatesDir = Path.GetFullPath(_settings.TemplatesDirectory);
                    if (!Directory.Exists(templatesDir))
                    {
                        _logger.LogDebug("Templates directory does not exist, skipping file watcher setup: {Path}", templatesDir);
                        return;
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Failed to resolve templates directory path, skipping file watcher setup: {Path}", _settings.TemplatesDirectory);
                    return;
                }

                try
                {
                    _fileWatcher = new FileSystemWatcher(templatesDir)
                    {
                        NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.Size | NotifyFilters.FileName,
                        IncludeSubdirectories = true,
                        EnableRaisingEvents = true,
                        Filter = "*.html"
                    };

                    _fileWatcher.Changed += OnTemplateFileChanged;
                    _fileWatcher.Created += OnTemplateFileChanged;
                    _fileWatcher.Deleted += OnTemplateFileChanged;
                    _fileWatcher.Error += OnFileWatcherError;
                    _logger.LogInformation("File watcher configured for templates directory: {Path}", templatesDir);
                    return;
                }
                catch (UnauthorizedAccessException ex)
                {
                    _logger.LogWarning(ex, "Access denied when creating file watcher for templates directory: {Path}", templatesDir);
                    return;
                }
                catch (ArgumentException ex)
                {
                    _logger.LogWarning(ex, "Invalid path for file watcher: {Path}", templatesDir);
                    return;
                }
            }

            // Fallback на TemplatePath для обратной совместимости
            var templatePath = _settings.TemplatePath;
            if (string.IsNullOrWhiteSpace(templatePath))
            {
                return;
            }

            try
            {
                if (!File.Exists(templatePath))
                {
                    return;
                }

                var directory = Path.GetDirectoryName(templatePath);
                var fileName = Path.GetFileName(templatePath);
                
                if (string.IsNullOrWhiteSpace(directory) || !Directory.Exists(directory))
                {
                    return;
                }

                _fileWatcher = new FileSystemWatcher(directory, fileName)
                {
                    NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.Size,
                    EnableRaisingEvents = true
                };

                _fileWatcher.Changed += OnTemplateFileChanged;
                _fileWatcher.Error += OnFileWatcherError;
                _logger.LogInformation("File watcher configured for template: {Path}", templatePath);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to setup file watcher for template path: {Path}", templatePath);
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to setup file watcher for template");
        }
    }

    private void OnFileWatcherError(object sender, ErrorEventArgs e)
    {
        _logger.LogError(e.GetException(), "FileSystemWatcher error occurred");
    }

    private void OnTemplateFileChanged(object sender, FileSystemEventArgs e)
    {
        // Защита от вызова во время dispose
        if (_isDisposing)
        {
            return;
        }

        // Используем семафор для предотвращения одновременных вызовов (неблокирующая проверка)
        if (!_fileWatcherSemaphore.Wait(0))
        {
            return;
        }

        try
        {
            // FileSystemWatcher может сработать дважды, игнорируем повторные события в течение 1 секунды
            var now = DateTime.UtcNow;
            var timeDifference = (now - _lastFileChangeTime).TotalSeconds;
            
            // Проверка на валидность разницы во времени (защита от переполнения)
            if (timeDifference > 0 && timeDifference < 1)
            {
                return;
            }

            // Проверка на отрицательную разницу (переполнение или сброс времени)
            if (timeDifference < 0)
            {
                _logger.LogWarning("Negative time difference detected, resetting last file change time");
            }

            _lastFileChangeTime = now;

            Interlocked.Increment(ref _fileWatcherEventsCount);
            _logger.LogInformation("Template file changed: {Path}, reloading templates...", e.FullPath);
            
            // Используем write lock для безопасной очистки
            _rwLock.EnterWriteLock();
            try
            {
                // Безопасная очистка словаря шаблонов
                // ConcurrentDictionary.Clear() потокобезопасен, но мы делаем это под lock для консистентности
                _templates.Clear();

                // Очищаем кэш существования файлов при изменении
                _fileExistsCache.Clear();

                // Инвалидируем все кэши (удаляем все ключи с префиксом)
                if (_cache != null)
                {
                    // К сожалению, IMemoryCache не поддерживает удаление по паттерну,
                    // поэтому просто перезагружаем все шаблоны
                    _logger.LogDebug("Cache invalidation: templates will be reloaded on next access");
                }

                // Перезагружаем все шаблоны
                LoadAllTemplates();
            }
            finally
            {
                _rwLock.ExitWriteLock();
            }
        }
        catch (ObjectDisposedException)
        {
            // Игнорируем, если объект уже освобожден
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error handling template file change: {Path}", e.FullPath);
        }
        finally
        {
            _fileWatcherSemaphore.Release();
        }
    }

    public void Dispose()
    {
        if (_isDisposing)
        {
            return;
        }

        _isDisposing = true;

        try
        {
            // Ожидаем завершения всех операций с файловым watcher
            // Используем Wait с timeout для избежания бесконечного ожидания
            if (!_fileWatcherSemaphore.Wait(TimeSpan.FromSeconds(5)))
            {
                _logger.LogWarning("Timeout waiting for file watcher semaphore during dispose");
            }

            try
            {
                // Отписываемся от событий перед освобождением
                if (_fileWatcher != null)
                {
                    _fileWatcher.Changed -= OnTemplateFileChanged;
                    _fileWatcher.Created -= OnTemplateFileChanged;
                    _fileWatcher.Deleted -= OnTemplateFileChanged;
                    _fileWatcher.Error -= OnFileWatcherError;
                    _fileWatcher.EnableRaisingEvents = false;
                    _fileWatcher.Dispose();
                    _fileWatcher = null;
                }
            }
            finally
            {
                _fileWatcherSemaphore.Release();
                _fileWatcherSemaphore.Dispose();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during Dispose");
        }
        finally
        {
            _rwLock.Dispose();
        }
    }

    // Встроенный шаблон как fallback
    private const string EmbeddedTemplateBody = """
<h2 class="auto-cursor-target">Общая информация</h2><ac:structured-macro ac:name="details" ac:schema-version="1" ac:macro-id="603005b4-1bd4-4dd8-87c7-1a038c368d0f"><ac:rich-text-body><p class="auto-cursor-target"><br /></p><table class="wrapped relative-table" style="width: 100.0%;"><colgroup><col style="width: 15.8659%;" /><col style="width: 84.1341%;" /></colgroup><tbody><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Банк/ДОМ</span></th><td>Банк</td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Информационная система</span></th>{{INFO_SYSTEM_CELL}}</tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Realm (Пространство)</span></th>{{REALM_CELL}}</tr><tr><th style="text-align: left;"><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Client ID (ID клиента)</span></th><td style="text-align: left;">{{CLIENT_ID}}</td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Name (Имя)</span></th><td>{{CLIENT_NAME}}</td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Access Type (Тип доступа)</span></th><td>{{ACCESS_TYPE}}</td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Status (Статус)</span></th><td>{{CLIENT_STATUS}}</td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Бизнес владелец</span></th>{{SERVICE_OWNER_CELL}}</tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Менеджер поддержки</span></th>{{SERVICE_MANAGER_CELL}}</tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Уровень критичности ИС</span></th><td><span style="color:var(--ds-text-accent-blue-bolder,#09326c);">BC</span></td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Заявка FTEST</span></th><td>{{TICKET_FTEST}}</td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Заявка PrePROD</span></th><td>{{TICKET_PREPROD}}</td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Заявка PROD</span></th><td>{{TICKET_PROD}}</td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Статус публикации</span></th><td><div class="content-wrapper"><p>{{PUBLICATION_STATUS}}</p></div></td></tr></tbody></table></ac:rich-text-body></ac:structured-macro><h2 class="auto-cursor-target"><span>Конфигурация клиента</span></h2><table class="relative-table wrapped" style="width: 99.0228%;"><colgroup><col style="width: 16.7215%;" /><col style="width: 83.2785%;" /></colgroup><tbody><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Description (Описание)</span></th><td>{{DESCRIPTION}}</td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Enabled (Включено)</span></th><td>enabled</td></tr><tr><th style="text-align: left;"><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Client Scopes</span></th><td style="text-align: left;">{{CLIENT_SCOPES}}</td></tr><tr><th style="text-align: left;"><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Full Scope Allowed</span></th><td style="text-align: left;"><span style="color:var(--ds-text-accent-blue-bolder,#09326c);">On</span></td></tr><tr><th style="text-align: left;"><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Standart flow</span></th><td style="text-align: left;">{{STANDARD_FLOW}}</td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Implicit Flow</span></th><td><span style="color:var(--ds-text-accent-blue-bolder,#09326c);">Off</span></td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Direct Access Grants </span></th><td>{{DIRECT_ACCESS_GRANTS}}</td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Service Accounts</span></th><td>{{SERVICE_ACCOUNTS}}</td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">OAuth 2.0 Device Authorization Grant</span></th><td>{{DEVICE_AUTHORIZATION}}</td></tr><tr><th style="text-align: left;"><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);"><strong style="text-align: left;">Valid Redirect URIs</strong></span></th><td style="text-align: left;">{{REDIRECT_TABLE}}<p class="auto-cursor-target"><br /></p></td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Valid post logout redirect URIs</span></th><td>+</td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Web Origins</span></th><td>+</td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Access Token Lifespan</span></th><td>5 min</td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Client Session Idle</span></th><td>30 min</td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Client Roles (Роль клиента)</span></th><td>{{LOCAL_ROLES_TABLE}}<p class="auto-cursor-target"><br /></p></td></tr><tr><th><span style="color:var(--ds-background-accent-lime-bolder,#5b7f24);">Service Account Role</span></th><td>{{SERVICE_ROLES_TABLE}}<p class="auto-cursor-target"><br /></p></td></tr></tbody></table>
""";

}
