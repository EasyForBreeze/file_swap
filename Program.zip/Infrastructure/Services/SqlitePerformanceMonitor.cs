using System.Collections.Concurrent;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Централизованный мониторинг производительности всех SQLite операций.
/// Этот класс является потокобезопасным и может использоваться из любого количества потоков одновременно.
/// Все операции используют lock-free алгоритмы для максимальной производительности.
/// </summary>
/// <remarks>
/// <para>
/// Thread-safety гарантируется через использование:
/// - <see cref="ConcurrentDictionary{TKey, TValue}"/> для хранения статистики
/// - <see cref="Interlocked"/> операций для атомарного обновления счетчиков
/// - Lock-free алгоритмы для чтения статистики
/// - Версионирование для обеспечения консистентности данных при одновременных операциях чтения и сброса
/// </para>
/// <para>
/// Внимание: Методы Reset* могут привести к временной рассинхронизации общей статистики
/// во время высоких нагрузок. Используйте их с осторожностью.
/// </para>
/// <para>
/// Все методы являются thread-safe и могут вызываться из любого количества потоков одновременно.
/// Операции записи (RecordOperation) не блокируют операции чтения (GetTotalStats, GetDatabaseStats, GetAllDatabaseStats).
/// </para>
/// </remarks>
public static class SqlitePerformanceMonitor
{
    private static readonly ConcurrentDictionary<string, DatabaseStats> _databaseStats = new();
    
    // Общая статистика по всем БД (используем long вместо int для защиты от переполнения)
    private static long _totalResponseTimeMs = 0;
    private static long _totalRequestCount = 0;
    
    // Проблема #14: Версионирование для атомарных снимков
    // Используем long.MaxValue - 1 как максимальное значение перед сбросом для защиты от переполнения
    private static long _version = 0;
    private const long MaxVersionValue = long.MaxValue - 1;
    
    // Проблема #10: Логирование ошибок
    private static volatile Action<string, Exception>? _errorLogger;
    
    // Проблема #11: Защита от слишком больших значений
    private const long MaxReasonableElapsedMs = 3600000; // 1 час (3,600,000 мс)
    
    // Проблема #12: События для мониторинга
    private const long SlowOperationThresholdMs = 1000; // 1 секунда
    
    // Проблема #16: Производительность самого мониторинга
    private static long _isEnabled = 1; // 1 = enabled, 0 = disabled (используем long для Interlocked.Read)
    
    // Проблема #17: Защита от DoS через большое количество уникальных БД
    // Проверка на 0: минимальное значение установлено в 1 для корректной работы
    private const int MaxTrackedDatabases = 1000;
    
    // Максимальная длина имени БД для защиты от проблем с производительностью и безопасностью
    private const int MaxDatabaseNameLength = 255;
    
    // Проблема #26: Счетчик отслеживаемых БД для оптимизации производительности
    private static long _trackedDatabasesCount = 0;
    
    // Проблема #18: Метрики производительности самого мониторинга
    private static long _monitorOverheadMs = 0;
    private static long _monitorOperationsCount = 0;
    
    /// <summary>
    /// Событие, возникающее при записи операции
    /// </summary>
    public static event Action<string, long>? OperationRecorded;
    
    /// <summary>
    /// Событие, возникающее при превышении порогового времени выполнения
    /// </summary>
    public static event Action<string, long>? SlowOperationDetected;
    
    /// <summary>
    /// Включить или отключить мониторинг производительности
    /// Проблема #16: Возможность отключения мониторинга для повышения производительности
    /// </summary>
    /// <param name="enabled">true для включения, false для отключения</param>
    public static void SetEnabled(bool enabled)
    {
        Interlocked.Exchange(ref _isEnabled, enabled ? 1L : 0L);
    }
    
    /// <summary>
    /// Проверить, включен ли мониторинг
    /// </summary>
    public static bool IsEnabled => Interlocked.Read(ref _isEnabled) == 1;
    
    /// <summary>
    /// Установить логгер для ошибок
    /// Проблема #10: Решение проблемы отсутствия логирования
    /// </summary>
    /// <param name="logger">Callback для логирования ошибок (message, exception)</param>
    public static void SetErrorLogger(Action<string, Exception> logger)
    {
        _errorLogger = logger;
    }
    
    /// <summary>
    /// Логирование ошибки
    /// </summary>
    private static void LogError(string message, Exception? exception = null)
    {
        // Безопасное чтение volatile поля через прямое обращение (volatile гарантирует видимость)
        var logger = _errorLogger;
        logger?.Invoke(message, exception ?? new InvalidOperationException(message));
    }
    
    /// <summary>
    /// Статистика по конкретной БД
    /// </summary>
    private class DatabaseStats
    {
        private long _totalTimeMs = 0;
        private long _requestCount = 0; // Изменено с int на long для защиты от переполнения
        
        // Проблема #15: Отслеживание времени последнего использования
        private long _lastAccessTimeTicks = DateTime.UtcNow.Ticks;
        
        // Кэш для DateTime из ticks для оптимизации производительности
        private DateTime? _cachedLastAccessTime;
        private long _cachedTicks;
        
        public string DatabaseName { get; init; } = string.Empty;
        
        /// <summary>
        /// Получить текущее значение общего времени (без блокировок)
        /// </summary>
        public long TotalTimeMs => _totalTimeMs;
        
        /// <summary>
        /// Получить текущее значение количества запросов (без блокировок)
        /// </summary>
        public long RequestCount => _requestCount;
        
        /// <summary>
        /// Добавить время атомарно
        /// </summary>
        public void AddTime(long elapsedMs)
        {
            Interlocked.Add(ref _totalTimeMs, elapsedMs);
        }
        
        /// <summary>
        /// Увеличить счетчик запросов атомарно
        /// </summary>
        public void IncrementCount()
        {
            Interlocked.Increment(ref _requestCount);
        }
        
        /// <summary>
        /// Сбросить статистику атомарно
        /// </summary>
        public (long TotalTimeMs, long RequestCount) Reset()
        {
            var totalTime = Interlocked.Exchange(ref _totalTimeMs, 0);
            var requestCount = Interlocked.Exchange(ref _requestCount, 0);
            return (totalTime, requestCount);
        }
        
        /// <summary>
        /// Получить снимок статистики (атомарное чтение)
        /// </summary>
        public (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetSnapshot()
        {
            // Атомарное чтение long значений через Interlocked для потокобезопасности
            var count = Interlocked.Read(ref _requestCount);
            var total = Interlocked.Read(ref _totalTimeMs);
            var average = count > 0 ? (double)total / count : 0;
            return (total, count, average);
        }
        
        /// <summary>
        /// Обновить время последнего доступа
        /// Проблема #15: Отслеживание времени последнего использования
        /// </summary>
        public void UpdateAccessTime()
        {
            var ticks = DateTime.UtcNow.Ticks;
            Interlocked.Exchange(ref _lastAccessTimeTicks, ticks);
            // Инвалидируем кэш
            _cachedLastAccessTime = null;
        }
        
        /// <summary>
        /// Получить время последнего доступа
        /// </summary>
        public DateTime LastAccessTime
        {
            get
            {
                var ticks = Interlocked.Read(ref _lastAccessTimeTicks);
                // Используем кэш для оптимизации производительности
                if (_cachedLastAccessTime.HasValue && _cachedTicks == ticks)
                {
                    return _cachedLastAccessTime.Value;
                }
                var dateTime = new DateTime(ticks);
                _cachedLastAccessTime = dateTime;
                _cachedTicks = ticks;
                return dateTime;
            }
        }
        
        /// <summary>
        /// Получить снимок со временем последнего доступа
        /// </summary>
        public (long TotalTimeMs, long RequestCount, double AverageTimeMs, DateTime LastAccessTime) GetSnapshotWithAccessTime()
        {
            var snapshot = GetSnapshot();
            return (snapshot.TotalTimeMs, snapshot.RequestCount, snapshot.AverageTimeMs, LastAccessTime);
        }
    }
    
    /// <summary>
    /// Записать время выполнения операции в статистику
    /// </summary>
    /// <param name="databaseName">Название БД (например, "audit", "wiki_pages", "forbidden_clients")</param>
    /// <param name="elapsedMs">Время выполнения в миллисекундах</param>
    /// <exception cref="ArgumentException">Когда databaseName null или пустая строка</exception>
    /// <exception cref="ArgumentOutOfRangeException">Когда elapsedMs отрицательное</exception>
    public static void RecordOperation(string databaseName, long elapsedMs)
    {
        // Проблема #16, #20: Быстрый выход, если мониторинг отключен (до создания Stopwatch)
        if (Interlocked.Read(ref _isEnabled) == 0)
            return;
        
        // Проблема #18: Измерение производительности самого мониторинга (создается только если мониторинг включен)
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        
        try
        {
            // Проблема #5: Валидация входных данных
            if (string.IsNullOrWhiteSpace(databaseName))
                throw new ArgumentException("Database name cannot be null or whitespace.", nameof(databaseName));
            
            if (databaseName.Length > MaxDatabaseNameLength)
                throw new ArgumentException($"Database name cannot exceed {MaxDatabaseNameLength} characters.", nameof(databaseName));
            
            if (elapsedMs < 0)
                throw new ArgumentOutOfRangeException(nameof(elapsedMs), "Elapsed time cannot be negative.");
            
            // Проблема #19, #26: Атомарная проверка лимита БД с использованием собственного счетчика
            var currentCount = Interlocked.Read(ref _trackedDatabasesCount);
            if (currentCount >= MaxTrackedDatabases)
            {
                // Используем TryGetValue вместо ContainsKey для более эффективной проверки
                if (!_databaseStats.TryGetValue(databaseName, out _))
                {
                    LogError($"Maximum number of tracked databases ({MaxTrackedDatabases}) reached. Ignoring '{databaseName}'.");
                    return;
                }
                // Если БД уже существует, продолжаем работу
            }
            
            // Проблема #11: Защита от слишком больших значений
            if (elapsedMs > MaxReasonableElapsedMs)
            {
                LogError($"Suspiciously large elapsed time: {elapsedMs}ms for database '{databaseName}'. Limiting to {MaxReasonableElapsedMs}ms.");
                elapsedMs = MaxReasonableElapsedMs; // Ограничиваем значение
            }
            
            // Проблема #4: Проверка на переполнение счетчика
            if (_totalRequestCount == long.MaxValue)
            {
                LogError("Total request count reached maximum value. Resetting all statistics.");
                // Автоматический сброс при переполнении
                ResetAllStats();
            }
            
            // Проблема #1, #2, #26: Используем lock-free подход с Interlocked операциями
            var dbStats = _databaseStats.GetOrAdd(databaseName, _ =>
            {
                // Увеличиваем счетчик только при создании новой записи
                Interlocked.Increment(ref _trackedDatabasesCount);
                return new DatabaseStats 
                { 
                    DatabaseName = databaseName 
                };
            });
            
            // Проблема #15: Обновление времени последнего доступа
            dbStats.UpdateAccessTime();
            
            // Lock-free операции для обновления статистики БД
            dbStats.AddTime(elapsedMs);
            dbStats.IncrementCount();
            
            // Lock-free операции для обновления общей статистики
            Interlocked.Add(ref _totalResponseTimeMs, elapsedMs);
            Interlocked.Increment(ref _totalRequestCount);
            
            // Обработка переполнения _version
            var newVersion = Interlocked.Increment(ref _version);
            if (newVersion >= MaxVersionValue)
            {
                // Сбрасываем версию атомарно, если достигли максимального значения
                Interlocked.Exchange(ref _version, 0);
            }
            
            // Проблема #12: События для мониторинга в реальном времени
            OnOperationRecorded(databaseName, elapsedMs);
        }
        finally
        {
            // Проблема #18, #21: Учет накладных расходов мониторинга (используем Ticks для точности)
            stopwatch.Stop();
            var overheadTicks = stopwatch.ElapsedTicks;
            if (overheadTicks > 0)
            {
                // Конвертируем в миллисекунды для более точного измерения
                var overheadMs = (long)(overheadTicks * 1000.0 / System.Diagnostics.Stopwatch.Frequency);
                Interlocked.Add(ref _monitorOverheadMs, overheadMs);
                Interlocked.Increment(ref _monitorOperationsCount);
            }
        }
    }
    
    /// <summary>
    /// Обработка события записи операции
    /// Проблема #23: Обработка исключений в обработчиках событий
    /// Оптимизация: проверяем наличие подписчиков перед вызовом для улучшения производительности
    /// </summary>
    private static void OnOperationRecorded(string databaseName, long elapsedMs)
    {
        // Оптимизация: проверяем наличие подписчиков перед вызовом
        var operationRecorded = OperationRecorded;
        if (operationRecorded != null)
        {
            try
            {
                operationRecorded.Invoke(databaseName, elapsedMs);
            }
            catch (Exception ex)
            {
                LogError($"Error in OperationRecorded event handler: {ex.Message}", ex);
            }
        }
        
        if (elapsedMs > SlowOperationThresholdMs)
        {
            var slowOperationDetected = SlowOperationDetected;
            if (slowOperationDetected != null)
            {
                try
                {
                    slowOperationDetected.Invoke(databaseName, elapsedMs);
                }
                catch (Exception ex)
                {
                    LogError($"Error in SlowOperationDetected event handler: {ex.Message}", ex);
                }
            }
        }
    }
    
    /// <summary>
    /// Получить общую статистику по всем SQLite БД
    /// Проблема #14, #22, #27: Атомарное чтение с версионированием и защитой от бесконечного цикла
    /// </summary>
    public static (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetTotalStats()
    {
        long version;
        long totalTime;
        long requestCount;
        const int maxRetries = 100;
        int retries = 0;
        
        // Атомарное чтение с версионированием для защиты от race condition
        // Проблема #27: Используем Interlocked.Read() для явной атомарности
        // Оптимизация: читаем версию один раз в начале цикла
        long initialVersion;
        do
        {
            initialVersion = Interlocked.Read(ref _version);
            totalTime = Interlocked.Read(ref _totalResponseTimeMs);
            requestCount = Interlocked.Read(ref _totalRequestCount);
            version = Interlocked.Read(ref _version);
            retries++;
        } while (initialVersion != version && retries < maxRetries);
        
        // Проблема #22: Если превышено количество попыток, используем последние прочитанные значения
        if (retries >= maxRetries)
        {
            LogError("GetTotalStats: exceeded maximum retries, using last read values");
        }
        
        var averageTime = requestCount > 0 ? (double)totalTime / requestCount : 0;
        return (totalTime, requestCount, averageTime);
    }
    
    /// <summary>
    /// Получить статистику по конкретной БД
    /// </summary>
    /// <param name="databaseName">Название БД</param>
    /// <exception cref="ArgumentException">Когда databaseName null или пустая строка</exception>
    public static (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetDatabaseStats(string databaseName)
    {
        // Проблема #5: Валидация входных данных
        if (string.IsNullOrWhiteSpace(databaseName))
            throw new ArgumentException("Database name cannot be null or whitespace.", nameof(databaseName));
        
        if (_databaseStats.TryGetValue(databaseName, out var stats))
        {
            return stats.GetSnapshot(); // Lock-free атомарное чтение
        }
        
        return (0, 0, 0);
    }
    
    /// <summary>
    /// Получить статистику по всем БД
    /// </summary>
    public static Dictionary<string, (long TotalTimeMs, long RequestCount, double AverageTimeMs)> GetAllDatabaseStats()
    {
        // Оптимизация: предварительно оцениваем размер для уменьшения реаллокаций
        var estimatedSize = _databaseStats.Count;
        var result = new Dictionary<string, (long TotalTimeMs, long RequestCount, double AverageTimeMs)>(estimatedSize);
        
        // Проблема #6: Используем снимок ключей для безопасной итерации
        // Оптимизация: используем ToArray только один раз
        var keys = _databaseStats.Keys.ToArray();
        
        foreach (var key in keys)
        {
            if (_databaseStats.TryGetValue(key, out var stats))
            {
                // Атомарное чтение через snapshot
                result[key] = stats.GetSnapshot();
            }
        }
        
        return result;
    }
    
    /// <summary>
    /// Сбросить всю статистику
    /// </summary>
    public static void ResetAllStats()
    {
        // Атомарный сброс общей статистики
        Interlocked.Exchange(ref _totalResponseTimeMs, 0);
        Interlocked.Exchange(ref _totalRequestCount, 0);
        
        // Обработка переполнения _version при инкременте
        var newVersion = Interlocked.Increment(ref _version);
        if (newVersion >= MaxVersionValue)
        {
            Interlocked.Exchange(ref _version, 0);
        }
        
        // Сброс статистики каждой БД
        var keys = _databaseStats.Keys.ToArray();
        foreach (var key in keys)
        {
            if (_databaseStats.TryGetValue(key, out var stats))
            {
                stats.Reset();
            }
        }
        
        // Проблема #26: Счетчик отслеживаемых БД не сбрасываем, так как записи остаются в словаре
        // Если нужно сбросить счетчик, нужно очистить словарь через RemoveDatabaseStats
    }
    
    /// <summary>
    /// Сбросить статистику конкретной БД
    /// </summary>
    /// <param name="databaseName">Название БД</param>
    /// <exception cref="ArgumentException">Когда databaseName null или пустая строка</exception>
    public static void ResetDatabaseStats(string databaseName)
    {
        // Проблема #5: Валидация входных данных
        if (string.IsNullOrWhiteSpace(databaseName))
            throw new ArgumentException("Database name cannot be null or whitespace.", nameof(databaseName));
        
        // Проблема #7: Синхронизация сброса с общей статистикой
        if (_databaseStats.TryGetValue(databaseName, out var stats))
        {
            var (totalTime, requestCount) = stats.Reset();
            
            // Вычитаем из общей статистики для синхронизации
            // Используем Interlocked.Add с отрицательными значениями (это безопасно и эффективно)
            Interlocked.Add(ref _totalResponseTimeMs, -totalTime);
            Interlocked.Add(ref _totalRequestCount, -requestCount);
            
            // Обработка переполнения _version
            var newVersion = Interlocked.Increment(ref _version);
            if (newVersion >= MaxVersionValue)
            {
                Interlocked.Exchange(ref _version, 0);
            }
        }
    }
    
    /// <summary>
    /// Удалить статистику конкретной БД из словаря
    /// Проблема #3: Решение проблемы утечки памяти
    /// </summary>
    /// <param name="databaseName">Название БД</param>
    /// <returns>true если статистика была удалена, false если БД не найдена</returns>
    /// <exception cref="ArgumentException">Когда databaseName null или пустая строка</exception>
    public static bool RemoveDatabaseStats(string databaseName)
    {
        if (string.IsNullOrWhiteSpace(databaseName))
            throw new ArgumentException("Database name cannot be null or whitespace.", nameof(databaseName));
        
        if (_databaseStats.TryRemove(databaseName, out var removedStats))
        {
            // Вычитаем из общей статистики перед удалением
            var snapshot = removedStats.GetSnapshot();
            Interlocked.Add(ref _totalResponseTimeMs, -snapshot.TotalTimeMs);
            Interlocked.Add(ref _totalRequestCount, -snapshot.RequestCount);
            
            // Обработка переполнения _version
            var newVersion = Interlocked.Increment(ref _version);
            if (newVersion >= MaxVersionValue)
            {
                Interlocked.Exchange(ref _version, 0);
            }
            
            // Проблема #26: Уменьшаем счетчик отслеживаемых БД с защитой от отрицательных значений
            var newCount = Interlocked.Decrement(ref _trackedDatabasesCount);
            if (newCount < 0)
            {
                // Исправляем отрицательное значение, устанавливая его в 0
                Interlocked.Exchange(ref _trackedDatabasesCount, 0);
                LogError("Tracked databases count became negative, reset to 0");
            }
            
            return true;
        }
        
        return false;
    }
    
    // Кэшированный JsonSerializerOptions для оптимизации производительности
    private static readonly JsonSerializerOptions _jsonOptions = new JsonSerializerOptions 
    { 
        WriteIndented = true 
    };
    
    /// <summary>
    /// Получить статистику в формате JSON
    /// Проблема #13: Экспорт статистики для анализа или мониторинга
    /// </summary>
    /// <returns>JSON строка со всей статистикой</returns>
    public static string ToJson()
    {
        var stats = new
        {
            Total = GetTotalStats(),
            Databases = GetAllDatabaseStats(),
            Timestamp = DateTime.UtcNow,
            Version = Interlocked.Read(ref _version)
        };
        
        return JsonSerializer.Serialize(stats, _jsonOptions);
    }
    
    /// <summary>
    /// Получить статистику в формате JSON (асинхронно)
    /// </summary>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>JSON строка со всей статистикой</returns>
    public static async Task<string> ToJsonAsync(CancellationToken cancellationToken = default)
    {
        // Используем Task.Run для выгрузки работы в пул потоков, но обрабатываем отмену
        try
        {
            return await Task.Run(() => ToJson(), cancellationToken);
        }
        catch (OperationCanceledException)
        {
            // Возвращаем пустую строку при отмене операции
            return "{}";
        }
    }
    
    /// <summary>
    /// Получить метрики производительности самого мониторинга
    /// Проблема #18, #25: Метрики производительности мониторинга с улучшенной проверкой
    /// </summary>
    /// <returns>Общее время накладных расходов, количество операций и среднее время</returns>
    public static (long OverheadMs, long OperationsCount, double AverageOverheadMs) GetMonitorStats()
    {
        // Использование Interlocked.Read для атомарного чтения и обеспечения видимости изменений между потоками
        var operationsCount = Interlocked.Read(ref _monitorOperationsCount);
        var overheadMs = Interlocked.Read(ref _monitorOverheadMs);
        
        // Проблема #25: Более явная проверка на нулевые значения
        if (operationsCount <= 0)
        {
            return (0, 0, 0);
        }
        
        var average = (double)overheadMs / operationsCount;
        return (overheadMs, operationsCount, average);
    }
    
    // Максимальный порог неактивности (1 год) для защиты от неправильного использования
    private static readonly TimeSpan MaxInactivityThreshold = TimeSpan.FromDays(365);
    
    /// <summary>
    /// Очистить статистику для БД, которые не использовались длительное время
    /// Проблема #15, #24: Использование информации о времени последнего доступа с атомарным удалением
    /// </summary>
    /// <param name="inactivityThreshold">Порог неактивности (БД не использовалась дольше этого времени)</param>
    /// <returns>Количество удаленных записей</returns>
    public static int CleanupInactiveDatabases(TimeSpan inactivityThreshold)
    {
        if (inactivityThreshold <= TimeSpan.Zero)
            throw new ArgumentException("Inactivity threshold must be positive.", nameof(inactivityThreshold));
        
        if (inactivityThreshold > MaxInactivityThreshold)
            throw new ArgumentException($"Inactivity threshold cannot exceed {MaxInactivityThreshold.TotalDays} days.", nameof(inactivityThreshold));
        
        // Кэшируем текущее время для оптимизации производительности
        var now = DateTime.UtcNow;
        var cutoffTime = now - inactivityThreshold;
        int removedCount = 0;
        
        // Проблема #24: Удаляем сразу при обнаружении, чтобы избежать race condition
        // Оптимизация: используем snapshot ключей только один раз
        var keys = _databaseStats.Keys.ToArray();
        foreach (var key in keys)
        {
            if (_databaseStats.TryGetValue(key, out var stats))
            {
                // Атомарная проверка и удаление
                if (stats.LastAccessTime < cutoffTime)
                {
                    if (RemoveDatabaseStats(key))
                    {
                        removedCount++;
                    }
                }
            }
        }
        
        return removedCount;
    }
    
    /// <summary>
    /// Получить статистику по всем БД с информацией о времени последнего доступа
    /// Проблема #15: Расширенная статистика с временем доступа
    /// </summary>
    public static Dictionary<string, (long TotalTimeMs, long RequestCount, double AverageTimeMs, DateTime LastAccessTime)> GetAllDatabaseStatsWithAccessTime()
    {
        // Оптимизация: предварительно оцениваем размер для уменьшения реаллокаций
        var estimatedSize = _databaseStats.Count;
        var result = new Dictionary<string, (long TotalTimeMs, long RequestCount, double AverageTimeMs, DateTime LastAccessTime)>(estimatedSize);
        
        // Используем общую логику получения ключей
        var keys = _databaseStats.Keys.ToArray();
        foreach (var key in keys)
        {
            if (_databaseStats.TryGetValue(key, out var stats))
            {
                result[key] = stats.GetSnapshotWithAccessTime();
            }
        }
        
        return result;
    }
    
    /// <summary>
    /// Получить статистику по конкретной БД с информацией о времени последнего доступа
    /// </summary>
    public static (long TotalTimeMs, long RequestCount, double AverageTimeMs, DateTime LastAccessTime)? GetDatabaseStatsWithAccessTime(string databaseName)
    {
        if (string.IsNullOrWhiteSpace(databaseName))
            throw new ArgumentException("Database name cannot be null or whitespace.", nameof(databaseName));
        
        if (_databaseStats.TryGetValue(databaseName, out var stats))
        {
            return stats.GetSnapshotWithAccessTime();
        }
        
        return null;
    }
}
