using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для форматирования времени в относительном формате (например, "5 минут назад")
/// </summary>
public class TimeFormatterService
{
    private readonly ILogger<TimeFormatterService> _logger;

    /// <summary>
    /// Инициализирует новый экземпляр TimeFormatterService
    /// </summary>
    /// <param name="logger">Логгер для записи операций</param>
    public TimeFormatterService(ILogger<TimeFormatterService> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Получает строку относительного времени (например, "5 минут назад")
    /// </summary>
    /// <param name="time">Время для форматирования</param>
    /// <returns>Строка относительного времени</returns>
    public string GetTimeAgo(DateTime time)
    {
        try
        {
            var timeSpan = DateTime.Now - time;
            
            if (timeSpan.TotalSeconds < 60)
            {
                return "только что";
            }
            else if (timeSpan.TotalMinutes < 60)
            {
                var minutes = (int)timeSpan.TotalMinutes;
                return $"{minutes} {GetMinutesWord(minutes)} назад";
            }
            else if (timeSpan.TotalHours < 24)
            {
                var hours = (int)timeSpan.TotalHours;
                return $"{hours} {GetHoursWord(hours)} назад";
            }
            else
            {
                var days = (int)timeSpan.TotalDays;
                return $"{days} {GetDaysWord(days)} назад";
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при форматировании времени: {Time}", time);
            return "недавно";
        }
    }

    /// <summary>
    /// Получает правильную форму слова "минута" в зависимости от числа
    /// </summary>
    /// <param name="minutes">Количество минут</param>
    /// <returns>Правильная форма слова</returns>
    public string GetMinutesWord(int minutes)
    {
        if (minutes % 10 == 1 && minutes % 100 != 11)
            return "минута";
        else if ((minutes % 10 >= 2 && minutes % 10 <= 4) && (minutes % 100 < 10 || minutes % 100 >= 20))
            return "минуты";
        else
            return "минут";
    }

    /// <summary>
    /// Получает правильную форму слова "час" в зависимости от числа
    /// </summary>
    /// <param name="hours">Количество часов</param>
    /// <returns>Правильная форма слова</returns>
    public string GetHoursWord(int hours)
    {
        if (hours % 10 == 1 && hours % 100 != 11)
            return "час";
        else if ((hours % 10 >= 2 && hours % 10 <= 4) && (hours % 100 < 10 || hours % 100 >= 20))
            return "часа";
        else
            return "часов";
    }

    /// <summary>
    /// Получает правильную форму слова "день" в зависимости от числа
    /// </summary>
    /// <param name="days">Количество дней</param>
    /// <returns>Правильная форма слова</returns>
    public string GetDaysWord(int days)
    {
        if (days % 10 == 1 && days % 100 != 11)
            return "день";
        else if ((days % 10 >= 2 && days % 10 <= 4) && (days % 100 < 10 || days % 100 >= 20))
            return "дня";
        else
            return "дней";
    }
}

