using System.Text.RegularExpressions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;
using new_assistant.Infrastructure.Services.Keycloak;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для формирования URL для Keycloak
/// </summary>
public class KeycloakUrlBuilderService : IKeycloakUrlBuilderService
{
    private readonly KeycloakStageSettings _stageSettings;
    private readonly IConfiguration _configuration;
    private readonly ILogger<KeycloakUrlBuilderService> _logger;
    
    // Кэш для базового URL (для оптимизации производительности)
    private string? _cachedBaseUrl;
    private readonly object _cacheLock = new object();
    
    // Регулярное выражение для проверки недопустимых символов в realm для URL
    // Realm не должен содержать символы, которые требуют URL-кодирования в пути
    private static readonly Regex InvalidRealmCharactersRegex = new Regex(@"[<>""|\\^`{}\[\]]", RegexOptions.Compiled | RegexOptions.CultureInvariant);

    public KeycloakUrlBuilderService(
        IOptions<KeycloakStageSettings> stageSettings,
        IConfiguration configuration,
        ILogger<KeycloakUrlBuilderService> logger)
    {
        _stageSettings = stageSettings?.Value ?? throw new ArgumentNullException(nameof(stageSettings));
        _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Получить базовый URL для STAGE окружения
    /// </summary>
    /// <returns>Валидированный базовый URL</returns>
    /// <exception cref="InvalidOperationException">Выбрасывается если baseUrl не настроен или имеет недопустимый формат</exception>
    public string GetStageBaseUrl()
    {
        // Используем кэш для оптимизации (конфигурация обычно не меняется во время выполнения)
        if (_cachedBaseUrl != null)
        {
            return _cachedBaseUrl;
        }
        
        lock (_cacheLock)
        {
            // Double-check locking pattern
            if (_cachedBaseUrl != null)
            {
                return _cachedBaseUrl;
            }
            
            var baseUrl = _stageSettings.BaseUrl;
            var useLegacy = _stageSettings.UseLegacyAuthPath;
            
            // Читаем из конфигурации, если не задано в настройках
            if (string.IsNullOrWhiteSpace(baseUrl))
            {
                var configSection = _configuration.GetSection("KeycloakStage");
                baseUrl = configSection.GetValue<string>("BaseUrl");
                
                // Более безопасная проверка для bool значения
                var useLegacySection = configSection.GetSection("UseLegacyAuthPath");
                if (useLegacySection.Exists())
                {
                    useLegacy = useLegacySection.Get<bool>();
                }
            }
            
            // Валидация обязательного параметра
            if (string.IsNullOrWhiteSpace(baseUrl))
            {
                _logger.LogError("KeycloakStage:BaseUrl не настроен в конфигурации");
                throw new InvalidOperationException("KeycloakStage:BaseUrl не настроен в конфигурации");
            }
            
            // Валидация формата URL
            if (!Uri.TryCreate(baseUrl, UriKind.Absolute, out var baseUri))
            {
                _logger.LogError("KeycloakStage:BaseUrl имеет недопустимый формат: {BaseUrl}", baseUrl);
                throw new InvalidOperationException($"KeycloakStage:BaseUrl имеет недопустимый формат: {baseUrl}");
            }
            
            // Проверяем, что это HTTP или HTTPS URL
            if (baseUri.Scheme != Uri.UriSchemeHttp && baseUri.Scheme != Uri.UriSchemeHttps)
            {
                _logger.LogError("KeycloakStage:BaseUrl должен использовать схему http или https: {BaseUrl}", baseUrl);
                throw new InvalidOperationException($"KeycloakStage:BaseUrl должен использовать схему http или https: {baseUrl}");
            }
            
            // Используем UriBuilder для безопасного построения URL
            var uriBuilder = new UriBuilder(baseUri);
            
            // Обрабатываем legacy auth path
            if (useLegacy)
            {
                // Проверяем путь через Uri, а не через EndsWith
                var path = uriBuilder.Path.TrimEnd('/');
                if (!path.EndsWith("/auth", StringComparison.OrdinalIgnoreCase))
                {
                    // Удаляем все завершающие слэши и добавляем /auth
                    uriBuilder.Path = $"{path}/auth";
                }
            }
            else
            {
                // Удаляем завершающие слэши из пути
                uriBuilder.Path = uriBuilder.Path.TrimEnd('/');
            }
            
            // Проверяем, что baseUrl не содержит /realms (чтобы избежать дублирования)
            var finalPath = uriBuilder.Path.TrimEnd('/');
            if (finalPath.Contains("/realms", StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogWarning(
                    "KeycloakStage:BaseUrl содержит '/realms' в пути, что может привести к дублированию: {BaseUrl}",
                    uriBuilder.Uri.ToString());
            }
            
            _cachedBaseUrl = uriBuilder.Uri.ToString();
            _logger.LogDebug("Сформирован базовый URL для STAGE: {BaseUrl}", _cachedBaseUrl);
            
            return _cachedBaseUrl;
        }
    }

    /// <summary>
    /// Валидация параметра realm
    /// </summary>
    /// <param name="realm">Название реалма для валидации</param>
    /// <param name="paramName">Имя параметра для сообщения об ошибке</param>
    /// <exception cref="ArgumentException">Выбрасывается если realm невалиден</exception>
    private void ValidateRealm(string realm, string paramName = "realm")
    {
        // Используем существующий валидатор
        KeycloakParameterValidator.ValidateRealm(realm, paramName);
        
        // Дополнительная проверка на недопустимые символы для URL пути
        // Realm не должен содержать символы, которые могут вызвать проблемы в URL
        if (InvalidRealmCharactersRegex.IsMatch(realm))
        {
            _logger.LogError("Realm содержит недопустимые символы для URL: {Realm}", realm);
            throw new ArgumentException(
                $"Realm содержит недопустимые символы для URL пути. Недопустимые символы: < > \" | \\ ^ ` {{ }} [ ]",
                paramName);
        }
        
        // Проверка на символы, которые требуют URL-кодирования (пробелы, слэши и т.д.)
        // Keycloak realm обычно не содержит таких символов, но для безопасности проверяем
        if (realm.Contains('/') || realm.Contains('?') || realm.Contains('#') || realm.Contains(' '))
        {
            _logger.LogError("Realm содержит символы, которые требуют URL-кодирования: {Realm}", realm);
            throw new ArgumentException(
                "Realm содержит символы, которые требуют URL-кодирования (/, ?, #, пробелы). Realm должен быть валидным для использования в URL пути.",
                paramName);
        }
    }

    /// <summary>
    /// Получить URL для realm в STAGE окружении
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <returns>URL для realm</returns>
    /// <exception cref="ArgumentException">Выбрасывается если realm невалиден</exception>
    public string GetStageRealmUrl(string realm)
    {
        ValidateRealm(realm);
        
        var baseUrl = GetStageBaseUrl();
        
        // Используем UriBuilder для безопасного построения URL
        if (!Uri.TryCreate(baseUrl, UriKind.Absolute, out var baseUri))
        {
            _logger.LogError("Не удалось распарсить базовый URL: {BaseUrl}", baseUrl);
            throw new InvalidOperationException($"Не удалось распарсить базовый URL: {baseUrl}");
        }
        
        var uriBuilder = new UriBuilder(baseUri);
        
        // Проверяем, что путь не содержит уже /realms
        var path = uriBuilder.Path.TrimEnd('/');
        if (!path.Contains("/realms", StringComparison.OrdinalIgnoreCase))
        {
            // Realm уже валидирован и не содержит недопустимых символов, поэтому можно безопасно добавить в путь
            uriBuilder.Path = $"{path}/realms/{realm}";
        }
        else
        {
            // Если /realms уже есть, просто добавляем realm
            uriBuilder.Path = $"{path}/{realm}";
        }
        
        var resultUrl = uriBuilder.Uri.ToString();
        _logger.LogDebug("Сформирован URL для realm {Realm}: {Url}", realm, resultUrl);
        
        return resultUrl;
    }

    /// <summary>
    /// Получить URL для endpoints в STAGE окружении
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <returns>URL для endpoints</returns>
    /// <exception cref="ArgumentException">Выбрасывается если realm невалиден</exception>
    public string GetStageEndpointsUrl(string realm)
    {
        ValidateRealm(realm);
        
        var baseUrl = GetStageBaseUrl();
        
        // Используем UriBuilder для безопасного построения URL
        if (!Uri.TryCreate(baseUrl, UriKind.Absolute, out var baseUri))
        {
            _logger.LogError("Не удалось распарсить базовый URL: {BaseUrl}", baseUrl);
            throw new InvalidOperationException($"Не удалось распарсить базовый URL: {baseUrl}");
        }
        
        var uriBuilder = new UriBuilder(baseUri);
        
        // Проверяем, что путь не содержит уже /realms
        var path = uriBuilder.Path.TrimEnd('/');
        if (!path.Contains("/realms", StringComparison.OrdinalIgnoreCase))
        {
            // Realm уже валидирован и не содержит недопустимых символов, поэтому можно безопасно добавить в путь
            uriBuilder.Path = $"{path}/realms/{realm}/.well-known/openid-configuration";
        }
        else
        {
            // Если /realms уже есть, просто добавляем realm и endpoint
            uriBuilder.Path = $"{path}/{realm}/.well-known/openid-configuration";
        }
        
        var resultUrl = uriBuilder.Uri.ToString();
        _logger.LogDebug("Сформирован URL для endpoints realm {Realm}: {Url}", realm, resultUrl);
        
        return resultUrl;
    }
}

