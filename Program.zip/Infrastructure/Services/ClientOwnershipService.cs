using Microsoft.Data.Sqlite;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;
using System.Linq;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для управления владением клиентами с использованием SQLite
/// </summary>
public class ClientOwnershipService : IClientOwnershipService, IDisposable
{
    private readonly string _connectionString;
    private readonly ILogger<ClientOwnershipService> _logger;
    private readonly IAuditService? _auditService;
    private readonly SemaphoreSlim _initSemaphore = new SemaphoreSlim(1, 1);
    private readonly SemaphoreSlim _transferLock = new SemaphoreSlim(1, 1);
    private volatile bool _isInitialized = false;
    private const string DatabaseName = "ownership";
    private bool _disposed = false;
    
    /// <summary>
    /// Максимальная длина username (255 символов - стандартный предел для большинства систем)
    /// </summary>
    private const int MaxUsernameLength = 255;
    
    /// <summary>
    /// Максимальная длина client_id (255 символов - достаточный предел для идентификаторов клиентов)
    /// </summary>
    private const int MaxClientIdLength = 255;
    
    /// <summary>
    /// Максимальная длина realm (255 символов - стандартный предел для реалмов Keycloak)
    /// </summary>
    private const int MaxRealmLength = 255;
    
    /// <summary>
    /// Timeout для команд SQLite в секундах
    /// </summary>
    private const int CommandTimeoutSeconds = 30;
    
    /// <summary>
    /// Минимальный timeout для команд SQLite в секундах
    /// </summary>
    private const int MinCommandTimeoutSeconds = 1;
    
    /// <summary>
    /// Размер батча для массовых операций (обработка больших коллекций)
    /// </summary>
    private const int BatchSize = 500;
    
    /// <summary>
    /// Минимальный размер батча для массовых операций
    /// </summary>
    private const int MinBatchSize = 1;
    
    static ClientOwnershipService()
    {
        // Проверка валидности констант при загрузке класса
        if (CommandTimeoutSeconds < MinCommandTimeoutSeconds)
        {
            throw new InvalidOperationException($"CommandTimeoutSeconds ({CommandTimeoutSeconds}) должен быть не менее {MinCommandTimeoutSeconds}");
        }
        
        if (BatchSize < MinBatchSize)
        {
            throw new InvalidOperationException($"BatchSize ({BatchSize}) должен быть не менее {MinBatchSize}");
        }
    }

    public ClientOwnershipService(DataPathsSettings dataPathsSettings, ILogger<ClientOwnershipService> logger, IAuditService? auditService = null)
    {
        try
        {
            _logger = logger;
            _auditService = auditService;
            var dbPath = dataPathsSettings.GetOwnershipDbPath();
            
            // Проверка и создание директории для БД
            var directory = Path.GetDirectoryName(dbPath);
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
                _logger.LogInformation("Создана директория для БД владения клиентами: {Directory}", directory);
            }
            
            _connectionString = $"Data Source={dbPath};Mode=ReadWriteCreate;Cache=Shared;Pooling=True";
        }
        catch
        {
            // Освобождаем ресурсы при ошибке в конструкторе
            _initSemaphore?.Dispose();
            _transferLock?.Dispose();
            throw;
        }
    }
    
    /// <summary>
    /// Проверка, не освобожден ли сервис
    /// </summary>
    private void ThrowIfDisposed()
    {
        if (_disposed)
            throw new ObjectDisposedException(nameof(ClientOwnershipService));
    }

    /// <summary>
    /// Асинхронная инициализация базы данных (вызывается автоматически при первом использовании)
    /// </summary>
    private async Task InitializeDatabaseAsync()
    {
        try
        {
            // Проверка прав доступа к БД
            try
            {
                var testConnection = new SqliteConnection(_connectionString);
                await testConnection.OpenAsync().ConfigureAwait(false);
                await testConnection.CloseAsync().ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                var builder = new SqliteConnectionStringBuilder(_connectionString);
                _logger.LogError(ex, "Невозможно создать или открыть БД владения клиентами по пути: {DbPath}", 
                    builder.DataSource);
                throw;
            }
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            await using var createTableCommand = connection.CreateCommand();
            createTableCommand.CommandTimeout = CommandTimeoutSeconds;
            createTableCommand.CommandText = @"
                CREATE TABLE IF NOT EXISTS user_client_ownership (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL,
                    client_id TEXT NOT NULL,
                    realm TEXT NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(username, client_id, realm)
                );
                
                CREATE INDEX IF NOT EXISTS idx_username_realm 
                ON user_client_ownership(username, realm);
                
                CREATE INDEX IF NOT EXISTS idx_client_realm 
                ON user_client_ownership(client_id, realm);
                
                CREATE INDEX IF NOT EXISTS idx_username_client_realm 
                ON user_client_ownership(username, client_id, realm);
                
                CREATE INDEX IF NOT EXISTS idx_created_at 
                ON user_client_ownership(created_at DESC);
                ";
            
            await createTableCommand.ExecuteNonQueryAsync().ConfigureAwait(false);
            
            _logger.LogDebug("База данных ownership успешно инициализирована");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка инициализации базы данных владения клиентами");
            throw;
        }
    }

    /// <summary>
    /// Гарантирует, что БД инициализирована перед выполнением операции
    /// </summary>
    private async Task EnsureInitializedAsync()
    {
        // Двойная проверка для оптимизации (double-check locking pattern)
        if (_isInitialized) return;
        
        await _initSemaphore.WaitAsync().ConfigureAwait(false);
        try
        {
            // Повторная проверка после получения блокировки для защиты от race conditions
            if (_isInitialized) return;
            
            await InitializeDatabaseAsync().ConfigureAwait(false);
            
            // Используем Thread.MemoryBarrier для гарантии видимости изменения в других потоках
            System.Threading.Thread.MemoryBarrier();
            _isInitialized = true;
        }
        finally
        {
            _initSemaphore.Release();
        }
    }

    /// <summary>
    /// Валидация строкового параметра с проверкой на null, whitespace и максимальную длину
    /// </summary>
    private static void ValidateStringParameter(string value, string paramName, int maxLength, string fieldName)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(value, paramName);
        if (value.Length > maxLength)
            throw new ArgumentException($"{fieldName} не может быть длиннее {maxLength} символов", paramName);
    }
    
    /// <summary>
    /// Валидация входных параметров
    /// </summary>
    private static void ValidateParameters(string username, string clientId, string realm)
    {
        ValidateStringParameter(username, nameof(username), MaxUsernameLength, "Username");
        ValidateStringParameter(clientId, nameof(clientId), MaxClientIdLength, "ClientId");
        ValidateStringParameter(realm, nameof(realm), MaxRealmLength, "Realm");
    }
    
    /// <summary>
    /// Валидация параметров для методов с двумя параметрами (clientId, realm)
    /// </summary>
    private static void ValidateClientRealmParameters(string clientId, string realm)
    {
        ValidateStringParameter(clientId, nameof(clientId), MaxClientIdLength, "ClientId");
        ValidateStringParameter(realm, nameof(realm), MaxRealmLength, "Realm");
    }
    
    /// <summary>
    /// Валидация параметров для методов с username и realm
    /// </summary>
    private static void ValidateUsernameRealmParameters(string username, string realm)
    {
        ValidateStringParameter(username, nameof(username), MaxUsernameLength, "Username");
        ValidateStringParameter(realm, nameof(realm), MaxRealmLength, "Realm");
    }
    
    /// <summary>
    /// Безопасное преобразование результата ExecuteScalarAsync в int с проверкой на переполнение
    /// </summary>
    private int SafeConvertToInt32(object? result, string context)
    {
        if (result == null || result == DBNull.Value)
        {
            _logger.LogError("{Context} returned null value", context);
            throw new InvalidOperationException($"{context} returned null value");
        }

        if (result is int intResult)
            return intResult;

        if (result is long longResult)
        {
            if (longResult > int.MaxValue || longResult < int.MinValue)
            {
                _logger.LogError("{Context} value overflow: {Value}", context, longResult);
                throw new OverflowException($"{context} value {longResult} exceeds int range");
            }
            return (int)longResult;
        }

        _logger.LogError("{Context} unexpected return type: {Type}", context, result.GetType());
        throw new InvalidOperationException($"{context} unexpected return type: {result.GetType()}");
    }
    
    /// <summary>
    /// Безопасное чтение DateTime из reader с обработкой ошибок
    /// </summary>
    private DateTime SafeParseDateTime(SqliteDataReader reader, int ordinal, string username, string fieldName)
    {
        if (reader.IsDBNull(ordinal))
        {
            _logger.LogWarning(
                "Null {FieldName} for user {Username}, using current UTC time as fallback", 
                fieldName, username);
            return DateTime.UtcNow;
        }

        try
        {
            return reader.GetDateTime(ordinal);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex,
                "Invalid {FieldName} format for user {Username}, using current UTC time as fallback", 
                fieldName, username);
            return DateTime.UtcNow;
        }
    }
    
    /// <summary>
    /// Безопасное получение строки из ExecuteScalarAsync
    /// </summary>
    private string? SafeGetStringFromScalar(object? result)
    {
        if (result == null || result == DBNull.Value)
            return null;
        
        return result.ToString();
    }
    
    /// <summary>
    /// Безопасный rollback транзакции с обработкой исключений
    /// </summary>
    private async Task SafeRollbackAsync(SqliteTransaction transaction, string context)
    {
        try
        {
            await transaction.RollbackAsync().ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при откате транзакции в {Context}", context);
            // Не пробрасываем исключение, так как уже находимся в обработке ошибки
        }
    }
    
    /// <summary>
    /// Добавление типизированного параметра к команде
    /// </summary>
    private static void AddTypedParameter(SqliteCommand command, string parameterName, SqliteType sqliteType, object? value)
    {
        var param = command.Parameters.Add(parameterName, sqliteType);
        param.Value = value ?? DBNull.Value;
    }

    public async Task<bool> IsOwnerAsync(string username, string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateParameters(username, clientId, realm);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                SELECT COUNT(*) FROM user_client_ownership 
                WHERE username = @username AND client_id = @clientId AND realm = @realm";
            
            AddTypedParameter(command, "@username", SqliteType.Text, username);
            AddTypedParameter(command, "@clientId", SqliteType.Text, clientId);
            AddTypedParameter(command, "@realm", SqliteType.Text, realm);
            
            var count = await command.ExecuteScalarAsync().ConfigureAwait(false);
            var result = SafeConvertToInt32(count, "IsOwnerAsync") > 0;
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            
            return result;
        }
        catch (SqliteException sqlEx) when (sqlEx.SqliteErrorCode == 5 || sqlEx.SqliteErrorCode == 6)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(sqlEx, "Ошибка подключения к БД при проверке владения клиентом {ClientId} пользователем {Username}", clientId, username);
            throw;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка проверки владения клиентом {ClientId} пользователем {Username}", clientId, username);
            throw;
        }
    }

    public async Task GrantOwnershipAsync(string username, string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateParameters(username, clientId, realm);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                INSERT OR IGNORE INTO user_client_ownership (username, client_id, realm) 
                VALUES (@username, @clientId, @realm)";
            
            AddTypedParameter(command, "@username", SqliteType.Text, username);
            AddTypedParameter(command, "@clientId", SqliteType.Text, clientId);
            AddTypedParameter(command, "@realm", SqliteType.Text, realm);
            
            var rowsAffected = await command.ExecuteNonQueryAsync().ConfigureAwait(false);
            
            if (rowsAffected == 0)
            {
                _logger.LogDebug(
                    "Попытка предоставить владение клиентом {ClientId} пользователю {Username}, но запись уже существует",
                    clientId, username);
            }
            else
            {
                _logger.LogDebug(
                    "Владение клиентом {ClientId} предоставлено пользователю {Username} в реалме {Realm}",
                    clientId, username, realm);
            }
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка предоставления владения клиентом {ClientId} пользователю {Username}", clientId, username);
            throw;
        }
    }

    public async Task RevokeOwnershipAsync(string username, string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateParameters(username, clientId, realm);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                DELETE FROM user_client_ownership 
                WHERE username = @username AND client_id = @clientId AND realm = @realm";
            
            AddTypedParameter(command, "@username", SqliteType.Text, username);
            AddTypedParameter(command, "@clientId", SqliteType.Text, clientId);
            AddTypedParameter(command, "@realm", SqliteType.Text, realm);
            
            await command.ExecuteNonQueryAsync().ConfigureAwait(false);
            
            _logger.LogDebug(
                "Владение клиентом {ClientId} отозвано у пользователя {Username} в реалме {Realm}",
                clientId, username, realm);
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка отзыва владения клиентом {ClientId} у пользователя {Username}", clientId, username);
            throw;
        }
    }

    public async Task<List<string>> GetUserClientsAsync(string username, string realm)
    {
        ThrowIfDisposed();
        ValidateUsernameRealmParameters(username, realm);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                SELECT client_id FROM user_client_ownership 
                WHERE username = @username AND realm = @realm 
                ORDER BY created_at DESC";
            
            AddTypedParameter(command, "@username", SqliteType.Text, username);
            AddTypedParameter(command, "@realm", SqliteType.Text, realm);
            
            var clients = new List<string>();
            await using var reader = await command.ExecuteReaderAsync().ConfigureAwait(false);
            var clientIdOrdinal = reader.GetOrdinal("client_id");
            while (await reader.ReadAsync().ConfigureAwait(false))
            {
                clients.Add(reader.GetString(clientIdOrdinal));
            }
            
            _logger.LogDebug(
                "Получено {Count} клиентов для пользователя {Username} в реалме {Realm}",
                clients.Count, username, realm);
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            
            return clients;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка получения клиентов пользователя {Username}", username);
            throw;
        }
    }

    public async Task<string?> GetClientOwnerAsync(string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateClientRealmParameters(clientId, realm);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                SELECT username FROM user_client_ownership 
                WHERE client_id = @clientId AND realm = @realm 
                LIMIT 1";
            
            AddTypedParameter(command, "@clientId", SqliteType.Text, clientId);
            AddTypedParameter(command, "@realm", SqliteType.Text, realm);
            
            var result = await command.ExecuteScalarAsync().ConfigureAwait(false);
            var owner = SafeGetStringFromScalar(result);
            
            _logger.LogDebug(
                "Получен владелец клиента {ClientId} в реалме {Realm}: {Owner}",
                clientId, realm, owner ?? "не найден");
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            
            return owner;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка получения владельца клиента {ClientId}", clientId);
            throw;
        }
    }

    public async Task TransferOwnershipAsync(string fromUsername, string toUsername, string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateParameters(fromUsername, clientId, realm);
        ValidateStringParameter(toUsername, nameof(toUsername), MaxUsernameLength, "Username");
        
        // Защита от race conditions при параллельных операциях
        await _transferLock.WaitAsync().ConfigureAwait(false);
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            await using var transaction = (Microsoft.Data.Sqlite.SqliteTransaction)await connection.BeginTransactionAsync().ConfigureAwait(false);
            
            try
            {
                // Проверка внутри транзакции, что старое владение существует
                var checkFromCommand = connection.CreateCommand();
                checkFromCommand.Transaction = transaction;
                checkFromCommand.CommandTimeout = CommandTimeoutSeconds;
                checkFromCommand.CommandText = @"
                    SELECT COUNT(*) FROM user_client_ownership 
                    WHERE username = @fromUsername AND client_id = @clientId AND realm = @realm";
                
                AddTypedParameter(checkFromCommand, "@fromUsername", SqliteType.Text, fromUsername);
                AddTypedParameter(checkFromCommand, "@clientId", SqliteType.Text, clientId);
                AddTypedParameter(checkFromCommand, "@realm", SqliteType.Text, realm);
                
                var fromCount = SafeConvertToInt32(await checkFromCommand.ExecuteScalarAsync().ConfigureAwait(false), "TransferOwnershipAsync-checkFrom");
                if (fromCount == 0)
                {
                    throw new InvalidOperationException(
                        $"Пользователь {fromUsername} не является владельцем клиента {clientId} в реалме {realm}");
                }
                
                // Проверка внутри транзакции, что новое владение не существует (если передаем другому пользователю)
                if (fromUsername != toUsername)
                {
                    var checkToCommand = connection.CreateCommand();
                    checkToCommand.Transaction = transaction;
                    checkToCommand.CommandTimeout = CommandTimeoutSeconds;
                    checkToCommand.CommandText = @"
                        SELECT COUNT(*) FROM user_client_ownership 
                        WHERE username = @toUsername AND client_id = @clientId AND realm = @realm";
                    
                    AddTypedParameter(checkToCommand, "@toUsername", SqliteType.Text, toUsername);
                    AddTypedParameter(checkToCommand, "@clientId", SqliteType.Text, clientId);
                    AddTypedParameter(checkToCommand, "@realm", SqliteType.Text, realm);
                    
                    var toCount = SafeConvertToInt32(await checkToCommand.ExecuteScalarAsync().ConfigureAwait(false), "TransferOwnershipAsync-checkTo");
                    if (toCount > 0)
                    {
                        throw new InvalidOperationException(
                            $"Пользователь {toUsername} уже является владельцем клиента {clientId} в реалме {realm}");
                    }
                }
                
                // Удаляем старое владение
                var deleteCommand = connection.CreateCommand();
                deleteCommand.Transaction = transaction;
                deleteCommand.CommandTimeout = CommandTimeoutSeconds;
                deleteCommand.CommandText = @"
                    DELETE FROM user_client_ownership 
                    WHERE username = @fromUsername AND client_id = @clientId AND realm = @realm";
                
                AddTypedParameter(deleteCommand, "@fromUsername", SqliteType.Text, fromUsername);
                AddTypedParameter(deleteCommand, "@clientId", SqliteType.Text, clientId);
                AddTypedParameter(deleteCommand, "@realm", SqliteType.Text, realm);
                
                var deletedRows = await deleteCommand.ExecuteNonQueryAsync().ConfigureAwait(false);
                
                if (deletedRows == 0)
                {
                    throw new InvalidOperationException(
                        $"Не удалось удалить владение клиентом {clientId} у пользователя {fromUsername} в реалме {realm}");
                }
                
                // Создаем новое владение (только если передаем другому пользователю)
                if (fromUsername != toUsername)
                {
                    var insertCommand = connection.CreateCommand();
                    insertCommand.Transaction = transaction;
                    insertCommand.CommandTimeout = CommandTimeoutSeconds;
                    insertCommand.CommandText = @"
                        INSERT INTO user_client_ownership (username, client_id, realm) 
                        VALUES (@toUsername, @clientId, @realm)";
                    
                    AddTypedParameter(insertCommand, "@toUsername", SqliteType.Text, toUsername);
                    AddTypedParameter(insertCommand, "@clientId", SqliteType.Text, clientId);
                    AddTypedParameter(insertCommand, "@realm", SqliteType.Text, realm);
                    
                    await insertCommand.ExecuteNonQueryAsync().ConfigureAwait(false);
                }
                
                await transaction.CommitAsync().ConfigureAwait(false);
                
                _logger.LogDebug(
                    "Владение клиентом {ClientId} передано от {FromUsername} к {ToUsername} в реалме {Realm}",
                    clientId, fromUsername, toUsername, realm);
            }
            catch
            {
                await SafeRollbackAsync(transaction, "TransferOwnershipAsync").ConfigureAwait(false);
                throw;
            }
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка передачи владения клиентом {ClientId} от {FromUsername} к {ToUsername}", clientId, fromUsername, toUsername);
            throw;
        }
        finally
        {
            _transferLock.Release();
        }
    }
    
    /// <summary>
    /// Получить все клиенты пользователя во всех реалмах
    /// </summary>
    public async Task<List<UserClientInfo>> GetAllUserClientsAsync(string username)
    {
        ThrowIfDisposed();
        ValidateStringParameter(username, nameof(username), MaxUsernameLength, "Username");
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                SELECT client_id, realm, created_at 
                FROM user_client_ownership 
                WHERE username = @username
                ORDER BY created_at DESC";
            
            AddTypedParameter(command, "@username", SqliteType.Text, username);
            
            var clients = new List<UserClientInfo>();
            
            await using var reader = await command.ExecuteReaderAsync().ConfigureAwait(false);
            var clientIdOrdinal = reader.GetOrdinal("client_id");
            var realmOrdinal = reader.GetOrdinal("realm");
            var createdAtOrdinal = reader.GetOrdinal("created_at");
            while (await reader.ReadAsync().ConfigureAwait(false))
            {
                var clientIdValue = reader.GetString(clientIdOrdinal);
                clients.Add(new UserClientInfo
                {
                    ClientId = clientIdValue,
                    Realm = reader.GetString(realmOrdinal),
                    GrantedAt = SafeParseDateTime(reader, createdAtOrdinal, username, "GrantedAt")
                });
            }
            
            _logger.LogDebug(
                "Получено {Count} клиентов для пользователя {Username} во всех реалмах",
                clients.Count, username);
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            
            return clients;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка получения всех клиентов пользователя {Username}", username);
            throw;
        }
    }
    
    /// <summary>
    /// Предоставить доступ (alias для GrantOwnershipAsync)
    /// </summary>
    public async Task GrantAccessAsync(string username, string clientId, string realm)
    {
        ThrowIfDisposed();
        await GrantOwnershipAsync(username, clientId, realm);
    }
    
    /// <summary>
    /// Отозвать доступ (alias для RevokeOwnershipAsync)
    /// </summary>
    public async Task RevokeAccessAsync(string username, string clientId, string realm)
    {
        ThrowIfDisposed();
        await RevokeOwnershipAsync(username, clientId, realm);
    }
    
    /// <summary>
    /// Предоставить доступ с логированием (для использования администраторами)
    /// </summary>
    public async Task GrantAccessWithAuditAsync(string adminUsername, string targetUsername, string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateParameters(targetUsername, clientId, realm);
        ValidateStringParameter(adminUsername, nameof(adminUsername), MaxUsernameLength, "AdminUsername");
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await GrantOwnershipAsync(targetUsername, clientId, realm).ConfigureAwait(false);
            
            // Логируем только если сервис аудита доступен
            if (_auditService != null)
            {
                try
                {
                    await _auditService.LogAccessGrantedAsync(adminUsername, targetUsername, clientId, realm)
                        .ConfigureAwait(false);
                }
                catch (Exception auditEx)
                {
                    // Компенсирующая транзакция: откатываем изменение владения только если оно было создано
                    _logger.LogWarning(auditEx, 
                        "Ошибка аудита при предоставлении доступа. Откатываем изменение владения.");
                    try
                    {
                        // Проверяем, что владение действительно было создано перед откатом
                        var wasCreated = await IsOwnerAsync(targetUsername, clientId, realm).ConfigureAwait(false);
                        if (wasCreated)
                        {
                            await RevokeOwnershipAsync(targetUsername, clientId, realm).ConfigureAwait(false);
                        }
                    }
                    catch (Exception rollbackEx)
                    {
                        _logger.LogError(rollbackEx, 
                            "Ошибка при откате владения после ошибки аудита для пользователя {Username} и клиента {ClientId}", 
                            targetUsername, clientId);
                    }
                    throw;
                }
            }
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка предоставления доступа с аудитом");
            throw;
        }
    }
    
    /// <summary>
    /// Отозвать доступ с логированием (для использования администраторами)
    /// </summary>
    public async Task RevokeAccessWithAuditAsync(string adminUsername, string targetUsername, string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateParameters(targetUsername, clientId, realm);
        ValidateStringParameter(adminUsername, nameof(adminUsername), MaxUsernameLength, "AdminUsername");
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            // Сохраняем состояние до отзыва для компенсации
            var wasOwner = await IsOwnerAsync(targetUsername, clientId, realm).ConfigureAwait(false);
            
            await RevokeOwnershipAsync(targetUsername, clientId, realm).ConfigureAwait(false);
            
            // Логируем только если сервис аудита доступен
            if (_auditService != null)
            {
                try
                {
                    await _auditService.LogAccessRevokedAsync(adminUsername, targetUsername, clientId, realm)
                        .ConfigureAwait(false);
                }
                catch (Exception auditEx)
                {
                    // Компенсирующая транзакция: восстанавливаем владение, если оно было
                    _logger.LogWarning(auditEx, 
                        "Ошибка аудита при отзыве доступа. Восстанавливаем изменение владения.");
                    if (wasOwner)
                    {
                        try
                        {
                            // Проверяем, что владение еще не занято другим пользователем
                            var currentOwner = await GetClientOwnerAsync(clientId, realm).ConfigureAwait(false);
                            if (currentOwner == null || currentOwner == targetUsername)
                            {
                                await GrantOwnershipAsync(targetUsername, clientId, realm).ConfigureAwait(false);
                            }
                            else
                            {
                                _logger.LogWarning(
                                    "Невозможно восстановить владение для пользователя {Username} и клиента {ClientId}, так как клиент уже принадлежит {CurrentOwner}", 
                                    targetUsername, clientId, currentOwner);
                            }
                        }
                        catch (Exception restoreEx)
                        {
                            _logger.LogError(restoreEx, 
                                "Ошибка при восстановлении владения после ошибки аудита для пользователя {Username} и клиента {ClientId}", 
                                targetUsername, clientId);
                        }
                    }
                    throw;
                }
            }
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка отзыва доступа с аудитом");
            throw;
        }
    }
    
    /// <summary>
    /// Удалить все записи владения для клиента (при удалении клиента)
    /// </summary>
    public async Task RemoveAllClientOwnershipsAsync(string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateClientRealmParameters(clientId, realm);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                DELETE FROM user_client_ownership 
                WHERE client_id = @clientId AND realm = @realm";
            
            AddTypedParameter(command, "@clientId", SqliteType.Text, clientId);
            AddTypedParameter(command, "@realm", SqliteType.Text, realm);
            
            var deletedRows = await command.ExecuteNonQueryAsync().ConfigureAwait(false);
            
            if (deletedRows > 0)
            {
                _logger.LogInformation("Удалено {Count} записей владения для клиента {ClientId} в реалме {Realm}", 
                    deletedRows, clientId, realm);
            }
            else
            {
                _logger.LogDebug("Записи владения для клиента {ClientId} в реалме {Realm} не найдены или уже были удалены", 
                    clientId, realm);
            }
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка удаления записей владения для клиента {ClientId} в реалме {Realm}", clientId, realm);
            throw;
        }
    }
    
    /// <summary>
    /// Проверить, есть ли владельцы у клиента
    /// </summary>
    public async Task<bool> HasOwnersAsync(string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateClientRealmParameters(clientId, realm);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                SELECT COUNT(*) FROM user_client_ownership 
                WHERE client_id = @clientId AND realm = @realm";
            
            AddTypedParameter(command, "@clientId", SqliteType.Text, clientId);
            AddTypedParameter(command, "@realm", SqliteType.Text, realm);
            
            var count = await command.ExecuteScalarAsync().ConfigureAwait(false);
            var result = SafeConvertToInt32(count, "HasOwnersAsync") > 0;
            
            _logger.LogDebug(
                "Проверка владельцев клиента {ClientId} в реалме {Realm}: {HasOwners}",
                clientId, realm, result ? "есть владельцы" : "нет владельцев");
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            
            return result;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка проверки владельцев клиента {ClientId}", clientId);
            throw;
        }
    }
    
    /// <summary>
    /// Получить всех владельцев клиента
    /// </summary>
    public async Task<List<string>> GetClientOwnersAsync(string clientId, string realm)
    {
        ThrowIfDisposed();
        ValidateClientRealmParameters(clientId, realm);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            
            var command = connection.CreateCommand();
            command.CommandTimeout = CommandTimeoutSeconds;
            command.CommandText = @"
                SELECT username FROM user_client_ownership 
                WHERE client_id = @clientId AND realm = @realm 
                ORDER BY created_at ASC";
            
            AddTypedParameter(command, "@clientId", SqliteType.Text, clientId);
            AddTypedParameter(command, "@realm", SqliteType.Text, realm);
            
            var owners = new List<string>();
            await using var reader = await command.ExecuteReaderAsync().ConfigureAwait(false);
            var usernameOrdinal = reader.GetOrdinal("username");
            while (await reader.ReadAsync().ConfigureAwait(false))
            {
                owners.Add(reader.GetString(usernameOrdinal));
            }
            
            _logger.LogDebug(
                "Получено {Count} владельцев для клиента {ClientId} в реалме {Realm}",
                owners.Count, clientId, realm);
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            
            return owners;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка получения владельцев клиента {ClientId}", clientId);
            throw;
        }
    }
    
    /// <summary>
    /// Массовое предоставление владения
    /// </summary>
    public async Task GrantOwnershipBatchAsync(string username, IEnumerable<string> clientIds, string realm)
    {
        ThrowIfDisposed();
        ValidateUsernameRealmParameters(username, realm);
        ArgumentNullException.ThrowIfNull(clientIds);
        
        // Оптимизация: используем массив для более эффективной работы с батчами
        var clientIdsArray = clientIds as string[] ?? clientIds.ToArray();
        if (clientIdsArray.Length == 0)
        {
            _logger.LogWarning("Попытка массового предоставления владения с пустым списком клиентов для пользователя {Username}", username);
            return;
        }
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            var totalAffected = 0;
            var skipped = 0;
            
            // Обработка больших коллекций батчами с оптимизированным batch INSERT
            for (int i = 0; i < clientIdsArray.Length; i += BatchSize)
            {
                var batchEnd = Math.Min(i + BatchSize, clientIdsArray.Length);
                var batchCount = batchEnd - i;
                
                await using var connection = new SqliteConnection(_connectionString);
                await connection.OpenAsync().ConfigureAwait(false);
                
                await using var transaction = (Microsoft.Data.Sqlite.SqliteTransaction)await connection.BeginTransactionAsync().ConfigureAwait(false);
                
                try
                {
                    // Валидация всех clientId в батче
                    for (int j = i; j < batchEnd; j++)
                    {
                        ValidateStringParameter(clientIdsArray[j], nameof(clientIds), MaxClientIdLength, "ClientId");
                    }
                    
                    // Создаем batch INSERT с VALUES списком
                    var valuesParts = new List<string>(batchCount);
                    var command = connection.CreateCommand();
                    command.Transaction = transaction;
                    command.CommandTimeout = CommandTimeoutSeconds;
                    
                    // Добавляем параметры
                    AddTypedParameter(command, "@username", SqliteType.Text, username);
                    AddTypedParameter(command, "@realm", SqliteType.Text, realm);
                    
                    for (int j = 0; j < batchCount; j++)
                    {
                        var paramName = $"@clientId{j}";
                        valuesParts.Add($"(@username, {paramName}, @realm)");
                        AddTypedParameter(command, paramName, SqliteType.Text, clientIdsArray[i + j]);
                    }
                    
                    // Используем INSERT OR IGNORE для пропуска дубликатов
                    command.CommandText = $@"
                        INSERT OR IGNORE INTO user_client_ownership (username, client_id, realm) 
                        VALUES {string.Join(", ", valuesParts)}";
                    
                    var rowsAffected = await command.ExecuteNonQueryAsync().ConfigureAwait(false);
                    totalAffected += rowsAffected;
                    skipped += (batchCount - rowsAffected);
                    
                    await transaction.CommitAsync().ConfigureAwait(false);
                }
                catch
                {
                    await SafeRollbackAsync(transaction, "GrantOwnershipBatchAsync").ConfigureAwait(false);
                    throw;
                }
            }
            
            _logger.LogInformation(
                "Массовое предоставление владения: добавлено {Added} клиентов, пропущено {Skipped} (уже существуют) для пользователя {Username} в реалме {Realm}",
                totalAffected, skipped, username, realm);
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка массового предоставления владения для пользователя {Username}", username);
            throw;
        }
    }
    
    /// <summary>
    /// Массовый отзыв владения
    /// </summary>
    public async Task RevokeOwnershipBatchAsync(string username, IEnumerable<string> clientIds, string realm)
    {
        ThrowIfDisposed();
        ValidateUsernameRealmParameters(username, realm);
        ArgumentNullException.ThrowIfNull(clientIds);
        
        // Оптимизация: используем массив для более эффективной работы с батчами
        var clientIdsArray = clientIds as string[] ?? clientIds.ToArray();
        if (clientIdsArray.Length == 0)
        {
            _logger.LogWarning("Попытка массового отзыва владения с пустым списком клиентов для пользователя {Username}", username);
            return;
        }
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            var totalDeleted = 0;
            
            // Обработка больших коллекций батчами с оптимизированным batch DELETE
            for (int i = 0; i < clientIdsArray.Length; i += BatchSize)
            {
                var batchEnd = Math.Min(i + BatchSize, clientIdsArray.Length);
                var batchCount = batchEnd - i;
                
                await using var connection = new SqliteConnection(_connectionString);
                await connection.OpenAsync().ConfigureAwait(false);
                
                await using var transaction = (Microsoft.Data.Sqlite.SqliteTransaction)await connection.BeginTransactionAsync().ConfigureAwait(false);
                
                try
                {
                    // Валидация всех clientId в батче
                    for (int j = i; j < batchEnd; j++)
                    {
                        ValidateStringParameter(clientIdsArray[j], nameof(clientIds), MaxClientIdLength, "ClientId");
                    }
                    
                    // Создаем batch DELETE с IN клаузой
                    var command = connection.CreateCommand();
                    command.Transaction = transaction;
                    command.CommandTimeout = CommandTimeoutSeconds;
                    
                    // Добавляем параметры
                    AddTypedParameter(command, "@username", SqliteType.Text, username);
                    AddTypedParameter(command, "@realm", SqliteType.Text, realm);
                    
                    var placeholders = new List<string>(batchCount);
                    for (int j = 0; j < batchCount; j++)
                    {
                        var paramName = $"@clientId{j}";
                        placeholders.Add(paramName);
                        AddTypedParameter(command, paramName, SqliteType.Text, clientIdsArray[i + j]);
                    }
                    
                    // Используем IN клаузу для эффективного удаления
                    command.CommandText = $@"
                        DELETE FROM user_client_ownership 
                        WHERE username = @username AND realm = @realm AND client_id IN ({string.Join(", ", placeholders)})";
                    
                    var rowsAffected = await command.ExecuteNonQueryAsync().ConfigureAwait(false);
                    totalDeleted += rowsAffected;
                    
                    await transaction.CommitAsync().ConfigureAwait(false);
                }
                catch
                {
                    await SafeRollbackAsync(transaction, "RevokeOwnershipBatchAsync").ConfigureAwait(false);
                    throw;
                }
            }
            
            _logger.LogInformation(
                "Массовый отзыв владения: удалено {Deleted} клиентов для пользователя {Username} в реалме {Realm}",
                totalDeleted, username, realm);
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка массового отзыва владения для пользователя {Username}", username);
            throw;
        }
    }
    
    /// <summary>
    /// Освобождение ресурсов
    /// </summary>
    public void Dispose()
    {
        if (_disposed)
            return;
        
        _initSemaphore?.Dispose();
        _transferLock?.Dispose();
        _disposed = true;
    }
}
