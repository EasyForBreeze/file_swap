using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Linq;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для работы с событиями клиента
/// </summary>
public class ClientEventsService : IClientEventsService
{
    private readonly ILogger<ClientEventsService> _logger;
    private readonly IPerformanceMetricsService? _metricsService;
    
    // Константы для валидации и ограничений
    private const int MaxPageSize = 1000;
    private const int MaxEventsToProcess = 1_000_000;
    private const int MinValidYear = 1900;
    private const int MaxValidYear = 2100;
    
    // Имена операций для метрик
    private const string OperationName_GetUniqueEventTypes = "ClientEvents.GetUniqueEventTypes";
    private const string OperationName_GetUniqueEventTypesAsync = "ClientEvents.GetUniqueEventTypesAsync";
    private const string OperationName_ApplyFilters = "ClientEvents.ApplyFilters";
    private const string OperationName_ApplyFiltersAsync = "ClientEvents.ApplyFiltersAsync";
    private const string OperationName_GetPageEvents = "ClientEvents.GetPageEvents";
    private const string OperationName_GetPageEventsAsync = "ClientEvents.GetPageEventsAsync";
    
    public ClientEventsService(
        ILogger<ClientEventsService> logger,
        IPerformanceMetricsService? metricsService = null)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _metricsService = metricsService;
    }
    
    /// <summary>
    /// Получить уникальные типы событий из списка событий
    /// </summary>
    /// <param name="events">Коллекция событий клиента. Может быть null.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Отсортированный список уникальных типов событий. Возвращает пустую коллекцию, если events равен null или не содержит событий.</returns>
    public IReadOnlyList<string> GetUniqueEventTypes(IEnumerable<ClientEventDto> events, CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            if (events == null)
            {
                _logger.LogWarning("GetUniqueEventTypes called with null events collection");
                return Array.Empty<string>();
            }

            // Создаем копию коллекции для защиты от изменений во время итерации
            // Для IEnumerable это может быть неэффективно, но обеспечивает безопасность
            var eventsList = events as IList<ClientEventDto> ?? events.ToList();

            // Используем HashSet для уникальности и лучшей производительности
            var uniqueTypes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var processedCount = 0;
            
            foreach (var evt in eventsList)
            {
                cancellationToken.ThrowIfCancellationRequested();
                
                // Проверяем null до инкремента счетчика (проблема #17)
                if (evt == null)
                {
                    continue;
                }
                
                if (++processedCount > MaxEventsToProcess)
                {
                    _logger.LogWarning("GetUniqueEventTypes: processed {Count} events, stopping to prevent memory issues", processedCount);
                    break;
                }
                
                if (!string.IsNullOrWhiteSpace(evt.Type))
                {
                    uniqueTypes.Add(evt.Type);
                }
            }
            
            var result = uniqueTypes
                .OrderBy(t => t, StringComparer.Ordinal)
                .ToList();
            
            _logger.LogInformation("GetUniqueEventTypes: found {Count} unique types from {ProcessedCount} events", 
                result.Count, processedCount);
            
            _metricsService?.RecordSuccess(OperationName_GetUniqueEventTypes);
            return result;
        }
        catch (OperationCanceledException)
        {
            _logger.LogInformation("GetUniqueEventTypes operation was cancelled");
            _metricsService?.RecordError(OperationName_GetUniqueEventTypes, "Cancelled");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in GetUniqueEventTypes");
            _metricsService?.RecordError(OperationName_GetUniqueEventTypes, ex.GetType().Name);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            _metricsService?.RecordOperationTime(OperationName_GetUniqueEventTypes, stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Применить фильтры к событиям
    /// </summary>
    /// <param name="events">Коллекция событий для фильтрации. Может быть null.</param>
    /// <param name="eventType">Тип события для фильтрации. Если null, пустая строка или "all", фильтр не применяется.</param>
    /// <param name="userFilter">Фильтр по пользователю. Если null или пустая строка, фильтр не применяется. Значение "system" фильтрует события без UserId.</param>
    /// <param name="dateFrom">Начальная дата диапазона. Если null, фильтр не применяется.</param>
    /// <param name="dateTo">Конечная дата диапазона. Если null, фильтр не применяется.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Отсортированный по времени (от новых к старым) список отфильтрованных событий.</returns>
    /// <exception cref="ArgumentException">Выбрасывается, если dateFrom больше dateTo или если даты невалидны.</exception>
    public IReadOnlyList<ClientEventDto> ApplyFilters(
        IEnumerable<ClientEventDto> events,
        string? eventType,
        string? userFilter,
        DateTime? dateFrom,
        DateTime? dateTo,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            if (events == null)
            {
                _logger.LogWarning("ApplyFilters called with null events collection");
                return Array.Empty<ClientEventDto>();
            }
            
            ValidateFilters(dateFrom, dateTo);

            // Создаем копию коллекции для защиты от изменений во время итерации (проблема #7)
            var eventsList = events as IList<ClientEventDto> ?? events.ToList();
            
            // Ограничение на количество обрабатываемых событий (проблема #9)
            if (eventsList.Count > MaxEventsToProcess)
            {
                _logger.LogWarning("ApplyFilters: input collection contains {Count} events, limiting to {MaxEvents} to prevent memory issues", 
                    eventsList.Count, MaxEventsToProcess);
                eventsList = eventsList.Take(MaxEventsToProcess).ToList();
            }

            // Объединяем все фильтры в один Where для лучшей производительности (проблема #10)
            var filtered = eventsList
                .Where(e =>
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    
                    if (e == null) return false;
                    
                    // Фильтр по типу события
                    var eventTypeMatch = string.IsNullOrWhiteSpace(eventType) || 
                                        eventType == "all" || 
                                        (!string.IsNullOrWhiteSpace(e.Type) && 
                                         e.Type.Equals(eventType, StringComparison.OrdinalIgnoreCase));
                    
                    if (!eventTypeMatch) return false;
                    
                    // Фильтр по пользователю
                    var userMatch = string.IsNullOrWhiteSpace(userFilter) ||
                                   (!string.IsNullOrEmpty(e.UserId) && 
                                    e.UserId.Contains(userFilter, StringComparison.OrdinalIgnoreCase)) ||
                                   (string.IsNullOrEmpty(e.UserId) && 
                                    userFilter.Equals("system", StringComparison.OrdinalIgnoreCase));
                    
                    if (!userMatch) return false;
                    
                    // Фильтр по датам
                    if (dateFrom.HasValue && e.Time < dateFrom.Value) return false;
                    if (dateTo.HasValue && e.Time > dateTo.Value) return false;
                    
                    return true;
                })
                .OrderByDescending(e => e.Time)
                .ToList();
            
            _logger.LogInformation("ApplyFilters: filtered {FilteredCount} events from input collection of {InputCount}", 
                filtered.Count, eventsList.Count);
            
            _metricsService?.RecordSuccess(OperationName_ApplyFilters);
            return filtered;
        }
        catch (OperationCanceledException)
        {
            _logger.LogInformation("ApplyFilters operation was cancelled");
            _metricsService?.RecordError(OperationName_ApplyFilters, "Cancelled");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in ApplyFilters");
            _metricsService?.RecordError(OperationName_ApplyFilters, ex.GetType().Name);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            _metricsService?.RecordOperationTime(OperationName_ApplyFilters, stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Получить отфильтрованные события для страницы
    /// </summary>
    /// <param name="events">Коллекция событий для пагинации. Может быть null.
    /// ВНИМАНИЕ: Для IEnumerable метод Skip/Take может требовать перечисления всей коллекции до нужной позиции.
    /// Для лучшей производительности используйте IQueryable версию GetPageEventsAsync.</param>
    /// <param name="page">Номер страницы (начиная с 1). Должен быть больше 0.</param>
    /// <param name="pageSize">Размер страницы. Должен быть больше 0.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список событий для указанной страницы.</returns>
    /// <exception cref="ArgumentException">Выбрасывается, если page или pageSize меньше или равны 0.</exception>
    public IReadOnlyList<ClientEventDto> GetPageEvents(
        IEnumerable<ClientEventDto> events,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            if (events == null)
            {
                _logger.LogWarning("GetPageEvents called with null events collection");
                return Array.Empty<ClientEventDto>();
            }
            
            ValidatePagination(page, pageSize);
            
            // Улучшенная проверка на переполнение (проблема #3)
            int skip;
            try
            {
                checked
                {
                    skip = (page - 1) * pageSize;
                }
            }
            catch (OverflowException)
            {
                var message = $"Page {page} with page size {pageSize} would cause overflow";
                _logger.LogError(message);
                throw new ArgumentException(message, nameof(page));
            }
            
            // Создаем копию коллекции для защиты от изменений (проблема #7)
            // Для IEnumerable это может быть неэффективно, но обеспечивает безопасность
            var eventsList = events as IList<ClientEventDto> ?? events.ToList();
            
            var result = eventsList
                .Skip(skip)
                .Take(pageSize)
                .ToList();
            
            _logger.LogInformation("GetPageEvents: returning {Count} events for page {Page}", 
                result.Count, page);
            
            _metricsService?.RecordSuccess(OperationName_GetPageEvents);
            return result;
        }
        catch (OperationCanceledException)
        {
            _logger.LogInformation("GetPageEvents operation was cancelled");
            _metricsService?.RecordError(OperationName_GetPageEvents, "Cancelled");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in GetPageEvents");
            _metricsService?.RecordError(OperationName_GetPageEvents, ex.GetType().Name);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            _metricsService?.RecordOperationTime(OperationName_GetPageEvents, stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Получить общее количество страниц
    /// </summary>
    /// <param name="totalEvents">Общее количество событий. Не может быть отрицательным.</param>
    /// <param name="pageSize">Размер страницы. Должен быть больше 0.</param>
    /// <returns>Количество страниц. Возвращает 0, если totalEvents равен 0.</returns>
    /// <exception cref="ArgumentException">Выбрасывается, если totalEvents отрицательное или pageSize меньше или равен 0.</exception>
    public int GetTotalPages(int totalEvents, int pageSize)
    {
        if (totalEvents < 0)
        {
            var message = "Total events cannot be negative";
            _logger.LogError(message);
            throw new ArgumentException(message, nameof(totalEvents));
        }
        
        if (pageSize < 1)
        {
            var message = "Page size must be greater than 0";
            _logger.LogError(message);
            throw new ArgumentException(message, nameof(pageSize));
        }
        
        if (pageSize > MaxPageSize)
        {
            var message = $"Page size cannot exceed {MaxPageSize}";
            _logger.LogWarning(message);
            throw new ArgumentException(message, nameof(pageSize));
        }
        
        if (totalEvents == 0) return 0;
        
        var totalPages = (int)Math.Ceiling((double)totalEvents / pageSize);
        _logger.LogDebug("GetTotalPages: {TotalEvents} events with page size {PageSize} = {TotalPages} pages", 
            totalEvents, pageSize, totalPages);
        
        return totalPages;
    }
    
    /// <summary>
    /// Получить уникальные типы событий из IQueryable (для оптимизации работы с БД)
    /// </summary>
    /// <param name="events">Queryable коллекция событий клиента</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Отсортированный список уникальных типов событий</returns>
    public async Task<IReadOnlyList<string>> GetUniqueEventTypesAsync(
        IQueryable<ClientEventDto> events,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            if (events == null)
            {
                _logger.LogWarning("GetUniqueEventTypesAsync called with null events collection");
                return Array.Empty<string>();
            }

            // Фильтрация выполняется на уровне БД через IQueryable
            var uniqueTypes = await Task.Run(() =>
            {
                return events
                    .Where(e => e != null && !string.IsNullOrWhiteSpace(e.Type))
                    .Select(e => e.Type)
                    .Distinct()
                    .OrderBy(t => t)
                    .ToList();
            }, cancellationToken);
            
            _logger.LogInformation("GetUniqueEventTypesAsync: found {Count} unique types", uniqueTypes.Count);
            
            _metricsService?.RecordSuccess(OperationName_GetUniqueEventTypesAsync);
            return uniqueTypes;
        }
        catch (NotSupportedException ex)
        {
            _logger.LogError(ex, "Query provider does not support the requested operation in GetUniqueEventTypesAsync");
            _metricsService?.RecordError(OperationName_GetUniqueEventTypesAsync, "NotSupported");
            throw new InvalidOperationException("The query cannot be executed with the current provider. Please ensure your data provider supports the required operations.", ex);
        }
        catch (OperationCanceledException)
        {
            _logger.LogInformation("GetUniqueEventTypesAsync operation was cancelled");
            _metricsService?.RecordError(OperationName_GetUniqueEventTypesAsync, "Cancelled");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing query in GetUniqueEventTypesAsync");
            _metricsService?.RecordError(OperationName_GetUniqueEventTypesAsync, ex.GetType().Name);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            _metricsService?.RecordOperationTime(OperationName_GetUniqueEventTypesAsync, stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Применить фильтры к событиям из IQueryable (для оптимизации работы с БД)
    /// </summary>
    /// <param name="events">Queryable коллекция событий для фильтрации</param>
    /// <param name="eventType">Тип события для фильтрации. Если null, пустая строка или "all", фильтр не применяется.</param>
    /// <param name="userFilter">Фильтр по пользователю. Если null или пустая строка, фильтр не применяется. Значение "system" фильтрует события без UserId.</param>
    /// <param name="dateFrom">Начальная дата диапазона. Если null, фильтр не применяется.</param>
    /// <param name="dateTo">Конечная дата диапазона. Если null, фильтр не применяется.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Отсортированный по времени (от новых к старым) список отфильтрованных событий.</returns>
    /// <exception cref="ArgumentException">Выбрасывается, если dateFrom больше dateTo или если даты невалидны.</exception>
    /// <exception cref="InvalidOperationException">Выбрасывается, если провайдер запросов не поддерживает операцию.</exception>
    public async Task<IReadOnlyList<ClientEventDto>> ApplyFiltersAsync(
        IQueryable<ClientEventDto> events,
        string? eventType,
        string? userFilter,
        DateTime? dateFrom,
        DateTime? dateTo,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            if (events == null)
            {
                _logger.LogWarning("ApplyFiltersAsync called with null events collection");
                return Array.Empty<ClientEventDto>();
            }
            
            ValidateFilters(dateFrom, dateTo);

            // Применяем все фильтры, которые можно выполнить на уровне БД (проблема #1)
            var query = events.Where(e => e != null);
            
            // Фильтры по датам можно применить на уровне БД
            if (dateFrom.HasValue)
            {
                query = query.Where(e => e.Time >= dateFrom.Value);
            }
            
            if (dateTo.HasValue)
            {
                query = query.Where(e => e.Time <= dateTo.Value);
            }
            
            // Применяем фильтры по типу события и пользователю
            // Для регистронезависимого сравнения в IQueryable некоторые провайдеры могут не поддерживать
            // StringComparison.OrdinalIgnoreCase, поэтому применяем фильтры на уровне БД где возможно,
            // а остальные фильтруем в памяти после материализации
            IQueryable<ClientEventDto> filteredQuery = query;
            
            // Пытаемся применить фильтры на уровне БД
            // Если провайдер не поддерживает, NotSupportedException будет выброшен при выполнении
            if (!string.IsNullOrWhiteSpace(eventType) && eventType != "all")
            {
                // Используем ToLower для совместимости с большинством провайдеров
                var lowerEventType = eventType.ToLower();
                filteredQuery = filteredQuery.Where(e => !string.IsNullOrWhiteSpace(e.Type) && 
                                                         e.Type.ToLower() == lowerEventType);
            }
            
            if (!string.IsNullOrWhiteSpace(userFilter))
            {
                var isSystemFilter = userFilter.Equals("system", StringComparison.OrdinalIgnoreCase);
                if (isSystemFilter)
                {
                    filteredQuery = filteredQuery.Where(e => string.IsNullOrEmpty(e.UserId));
                }
                else
                {
                    var lowerUserFilter = userFilter.ToLower();
                    filteredQuery = filteredQuery.Where(e => !string.IsNullOrEmpty(e.UserId) && 
                                                             e.UserId.ToLower().Contains(lowerUserFilter));
                }
            }
            
            // Применяем сортировку на уровне БД
            filteredQuery = filteredQuery.OrderByDescending(e => e.Time);
            
            // Материализуем с ограничением для защиты от больших результатов (проблема #1)
            // Если провайдер не поддерживает операцию, NotSupportedException будет выброшен здесь
            List<ClientEventDto> materialized;
            try
            {
                materialized = await Task.Run(() => filteredQuery.Take(MaxEventsToProcess).ToList(), cancellationToken);
            }
            catch (NotSupportedException)
            {
                // Если провайдер не поддерживает операции, материализуем базовый запрос
                // и применяем фильтры в памяти
                var baseQuery = query.OrderByDescending(e => e.Time);
                materialized = await Task.Run(() => baseQuery.Take(MaxEventsToProcess).ToList(), cancellationToken);
                
                // Применяем фильтры в памяти с использованием StringComparison.OrdinalIgnoreCase (проблема #4)
                var filtered = materialized.AsEnumerable();
                
                if (!string.IsNullOrWhiteSpace(eventType) && eventType != "all")
                {
                    filtered = filtered.Where(e => !string.IsNullOrWhiteSpace(e.Type) && 
                                                   e.Type.Equals(eventType, StringComparison.OrdinalIgnoreCase));
                }
                
                if (!string.IsNullOrWhiteSpace(userFilter))
                {
                    var isSystemFilter = userFilter.Equals("system", StringComparison.OrdinalIgnoreCase);
                    if (isSystemFilter)
                    {
                        filtered = filtered.Where(e => string.IsNullOrEmpty(e.UserId));
                    }
                    else
                    {
                        filtered = filtered.Where(e => !string.IsNullOrEmpty(e.UserId) && 
                                                       e.UserId.Contains(userFilter, StringComparison.OrdinalIgnoreCase));
                    }
                }
                
                materialized = filtered.OrderByDescending(e => e.Time).ToList();
            }
            
            _logger.LogInformation("ApplyFiltersAsync: filtered {FilteredCount} events from query", materialized.Count);
            
            _metricsService?.RecordSuccess(OperationName_ApplyFiltersAsync);
            return materialized;
        }
        catch (NotSupportedException ex)
        {
            _logger.LogError(ex, "Query provider does not support the requested operation in ApplyFiltersAsync");
            _metricsService?.RecordError(OperationName_ApplyFiltersAsync, "NotSupported");
            throw new InvalidOperationException("The query cannot be executed with the current provider. Please ensure your data provider supports the required operations.", ex);
        }
        catch (OperationCanceledException)
        {
            _logger.LogInformation("ApplyFiltersAsync operation was cancelled");
            _metricsService?.RecordError(OperationName_ApplyFiltersAsync, "Cancelled");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing query in ApplyFiltersAsync");
            _metricsService?.RecordError(OperationName_ApplyFiltersAsync, ex.GetType().Name);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            _metricsService?.RecordOperationTime(OperationName_ApplyFiltersAsync, stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Получить отфильтрованные события для страницы из IQueryable (для оптимизации работы с БД)
    /// </summary>
    /// <param name="events">Queryable коллекция событий для пагинации</param>
    /// <param name="page">Номер страницы (начиная с 1). Должен быть больше 0.</param>
    /// <param name="pageSize">Размер страницы. Должен быть больше 0.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список событий для указанной страницы.</returns>
    /// <exception cref="ArgumentException">Выбрасывается, если page или pageSize меньше или равны 0.</exception>
    /// <exception cref="InvalidOperationException">Выбрасывается, если провайдер запросов не поддерживает операцию.</exception>
    public async Task<IReadOnlyList<ClientEventDto>> GetPageEventsAsync(
        IQueryable<ClientEventDto> events,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            if (events == null)
            {
                _logger.LogWarning("GetPageEventsAsync called with null events collection");
                return Array.Empty<ClientEventDto>();
            }
            
            ValidatePagination(page, pageSize);
            
            // Улучшенная проверка на переполнение (проблема #3)
            int skip;
            try
            {
                checked
                {
                    skip = (page - 1) * pageSize;
                }
            }
            catch (OverflowException)
            {
                var message = $"Page {page} with page size {pageSize} would cause overflow";
                _logger.LogError(message);
                throw new ArgumentException(message, nameof(page));
            }
            
            // Фильтрация и пагинация выполняются на уровне БД через IQueryable
            int totalCount;
            try
            {
                totalCount = await Task.Run(() => events.Count(), cancellationToken);
            }
            catch (NotSupportedException ex)
            {
                _logger.LogError(ex, "Query provider does not support Count() operation in GetPageEventsAsync");
                _metricsService?.RecordError(OperationName_GetPageEventsAsync, "NotSupported");
                throw new InvalidOperationException("The query provider does not support the Count() operation. Please ensure your data provider supports this operation.", ex);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing Count() in GetPageEventsAsync");
                _metricsService?.RecordError(OperationName_GetPageEventsAsync, ex.GetType().Name);
                throw;
            }
            
            var totalPages = GetTotalPages(totalCount, pageSize);
            
            if (page > totalPages && totalPages > 0)
            {
                _logger.LogInformation("GetPageEventsAsync: requested page {Page} is greater than total pages {TotalPages}, returning empty collection", 
                    page, totalPages);
                return Array.Empty<ClientEventDto>();
            }
            
            var result = await Task.Run(() =>
            {
                return events
                    .Skip(skip)
                    .Take(pageSize)
                    .ToList();
            }, cancellationToken);
            
            _logger.LogInformation("GetPageEventsAsync: returning {Count} events for page {Page} of {TotalPages}", 
                result.Count, page, totalPages);
            
            _metricsService?.RecordSuccess(OperationName_GetPageEventsAsync);
            return result;
        }
        catch (NotSupportedException ex)
        {
            _logger.LogError(ex, "Query provider does not support the requested operation in GetPageEventsAsync");
            _metricsService?.RecordError(OperationName_GetPageEventsAsync, "NotSupported");
            throw new InvalidOperationException("The query cannot be executed with the current provider. Please ensure your data provider supports the required operations.", ex);
        }
        catch (OperationCanceledException)
        {
            _logger.LogInformation("GetPageEventsAsync operation was cancelled");
            _metricsService?.RecordError(OperationName_GetPageEventsAsync, "Cancelled");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing query in GetPageEventsAsync");
            _metricsService?.RecordError(OperationName_GetPageEventsAsync, ex.GetType().Name);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            _metricsService?.RecordOperationTime(OperationName_GetPageEventsAsync, stopwatch.ElapsedMilliseconds);
        }
    }
    
    /// <summary>
    /// Проверяет, является ли DateTime валидным значением
    /// </summary>
    /// <param name="dateTime">Дата для проверки</param>
    /// <returns>true, если дата валидна, иначе false</returns>
    private static bool IsValidDateTime(DateTime dateTime)
    {
        return dateTime != DateTime.MinValue && 
               dateTime != DateTime.MaxValue &&
               dateTime.Year >= MinValidYear && 
               dateTime.Year <= MaxValidYear;
    }
    
    /// <summary>
    /// Валидирует параметры фильтрации дат
    /// </summary>
    /// <param name="dateFrom">Начальная дата диапазона</param>
    /// <param name="dateTo">Конечная дата диапазона</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    private void ValidateFilters(DateTime? dateFrom, DateTime? dateTo)
    {
        if (dateFrom.HasValue && dateTo.HasValue && dateFrom.Value > dateTo.Value)
        {
            var message = "DateFrom cannot be greater than DateTo";
            _logger.LogError(message);
            throw new ArgumentException(message, nameof(dateFrom));
        }
        
        if (dateFrom.HasValue && !IsValidDateTime(dateFrom.Value))
        {
            var message = $"Invalid DateFrom value. Year must be between {MinValidYear} and {MaxValidYear}";
            _logger.LogError(message);
            throw new ArgumentException(message, nameof(dateFrom));
        }
        
        if (dateTo.HasValue && !IsValidDateTime(dateTo.Value))
        {
            var message = $"Invalid DateTo value. Year must be between {MinValidYear} and {MaxValidYear}";
            _logger.LogError(message);
            throw new ArgumentException(message, nameof(dateTo));
        }
    }
    
    /// <summary>
    /// Валидирует параметры пагинации
    /// </summary>
    /// <param name="page">Номер страницы</param>
    /// <param name="pageSize">Размер страницы</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    private void ValidatePagination(int page, int pageSize)
    {
        if (page < 1)
        {
            var message = "Page must be greater than 0";
            _logger.LogError(message);
            throw new ArgumentException(message, nameof(page));
        }
        
        if (pageSize < 1)
        {
            var message = "Page size must be greater than 0";
            _logger.LogError(message);
            throw new ArgumentException(message, nameof(pageSize));
        }
        
        if (pageSize > MaxPageSize)
        {
            var message = $"Page size cannot exceed {MaxPageSize}";
            _logger.LogWarning(message);
            throw new ArgumentException(message, nameof(pageSize));
        }
    }
}
