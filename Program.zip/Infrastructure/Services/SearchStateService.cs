using System.Collections.Concurrent;
using System.Linq;
using System.Security.Claims;
using System.Threading;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.Constants;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services
{
    /// <summary>
    /// Сервис для управления состоянием поиска клиентов и кэширования данных
    /// </summary>
    /// <remarks>
    /// Сервис обеспечивает потокобезопасность, защиту от утечек памяти и изоляцию данных по пользователям.
    /// Все операции логируются для мониторинга и отладки.
    /// </remarks>
    public class SearchStateService : ISearchStateService, IDisposable
    {
        // Потокобезопасные блокировки
        private readonly ReaderWriterLockSlim _stateLock = new ReaderWriterLockSlim();
        private readonly ReaderWriterLockSlim _cacheLock = new ReaderWriterLockSlim();
        private readonly object _disposeLock = new object();

        // Состояние поиска (изолировано по пользователям)
        private readonly ConcurrentDictionary<string, UserSearchState> _userStates = new();

        // Кэш клиентов пользователя (изолирован по пользователям)
        private readonly ConcurrentDictionary<string, UserCacheState> _userCaches = new();

        // Событие для запроса обновления списка клиентов (защита от утечек памяти)
        private readonly WeakEventManager _refreshEventManager = new WeakEventManager();

        // Метрики кэша
        private long _cacheHits = 0;
        private long _cacheMisses = 0;

        // Метрики сервиса
        private long _totalOperations = 0;
        private long _totalErrors = 0;
        private long _totalUsers = 0;

        // Зависимости
        private readonly ILogger<SearchStateService> _logger;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly SearchStateServiceSettings _settings;
        private volatile bool _disposed = false;

        // Константы для валидации
        private const int MaxSearchQueryLength = 1000;
        private const int MaxCurrentPage = int.MaxValue;
        private const int MaxUsersLimit = 10000; // Максимальное количество пользователей

        /// <summary>
        /// Событие запроса на обновление списка клиентов
        /// </summary>
        /// <remarks>
        /// Использует WeakEventManager для автоматической очистки подписчиков и предотвращения утечек памяти.
        /// </remarks>
        public event Action? OnUserClientsRefreshRequested
        {
            add => _refreshEventManager.AddEventHandler(value);
            remove => _refreshEventManager.RemoveEventHandler(value);
        }

        /// <summary>
        /// Инициализирует новый экземпляр SearchStateService
        /// </summary>
        /// <param name="logger">Логгер для записи операций</param>
        /// <param name="httpContextAccessor">Доступ к HttpContext для получения текущего пользователя</param>
        /// <param name="options">Настройки сервиса</param>
        /// <exception cref="ArgumentNullException">Когда любой из параметров равен null</exception>
        public SearchStateService(
            ILogger<SearchStateService> logger, 
            IHttpContextAccessor httpContextAccessor,
            IOptions<SearchStateServiceSettings> options)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
            _settings = options?.Value ?? throw new ArgumentNullException(nameof(options));

            // Валидация настроек
            if (_settings.MaxCacheSize <= 0)
            {
                throw new ArgumentException("MaxCacheSize must be greater than 0", nameof(options));
            }

            if (_settings.DefaultCacheExpiration <= TimeSpan.Zero)
            {
                throw new ArgumentException("DefaultCacheExpiration must be greater than TimeSpan.Zero", nameof(options));
            }
        }

        /// <summary>
        /// Получает идентификатор текущего пользователя
        /// </summary>
        /// <returns>Идентификатор пользователя или "anonymous" если пользователь не аутентифицирован</returns>
        private string GetCurrentUserId()
        {
            try
            {
                var httpContext = _httpContextAccessor?.HttpContext;
                if (httpContext?.User?.Identity?.IsAuthenticated == true)
                {
                    // Приоритет: Subject (sub) > Name (preferred_username) > Identity.Name
                    var userId = httpContext.User.FindFirstValue(Claims.Subject)
                        ?? httpContext.User.FindFirstValue(Claims.Name)
                        ?? httpContext.User.Identity?.Name
                        ?? "anonymous";
                    
                    // Валидация полученного userId
                    if (string.IsNullOrWhiteSpace(userId))
                    {
                        _logger.LogWarning("Received empty userId, using 'anonymous'");
                        return "anonymous";
                    }

                    return userId;
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Не удалось получить идентификатор пользователя из HttpContext");
            }

            return "anonymous";
        }

        /// <summary>
        /// Сохраняет состояние поиска для текущего пользователя
        /// </summary>
        /// <param name="searchQuery">Поисковый запрос. Не может быть null.</param>
        /// <param name="searchResponse">Результат поиска. Может быть null.</param>
        /// <param name="currentPage">Номер текущей страницы. Должен быть больше 0.</param>
        /// <param name="lastSearchTime">Время последнего поиска в UTC. Не может быть в будущем.</param>
        /// <exception cref="ArgumentNullException">Когда searchQuery равен null.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Когда currentPage меньше 1.</exception>
        /// <exception cref="ArgumentException">Когда lastSearchTime в будущем.</exception>
        /// <remarks>
        /// Все временные метки должны быть в UTC. Если передано локальное время, оно будет обработано как UTC.
        /// </remarks>
        public void SaveSearchState(string searchQuery, ClientsSearchResponse? searchResponse, int currentPage, DateTime? lastSearchTime)
        {
            // Валидация параметров до входа в lock
            ArgumentNullException.ThrowIfNull(searchQuery);

            if (string.IsNullOrWhiteSpace(searchQuery))
            {
                throw new ArgumentException("Search query cannot be empty", nameof(searchQuery));
            }

            if (searchQuery.Length > MaxSearchQueryLength)
            {
                throw new ArgumentException($"Search query length cannot exceed {MaxSearchQueryLength} characters", nameof(searchQuery));
            }

            if (currentPage < 1)
            {
                throw new ArgumentOutOfRangeException(nameof(currentPage), "Page number must be greater than 0");
            }

            if (currentPage > MaxCurrentPage)
            {
                throw new ArgumentOutOfRangeException(nameof(currentPage), $"Page number cannot exceed {MaxCurrentPage}");
            }

            // Валидация searchResponse
            if (searchResponse != null)
            {
                if (searchResponse.TotalFound < 0)
                {
                    throw new ArgumentException("TotalFound cannot be negative", nameof(searchResponse));
                }

                if (searchResponse.Clients != null && searchResponse.Clients.Any(c => c == null))
                {
                    throw new ArgumentException("SearchResponse.Clients cannot contain null elements", nameof(searchResponse));
                }
            }

            DateTime? normalizedLastSearchTime = null;
            if (lastSearchTime.HasValue)
            {
                // Нормализуем время в UTC для корректного сравнения
                var utcTime = lastSearchTime.Value.Kind == DateTimeKind.Unspecified
                    ? DateTime.SpecifyKind(lastSearchTime.Value, DateTimeKind.Utc)
                    : lastSearchTime.Value.ToUniversalTime();

                if (utcTime > DateTime.UtcNow)
                {
                    throw new ArgumentException("Last search time cannot be in the future", nameof(lastSearchTime));
                }

                normalizedLastSearchTime = utcTime;
            }

            try
            {
                Interlocked.Increment(ref _totalOperations);
                var userId = GetCurrentUserId();

                try
                {
                    _stateLock.EnterWriteLock();
                    try
                    {
                        ThrowIfDisposedLocked();

                        // Проверка ограничения на количество пользователей
                        if (!_userStates.ContainsKey(userId) && _userStates.Count >= MaxUsersLimit)
                        {
                            _logger.LogWarning(
                                "Maximum users limit ({MaxUsers}) reached. Cannot add new user state for {UserId}",
                                MaxUsersLimit, userId);
                            throw new InvalidOperationException($"Maximum users limit ({MaxUsersLimit}) reached");
                        }

                        var state = _userStates.GetOrAdd(userId, _ => 
                        {
                            Interlocked.Increment(ref _totalUsers);
                            return new UserSearchState();
                        });
                        state.SearchQuery = searchQuery;
                        state.SearchResponse = searchResponse;
                        state.CurrentPage = currentPage;
                        state.LastSearchTime = normalizedLastSearchTime;
                        state.HasState = true;

                        _logger.LogDebug(
                            "Search state saved for user {UserId}: Query={Query}, Page={Page}, Results={Results}",
                            userId, searchQuery, currentPage, searchResponse?.TotalFound ?? 0);
                    }
                    finally
                    {
                        _stateLock.ExitWriteLock();
                    }
                }
                catch (LockRecursionException ex)
                {
                    _logger.LogError(ex, "Lock recursion detected in SaveSearchState");
                    Interlocked.Increment(ref _totalErrors);
                    throw;
                }
                catch (ObjectDisposedException)
                {
                    Interlocked.Increment(ref _totalErrors);
                    throw;
                }
            }
            catch (Exception ex) when (!(ex is ArgumentException || ex is ArgumentOutOfRangeException || ex is InvalidOperationException))
            {
                _logger.LogError(ex, "Failed to save search state");
                Interlocked.Increment(ref _totalErrors);
                throw;
            }
        }

        /// <summary>
        /// Получает сохраненное состояние поиска для текущего пользователя
        /// </summary>
        /// <returns>Состояние поиска или null, если состояние не сохранено</returns>
        /// <remarks>
        /// Все временные метки используют UTC время.
        /// </remarks>
        public SearchState? GetSearchState()
        {
            try
            {
                Interlocked.Increment(ref _totalOperations);
                var userId = GetCurrentUserId();

                try
                {
                    _stateLock.EnterReadLock();
                    try
                    {
                        ThrowIfDisposedLocked();

                        if (_userStates.TryGetValue(userId, out var state) && state.HasState)
                        {
                            return new SearchState
                            {
                                SearchQuery = state.SearchQuery,
                                SearchResponse = state.SearchResponse,
                                CurrentPage = state.CurrentPage,
                                LastSearchTime = state.LastSearchTime
                            };
                        }
                    }
                    finally
                    {
                        _stateLock.ExitReadLock();
                    }
                }
                catch (LockRecursionException ex)
                {
                    _logger.LogError(ex, "Lock recursion detected in GetSearchState");
                    Interlocked.Increment(ref _totalErrors);
                    return null;
                }
                catch (ObjectDisposedException)
                {
                    Interlocked.Increment(ref _totalErrors);
                    return null;
                }

                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to get search state");
                Interlocked.Increment(ref _totalErrors);
                return null;
            }
        }

        /// <summary>
        /// Получает сохраненное состояние поиска для текущего пользователя (асинхронная версия)
        /// </summary>
        /// <param name="cancellationToken">Токен отмены операции</param>
        /// <returns>Состояние поиска или null, если состояние не сохранено</returns>
        /// <remarks>
        /// Все временные метки используют UTC время.
        /// </remarks>
        public Task<SearchState?> GetSearchStateAsync(CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return Task.FromResult(GetSearchState());
        }

        /// <summary>
        /// Очищает сохраненное состояние поиска для текущего пользователя
        /// </summary>
        public void ClearSearchState()
        {
            try
            {
                Interlocked.Increment(ref _totalOperations);
                var userId = GetCurrentUserId();

                try
                {
                    _stateLock.EnterWriteLock();
                    try
                    {
                        ThrowIfDisposedLocked();

                        if (_userStates.TryGetValue(userId, out var state))
                        {
                            state.SearchQuery = string.Empty;
                            state.SearchResponse = null;
                            state.CurrentPage = 1;
                            state.LastSearchTime = null;
                            state.HasState = false;

                            _logger.LogDebug("Search state cleared for user {UserId}", userId);
                        }
                    }
                    finally
                    {
                        _stateLock.ExitWriteLock();
                    }
                }
                catch (LockRecursionException ex)
                {
                    _logger.LogError(ex, "Lock recursion detected in ClearSearchState");
                    Interlocked.Increment(ref _totalErrors);
                }
                catch (ObjectDisposedException)
                {
                    Interlocked.Increment(ref _totalErrors);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to clear search state");
                Interlocked.Increment(ref _totalErrors);
            }
        }

        /// <summary>
        /// Проверяет, есть ли сохраненное состояние поиска для текущего пользователя
        /// </summary>
        /// <returns>true если состояние сохранено, иначе false</returns>
        public bool HasSavedState()
        {
            try
            {
                Interlocked.Increment(ref _totalOperations);
                var userId = GetCurrentUserId();

                try
                {
                    _stateLock.EnterReadLock();
                    try
                    {
                        ThrowIfDisposedLocked();
                        return _userStates.TryGetValue(userId, out var state) && state.HasState;
                    }
                    finally
                    {
                        _stateLock.ExitReadLock();
                    }
                }
                catch (LockRecursionException ex)
                {
                    _logger.LogError(ex, "Lock recursion detected in HasSavedState");
                    Interlocked.Increment(ref _totalErrors);
                    return false;
                }
                catch (ObjectDisposedException)
                {
                    Interlocked.Increment(ref _totalErrors);
                    return false;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to check saved state");
                Interlocked.Increment(ref _totalErrors);
                return false;
            }
        }

        /// <summary>
        /// Сохраняет список клиентов пользователя в кэш
        /// </summary>
        /// <param name="clients">Список клиентов для кэширования. Не может быть null.</param>
        /// <exception cref="ArgumentNullException">Когда clients равен null.</exception>
        public void CacheUserClients(List<ClientDetailsDto> clients)
        {
            ArgumentNullException.ThrowIfNull(clients);

            if (clients.Count == 0)
            {
                throw new ArgumentException("Clients list cannot be empty", nameof(clients));
            }

            // Проверка на null элементы
            if (clients.Any(c => c == null))
            {
                throw new ArgumentException("Clients list cannot contain null elements", nameof(clients));
            }

            // Проверка максимальной длины списка
            if (clients.Count > _settings.MaxCacheSize * 2)
            {
                throw new ArgumentException($"Clients list cannot exceed {_settings.MaxCacheSize * 2} elements", nameof(clients));
            }

            try
            {
                Interlocked.Increment(ref _totalOperations);
                var userId = GetCurrentUserId();

                // Ограничение размера кэша - оптимизируем сортировку
                List<ClientDetailsDto> clientsToCache;
                if (clients.Count > _settings.MaxCacheSize)
                {
                    // Используем более эффективный подход: частичная сортировка
                    var sortedClients = clients.OrderByDescending(c => c.UpdatedAt);
                    clientsToCache = new List<ClientDetailsDto>(_settings.MaxCacheSize);
                    foreach (var client in sortedClients.Take(_settings.MaxCacheSize))
                    {
                        clientsToCache.Add(client);
                    }
                }
                else
                {
                    // Создаем копию списка для защиты от модификации
                    clientsToCache = new List<ClientDetailsDto>(clients);
                }

                try
                {
                    _cacheLock.EnterWriteLock();
                    try
                    {
                        ThrowIfDisposedLocked();

                        // Проверка ограничения на количество пользователей
                        if (!_userCaches.ContainsKey(userId) && _userCaches.Count >= MaxUsersLimit)
                        {
                            _logger.LogWarning(
                                "Maximum users limit ({MaxUsers}) reached. Cannot add new user cache for {UserId}",
                                MaxUsersLimit, userId);
                            throw new InvalidOperationException($"Maximum users limit ({MaxUsersLimit}) reached");
                        }

                        var cacheState = _userCaches.GetOrAdd(userId, _ => 
                        {
                            Interlocked.Increment(ref _totalUsers);
                            return new UserCacheState();
                        });
                        cacheState.CachedClients = clientsToCache;
                        cacheState.CacheTimestamp = DateTime.UtcNow;

                        _logger.LogDebug(
                            "User clients cached for user {UserId}: Count={Count}",
                            userId, cacheState.CachedClients.Count);
                    }
                    finally
                    {
                        _cacheLock.ExitWriteLock();
                    }
                }
                catch (LockRecursionException ex)
                {
                    _logger.LogError(ex, "Lock recursion detected in CacheUserClients");
                    Interlocked.Increment(ref _totalErrors);
                    throw;
                }
                catch (ObjectDisposedException)
                {
                    Interlocked.Increment(ref _totalErrors);
                    throw;
                }
            }
            catch (Exception ex) when (!(ex is ArgumentException || ex is InvalidOperationException))
            {
                _logger.LogError(ex, "Failed to cache user clients");
                Interlocked.Increment(ref _totalErrors);
                throw;
            }
        }

        /// <summary>
        /// Получает кэшированные клиенты пользователя (возвращает копию для защиты от модификации)
        /// </summary>
        /// <returns>Копия списка кэшированных клиентов или null если кэш пуст</returns>
        public List<ClientDetailsDto>? GetCachedUserClients()
        {
            try
            {
                Interlocked.Increment(ref _totalOperations);
                var userId = GetCurrentUserId();

                try
                {
                    _cacheLock.EnterReadLock();
                    try
                    {
                        ThrowIfDisposedLocked();

                        if (_userCaches.TryGetValue(userId, out var cacheState) && cacheState.CachedClients != null)
                        {
                            Interlocked.Increment(ref _cacheHits);
                            // Возвращаем копию для защиты от модификации - оптимизированное создание списка
                            var result = new List<ClientDetailsDto>(cacheState.CachedClients.Count);
                            foreach (var client in cacheState.CachedClients)
                            {
                                result.Add(client);
                            }
                            return result;
                        }
                    }
                    finally
                    {
                        _cacheLock.ExitReadLock();
                    }
                }
                catch (LockRecursionException ex)
                {
                    _logger.LogError(ex, "Lock recursion detected in GetCachedUserClients");
                    Interlocked.Increment(ref _totalErrors);
                    Interlocked.Increment(ref _cacheMisses);
                    return null;
                }
                catch (ObjectDisposedException)
                {
                    Interlocked.Increment(ref _totalErrors);
                    Interlocked.Increment(ref _cacheMisses);
                    return null;
                }

                Interlocked.Increment(ref _cacheMisses);
                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to get cached user clients");
                Interlocked.Increment(ref _totalErrors);
                Interlocked.Increment(ref _cacheMisses);
                return null;
            }
        }

        /// <summary>
        /// Проверяет, актуален ли кэш клиентов для текущего пользователя (не старше указанного времени)
        /// </summary>
        /// <param name="maxAge">Максимальный возраст кэша</param>
        /// <returns>true если кэш валиден, иначе false</returns>
        public bool IsUserClientsCacheValid(TimeSpan maxAge)
        {
            if (maxAge <= TimeSpan.Zero)
            {
                throw new ArgumentException("maxAge must be greater than TimeSpan.Zero", nameof(maxAge));
            }

            try
            {
                Interlocked.Increment(ref _totalOperations);
                var userId = GetCurrentUserId();

                // Кэшируем текущее время для консистентности
                var now = DateTime.UtcNow;

                try
                {
                    _cacheLock.EnterReadLock();
                    try
                    {
                        ThrowIfDisposedLocked();

                        if (!_userCaches.TryGetValue(userId, out var cacheState) || 
                            cacheState.CachedClients == null || 
                            cacheState.CacheTimestamp == null)
                        {
                            return false;
                        }

                        var age = now - cacheState.CacheTimestamp.Value;
                        return age < maxAge;
                    }
                    finally
                    {
                        _cacheLock.ExitReadLock();
                    }
                }
                catch (LockRecursionException ex)
                {
                    _logger.LogError(ex, "Lock recursion detected in IsUserClientsCacheValid");
                    Interlocked.Increment(ref _totalErrors);
                    return false;
                }
                catch (ObjectDisposedException)
                {
                    Interlocked.Increment(ref _totalErrors);
                    return false;
                }
            }
            catch (Exception ex) when (!(ex is ArgumentException))
            {
                _logger.LogError(ex, "Failed to check cache validity");
                Interlocked.Increment(ref _totalErrors);
                return false;
            }
        }

        /// <summary>
        /// Инвалидирует (очищает) кэш клиентов для текущего пользователя
        /// </summary>
        public void InvalidateUserClientsCache()
        {
            try
            {
                Interlocked.Increment(ref _totalOperations);
                var userId = GetCurrentUserId();

                try
                {
                    _cacheLock.EnterWriteLock();
                    try
                    {
                        ThrowIfDisposedLocked();

                        if (_userCaches.TryGetValue(userId, out var cacheState))
                        {
                            cacheState.CachedClients = null;
                            cacheState.CacheTimestamp = null;

                            _logger.LogDebug("User clients cache invalidated for user {UserId}", userId);
                        }
                    }
                    finally
                    {
                        _cacheLock.ExitWriteLock();
                    }
                }
                catch (LockRecursionException ex)
                {
                    _logger.LogError(ex, "Lock recursion detected in InvalidateUserClientsCache");
                    Interlocked.Increment(ref _totalErrors);
                }
                catch (ObjectDisposedException)
                {
                    Interlocked.Increment(ref _totalErrors);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to invalidate user clients cache");
                Interlocked.Increment(ref _totalErrors);
            }
        }

        /// <summary>
        /// Запрашивает принудительное обновление списка клиентов
        /// </summary>
        public void RequestUserClientsRefresh()
        {
            try
            {
                Interlocked.Increment(ref _totalOperations);
                var userId = GetCurrentUserId();

                // Инвалидируем кэш
                InvalidateUserClientsCache();

                // Вызываем событие через WeakEventManager
                _refreshEventManager.RaiseEvent();

                _logger.LogDebug("User clients refresh requested for user {UserId}", userId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to request user clients refresh");
                Interlocked.Increment(ref _totalErrors);
            }
        }

        /// <summary>
        /// Сохраняет состояние поиска для текущего пользователя (асинхронная версия)
        /// </summary>
        /// <param name="searchQuery">Поисковый запрос. Не может быть null.</param>
        /// <param name="searchResponse">Результат поиска. Может быть null.</param>
        /// <param name="currentPage">Номер текущей страницы. Должен быть больше 0.</param>
        /// <param name="lastSearchTime">Время последнего поиска в UTC. Не может быть в будущем.</param>
        /// <param name="cancellationToken">Токен отмены операции</param>
        /// <exception cref="ArgumentNullException">Когда searchQuery равен null.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Когда currentPage меньше 1.</exception>
        /// <exception cref="ArgumentException">Когда lastSearchTime в будущем.</exception>
        /// <remarks>
        /// Все временные метки должны быть в UTC. Если передано локальное время, оно будет обработано как UTC.
        /// </remarks>
        public Task SaveSearchStateAsync(string searchQuery, ClientsSearchResponse? searchResponse, int currentPage, DateTime? lastSearchTime, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            SaveSearchState(searchQuery, searchResponse, currentPage, lastSearchTime);
            return Task.CompletedTask;
        }

        /// <summary>
        /// Получает метрики использования кэша
        /// </summary>
        /// <returns>Кортеж с количеством попаданий, промахов и процентом попаданий</returns>
        public (long Hits, long Misses, double HitRate) GetCacheMetrics()
        {
            // Используем обычное чтение для long на 64-битных платформах (атомарно по умолчанию)
            var hits = Volatile.Read(ref _cacheHits);
            var misses = Volatile.Read(ref _cacheMisses);
            var total = hits + misses;
            var hitRate = total > 0 ? (double)hits / total : 0.0;

            return (hits, misses, hitRate);
        }

        /// <summary>
        /// Получает метрики использования сервиса
        /// </summary>
        /// <returns>Кортеж с общим количеством операций, ошибок, пользователей и размером словарей</returns>
        public (long TotalOperations, long TotalErrors, long TotalUsers, int StatesCount, int CachesCount) GetServiceMetrics()
        {
            var operations = Volatile.Read(ref _totalOperations);
            var errors = Volatile.Read(ref _totalErrors);
            var users = Volatile.Read(ref _totalUsers);
            
            int statesCount, cachesCount;
            try
            {
                _stateLock.EnterReadLock();
                try
                {
                    statesCount = _userStates.Count;
                }
                finally
                {
                    _stateLock.ExitReadLock();
                }

                _cacheLock.EnterReadLock();
                try
                {
                    cachesCount = _userCaches.Count;
                }
                finally
                {
                    _cacheLock.ExitReadLock();
                }
            }
            catch
            {
                statesCount = 0;
                cachesCount = 0;
            }

            return (operations, errors, users, statesCount, cachesCount);
        }

        /// <summary>
        /// Очищает устаревшие состояния пользователей для освобождения памяти
        /// </summary>
        /// <param name="maxAge">Максимальный возраст состояния. Состояния старше этого возраста будут удалены.</param>
        /// <returns>Количество удаленных состояний</returns>
        /// <remarks>
        /// Этот метод следует вызывать периодически (например, через фоновый сервис) для предотвращения утечек памяти.
        /// </remarks>
        public int CleanupOldStates(TimeSpan maxAge)
        {
            if (maxAge <= TimeSpan.Zero)
            {
                throw new ArgumentException("maxAge must be greater than TimeSpan.Zero", nameof(maxAge));
            }

            var removedCount = 0;
            var startTime = DateTime.UtcNow;
            var cutoffTime = startTime - maxAge;
            const int maxCleanupDurationSeconds = 30; // Максимальное время выполнения очистки

            try
            {
                Interlocked.Increment(ref _totalOperations);

                // Очистка состояний поиска
                try
                {
                    _stateLock.EnterWriteLock();
                    try
                    {
                        ThrowIfDisposedLocked();

                        // Проверяем таймаут перед началом очистки
                        if ((DateTime.UtcNow - startTime).TotalSeconds > maxCleanupDurationSeconds)
                        {
                            _logger.LogWarning("Cleanup timeout reached before processing states");
                            return removedCount;
                        }

                        // Используем более эффективный подход: собираем ключи для удаления
                        var statesToRemove = new List<string>(Math.Min(_userStates.Count, 1000));
                        foreach (var kvp in _userStates)
                        {
                            // Проверяем таймаут во время итерации
                            if ((DateTime.UtcNow - startTime).TotalSeconds > maxCleanupDurationSeconds)
                            {
                                _logger.LogWarning("Cleanup timeout reached during states iteration");
                                break;
                            }

                            if (kvp.Value.LastSearchTime.HasValue && 
                                kvp.Value.LastSearchTime.Value < cutoffTime)
                            {
                                statesToRemove.Add(kvp.Key);
                            }
                        }

                        // Удаляем найденные ключи
                        foreach (var key in statesToRemove)
                        {
                            if (_userStates.TryRemove(key, out _))
                            {
                                removedCount++;
                            }
                        }
                    }
                    finally
                    {
                        _stateLock.ExitWriteLock();
                    }
                }
                catch (LockRecursionException ex)
                {
                    _logger.LogError(ex, "Lock recursion detected in CleanupOldStates (states)");
                    Interlocked.Increment(ref _totalErrors);
                }
                catch (ObjectDisposedException)
                {
                    Interlocked.Increment(ref _totalErrors);
                    return removedCount;
                }

                // Очистка кэшей
                try
                {
                    _cacheLock.EnterWriteLock();
                    try
                    {
                        ThrowIfDisposedLocked();

                        // Проверяем таймаут перед началом очистки кэшей
                        if ((DateTime.UtcNow - startTime).TotalSeconds > maxCleanupDurationSeconds)
                        {
                            _logger.LogWarning("Cleanup timeout reached before processing caches");
                            return removedCount;
                        }

                        var cachesToRemove = new List<string>(Math.Min(_userCaches.Count, 1000));
                        foreach (var kvp in _userCaches)
                        {
                            // Проверяем таймаут во время итерации
                            if ((DateTime.UtcNow - startTime).TotalSeconds > maxCleanupDurationSeconds)
                            {
                                _logger.LogWarning("Cleanup timeout reached during caches iteration");
                                break;
                            }

                            if (kvp.Value.CacheTimestamp.HasValue && 
                                kvp.Value.CacheTimestamp.Value < cutoffTime)
                            {
                                cachesToRemove.Add(kvp.Key);
                            }
                        }

                        // Удаляем найденные ключи
                        foreach (var key in cachesToRemove)
                        {
                            if (_userCaches.TryRemove(key, out _))
                            {
                                removedCount++;
                            }
                        }
                    }
                    finally
                    {
                        _cacheLock.ExitWriteLock();
                    }
                }
                catch (LockRecursionException ex)
                {
                    _logger.LogError(ex, "Lock recursion detected in CleanupOldStates (caches)");
                    Interlocked.Increment(ref _totalErrors);
                }
                catch (ObjectDisposedException)
                {
                    Interlocked.Increment(ref _totalErrors);
                }

                if (removedCount > 0)
                {
                    _logger.LogInformation(
                        "Cleaned up {Count} old user states older than {MaxAge}",
                        removedCount, maxAge);
                }
            }
            catch (Exception ex) when (!(ex is ArgumentException))
            {
                _logger.LogError(ex, "Failed to cleanup old states");
                Interlocked.Increment(ref _totalErrors);
            }

            return removedCount;
        }

        /// <summary>
        /// Проверяет, не был ли объект освобожден
        /// </summary>
        /// <exception cref="ObjectDisposedException">Когда объект уже освобожден</exception>
        private void ThrowIfDisposed()
        {
            // Используем volatile чтение для потокобезопасности
            if (_disposed)
            {
                throw new ObjectDisposedException(nameof(SearchStateService));
            }
        }

        /// <summary>
        /// Проверяет, не был ли объект освобожден (для использования внутри lock)
        /// </summary>
        /// <exception cref="ObjectDisposedException">Когда объект уже освобожден</exception>
        private void ThrowIfDisposedLocked()
        {
            // Внутри lock проверяем еще раз для защиты от race condition
            if (_disposed)
            {
                throw new ObjectDisposedException(nameof(SearchStateService));
            }
        }

        /// <summary>
        /// Освобождает ресурсы
        /// </summary>
        public void Dispose()
        {
            // Используем volatile чтение и запись для потокобезопасности
            if (!_disposed)
            {
                lock (_disposeLock)
                {
                    if (!_disposed)
                    {
                        try
                        {
                            _stateLock?.Dispose();
                        }
                        catch (Exception ex)
                        {
                            _logger?.LogError(ex, "Error disposing state lock");
                        }

                        try
                        {
                            _cacheLock?.Dispose();
                        }
                        catch (Exception ex)
                        {
                            _logger?.LogError(ex, "Error disposing cache lock");
                        }
                        
                        // Очищаем состояния пользователей для освобождения памяти
                        _userStates.Clear();
                        _userCaches.Clear();
                        
                        _disposed = true;
                    }
                }
            }
        }

        /// <summary>
        /// Внутренний класс для хранения состояния поиска пользователя
        /// </summary>
        private class UserSearchState
        {
            public string SearchQuery { get; set; } = string.Empty;
            public ClientsSearchResponse? SearchResponse { get; set; }
            public int CurrentPage { get; set; } = 1;
            public DateTime? LastSearchTime { get; set; }
            public bool HasState { get; set; } = false;
        }

        /// <summary>
        /// Внутренний класс для хранения кэша клиентов пользователя
        /// </summary>
        private class UserCacheState
        {
            public List<ClientDetailsDto>? CachedClients { get; set; }
            public DateTime? CacheTimestamp { get; set; }
        }
    }
}
