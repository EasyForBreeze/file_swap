namespace new_assistant.Infrastructure.Services.KeycloakAdmin;

/// <summary>
/// Вспомогательный класс для форматирования ролей
/// </summary>
public static class RoleFormatHelper
{
    public const char ClientRoleSeparator = '|';
    public const char RolePartSeparator = ':';
    
    public static string FormatClientRole(string clientId, string clientInternalId, string roleId, string roleName)
    {
        return $"{clientId}{ClientRoleSeparator}{clientInternalId}{RolePartSeparator}{roleId}{RolePartSeparator}{roleName}";
    }
    
    public static (string? ClientId, string? ClientInternalId, string? RoleId, string? RoleName) ParseClientRole(string roleStr)
    {
        if (string.IsNullOrEmpty(roleStr))
            return (null, null, null, null);
        
        if (!roleStr.Contains(ClientRoleSeparator) || !roleStr.Contains(RolePartSeparator))
            return (null, null, null, null);
        
        var firstSplit = roleStr.Split(ClientRoleSeparator, 2);
        if (firstSplit.Length != 2)
            return (null, null, null, null);
        
        var secondPart = firstSplit[1];
        var parts = secondPart.Split(RolePartSeparator, 3);
        
        if (parts.Length != 3)
            return (null, null, null, null);
        
        return (firstSplit[0], parts[0], parts[1], parts[2]);
    }
}

