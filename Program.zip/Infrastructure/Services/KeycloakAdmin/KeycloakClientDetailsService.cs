using System.Diagnostics;
using System.Text.Json;
using System.Text.Json.Serialization;
using new_assistant.Core.Interfaces;
using new_assistant.Core.DTOs;
using System.Linq;
using new_assistant.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using static new_assistant.Infrastructure.Services.KeycloakAdmin.KeycloakClientConstants;

namespace new_assistant.Infrastructure.Services.KeycloakAdmin;

/// <summary>
/// Сервис для получения детальной информации о клиентах Keycloak
/// </summary>
public class KeycloakClientDetailsService : IKeycloakClientDetailsService
{
    private readonly KeycloakHttpClient _httpClient;
    private readonly KeycloakAdminSettings _settings;
    private readonly ILogger<KeycloakClientDetailsService> _logger;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IKeycloakCacheService _cacheService;
    private readonly IPerformanceMetricsService _metricsService;

    public KeycloakClientDetailsService(
        KeycloakHttpClient httpClient,
        IOptions<KeycloakAdminSettings> settings,
        ILogger<KeycloakClientDetailsService> logger,
        IHttpClientFactory httpClientFactory,
        IKeycloakCacheService cacheService,
        IPerformanceMetricsService metricsService)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _settings = settings?.Value ?? throw new ArgumentNullException(nameof(settings));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _httpClientFactory = httpClientFactory ?? throw new ArgumentNullException(nameof(httpClientFactory));
        _cacheService = cacheService ?? throw new ArgumentNullException(nameof(cacheService));
        _metricsService = metricsService ?? throw new ArgumentNullException(nameof(metricsService));
    }

    /// <summary>
    /// Получить детальную информацию о клиенте
    /// </summary>
    public async Task<ClientDetailsDto?> GetClientDetailsAsync(string clientId, string realm, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId не может быть пустым", nameof(clientId));
        
        // Валидация длины параметров (исправление проблемы #22)
        const int MaxClientIdLength = 200;
        const int MaxRealmLength = 100;
        if (clientId.Length > MaxClientIdLength)
            throw new ArgumentException($"ClientId не может быть длиннее {MaxClientIdLength} символов", nameof(clientId));
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        if (realm.Length > MaxRealmLength)
            throw new ArgumentException($"Realm не может быть длиннее {MaxRealmLength} символов", nameof(realm));
        
        var stopwatch = Stopwatch.StartNew();
        try
        {
            // Получаем полную информацию о клиенте из KeyCloak
            var clientJson = await _httpClient.GetClientFullInfoAsync(realm, clientId, cancellationToken);
            
            if (clientJson == null)
            {
                _logger.LogWarning("Клиент {ClientId} не найден в реалме {Realm}", clientId, realm);
                return null;
            }
            
            // Получаем internal ID клиента для дальнейших запросов
            var internalId = GetStringProperty(clientJson.Value, "id");
            
            // Получаем дополнительную информацию (параллельно для оптимизации)
            var rolesTask = internalId != null ? GetClientRolesAsyncInternal(internalId, realm, cancellationToken) : Task.FromResult((new List<string>(), new List<string>()));
            var endpointsTask = GetClientEndpointsAsync(clientId, realm, cancellationToken);
            var secretTask = internalId != null ? _httpClient.GetClientSecretAsync(realm, internalId, cancellationToken) : Task.FromResult<string?>(null);
            var defaultScopesTask = internalId != null ? _httpClient.GetClientScopesAsync(realm, internalId, isDefault: true, cancellationToken) : Task.FromResult(new List<string>());
            var optionalScopesTask = internalId != null ? _httpClient.GetClientScopesAsync(realm, internalId, isDefault: false, cancellationToken) : Task.FromResult(new List<string>());
            
            // События не загружаем сразу - будут загружены лениво при переходе на вкладку Events
            await Task.WhenAll(rolesTask, endpointsTask, secretTask, defaultScopesTask, optionalScopesTask);
            
            var roles = await rolesTask;
            var endpoints = await endpointsTask;
            var secret = await secretTask;
            var defaultScopes = await defaultScopesTask;
            var optionalScopes = await optionalScopesTask;
            
            // Парсим JSON и формируем детальную информацию
            var id = GetStringProperty(clientJson.Value, "id");
            if (string.IsNullOrEmpty(id))
            {
                // Улучшенная обработка ошибок для обязательных полей (исправление проблемы #5)
                _logger.LogError("Клиент {ClientId} не содержит обязательного поля 'id' в реалме {Realm}", clientId, realm);
                throw new InvalidOperationException($"Клиент '{clientId}' в реалме '{realm}' не содержит обязательного поля 'id'");
            }
            
            var details = new ClientDetailsDto
            {
                // Основная информация
                Id = id,
                ClientId = GetStringProperty(clientJson.Value, "clientId") ?? clientId,
                Name = GetStringProperty(clientJson.Value, "name") ?? "",
                Description = GetStringProperty(clientJson.Value, "description"),
                Enabled = GetBoolProperty(clientJson.Value, "enabled", true),
                Protocol = GetStringProperty(clientJson.Value, "protocol") ?? ProtocolOpenIdConnect,
                
                // URLs
                RootUrl = GetStringProperty(clientJson.Value, "rootUrl"),
                BaseUrl = GetStringProperty(clientJson.Value, "baseUrl"),
                AdminUrl = GetStringProperty(clientJson.Value, "adminUrl"),
                
                // Lists
                RedirectUris = GetStringArrayProperty(clientJson.Value, "redirectUris"),
                WebOrigins = GetStringArrayProperty(clientJson.Value, "webOrigins"),
                
                // Capability config
                ClientAuthentication = !GetBoolProperty(clientJson.Value, "publicClient", false), // publicClient = false означает требуется аутентификация
                StandardFlow = GetBoolProperty(clientJson.Value, "standardFlowEnabled", true),
                ServiceAccountsEnabled = GetBoolProperty(clientJson.Value, "serviceAccountsEnabled", false),
                DirectAccessGrantsEnabled = GetBoolProperty(clientJson.Value, "directAccessGrantsEnabled", false),
                AuthorizationServicesEnabled = GetBoolProperty(clientJson.Value, "authorizationServicesEnabled", false),
                FrontChannelLogout = GetBoolProperty(clientJson.Value, "frontchannelLogout", false),
                
                // Определяем ClientType
                ClientType = GetBoolProperty(clientJson.Value, "publicClient", false) ? AccessTypePublic : 
                            GetBoolProperty(clientJson.Value, "bearerOnly", false) ? AccessTypeBearerOnly : AccessTypeConfidential,
                AccessType = GetBoolProperty(clientJson.Value, "publicClient", false) ? AccessTypePublic : 
                            GetBoolProperty(clientJson.Value, "bearerOnly", false) ? AccessTypeBearerOnly : AccessTypeConfidential,
                
                // Дополнительная информация
                ClientSecret = secret,
                LocalRoles = roles.Item1,
                ServiceRoles = roles.Item2,
                Endpoints = endpoints,
                Events = new List<ClientEventDto>(), // События загружаются лениво
                Realm = realm,
                CreatedAt = GetDateTimeProperty(clientJson.Value, "createdDate"),
                UpdatedAt = GetDateTimeProperty(clientJson.Value, "lastModifiedDate"),
                Attributes = GetAttributesProperty(clientJson.Value),
                DefaultClientScopes = defaultScopes,
                OptionalClientScopes = optionalScopes
            };
            
            return details;
        }
        catch (Exception ex) when (ex.Message.Contains("not found", StringComparison.OrdinalIgnoreCase) || 
                                    ex.Message.Contains("404", StringComparison.OrdinalIgnoreCase) ||
                                    ex.Message.Contains("NotFound", StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogWarning("Клиент {ClientId} не найден в реалме {Realm}", clientId, realm);
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при получении деталей клиента {ClientId} в реалме {Realm}", clientId, realm);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            _metricsService.RecordOperationTime("KeycloakClientDetails.GetClientDetails", stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Получить роли клиента (локальные и сервисные)
    /// </summary>
    public async Task<(List<string> LocalRoles, List<string> ServiceRoles)> GetClientRolesAsync(string clientId, string realm, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId не может быть пустым", nameof(clientId));
        
        // Получаем internal ID клиента
        var clientJson = await _httpClient.GetClientFullInfoAsync(realm, clientId, cancellationToken);
        if (clientJson == null)
        {
            _logger.LogWarning("Клиент {ClientId} не найден в реалме {Realm}", clientId, realm);
            return (new List<string>(), new List<string>());
        }
        
        var internalId = GetStringProperty(clientJson.Value, "id");
        if (string.IsNullOrEmpty(internalId))
        {
            _logger.LogWarning("Клиент {ClientId} не содержит поля 'id'", clientId);
            return (new List<string>(), new List<string>());
        }
        
        return await GetClientRolesAsyncInternal(internalId, realm, cancellationToken);
    }

    /// <summary>
    /// Внутренний метод для получения ролей (используется внутри GetClientDetailsAsync)
    /// </summary>
    private async Task<(List<string> LocalRoles, List<string> ServiceRoles)> GetClientRolesAsyncInternal(string clientInternalId, string realm, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(clientInternalId))
            throw new ArgumentException("ClientInternalId не может быть пустым", nameof(clientInternalId));
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        try
        {
            // Получаем локальные роли клиента
            var localRolesDto = await _httpClient.GetClientRolesAsync(realm, clientInternalId, cancellationToken);
            
            var localRoles = new List<string>();
            foreach (var role in localRolesDto)
            {
                if (!string.IsNullOrEmpty(role.Name))
                {
                    localRoles.Add(role.Name);
                }
            }
            
            // Получаем service account роли
            var serviceRoles = new List<string>();
            
            // Сначала получаем service account пользователя
            var serviceAccountUserId = await _httpClient.GetServiceAccountUserIdAsync(realm, clientInternalId, cancellationToken);
            
            if (serviceAccountUserId != null)
            {
                // Получаем role mappings для service account пользователя  
                // Этот эндпоинт возвращает структуру с clientMappings, где ключ = clientId
                var roleMappingsResponse = await _httpClient.GetUserRoleMappingsAsync(realm, serviceAccountUserId, cancellationToken);
                
                // Парсим роли - clientId уже добавлен в GetUserRoleMappingsAsync!
                foreach (var role in roleMappingsResponse)
                {
                    var roleName = role.Name;
                    var roleId = role.Id;
                    var containerId = role.ContainerId;
                    
                    // Получаем clientId который мы добавили в GetUserRoleMappingsAsync
                    var clientIdFromRole = role.ClientId;
                    
                    if (!string.IsNullOrEmpty(roleName) && !string.IsNullOrEmpty(roleId))
                    {
                        // Проверяем является ли это client ролью
                        if (!string.IsNullOrEmpty(containerId) && !string.IsNullOrEmpty(clientIdFromRole))
                        {
                            // Client роль: сохраняем в формате "clientId|clientInternalId:roleId:roleName"
                            serviceRoles.Add(RoleFormatHelper.FormatClientRole(clientIdFromRole, containerId, roleId, roleName));
                        }
                        else
                        {
                            // Realm роль: сохраняем просто имя
                            serviceRoles.Add(roleName);
                        }
                    }
                }
            }
            // Service account не включен для клиента - это нормально, просто не будет service roles
            
            return (localRoles, serviceRoles);
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("Операция получения ролей клиента была отменена для {ClientId} в реалме {Realm}", clientInternalId, realm);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при получении ролей клиента {ClientId} в реалме {Realm}", clientInternalId, realm);
            return (new List<string>(), new List<string>());
        }
    }

    /// <summary>
    /// Получить эндпоинты клиента
    /// </summary>
    public async Task<List<string>> GetClientEndpointsAsync(string clientId, string realm, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId не может быть пустым", nameof(clientId));
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        try
        {
            // Получаем well-known конфигурацию с кэшированием (не зависит от clientId, только от realm)
            // Обработка исключений при работе с кэшем (исправление проблемы #27)
            Dictionary<string, string> wellKnownDict;
            try
            {
                wellKnownDict = await _cacheService.GetOrCreateWellKnownEndpointsAsync(
                    realm,
                    async () => await LoadWellKnownEndpointsAsync(realm, cancellationToken),
                    cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Ошибка при получении well-known endpoints из кэша для реалма {Realm}, загружаем напрямую", realm);
                wellKnownDict = await LoadWellKnownEndpointsAsync(realm, cancellationToken);
            }
            
            // Конвертируем Dictionary в List<string> для обратной совместимости
            var endpoints = wellKnownDict
                .Select(kvp => $"{kvp.Key}: {kvp.Value}")
                .ToList();
            
            return endpoints;
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("Операция получения эндпоинтов была отменена для клиента {ClientId} в реалме {Realm}", clientId, realm);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при получении эндпоинтов клиента {ClientId} в реалме {Realm}", clientId, realm);
            throw;
        }
    }

    /// <summary>
    /// Получить всех клиентов реалма в виде JsonElement
    /// </summary>
    public async Task<List<JsonElement>> GetAllClientsAsJsonAsync(string realm, CancellationToken cancellationToken = default)
    {
        return await _httpClient.GetAllClientsAsJsonAsync(realm, cancellationToken);
    }

    // Вспомогательные методы для парсинга JSON
    private string? GetStringProperty(JsonElement json, string propertyName)
    {
        return json.TryGetProperty(propertyName, out var prop) && prop.ValueKind == JsonValueKind.String 
            ? prop.GetString() 
            : null;
    }
    
    private bool GetBoolProperty(JsonElement json, string propertyName, bool defaultValue)
    {
        if (json.TryGetProperty(propertyName, out var prop) && 
            (prop.ValueKind == JsonValueKind.True || prop.ValueKind == JsonValueKind.False))
        {
            return prop.GetBoolean();
        }
        return defaultValue;
    }
    
    private List<string> GetStringArrayProperty(JsonElement json, string propertyName)
    {
        if (json.TryGetProperty(propertyName, out var prop) && prop.ValueKind == JsonValueKind.Array)
        {
            return prop.EnumerateArray()
                .Where(e => e.ValueKind == JsonValueKind.String)
                .Select(e => e.GetString() ?? string.Empty)
                .Where(s => !string.IsNullOrEmpty(s))
                .ToList();
        }
        return new List<string>();
    }
    
    private Dictionary<string, List<string>> GetAttributesProperty(JsonElement json)
    {
        var attributes = new Dictionary<string, List<string>>();
        
        if (json.TryGetProperty("attributes", out var attrProp) && attrProp.ValueKind == JsonValueKind.Object)
        {
            foreach (var property in attrProp.EnumerateObject())
            {
                switch (property.Value.ValueKind)
                {
                    case JsonValueKind.Array:
                        var values = new List<string>();
                        foreach (var element in property.Value.EnumerateArray())
                        {
                            string? elementValue;
                            try
                            {
                                elementValue = element.ValueKind == JsonValueKind.String
                                    ? element.GetString()
                                    : element.GetRawText();
                            }
                            catch (Exception ex)
                            {
                                // Обработка ошибок при получении сырого текста (исправление проблемы #17)
                                _logger.LogWarning(ex, "Ошибка при получении значения из JSON элемента для атрибута {AttributeName}", property.Name);
                                continue;
                            }

                            if (!string.IsNullOrEmpty(elementValue))
                            {
                                values.Add(elementValue);
                            }
                        }
                        if (values.Count > 0)
                        {
                            attributes[property.Name] = values;
                        }
                        break;
                    case JsonValueKind.String:
                        var stringValue = property.Value.GetString();
                        if (!string.IsNullOrEmpty(stringValue))
                        {
                            attributes[property.Name] = new List<string> { stringValue };
                        }
                        break;
                    case JsonValueKind.Number:
                    case JsonValueKind.True:
                    case JsonValueKind.False:
                        try
                        {
                            attributes[property.Name] = new List<string> { property.Value.GetRawText() };
                        }
                        catch (Exception ex)
                        {
                            // Обработка ошибок при получении сырого текста (исправление проблемы #17)
                            _logger.LogWarning(ex, "Ошибка при получении сырого текста для атрибута {AttributeName}", property.Name);
                            // Пропускаем этот атрибут
                        }
                        break;
                    default:
                        // Игнорируем сложные типы, чтобы не отправлять некорректные данные
                        break;
                }
            }
        }
        
        return attributes;
    }
    
    private DateTime GetDateTimeProperty(JsonElement json, string propertyName)
    {
        if (json.TryGetProperty(propertyName, out var prop) && prop.ValueKind == JsonValueKind.Number)
        {
            try
            {
                // Keycloak хранит даты как Unix timestamp в миллисекундах
                // Улучшенная обработка ошибок парсинга (исправление проблемы #7, #15)
                if (!prop.TryGetInt64(out var timestamp))
                {
                    _logger.LogWarning("Не удалось получить Int64 значение для свойства {PropertyName}", propertyName);
                    return DateTime.MinValue;
                }
                
                return DateTimeOffset.FromUnixTimeMilliseconds(timestamp).DateTime;
            }
            catch (ArgumentOutOfRangeException ex)
            {
                _logger.LogWarning(ex, "Значение timestamp для свойства {PropertyName} вне допустимого диапазона", propertyName);
                return DateTime.MinValue;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Ошибка при преобразовании timestamp для свойства {PropertyName}", propertyName);
                return DateTime.MinValue;
            }
        }
        return DateTime.MinValue;
    }

    /// <summary>
    /// Загрузка well-known endpoints непосредственно из Keycloak (без кэша)
    /// </summary>
    private async Task<Dictionary<string, string>> LoadWellKnownEndpointsAsync(string realm, CancellationToken cancellationToken = default)
    {
        var endpoints = new Dictionary<string, string>();
        
        using var httpClient = _httpClientFactory.CreateClient();
        try
        {
            var baseUrl = _settings.BaseUrl.TrimEnd('/');
            var authPrefix = _settings.UseLegacyAuthPath ? "/auth" : string.Empty;
            var wellKnownUrl = $"{baseUrl}{authPrefix}/realms/{realm}/.well-known/openid-configuration";
            var wellKnownResponse = await httpClient.GetAsync(wellKnownUrl, cancellationToken).ConfigureAwait(false);
            
            if (wellKnownResponse.IsSuccessStatusCode)
            {
                var wellKnownContent = await wellKnownResponse.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                var wellKnown = System.Text.Json.JsonSerializer.Deserialize<JsonElement>(wellKnownContent);
                
                if (wellKnown.ValueKind != JsonValueKind.Object)
                {
                    _logger.LogWarning("Неверный формат well-known конфигурации для реалма {Realm}", realm);
                    AddFallbackEndpoints(endpoints, realm);
                    return endpoints;
                }
                
                // Извлекаем основные эндпоинты
                if (wellKnown.TryGetProperty("issuer", out var issuer) && issuer.GetString() != null)
                    endpoints["Issuer"] = issuer.GetString()!;
                
                if (wellKnown.TryGetProperty("authorization_endpoint", out var authEndpoint) && authEndpoint.GetString() != null)
                    endpoints["Authorization"] = authEndpoint.GetString()!;
                
                if (wellKnown.TryGetProperty("token_endpoint", out var tokenEndpoint) && tokenEndpoint.GetString() != null)
                    endpoints["Token"] = tokenEndpoint.GetString()!;
                
                if (wellKnown.TryGetProperty("userinfo_endpoint", out var userinfoEndpoint) && userinfoEndpoint.GetString() != null)
                    endpoints["UserInfo"] = userinfoEndpoint.GetString()!;
                
                if (wellKnown.TryGetProperty("end_session_endpoint", out var logoutEndpoint) && logoutEndpoint.GetString() != null)
                    endpoints["Logout"] = logoutEndpoint.GetString()!;
                
                if (wellKnown.TryGetProperty("jwks_uri", out var jwksEndpoint) && jwksEndpoint.GetString() != null)
                    endpoints["JWKS"] = jwksEndpoint.GetString()!;
                
                if (wellKnown.TryGetProperty("introspection_endpoint", out var introspectionEndpoint) && introspectionEndpoint.GetString() != null)
                    endpoints["Introspection"] = introspectionEndpoint.GetString()!;
                
                if (wellKnown.TryGetProperty("revocation_endpoint", out var revocationEndpoint) && revocationEndpoint.GetString() != null)
                    endpoints["Revocation"] = revocationEndpoint.GetString()!;
            }
            else
            {
                _logger.LogWarning("Не удалось получить well-known конфигурацию по URL {Url}, используем базовые эндпоинты", wellKnownUrl);
                AddFallbackEndpoints(endpoints, realm);
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при получении well-known конфигурации по URL. BaseUrl={BaseUrl}, UseLegacyAuthPath={UseLegacy}", _settings.BaseUrl, _settings.UseLegacyAuthPath);
            AddFallbackEndpoints(endpoints, realm);
        }
        
        return endpoints;
    }
    
    private void AddFallbackEndpoints(Dictionary<string, string> endpoints, string realm)
    {
        endpoints["Authorization"] = $"{_settings.BaseUrl}/realms/{realm}/protocol/openid-connect/auth";
        endpoints["Token"] = $"{_settings.BaseUrl}/realms/{realm}/protocol/openid-connect/token";
        endpoints["UserInfo"] = $"{_settings.BaseUrl}/realms/{realm}/protocol/openid-connect/userinfo";
    }
}

