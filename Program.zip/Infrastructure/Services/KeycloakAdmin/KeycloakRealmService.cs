using new_assistant.Core.Interfaces;
using new_assistant.Core.DTOs;

namespace new_assistant.Infrastructure.Services.KeycloakAdmin;

/// <summary>
/// Сервис для работы с реалмами Keycloak
/// </summary>
public class KeycloakRealmService : IKeycloakRealmService
{
    private readonly KeycloakHttpClient _httpClient;

    public KeycloakRealmService(KeycloakHttpClient httpClient)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
    }

    /// <summary>
    /// Получить список всех реалмов (кроме master)
    /// </summary>
    public async Task<IEnumerable<string>> GetRealmsListAsync(CancellationToken cancellationToken = default)
    {
        return await _httpClient.GetRealmsListAsync(cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Получить детальную информацию о всех реалмах (с Display Name)
    /// </summary>
    public async Task<IReadOnlyList<RealmDto>> GetRealmsWithDetailsAsync(CancellationToken cancellationToken = default)
    {
        return await _httpClient.GetRealmsWithDetailsAsync(cancellationToken).ConfigureAwait(false);
    }
}

