using System.Collections.Concurrent;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для показа уведомлений с полной потокобезопасностью и оптимизацией производительности
/// </summary>
public class NotificationService : INotificationService
{
    private const int MaxNotifications = 50;
    private const int MinNotifications = 1;
    private const int MaxTitleLength = 200;
    private const int MaxMessageLength = 1000;
    private const int MaxActionTextLength = 100;
    private const int DefaultDurationMs = 5000;
    private const int ExitAnimationDurationMs = 300;
    private const int DisposeLockTimeoutMs = 100;

    private readonly Dictionary<int, NotificationItem> _notifications = new();
    private readonly SortedDictionary<(DateTime CreatedAt, int Id), int> _notificationsByTime = new();
    private readonly Dictionary<int, CancellationTokenSource> _notificationTimers = new();
    private readonly SemaphoreSlim _operationLock = new SemaphoreSlim(1, 1);
    private readonly ILogger<NotificationService> _logger;
    private long _notificationIdCounter = 0;
    private Func<Task>? _onStateChangedAsync;
    private readonly CancellationTokenSource _cts = new();
    private long _disposed = 0; // Используем long для Interlocked операций

    // Кэширование для оптимизации производительности
    private IReadOnlyList<NotificationItem>? _cachedNotifications;
    private int _lastNotificationCount = -1;
    private readonly object _cacheLock = new object();

    private static readonly Regex UrlPattern = new(@"^https?://.+", RegexOptions.Compiled | RegexOptions.IgnoreCase);

    public NotificationService(ILogger<NotificationService> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        
        // Валидация констант
        if (MaxNotifications < MinNotifications)
        {
            throw new InvalidOperationException($"MaxNotifications ({MaxNotifications}) must be greater than or equal to MinNotifications ({MinNotifications})");
        }
    }

    public IReadOnlyList<NotificationItem> Notifications
    {
        get
        {
            if (IsDisposed)
                return Array.Empty<NotificationItem>().AsReadOnly();

            lock (_cacheLock)
            {
                // Получаем безопасную копию счетчика и данных
                int currentCount;
                Dictionary<int, NotificationItem> notificationsSnapshot;
                
                // Используем синхронный Wait с таймаутом для чтения
                if (_operationLock.Wait(TimeSpan.FromMilliseconds(DisposeLockTimeoutMs)))
                {
                    try
                    {
                        currentCount = _notifications.Count;
                        notificationsSnapshot = new Dictionary<int, NotificationItem>(_notifications);
                    }
                    finally
                    {
                        _operationLock.Release();
                    }
                }
                else
                {
                    // Если не удалось получить lock, возвращаем старый кэш или пустой список
                    if (_cachedNotifications != null)
                    {
                        return _cachedNotifications;
                    }
                    return Array.Empty<NotificationItem>().AsReadOnly();
                }

                // Инвалидируем кэш только при изменении количества уведомлений
                if (_cachedNotifications == null || _lastNotificationCount != currentCount)
                {
                    // Используем snapshot для создания списка без необходимости блокировки
                    _cachedNotifications = notificationsSnapshot.Values
                        .OrderByDescending(n => n.CreatedAt)
                        .ToList()
                        .AsReadOnly();
                    _lastNotificationCount = currentCount;
                }
                return _cachedNotifications;
            }
        }
    }

    /// <summary>
    /// Устанавливает callback для обновления UI
    /// </summary>
    public void SetStateChangedCallback(Func<Task> callback)
    {
        if (callback == null)
            throw new ArgumentNullException(nameof(callback));

        if (IsDisposed)
            throw new ObjectDisposedException(nameof(NotificationService));

        _onStateChangedAsync = callback;
    }

    /// <summary>
    /// Очищает callback для предотвращения утечек памяти
    /// </summary>
    public void ClearCallback()
    {
        _onStateChangedAsync = null;
    }

    /// <summary>
    /// Показывает уведомление
    /// </summary>
    public async Task ShowNotificationAsync(
        NotificationType type,
        string title,
        string message,
        int durationMs = DefaultDurationMs,
        string? actionLink = null,
        string? actionText = null)
    {
        // Валидация параметров до входа в lock
        ValidateShowNotificationParameters(title, message, durationMs, actionLink, actionText);

        if (IsDisposed)
            throw new ObjectDisposedException(nameof(NotificationService));

        // Нормализация durationMs
        if (durationMs == 0)
        {
            durationMs = DefaultDurationMs;
        }

        await WaitForLockAsync();
        
        try
        {
            if (IsDisposed)
                throw new ObjectDisposedException(nameof(NotificationService));

            // Удаляем старые уведомления при превышении лимита (оптимизированная версия)
            RemoveOldestNotificationsIfNeeded();

            // Генерируем ID с защитой от переполнения
            var notificationId = GetNextNotificationId();
            
            var notification = new NotificationItem
            {
                Id = notificationId,
                Type = type,
                Title = title,
                Message = message,
                ActionLink = actionLink,
                ActionText = actionText,
                CreatedAt = DateTime.UtcNow
            };

            _notifications[notification.Id] = notification;
            _notificationsByTime[(notification.CreatedAt, notification.Id)] = notification.Id;
            InvalidateCache();

            // Запускаем таймер для автоматического удаления
            var notificationCts = new CancellationTokenSource();
            _notificationTimers[notification.Id] = notificationCts;

            // Используем более правильный подход для фоновых задач в Blazor
            _ = StartNotificationTimerAsync(notification.Id, durationMs, notificationCts.Token);
        }
        catch (OperationCanceledException)
        {
            // Сервис отменяется, это нормально
            throw new ObjectDisposedException(nameof(NotificationService));
        }
        finally
        {
            _operationLock.Release();
        }
        
        // ВАЖНО: Вызываем callback ПОСЛЕ освобождения lock!
        // Иначе MainLayout не сможет прочитать Notifications из-за занятого lock
        await InvokeCallbackAsync("ShowNotification");
    }

    /// <summary>
    /// Удаляет уведомление по ID
    /// </summary>
    public void RemoveNotification(int id)
    {
        if (IsDisposed)
            throw new ObjectDisposedException(nameof(NotificationService));

        // Для синхронного метода используем WaitAsync с коротким таймаутом
        if (!_operationLock.Wait(TimeSpan.FromMilliseconds(DisposeLockTimeoutMs)))
        {
            _logger.LogWarning("Failed to acquire lock for RemoveNotification. ID: {NotificationId}", id);
            return;
        }

        try
        {
            if (IsDisposed)
                return;

            RemoveNotificationInternal(id, animateExit: true);
        }
        finally
        {
            _operationLock.Release();
        }
    }

    /// <summary>
    /// Внутренний метод для удаления уведомления (вызывается только внутри lock)
    /// </summary>
    private void RemoveNotificationInternal(int id, bool animateExit)
    {
        if (!_notifications.TryGetValue(id, out var notification))
            return;

        try
        {
            if (animateExit)
            {
                notification.SetExiting();
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error calling SetExiting for notification ID {NotificationId}", id);
        }

        // Отменяем таймер уведомления
        if (_notificationTimers.TryGetValue(id, out var cts))
        {
            try
            {
                cts.Cancel();
                cts.Dispose();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error canceling timer for notification ID {NotificationId}", id);
            }
            _notificationTimers.Remove(id);
        }

        // Удаляем из коллекций
        _notifications.Remove(id);
        _notificationsByTime.Remove((notification.CreatedAt, notification.Id));
        InvalidateCache();

        // Асинхронно вызываем callback для обновления UI
        if (animateExit)
        {
            _ = InvokeCallbackWithDelayAsync("RemoveNotification");
        }
        else
        {
            _ = InvokeCallbackAsync("RemoveNotification");
        }
    }

    /// <summary>
    /// Запускает таймер для автоматического удаления уведомления
    /// </summary>
    private async Task StartNotificationTimerAsync(int notificationId, int durationMs, CancellationToken cancellationToken)
    {
        try
        {
            await Task.Delay(durationMs, cancellationToken).ConfigureAwait(false);

            await WaitForLockAsync();
            try
            {
                if (IsDisposed || cancellationToken.IsCancellationRequested)
                    return;

                if (_notifications.TryGetValue(notificationId, out var existing))
                {
                    try
                    {
                        existing.SetExiting();
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Error calling SetExiting in timer for notification ID {NotificationId}", notificationId);
                    }
                    await InvokeCallbackAsync("TimerSetExiting").ConfigureAwait(false);
                }

                await Task.Delay(ExitAnimationDurationMs, cancellationToken).ConfigureAwait(false);

                if (_notifications.TryGetValue(notificationId, out _))
                {
                    RemoveNotificationInternal(notificationId, animateExit: false);
                    await InvokeCallbackAsync("TimerRemove").ConfigureAwait(false);
                }
            }
            finally
            {
                _operationLock.Release();
            }
        }
        catch (TaskCanceledException)
        {
            // Сервис удаляется или уведомление отменено вручную
            await WaitForLockAsync();
            try
            {
                if (_notifications.ContainsKey(notificationId))
                {
                    RemoveNotificationInternal(notificationId, animateExit: false);
                }
            }
            finally
            {
                _operationLock.Release();
            }
        }
        catch (OperationCanceledException)
        {
            // То же самое
            await WaitForLockAsync();
            try
            {
                if (_notifications.ContainsKey(notificationId))
                {
                    RemoveNotificationInternal(notificationId, animateExit: false);
                }
            }
            finally
            {
                _operationLock.Release();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in notification timer for ID {NotificationId}", notificationId);
            
            await WaitForLockAsync();
            try
            {
                if (_notifications.ContainsKey(notificationId))
                {
                    RemoveNotificationInternal(notificationId, animateExit: false);
                }
            }
            finally
            {
                _operationLock.Release();
            }
        }
        finally
        {
            // Очищаем таймер из словаря
            await WaitForLockAsync();
            try
            {
                if (_notificationTimers.TryGetValue(notificationId, out var timerCts))
                {
                    try
                    {
                        timerCts.Dispose();
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Error disposing timer CTS for notification ID {NotificationId}", notificationId);
                    }
                    _notificationTimers.Remove(notificationId);
                }
            }
            finally
            {
                _operationLock.Release();
            }
        }
    }

    /// <summary>
    /// Безопасно вызывает callback для обновления UI
    /// </summary>
    private async Task InvokeCallbackAsync(string operation)
    {
        // Создаем snapshot callback для защиты от изменений во время выполнения
        var callback = _onStateChangedAsync;
        if (callback != null)
        {
            try
            {
                await callback.Invoke().ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                // Логируем ошибку callback с информацией об операции
                _logger.LogError(ex, "Error invoking notification callback during operation: {Operation}", operation);
            }
        }
    }

    /// <summary>
    /// Вызывает callback с задержкой для анимации выхода
    /// </summary>
    private async Task InvokeCallbackWithDelayAsync(string operation)
    {
        try
        {
            await InvokeCallbackAsync(operation).ConfigureAwait(false);
            await Task.Delay(ExitAnimationDurationMs, _cts.Token).ConfigureAwait(false);
        }
        catch (TaskCanceledException)
        {
            // Сервис удаляется, это нормально
        }
        catch (OperationCanceledException)
        {
            // То же самое
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error in InvokeCallbackWithDelayAsync during operation: {Operation}", operation);
        }
    }

    /// <summary>
    /// Инвалидирует кэш уведомлений
    /// </summary>
    private void InvalidateCache()
    {
        lock (_cacheLock)
        {
            _cachedNotifications = null;
            _lastNotificationCount = -1;
        }
    }

    /// <summary>
    /// Проверяет, не был ли сервис удален (потокобезопасно)
    /// </summary>
    private bool IsDisposed => Interlocked.Read(ref _disposed) != 0;

    /// <summary>
    /// Ожидает получения lock с обработкой отмены
    /// </summary>
    private async Task WaitForLockAsync()
    {
        try
        {
            await _operationLock.WaitAsync(_cts.Token).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            throw new ObjectDisposedException(nameof(NotificationService));
        }
    }

    /// <summary>
    /// Удаляет старейшие уведомления при превышении лимита (оптимизированная версия)
    /// </summary>
    private void RemoveOldestNotificationsIfNeeded()
    {
        while (_notifications.Count >= MaxNotifications && _notificationsByTime.Count > 0)
        {
            // Используем SortedDictionary для O(log n) поиска старейшего
            var oldestEntry = _notificationsByTime.First();
            var oldestId = oldestEntry.Value;
            
            if (_notifications.TryGetValue(oldestId, out var oldest))
            {
                RemoveNotificationInternal(oldestId, animateExit: false);
            }
            else
            {
                // Удаляем несуществующую запись из SortedDictionary
                _notificationsByTime.Remove(oldestEntry.Key);
            }
        }
    }

    /// <summary>
    /// Получает следующий ID уведомления с защитой от переполнения
    /// </summary>
    private int GetNextNotificationId()
    {
        var nextId = (int)Interlocked.Increment(ref _notificationIdCounter);
        
        // Защита от переполнения: если достигнут int.MaxValue, сбрасываем счетчик
        if (nextId == int.MinValue || nextId == 0)
        {
            _logger.LogWarning("Notification ID counter overflow detected, resetting counter");
            Interlocked.Exchange(ref _notificationIdCounter, 0);
            nextId = (int)Interlocked.Increment(ref _notificationIdCounter);
        }

        return nextId;
    }

    /// <summary>
    /// Валидирует параметры для ShowNotificationAsync
    /// </summary>
    private static void ValidateShowNotificationParameters(
        string title, 
        string message, 
        int durationMs, 
        string? actionLink, 
        string? actionText)
    {
        if (string.IsNullOrWhiteSpace(title))
            throw new ArgumentException("Title cannot be null or empty", nameof(title));

        if (title.Length > MaxTitleLength)
            throw new ArgumentException($"Title length cannot exceed {MaxTitleLength} characters", nameof(title));

        if (string.IsNullOrWhiteSpace(message))
            throw new ArgumentException("Message cannot be null or empty", nameof(message));

        if (message.Length > MaxMessageLength)
            throw new ArgumentException($"Message length cannot exceed {MaxMessageLength} characters", nameof(message));

        if (durationMs < 0)
            throw new ArgumentOutOfRangeException(nameof(durationMs), "Duration must be non-negative");

        if (actionLink != null && !string.IsNullOrWhiteSpace(actionLink))
        {
            if (!UrlPattern.IsMatch(actionLink))
            {
                throw new ArgumentException("ActionLink must be a valid HTTP or HTTPS URL", nameof(actionLink));
            }
        }

        if (actionText != null && actionText.Length > MaxActionTextLength)
        {
            throw new ArgumentException($"ActionText length cannot exceed {MaxActionTextLength} characters", nameof(actionText));
        }
    }

    /// <summary>
    /// Освобождает ресурсы
    /// </summary>
    public void Dispose()
    {
        // Используем Interlocked.Exchange для атомарной проверки и установки флага
        if (Interlocked.Exchange(ref _disposed, 1) != 0)
            return;

        bool lockAcquired = false;
        try
        {
            // Пытаемся получить блокировку с коротким таймаутом
            lockAcquired = _operationLock.Wait(TimeSpan.FromMilliseconds(DisposeLockTimeoutMs));

            // Отменяем все операции
            try
            {
                _cts.Cancel();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error canceling main cancellation token source during disposal");
            }

            _onStateChangedAsync = null;

            // Отменяем все таймеры уведомлений
            foreach (var (id, cts) in _notificationTimers.ToList())
            {
                try
                {
                    cts.Cancel();
                    cts.Dispose();
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Error disposing notification timer for ID {NotificationId}", id);
                }
            }

            // Очищаем коллекции
            _notificationTimers.Clear();
            _notifications.Clear();
            _notificationsByTime.Clear();
            InvalidateCache();

            // Освобождаем ресурсы
            try
            {
                _cts.Dispose();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error disposing main cancellation token source");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during NotificationService disposal");
        }
        finally
        {
            if (lockAcquired)
            {
                try
                {
                    _operationLock.Release();
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Error releasing operation lock during disposal");
                }
            }
            
            try
            {
                _operationLock.Dispose();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error disposing operation lock");
            }
        }
    }
}
