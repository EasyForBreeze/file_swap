using System.Diagnostics;
using System.Linq;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services.UsersManagement;

/// <summary>
/// Сервис для получения и обновления информации о пользователях через users-management API
/// </summary>
public class UsersInfoService : UsersManagementBaseService, IUsersInfoService
{
    // Константы для валидации
    private const int MaxUsernameLength = 255;
    private const int MaxNameLength = 255;
    private const int MaxEmailLength = 320; // RFC 5321
    private const int MaxErrorContentLength = 500;
    private const int OperationTimeoutSeconds = 30; // Timeout для отдельных операций (проблема #20)
    
    // Константы для HTTP статус-кодов
    private const int HttpStatusCodeConflict = 409;
    
    // Константы для имен JSON полей (проблема #13)
    private static class JsonPropertyNames
    {
        public const string Id = "id";
        public const string Username = "username";
        public const string FirstName = "firstName";
        public const string LastName = "lastName";
        public const string Email = "email";
        public const string EmailVerified = "emailVerified";
        public const string Enabled = "enabled";
        public const string FederationLink = "federationLink";
        public const string CreatedTimestamp = "createdTimestamp";
        public const string Attributes = "attributes";
        public const string RealmRoles = "realmRoles";
        public const string ClientRoles = "clientRoles";
        public const string Groups = "groups";
        public const string Credentials = "credentials";
        public const string BruteForceStatus = "bruteForceStatus";
        public const string RequiredActions = "requiredActions";
        public const string Name = "name";
        public const string Description = "description";
        public const string ClientId = "clientId";
        public const string Type = "type";
        public const string CreatedDate = "createdDate";
        public const string UserLabel = "userLabel";
        public const string NumFailures = "numFailures";
        public const string Disabled = "disabled";
        public const string LastIPFailure = "lastIPFailure";
        public const string LastFailure = "lastFailure";
    }
    
    // Регулярные выражения для валидации
    private static readonly Regex EmailRegex = new(
        @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
        RegexOptions.Compiled | RegexOptions.IgnoreCase,
        TimeSpan.FromMilliseconds(250));
    
    private static readonly Regex UsernameRegex = new(
        @"^[a-zA-Z0-9._-]+$",
        RegexOptions.Compiled,
        TimeSpan.FromMilliseconds(100));
    
    public UsersInfoService(
        HttpClient httpClient,
        Microsoft.Extensions.Options.IOptions<new_assistant.Configuration.KeycloakAdminSettings> settings,
        new_assistant.Core.Interfaces.IAuditService auditService,
        Microsoft.AspNetCore.Http.IHttpContextAccessor httpContextAccessor,
        new_assistant.Core.Interfaces.ITokenExchangeService tokenExchangeService,
        new_assistant.Core.Interfaces.IPerformanceMetricsService metricsService,
        ILogger<UsersInfoService> logger)
        : base(httpClient, settings, auditService, httpContextAccessor, tokenExchangeService, metricsService, logger)
    {
    }
    
    /// <summary>
    /// Получить детальную информацию о пользователе по его ID
    /// </summary>
    public async Task<UserDetailedInfoDto?> GetUserInfoAsync(
        string accessToken,
        string realm,
        string userId,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        ValidateCommonParameters(accessToken, realm, "GetUserInfo");
        if (string.IsNullOrWhiteSpace(userId))
            throw new ArgumentException("User ID cannot be null or empty", nameof(userId));
        if (userId.Length > MaxUserIdLength)
            throw new ArgumentException($"User ID cannot exceed {MaxUserIdLength} characters", nameof(userId));
        
        // Валидация realm и userId на инъекции (проблема #19, #21, #22)
        if (!IsValidRealm(realm))
            throw new ArgumentException("Realm contains invalid characters", nameof(realm));
        
        if (!IsValidUserId(userId))
            throw new ArgumentException("User ID contains invalid characters", nameof(userId));
        
        try
        {
            // Формируем endpoint для users-management API
            var endpoint = $"auth/realms/{realm}/users-management/{ApiVersionV2}/users/{userId}";
            
            var request = await CreateRequestAsync(HttpMethod.Get, endpoint, accessToken, realm, cancellationToken).ConfigureAwait(false);
            
            Logger.LogDebug("Получение информации о пользователе: Realm={Realm}, UserId={UserId}", realm, userId);
            
            // Использование timeout для отдельных операций (проблема #20)
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            cts.CancelAfter(TimeSpan.FromSeconds(OperationTimeoutSeconds));
            
            var stopwatch = Stopwatch.StartNew();
            using var response = await SendWithRetryAsync(request, cts.Token).ConfigureAwait(false);
            stopwatch.Stop();
            try
            {
                MetricsService.RecordOperationTime(MetricsOperationName, stopwatch.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                Logger.LogWarning(ex, "Ошибка при записи метрик производительности");
            }
            
            if (!response.IsSuccessStatusCode)
            {
                var truncatedError = await ReadAndTruncateErrorContentAsync(response, cancellationToken).ConfigureAwait(false);
                Logger.LogWarning(
                    "Ошибка получения информации о пользователе: StatusCode={StatusCode}, Error={Error}, Realm={Realm}, UserId={UserId}", 
                    response.StatusCode, 
                    truncatedError,
                    realm, 
                    userId);
                return null;
            }
            
            // Проблема #9: Улучшенная обработка ReadAsStringAsync
            string content;
            try
            {
                content = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Ошибка при чтении содержимого ответа для реалма {Realm}, UserId={UserId}", realm, userId);
                return null;
            }
            
            // Проверка на пустой ответ (проблема #3)
            if (string.IsNullOrWhiteSpace(content))
            {
                Logger.LogWarning("Получен пустой ответ при получении информации о пользователе: Realm={Realm}, UserId={UserId}", 
                    realm, userId);
                return null;
            }
            
            // Проблема #3: Улучшенная обработка исключений при десериализации
            JsonElement userJson;
            try
            {
                userJson = JsonSerializer.Deserialize<JsonElement>(content, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (JsonException ex)
            {
                Logger.LogError(ex, "Ошибка десериализации JSON при получении информации о пользователе: Realm={Realm}, UserId={UserId}, ContentLength={ContentLength}", 
                    realm, userId, content?.Length ?? 0);
                return null;
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Неожиданная ошибка при десериализации JSON при получении информации о пользователе: Realm={Realm}, UserId={UserId}, ContentLength={ContentLength}", 
                    realm, userId, content?.Length ?? 0);
                return null;
            }
            
            if (userJson.ValueKind != JsonValueKind.Object)
            {
                Logger.LogWarning("Неверный формат ответа при получении информации о пользователе");
                return null;
            }
            
            // Парсим основной объект с использованием безопасных методов (проблема #2) и констант (проблема #13)
            var userInfo = new UserDetailedInfoDto
            {
                Id = SafeGetString(userJson, JsonPropertyNames.Id),
                Username = SafeGetString(userJson, JsonPropertyNames.Username),
                FirstName = SafeGetStringOrNull(userJson, JsonPropertyNames.FirstName),
                LastName = SafeGetStringOrNull(userJson, JsonPropertyNames.LastName),
                Email = SafeGetStringOrNull(userJson, JsonPropertyNames.Email),
                EmailVerified = SafeGetBoolean(userJson, JsonPropertyNames.EmailVerified),
                Enabled = SafeGetBoolean(userJson, JsonPropertyNames.Enabled),
                FederationLink = SafeGetStringOrNull(userJson, JsonPropertyNames.FederationLink),
                CreatedTimestamp = SafeGetInt64(userJson, JsonPropertyNames.CreatedTimestamp)
            };
            
            // Парсим attributes
            if (userJson.TryGetProperty(JsonPropertyNames.Attributes, out var attributes) && attributes.ValueKind == JsonValueKind.Object)
            {
                userInfo.Attributes = new Dictionary<string, List<string>>();
                foreach (var attr in attributes.EnumerateObject())
                {
                    if (attr.Value.ValueKind == JsonValueKind.Array)
                    {
                        var values = new List<string>();
                        foreach (var val in attr.Value.EnumerateArray())
                        {
                            // Безопасное получение строки (проблема #18)
                            var strVal = val.ValueKind == JsonValueKind.String ? val.GetString() : null;
                            if (!string.IsNullOrEmpty(strVal))
                            {
                                values.Add(strVal);
                            }
                        }
                        userInfo.Attributes[attr.Name] = values;
                    }
                }
            }
            
            // Парсим realmRoles
            if (userJson.TryGetProperty(JsonPropertyNames.RealmRoles, out var realmRoles) && realmRoles.ValueKind == JsonValueKind.Array)
            {
                foreach (var role in realmRoles.EnumerateArray())
                {
                    userInfo.RealmRoles.Add(new UserRealmRoleDto
                    {
                        Id = SafeGetString(role, JsonPropertyNames.Id),
                        Name = SafeGetString(role, JsonPropertyNames.Name),
                        Description = SafeGetStringOrNull(role, JsonPropertyNames.Description)
                    });
                }
            }
            
            // Парсим clientRoles
            if (userJson.TryGetProperty(JsonPropertyNames.ClientRoles, out var clientRoles) && clientRoles.ValueKind == JsonValueKind.Array)
            {
                foreach (var role in clientRoles.EnumerateArray())
                {
                    userInfo.ClientRoles.Add(new UserClientRoleDto
                    {
                        ClientId = SafeGetString(role, JsonPropertyNames.ClientId),
                        Id = SafeGetString(role, JsonPropertyNames.Id),
                        Name = SafeGetString(role, JsonPropertyNames.Name),
                        Description = SafeGetStringOrNull(role, JsonPropertyNames.Description)
                    });
                }
            }
            
            // Парсим groups
            if (userJson.TryGetProperty(JsonPropertyNames.Groups, out var groups) && groups.ValueKind == JsonValueKind.Array)
            {
                foreach (var group in groups.EnumerateArray())
                {
                    userInfo.Groups.Add(new UserGroupDto
                    {
                        Id = SafeGetString(group, JsonPropertyNames.Id),
                        Name = SafeGetString(group, JsonPropertyNames.Name)
                    });
                }
            }
            
            // Парсим credentials
            if (userJson.TryGetProperty(JsonPropertyNames.Credentials, out var credentials) && credentials.ValueKind == JsonValueKind.Array)
            {
                foreach (var cred in credentials.EnumerateArray())
                {
                    userInfo.Credentials.Add(new UserCredentialDto
                    {
                        Id = SafeGetString(cred, JsonPropertyNames.Id),
                        Type = SafeGetString(cred, JsonPropertyNames.Type),
                        CreatedDate = SafeGetInt64(cred, JsonPropertyNames.CreatedDate),
                        UserLabel = SafeGetStringOrNull(cred, JsonPropertyNames.UserLabel)
                    });
                }
            }
            
            // Парсим bruteForceStatus с использованием безопасных методов (проблема #2) и констант (проблема #13)
            if (userJson.TryGetProperty(JsonPropertyNames.BruteForceStatus, out var bruteForceStatus) && bruteForceStatus.ValueKind == JsonValueKind.Object)
            {
                userInfo.BruteForceStatus = new BruteForceStatusDto
                {
                    NumFailures = SafeGetInt32(bruteForceStatus, JsonPropertyNames.NumFailures),
                    Disabled = SafeGetBoolean(bruteForceStatus, JsonPropertyNames.Disabled),
                    LastIPFailure = SafeGetStringOrNull(bruteForceStatus, JsonPropertyNames.LastIPFailure),
                    LastFailure = SafeGetInt64(bruteForceStatus, JsonPropertyNames.LastFailure)
                };
            }
            
            // Парсим requiredActions
            if (userJson.TryGetProperty(JsonPropertyNames.RequiredActions, out var requiredActions) && requiredActions.ValueKind == JsonValueKind.Array)
            {
                foreach (var action in requiredActions.EnumerateArray())
                {
                    // Безопасное получение строки (проблема #18)
                    var actionStr = action.ValueKind == JsonValueKind.String ? action.GetString() : null;
                    if (!string.IsNullOrEmpty(actionStr))
                    {
                        userInfo.RequiredActions.Add(actionStr);
                    }
                }
            }
            
            // Убедиться, что коллекции не null (проблема #17)
            userInfo.RealmRoles ??= new List<UserRealmRoleDto>();
            userInfo.ClientRoles ??= new List<UserClientRoleDto>();
            userInfo.Groups ??= new List<UserGroupDto>();
            userInfo.Credentials ??= new List<UserCredentialDto>();
            userInfo.RequiredActions ??= new List<string>();
            
            Logger.LogDebug("Информация о пользователе получена: Username={Username}", userInfo.Username);
            return userInfo;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при получении информации о пользователе в реалме {Realm}, UserId={UserId}", realm, userId);
            throw;
        }
    }
    
    /// <summary>
    /// Обновить информацию о пользователе (имя, фамилия, email)
    /// </summary>
    public async Task<bool> UpdateUserAsync(
        string accessToken,
        string realm,
        string userId,
        string? firstName,
        string? lastName,
        string? email,
        string? targetUsername = null,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        ValidateCommonParameters(accessToken, realm, "UpdateUser");
        if (string.IsNullOrWhiteSpace(userId))
            throw new ArgumentException("User ID cannot be null or empty", nameof(userId));
        if (userId.Length > MaxUserIdLength)
            throw new ArgumentException($"User ID cannot exceed {MaxUserIdLength} characters", nameof(userId));
        
        // Валидация realm и userId на инъекции (проблема #19, #21, #22)
        if (!IsValidRealm(realm))
            throw new ArgumentException("Realm contains invalid characters", nameof(realm));
        
        if (!IsValidUserId(userId))
            throw new ArgumentException("User ID contains invalid characters", nameof(userId));
        
        // Валидация email (проблема #1)
        if (!string.IsNullOrEmpty(email) && !IsValidEmail(email))
            throw new ArgumentException("Invalid email format", nameof(email));
        
        // Валидация длины полей (проблема #15)
        if (!string.IsNullOrEmpty(firstName) && firstName.Length > MaxNameLength)
            throw new ArgumentException($"First name cannot exceed {MaxNameLength} characters", nameof(firstName));
        
        if (!string.IsNullOrEmpty(lastName) && lastName.Length > MaxNameLength)
            throw new ArgumentException($"Last name cannot exceed {MaxNameLength} characters", nameof(lastName));
        
        if (!string.IsNullOrEmpty(email) && email.Length > MaxEmailLength)
            throw new ArgumentException($"Email cannot exceed {MaxEmailLength} characters", nameof(email));
        
        try
        {
            // Формируем endpoint для users-management API
            var endpoint = $"auth/realms/{realm}/users-management/{ApiVersionV1}/users/{userId}";
            
            // Формируем тело запроса и metadata одновременно (проблема #6)
            var updateData = new Dictionary<string, object>();
            var metadata = new Dictionary<string, string>();
            
            if (!string.IsNullOrEmpty(firstName))
            {
                updateData["firstName"] = firstName;
                metadata["firstName"] = firstName;
            }
            
            if (!string.IsNullOrEmpty(lastName))
            {
                updateData["lastName"] = lastName;
                metadata["lastName"] = lastName;
            }
            
            if (!string.IsNullOrEmpty(email))
            {
                updateData["email"] = email;
                metadata["email"] = email;
            }
            
            // Проверка на пустой словарь обновления (проблема #7)
            if (updateData.Count == 0)
            {
                Logger.LogWarning("Попытка обновить пользователя без указания полей для обновления: Realm={Realm}, UserId={UserId}", 
                    realm, userId);
                return false;
            }
            
            // Создаем JSON из словаря
            var jsonContent = JsonContent.Create(updateData);
            var updatedFields = updateData.Keys.OrderBy(k => k).ToArray();
            var fieldsForLog = updatedFields.Length > 0 ? string.Join(",", updatedFields) : "none";
            
            Logger.LogDebug("Отправка PUT запроса на обновление пользователя: Endpoint={Endpoint}, Fields={Fields}", endpoint, fieldsForLog);
            
            // Создаем запрос
            var request = await CreateRequestAsync(HttpMethod.Put, endpoint, accessToken, realm, cancellationToken).ConfigureAwait(false);
            request.Content = jsonContent;
            // Безопасное добавление заголовка Accept
            if (!request.Headers.Contains("Accept"))
            {
                request.Headers.TryAddWithoutValidation("Accept", "application/json");
            }
            
            // Использование timeout для отдельных операций (проблема #20)
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            cts.CancelAfter(TimeSpan.FromSeconds(OperationTimeoutSeconds));
            
            var stopwatch = Stopwatch.StartNew();
            using var response = await SendWithRetryAsync(request, cts.Token).ConfigureAwait(false);
            stopwatch.Stop();
            try
            {
                MetricsService.RecordOperationTime(MetricsOperationName, stopwatch.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                Logger.LogWarning(ex, "Ошибка при записи метрик производительности");
            }
            
            if (!response.IsSuccessStatusCode)
            {
                var truncatedError = await ReadAndTruncateErrorContentAsync(response, cancellationToken).ConfigureAwait(false);
                Logger.LogError("Ошибка обновления пользователя: StatusCode={StatusCode}, Error={Error}, Realm={Realm}, UserId={UserId}, Fields={Fields}", 
                    response.StatusCode, truncatedError, realm, userId, fieldsForLog);
                return false;
            }
            
            Logger.LogInformation("Пользователь успешно обновлен: Realm={Realm}, UserId={UserId}", realm, userId);

            var actingUser = GetActingUsername();
            var targetDisplay = FormatTargetDisplay(targetUsername, userId);

            var updatedFieldsDescription = metadata.Count > 0
                ? string.Join(", ", metadata.Keys.Select(k => $"{k}"))
                : "без изменений";

            var description = $"Пользователь {actingUser} обновил информацию пользователя {targetDisplay} ({updatedFieldsDescription}).";
            // Проблема #27: Использование LogAuditWithTimeoutAsync для обработки исключений
            try
            {
                await AuditService.LogUserManagementActionAsync(
                    actingUser,
                    "UserInfoUpdated",
                    userId,
                    targetUsername,
                    realm,
                    description,
                    metadata.Count > 0 ? metadata : null).ConfigureAwait(false);
            }
            catch (Exception auditEx)
            {
                Logger.LogWarning(auditEx, "Ошибка при логировании аудита для обновления пользователя: Realm={Realm}, UserId={UserId}", realm, userId);
            }
            return true;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при обновлении пользователя в реалме {Realm}, UserId={UserId}", realm, userId);
            return false;
        }
    }
    
    /// <summary>
    /// Создать нового пользователя в указанном реалме
    /// </summary>
    public async Task<bool> CreateUserAsync(
        string accessToken,
        string realm,
        string username,
        string firstName,
        string lastName,
        string email,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        ValidateCommonParameters(accessToken, realm, "CreateUser");
        
        // Валидация realm на инъекции (проблема #19, #21, #22)
        if (!IsValidRealm(realm))
            throw new ArgumentException("Realm contains invalid characters", nameof(realm));
        
        // Валидация username (проблема #5)
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        
        if (username.Length > MaxUsernameLength)
            throw new ArgumentException($"Username cannot exceed {MaxUsernameLength} characters", nameof(username));
        
        if (!UsernameRegex.IsMatch(username))
            throw new ArgumentException("Username contains invalid characters. Only letters, numbers, dots, underscores and hyphens are allowed", nameof(username));
        
        if (string.IsNullOrWhiteSpace(firstName))
            throw new ArgumentException("First name cannot be null or empty", nameof(firstName));
        
        if (string.IsNullOrWhiteSpace(lastName))
            throw new ArgumentException("Last name cannot be null or empty", nameof(lastName));
        
        // Валидация email (проблема #1)
        if (string.IsNullOrWhiteSpace(email))
            throw new ArgumentException("Email cannot be null or empty", nameof(email));
        
        if (!IsValidEmail(email))
            throw new ArgumentException("Invalid email format", nameof(email));
        
        // Валидация длины полей (проблема #15)
        if (firstName.Length > MaxNameLength)
            throw new ArgumentException($"First name cannot exceed {MaxNameLength} characters", nameof(firstName));
        
        if (lastName.Length > MaxNameLength)
            throw new ArgumentException($"Last name cannot exceed {MaxNameLength} characters", nameof(lastName));
        
        if (email.Length > MaxEmailLength)
            throw new ArgumentException($"Email cannot exceed {MaxEmailLength} characters", nameof(email));
        
        try
        {
            // Формируем endpoint для users-management API
            var endpoint = $"auth/realms/{realm}/users-management/{ApiVersionV1}/users";
            
            // Формируем тело запроса
            var createData = new Dictionary<string, object>
            {
                ["username"] = username,
                ["firstName"] = firstName,
                ["lastName"] = lastName,
                ["email"] = email
            };
            
            // Создаем JSON из словаря
            var jsonContent = JsonContent.Create(createData);
            
            Logger.LogDebug("Отправка POST запроса на создание пользователя: Endpoint={Endpoint}, Realm={Realm}, Username={Username}", endpoint, realm, username);
            
            // Создаем запрос
            var request = await CreateRequestAsync(HttpMethod.Post, endpoint, accessToken, realm, cancellationToken).ConfigureAwait(false);
            request.Content = jsonContent;
            // Безопасное добавление заголовка Accept
            if (!request.Headers.Contains("Accept"))
            {
                request.Headers.TryAddWithoutValidation("Accept", "application/json");
            }
            
            // Использование timeout для отдельных операций (проблема #20)
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            cts.CancelAfter(TimeSpan.FromSeconds(OperationTimeoutSeconds));
            
            var stopwatch = Stopwatch.StartNew();
            using var response = await SendWithRetryAsync(request, cts.Token).ConfigureAwait(false);
            stopwatch.Stop();
            try
            {
                MetricsService.RecordOperationTime(MetricsOperationName, stopwatch.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                Logger.LogWarning(ex, "Ошибка при записи метрик производительности");
            }
            
            if (!response.IsSuccessStatusCode)
            {
                var truncatedError = await ReadAndTruncateErrorContentAsync(response, cancellationToken).ConfigureAwait(false);
                
                // Обработка ошибки 409 Conflict - пользователь уже существует (проблема #10)
                if ((int)response.StatusCode == HttpStatusCodeConflict)
                {
                    Logger.LogWarning("Пользователь уже существует: Realm={Realm}, Username={Username}, Error={Error}", 
                        realm, username, truncatedError);
                    return false;
                }
                
                Logger.LogError("Ошибка создания пользователя: StatusCode={StatusCode}, Error={Error}, Realm={Realm}, Username={Username}", 
                    response.StatusCode, truncatedError, realm, username);
                return false;
            }
            
            Logger.LogInformation("Пользователь успешно создан: Realm={Realm}, Username={Username}", realm, username);
            
            // Попытка извлечь userId из Location header (если API его возвращает)
            var createdUserId = ExtractUserIdFromLocationHeader(response);
            
            // Добавление аудита при создании пользователя (проблема #11)
            var actingUser = GetActingUsername();
            var metadata = new Dictionary<string, string>
            {
                ["username"] = username,
                ["firstName"] = firstName ?? string.Empty,
                ["lastName"] = lastName ?? string.Empty,
                ["email"] = email ?? string.Empty
            };
            
            var description = $"Пользователь {actingUser} создал нового пользователя {username}.";
            // Проблема #27: Обработка исключений при логировании аудита
            try
            {
                await AuditService.LogUserManagementActionAsync(
                    actingUser,
                    "UserCreated",
                    createdUserId,
                    username,
                    realm,
                    description,
                    metadata).ConfigureAwait(false);
            }
            catch (Exception auditEx)
            {
                Logger.LogWarning(auditEx, "Ошибка при логировании аудита для создания пользователя: Realm={Realm}, Username={Username}", realm, username);
            }
            
            return true;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при создании пользователя в реалме {Realm}, Username={Username}", realm, username);
            return false;
        }
    }
    
    #region Вспомогательные методы валидации и парсинга
    
    /// <summary>
    /// Валидация формата email адреса
    /// </summary>
    private static bool IsValidEmail(string email)
    {
        if (string.IsNullOrWhiteSpace(email))
            return false;
        
        return EmailRegex.IsMatch(email);
    }
    
    /// <summary>
    /// Безопасное получение boolean значения из JsonElement
    /// </summary>
    private static bool SafeGetBoolean(JsonElement element, string propertyName, bool defaultValue = false)
    {
        if (!element.TryGetProperty(propertyName, out var property))
            return defaultValue;
        
        if (property.ValueKind == JsonValueKind.True)
            return true;
        if (property.ValueKind == JsonValueKind.False)
            return false;
        
        return defaultValue;
    }
    
    /// <summary>
    /// Безопасное получение boolean значения из JsonElement (перегрузка для прямого элемента)
    /// </summary>
    private static bool SafeGetBoolean(JsonElement element, bool defaultValue = false)
    {
        if (element.ValueKind == JsonValueKind.True)
            return true;
        if (element.ValueKind == JsonValueKind.False)
            return false;
        return defaultValue;
    }
    
    /// <summary>
    /// Безопасное получение int64 значения из JsonElement
    /// </summary>
    private static long SafeGetInt64(JsonElement element, string propertyName, long defaultValue = 0)
    {
        if (!element.TryGetProperty(propertyName, out var property))
            return defaultValue;
        
        // Проблема #7: Улучшенная обработка TryGetInt64
        try
        {
            if (property.ValueKind == JsonValueKind.Number && property.TryGetInt64(out var value))
                return value;
        }
        catch (Exception)
        {
            // Игнорируем ошибки парсинга, возвращаем значение по умолчанию
        }
        
        return defaultValue;
    }
    
    /// <summary>
    /// Безопасное получение int64 значения из JsonElement (перегрузка для прямого элемента)
    /// </summary>
    private static long SafeGetInt64(JsonElement element, long defaultValue = 0)
    {
        // Проблема #7: Улучшенная обработка TryGetInt64
        try
        {
            if (element.ValueKind == JsonValueKind.Number && element.TryGetInt64(out var value))
                return value;
        }
        catch (Exception)
        {
            // Игнорируем ошибки парсинга, возвращаем значение по умолчанию
        }
        return defaultValue;
    }
    
    /// <summary>
    /// Безопасное получение int32 значения из JsonElement
    /// </summary>
    private static int SafeGetInt32(JsonElement element, string propertyName, int defaultValue = 0)
    {
        if (!element.TryGetProperty(propertyName, out var property))
            return defaultValue;
        
        // Проблема #7: Улучшенная обработка TryGetInt32
        try
        {
            if (property.ValueKind == JsonValueKind.Number && property.TryGetInt32(out var value))
                return value;
        }
        catch (Exception)
        {
            // Игнорируем ошибки парсинга, возвращаем значение по умолчанию
        }
        
        return defaultValue;
    }
    
    /// <summary>
    /// Безопасное получение строки из JsonElement
    /// </summary>
    private static string SafeGetString(JsonElement element, string propertyName, string defaultValue = "")
    {
        if (!element.TryGetProperty(propertyName, out var property))
            return defaultValue;
        
        // Проблема #5: Улучшенная обработка GetString
        try
        {
            return property.ValueKind == JsonValueKind.String ? property.GetString() ?? defaultValue : defaultValue;
        }
        catch (Exception)
        {
            return defaultValue;
        }
    }
    
    /// <summary>
    /// Безопасное получение строки или null из JsonElement
    /// </summary>
    private static string? SafeGetStringOrNull(JsonElement element, string propertyName)
    {
        if (!element.TryGetProperty(propertyName, out var property))
            return null;
        
        // Проблема #5: Улучшенная обработка GetString
        try
        {
            return property.ValueKind == JsonValueKind.String ? property.GetString() : null;
        }
        catch (Exception)
        {
            return null;
        }
    }
    
    /// <summary>
    /// Обрезка строки для логирования
    /// </summary>
    private static string TruncateForLogging(string content, int maxLength = MaxErrorContentLength)
    {
        if (string.IsNullOrEmpty(content) || content.Length <= maxLength)
            return content ?? string.Empty;
        
        // Проблема #28: Использование Range оператора вместо Substring
        return content[..maxLength] + "...";
    }
    
    /// <summary>
    /// Читает и обрезает содержимое ошибки из HTTP ответа для безопасного логирования
    /// </summary>
    /// <param name="response">HTTP ответ с ошибкой</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Обрезанное содержимое ошибки, безопасное для логирования</returns>
    private static async Task<string> ReadAndTruncateErrorContentAsync(
        HttpResponseMessage response, 
        CancellationToken cancellationToken)
    {
        if (response?.Content == null)
            return "No error content available";
        
        try
        {
            var errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            return TruncateForLogging(errorContent);
        }
        catch (Exception)
        {
            // Если не удалось прочитать содержимое, возвращаем общее сообщение
            return "Failed to read error content";
        }
    }
    
    
    /// <summary>
    /// Извлекает userId из Location header HTTP ответа
    /// </summary>
    /// <param name="response">HTTP ответ с заголовком Location</param>
    /// <returns>userId, извлеченный из Location header, или пустая строка, если не удалось извлечь</returns>
    private static string ExtractUserIdFromLocationHeader(HttpResponseMessage response)
    {
        if (response?.Headers?.Location == null)
            return string.Empty;
        
        try
        {
            var locationUri = response.Headers.Location;
            var pathSegments = locationUri.Segments;
            
            // Обычно userId находится в последнем сегменте пути
            // Например: /auth/realms/{realm}/users/{userId}
            if (pathSegments.Length > 0)
            {
                var lastSegment = pathSegments[^1].TrimEnd('/');
                if (!string.IsNullOrWhiteSpace(lastSegment) && IsValidUserId(lastSegment))
                {
                    return lastSegment;
                }
            }
        }
        catch (Exception)
        {
            // Игнорируем ошибки при извлечении userId из Location header
            // Это не критично для работы приложения
        }
        
        return string.Empty;
    }
    
    #endregion
}
