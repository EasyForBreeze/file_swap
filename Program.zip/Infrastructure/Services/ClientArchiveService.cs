using System.Collections.Concurrent;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using ICSharpCode.SharpZipLib.Zip;
using new_assistant.Configuration;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для создания архивов с учетными данными клиентов
/// </summary>
public class ClientArchiveService : IClientArchiveService, IDisposable
{
    private readonly ILogger<ClientArchiveService> _logger;
    private readonly IPerformanceMetricsService? _metricsService;
    private readonly string _archivesDirectory;
    private readonly string _normalizedArchivesDirectory;
    private readonly string _tempDirectoryName;
    private bool _disposed = false;
    
    // Константы для валидации и ограничений
    private static readonly char[] InvalidFileNameChars = Path.GetInvalidFileNameChars();
    private const int DefaultPasswordLength = 16;
    private const int MinPasswordLength = 8;
    private const int MaxPasswordLength = 128;
    private const int CompressionLevel = 9;
    private const int BufferSize = 4096;
    private const long MaxFileSizeBytes = 10 * 1024 * 1024; // 10 MB
    private const int MaxClientIdLength = 255;
    private const int MaxClientSecretLength = 4096;
    private const int MaxConcurrentOperations = 10;
    private const string TempDirectoryBaseName = ".temp";
    
    // Константы для очистки и временных файлов
    private const int TempFileCleanupHours = 1;
    private const int CleanupBatchSize = 100;
    private const int OperationTimeoutMs = 30000;
    
    // Блокировки для предотвращения race conditions
    // Используем структуру с счетчиком ссылок для безопасного управления семафорами
    private class SemaphoreWrapper
    {
        public SemaphoreSlim Semaphore { get; }
        public int ReferenceCount;
        
        public SemaphoreWrapper()
        {
            Semaphore = new SemaphoreSlim(1, 1);
            ReferenceCount = 0;
        }
    }
    
    private static readonly ConcurrentDictionary<string, SemaphoreWrapper> _clientLocks = new();
    private static readonly SemaphoreSlim _globalOperationLimit = new SemaphoreSlim(MaxConcurrentOperations, MaxConcurrentOperations);
    private static readonly object _disposeLock = new object();

    public ClientArchiveService(DataPathsSettings dataPathsSettings, ILogger<ClientArchiveService> logger, IPerformanceMetricsService? metricsService = null)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _metricsService = metricsService;
        
        if (dataPathsSettings == null)
            throw new ArgumentNullException(nameof(dataPathsSettings));
        
        _archivesDirectory = dataPathsSettings.GetArchivesDirectoryPath();
        
        if (string.IsNullOrWhiteSpace(_archivesDirectory))
            throw new InvalidOperationException("Путь к директории архивов не может быть пустым");
        
        // Кэшируем нормализованный путь
        _normalizedArchivesDirectory = NormalizePath(_archivesDirectory);
        
        // Создаем уникальное имя временной директории с ProcessId и timestamp для избежания конфликтов
        _tempDirectoryName = $"{TempDirectoryBaseName}_{Environment.ProcessId}_{DateTime.UtcNow:yyyyMMddHHmmss}";
        
        // Дополнительная проверка, что директория существует или может быть создана
        try
        {
            if (!Directory.Exists(_archivesDirectory))
            {
                Directory.CreateDirectory(_archivesDirectory);
                _logger.LogInformation("Создана директория архивов: {ArchivesDirectory}", _archivesDirectory);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Не удалось создать директорию архивов: {ArchivesDirectory}", _archivesDirectory);
            throw;
        }
    }
    
    /// <summary>
    /// Валидирует строку на пустоту и null
    /// </summary>
    private static void ValidateNotEmpty(string value, string paramName, string fieldName)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new ArgumentException($"{fieldName} не может быть пустым", paramName);
    }
    
    /// <summary>
    /// Валидирует длину строки
    /// </summary>
    private static void ValidateLength(string value, string paramName, string fieldName, int maxLength)
    {
        if (value.Length > maxLength)
            throw new ArgumentException($"{fieldName} слишком длинный (максимум {maxLength} символов)", paramName);
    }
    
    /// <summary>
    /// Валидирует строку на наличие недопустимых символов для имени файла
    /// </summary>
    private static void ValidateFileNameChars(string value, string paramName, string fieldName)
    {
        if (value.IndexOfAny(InvalidFileNameChars) >= 0)
            throw new ArgumentException($"{fieldName} содержит недопустимые символы: {value}", paramName);
        
        // Защита от path traversal
        if (value.Contains("..") || value.Contains("/") || value.Contains("\\"))
            throw new ArgumentException($"{fieldName} содержит недопустимые символы: {value}", paramName);
    }
    
    /// <summary>
    /// Валидирует Client ID на безопасность и корректность
    /// </summary>
    private void ValidateClientId(string clientId)
    {
        ValidateNotEmpty(clientId, nameof(clientId), "Client ID");
        ValidateFileNameChars(clientId, nameof(clientId), "Client ID");
        ValidateLength(clientId, nameof(clientId), "Client ID", MaxClientIdLength);
    }
    
    /// <summary>
    /// Валидирует Client Secret на корректность
    /// </summary>
    private void ValidateClientSecret(string clientSecret)
    {
        ValidateNotEmpty(clientSecret, nameof(clientSecret), "Client Secret");
        ValidateLength(clientSecret, nameof(clientSecret), "Client Secret", MaxClientSecretLength);
    }
    
    /// <summary>
    /// Нормализует путь к файлу, преобразуя относительные пути в абсолютные и разрешая все символы пути
    /// </summary>
    /// <param name="path">Путь к файлу или директории для нормализации</param>
    /// <returns>Нормализованный абсолютный путь</returns>
    /// <exception cref="ArgumentException">Если путь пустой или содержит только пробелы, либо если путь невалиден</exception>
    /// <remarks>
    /// Метод использует Path.GetFullPath для нормализации пути, что включает:
    /// - Преобразование относительных путей в абсолютные
    /// - Разрешение символов '.' и '..'
    /// - Нормализацию разделителей пути
    /// - Проверку валидности пути
    /// </remarks>
    private string NormalizePath(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
            throw new ArgumentException("Путь не может быть пустым", nameof(path));
        
        try
        {
            var normalizedPath = Path.GetFullPath(path);
            _logger.LogTrace("Нормализован путь: {OriginalPath} -> {NormalizedPath}", path, normalizedPath);
            return normalizedPath;
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Недопустимый путь: {Path}", path);
            throw new ArgumentException($"Недопустимый путь: {path}", nameof(path), ex);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Неожиданная ошибка при нормализации пути: {Path}", path);
            throw new ArgumentException($"Ошибка при нормализации пути: {path}", nameof(path), ex);
        }
    }

    /// <summary>
    /// Генерирует случайный пароль для архива
    /// </summary>
    /// <param name="length">Длина пароля (по умолчанию 16)</param>
    /// <returns>Сгенерированный пароль</returns>
    /// <exception cref="ArgumentException">Если длина пароля вне допустимого диапазона</exception>
    /// <exception cref="CryptographicException">Если не удалось создать генератор случайных чисел</exception>
    /// <remarks>
    /// ВАЖНО: Пароли хранятся в обычных строках. Для критичных приложений рекомендуется
    /// использовать пароли сразу после генерации и не хранить их в памяти дольше необходимого.
    /// В .NET Core SecureString имеет ограниченную эффективность, поэтому используется обычная строка.
    /// </remarks>
    public string GeneratePassword(int length = DefaultPasswordLength)
    {
        // Валидация параметра
        if (length < MinPasswordLength)
            throw new ArgumentException($"Длина пароля должна быть не менее {MinPasswordLength} символов", nameof(length));
        
        if (length > MaxPasswordLength)
            throw new ArgumentException($"Длина пароля не должна превышать {MaxPasswordLength} символов", nameof(length));
        
        const string validChars = "ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz0123456789!@#$%^&*";
        var password = new char[length];
        var validCharsLength = (uint)validChars.Length;
        
        try
        {
            using (var rng = RandomNumberGenerator.Create())
            {
                for (int i = 0; i < length; i++)
                {
                    // Используем rejection sampling для равномерного распределения
                    uint randomValue;
                    do
                    {
                        byte[] randomBytes = new byte[4];
                        rng.GetBytes(randomBytes);
                        randomValue = BitConverter.ToUInt32(randomBytes, 0);
                    } while (randomValue >= uint.MaxValue - (uint.MaxValue % validCharsLength));
                    
                    password[i] = validChars[(int)(randomValue % validCharsLength)];
                }
            }
        }
        catch (Exception ex) when (ex is CryptographicException || ex is PlatformNotSupportedException)
        {
            _logger.LogError(ex, "Не удалось создать генератор случайных чисел для пароля");
            throw new CryptographicException("Не удалось сгенерировать пароль: ошибка при создании генератора случайных чисел", ex);
        }
        
        var result = new string(password);
        _logger.LogDebug("Сгенерирован пароль длиной {Length} символов", length);
        
        return result;
    }

    /// <summary>
    /// Создает текстовый файл с учетными данными клиента
    /// </summary>
    /// <param name="clientId">Client ID</param>
    /// <param name="clientSecret">Client Secret</param>
    /// <returns>Путь к созданному файлу</returns>
    /// <exception cref="ArgumentException">Если параметры невалидны</exception>
    public string CreateCredentialsFile(string clientId, string clientSecret)
    {
        ValidateClientId(clientId);
        ValidateClientSecret(clientSecret);
        
        var fileName = $"{clientId}_credentials.txt";
        var filePath = Path.Combine(_archivesDirectory, fileName);
        
        // Дополнительная проверка безопасности пути
        var normalizedFilePath = NormalizePath(filePath);
        
        // Используем правильное сравнение в зависимости от платформы
        var pathComparison = RuntimeInformation.IsOSPlatform(OSPlatform.Windows) 
            ? StringComparison.OrdinalIgnoreCase 
            : StringComparison.Ordinal;
        
        if (!normalizedFilePath.StartsWith(_normalizedArchivesDirectory, pathComparison))
            throw new UnauthorizedAccessException($"Доступ к файлу вне директории архивов запрещен: {filePath}");
        
        var content = $"Client ID: {clientId}\nClient Secret: {clientSecret}";
        
        // Используем UTF-8 с BOM для лучшей совместимости
        var utf8WithBom = new UTF8Encoding(encoderShouldEmitUTF8Identifier: true);
        File.WriteAllText(normalizedFilePath, content, utf8WithBom);
        _logger.LogDebug("Создан файл с учетными данными для клиента {ClientId}", clientId);
        
        return normalizedFilePath;
    }

    /// <summary>
    /// Создает защищенный паролем ZIP архив
    /// </summary>
    /// <param name="sourceFilePath">Путь к файлу для архивации</param>
    /// <param name="password">Пароль для архива (не может быть пустым)</param>
    /// <returns>Путь к созданному архиву</returns>
    /// <exception cref="ArgumentException">Если параметры невалидны</exception>
    /// <exception cref="FileNotFoundException">Если исходный файл не найден</exception>
    /// <exception cref="UnauthorizedAccessException">Если доступ к файлу запрещен</exception>
    /// <exception cref="IOException">Если произошла ошибка ввода-вывода</exception>
    public string CreatePasswordProtectedArchive(string sourceFilePath, string password)
    {
        if (string.IsNullOrWhiteSpace(sourceFilePath))
            throw new ArgumentException("Путь к исходному файлу не может быть пустым", nameof(sourceFilePath));
        
        if (string.IsNullOrWhiteSpace(password))
            throw new ArgumentException("Пароль не может быть пустым", nameof(password));
        
        if (!File.Exists(sourceFilePath))
            throw new FileNotFoundException($"Исходный файл не найден: {sourceFilePath}", sourceFilePath);
        
        // Проверка, что файл находится в допустимой директории
        var normalizedSourcePath = NormalizePath(sourceFilePath);
        
        // Используем правильное сравнение в зависимости от платформы
        var pathComparison = RuntimeInformation.IsOSPlatform(OSPlatform.Windows) 
            ? StringComparison.OrdinalIgnoreCase 
            : StringComparison.Ordinal;
        
        if (!normalizedSourcePath.StartsWith(_normalizedArchivesDirectory, pathComparison))
            throw new UnauthorizedAccessException($"Доступ к файлу вне директории архивов запрещен: {sourceFilePath}");
        
        var fileInfo = new FileInfo(normalizedSourcePath);
        
        // Проверка размера файла
        if (fileInfo.Length > MaxFileSizeBytes)
            throw new ArgumentException($"Размер файла ({fileInfo.Length} байт) превышает максимально допустимый ({MaxFileSizeBytes} байт)", nameof(sourceFilePath));
        
        if (fileInfo.Length == 0)
            throw new ArgumentException("Файл пуст", nameof(sourceFilePath));
        
        // Проверка доступного места на диске (минимум в 2 раза больше размера файла)
        // Пытаемся проверить на всех платформах, где это возможно
        try
        {
            var rootPath = Path.GetPathRoot(_normalizedArchivesDirectory);
            if (!string.IsNullOrEmpty(rootPath))
            {
                try
                {
                    var driveInfo = new DriveInfo(rootPath);
                    var requiredSpace = checked(fileInfo.Length * 2);
                    if (driveInfo.AvailableFreeSpace < requiredSpace)
                        throw new IOException($"Недостаточно места на диске для создания архива. Требуется: {requiredSpace} байт, доступно: {driveInfo.AvailableFreeSpace} байт");
                }
                catch (PlatformNotSupportedException)
                {
                    // На Unix системах DriveInfo может не работать, но мы попробуем
                    _logger.LogDebug("Проверка доступного места на диске не поддерживается на данной платформе, пропускаем");
                }
            }
            else
            {
                _logger.LogDebug("Не удалось определить корневой путь для проверки доступного места на диске");
            }
        }
        catch (IOException)
        {
            // Пробрасываем IOException о нехватке места дальше
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при проверке доступного места на диске, продолжаем без проверки");
            // Продолжаем без проверки для других ошибок
        }
        
        var sourceFileName = Path.GetFileNameWithoutExtension(normalizedSourcePath);
        var archiveFileName = $"{sourceFileName}.zip";
        var archivePath = Path.Combine(_archivesDirectory, archiveFileName);
        
        try
        {
            using (var fsOut = File.Create(archivePath))
            using (var zipStream = new ZipOutputStream(fsOut))
            {
                zipStream.SetLevel(CompressionLevel); // Максимальный уровень сжатия
                zipStream.Password = password; // Устанавливаем пароль
                
                var entry = new ZipEntry(Path.GetFileName(normalizedSourcePath))
                {
                    DateTime = fileInfo.LastWriteTimeUtc,
                    Size = fileInfo.Length
                };
                
                zipStream.PutNextEntry(entry);
                
                try
                {
                    using (var fsIn = File.OpenRead(normalizedSourcePath))
                    {
                        var buffer = new byte[BufferSize];
                        int bytesRead;
                        while ((bytesRead = fsIn.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            zipStream.Write(buffer, 0, bytesRead);
                        }
                    }
                }
                catch (IOException ex)
                {
                    // Проверяем код ошибки для нехватки места на диске или блокировки файла
                    var errorCode = ex.HResult & 0xFFFF;
                    if (errorCode == 0x27 || errorCode == 0x70) // ERROR_HANDLE_DISK_FULL или ERROR_DISK_FULL
                    {
                        _logger.LogError(ex, "Недостаточно места на диске для создания архива: {ArchivePath}", archivePath);
                        throw new IOException($"Недостаточно места на диске для создания архива: {archivePath}", ex);
                    }
                    // Файл может быть заблокирован другим процессом
                    _logger.LogError(ex, "Не удалось прочитать файл (возможно, файл заблокирован): {SourceFile}", normalizedSourcePath);
                    throw new IOException($"Не удалось прочитать файл (возможно, файл заблокирован другим процессом): {normalizedSourcePath}", ex);
                }
                catch (UnauthorizedAccessException ex)
                {
                    _logger.LogError(ex, "Нет доступа к файлу: {SourceFile}", normalizedSourcePath);
                    throw new UnauthorizedAccessException($"Нет доступа к файлу: {normalizedSourcePath}", ex);
                }
                
                zipStream.CloseEntry();
            }
            
            _logger.LogInformation("Создан защищенный архив: {ArchivePath}", archivePath);
            return archivePath;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при создании архива для файла {SourceFile}", sourceFilePath);
            throw;
        }
    }

    /// <summary>
    /// Удаляет временные файлы (оригинальный файл и архив)
    /// </summary>
    /// <param name="filePaths">Пути к файлам для удаления</param>
    /// <remarks>
    /// Метод безопасно удаляет указанные файлы, логируя все операции.
    /// Ошибки при удалении отдельных файлов не прерывают процесс удаления остальных.
    /// </remarks>
    public void CleanupFiles(IEnumerable<string> filePaths)
    {
        if (filePaths == null)
        {
            _logger.LogDebug("Нет файлов для удаления");
            return;
        }
        
        var filePathsList = filePaths.ToList();
        if (filePathsList.Count == 0)
        {
            _logger.LogDebug("Нет файлов для удаления");
            return;
        }
        
        var deletedCount = 0;
        var failedCount = 0;
        
        foreach (var filePath in filePathsList)
        {
            if (string.IsNullOrWhiteSpace(filePath))
                continue;
                
            try
            {
                if (File.Exists(filePath))
                {
                    var fileInfo = new FileInfo(filePath);
                    var fileSize = fileInfo.Length;
                    
                    File.Delete(filePath);
                    deletedCount++;
                    
                    _logger.LogInformation("Удален файл: {FilePath} (размер: {Size} байт)", filePath, fileSize);
                }
                else
                {
                    _logger.LogDebug("Файл не существует, пропуск: {FilePath}", filePath);
                }
            }
            catch (Exception ex)
            {
                failedCount++;
                _logger.LogWarning(ex, "Не удалось удалить файл: {FilePath}", filePath);
            }
        }
        
        if (deletedCount > 0 || failedCount > 0)
        {
            _logger.LogInformation("Очистка файлов завершена: удалено {DeletedCount}, ошибок {FailedCount}", 
                deletedCount, failedCount);
        }
    }

    /// <summary>
    /// Создает полный пакет: файл с учетными данными + защищенный архив
    /// Использует транзакционный подход: создает файлы во временной директории, затем атомарно перемещает в финальное место
    /// </summary>
    /// <param name="clientId">Client ID клиента</param>
    /// <param name="clientSecret">Client Secret клиента</param>
    /// <returns>Tuple с путем к архиву и паролем для доступа к архиву</returns>
    /// <exception cref="ArgumentException">Если параметры невалидны (пустые строки, недопустимые символы и т.д.)</exception>
    /// <exception cref="UnauthorizedAccessException">Если доступ к файлу или директории запрещен</exception>
    /// <exception cref="IOException">Если произошла ошибка ввода-вывода при создании файлов или архива</exception>
    /// <remarks>
    /// Метод проверяет существование архива перед созданием. Если архив уже существует, он будет перезаписан с предупреждением в логах.
    /// Все операции логируются для аудита безопасности.
    /// </remarks>
    public (string ArchivePath, string Password) CreateClientCredentialsPackage(string clientId, string clientSecret)
    {
        const string operationName = "CreateClientCredentialsPackage";
        var stopwatch = Stopwatch.StartNew();
        
        ValidateClientId(clientId);
        ValidateClientSecret(clientSecret);
        
        // Глобальное ограничение на количество одновременных операций
        if (!_globalOperationLimit.Wait(OperationTimeoutMs))
        {
            _metricsService?.RecordError(operationName, nameof(TimeoutException));
            throw new TimeoutException($"Не удалось получить глобальную блокировку в течение {OperationTimeoutMs}мс. Возможно, слишком много одновременных операций.");
        }
        
        try
        {
            // Получаем или создаем семафор для конкретного клиента (защита от race condition)
            var wrapper = _clientLocks.GetOrAdd(clientId, _ => new SemaphoreWrapper());
            
            // Атомарно увеличиваем счетчик ссылок
            Interlocked.Increment(ref wrapper.ReferenceCount);
            
            try
            {
                // Исправление: используем Wait с таймаутом вместо бесконечного ожидания
                if (!wrapper.Semaphore.Wait(OperationTimeoutMs))
                {
                    Interlocked.Decrement(ref wrapper.ReferenceCount);
                    throw new TimeoutException($"Не удалось получить блокировку для клиента {clientId} в течение {OperationTimeoutMs}мс.");
                }
            }
            catch
            {
                // Если не удалось получить блокировку, уменьшаем счетчик
                Interlocked.Decrement(ref wrapper.ReferenceCount);
                throw;
            }
            
            try
            {
                // Проверка на существование архива перед созданием
                var existingArchivePath = GetArchivePath(clientId);
                FileInfo? existingFileInfo = null;
                if (existingArchivePath != null)
                {
                    existingFileInfo = new FileInfo(existingArchivePath);
                    _logger.LogWarning("Архив для клиента {ClientId} уже существует (размер: {Size} байт, создан: {CreatedAt}). Будет перезаписан.", 
                        clientId, existingFileInfo.Length, existingFileInfo.CreationTimeUtc);
                }
                
                _logger.LogInformation("Начало создания пакета учетных данных для клиента {ClientId}", clientId);
                
                string? tempCredentialsPath = null;
                string? tempArchivePath = null;
                string? finalArchivePath = null;
                string? password = null;
                string? tempDir = null;
                
                try
                {
                    // Очищаем старые временные файлы перед началом работы
                    CleanupTempDirectory();
                    
                    // Создаем временную директорию для транзакционной работы
                    tempDir = Path.Combine(_archivesDirectory, _tempDirectoryName);
                    try
                    {
                        Directory.CreateDirectory(tempDir);
                        _logger.LogDebug("Создана временная директория: {TempDir}", tempDir);
                    }
                    catch (Exception ex) when (ex is UnauthorizedAccessException || ex is IOException || ex is DirectoryNotFoundException)
                    {
                        _logger.LogError(ex, "Не удалось создать временную директорию: {TempDir}", tempDir);
                        throw new IOException($"Не удалось создать временную директорию для работы: {tempDir}", ex);
                    }
            
            // 1. Генерируем пароль
            password = GeneratePassword();
            _logger.LogDebug("Сгенерирован пароль для архива клиента {ClientId}", clientId);
            
            // 2. Создаем файл с учетными данными во временной директории
            // Используем более уникальное имя с timestamp для избежания коллизий
            var timestamp = DateTime.UtcNow.Ticks;
            var uniqueId = $"{Guid.NewGuid():N}_{timestamp}";
            tempCredentialsPath = Path.Combine(tempDir, $"{uniqueId}_credentials.txt");
            
            // Проверяем, что файл не существует (на случай коллизии)
            int retryCount = 0;
            while (File.Exists(tempCredentialsPath) && retryCount < 10)
            {
                uniqueId = $"{Guid.NewGuid():N}_{DateTime.UtcNow.Ticks}";
                tempCredentialsPath = Path.Combine(tempDir, $"{uniqueId}_credentials.txt");
                retryCount++;
            }
            
            if (File.Exists(tempCredentialsPath))
                throw new IOException($"Не удалось создать уникальное имя для временного файла после {retryCount} попыток");
            
            var content = $"Client ID: {clientId}\nClient Secret: {clientSecret}";
            // Используем UTF-8 с BOM для лучшей совместимости
            var utf8WithBom = new UTF8Encoding(encoderShouldEmitUTF8Identifier: true);
            File.WriteAllText(tempCredentialsPath, content, utf8WithBom);
            _logger.LogDebug("Создан временный файл с учетными данными для клиента {ClientId}: {FilePath}", clientId, tempCredentialsPath);
            
            // 3. Создаем архив во временной директории
            uniqueId = $"{Guid.NewGuid():N}_{DateTime.UtcNow.Ticks}";
            tempArchivePath = Path.Combine(tempDir, $"{uniqueId}.zip");
            
            // Проверяем, что файл не существует
            retryCount = 0;
            while (File.Exists(tempArchivePath) && retryCount < 10)
            {
                uniqueId = $"{Guid.NewGuid():N}_{DateTime.UtcNow.Ticks}";
                tempArchivePath = Path.Combine(tempDir, $"{uniqueId}.zip");
                retryCount++;
            }
            
            if (File.Exists(tempArchivePath))
                throw new IOException($"Не удалось создать уникальное имя для временного архива после {retryCount} попыток");
            CreatePasswordProtectedArchiveInternal(tempCredentialsPath, tempArchivePath, password);
            _logger.LogDebug("Создан временный архив для клиента {ClientId}: {ArchivePath}", clientId, tempArchivePath);
            
                    // 4. Атомарно перемещаем архив в финальное место
                    finalArchivePath = Path.Combine(_archivesDirectory, $"{clientId}_credentials.zip");
                    
                    // Проверяем, что файлы на одном томе для атомарности операции
                    var tempDrive = Path.GetPathRoot(Path.GetFullPath(tempArchivePath));
                    var finalDrive = Path.GetPathRoot(Path.GetFullPath(finalArchivePath));
                    var canMoveAtomically = string.Equals(tempDrive, finalDrive, StringComparison.OrdinalIgnoreCase);
                    
                    if (canMoveAtomically)
                    {
                        // Удаляем существующий файл, если он есть (для совместимости с разными платформами)
                        if (File.Exists(finalArchivePath))
                        {
                            File.Delete(finalArchivePath);
                            _logger.LogDebug("Удален существующий архив перед перемещением: {FinalArchivePath}", finalArchivePath);
                        }
                        
                        File.Move(tempArchivePath, finalArchivePath);
                        tempArchivePath = null; // Помечаем как обработанный
                        _logger.LogInformation("Архив перемещен в финальное место: {FinalArchivePath}", finalArchivePath);
                    }
                    else
                    {
                        // Если файлы на разных томах, используем копирование с проверкой целостности
                        _logger.LogWarning("Файлы на разных томах, используем копирование вместо перемещения");
                        
                        // Удаляем существующий файл, если он есть
                        if (File.Exists(finalArchivePath))
                        {
                            File.Delete(finalArchivePath);
                            _logger.LogDebug("Удален существующий архив перед копированием: {FinalArchivePath}", finalArchivePath);
                        }
                        
                        // Копируем файл
                        File.Copy(tempArchivePath, finalArchivePath, overwrite: true);
                        
                        // Проверяем целостность: сравниваем размеры
                        var tempFileInfo = new FileInfo(tempArchivePath);
                        var copiedFileInfo = new FileInfo(finalArchivePath);
                        if (tempFileInfo.Length != copiedFileInfo.Length)
                        {
                            File.Delete(finalArchivePath);
                            throw new IOException($"Ошибка при копировании архива: размеры не совпадают (временный: {tempFileInfo.Length}, финальный: {copiedFileInfo.Length})");
                        }
                        
                        // Удаляем временный файл только после успешной проверки
                        File.Delete(tempArchivePath);
                        tempArchivePath = null; // Помечаем как обработанный
                        _logger.LogInformation("Архив скопирован в финальное место: {FinalArchivePath}", finalArchivePath);
                    }
            
            // 5. Удаляем временный текстовый файл
            CleanupFiles(new[] { tempCredentialsPath });
            tempCredentialsPath = null;
            
                    var finalFileInfo = new FileInfo(finalArchivePath);
                    stopwatch.Stop();
                    var elapsedMs = stopwatch.ElapsedMilliseconds;
                    
                    _logger.LogInformation("Пакет учетных данных для клиента {ClientId} успешно создан. Архив: {ArchivePath} (размер: {Size} байт, время: {ElapsedMs} мс)", 
                        clientId, finalArchivePath, finalFileInfo.Length, elapsedMs);
                    
                    // Записываем метрики
                    _metricsService?.RecordSuccess(operationName);
                    _metricsService?.RecordOperationTime(operationName, elapsedMs);
                    
                    return (finalArchivePath, password);
                }
                catch (Exception ex)
                {
                    stopwatch.Stop();
                    var elapsedMs = stopwatch.ElapsedMilliseconds;
                    
                    _logger.LogError(ex, "Ошибка при создании пакета учетных данных для клиента {ClientId}", clientId);
                    
                    // Записываем метрики ошибки
                    _metricsService?.RecordError(operationName, ex.GetType().Name);
                    _metricsService?.RecordOperationTime(operationName, elapsedMs);
                    
                    throw;
                }
                finally
                {
                    // Гарантированная очистка всех временных файлов в finally блоке
                    if (tempCredentialsPath != null)
                    {
                        try
                        {
                            CleanupFiles(new[] { tempCredentialsPath });
                        }
                        catch (Exception cleanupEx)
                        {
                            _logger.LogWarning(cleanupEx, "Не удалось очистить временный файл: {FilePath}", tempCredentialsPath);
                        }
                    }
                    
                    if (tempArchivePath != null)
                    {
                        try
                        {
                            CleanupFiles(new[] { tempArchivePath });
                        }
                        catch (Exception cleanupEx)
                        {
                            _logger.LogWarning(cleanupEx, "Не удалось очистить временный архив: {FilePath}", tempArchivePath);
                        }
                    }
                    
                    // Если финальный архив был создан, но произошла ошибка, удаляем его
                    if (finalArchivePath != null && File.Exists(finalArchivePath))
                    {
                        // Проверяем, что операция не завершилась успешно
                        // (если успешно, finalArchivePath должен быть возвращен)
                        try
                        {
                            // Проверяем, что файл существует и не является финальным результатом
                            // Это делается только в случае ошибки
                            var fileInfo = new FileInfo(finalArchivePath);
                            if (fileInfo.Length == 0)
                            {
                                // Пустой файл - удаляем
                                CleanupFiles(new[] { finalArchivePath });
                            }
                        }
                        catch (Exception cleanupEx)
                        {
                            _logger.LogWarning(cleanupEx, "Не удалось проверить финальный архив: {FilePath}", finalArchivePath);
                        }
                    }
                }
            }
            finally
            {
                wrapper.Semaphore.Release();
                
                // Атомарно уменьшаем счетчик ссылок
                var newCount = Interlocked.Decrement(ref wrapper.ReferenceCount);
                
                // Безопасно удаляем семафор, если больше нет ссылок
                if (newCount == 0)
                {
                    // Используем TryRemove для атомарности
                    if (_clientLocks.TryRemove(clientId, out var removedWrapper))
                    {
                        // Проверяем, что это тот же wrapper (защита от race condition)
                        if (removedWrapper == wrapper && Interlocked.CompareExchange(ref wrapper.ReferenceCount, -1, 0) == 0)
                        {
                            try
                            {
                                wrapper.Semaphore.Dispose();
                            }
                            catch (Exception ex)
                            {
                                _logger.LogWarning(ex, "Ошибка при освобождении семафора для клиента {ClientId}", clientId);
                            }
                        }
                        else
                        {
                            // Кто-то другой уже добавил новый wrapper, возвращаем старый обратно
                            _clientLocks.TryAdd(clientId, wrapper);
                            Interlocked.Increment(ref wrapper.ReferenceCount);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            var elapsedMs = stopwatch.ElapsedMilliseconds;
            
            // Записываем метрики для ошибок
            _metricsService?.RecordError(operationName, ex.GetType().Name);
            _metricsService?.RecordOperationTime(operationName, elapsedMs);
            
            throw;
        }
        finally
        {
            _globalOperationLimit.Release();
        }
    }
    
    /// <summary>
    /// Очищает старые временные файлы из временной директории
    /// </summary>
    private void CleanupTempDirectory()
    {
        var tempDir = Path.Combine(_archivesDirectory, _tempDirectoryName);
        if (!Directory.Exists(tempDir))
            return;
        
        try
        {
            var cutoffTime = DateTime.UtcNow.AddHours(-TempFileCleanupHours);
            var deletedCount = 0;
            
            // Используем EnumerateFiles напрямую без материализации для экономии памяти
            foreach (var file in Directory.EnumerateFiles(tempDir))
            {
                try
                {
                    var fileInfo = new FileInfo(file);
                    
                    // Проверяем время последнего доступа вместо времени создания для более безопасной очистки
                    var lastAccessTime = fileInfo.LastAccessTimeUtc;
                    var creationTime = fileInfo.CreationTimeUtc;
                    var oldestTime = lastAccessTime < creationTime ? lastAccessTime : creationTime;
                    
                    // Удаляем только файлы, которые не использовались более указанного времени
                    if (oldestTime < cutoffTime)
                    {
                        // Дополнительная проверка: пытаемся открыть файл для чтения, чтобы убедиться, что он не используется
                        try
                        {
                            using (var stream = File.Open(file, FileMode.Open, FileAccess.Read, FileShare.Delete))
                            {
                                // Файл доступен для чтения, можно безопасно удалить
                            }
                            
                            File.Delete(file);
                            deletedCount++;
                        }
                        catch (IOException)
                        {
                            // Файл используется другим процессом, пропускаем
                            _logger.LogDebug("Временный файл используется другим процессом, пропускаем: {FilePath}", file);
                        }
                        catch (UnauthorizedAccessException)
                        {
                            // Нет доступа к файлу, пропускаем
                            _logger.LogDebug("Нет доступа к временному файлу, пропускаем: {FilePath}", file);
                        }
                    }
                }
                catch (FileNotFoundException)
                {
                    // Файл уже удален, пропускаем
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Не удалось удалить временный файл: {FilePath}", file);
                }
            }
            
            if (deletedCount > 0)
            {
                _logger.LogInformation("Очищено {Count} старых временных файлов из директории {TempDir}", deletedCount, _tempDirectoryName);
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при очистке временной директории: {TempDir}", tempDir);
        }
    }
    
    /// <summary>
    /// Внутренний метод для создания защищенного архива без дополнительной валидации путей
    /// (используется для работы с временными файлами в транзакционных операциях)
    /// </summary>
    /// <param name="sourceFilePath">Путь к исходному файлу для архивации</param>
    /// <param name="archivePath">Путь к создаваемому архиву</param>
    /// <param name="password">Пароль для защиты архива</param>
    /// <exception cref="ArgumentException">Если параметры невалидны или файл пуст/слишком большой</exception>
    /// <exception cref="FileNotFoundException">Если исходный файл не найден</exception>
    /// <exception cref="IOException">Если произошла ошибка ввода-вывода при создании архива</exception>
    private void CreatePasswordProtectedArchiveInternal(string sourceFilePath, string archivePath, string password)
    {
        if (string.IsNullOrWhiteSpace(password))
            throw new ArgumentException("Пароль не может быть пустым", nameof(password));
        
        // Валидация длины пароля
        if (password.Length < MinPasswordLength)
            throw new ArgumentException($"Пароль слишком короткий (минимум {MinPasswordLength} символов)", nameof(password));
        
        if (password.Length > MaxPasswordLength)
            throw new ArgumentException($"Пароль слишком длинный (максимум {MaxPasswordLength} символов)", nameof(password));
        
        if (!File.Exists(sourceFilePath))
            throw new FileNotFoundException($"Исходный файл не найден: {sourceFilePath}", sourceFilePath);
        
        var fileInfo = new FileInfo(sourceFilePath);
        
        // Проверка размера файла
        if (fileInfo.Length > MaxFileSizeBytes)
            throw new ArgumentException($"Размер файла ({fileInfo.Length} байт) превышает максимально допустимый ({MaxFileSizeBytes} байт)", nameof(sourceFilePath));
        
        if (fileInfo.Length == 0)
            throw new ArgumentException("Файл пуст", nameof(sourceFilePath));
        
        try
        {
            using (var fsOut = File.Create(archivePath))
            using (var zipStream = new ZipOutputStream(fsOut))
            {
                zipStream.SetLevel(CompressionLevel);
                zipStream.Password = password;
                
                var entry = new ZipEntry(Path.GetFileName(sourceFilePath))
                {
                    DateTime = fileInfo.LastWriteTimeUtc,
                    Size = fileInfo.Length
                };
                
                zipStream.PutNextEntry(entry);
                
                try
                {
                    using (var fsIn = File.OpenRead(sourceFilePath))
                    {
                        var buffer = new byte[BufferSize];
                        int bytesRead;
                        while ((bytesRead = fsIn.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            zipStream.Write(buffer, 0, bytesRead);
                        }
                    }
                }
                catch (IOException ex)
                {
                    // Проверяем код ошибки для нехватки места на диске
                    var errorCode = ex.HResult & 0xFFFF;
                    if (errorCode == 0x27 || errorCode == 0x70) // ERROR_HANDLE_DISK_FULL или ERROR_DISK_FULL
                    {
                        _logger.LogError(ex, "Недостаточно места на диске для создания архива: {ArchivePath}", archivePath);
                        throw new IOException($"Недостаточно места на диске для создания архива: {archivePath}", ex);
                    }
                    throw;
                }
                
                zipStream.CloseEntry();
            }
            
            // Проверка целостности архива: пытаемся открыть его
            try
            {
                using (var zipFile = new ZipFile(archivePath))
                {
                    zipFile.Password = password;
                    if (zipFile.Count == 0)
                    {
                        throw new IOException($"Архив создан, но пуст: {archivePath}");
                    }
                    
                    // Проверяем первый entry
                    var firstEntry = zipFile[0];
                    if (firstEntry == null)
                    {
                        throw new IOException($"Архив создан, но не содержит записей: {archivePath}");
                    }
                }
                
                _logger.LogDebug("Создан временный защищенный архив с проверкой целостности: {ArchivePath}", archivePath);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при проверке целостности архива: {ArchivePath}", archivePath);
                // Удаляем поврежденный архив
                try
                {
                    File.Delete(archivePath);
                }
                catch
                {
                    // Игнорируем ошибки удаления
                }
                throw new IOException($"Архив создан, но поврежден: {archivePath}", ex);
            }
        }
        catch (IOException)
        {
            // Пробрасываем IOException дальше (включая нехватку места)
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при создании архива для файла {SourceFile}", sourceFilePath);
            throw;
        }
    }

    /// <summary>
    /// Получает путь к архиву по Client ID
    /// </summary>
    /// <param name="clientId">Client ID</param>
    /// <returns>Путь к архиву или null если не найден</returns>
    /// <exception cref="ArgumentException">Если Client ID невалиден</exception>
    /// <exception cref="UnauthorizedAccessException">Если доступ к файлу запрещен</exception>
    public string? GetArchivePath(string clientId)
    {
        ValidateClientId(clientId);
        
        var archiveFileName = $"{clientId}_credentials.zip";
        var archivePath = Path.Combine(_archivesDirectory, archiveFileName);
        
        // Дополнительная проверка безопасности пути
        var normalizedArchivePath = NormalizePath(archivePath);
        
        // Используем правильное сравнение в зависимости от платформы
        var pathComparison = RuntimeInformation.IsOSPlatform(OSPlatform.Windows) 
            ? StringComparison.OrdinalIgnoreCase 
            : StringComparison.Ordinal;
        
        if (!normalizedArchivePath.StartsWith(_normalizedArchivesDirectory, pathComparison))
            throw new UnauthorizedAccessException($"Доступ к файлу вне директории архивов запрещен: {archivePath}");
        
        var exists = File.Exists(normalizedArchivePath);
        
        if (exists)
        {
            var fileInfo = new FileInfo(normalizedArchivePath);
            _logger.LogInformation("Найден архив для клиента {ClientId}: {ArchivePath} (размер: {Size} байт, создан: {CreatedAt})", 
                clientId, normalizedArchivePath, fileInfo.Length, fileInfo.CreationTimeUtc);
        }
        else
        {
            _logger.LogDebug("Архив для клиента {ClientId} не найден", clientId);
        }
        
        return exists ? normalizedArchivePath : null;
    }

    /// <summary>
    /// Очищает старые архивы, удаляя файлы старше указанного количества дней
    /// </summary>
    /// <param name="retentionDays">Количество дней хранения архивов (по умолчанию 1 день)</param>
    /// <returns>Tuple с количеством удаленных файлов и общим размером удаленных файлов в байтах</returns>
    /// <exception cref="ArgumentException">Если количество дней вне допустимого диапазона (0-365)</exception>
    /// <remarks>
    /// Метод удаляет все архивы, созданные раньше чем (текущая дата - retentionDays).
    /// Все операции логируются для аудита. Ошибки при удалении отдельных файлов не прерывают процесс.
    /// </remarks>
    public (int DeletedCount, long TotalSizeBytes) CleanupOldArchives(int retentionDays = 1)
    {
        if (retentionDays < 0)
            throw new ArgumentException("Количество дней хранения не может быть отрицательным", nameof(retentionDays));
        
        if (retentionDays > 365)
            throw new ArgumentException("Количество дней хранения не должно превышать 365", nameof(retentionDays));
        
        var cutoffDate = DateTime.UtcNow.AddDays(-retentionDays);
        _logger.LogInformation("Начало очистки архивов старше {CutoffDate} (retention: {RetentionDays} дней)", 
            cutoffDate.ToString("yyyy-MM-dd HH:mm:ss"), retentionDays);
        
        var deletedCount = 0;
        var totalSize = 0L;

        if (!Directory.Exists(_archivesDirectory))
        {
            _logger.LogDebug("Папка архивов не существует: {ArchivesDirectory}", _archivesDirectory);
            return (0, 0);
        }

        var archiveFiles = Directory.EnumerateFiles(_archivesDirectory, "*.zip", SearchOption.TopDirectoryOnly);
        _logger.LogDebug("Начало обработки архивных файлов для очистки");

        var processedCount = 0;
        foreach (var filePath in archiveFiles)
        {
            try
            {
                var fileInfo = new FileInfo(filePath);
                
                // Проверяем возраст файла
                if (fileInfo.CreationTimeUtc < cutoffDate)
                {
                    var fileSize = fileInfo.Length;
                    
                    // Проверка на отрицательный размер
                    if (fileSize < 0)
                    {
                        _logger.LogWarning("Обнаружен файл с отрицательным размером: {FilePath}", filePath);
                        continue; // Пропускаем такой файл
                    }
                    
                    // Проверка на переполнение с использованием checked блока
                    try
                    {
                        checked
                        {
                            totalSize += fileSize;
                        }
                    }
                    catch (OverflowException)
                    {
                        _logger.LogWarning("Превышен максимальный размер для подсчета. Остановка подсчета размера.");
                        totalSize = long.MaxValue;
                        break; // Прекращаем подсчет
                    }
                    
                    try
                    {
                        File.Delete(filePath);
                        deletedCount++;
                        
                        _logger.LogInformation("Удален старый архив: {FileName} (создан: {CreatedAt}, размер: {Size} байт)", 
                            fileInfo.Name, fileInfo.CreationTimeUtc, fileSize);
                    }
                    catch (FileNotFoundException)
                    {
                        // Файл уже удален другим процессом, пропускаем
                        _logger.LogDebug("Файл уже удален другим процессом: {FilePath}", filePath);
                    }
                    
                    // Батчинг: ограничиваем количество обрабатываемых файлов за раз
                    processedCount++;
                    if (processedCount >= CleanupBatchSize)
                    {
                        _logger.LogDebug("Обработано {ProcessedCount} файлов, делаем паузу для других операций", processedCount);
                        Thread.Sleep(10); // Небольшая пауза для других операций
                        processedCount = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Не удалось удалить архив: {FilePath}", filePath);
            }
        }

        if (deletedCount > 0)
        {
            _logger.LogInformation("Очистка архивов завершена: удалено {DeletedCount} файлов, освобождено {TotalSize} байт", 
                deletedCount, totalSize);
        }
        else
        {
            _logger.LogDebug("Очистка архивов: файлов для удаления не найдено");
        }

        return (deletedCount, totalSize);
    }

    /// <summary>
    /// Получает статистику по архивам
    /// </summary>
    /// <returns>Tuple с количеством файлов, общим размером в байтах и датой создания самого старого файла</returns>
    /// <remarks>
    /// Метод сканирует директорию архивов и собирает статистику. 
    /// Если директория не существует, возвращает нулевые значения.
    /// Ошибки при обработке отдельных файлов логируются, но не прерывают процесс.
    /// </remarks>
    public (int FileCount, long TotalSizeBytes, DateTime? OldestFileDate) GetArchiveStats()
    {
        _logger.LogDebug("Начало сбора статистики по архивам в директории: {ArchivesDirectory}", _archivesDirectory);
        
        if (!Directory.Exists(_archivesDirectory))
        {
            _logger.LogDebug("Директория архивов не существует: {ArchivesDirectory}", _archivesDirectory);
            return (0, 0, null);
        }

        var archiveFiles = Directory.EnumerateFiles(_archivesDirectory, "*.zip", SearchOption.TopDirectoryOnly);
        
        var totalSize = 0L;
        DateTime? oldestDate = null;
        var fileCount = 0;
        var errorCount = 0;

        foreach (var filePath in archiveFiles)
        {
            try
            {
                var fileInfo = new FileInfo(filePath);
                
                // Проверка на отрицательный размер
                if (fileInfo.Length < 0)
                {
                    _logger.LogWarning("Обнаружен файл с отрицательным размером: {FilePath}", filePath);
                    continue; // Пропускаем такой файл
                }
                
                // Проверка на переполнение с использованием checked блока
                try
                {
                    checked
                    {
                        totalSize += fileInfo.Length;
                    }
                }
                catch (OverflowException)
                {
                    _logger.LogWarning("Превышен максимальный размер при подсчете статистики архивов");
                    totalSize = long.MaxValue;
                    break; // Прекращаем подсчет
                }
                
                if (oldestDate == null || fileInfo.CreationTimeUtc < oldestDate)
                {
                    oldestDate = fileInfo.CreationTimeUtc;
                }
                
                fileCount++;
            }
            catch (Exception ex)
            {
                errorCount++;
                _logger.LogWarning(ex, "Ошибка при получении информации о файле: {FilePath}", filePath);
            }
        }

        _logger.LogInformation("Статистика архивов собрана: файлов {FileCount}, общий размер {TotalSize} байт, самый старый архив от {OldestDate}, ошибок {ErrorCount}", 
            fileCount, totalSize, oldestDate?.ToString("yyyy-MM-dd HH:mm:ss") ?? "N/A", errorCount);

        return (fileCount, totalSize, oldestDate);
    }
    
    /// <summary>
    /// Освобождает ресурсы, используемые сервисом
    /// </summary>
    public void Dispose()
    {
        if (_disposed) return;
        
        // Используем блокировку для безопасного освобождения семафоров
        lock (_disposeLock)
        {
            if (_disposed) return;
            
            try
            {
                // Очищаем семафоры для клиентов с безопасной блокировкой
                var keys = _clientLocks.Keys.ToList(); // Создаем копию списка ключей
                foreach (var clientId in keys)
                {
                    if (_clientLocks.TryRemove(clientId, out var wrapper))
                    {
                        try
                        {
                            // Устанавливаем счетчик в -1, чтобы предотвратить дальнейшее использование
                            Interlocked.Exchange(ref wrapper.ReferenceCount, -1);
                            wrapper.Semaphore.Dispose();
                        }
                        catch (Exception ex)
                        {
                            _logger.LogWarning(ex, "Ошибка при освобождении семафора для клиента {ClientId}", clientId);
                        }
                    }
                }
                
                // Очищаем временную директорию
                CleanupTempDirectory();
                
                _logger.LogDebug("ClientArchiveService успешно освобожден");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при освобождении ресурсов ClientArchiveService");
            }
            finally
            {
                _disposed = true;
            }
        }
    }
}

