using new_assistant.Core.Constants;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Реализация форматирования сообщений для аудит-логов
/// </summary>
public class AuditMessageFormatterService : IAuditMessageFormatter
{
    public string ClientCreated(string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        return $"Создан клиент {clientId} в реалме {realm}";
    }

    public string ClientDeleted(string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        return $"Удален клиент {clientId} из реалма {realm}";
    }

    public string ClientUpdated(string changedFields)
    {
        if (string.IsNullOrWhiteSpace(changedFields))
            throw new ArgumentException("Changed fields cannot be null or empty", nameof(changedFields));
        
        return $"Изменены поля: {changedFields}";
    }

    public string AccessGranted(string targetUsername, string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(targetUsername))
            throw new ArgumentException("Target username cannot be null or empty", nameof(targetUsername));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        return $"Пользователю {targetUsername} предоставлен доступ к клиенту {clientId} в реалме {realm}";
    }

    public string AccessRevoked(string targetUsername, string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(targetUsername))
            throw new ArgumentException("Target username cannot be null or empty", nameof(targetUsername));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        return $"У пользователя {targetUsername} отозван доступ к клиенту {clientId} в реалме {realm}";
    }

    public string RoleAdded(string roleName, string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(roleName))
            throw new ArgumentException("Role name cannot be null or empty", nameof(roleName));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        return $"Добавлена роль '{roleName}' для клиента {clientId} в реалме {realm}";
    }

    public string RoleRemoved(string roleName, string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(roleName))
            throw new ArgumentException("Role name cannot be null or empty", nameof(roleName));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        return $"Удалена роль '{roleName}' для клиента {clientId} в реалме {realm}";
    }

    public string SecretRegenerated(string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        return $"Регенерирован Client Secret для клиента {clientId} в реалме {realm}";
    }

    public string UserLogin(string username)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        
        return $"Пользователь {username} вошел в систему";
    }

    public string ForbiddenClientAdded(string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        return $"Клиент {clientId} из реалма {realm} добавлен в запрещенные";
    }

    public string ForbiddenClientRemoved(string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        return $"Клиент {clientId} из реалма {realm} удален из запрещенных";
    }

    public string ClientMigrated(string sourceRealm, string targetRealm, string status)
    {
        if (string.IsNullOrWhiteSpace(sourceRealm))
            throw new ArgumentException("Source realm cannot be null or empty", nameof(sourceRealm));
        if (string.IsNullOrWhiteSpace(targetRealm))
            throw new ArgumentException("Target realm cannot be null or empty", nameof(targetRealm));
        if (string.IsNullOrWhiteSpace(status))
            throw new ArgumentException("Status cannot be null or empty", nameof(status));
        
        return $"Клиент перенесён из {MigrationConstants.StatusTest} ({sourceRealm}) в {MigrationConstants.StatusStage} ({targetRealm}). Статус: {status}";
    }
}

