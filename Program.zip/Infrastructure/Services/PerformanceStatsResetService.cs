using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Фоновый сервис для автоматического сброса статистики производительности
/// </summary>
public class PerformanceStatsResetService : BackgroundService
{
    private readonly ILogger<PerformanceStatsResetService> _logger;
    private readonly IPerformanceMetricsService _metricsService;
    private readonly ISqlitePerformanceMonitor _sqliteMonitor;
    private readonly PerformanceStatsResetSettings _settings;
    private readonly TimeSpan _resetInterval;
    private readonly SemaphoreSlim _resetSemaphore;
    private readonly TimeSpan _resetTimeout;
    
    private int _consecutiveErrors = 0;
    private long _successfulResets = 0;
    private long _failedResets = 0;
    
    private const int MaxConsecutiveErrors = 5;
    private static readonly TimeSpan BaseErrorDelay = TimeSpan.FromSeconds(30);
    private static readonly TimeSpan MaxErrorDelay = TimeSpan.FromMinutes(5);
    private const int MaxErrorMessagesInLog = 5;
    private const int MaxConsecutiveErrorsValue = int.MaxValue - 1000; // Защита от переполнения
    private const int MaxPowerShift = 62; // Максимальный битовый сдвиг для long (2^62 безопасно)
    private static readonly TimeSpan DefaultResetTimeout = TimeSpan.FromMinutes(5);
    private const int StatsLoggingInterval = 10;

    public PerformanceStatsResetService(
        ILogger<PerformanceStatsResetService> logger,
        IPerformanceMetricsService metricsService,
        ISqlitePerformanceMonitor sqliteMonitor,
        IOptions<PerformanceStatsResetSettings> settings)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _metricsService = metricsService ?? throw new ArgumentNullException(nameof(metricsService));
        _sqliteMonitor = sqliteMonitor ?? throw new ArgumentNullException(nameof(sqliteMonitor));
        
        var settingsValue = settings?.Value ?? throw new ArgumentNullException(nameof(settings));
        _settings = settingsValue;
        
        // Валидация интервала
        var interval = _settings.ResetInterval;
        if (interval <= TimeSpan.Zero)
            throw new ArgumentException("Reset interval must be positive", nameof(settings));
        if (interval == TimeSpan.MaxValue)
            throw new ArgumentException("Reset interval cannot be TimeSpan.MaxValue", nameof(settings));
        if (interval > TimeSpan.FromHours(24))
            throw new ArgumentException("Reset interval cannot exceed 24 hours", nameof(settings));
        
        _resetInterval = interval;
        _resetSemaphore = new SemaphoreSlim(1, 1); // Только один поток может выполнять сброс одновременно
        _resetTimeout = DefaultResetTimeout;
        
        // Проверка константы MaxConsecutiveErrors
        if (MaxConsecutiveErrors <= 0)
        {
            throw new InvalidOperationException("MaxConsecutiveErrors must be greater than 0");
        }
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // Примечание: Изменение настройки Enabled требует перезапуска приложения для вступления в силу
        if (!_settings.Enabled)
        {
            _logger.LogInformation("Сервис сброса статистики производительности отключен в конфигурации");
            return;
        }
        
        _logger.LogInformation(
            "Фоновый сервис сброса статистики производительности запущен. Интервал: {Interval}",
            _resetInterval);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await Task.Delay(_resetInterval, stoppingToken);
                
                if (!stoppingToken.IsCancellationRequested)
                {
                    await ResetPerformanceStatsAsync(stoppingToken);
                    Interlocked.Exchange(ref _consecutiveErrors, 0); // Сброс счетчика при успехе
                }
            }
            catch (Exception ex) when (IsCancellationException(ex))
            {
                _logger.LogInformation("Фоновый сервис сброса статистики производительности остановлен по запросу.");
                break;
            }
            catch (Exception ex)
            {
                await HandleErrorAsync(ex, stoppingToken);
            }
        }

        var successful = Volatile.Read(ref _successfulResets);
        var failed = Volatile.Read(ref _failedResets);
        
        _logger.LogInformation(
            "Фоновый сервис сброса статистики производительности завершил работу. " +
            "Итоговая статистика: Успешно: {Success}, Ошибок: {Failed}",
            successful, failed);
    }

    private async Task ResetPerformanceStatsAsync(CancellationToken cancellationToken = default)
    {
        // Защита от одновременного выполнения сброса
        if (!await _resetSemaphore.WaitAsync(0, cancellationToken))
        {
            _logger.LogWarning("Операция сброса уже выполняется, пропускаем текущий запрос");
            return;
        }

        var stopwatch = Stopwatch.StartNew();
        var resetTime = DateTime.UtcNow; // Кэшируем время для использования в логах
        
        try
        {
            // Используем таймаут для операции сброса
            using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeoutCts.CancelAfter(_resetTimeout);
            
            var resetResults = new List<(string Service, bool Success, string? Error)>(capacity: 2);
            
            // Сброс IPerformanceMetricsService с валидацией
            await ResetMetricsServiceAsync(resetResults, timeoutCts.Token);
            
            // Сброс SqlitePerformanceMonitor с валидацией
            await ResetSqliteMonitorAsync(resetResults, timeoutCts.Token);
            
            // Логирование результата
            var successCount = resetResults.Count(r => r.Success);
            var totalCount = resetResults.Count;
            
            if (successCount == totalCount)
            {
                var newValue = Interlocked.Increment(ref _successfulResets);
                if (newValue == long.MaxValue)
                {
                    // Защита от переполнения - сброс счетчика
                    Interlocked.Exchange(ref _successfulResets, 0);
                    _logger.LogWarning("Счетчик успешных сбросов достиг максимума, выполнен сброс");
                }
                
                _logger.LogInformation(
                    "Performance statistics reset completed successfully at {ResetTime:yyyy-MM-dd HH:mm:ss} UTC. " +
                    "All {Count} services reset.",
                    resetTime, totalCount);
            }
            else
            {
                var newValue = Interlocked.Increment(ref _failedResets);
                if (newValue == long.MaxValue)
                {
                    // Защита от переполнения - сброс счетчика
                    Interlocked.Exchange(ref _failedResets, 0);
                    _logger.LogWarning("Счетчик неудачных сбросов достиг максимума, выполнен сброс");
                }
                
                // Оптимизация: собираем ошибки напрямую без лишних итераций
                var errorCount = 0;
                var errorBuilder = new System.Text.StringBuilder();
                var loggedErrors = 0;
                
                foreach (var result in resetResults)
                {
                    if (!result.Success)
                    {
                        errorCount++;
                        if (loggedErrors < MaxErrorMessagesInLog)
                        {
                            if (loggedErrors > 0)
                                errorBuilder.Append("; ");
                            errorBuilder.Append(result.Service).Append(": ").Append(result.Error);
                            loggedErrors++;
                        }
                    }
                }
                
                if (errorCount > MaxErrorMessagesInLog)
                {
                    errorBuilder.Append("; ... и еще ").Append(errorCount - MaxErrorMessagesInLog).Append(" ошибок");
                }
                
                _logger.LogWarning(
                    "Performance statistics reset completed with errors at {ResetTime:yyyy-MM-dd HH:mm:ss} UTC. " +
                    "Success: {SuccessCount}/{TotalCount}. Errors: {Errors}",
                    resetTime, successCount, totalCount, errorBuilder.ToString());
            }
            
            // Периодическое логирование статистики
            var successful = Volatile.Read(ref _successfulResets);
            var failed = Volatile.Read(ref _failedResets);
            var totalOperations = successful + failed;
            
            if (totalOperations > 0 && totalOperations % StatsLoggingInterval == 0)
            {
                _logger.LogInformation(
                    "Статистика работы сервиса сброса: Успешно: {Success}, Ошибок: {Failed}",
                    successful, failed);
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            _logger.LogWarning("Операция сброса была отменена");
            throw;
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("Операция сброса превысила таймаут {Timeout}", _resetTimeout);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            _logger.LogDebug("Операция сброса статистики заняла {ElapsedMs} мс", stopwatch.ElapsedMilliseconds);
            _resetSemaphore.Release();
        }
    }

    private async Task ResetMetricsServiceAsync(
        List<(string Service, bool Success, string? Error)> resetResults,
        CancellationToken cancellationToken)
    {
        try
        {
            // Получаем метрики до сброса для валидации
            var metricsBefore = _metricsService.GetAllMetrics();
            var hasMetricsBefore = metricsBefore != null && metricsBefore.Count > 0;
            
            _metricsService.Reset();
            
            // Валидация: проверяем, что метрики действительно сброшены
            await Task.Yield(); // Даем время на завершение операции
            var metricsAfter = _metricsService.GetAllMetrics();
            var hasMetricsAfter = metricsAfter != null && metricsAfter.Count > 0;
            
            // Если были метрики до сброса, но они остались после - это ошибка
            if (hasMetricsBefore && hasMetricsAfter && metricsAfter != null && metricsBefore != null && metricsAfter.Count >= metricsBefore.Count)
            {
                var errorMsg = $"Метрики не были полностью сброшены. Было: {metricsBefore.Count}, стало: {metricsAfter.Count}";
                resetResults.Add(("IPerformanceMetricsService", false, errorMsg));
                _logger.LogError("Failed to reset IPerformanceMetricsService statistics: {Error}", errorMsg);
                return;
            }
            
            resetResults.Add(("IPerformanceMetricsService", true, null));
            _logger.LogDebug("IPerformanceMetricsService statistics reset successfully");
        }
        catch (Exception ex)
        {
            resetResults.Add(("IPerformanceMetricsService", false, ex.Message));
            _logger.LogError(ex, "Failed to reset IPerformanceMetricsService statistics");
        }
    }

    private async Task ResetSqliteMonitorAsync(
        List<(string Service, bool Success, string? Error)> resetResults,
        CancellationToken cancellationToken)
    {
        try
        {
            // Получаем статистику до сброса для валидации
            var statsBefore = _sqliteMonitor.GetAllDatabaseStats();
            var hasStatsBefore = statsBefore != null && statsBefore.Count > 0;
            
            _sqliteMonitor.ResetAllStats();
            
            // Валидация: проверяем, что статистика действительно сброшена
            await Task.Yield(); // Даем время на завершение операции
            var statsAfter = _sqliteMonitor.GetAllDatabaseStats();
            var hasStatsAfter = statsAfter != null && statsAfter.Count > 0;
            
            // Проверяем, что все значения сброшены (TotalTimeMs и RequestCount должны быть 0)
            if (hasStatsAfter && statsAfter != null)
            {
                var notResetDatabases = statsAfter
                    .Where(kvp => kvp.Value.TotalTimeMs > 0 || kvp.Value.RequestCount > 0)
                    .Select(kvp => kvp.Key)
                    .ToList();
                
                if (notResetDatabases.Count > 0)
                {
                    var errorMsg = $"Статистика не была полностью сброшена для БД: {string.Join(", ", notResetDatabases)}";
                    resetResults.Add(("SqlitePerformanceMonitor", false, errorMsg));
                    _logger.LogError("Failed to reset SqlitePerformanceMonitor statistics: {Error}", errorMsg);
                    return;
                }
            }
            
            resetResults.Add(("SqlitePerformanceMonitor", true, null));
            _logger.LogDebug("SqlitePerformanceMonitor statistics reset successfully");
        }
        catch (Exception ex)
        {
            resetResults.Add(("SqlitePerformanceMonitor", false, ex.Message));
            _logger.LogError(ex, "Failed to reset SqlitePerformanceMonitor statistics");
        }
    }

    private async Task HandleErrorAsync(Exception ex, CancellationToken stoppingToken)
    {
        var errorCount = Interlocked.Increment(ref _consecutiveErrors);
        
        // Защита от переполнения
        if (errorCount >= MaxConsecutiveErrorsValue)
        {
            _logger.LogCritical(
                "Счетчик последовательных ошибок достиг критического значения ({MaxValue}), выполнен сброс",
                MaxConsecutiveErrorsValue);
            Interlocked.Exchange(ref _consecutiveErrors, MaxConsecutiveErrors);
        }
        
        _logger.LogError(ex, 
            "Ошибка при сбросе статистики производительности. Последовательных ошибок: {ErrorCount}", 
            errorCount);
        
        // Экспоненциальная задержка при ошибках
        if (errorCount <= MaxConsecutiveErrors)
        {
            // Используем битовый сдвиг вместо Math.Pow для степеней двойки (оптимизация производительности)
            // Защита от переполнения: ограничиваем максимальный сдвиг
            var shift = Math.Min(errorCount - 1, MaxPowerShift);
            var power = shift > 0 ? (1L << shift) : 1;
            var delaySeconds = Math.Min(
                BaseErrorDelay.TotalSeconds * power, 
                MaxErrorDelay.TotalSeconds);
            var delay = TimeSpan.FromSeconds(delaySeconds);
            
            _logger.LogWarning(
                "Ожидание {Delay} секунд перед следующей попыткой из-за ошибок",
                delay.TotalSeconds);
            
            try
            {
                await Task.Delay(delay, stoppingToken);
            }
            catch (Exception delayEx) when (IsCancellationException(delayEx))
            {
                // Игнорируем отмену при задержке
            }
        }
        else
        {
            _logger.LogCritical(
                "Достигнуто максимальное количество последовательных ошибок ({MaxErrors}). " +
                "Сервис продолжит работу с обычным интервалом.",
                MaxConsecutiveErrors);
            Interlocked.Exchange(ref _consecutiveErrors, 0); // Сброс для следующего цикла
        }
    }

    private static bool IsCancellationException(Exception ex)
    {
        return ex is TaskCanceledException || ex is OperationCanceledException;
    }

    public override void Dispose()
    {
        _resetSemaphore?.Dispose();
        base.Dispose();
    }
}
