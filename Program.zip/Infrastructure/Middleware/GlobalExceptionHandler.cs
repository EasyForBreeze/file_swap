using System.Net;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace new_assistant.Infrastructure.Middleware;

/// <summary>
/// Глобальный обработчик исключений для критических ошибок
/// </summary>
public class GlobalExceptionHandler : IExceptionHandler
{
    private readonly ILogger<GlobalExceptionHandler> _logger;

    public GlobalExceptionHandler(ILogger<GlobalExceptionHandler> logger)
    {
        _logger = logger;
    }

    public async ValueTask<bool> TryHandleAsync(
        HttpContext httpContext,
        Exception exception,
        CancellationToken cancellationToken)
    {
        // Логируем исключение
        _logger.LogError(exception, "Критическая ошибка: {Message}", exception.Message);

        // Определяем, является ли ошибка критической
        var isCriticalError = IsCriticalError(exception);

        // Проверяем, является ли запрос API запросом
        var isApiRequest = httpContext.Request.Path.StartsWithSegments("/api");

        if (isApiRequest)
        {
            // Для API запросов возвращаем ProblemDetails в формате JSON
            var statusCode = GetStatusCode(exception);
            var environment = httpContext.RequestServices.GetService<IWebHostEnvironment>();
            
            var problemDetails = new ProblemDetails
            {
                Status = statusCode,
                Title = GetUserFriendlyMessage(exception),
                Detail = environment?.IsDevelopment() == true ? exception.ToString() : null,
                Instance = httpContext.Request.Path
            };

            httpContext.Response.StatusCode = statusCode;
            httpContext.Response.ContentType = "application/problem+json";
            
            await httpContext.Response.WriteAsJsonAsync(problemDetails, cancellationToken);
            return true;
        }

        if (isCriticalError)
        {
            // Для критических ошибок перенаправляем на страницу ошибки
            var errorMessage = GetUserFriendlyMessage(exception);
            var errorCode = GetErrorCode(exception);

            // Проверяем, не является ли текущий запрос уже запросом к странице ошибки
            if (!httpContext.Request.Path.StartsWithSegments("/error"))
            {
                // Используем Items для передачи данных об ошибке (доступно в рамках одного запроса)
                httpContext.Items["ErrorMessage"] = errorMessage;
                httpContext.Items["ErrorCode"] = errorCode;
                
                // В режиме разработки добавляем детали
                var environment = httpContext.RequestServices.GetService<IWebHostEnvironment>();
                if (environment?.IsDevelopment() == true)
                {
                    httpContext.Items["ErrorDetails"] = exception.ToString();
                }

                // Используем короткий URL без параметров
                httpContext.Response.Redirect("/error");
                return true;
            }
        }

        // Для некритических ошибок возвращаем false, чтобы передать обработку дальше
        return false;
    }

    /// <summary>
    /// Определяет, является ли исключение критическим
    /// </summary>
    private bool IsCriticalError(Exception exception)
    {
        // Проверяем тип исключения
        return exception switch
        {
            // Ошибки подключения к внешним сервисам (KeyCloak и т.д.)
            HttpRequestException => true,
            TimeoutException => true,
            TaskCanceledException => true,
            OperationCanceledException => true,
            
            // Ошибки базы данных SQLite
            Microsoft.Data.Sqlite.SqliteException => true,
            
            // Ошибки аутентификации/авторизации, которые могут указывать на недоступность KeyCloak
            InvalidOperationException ex when ex.Message.Contains("KeyCloak") || 
                                               ex.Message.Contains("authentication") ||
                                               ex.Message.Contains("token") => true,
            
            // Все остальные - некритические
            _ => false
        };
    }

    /// <summary>
    /// Получает понятное для пользователя сообщение об ошибке
    /// </summary>
    private string GetUserFriendlyMessage(Exception exception)
    {
        return exception switch
        {
            HttpRequestException => "Не удалось подключиться к серверу аутентификации KeyCloak. Пожалуйста, попробуйте позже.",
            TimeoutException => "Превышено время ожидания ответа от сервера. Пожалуйста, попробуйте позже.",
            TaskCanceledException => "Запрос был прерван. Пожалуйста, попробуйте еще раз.",
            Microsoft.Data.Sqlite.SqliteException => "Возникла проблема с подключением к базе данных. Пожалуйста, попробуйте позже.",
            InvalidOperationException ex when ex.Message.Contains("KeyCloak") => 
                "Сервис аутентификации временно недоступен. Пожалуйста, попробуйте позже.",
            _ => "Произошла непредвиденная ошибка. Наша команда уже уведомлена и работает над устранением проблемы."
        };
    }

    /// <summary>
    /// Получает код ошибки для логирования
    /// </summary>
    private string GetErrorCode(Exception exception)
    {
        return exception switch
        {
            HttpRequestException => "503",
            TimeoutException => "504",
            TaskCanceledException => "408",
            Microsoft.Data.Sqlite.SqliteException => "503",
            _ => "500"
        };
    }

    /// <summary>
    /// Получает HTTP статус код для исключения
    /// </summary>
    private int GetStatusCode(Exception exception)
    {
        return exception switch
        {
            HttpRequestException => StatusCodes.Status503ServiceUnavailable,
            TimeoutException => StatusCodes.Status504GatewayTimeout,
            TaskCanceledException => StatusCodes.Status408RequestTimeout,
            Microsoft.Data.Sqlite.SqliteException => StatusCodes.Status503ServiceUnavailable,
            _ => StatusCodes.Status500InternalServerError
        };
    }
}

