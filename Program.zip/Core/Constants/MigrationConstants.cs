namespace new_assistant.Core.Constants;

/// <summary>
/// Константы для миграции клиентов
/// </summary>
public static class MigrationConstants
{
    /// <summary>
    /// Realm для глобальных записей Wiki
    /// </summary>
    public const string RealmGlobal = "GLOBAL";
    
    /// <summary>
    /// Статус STAGE (используется для статуса и публикации)
    /// </summary>
    public const string StatusStage = "STAGE";
    
    /// <summary>
    /// Статус TEST
    /// </summary>
    public const string StatusTest = "TEST";
    
    /// <summary>
    /// Статус публикации STAGE (алиас для StatusStage)
    /// </summary>
    public const string PublicationStatusStage = StatusStage;
    
    /// <summary>
    /// Префикс для ручных pageId
    /// </summary>
    public const string ManualPageIdPrefix = "manual-";
    
    /// <summary>
    /// Максимальная длина pageId
    /// </summary>
    public const int MaxPageIdLength = 50;
    
    /// <summary>
    /// Длина ручного pageId
    /// </summary>
    public const int ManualPageIdLength = 16;
    
    /// <summary>
    /// Окружение STAGE
    /// </summary>
    public const string EnvironmentStage = "STAGE";
    
    /// <summary>
    /// Окружение TEST
    /// </summary>
    public const string EnvironmentTest = "TEST";
    
    /// <summary>
    /// Тип scope: default
    /// </summary>
    public const string ScopeTypeDefault = "default";
    
    /// <summary>
    /// Тип scope: optional
    /// </summary>
    public const string ScopeTypeOptional = "optional";
    
    /// <summary>
    /// Статус миграции: Success
    /// </summary>
    public const string MigrationStatusSuccess = "Success";
    
    /// <summary>
    /// Статус миграции: PartialSuccess
    /// </summary>
    public const string MigrationStatusPartialSuccess = "PartialSuccess";
    
    /// <summary>
    /// Статус миграции: Failed
    /// </summary>
    public const string MigrationStatusFailed = "Failed";
    
    /// <summary>
    /// Максимальная длина ClientId
    /// </summary>
    public const int MaxClientIdLength = 200;
    
    /// <summary>
    /// Максимальная длина Realm
    /// </summary>
    public const int MaxRealmLength = 100;
    
    /// <summary>
    /// Максимальная длина Email
    /// </summary>
    public const int MaxEmailLength = 254;
    
    /// <summary>
    /// Максимальная длина URL
    /// </summary>
    public const int MaxUrlLength = 2048;
    
    /// <summary>
    /// Максимальная длина поля migratedBy
    /// </summary>
    public const int MaxMigratedByLength = 200;
    
    /// <summary>
    /// Размер батча для обработки больших списков
    /// </summary>
    public const int BatchSize = 50;
    
    /// <summary>
    /// Длина хеша для обрезки pageId
    /// </summary>
    public const int PageIdHashLength = 8;
    
    /// <summary>
    /// Максимальная длина URL для валидации
    /// </summary>
    public const int MaxWikiUrlLength = 2048;
}

