namespace new_assistant.Core.Constants;

/// <summary>
/// Константы для страницы ClientDetails
/// </summary>
public static class ClientDetailsConstants
{
    /// <summary>
    /// Названия вкладок
    /// </summary>
    public static class Tabs
    {
        public const string Settings = "settings";
        public const string Credentials = "credentials";
        public const string Roles = "roles";
        public const string Endpoints = "endpoints";
        public const string Evaluate = "evaluate";
        public const string Events = "events";
    }

    /// <summary>
    /// Типы токенов для генерации
    /// </summary>
    public static class TokenTypes
    {
        public const string Access = "access";
        public const string Id = "id";
        public const string UserInfo = "userinfo";
    }

    /// <summary>
    /// Значения фильтров событий
    /// </summary>
    public enum EventFilter
    {
        All
    }
    
    /// <summary>
    /// Значения фильтров событий (строковые константы для обратной совместимости)
    /// </summary>
    public static class EventFilters
    {
        public const string All = "all";
    }

    /// <summary>
    /// Константы для таймаутов операций (в секундах)
    /// </summary>
    public static class Timeouts
    {
        /// <summary>
        /// Таймаут для загрузки данных клиента
        /// </summary>
        public const int LoadClientDetails = 30;

        /// <summary>
        /// Таймаут для сохранения изменений
        /// </summary>
        public const int SaveChanges = 30;

        /// <summary>
        /// Таймаут для поиска ролей
        /// </summary>
        public const int SearchRoles = 15;

        /// <summary>
        /// Таймаут для поиска пользователей
        /// </summary>
        public const int SearchUsers = 15;

        /// <summary>
        /// Таймаут для генерации токена
        /// </summary>
        public const int GenerateToken = 20;

        /// <summary>
        /// Таймаут для загрузки событий
        /// </summary>
        public const int LoadEvents = 30;

        /// <summary>
        /// Таймаут для удаления клиента
        /// </summary>
        public const int DeleteClient = 30;
    }

    /// <summary>
    /// Константы для UI (задержки, размеры и т.д.)
    /// </summary>
    public static class Ui
    {
        /// <summary>
        /// Задержка перед показом индикатора загрузки (в миллисекундах)
        /// </summary>
        public const int LoadingIndicatorDelay = 200;

        /// <summary>
        /// Задержка перед показом спиннера поиска (в миллисекундах)
        /// </summary>
        public const int SearchSpinnerDelay = 500;

        /// <summary>
        /// Количество событий на странице
        /// </summary>
        public const int EventsPerPage = 10;

        /// <summary>
        /// Задержка анимации обновления событий (в миллисекундах)
        /// </summary>
        public const int EventsAnimationDelay = 200;

        /// <summary>
        /// Задержка после обновления событий (в миллисекундах)
        /// </summary>
        public const int EventsUpdateDelay = 100;
    }
}

