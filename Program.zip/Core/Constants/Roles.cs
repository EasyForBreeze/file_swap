namespace new_assistant.Core.Constants;

/// <summary>
/// Константы для ролей пользователей
/// </summary>
public static class Roles
{
    /// <summary>
    /// Роль администратора - полный доступ ко всем функциям
    /// </summary>
    public const string Admin = "assistant-admin";
    
    /// <summary>
    /// Роль пользователя - доступ к разделу "Мои клиенты"
    /// </summary>
    public const string User = "assistant-user";
    
    /// <summary>
    /// Роль оператора - доступ к разделу "Управление пользователями"
    /// </summary>
    public const string Operator = "assistant-operator";
}

