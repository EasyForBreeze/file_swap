using System.Text.RegularExpressions;

namespace new_assistant.Core.Helpers;

/// <summary>
/// Утилита для маскирования чувствительных данных в логах
/// </summary>
public static class LogMaskingHelper
{
    private const string MaskedValue = "***MASKED***";
    private const int VisiblePrefixLength = 4;
    private const int VisibleSuffixLength = 4;
    
    // Паттерны для поиска чувствительных данных
    private static readonly Regex TokenPattern = new Regex(
        @"(?:access[_-]?token|refresh[_-]?token|bearer)\s*[:=]\s*([a-zA-Z0-9\-_\.]+)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);
    
    private static readonly Regex SecretPattern = new Regex(
        @"(?:secret|password|pwd|passwd)\s*[:=]\s*([^\s""']+)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);
    
    private static readonly Regex ClientSecretPattern = new Regex(
        @"(?:client[_-]?secret)\s*[:=]\s*([a-zA-Z0-9\-_\.]+)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);
    
    /// <summary>
    /// Маскирует токены в строке
    /// </summary>
    public static string MaskTokens(string? input)
    {
        if (string.IsNullOrEmpty(input))
            return input ?? string.Empty;
        
        return TokenPattern.Replace(input, match =>
        {
            var token = match.Groups[1].Value;
            return match.Value.Replace(token, MaskedValue);
        });
    }
    
    /// <summary>
    /// Маскирует секреты в строке
    /// </summary>
    public static string MaskSecrets(string? input)
    {
        if (string.IsNullOrEmpty(input))
            return input ?? string.Empty;
        
        var result = SecretPattern.Replace(input, match =>
        {
            var secret = match.Groups[1].Value;
            return match.Value.Replace(secret, MaskedValue);
        });
        
        return ClientSecretPattern.Replace(result, match =>
        {
            var secret = match.Groups[1].Value;
            return match.Value.Replace(secret, MaskedValue);
        });
    }
    
    /// <summary>
    /// Маскирует значение с частичным отображением (первые и последние символы)
    /// </summary>
    public static string MaskWithPartial(string? value, int visiblePrefix = VisiblePrefixLength, int visibleSuffix = VisibleSuffixLength)
    {
        if (string.IsNullOrEmpty(value))
            return string.Empty;
        
        if (value.Length <= visiblePrefix + visibleSuffix)
            return MaskedValue;
        
        var prefix = value.Substring(0, visiblePrefix);
        var suffix = value.Substring(value.Length - visibleSuffix);
        return $"{prefix}...{suffix}";
    }
    
    /// <summary>
    /// Полностью маскирует значение
    /// </summary>
    public static string Mask(string? value)
    {
        if (string.IsNullOrEmpty(value))
            return string.Empty;
        
        return MaskedValue;
    }
    
    /// <summary>
    /// Маскирует все чувствительные данные в строке
    /// </summary>
    public static string MaskSensitiveData(string? input)
    {
        if (string.IsNullOrEmpty(input))
            return input ?? string.Empty;
        
        var result = MaskTokens(input);
        result = MaskSecrets(result);
        return result;
    }
}

