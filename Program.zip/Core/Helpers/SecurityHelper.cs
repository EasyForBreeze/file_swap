using System.Text;
using System.Text.RegularExpressions;

namespace new_assistant.Core.Helpers;

/// <summary>
/// Утилиты для обеспечения безопасности
/// </summary>
public static class SecurityHelper
{
    // Константы для валидации
    private const int MaxRoleLength = 500;
    private const int MaxClientIdLength = 255;
    private const int MaxRealmLength = 100;
    private const int MaxUsernameLength = 255;
    private const int MaxDescriptionLength = 2000;
    
    // Паттерны для валидации
    private static readonly Regex DangerousCharsPattern = new Regex(@"[<>""'&]", RegexOptions.Compiled);
    private static readonly Regex PathTraversalPattern = new Regex(@"\.\.|[/\\]", RegexOptions.Compiled);
    
    /// <summary>
    /// Экранирует HTML символы для защиты от XSS
    /// </summary>
    /// <param name="input">Входная строка</param>
    /// <returns>Экранированная строка</returns>
    public static string HtmlEncode(string? input)
    {
        if (string.IsNullOrEmpty(input))
            return string.Empty;
        
        var sb = new StringBuilder(input.Length * 2);
        foreach (var c in input)
        {
            switch (c)
            {
                case '<':
                    sb.Append("&lt;");
                    break;
                case '>':
                    sb.Append("&gt;");
                    break;
                case '"':
                    sb.Append("&quot;");
                    break;
                case '\'':
                    sb.Append("&#x27;");
                    break;
                case '&':
                    sb.Append("&amp;");
                    break;
                default:
                    sb.Append(c);
                    break;
            }
        }
        return sb.ToString();
    }
    
    /// <summary>
    /// Валидирует длину строки
    /// </summary>
    /// <param name="value">Значение для проверки</param>
    /// <param name="maxLength">Максимальная длина</param>
    /// <param name="fieldName">Название поля для сообщения об ошибке</param>
    /// <exception cref="ArgumentException">Если длина превышает максимум</exception>
    public static void ValidateLength(string? value, int maxLength, string fieldName)
    {
        if (value != null && value.Length > maxLength)
        {
            throw new ArgumentException($"{fieldName} слишком длинный (максимум {maxLength} символов, получено {value.Length})", fieldName);
        }
    }
    
    /// <summary>
    /// Валидирует строку на наличие опасных символов для HTML
    /// </summary>
    /// <param name="value">Значение для проверки</param>
    /// <param name="fieldName">Название поля для сообщения об ошибке</param>
    /// <exception cref="ArgumentException">Если найдены опасные символы</exception>
    public static void ValidateNoHtmlChars(string? value, string fieldName)
    {
        if (string.IsNullOrEmpty(value))
            return;
        
        if (DangerousCharsPattern.IsMatch(value))
        {
            throw new ArgumentException($"{fieldName} содержит недопустимые HTML символы", fieldName);
        }
    }
    
    /// <summary>
    /// Валидирует строку на path traversal атаки
    /// </summary>
    /// <param name="value">Значение для проверки</param>
    /// <param name="fieldName">Название поля для сообщения об ошибке</param>
    /// <exception cref="ArgumentException">Если найдены признаки path traversal</exception>
    public static void ValidateNoPathTraversal(string? value, string fieldName)
    {
        if (string.IsNullOrEmpty(value))
            return;
        
        if (PathTraversalPattern.IsMatch(value))
        {
            throw new ArgumentException($"{fieldName} содержит недопустимые символы для пути", fieldName);
        }
    }
    
    /// <summary>
    /// Валидирует Client ID
    /// </summary>
    public static void ValidateClientId(string? clientId)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID не может быть пустым", nameof(clientId));
        
        ValidateLength(clientId, MaxClientIdLength, "Client ID");
        ValidateNoPathTraversal(clientId, "Client ID");
    }
    
    /// <summary>
    /// Валидирует Realm
    /// </summary>
    public static void ValidateRealm(string? realm)
    {
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        ValidateLength(realm, MaxRealmLength, "Realm");
        ValidateNoPathTraversal(realm, "Realm");
    }
    
    /// <summary>
    /// Валидирует имя пользователя
    /// </summary>
    public static void ValidateUsername(string? username)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username не может быть пустым", nameof(username));
        
        ValidateLength(username, MaxUsernameLength, "Username");
    }
    
    /// <summary>
    /// Валидирует роль
    /// </summary>
    public static void ValidateRole(string? role)
    {
        if (string.IsNullOrWhiteSpace(role))
            throw new ArgumentException("Role не может быть пустым", nameof(role));
        
        ValidateLength(role, MaxRoleLength, "Role");
        ValidateNoPathTraversal(role, "Role");
    }
    
    /// <summary>
    /// Валидирует описание
    /// </summary>
    public static void ValidateDescription(string? description)
    {
        if (description == null)
            return;
        
        ValidateLength(description, MaxDescriptionLength, "Description");
    }
}

