using System.Runtime.Serialization;

namespace new_assistant.Core.Exceptions;

/// <summary>
/// Исключение, возникающее при ошибках логирования аудита
/// </summary>
[Serializable]
public class AuditLoggingException : Exception
{
    public AuditLoggingException(string message) : base(message)
    {
    }

    public AuditLoggingException(string message, Exception innerException) : base(message, innerException)
    {
    }
    
    /// <summary>
    /// Конструктор для сериализации
    /// </summary>
    [Obsolete("This constructor is obsolete and will be removed in a future version. Use the standard constructors instead.")]
    protected AuditLoggingException(SerializationInfo info, StreamingContext context)
        : base(info, context)
    {
    }
}

