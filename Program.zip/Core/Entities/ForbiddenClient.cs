using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace new_assistant.Core.Entities;

/// <summary>
/// Сущность запрещенного клиента.
/// Клиенты в этом списке запрещены для взаимодействия обычными пользователями.
/// </summary>
[Table("forbidden_clients")]
public class ForbiddenClient
{
    /// <summary>
    /// Уникальный идентификатор записи
    /// </summary>
    [Key]
    [Column("id")]
    public int Id { get; set; }
    
    /// <summary>
    /// Client ID из Keycloak
    /// </summary>
    [Required]
    [Column("client_id")]
    [MaxLength(255)]
    // Note: Create index for performance: CREATE INDEX IX_forbidden_clients_client_id ON forbidden_clients(client_id);
    public string ClientId { get; set; } = string.Empty;
    
    /// <summary>
    /// Realm из Keycloak
    /// </summary>
    [Required]
    [Column("realm")]
    [MaxLength(255)]
    // Note: Create index for performance: CREATE INDEX IX_forbidden_clients_realm ON forbidden_clients(realm);
    public string Realm { get; set; } = string.Empty;
    
    /// <summary>
    /// Username администратора, который добавил клиента в запрещенные
    /// </summary>
    [Required]
    [Column("added_by")]
    [MaxLength(255)]
    public string AddedBy { get; set; } = string.Empty;
    
    /// <summary>
    /// Дата и время добавления в запрещенные
    /// </summary>
    [Required]
    [Column("added_at")]
    // Note: Create index for performance: CREATE INDEX IX_forbidden_clients_added_at ON forbidden_clients(added_at);
    public DateTime AddedAt { get; set; }
}

