using System.ComponentModel.DataAnnotations;

namespace new_assistant.Core.DTOs;

/// <summary>
/// ViewModel для создания нового пользователя
/// </summary>
public class CreateUserViewModel
{
    /// <summary>
    /// Имя пользователя (username)
    /// </summary>
    [Required(ErrorMessage = "Username обязателен")]
    [MinLength(3, ErrorMessage = "Username должен быть не менее 3 символов")]
    [MaxLength(255, ErrorMessage = "Username не может превышать 255 символов")]
    [RegularExpression(@"^[a-zA-Z0-9_.-]+$", ErrorMessage = "Username может содержать только буквы, цифры, точки, дефисы и подчеркивания")]
    public string Username { get; set; } = string.Empty;

    /// <summary>
    /// Имя пользователя
    /// </summary>
    [Required(ErrorMessage = "Имя обязательно")]
    [MinLength(1, ErrorMessage = "Имя не может быть пустым")]
    [MaxLength(255, ErrorMessage = "Имя не может превышать 255 символов")]
    public string FirstName { get; set; } = string.Empty;

    /// <summary>
    /// Фамилия пользователя
    /// </summary>
    [Required(ErrorMessage = "Фамилия обязательна")]
    [MinLength(1, ErrorMessage = "Фамилия не может быть пустой")]
    [MaxLength(255, ErrorMessage = "Фамилия не может превышать 255 символов")]
    public string LastName { get; set; } = string.Empty;

    /// <summary>
    /// Email адрес пользователя
    /// </summary>
    [Required(ErrorMessage = "Email обязателен")]
    [EmailAddress(ErrorMessage = "Email имеет неверный формат")]
    [MaxLength(255, ErrorMessage = "Email не может превышать 255 символов")]
    public string Email { get; set; } = string.Empty;
}

