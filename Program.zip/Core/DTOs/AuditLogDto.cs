using System;
using System.Collections.Generic;

namespace new_assistant.Core.DTOs;

/// <summary>
/// DTO для отображения записей аудита
/// </summary>
public class AuditLogDto
{
    public long Id { get; set; }
    public string EventType { get; set; } = string.Empty;
    public string EventTypeDisplay { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public string? ClientId { get; set; }
    public string? Realm { get; set; }
    public string? TargetUsername { get; set; }
    public string Description { get; set; } = string.Empty;
    public string? ChangeDetails { get; set; }
    public DateTime CreatedAt { get; set; }
}

/// <summary>
/// DTO для фильтрации записей аудита
/// </summary>
public class AuditLogFilterDto
{
    public string? EventType { get; set; }
    public string? Username { get; set; }
    public string? ClientId { get; set; }
    public string? Realm { get; set; }
    public DateTime? DateFrom { get; set; }
    public DateTime? DateTo { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 10;
}

/// <summary>
/// DTO для изменений полей клиента
/// </summary>
public record FieldChangeDto
{
    public string FieldName { get; init; } = string.Empty;
    public string? OldValue { get; init; }
    public string? NewValue { get; init; }
}

/// <summary>
/// Результат запроса с пагинацией
/// </summary>
public class AuditLogPagedResult
{
    public IReadOnlyList<AuditLogDto> Items { get; set; } = Array.Empty<AuditLogDto>();
    public int TotalCount { get; set; }
    public int Page { get; set; }
    public int PageSize { get; set; }
    
    private int? _totalPages;
    
    public int TotalPages
    {
        get
        {
            if (_totalPages.HasValue)
                return _totalPages.Value;
            
            if (PageSize <= 0)
                return 0;
            
            _totalPages = (int)Math.Ceiling(TotalCount / (double)PageSize);
            return _totalPages.Value;
        }
    }
    
    public AuditLogPagedResult()
    {
    }
    
    public AuditLogPagedResult(IEnumerable<AuditLogDto> items, int totalCount, int page, int pageSize)
    {
        var itemsList = items?.ToList();
        Items = itemsList != null ? itemsList.AsReadOnly() : (IReadOnlyList<AuditLogDto>)Array.Empty<AuditLogDto>();
        TotalCount = totalCount;
        Page = page > 0 ? page : 1;
        PageSize = pageSize > 0 ? pageSize : 10;
    }
}

