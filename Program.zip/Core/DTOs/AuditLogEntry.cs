namespace new_assistant.Core.DTOs;

/// <summary>
/// Запись аудит-лога для массовой вставки
/// </summary>
public record AuditLogEntry(
    string EventType,
    string Username,
    string? ClientId,
    string? Realm,
    string? TargetUsername,
    string Description,
    string? ChangeDetails
);

