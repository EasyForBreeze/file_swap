using new_assistant.Core.DTOs;

namespace new_assistant.Core.DTOs;

/// <summary>
/// ViewModel для работы с событиями клиента
/// Группирует связанные параметры для упрощения управления состоянием
/// </summary>
public class ClientEventsViewModel
{
    /// <summary>
    /// Все загруженные события
    /// </summary>
    public IReadOnlyList<ClientEventDto> AllEvents { get; set; } = Array.Empty<ClientEventDto>();

    /// <summary>
    /// Отфильтрованные события для текущей страницы
    /// </summary>
    public IReadOnlyList<ClientEventDto> FilteredEvents { get; set; } = Array.Empty<ClientEventDto>();

    /// <summary>
    /// Все типы событий
    /// </summary>
    public IReadOnlyList<string> AllEventTypes { get; set; } = Array.Empty<string>();

    /// <summary>
    /// Выбранный тип события для фильтрации
    /// </summary>
    public string SelectedEventType { get; set; } = "all";

    /// <summary>
    /// Фильтр по пользователю
    /// </summary>
    public string UserFilter { get; set; } = string.Empty;

    /// <summary>
    /// Дата начала для фильтрации
    /// </summary>
    public DateTime? DateFrom { get; set; }

    /// <summary>
    /// Дата окончания для фильтрации
    /// </summary>
    public DateTime? DateTo { get; set; }

    /// <summary>
    /// Текущая страница событий
    /// </summary>
    public int CurrentEventsPage { get; set; } = 1;

    /// <summary>
    /// Количество событий на странице
    /// </summary>
    public int EventsPerPage { get; set; } = 10;

    /// <summary>
    /// Флаг загрузки событий
    /// </summary>
    public bool EventsLoaded { get; set; } = false;

    /// <summary>
    /// Флаг применения фильтров
    /// </summary>
    public bool HasAppliedFilters { get; set; } = false;

    /// <summary>
    /// Флаг анимации обновления событий
    /// </summary>
    public bool IsEventsAnimating { get; set; } = false;
    
    /// <summary>
    /// Поле для сортировки событий
    /// </summary>
    public string SortBy { get; set; } = "Time";
    
    /// <summary>
    /// Направление сортировки (true - по убыванию, false - по возрастанию)
    /// </summary>
    public bool SortDescending { get; set; } = true;
}

