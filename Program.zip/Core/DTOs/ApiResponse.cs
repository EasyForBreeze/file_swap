namespace new_assistant.Core.DTOs;

/// <summary>
/// Стандартизированный класс для ответов с ошибками API
/// </summary>
public class ApiErrorResponse
{
    /// <summary>
    /// Сообщение об ошибке
    /// </summary>
    public string Error { get; set; } = string.Empty;
    
    /// <summary>
    /// Дополнительные детали об ошибке (опционально)
    /// </summary>
    public string? Details { get; set; }
}

/// <summary>
/// Стандартизированный класс для успешных ответов API
/// </summary>
public class ApiSuccessResponse
{
    /// <summary>
    /// Флаг успешности операции
    /// </summary>
    public bool Success { get; set; } = true;
    
    /// <summary>
    /// Сообщение о результате операции
    /// </summary>
    public string Message { get; set; } = string.Empty;
    
    /// <summary>
    /// Дополнительные данные ответа (опционально)
    /// </summary>
    public object? Data { get; set; }
}

