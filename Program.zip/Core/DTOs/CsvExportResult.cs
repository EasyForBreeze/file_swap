namespace new_assistant.Core.DTOs;

/// <summary>
/// Результат экспорта в CSV
/// </summary>
public record CsvExportResult
{
    public byte[] Content { get; init; } = Array.Empty<byte>();
    public string Encoding { get; init; } = "UTF-8";
    public string FileName { get; init; } = "audit_logs.csv";
    public string ContentType { get; init; } = "text/csv; charset=utf-8";
}

