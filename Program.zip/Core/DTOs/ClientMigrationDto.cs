using System.ComponentModel.DataAnnotations;

namespace new_assistant.Core.DTOs;

/// <summary>
/// Запрос на перенос клиента
/// </summary>
public class ClientMigrationRequest
{
    /// <summary>
    /// ID клиента для переноса
    /// </summary>
    [Required(ErrorMessage = "ClientId обязателен")]
    public string ClientId { get; set; } = string.Empty;
    
    /// <summary>
    /// Исходный realm (TEST)
    /// </summary>
    [Required(ErrorMessage = "SourceRealm обязателен")]
    public string SourceRealm { get; set; } = string.Empty;
    
    /// <summary>
    /// Целевой realm (STAGE)
    /// </summary>
    [Required(ErrorMessage = "TargetRealm обязателен")]
    public string TargetRealm { get; set; } = string.Empty;
    
    /// <summary>
    /// Номер заявки (опционально)
    /// </summary>
    public string? TicketNumber { get; set; }
    
    /// <summary>
    /// Email для уведомления (опционально)
    /// </summary>
    public string? NotificationEmail { get; set; }
    
    /// <summary>
    /// Ссылка на Wiki страницу (опционально)
    /// </summary>
    public string? WikiPageUrl { get; set; }

    /// <summary>
    /// Ссылка на заявку (опционально)
    /// </summary>
    public string? TicketUrl { get; set; }
}

/// <summary>
/// Результат валидации возможности переноса
/// </summary>
public class MigrationValidationResult
{
    /// <summary>
    /// Можно ли выполнить перенос
    /// </summary>
    public bool CanMigrate { get; set; }
    
    /// <summary>
    /// Клиент существует в целевом realm
    /// </summary>
    public bool ClientExistsInTarget { get; set; }
    
    /// <summary>
    /// Отсутствующие realm roles
    /// </summary>
    public List<string> MissingRealmRoles { get; set; } = new();
    
    /// <summary>
    /// Отсутствующие client roles (формат: "clientId:roleName")
    /// </summary>
    public List<string> MissingClientRoles { get; set; } = new();
    
    /// <summary>
    /// Отсутствующие client scopes
    /// </summary>
    public List<string> MissingClientScopes { get; set; } = new();
    
    /// <summary>
    /// Отсутствующие authentication flows
    /// </summary>
    public List<string> MissingAuthFlows { get; set; } = new();
    
    /// <summary>
    /// Существующие realm roles (прошедшие валидацию)
    /// </summary>
    public List<string> ValidatedRealmRoles { get; set; } = new();
    
    /// <summary>
    /// Существующие client roles (прошедшие валидацию, формат: "clientId:roleName")
    /// </summary>
    public List<string> ValidatedClientRoles { get; set; } = new();
    
    /// <summary>
    /// Существующие default client scopes (прошедшие валидацию)
    /// </summary>
    public List<string> ValidatedDefaultClientScopes { get; set; } = new();
    
    /// <summary>
    /// Существующие optional client scopes (прошедшие валидацию)
    /// </summary>
    public List<string> ValidatedOptionalClientScopes { get; set; } = new();
    
    /// <summary>
    /// Ссылка на Wiki страницу, найденную в репозитории (если есть)
    /// </summary>
    public string? ExistingWikiPageUrl { get; set; }
    
    private int? _warningCount;
    
    /// <summary>
    /// Общее количество warnings
    /// </summary>
    public int WarningCount
    {
        get
        {
            if (_warningCount.HasValue)
                return _warningCount.Value;
            
            _warningCount = MissingRealmRoles.Count + MissingClientRoles.Count + 
                           MissingClientScopes.Count + MissingAuthFlows.Count;
            return _warningCount.Value;
        }
    }
    
    /// <summary>
    /// Детальное описание проблем
    /// </summary>
    public List<string> Messages { get; set; } = new();
}

/// <summary>
/// Результат переноса клиента
/// </summary>
public class ClientMigrationResult
{
    /// <summary>
    /// Успешно ли выполнен перенос
    /// </summary>
    public bool Success { get; set; }
    
    /// <summary>
    /// ID клиента
    /// </summary>
    public string ClientId { get; set; } = string.Empty;
    
    /// <summary>
    /// Новый Client Secret в STAGE
    /// </summary>
    public string NewClientSecret { get; set; } = string.Empty;
    
    /// <summary>
    /// Internal ID клиента в STAGE
    /// </summary>
    public string NewInternalId { get; set; } = string.Empty;
    
    /// <summary>
    /// Пароль от архива с учетными данными
    /// </summary>
    public string ArchivePassword { get; set; } = string.Empty;
    
    /// <summary>
    /// Количество перенесённых локальных ролей
    /// </summary>
    public int LocalRolesMigrated { get; set; }
    
    /// <summary>
    /// Количество перенесённых service account ролей
    /// </summary>
    public int ServiceRolesMigrated { get; set; }
    
    /// <summary>
    /// Количество перенесённых mappers
    /// </summary>
    public int MappersMigrated { get; set; }
    
    /// <summary>
    /// Warnings при переносе
    /// </summary>
    public List<string> Warnings { get; set; } = new();
    
    /// <summary>
    /// Ошибки при переносе
    /// </summary>
    public List<string> Errors { get; set; } = new();
    
    /// <summary>
    /// Redirect URIs клиента
    /// </summary>
    public List<string> RedirectUris { get; set; } = new();
    
    /// <summary>
    /// Ссылка на Wiki страницу
    /// </summary>
    public string? WikiPageUrl { get; set; }
    
    /// <summary>
    /// Путь к архиву с credentials
    /// </summary>
    public string? ArchivePath { get; set; }
}

