namespace new_assistant.Core.DTOs;

/// <summary>
/// Информация о роли пользователя в конкретном реалме
/// </summary>
public record UserRoleInfo
{
    /// <summary>
    /// Название роли (например, kc-ga-users-management-api.block.user)
    /// </summary>
    public string RoleName { get; init; } = string.Empty;
    
    /// <summary>
    /// Реалм, в котором найдена роль (например, internal-dom-idm)
    /// </summary>
    public string Realm { get; init; } = string.Empty;
}

