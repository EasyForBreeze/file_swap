using System;
using System.Collections.Generic;

namespace new_assistant.Core.DTOs;

/// <summary>
/// Данные для создания клиента из UI
/// </summary>
public class ClientCreationData
{
    public string Realm { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool ClientAuthentication { get; set; }
    public bool StandardFlow { get; set; }
    public bool ServiceAccount { get; set; }
    public List<string> LocalRoles { get; set; } = new();
    public List<string> RedirectUris { get; set; } = new();
    public string OwnerSystemName { get; set; } = string.Empty;
    public string OwnerSystemUrl { get; set; } = string.Empty;
    public string OwnerName { get; set; } = string.Empty;
    public string? SupportManager { get; set; }
    public string? PublicationStatus { get; set; }
    
    // Дополнительные поля для администраторов (шаг 6)
    public string? TicketNumber { get; set; }
    public string? NotificationEmail { get; set; }
    public string? TicketUrl { get; set; }
}
