namespace new_assistant.Core.DTOs;

/// <summary>
/// Статистика использования кеша токенов.
/// </summary>
public class TokenCacheStatistics
{
    private long _cacheHits;
    private long _cacheMisses;
    private long? _totalRequests;
    private double? _cacheHitRate;
    
    /// <summary>
    /// Количество попаданий в кеш (токен был найден в кеше и использован).
    /// </summary>
    public long CacheHits 
    { 
        get => _cacheHits;
        set
        {
            if (_cacheHits != value)
            {
                _cacheHits = value;
                InvalidateCache();
            }
        }
    }
    
    /// <summary>
    /// Количество промахов кеша (токен не был найден в кеше и был запрошен заново).
    /// </summary>
    public long CacheMisses 
    { 
        get => _cacheMisses;
        set
        {
            if (_cacheMisses != value)
            {
                _cacheMisses = value;
                InvalidateCache();
            }
        }
    }
    
    /// <summary>
    /// Общее количество попыток получения токена.
    /// </summary>
    public long TotalRequests
    {
        get
        {
            if (_totalRequests.HasValue)
                return _totalRequests.Value;
            
            _totalRequests = CacheHits + CacheMisses;
            return _totalRequests.Value;
        }
    }
    
    /// <summary>
    /// Процент попаданий в кеш (0-100).
    /// </summary>
    public double CacheHitRate
    {
        get
        {
            if (_cacheHitRate.HasValue)
                return _cacheHitRate.Value;
            
            var total = TotalRequests;
            _cacheHitRate = total > 0 ? (double)CacheHits / total * 100 : 0;
            return _cacheHitRate.Value;
        }
    }
    
    /// <summary>
    /// Сбрасывает кэшированные значения при изменении базовых свойств.
    /// </summary>
    private void InvalidateCache()
    {
        _totalRequests = null;
        _cacheHitRate = null;
    }
}

