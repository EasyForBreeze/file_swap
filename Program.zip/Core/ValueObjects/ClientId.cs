using System;
using System.Text.RegularExpressions;

namespace new_assistant.Core.ValueObjects;

/// <summary>
/// Value Object для идентификатора клиента
/// </summary>
public readonly record struct ClientId
{
    private static readonly Regex ClientIdPattern = new(@"^app-[a-z0-9-]+$", RegexOptions.Compiled | RegexOptions.IgnoreCase);
    private const int MaxLength = 200;
    
    public string Value { get; }

    private ClientId(string value)
    {
        Value = value;
    }

    /// <summary>
    /// Создает ClientId из строки с валидацией
    /// </summary>
    /// <param name="value">Значение идентификатора клиента</param>
    /// <returns>ClientId если значение валидно</returns>
    /// <exception cref="ArgumentException">Если значение невалидно</exception>
    public static ClientId Parse(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(value));

        if (value.Length > MaxLength)
            throw new ArgumentException($"Client ID cannot be longer than {MaxLength} characters", nameof(value));

        if (!ClientIdPattern.IsMatch(value))
            throw new ArgumentException($"Client ID must match pattern: {ClientIdPattern}", nameof(value));

        return new ClientId(value);
    }

    /// <summary>
    /// Пытается создать ClientId из строки
    /// </summary>
    /// <param name="value">Значение идентификатора клиента</param>
    /// <param name="clientId">Результат, если успешно</param>
    /// <returns>true если успешно, false если невалидно</returns>
    public static bool TryParse(string? value, out ClientId clientId)
    {
        clientId = default;
        
        if (string.IsNullOrWhiteSpace(value))
            return false;

        if (value.Length > MaxLength)
            return false;

        if (!ClientIdPattern.IsMatch(value))
            return false;

        clientId = new ClientId(value);
        return true;
    }

    /// <summary>
    /// Неявное преобразование в string для обратной совместимости
    /// </summary>
    public static implicit operator string(ClientId clientId) => clientId.Value;

    /// <summary>
    /// Явное преобразование из string (использует Parse)
    /// </summary>
    public static explicit operator ClientId(string value) => Parse(value);

    public override string ToString() => Value;
}

