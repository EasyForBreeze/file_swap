namespace new_assistant.Core.Interfaces;

/// <summary>
/// Сервис для форматирования типов событий аудита
/// </summary>
public interface IEventFormatterService
{
    /// <summary>
    /// Получает отображаемое название типа события
    /// </summary>
    /// <param name="eventType">Тип события</param>
    /// <returns>Отображаемое название</returns>
    string GetEventTypeDisplay(string eventType);

    /// <summary>
    /// Получает CSS класс для badge типа события
    /// </summary>
    /// <param name="eventType">Тип события</param>
    /// <returns>CSS класс для badge</returns>
    string GetEventTypeBadgeClass(string eventType);
}

