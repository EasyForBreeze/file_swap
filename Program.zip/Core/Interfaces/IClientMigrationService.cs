using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс сервиса для переноса клиентов из TEST в STAGE
/// </summary>
public interface IClientMigrationService
{
    /// <summary>
    /// Валидировать возможность переноса клиента
    /// </summary>
    Task<MigrationValidationResult> ValidateMigrationAsync(ClientMigrationRequest request, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Выполнить перенос клиента из TEST в STAGE
    /// </summary>
    Task<ClientMigrationResult> MigrateClientAsync(ClientMigrationRequest request, string migratedBy, CancellationToken cancellationToken = default);
}

