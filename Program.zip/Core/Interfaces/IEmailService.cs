namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для отправки email уведомлений
/// </summary>
public interface IEmailService
{
    /// <summary>
    /// Отправляет заявку на получение доступа
    /// </summary>
    Task<bool> SendAccessRequestAsync(string username, string adminEmail);

    /// <summary>
    /// Отправляет учетные данные клиента (пароль от архива) на указанный email
    /// </summary>
    Task<bool> SendClientCredentialsEmailAsync(
        string recipientEmail, 
        string clientId, 
        string realm, 
        string archivePassword,
        string? ticketNumber = null,
        string? ticketUrl = null,
        string? wikiPageUrl = null,
        string environment = "TEST",
        string? baseUrl = null,
        string? endpointsUrl = null,
        string? creatioUrl = null);

    /// <summary>
    /// Тестирует SMTP соединение
    /// </summary>
    Task<bool> TestSmtpConnectionAsync();
}

