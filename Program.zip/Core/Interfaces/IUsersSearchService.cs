using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для сервиса поиска пользователей через users-management API
/// </summary>
public interface IUsersSearchService
{
    /// <summary>
    /// Поиск пользователей в указанном реалме по username, имени, фамилии или email
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса</param>
    /// <param name="realm">Название реалма для поиска пользователей</param>
    /// <param name="searchTerm">Поисковый запрос (username, имя, фамилия или email). Если null или пустой, возвращаются все пользователи с учетом пагинации</param>
    /// <param name="exact">Если true, выполняется точный поиск. По умолчанию false</param>
    /// <param name="first">Индекс первого результата для пагинации (0-based). По умолчанию 0</param>
    /// <param name="max">Максимальное количество результатов. По умолчанию 100</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список найденных пользователей (только для чтения)</returns>
    Task<IReadOnlyList<UserSearchResultDto>> SearchUsersAsync(
        string accessToken,
        string realm,
        string? searchTerm = null,
        bool exact = false,
        int first = 0,
        int max = 100,
        CancellationToken cancellationToken = default);
}

