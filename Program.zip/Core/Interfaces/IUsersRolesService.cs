using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для сервиса управления ролями пользователей через users-management API
/// </summary>
public interface IUsersRolesService
{
    /// <summary>
    /// Удалить realm роли у пользователя
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="roles">Список realm ролей для удаления</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>true, если удаление выполнено успешно, иначе false</returns>
    Task<bool> RemoveRealmRolesAsync(
        string accessToken,
        string realm,
        string userId,
        List<UserRealmRoleDto> roles,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Удалить client роль у пользователя
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="clientId">ID клиента</param>
    /// <param name="role">Client роль для удаления</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>true, если удаление выполнено успешно, иначе false</returns>
    Task<bool> RemoveClientRoleAsync(
        string accessToken,
        string realm,
        string userId,
        string clientId,
        UserClientRoleDto role,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Добавить realm роли пользователю
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="roles">Список realm ролей для добавления</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>true, если добавление выполнено успешно, иначе false</returns>
    Task<bool> AddRealmRolesAsync(
        string accessToken,
        string realm,
        string userId,
        List<UserRealmRoleDto> roles,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Добавить client роль пользователю
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="clientId">ID клиента</param>
    /// <param name="role">Client роль для добавления</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>true, если добавление выполнено успешно, иначе false</returns>
    Task<bool> AddClientRoleAsync(
        string accessToken,
        string realm,
        string userId,
        string clientId,
        UserClientRoleDto role,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
}

