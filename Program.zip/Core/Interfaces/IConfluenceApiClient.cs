namespace new_assistant.Core.Interfaces;

/// <summary>
/// Клиент для работы с Confluence API
/// </summary>
public interface IConfluenceApiClient
{
    /// <summary>
    /// Создать страницу в Confluence
    /// </summary>
    Task<ConfluencePageResponse?> CreatePageAsync(
        string title,
        string content,
        string spaceKey,
        string parentPageId,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Получить страницу из Confluence
    /// </summary>
    Task<ConfluencePageResponse?> GetPageAsync(
        string pageId,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Обновить страницу в Confluence
    /// </summary>
    Task<ConfluencePageResponse?> UpdatePageAsync(
        string pageId,
        string title,
        string content,
        int expectedVersion,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Добавить метки к странице
    /// </summary>
    Task<bool> AddLabelsAsync(
        string pageId,
        List<string> labels,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Проверить доступность API
    /// </summary>
    Task<bool> IsAvailableAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Найти страницу по space key и title
    /// </summary>
    Task<(string Id, string Title, string Url, int Version)?> ResolvePageAsync(
        string spaceKey,
        string title,
        CancellationToken cancellationToken = default);
}

/// <summary>
/// Ответ от Confluence API с информацией о странице
/// </summary>
public class ConfluencePageResponse
{
    public string Id { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public int Version { get; set; }
    public string Url { get; set; } = string.Empty;
    public string Body { get; set; } = string.Empty;
}

