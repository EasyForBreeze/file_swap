namespace new_assistant.Core.Interfaces;

/// <summary>
/// Сервис для управления владением клиентами
/// </summary>
public interface IClientOwnershipService
{
    /// <summary>
    /// Проверить, является ли пользователь владельцем клиента
    /// </summary>
    Task<bool> IsOwnerAsync(string username, string clientId, string realm);
    
    /// <summary>
    /// Предоставить владение клиентом пользователю
    /// </summary>
    Task GrantOwnershipAsync(string username, string clientId, string realm);
    
    /// <summary>
    /// Отозвать владение клиентом у пользователя
    /// </summary>
    Task RevokeOwnershipAsync(string username, string clientId, string realm);
    
    /// <summary>
    /// Получить список клиентов пользователя
    /// </summary>
    Task<List<string>> GetUserClientsAsync(string username, string realm);
    
    /// <summary>
    /// Получить владельца клиента
    /// </summary>
    Task<string?> GetClientOwnerAsync(string clientId, string realm);
    
    /// <summary>
    /// Передать владение клиентом другому пользователю
    /// </summary>
    Task TransferOwnershipAsync(string fromUsername, string toUsername, string clientId, string realm);
    
    /// <summary>
    /// Получить все клиенты пользователя во всех реалмах (с информацией о реалме)
    /// </summary>
    Task<List<UserClientInfo>> GetAllUserClientsAsync(string username);
    
    /// <summary>
    /// Предоставить доступ (alias для GrantOwnershipAsync для совместимости с API)
    /// </summary>
    Task GrantAccessAsync(string username, string clientId, string realm);
    
    /// <summary>
    /// Отозвать доступ (alias для RevokeOwnershipAsync для совместимости с API)
    /// </summary>
    Task RevokeAccessAsync(string username, string clientId, string realm);
    
    /// <summary>
    /// Предоставить доступ с логированием аудита (для использования администраторами)
    /// </summary>
    Task GrantAccessWithAuditAsync(string adminUsername, string targetUsername, string clientId, string realm);
    
    /// <summary>
    /// Отозвать доступ с логированием аудита (для использования администраторами)
    /// </summary>
    Task RevokeAccessWithAuditAsync(string adminUsername, string targetUsername, string clientId, string realm);
    
    /// <summary>
    /// Удалить все записи владения для клиента (при удалении клиента)
    /// </summary>
    Task RemoveAllClientOwnershipsAsync(string clientId, string realm);
    
    /// <summary>
    /// Проверить, есть ли владельцы у клиента
    /// </summary>
    Task<bool> HasOwnersAsync(string clientId, string realm);
    
    /// <summary>
    /// Получить всех владельцев клиента
    /// </summary>
    Task<List<string>> GetClientOwnersAsync(string clientId, string realm);
    
    /// <summary>
    /// Массовое предоставление владения
    /// </summary>
    Task GrantOwnershipBatchAsync(string username, IEnumerable<string> clientIds, string realm);
    
    /// <summary>
    /// Массовый отзыв владения
    /// </summary>
    Task RevokeOwnershipBatchAsync(string username, IEnumerable<string> clientIds, string realm);
}

/// <summary>
/// Информация о клиенте пользователя с указанием реалма
/// </summary>
public class UserClientInfo
{
    public string ClientId { get; set; } = string.Empty;
    public string Realm { get; set; } = string.Empty;
    public DateTime GrantedAt { get; set; }
}
