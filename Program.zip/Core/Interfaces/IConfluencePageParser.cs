namespace new_assistant.Core.Interfaces;

/// <summary>
/// Парсер для извлечения данных из HTML/XML страниц Confluence
/// </summary>
public interface IConfluencePageParser
{
    /// <summary>
    /// Извлечь локальные роли с контурами из HTML
    /// </summary>
    Dictionary<string, string> ExtractLocalRoles(string html);

    /// <summary>
    /// Извлечь service роли с контурами из HTML
    /// </summary>
    Dictionary<string, string> ExtractServiceRoles(string html);

    /// <summary>
    /// Извлечь значение поля из HTML
    /// </summary>
    string ExtractField(string html, string fieldName);

    /// <summary>
    /// Извлечь ссылку из HTML
    /// </summary>
    string ExtractLink(string html, string fieldName);

    /// <summary>
    /// Извлечь значение поля из XML структуры
    /// </summary>
    string ExtractFieldFromXml(string xmlContent, string fieldName);
}

