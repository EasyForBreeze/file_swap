using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для поиска клиентов Keycloak
/// </summary>
public interface IKeycloakClientSearchService
{
    /// <summary>
    /// Поиск клиентов с отслеживанием прогресса
    /// </summary>
    Task<ClientsSearchResponse> SearchClientsWithProgressAsync(
        string searchTerm, 
        IProgress<SearchProgress> progress, 
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Простой поиск клиентов без прогресса
    /// </summary>
    Task<ClientsSearchResponse> SearchClientsAsync(
        string searchTerm, 
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Поиск клиентов по Client ID (с опциональной фильтрацией по realm)
    /// </summary>
    Task<List<ClientSearchResult>> SearchClientsByIdAsync(string searchTerm, string? realm = null, CancellationToken cancellationToken = default);
}

