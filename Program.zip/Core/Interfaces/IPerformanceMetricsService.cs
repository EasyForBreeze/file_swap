namespace new_assistant.Core.Interfaces;

/// <summary>
/// Сервис для сбора метрик производительности
/// </summary>
public interface IPerformanceMetricsService
{
    /// <summary>
    /// Записать метрику времени выполнения операции
    /// </summary>
    void RecordOperationTime(string operationName, long elapsedMilliseconds);
    
    /// <summary>
    /// Записать метрику успешной операции
    /// </summary>
    void RecordSuccess(string operationName);
    
    /// <summary>
    /// Записать метрику ошибки
    /// </summary>
    void RecordError(string operationName, string errorType);
    
    /// <summary>
    /// Получить статистику по операции
    /// </summary>
    OperationMetrics GetMetrics(string operationName);
    
    /// <summary>
    /// Получить все метрики
    /// </summary>
    Dictionary<string, OperationMetrics> GetAllMetrics();
    
    /// <summary>
    /// Сбросить метрики
    /// </summary>
    void Reset();
}

/// <summary>
/// Метрики операции
/// </summary>
public class OperationMetrics
{
    public string OperationName { get; set; } = string.Empty;
    public long TotalCalls { get; set; }
    public long SuccessfulCalls { get; set; }
    public long FailedCalls { get; set; }
    public long TotalTimeMs { get; set; }
    public long MinTimeMs { get; set; } = long.MaxValue;
    public long MaxTimeMs { get; set; }
    public double AverageTimeMs => TotalCalls > 0 ? (double)TotalTimeMs / TotalCalls : 0;
    public double SuccessRate => TotalCalls > 0 ? (double)SuccessfulCalls / TotalCalls * 100 : 0;
    public Dictionary<string, int> ErrorCounts { get; set; } = new();
}

