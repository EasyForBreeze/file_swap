using System;
using System.Collections.Generic;

namespace new_assistant.Configuration;

/// <summary>
/// Настройки rate limiting для защиты от брутфорса и DDoS атак.
/// </summary>
public sealed class RateLimitingSettings
{
    /// <summary>
    /// Максимальное количество запросов в минуту для аутентификации.
    /// Должно быть в диапазоне от 1 до 1000.
    /// </summary>
    public int AuthRequestsPerMinute { get; init; } = 10;

    /// <summary>
    /// Максимальное количество API запросов в минуту для обычных пользователей.
    /// Должно быть в диапазоне от 1 до 10000.
    /// </summary>
    public int ApiRequestsPerMinute { get; init; } = 100;

    /// <summary>
    /// Максимальное количество API запросов в минуту для администраторов.
    /// Должно быть в диапазоне от 1 до 100000.
    /// </summary>
    public int AdminApiRequestsPerMinute { get; init; } = 500;

    /// <summary>
    /// Время блокировки в минутах при превышении лимитов.
    /// Должно быть в диапазоне от 0 до 1440 (24 часа).
    /// Значение 0 означает отсутствие блокировки (только отклонение запросов).
    /// </summary>
    public int BlockDurationMinutes { get; init; } = 15;

    /// <summary>
    /// Включить rate limiting.
    /// </summary>
    public bool Enabled { get; init; } = true;

    /// <summary>
    /// Количество сегментов для SlidingWindow limiter.
    /// Больше сегментов = более точный контроль, но выше нагрузка на память.
    /// Рекомендуемое значение: 6 (сегмент = 10 секунд при окне 1 минута).
    /// </summary>
    public int SegmentsPerWindow { get; init; } = 6;

    /// <summary>
    /// IP адреса, которые исключены из rate limiting (белый список).
    /// Полезно для внутренних сервисов, мониторинга и emergency доступа.
    /// Используется HashSet для эффективного поиска O(1).
    /// </summary>
    public HashSet<string> BypassIpAddresses { get; init; } = new();

    /// <summary>
    /// Имена пользователей, которые исключены из rate limiting (белый список).
    /// Полезно для администраторов и системных пользователей.
    /// Используется HashSet для эффективного поиска O(1).
    /// </summary>
    public HashSet<string> BypassUserNames { get; init; } = new();

    /// <summary>
    /// Сообщение об ошибке при превышении лимита запросов.
    /// Если не указано, используется сообщение по умолчанию на английском языке.
    /// </summary>
    public string? ErrorMessage { get; init; }

    /// <summary>
    /// Время ожидания в секундах перед повторной попыткой (для заголовка Retry-After).
    /// Если не указано, используется значение по умолчанию: 60 секунд.
    /// </summary>
    public int RetryAfterSeconds { get; init; } = 60;
}
