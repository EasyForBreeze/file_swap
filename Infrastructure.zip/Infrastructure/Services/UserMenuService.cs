using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.Constants;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для определения доступных пунктов меню пользователя на основе его ролей
/// Получает роли из всех реалмов через token exchange (роли извлекаются из JWT токена)
/// </summary>
public class UserMenuService : IUserMenuService, IDisposable, IAsyncDisposable
{
    private readonly ILogger<UserMenuService> _logger;
    private readonly ITokenExchangeService _tokenExchangeService;
    private readonly TokenExchangeSettings _tokenExchangeSettings;
    private readonly IMemoryCache _cache;
    
    // Константы для названий ролей
    private const string BLOCK_USER = "kc-ga-users-management-api.block.user";
    private const string UNBLOCK_USER = "kc-ga-users-management-api.unblock.user";
    private const string ADD_REALM_ROLES = "kc-ga-users-management-api.add.realm.roles.to.user";
    private const string ADD_CLIENT_ROLES = "kc-ga-users-management-api.add.client.roles.to.user";
    private const string DELETE_REALM_ROLES = "kc-ga-users-management-api.delete.realm.roles.from.user";
    private const string DELETE_CLIENT_ROLES = "kc-ga-users-management-api.delete.client.roles.from.user";
    private const string ADD_USER = "kc-ga-users-management-api.add.user";
    private const string GET_USER_CERTIFICATE = "kc-ga-users-management-api.get.user.certificate";
    private const string ADD_USER_CERTIFICATE = "kc-ga-users-management-api.add.user.certificate";
    private const string UPDATE_USER = "kc-ga-users-management-api.update.user";
    private const string GET_USER = "kc-ga-users-management-api.get.user";
    private const string SEARCH_USERS = "kc-ga-users-management-api.search.users";
    private const string SEND_MAIL = "kc-ga-users-management-api.send.mail.to.user";
    private const string DELETE_CREDENTIALS = "kc-ga-users-management-api.delete.user.credentials";
    
    // Название клиента для поиска ролей
    // Используем константу Claims.UsersManagementApiClient вместо локальной константы
    
        // TTL для кэша ролей пользователя (10 минут - оптимизировано для баланса производительности и актуальности)
    private static readonly TimeSpan CacheTtl = TimeSpan.FromMinutes(10);
    
    // Проверка валидности CacheTtl
    private static void ValidateCacheTtl()
    {
        if (CacheTtl <= TimeSpan.Zero)
        {
            throw new InvalidOperationException($"CacheTtl must be greater than zero, but was {CacheTtl}");
        }
    }
    
    // Максимальное количество параллельных запросов к реалмам
    private const int MaxConcurrentRealmRequests = 5;
    
    // Проверка валидности MaxConcurrentRealmRequests
    private static void ValidateMaxConcurrentRealmRequests()
    {
        if (MaxConcurrentRealmRequests <= 0)
        {
            throw new InvalidOperationException($"MaxConcurrentRealmRequests must be greater than zero, but was {MaxConcurrentRealmRequests}");
        }
    }
    
    // Таймаут для запроса к одному реалму (секунды)
    private const int RealmRequestTimeoutSeconds = 10;
    
    // Защита от параллельных запросов для одного пользователя
    // Используем SemaphoreInfo для отслеживания времени последнего использования
    private readonly ConcurrentDictionary<string, SemaphoreInfo> _userRolesLocks = new();
    private int _disposed = 0; // 0 = false, 1 = true, используем Interlocked для атомарности
    private readonly object _disposeLock = new object();
    private readonly Timer? _cleanupTimer;
    
    // Интервал очистки неиспользуемых семафоров (30 минут)
    private static readonly TimeSpan CleanupInterval = TimeSpan.FromMinutes(30);
    
    // Максимальное время простоя семафора перед удалением (30 минут)
    private static readonly TimeSpan SemaphoreMaxIdleTime = TimeSpan.FromMinutes(30);
    
    // Таймаут для очистки семафоров (5 секунд)
    private static readonly TimeSpan CleanupTimeout = TimeSpan.FromSeconds(5);
    
    // Кэш списка реалмов для оптимизации
    private readonly Lazy<List<string>> _cachedRealms;
    
    // Кэш настроек реалмов для оптимизации
    private readonly Lazy<Dictionary<string, TokenExchangeRealmSettings>> _cachedRealmSettings;
    
    // Кэшируем SHA256 для оптимизации производительности (ThreadLocal для потокобезопасности)
    private readonly ThreadLocal<SHA256> _sha256 = new(() => SHA256.Create(), true);
    
    // Кэшируем JsonSerializerOptions для оптимизации
    private static readonly JsonSerializerOptions _jsonOptions = new JsonSerializerOptions
    {
        PropertyNameCaseInsensitive = false
    };
    
    // Максимальная длина username для валидации
    private const int MaxUsernameLength = 500;
    
    // Максимальная длина accessToken для валидации
    private const int MaxAccessTokenLength = 50000;
    
    /// <summary>
    /// Информация о семафоре с отслеживанием времени последнего использования
    /// </summary>
    private sealed class SemaphoreInfo
    {
        public SemaphoreSlim Semaphore { get; }
        public DateTime LastUsed { get; set; }
        
        public SemaphoreInfo()
        {
            Semaphore = new SemaphoreSlim(1, 1);
            LastUsed = DateTime.UtcNow;
        }
    }
    
    public UserMenuService(
        ILogger<UserMenuService> logger,
        ITokenExchangeService tokenExchangeService,
        IOptions<TokenExchangeSettings> tokenExchangeSettings,
        IMemoryCache cache)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _tokenExchangeService = tokenExchangeService ?? throw new ArgumentNullException(nameof(tokenExchangeService));
        _tokenExchangeSettings = tokenExchangeSettings?.Value ?? throw new ArgumentNullException(nameof(tokenExchangeSettings));
        _cache = cache ?? throw new ArgumentNullException(nameof(cache));
        
        if (_tokenExchangeSettings.Realms == null || _tokenExchangeSettings.Realms.Count == 0)
        {
            _logger.LogWarning("Список реалмов в TokenExchangeSettings пуст");
        }
        
        // Проверяем, что константа UsersManagementApiClient определена
        if (string.IsNullOrWhiteSpace(Claims.UsersManagementApiClient))
        {
            throw new InvalidOperationException("Константа Claims.UsersManagementApiClient не определена или пуста");
        }
        
        // Валидация констант
        ValidateCacheTtl();
        ValidateMaxConcurrentRealmRequests();
        
        // Инициализируем кэш списка реалмов
        _cachedRealms = new Lazy<List<string>>(() =>
        {
            if (_tokenExchangeSettings.Realms == null)
            {
                return new List<string>();
            }
            
            return _tokenExchangeSettings.Realms
                .Select(r => r.Realm)
                .Where(r => !string.IsNullOrWhiteSpace(r))
                .Distinct()
                .ToList();
        });
        
        // Инициализируем кэш настроек реалмов для оптимизации
        _cachedRealmSettings = new Lazy<Dictionary<string, TokenExchangeRealmSettings>>(() =>
        {
            if (_tokenExchangeSettings.Realms == null)
            {
                return new Dictionary<string, TokenExchangeRealmSettings>();
            }
            
            return _tokenExchangeSettings.Realms
                .Where(r => !string.IsNullOrWhiteSpace(r.Realm))
                .GroupBy(r => r.Realm)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
        });
        
        // Запускаем периодическую очистку неиспользуемых семафоров для предотвращения утечки памяти
        _cleanupTimer = new Timer(CleanupUnusedSemaphores, null, CleanupInterval, CleanupInterval);
    }
    
    /// <summary>
    /// Получить список реалмов из настроек (кэшируется)
    /// </summary>
    private List<string> GetRealms()
    {
        return _cachedRealms.Value;
    }
    
    /// <summary>
    /// Создать безопасный ключ кэша для username
    /// </summary>
    private string CreateCacheKey(string username)
    {
        if (string.IsNullOrWhiteSpace(username))
        {
            // Возвращаем специальный ключ для пустых имен вместо исключения
            return "user-roles:anonymous";
        }
        
        // Валидация длины username
        if (username.Length > MaxUsernameLength)
        {
            throw new ArgumentException($"Username exceeds maximum length of {MaxUsernameLength} characters", nameof(username));
        }
        
        // Нормализуем username (trim и lowercase для консистентности)
        var normalizedUsername = username.Trim().ToLowerInvariant();
        
        // Максимальная длина для username в кэш-ключе (после нормализации может быть короче)
        const int MaxCacheKeyLength = 255;
        
        // Защита от слишком длинных имен - используем хэш
        if (normalizedUsername.Length > MaxCacheKeyLength)
        {
            // Используем ThreadLocal SHA256 для потокобезопасности
            // Если ThreadLocal не инициализирован (например, при Dispose), создаем временный экземпляр
            SHA256? sha256 = null;
            bool shouldDispose = false;
            try
            {
                sha256 = _sha256?.Value;
                if (sha256 == null)
                {
                    sha256 = SHA256.Create();
                    shouldDispose = true;
                }
                var hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(normalizedUsername));
                normalizedUsername = Convert.ToBase64String(hash);
            }
            finally
            {
                if (shouldDispose)
                {
                    sha256?.Dispose();
                }
            }
        }
        
        return $"user-roles:{normalizedUsername}";
    }
    
    /// <summary>
    /// Очистка неиспользуемых семафоров для предотвращения утечки памяти
    /// </summary>
    private void CleanupUnusedSemaphores(object? state)
    {
        // Быстрая проверка для раннего выхода
        if (IsDisposed)
            return;
        
        try
        {
            // Используем таймаут для предотвращения длительной блокировки
            using var cleanupCts = new CancellationTokenSource(CleanupTimeout);
            var cancellationToken = cleanupCts.Token;
            
            // Дополнительная проверка внутри try-catch для безопасности
            if (IsDisposed)
                return;
            
            var cutoffTime = DateTime.UtcNow - SemaphoreMaxIdleTime;
            var keysToRemove = new List<string>();
            
            // Оптимизируем создание snapshot - используем более эффективный подход
            // Создаем снимок ключей для безопасной итерации только один раз
            string[] keysSnapshot;
            try
            {
                keysSnapshot = _userRolesLocks.Keys.ToArray();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Ошибка при создании snapshot ключей для очистки");
                return;
            }
            
            foreach (var key in keysSnapshot)
            {
                if (IsDisposed || cancellationToken.IsCancellationRequested)
                    return;
                
                if (!_userRolesLocks.TryGetValue(key, out var semaphoreInfo))
                    continue;
                
                try
                {
                    // Проверяем, что семафор не используется
                    // Используем атомарную проверку: пытаемся захватить семафор, если успешно - сразу отпускаем
                    // Если CurrentCount == 1 и LastUsed старый, можно безопасно удалить
                    var lastUsed = semaphoreInfo.LastUsed; // Атомарное чтение DateTime
                    if (lastUsed < cutoffTime)
                    {
                        // Проверяем CurrentCount внутри try-catch для безопасности
                        int currentCount;
                        try
                        {
                            currentCount = semaphoreInfo.Semaphore.CurrentCount;
                        }
                        catch (ObjectDisposedException)
                        {
                            // Семафор уже освобожден, добавляем в список на удаление
                            keysToRemove.Add(key);
                            continue;
                        }
                        
                        // Удаляем только если семафор не используется И не использовался давно
                        // CurrentCount == 1 означает, что никого не ждет
                        if (currentCount == 1)
                        {
                            keysToRemove.Add(key);
                        }
                    }
                }
                catch (ObjectDisposedException)
                {
                    // Семафор уже освобожден, добавляем в список на удаление
                    keysToRemove.Add(key);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Ошибка при проверке семафора для ключа {Key}", key);
                }
            }
            
            foreach (var key in keysToRemove)
            {
                if (IsDisposed || cancellationToken.IsCancellationRequested)
                    return;
                
                if (_userRolesLocks.TryRemove(key, out var semaphoreInfo))
                {
                    try
                    {
                        semaphoreInfo.Semaphore?.Dispose();
                        _logger.LogDebug("Освобожден неиспользуемый семафор для ключа {Key}", key);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Ошибка при освобождении семафора для ключа {Key}", key);
                    }
                }
            }
            
            if (keysToRemove.Count > 0)
            {
                _logger.LogDebug("Очищено {Count} неиспользуемых семафоров", keysToRemove.Count);
            }
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("Очистка неиспользуемых семафоров была прервана по таймауту");
        }
        catch (ObjectDisposedException)
        {
            // Игнорируем, если объект уже освобожден
            return;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при очистке неиспользуемых семафоров");
        }
    }
    
    /// <summary>
    /// Проверка, не был ли объект освобожден
    /// </summary>
    private void ThrowIfDisposed()
    {
        if (Interlocked.CompareExchange(ref _disposed, 0, 0) != 0)
            throw new ObjectDisposedException(nameof(UserMenuService));
    }
    
    /// <summary>
    /// Проверка, не был ли объект освобожден (без исключения, для проверок в критических секциях)
    /// </summary>
    private bool IsDisposed => Interlocked.CompareExchange(ref _disposed, 0, 0) != 0;
    
    /// <summary>
    /// Получить разрешения пользователя для отображения пунктов меню
    /// </summary>
    public async Task<UserMenuPermissions> GetUserMenuPermissionsAsync(ClaimsPrincipal user, CancellationToken cancellationToken = default)
    {
        // Проверка disposed без lock (легковесная проверка перед началом работы)
        if (IsDisposed)
        {
            throw new ObjectDisposedException(nameof(UserMenuService));
        }
        
        if (user?.Identity?.IsAuthenticated != true)
        {
            return new UserMenuPermissions();
        }
        
        // Получаем username из токена
        var username = user.FindFirst("preferred_username")?.Value;
        
        if (string.IsNullOrEmpty(username))
        {
            _logger.LogWarning("Не удалось получить preferred_username из токена пользователя");
            return new UserMenuPermissions();
        }
        
        // Получаем роли пользователя из всех реалмов
        var userRoles = await GetUserRolesFromAllRealmsAsync(username, cancellationToken).ConfigureAwait(false);
        
        // Оптимизируем создание HashSet - используем предварительно оцененный размер
        var estimatedRoleCount = Math.Max(userRoles.Count, 10);
        var roleNames = new HashSet<string>(estimatedRoleCount, StringComparer.OrdinalIgnoreCase);
        foreach (var role in userRoles)
        {
            roleNames.Add(role.RoleName);
        }
        
        // Оптимизируем Distinct для реалмов - используем HashSet напрямую
        var availableRealms = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var role in userRoles)
        {
            availableRealms.Add(role.Realm);
        }
        
        var permissions = new UserMenuPermissions
        {
            UserRoles = userRoles,
            AvailableRealms = availableRealms.ToList(),
            
            // а) Блокировка/разблокировка пользователя
            CanBlockUnblockUser = roleNames.Contains(BLOCK_USER) || roleNames.Contains(UNBLOCK_USER),
            
            // б) Роли клиента/реалма
            CanManageUserRoles = roleNames.Contains(ADD_REALM_ROLES) ||
                                roleNames.Contains(ADD_CLIENT_ROLES) ||
                                roleNames.Contains(DELETE_REALM_ROLES) ||
                                roleNames.Contains(DELETE_CLIENT_ROLES),
            
            // в) Добавление пользователя
            CanAddUser = roleNames.Contains(ADD_USER),
            
            // г) Сертификат пользователя
            CanManageUserCertificate = roleNames.Contains(GET_USER_CERTIFICATE) ||
                                      roleNames.Contains(ADD_USER_CERTIFICATE),
            
            // д) Обновление информации пользователя
            CanUpdateUser = roleNames.Contains(UPDATE_USER),
            
            // е) Информация о пользователе
            CanGetUserInfo = roleNames.Contains(GET_USER),
            
            // з) Поиск пользователей
            CanSearchUsers = roleNames.Contains(SEARCH_USERS),
            
            // ж) Сброс пароля (требуется И send.mail И delete.credentials)
            CanResetUserPassword = roleNames.Contains(SEND_MAIL) && roleNames.Contains(DELETE_CREDENTIALS)
        };
        
        return permissions;
    }
    
    /// <summary>
    /// Получить роли пользователя из реалмов, указанных в token-exchange.json
    /// </summary>
    public async Task<List<UserRoleInfo>> GetUserRolesFromAllRealmsAsync(string username, CancellationToken cancellationToken = default)
    {
        // Проверка disposed без lock (легковесная проверка перед началом работы)
        if (IsDisposed)
        {
            throw new ObjectDisposedException(nameof(UserMenuService));
        }
        
        if (string.IsNullOrEmpty(username))
        {
            return new List<UserRoleInfo>();
        }
        
        // Валидация длины username
        if (username.Length > MaxUsernameLength)
        {
            _logger.LogWarning("Username превышает максимальную длину {MaxLength}: {ActualLength}", MaxUsernameLength, username.Length);
            return new List<UserRoleInfo>();
        }
        
        // Проверяем кэш
        var cacheKey = CreateCacheKey(username);
        if (_cache.TryGetValue<List<UserRoleInfo>>(cacheKey, out var cachedRoles) && cachedRoles != null)
        {
            _logger.LogDebug("Роли пользователя {Username} получены из кэша ({Count} ролей)", username, cachedRoles.Count);
            return cachedRoles;
        }
        
        // Получаем или создаем семафор для защиты от параллельных запросов
        var semaphoreInfo = _userRolesLocks.GetOrAdd(cacheKey, _ => new SemaphoreInfo());
        var currentTime = DateTime.UtcNow; // Кэшируем время
        semaphoreInfo.LastUsed = currentTime; // Обновляем время последнего использования
        var semaphore = semaphoreInfo.Semaphore;
        
        await semaphore.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            // Проверка disposed после получения блокировки
            if (IsDisposed)
            {
                throw new ObjectDisposedException(nameof(UserMenuService));
            }
            
            // Повторная проверка кэша после получения блокировки (double-check pattern)
            if (_cache.TryGetValue<List<UserRoleInfo>>(cacheKey, out var cachedAfterLock) && cachedAfterLock != null)
            {
                _logger.LogDebug("Роли пользователя {Username} получены из кэша после блокировки ({Count} ролей)", username, cachedAfterLock.Count);
                return cachedAfterLock;
            }
        
            var allRoles = new List<UserRoleInfo>();
            
            // Получаем список реалмов из кэша
            var realms = GetRealms();
            
            _logger.LogInformation("Начинаем поиск пользователя {Username} в {Count} реалмах из token-exchange.json", username, realms.Count);
            
            if (realms.Count == 0)
            {
                _logger.LogWarning("Список реалмов в token-exchange.json пуст!");
                return new List<UserRoleInfo>();
            }
            
            // Ограничиваем параллелизм для предотвращения перегрузки
            using var semaphoreSlim = new SemaphoreSlim(MaxConcurrentRealmRequests, MaxConcurrentRealmRequests);
            
            // Параллельная обработка реалмов с ограничением параллелизма
            var tasks = realms.Select(async realm =>
            {
                await semaphoreSlim.WaitAsync(cancellationToken).ConfigureAwait(false);
                try
                {
                    // Таймаут для каждого реалма, чтобы медленные реалмы не блокировали всю загрузку
                    CancellationTokenSource? realmCts = null;
                    try
                    {
                        realmCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                        realmCts.CancelAfter(TimeSpan.FromSeconds(RealmRequestTimeoutSeconds));
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Ошибка при создании CancellationTokenSource для реалма {Realm}", realm);
                        return Enumerable.Empty<UserRoleInfo>();
                    }
                    
                    using (realmCts)
                    {
                        // Получаем настройки реалма из кэша
                        if (!_cachedRealmSettings.Value.TryGetValue(realm, out var realmSettings))
                        {
                            _logger.LogWarning("Настройки для реалма {Realm} не найдены в token-exchange.json", realm);
                            return Enumerable.Empty<UserRoleInfo>();
                        }
                        
                        // Получаем токен через token exchange
                        _logger.LogDebug("Получение токена через token exchange для реалма {Realm}", realm);
                        var tokenResult = await _tokenExchangeService.GetTokenForRealmAsync(realm, realmCts.Token).ConfigureAwait(false);
                        if (tokenResult == null)
                        {
                            _logger.LogWarning("TokenExchangeService вернул null для реалма {Realm}", realm);
                            return Enumerable.Empty<UserRoleInfo>();
                        }
                        
                        if (string.IsNullOrWhiteSpace(tokenResult.AccessToken))
                        {
                            _logger.LogWarning("AccessToken пуст для реалма {Realm}", realm);
                            return Enumerable.Empty<UserRoleInfo>();
                        }
                        
                        _logger.LogDebug("Токен успешно получен для реалма {Realm}", realm);
                        
                        // Извлекаем роли напрямую из токена (resource_access.users-management-api.roles)
                        var roles = ExtractRolesFromToken(tokenResult.AccessToken);
                        
                        if (roles.Count == 0)
                        {
                            _logger.LogInformation("У пользователя {Username} нет ролей клиента {ClientId} в токене реалма {Realm}", 
                                username, Claims.UsersManagementApiClient, realm);
                            return Enumerable.Empty<UserRoleInfo>();
                        }
                        
                        _logger.LogDebug("Найдено {Count} ролей для пользователя {Username} в реалме {Realm}", 
                            roles.Count, username, realm);
                        
                        // Логируем список ролей только на уровне Trace
                        _logger.LogTrace("Роли пользователя {Username} в реалме {Realm}: {Roles}", 
                            username, realm, string.Join(", ", roles.Where(r => !string.IsNullOrWhiteSpace(r))));
                        
                        // Возвращаем роли для этого реалма
                        return roles.Select(roleName => new UserRoleInfo
                        {
                            RoleName = roleName,
                            Realm = realm
                        });
                    }
                }
                catch (OperationCanceledException)
                {
                    _logger.LogWarning("Таймаут при получении ролей пользователя {Username} из реалма {Realm} (пропущен)", 
                        username, realm);
                    // Возвращаем пустой список для этого реалма
                    return Enumerable.Empty<UserRoleInfo>();
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Ошибка при получении ролей пользователя {Username} из реалма {Realm}", 
                        username, realm);
                    // Возвращаем пустой список для этого реалма
                    return Enumerable.Empty<UserRoleInfo>();
                }
                finally
                {
                    semaphoreSlim.Release();
                }
            });
            
            // Ждем завершения всех задач и объединяем результаты
            var results = await Task.WhenAll(tasks).ConfigureAwait(false);
            
            // Оптимизируем объединение результатов - используем предварительно оцененное количество
            var estimatedCapacity = realms.Count * 5; // Примерная оценка
            allRoles = new List<UserRoleInfo>(estimatedCapacity);
            foreach (var result in results)
            {
                allRoles.AddRange(result);
            }
            
            // Оптимизируем Distinct - используем HashSet для отслеживания уникальных реалмов
            var successfulRealms = new HashSet<string>(allRoles.Select(r => r.Realm), StringComparer.OrdinalIgnoreCase).Count;
            var totalRealms = realms.Count;
            
            _logger.LogInformation("Всего найдено {Count} ролей для пользователя {Username} в {SuccessfulRealms}/{TotalRealms} реалмах",
                allRoles.Count, username, successfulRealms, totalRealms);
            
            // Проверяем, если все реалмы не ответили
            if (successfulRealms == 0 && totalRealms > 0)
            {
                _logger.LogWarning("Не удалось получить роли пользователя {Username} ни из одного реалма. Проверьте подключение и настройки token-exchange.json", username);
            }
            else if (successfulRealms < totalRealms)
            {
                _logger.LogWarning("Не удалось получить роли пользователя {Username} из {FailedRealms} реалмов из {TotalRealms}",
                    username, totalRealms - successfulRealms, totalRealms);
            }
            
            // Сохраняем в кэш
            // Используем SetSize(1) для учета размера элемента в кэше
            // Каждая запись в кэше занимает 1 единицу из SizeLimit
            // ВАЖНО: Убедитесь, что IMemoryCache настроен с SizeLimit в DI контейнере:
            // services.AddMemoryCache(options => { options.SizeLimit = 1000; });
            try
            {
                var cacheOptions = new MemoryCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = CacheTtl,
                    Size = 1, // Каждая запись ролей пользователя занимает 1 единицу размера
                    Priority = CacheItemPriority.Normal
                };
                _cache.Set(cacheKey, allRoles, cacheOptions);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Ошибка при сохранении ролей пользователя {Username} в кэш", username);
                // Продолжаем выполнение, даже если кэш не удалось сохранить
            }
            
            return allRoles;
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("Операция получения ролей пользователя {Username} была отменена", username);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Критическая ошибка при получении ролей пользователя {Username}", username);
            return new List<UserRoleInfo>();
        }
        finally
        {
            // Всегда освобождаем семафор в finally
            try
            {
                semaphore.Release();
            }
            catch (ObjectDisposedException)
            {
                // Семафор уже освобожден, игнорируем
            }
            catch (SemaphoreFullException ex)
            {
                _logger.LogWarning(ex, "Попытка освободить семафор, который уже полностью освобожден для ключа {CacheKey}", cacheKey);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Неожиданная ошибка при освобождении семафора для ключа {CacheKey}", cacheKey);
            }
        }
    }
    
    /// <summary>
    /// Извлечь роли пользователя из JWT токена (resource_access.users-management-api.roles)
    /// </summary>
    private List<string> ExtractRolesFromToken(string accessToken)
    {
        if (string.IsNullOrWhiteSpace(accessToken))
        {
            return new List<string>();
        }
        
        // Валидация длины accessToken
        if (accessToken.Length > MaxAccessTokenLength)
        {
            _logger.LogWarning("AccessToken превышает максимальную длину {MaxLength}: {ActualLength}", MaxAccessTokenLength, accessToken.Length);
            return new List<string>();
        }

        try
        {
            // JWT токен состоит из 3 частей: header.payload.signature
            var parts = accessToken.Split('.');
            if (parts.Length != 3 || parts.Any(string.IsNullOrWhiteSpace))
            {
                _logger.LogWarning("Неверный формат JWT токена (ожидается 3 непустые части)");
                return new List<string>();
            }

            // Опциональная валидация header токена (проверка типа JWT)
            try
            {
                var headerBytes = DecodeBase64Url(parts[0]);
                var headerJson = Encoding.UTF8.GetString(headerBytes);
                var headerElement = JsonSerializer.Deserialize<JsonElement>(headerJson, _jsonOptions);
                
                if (headerElement.TryGetProperty("typ", out var typ))
                {
                    var typValue = typ.GetString();
                    if (!string.Equals(typValue, "JWT", StringComparison.OrdinalIgnoreCase))
                    {
                        _logger.LogWarning("JWT токен имеет неверный тип: {Type}", typValue);
                        // Продолжаем обработку, так как это не критично
                    }
                }
            }
            catch (FormatException)
            {
                // Игнорируем ошибки декодирования base64url в header
            }
            catch (JsonException)
            {
                // Игнорируем ошибки парсинга JSON в header
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Ошибка при валидации header токена, продолжаем обработку");
            }

            // Декодируем payload (вторая часть)
            byte[] payloadBytes;
            try
            {
                var payload = parts[1];
                payloadBytes = DecodeBase64Url(payload);
            }
            catch (FormatException ex)
            {
                _logger.LogWarning(ex, "Неверный формат base64url в payload токена");
                return new List<string>();
            }
            catch (ArgumentException ex)
            {
                _logger.LogWarning(ex, "Неверный аргумент при декодировании payload токена");
                return new List<string>();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Неожиданная ошибка при декодировании payload токена");
                return new List<string>();
            }
            
            var payloadJson = Encoding.UTF8.GetString(payloadBytes);
            
            _logger.LogDebug("Payload токена декодирован, размер: {Size} байт", payloadBytes.Length);
            
            // Парсим JSON с использованием кэшированных опций
            JsonElement payloadElement;
            try
            {
                payloadElement = JsonSerializer.Deserialize<JsonElement>(payloadJson, _jsonOptions);
            }
            catch (JsonException ex)
            {
                _logger.LogWarning(ex, "Невалидный JSON в payload токена");
                return new List<string>();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Неожиданная ошибка при парсинге JSON payload токена");
                return new List<string>();
            }
            
            // Извлекаем resource_access.users-management-api.roles
            if (payloadElement.TryGetProperty("resource_access", out var resourceAccess))
            {
                if (resourceAccess.TryGetProperty(Claims.UsersManagementApiClient, out var usersManagementApi))
                {
                    if (usersManagementApi.TryGetProperty("roles", out var rolesElement))
                    {
                        // Оптимизируем создание списка - оцениваем количество ролей
                        var roles = new List<string>();
                        foreach (var roleElement in rolesElement.EnumerateArray())
                        {
                            var roleName = roleElement.GetString();
                            if (!string.IsNullOrWhiteSpace(roleName))
                            {
                                roles.Add(roleName);
                            }
                        }
                        
                        _logger.LogDebug("Извлечено {Count} ролей из токена для клиента {ClientId}", roles.Count, Claims.UsersManagementApiClient);
                        return roles;
                    }
                }
            }
            
            _logger.LogDebug("Роли клиента {ClientId} не найдены в токене (resource_access отсутствует или клиент не найден)", Claims.UsersManagementApiClient);
            return new List<string>();
        }
        catch (FormatException ex)
        {
            _logger.LogWarning(ex, "Неверный формат base64url в payload токена");
            return new List<string>();
        }
        catch (JsonException ex)
        {
            _logger.LogWarning(ex, "Невалидный JSON в payload токена");
            return new List<string>();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при извлечении ролей из токена");
            return new List<string>();
        }
    }
    
    /// <summary>
    /// Декодирование base64url строки в массив байтов
    /// </summary>
    private static byte[] DecodeBase64Url(string base64Url)
    {
        if (string.IsNullOrWhiteSpace(base64Url))
        {
            throw new ArgumentException("Base64url string cannot be empty", nameof(base64Url));
        }
        
        // Оптимизируем замену символов - используем StringBuilder для больших строк
        // Для большинства токенов простая замена будет быстрее
        string base64;
        if (base64Url.Length > 1000)
        {
            var sb = new StringBuilder(base64Url);
            sb.Replace('-', '+');
            sb.Replace('_', '/');
            base64 = sb.ToString();
        }
        else
        {
            // Для коротких строк простая замена быстрее
            base64 = base64Url.Replace('-', '+').Replace('_', '/');
        }
        
        // Добавляем padding только если его нет
        var paddingLength = base64.Length % 4;
        if (paddingLength != 0)
        {
            if (paddingLength == 2)
            {
                base64 += "==";
            }
            else if (paddingLength == 3)
            {
                base64 += "=";
            }
            else
            {
                throw new FormatException("Invalid base64url string: padding calculation failed");
            }
        }
        
        try
        {
            return Convert.FromBase64String(base64);
        }
        catch (FormatException ex)
        {
            throw new FormatException($"Invalid base64url string: {ex.Message}", ex);
        }
    }
    
    /// <summary>
    /// Освобождаем ресурсы (семафоры и таймер)
    /// </summary>
    public void Dispose()
    {
        // Используем Interlocked для атомарной проверки и установки disposed
        if (Interlocked.Exchange(ref _disposed, 1) != 0)
            return;
        
        lock (_disposeLock)
        {
            // Двойная проверка внутри lock для безопасности
            if (Interlocked.CompareExchange(ref _disposed, 1, 1) != 1)
            {
                Interlocked.Exchange(ref _disposed, 1);
            }
            
            DisposeCore();
        }
    }
    
    /// <summary>
    /// Общая логика освобождения ресурсов
    /// </summary>
    private void DisposeCore()
    {
        // Освобождаем таймер очистки
        try
        {
            _cleanupTimer?.Dispose();
        }
        catch (Exception ex)
        {
            _logger?.LogWarning(ex, "Ошибка при освобождении таймера в UserMenuService");
        }
        
        // Освобождаем все семафоры
        foreach (var semaphoreInfo in _userRolesLocks.Values)
        {
            try
            {
                semaphoreInfo?.Semaphore?.Dispose();
            }
            catch (Exception ex)
            {
                _logger?.LogWarning(ex, "Ошибка при освобождении семафора в UserMenuService");
            }
        }
        
        _userRolesLocks.Clear();
        
        // Освобождаем ThreadLocal SHA256
        try
        {
            _sha256.Dispose();
        }
        catch (Exception ex)
        {
            _logger?.LogWarning(ex, "Ошибка при освобождении ThreadLocal SHA256 в UserMenuService");
        }
    }
    
    /// <summary>
    /// Асинхронное освобождение ресурсов
    /// </summary>
    public ValueTask DisposeAsync()
    {
        // Используем Interlocked для атомарной проверки и установки disposed
        if (Interlocked.Exchange(ref _disposed, 1) != 0)
            return ValueTask.CompletedTask;
        
        lock (_disposeLock)
        {
            // Двойная проверка внутри lock для безопасности
            if (Interlocked.CompareExchange(ref _disposed, 1, 1) != 1)
            {
                Interlocked.Exchange(ref _disposed, 1);
            }
            
            DisposeCore();
        }
        
        return ValueTask.CompletedTask;
    }
}
