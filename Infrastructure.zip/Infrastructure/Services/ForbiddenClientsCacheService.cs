using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для кэширования списка запрещенных клиентов
/// </summary>
public class ForbiddenClientsCacheService
{
    private readonly IForbiddenClientRepository _forbiddenRepo;
    private readonly IMemoryCache _memoryCache;
    private readonly ClientAccessSettings _settings;
    private readonly ILogger<ForbiddenClientsCacheService> _logger;
    private const string CacheKey = "ForbiddenClients_All";

    public ForbiddenClientsCacheService(
        IForbiddenClientRepository forbiddenRepo,
        IMemoryCache memoryCache,
        IOptions<ClientAccessSettings> settings,
        ILogger<ForbiddenClientsCacheService> logger)
    {
        _forbiddenRepo = forbiddenRepo;
        _memoryCache = memoryCache;
        _settings = settings.Value;
        _logger = logger;
    }

    /// <summary>
    /// Получить список всех запрещенных клиентов с кэшированием
    /// </summary>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Список запрещенных клиентов (ClientId, Realm)</returns>
    public async Task<List<(string ClientId, string Realm)>> GetForbiddenClientsAsync(CancellationToken cancellationToken = default)
    {
        if (_memoryCache.TryGetValue(CacheKey, out List<(string ClientId, string Realm)>? cachedClients) && cachedClients != null)
        {
            _logger.LogDebug("Запрещенные клиенты получены из кэша");
            return cachedClients;
        }

        _logger.LogDebug("Загрузка запрещенных клиентов из репозитория");
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        
        var clients = await _forbiddenRepo.GetAllForbiddenClientIdsAsync(cancellationToken);
        stopwatch.Stop();
        
        _logger.LogInformation("Загрузка запрещенных клиентов - {Time}мс", stopwatch.ElapsedMilliseconds);

        // Кэшируем на время, указанное в настройках
        var cacheOptions = new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(_settings.ForbiddenClientsCacheTtlMinutes),
            SlidingExpiration = null,
            Size = 1 // Указываем размер для MemoryCache с SizeLimit
        };

        _memoryCache.Set(CacheKey, clients, cacheOptions);
        
        return clients;
    }

    /// <summary>
    /// Инвалидировать кэш запрещенных клиентов
    /// </summary>
    public void InvalidateCache()
    {
        _memoryCache.Remove(CacheKey);
        _logger.LogDebug("Кэш запрещенных клиентов инвалидирован");
    }
}

