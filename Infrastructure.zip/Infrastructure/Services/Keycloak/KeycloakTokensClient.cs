using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services.Keycloak;

/// <summary>
/// Клиент для генерации example токенов Keycloak
/// </summary>
public class KeycloakTokensClient : KeycloakHttpClientBase
{
    /// <summary>
    /// Дефолтный scope для генерации токенов (openid profile email)
    /// </summary>
    private const string DefaultScope = "openid profile email";
    
    /// <summary>
    /// Кэшированное значение для дефолтного scope после URL-кодирования.
    /// Используется для оптимизации производительности, так как DefaultScope является константой.
    /// </summary>
    private static readonly string DefaultScopeEscaped;
    
    /// <summary>
    /// Статический конструктор для инициализации DefaultScopeEscaped
    /// </summary>
    static KeycloakTokensClient()
    {
        DefaultScopeEscaped = Uri.EscapeDataString(DefaultScope);
    }
    
    /// <summary>
    /// Регулярное выражение для валидации формата UUID
    /// </summary>
    private static readonly Regex UuidRegex = new(@"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", 
        RegexOptions.Compiled);
    
    /// <summary>
    /// Максимальная длина scope параметра (в символах)
    /// </summary>
    private const int MaxScopeLength = 1000;
    
    /// <summary>
    /// Максимальная длина error content для логирования (в символах).
    /// Используется для предотвращения засорения логов большими сообщениями об ошибках.
    /// </summary>
    private const int MaxErrorContentLengthForLogging = 500;
    
    /// <summary>
    /// Максимальная длина результата в байтах.
    /// Используется для проверки Content-Length перед чтением контента.
    /// </summary>
    private const int MaxResultLengthBytes = 100000;
    
    /// <summary>
    /// Максимальная длина результата в символах.
    /// Используется для проверки размера строки после чтения контента.
    /// </summary>
    private const int MaxResultLengthChars = 100000;
    
    /// <summary>
    /// Максимальная длина clientInternalId параметра (в символах)
    /// </summary>
    private const int MaxClientInternalIdLength = 100;
    
    /// <summary>
    /// Максимальная длина userId параметра (в символах)
    /// </summary>
    private const int MaxUserIdLength = 100;
    
    /// <summary>
    /// Шаблон базового пути для формирования endpoint
    /// </summary>
    private const string BasePathTemplate = "admin/realms/{0}/clients/{1}/{2}?userId={3}&scope={4}";
    
    /// <summary>
    /// Вычисленная длина базового пути (без параметров)
    /// </summary>
    private static readonly int BasePathLength = string.Format(BasePathTemplate, 
        string.Empty, string.Empty, string.Empty, string.Empty, string.Empty).Length;
    
    /// <summary>
    /// Endpoint путь для генерации example access token
    /// </summary>
    private const string GenerateAccessTokenEndpoint = "evaluate-scopes/generate-example-access-token";
    
    /// <summary>
    /// Endpoint путь для генерации example ID token
    /// </summary>
    private const string GenerateIdTokenEndpoint = "evaluate-scopes/generate-example-id-token";
    
    /// <summary>
    /// Endpoint путь для генерации example UserInfo
    /// </summary>
    private const string GenerateUserInfoEndpoint = "evaluate-scopes/generate-example-userinfo";
    
    public KeycloakTokensClient(
        System.Net.Http.HttpClient httpClient,
        new_assistant.Configuration.KeycloakAdminSettings settings,
        ILogger logger,
        new_assistant.Core.Interfaces.IKeycloakCacheService cacheService,
        new_assistant.Core.Interfaces.IPerformanceMetricsService metricsService)
        : base(httpClient, settings, logger, cacheService, metricsService)
    {
    }
    
    /// <summary>
    /// Проверяет, не был ли объект освобожден, и выбрасывает исключение если был
    /// </summary>
    private void ThrowIfDisposed()
    {
        if (Disposed)
        {
            throw new ObjectDisposedException(nameof(KeycloakTokensClient));
        }
    }
    
    /// <summary>
    /// Санитизирует содержимое ошибки, удаляя чувствительную информацию
    /// </summary>
    private static string SanitizeErrorContent(string errorContent, int maxLength = MaxErrorContentLengthForLogging)
    {
        if (string.IsNullOrEmpty(errorContent))
            return string.Empty;
        
        // Удаляем потенциально чувствительные данные
        var sanitized = Regex.Replace(
            errorContent,
            @"(?:access_token|refresh_token|client_secret|password|secret)[\s:=]+[""']?([^""'\s]+)[""']?",
            "$1=***REDACTED***",
            RegexOptions.IgnoreCase);
        
        return TruncateForLogging(sanitized, maxLength);
    }
    
    /// <summary>
    /// Обрезает строку для логирования, используя оптимизированный подход
    /// </summary>
    private static string TruncateForLogging(string content, int maxLength)
    {
        if (string.IsNullOrEmpty(content) || content.Length <= maxLength)
            return content ?? string.Empty;
        
        return content.AsSpan(0, maxLength).ToString() + "...";
    }
    
    /// <summary>
    /// Проверяет валидность JSON без создания полного DOM
    /// </summary>
    private static bool IsValidJson(string json)
    {
        if (string.IsNullOrWhiteSpace(json))
            return false;
        
        try
        {
            using var doc = JsonDocument.Parse(json, new JsonDocumentOptions 
            { 
                MaxDepth = 64, // Ограничение глубины для безопасности
                AllowTrailingCommas = false,
                CommentHandling = JsonCommentHandling.Skip // Пропускать комментарии
            });
            return true;
        }
        catch (JsonException)
        {
            return false;
        }
    }
    
    /// <summary>
    /// Читает содержимое HTTP ответа с ограничением по размеру
    /// </summary>
    private static async Task<string> ReadContentWithLimitAsync(
        HttpContent content, 
        int maxBytes, 
        CancellationToken cancellationToken)
    {
        if (content.Headers.ContentLength.HasValue)
        {
            var contentLength = content.Headers.ContentLength.Value;
            if (contentLength > maxBytes)
            {
                throw new InvalidOperationException(
                    $"Response content length ({contentLength} bytes) exceeds maximum allowed length ({maxBytes} bytes)");
            }
        }
        
        // Используем Stream для чтения с ограничением
        using var stream = await content.ReadAsStreamAsync(cancellationToken).ConfigureAwait(false);
        using var limitedStream = new System.IO.MemoryStream(maxBytes);
        
        var buffer = new byte[8192];
        int totalRead = 0;
        int bytesRead;
        
        while ((bytesRead = await stream.ReadAsync(buffer, 0, Math.Min(buffer.Length, maxBytes - totalRead), cancellationToken).ConfigureAwait(false)) > 0)
        {
            totalRead += bytesRead;
            if (totalRead > maxBytes)
            {
                throw new InvalidOperationException(
                    $"Response content exceeds maximum allowed length ({maxBytes} bytes)");
            }
            await limitedStream.WriteAsync(buffer, 0, bytesRead, cancellationToken).ConfigureAwait(false);
        }
        
        limitedStream.Position = 0;
        using var reader = new System.IO.StreamReader(limitedStream, System.Text.Encoding.UTF8);
        return await reader.ReadToEndAsync().ConfigureAwait(false);
    }
    
    /// <summary>
    /// Валидирует относительный путь на корректность формата
    /// </summary>
    private static void ValidateRelativePath(string relativePath)
    {
        if (!Uri.TryCreate(relativePath, UriKind.Relative, out var uri))
        {
            throw new ArgumentException($"Invalid endpoint format: {relativePath}", nameof(relativePath));
        }
        
        // Дополнительная проверка: путь не должен содержать абсолютные компоненты
        if (relativePath.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
            relativePath.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
        {
            throw new ArgumentException("Endpoint path cannot be an absolute URL", nameof(relativePath));
        }
        
        // Проверка на наличие query параметров в правильном формате
        var queryIndex = relativePath.IndexOf('?');
        if (queryIndex >= 0)
        {
            var query = relativePath.Substring(queryIndex + 1);
            if (string.IsNullOrEmpty(query) || !query.Contains('='))
            {
                throw new ArgumentException("Invalid query string format in endpoint path", nameof(relativePath));
            }
        }
    }
    
    /// <summary>
    /// Обрабатывает исключение и устанавливает соответствующие метрики
    /// </summary>
    private void HandleException(Exception ex, Stopwatch stopwatch, ref bool isSuccess, ref string? errorType, string operationName)
    {
        isSuccess = false;
        
        switch (ex)
        {
            case TaskCanceledException tce when tce.InnerException is TimeoutException:
                errorType = "Timeout";
                Logger?.LogError("Timeout when generating {OperationName} - {Time}ms", 
                    operationName, stopwatch.ElapsedMilliseconds);
                throw new TimeoutException($"Request timeout when generating {operationName}", tce.InnerException);
                
            case TaskCanceledException tce:
                errorType = "Cancelled";
                Logger?.LogWarning("Operation for generating {OperationName} was cancelled (TaskCanceledException)", operationName);
                throw new OperationCanceledException("Operation was cancelled", tce);
                
            case TimeoutException te:
                errorType = "Timeout";
                Logger?.LogError(te, "Timeout when generating {OperationName} - {Time}ms", 
                    operationName, stopwatch.ElapsedMilliseconds);
                throw new TimeoutException($"Request timeout when generating {operationName}: {te.Message}", te);
                
            case OperationCanceledException oce:
                errorType = "Cancelled";
                Logger?.LogWarning("Operation for generating {OperationName} was cancelled", operationName);
                throw new OperationCanceledException("Operation was cancelled", oce);
                
            case HttpRequestException hre:
                errorType = string.IsNullOrEmpty(errorType) ? "HttpRequestError" : errorType;
                Logger?.LogError(hre, "HTTP request error when generating {OperationName} - {Time}ms", 
                    operationName, stopwatch.ElapsedMilliseconds);
                throw new HttpRequestException("HTTP request error", hre);
                
            case ArgumentException ae:
                // errorType уже установлен
                throw new ArgumentException(ae.Message, ae);
            case InvalidOperationException ioe:
                // errorType уже установлен
                throw new InvalidOperationException(ioe.Message, ioe);
                
            default:
                errorType = string.IsNullOrEmpty(errorType) ? "UnexpectedError" : errorType;
                Logger?.LogError(ex, "Error generating {OperationName} - {Time}ms", 
                    operationName, stopwatch.ElapsedMilliseconds);
                throw new InvalidOperationException($"Error generating {operationName}: {ex.Message}", ex);
        }
    }
    
    /// <summary>
    /// Останавливает stopwatch и записывает метрики производительности
    /// </summary>
    private void StopAndRecordMetrics(Stopwatch stopwatch, bool isSuccess = true, string? errorType = null, string? operationName = null)
    {
        if (stopwatch.IsRunning)
        {
            stopwatch.Stop();
            RecordRequestTime(stopwatch.ElapsedMilliseconds);
            
            if (!string.IsNullOrEmpty(operationName))
            {
                if (isSuccess)
                {
                    RecordSuccess($"GenerateExampleToken.{operationName}");
                }
                else
                {
                    RecordError($"GenerateExampleToken.{operationName}", errorType ?? "Unknown");
                }
            }
        }
    }
    
    // Используем KeycloakParameterValidator для унификации валидации (исправление проблемы #2)
    // Все методы валидации удалены и заменены на использование KeycloakParameterValidator
    
    /// <summary>
    /// Проверяет, что компонент пути безопасен для использования в URL
    /// </summary>
    private static string EnsureSafePathComponent(string component, string componentName)
    {
        if (string.IsNullOrEmpty(component))
            return component;
        
        // Проверяем, что компонент не содержит символов, требующих кодирования
        if (component.Any(c => c == '/' || c == '?' || c == '#' || c == '&' || c == '='))
        {
            throw new ArgumentException(
                $"{componentName} contains characters that are not allowed in URL path components", 
                componentName);
        }
        
        return component;
    }
    
    /// <summary>
    /// Валидация operationName параметра
    /// </summary>
    private static void ValidateOperationName(string operationName)
    {
        if (string.IsNullOrWhiteSpace(operationName))
            throw new ArgumentException("OperationName cannot be null or empty", nameof(operationName));
        
        const int MaxOperationNameLength = 200;
        if (operationName.Length > MaxOperationNameLength)
            throw new ArgumentException($"OperationName cannot exceed {MaxOperationNameLength} characters", nameof(operationName));
    }
    
    /// <summary>
    /// Валидация endpointPath параметра
    /// </summary>
    private static void ValidateEndpointPath(string endpointPath)
    {
        if (string.IsNullOrWhiteSpace(endpointPath))
            throw new ArgumentException("EndpointPath cannot be null or empty", nameof(endpointPath));
        
        if (endpointPath.Length > MaxEndpointLength)
            throw new ArgumentException($"EndpointPath cannot exceed {MaxEndpointLength} characters", nameof(endpointPath));
        
        // Проверка на абсолютный путь (не должен начинаться с "/")
        if (endpointPath.StartsWith("/", StringComparison.Ordinal))
        {
            throw new ArgumentException("EndpointPath cannot start with '/' (absolute paths are not allowed)", nameof(endpointPath));
        }
        
        // Проверка на недопустимые символы в пути
        if (endpointPath.Contains("..", StringComparison.Ordinal) || 
            endpointPath.Contains("//", StringComparison.Ordinal))
        {
            throw new ArgumentException("EndpointPath contains invalid path sequences", nameof(endpointPath));
        }
        
        // Проверка на другие потенциально опасные символы в пути
        if (endpointPath.Contains("\\", StringComparison.Ordinal) || 
            endpointPath.Contains("\0", StringComparison.Ordinal))
        {
            throw new ArgumentException("EndpointPath contains invalid characters", nameof(endpointPath));
        }
        
        // Проверка URL injection для endpointPath
        ValidateParameterForUrlInjection(endpointPath, nameof(endpointPath));
    }
    
    /// <summary>
    /// Проверка параметра на наличие недопустимых символов для URL
    /// Использует ReadOnlySpan<char> для лучшей производительности
    /// </summary>
    private static void ValidateParameterForUrlInjection(string parameter, string parameterName)
    {
        if (string.IsNullOrEmpty(parameter))
            return;
        
        // Используем ReadOnlySpan<char> для оптимизации производительности
        ReadOnlySpan<char> parameterSpan = parameter;
        ValidateParameterForUrlInjection(parameterSpan, parameterName);
    }
    
    /// <summary>
    /// Проверка параметра на наличие недопустимых символов для URL (оптимизированная версия с ReadOnlySpan)
    /// </summary>
    private static void ValidateParameterForUrlInjection(ReadOnlySpan<char> parameter, string parameterName)
    {
        if (parameter.IsEmpty)
            return;
            
        // Проверка на непечатные управляющие символы (кроме табуляции, которая допустима)
        // Uri.EscapeDataString уже защищает от большинства проблем, но дополнительная проверка не помешает
        foreach (var c in parameter)
        {
            if (char.IsControl(c) && c != '\t')
            {
                throw new ArgumentException(
                    $"Parameter {parameterName} contains invalid control characters", 
                    parameterName);
            }
        }
        
        // Проверка на потенциально опасные URL символы (до кодирования)
        // Проверяем наличие символов, которые не должны быть в параметрах URL
        // ReadOnlySpan<char>.Contains(char) - оптимальный метод для проверки символов
        if (parameter.Contains('?') || 
            parameter.Contains('#') || 
            parameter.Contains('&') || 
            parameter.Contains('='))
        {
            throw new ArgumentException(
                $"Parameter {parameterName} contains URL structure characters that are not allowed", 
                parameterName);
        }
    }
    
    /// <summary>
    /// Общий метод для генерации example токенов/данных
    /// </summary>
    private async Task<string> GenerateExampleTokenAsync(
        string realm, 
        string clientInternalId, 
        string userId, 
        string? scope, 
        string endpointPath,
        string operationName,
        CancellationToken cancellationToken)
    {
        // Проверка на Disposed перед выполнением операции
        ThrowIfDisposed();
        
        // Валидация параметров через KeycloakParameterValidator (исправление проблемы #2)
        KeycloakParameterValidator.ValidateRealm(realm);
        KeycloakParameterValidator.ValidateClientInternalId(clientInternalId);
        KeycloakParameterValidator.ValidateUserId(userId);
        KeycloakParameterValidator.ValidateScope(scope);
        
        // Дополнительная валидация специфичных параметров
        ValidateEndpointPath(endpointPath);
        ValidateOperationName(operationName);
        
        // HttpClient является readonly полем, инициализированным в конструкторе базового класса
        // Проверка на null избыточна (исправление проблемы #4)
        // Вместо этого проверяем Disposed состояние
        if (Disposed)
        {
            throw new ObjectDisposedException(nameof(KeycloakTokensClient));
        }
        
        cancellationToken.ThrowIfCancellationRequested();
        
        var stopwatch = Stopwatch.StartNew();
        var isSuccess = false;
        string? errorType = null;
        
        // Использование BeginScope для добавления контекста в логи
        using (Logger?.BeginScope(new Dictionary<string, object>
        {
            ["Operation"] = operationName,
            ["Realm"] = realm,
            ["ClientInternalId"] = clientInternalId,
            ["UserId"] = userId
        }))
        {
            var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
            if (!acquired)
            {
                // isSuccess уже false по умолчанию
                errorType = "SemaphoreDisposed";
                Logger?.LogError("Semaphore disposed, cannot execute operation");
                throw new InvalidOperationException("Semaphore disposed, cannot execute operation");
            }
            
            try
            {
            var token = await GetAdminTokenAsync(cancellationToken).ConfigureAwait(false);
            
            if (string.IsNullOrEmpty(token))
            {
                isSuccess = false;
                errorType = "TokenRetrievalFailed";
                Logger?.LogError("Failed to obtain admin token for generating {OperationName}", operationName);
                throw new InvalidOperationException($"Failed to get admin token for {operationName}");
            }
            
            // Оптимизация: используем кэшированное значение для дефолтного scope
            // ВАЖНО: Параметры scope и userId должны быть НЕ закодированы при передаче в метод
            // Если параметры уже закодированы, произойдет двойное кодирование
            var scopeParam = scope != null ? Uri.EscapeDataString(scope) : DefaultScopeEscaped;
            var userIdParam = Uri.EscapeDataString(userId);
            
            // Проверяем безопасность компонентов пути
            var safeRealm = EnsureSafePathComponent(realm, nameof(realm));
            var safeClientInternalId = EnsureSafePathComponent(clientInternalId, nameof(clientInternalId));
            
            // Оценка длины до форматирования для ранней валидации
            var estimatedLength = BasePathLength + 
                safeRealm.Length + 
                safeClientInternalId.Length + 
                endpointPath.Length + 
                userIdParam.Length + 
                scopeParam.Length;
            
            if (estimatedLength > MaxEndpointLength)
            {
                isSuccess = false;
                errorType = "EndpointTooLong";
                Logger?.LogError("Estimated endpoint length ({Length}) exceeds maximum allowed length ({MaxLength})", 
                    estimatedLength, MaxEndpointLength);
                throw new ArgumentException(
                    $"Estimated endpoint length ({estimatedLength}) exceeds maximum allowed length ({MaxEndpointLength})", 
                    nameof(endpointPath));
            }
            
            // Формирование относительного пути endpoint с использованием string.Format для оптимизации
            var relativePath = string.Format(BasePathTemplate, 
                safeRealm, safeClientInternalId, endpointPath, userIdParam, scopeParam);
            
            // Дополнительная проверка после форматирования (на всякий случай, если оценка была неточной)
            if (relativePath.Length > MaxEndpointLength)
            {
                isSuccess = false;
                errorType = "EndpointTooLong";
                Logger?.LogError("Endpoint length ({Length}) exceeds maximum allowed length ({MaxLength})", 
                    relativePath.Length, MaxEndpointLength);
                throw new ArgumentException(
                    $"Endpoint length ({relativePath.Length}) exceeds maximum allowed length ({MaxEndpointLength})", 
                    nameof(endpointPath));
            }
            
            // Проверка на валидность относительного пути перед использованием
            ValidateRelativePath(relativePath);
            
            // Использование относительного пути напрямую - HttpClient автоматически объединит его с BaseAddress (AdminApiBaseUrl)
            // Uri.TryCreate используется только для валидации, затем передаем исходный relativePath
            using var request = await CreateAuthorizedRequestAsync(HttpMethod.Get, relativePath, cancellationToken).ConfigureAwait(false);
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            
            if (!response.IsSuccessStatusCode)
            {
                isSuccess = false;
                var errorContent = response.Content != null
                    ? await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false)
                    : string.Empty;
                
                // Санитизация и ограничение длины errorContent при логировании
                var errorContentForLogging = SanitizeErrorContent(errorContent);
                
                // Различаем типы ошибок
                var statusCodeInt = (int)response.StatusCode;
                if (statusCodeInt >= 500)
                {
                    // Серверная ошибка - может быть временной
                    errorType = "ServerError";
                    Logger?.LogError("Server error when generating {OperationName}: {StatusCode} - {Error}", 
                        operationName, response.StatusCode, errorContentForLogging);
                    throw new HttpRequestException(
                        $"Server error when generating {operationName}: {response.StatusCode} - {errorContent}", 
                        null, response.StatusCode);
                }
                else if (statusCodeInt >= 400)
                {
                    // Ошибка клиента - обычно постоянная
                    errorType = "ClientError";
                    Logger?.LogWarning("Client error when generating {OperationName}: {StatusCode} - {Error}", 
                        operationName, response.StatusCode, errorContentForLogging);
                    throw new HttpRequestException(
                        $"Client error when generating {operationName}: {response.StatusCode} - {errorContent}", 
                        null, response.StatusCode);
                }
                else
                {
                    errorType = "UnexpectedStatusCode";
                    Logger?.LogError("Unexpected status code when generating {OperationName}: {StatusCode} - {Error}", 
                        operationName, response.StatusCode, errorContentForLogging);
                    throw new HttpRequestException(
                        $"Failed to generate {operationName}: {response.StatusCode} - {errorContent}");
                }
            }
            
            if (response.Content == null)
            {
                isSuccess = false;
                errorType = "NullResponseContent";
                Logger?.LogError("Response.Content is null when generating {OperationName}", operationName);
                throw new InvalidOperationException($"Response content is null when generating {operationName}");
            }
            
            // Сохраняем ссылку на Content для избежания повторных проверок и предупреждений компилятора
            var content = response.Content;
            
            // Используем оптимизированный метод чтения контента с ограничением
            var result = await ReadContentWithLimitAsync(content, MaxResultLengthBytes, cancellationToken).ConfigureAwait(false);
            
            // Проверка на пустой контент перед возвратом
            if (string.IsNullOrWhiteSpace(result))
            {
                isSuccess = false;
                errorType = "EmptyResponseContent";
                Logger?.LogError("Response content is empty when generating {OperationName}", operationName);
                throw new InvalidOperationException($"Response content is empty when generating {operationName}");
            }
            
            // Дополнительная проверка на максимальную длину результата (если Content-Length не был указан)
            if (result.Length > MaxResultLengthChars)
            {
                isSuccess = false;
                errorType = "ContentTooLarge";
                Logger?.LogError("Response content too large ({Length} characters) when generating {OperationName}", 
                    result.Length, operationName);
                throw new InvalidOperationException($"Response content too large ({result.Length} characters) when generating {operationName}");
            }
            
            // Проверка на валидность JSON результата с оптимизацией
            // Если JSON невалиден, это может указывать на проблему, но не критично для продолжения работы
            // Логируем предупреждение, но продолжаем выполнение
            if (!IsValidJson(result))
            {
                Logger?.LogWarning("Response content is not valid JSON when generating {OperationName}. Returning original string.", operationName);
            }
            
            // Успешное выполнение операции
            isSuccess = true;
            Logger?.LogInformation("Generation of {OperationName} completed in {Time}ms", operationName, stopwatch.ElapsedMilliseconds);
            
            return result;
            }
            catch (Exception ex)
            {
                // Используем централизованную обработку исключений
                // HandleException выбрасывает исключение внутри, поэтому этот throw недостижим
                HandleException(ex, stopwatch, ref isSuccess, ref errorType, operationName);
                throw; // Недостижимый код, но необходим для компилятора
            }
            finally
            {
                // Гарантированно записываем метрики в finally
                StopAndRecordMetrics(stopwatch, isSuccess, errorType, operationName);
                SafeReleaseSemaphore();
            }
        }
    }
    
    /// <summary>
    /// Генерация example access token для пользователя
    /// </summary>
    /// <param name="realm">Название реалма Keycloak</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="userId">ID пользователя (UUID)</param>
    /// <param name="scope">Опциональный scope. Если null, используется дефолтный: "openid profile email"</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>JSON строка с example access token</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="InvalidOperationException">Выбрасывается при ошибках выполнения операции</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции</exception>
    public async Task<string> GenerateExampleAccessTokenAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default)
    {
        return await GenerateExampleTokenAsync(
            realm, 
            clientInternalId, 
            userId, 
            scope, 
            GenerateAccessTokenEndpoint,
            "example access token",
            cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Генерация example ID token для пользователя
    /// </summary>
    /// <param name="realm">Название реалма Keycloak</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="userId">ID пользователя (UUID)</param>
    /// <param name="scope">Опциональный scope. Если null, используется дефолтный: "openid profile email"</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>JSON строка с example ID token</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="InvalidOperationException">Выбрасывается при ошибках выполнения операции</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции</exception>
    public async Task<string> GenerateExampleIdTokenAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default)
    {
        return await GenerateExampleTokenAsync(
            realm, 
            clientInternalId, 
            userId, 
            scope, 
            GenerateIdTokenEndpoint,
            "example ID token",
            cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Генерация example UserInfo для пользователя
    /// </summary>
    /// <param name="realm">Название реалма Keycloak</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="userId">ID пользователя (UUID)</param>
    /// <param name="scope">Опциональный scope. Если null, используется дефолтный: "openid profile email"</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>JSON строка с example UserInfo</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="InvalidOperationException">Выбрасывается при ошибках выполнения операции</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса</exception>
    /// <exception cref="ObjectDisposedException">Выбрасывается если объект уже освобожден</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции</exception>
    public async Task<string> GenerateExampleUserInfoAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default)
    {
        return await GenerateExampleTokenAsync(
            realm, 
            clientInternalId, 
            userId, 
            scope, 
            GenerateUserInfoEndpoint,
            "example UserInfo",
            cancellationToken).ConfigureAwait(false);
    }
}




