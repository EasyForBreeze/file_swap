using System.Globalization;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.WebUtilities;
using new_assistant.Core.Constants;
using new_assistant.Core.DTOs;
using new_assistant.Core.Entities;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для работы с Wiki страницами при миграции клиентов
/// </summary>
public class ClientMigrationWikiService : IClientMigrationWikiService
{
    private readonly IWikiPageRepository _wikiPageRepository;
    private readonly IConfluenceService _confluenceService;
    private readonly ILogger<ClientMigrationWikiService> _logger;

    public ClientMigrationWikiService(
        IWikiPageRepository wikiPageRepository,
        IConfluenceService confluenceService,
        ILogger<ClientMigrationWikiService> logger)
    {
        _wikiPageRepository = wikiPageRepository ?? throw new ArgumentNullException(nameof(wikiPageRepository));
        _confluenceService = confluenceService ?? throw new ArgumentNullException(nameof(confluenceService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Создать fallback pageId
    /// </summary>
    private static string CreateFallbackPageId()
    {
        var guidString = Guid.NewGuid().ToString("N");
        var prefix = MigrationConstants.ManualPageIdPrefix;
        var fullString = prefix + guidString;
        var targetLength = MigrationConstants.ManualPageIdLength;
        
        // Безопасная обрезка с проверкой длины
        return fullString.Length > targetLength 
            ? fullString.Substring(0, targetLength) 
            : fullString.PadRight(targetLength, '0');
    }

    /// <summary>
    /// Извлечь метаданные из Wiki URL
    /// </summary>
    public async Task<(string PageId, string Title, string Url, bool IsValid)> ExtractWikiMetadataAsync(
        string wikiUrl, 
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(wikiUrl))
        {
            return (CreateFallbackPageId(), "Wiki Page", string.Empty, false);
        }

        var trimmedUrl = wikiUrl.Trim();
        
        // Валидация длины URL
        if (trimmedUrl.Length > MigrationConstants.MaxWikiUrlLength)
        {
            _logger.LogWarning("URL превышает максимальную длину: {Length}, Max: {Max}", 
                trimmedUrl.Length, MigrationConstants.MaxWikiUrlLength);
            trimmedUrl = trimmedUrl.Substring(0, MigrationConstants.MaxWikiUrlLength);
        }
        
        // Валидация URL формата
        if (!Uri.TryCreate(trimmedUrl, UriKind.Absolute, out var uri))
        {
            _logger.LogWarning("Некорректный формат Wiki URL: {Url}", trimmedUrl);
            return (CreateFallbackPageId(), "Wiki Page", trimmedUrl, false);
        }
        
        // Проверка схемы (должен быть http или https)
        if (uri.Scheme != "http" && uri.Scheme != "https")
        {
            _logger.LogWarning("Неподдерживаемая схема URL: {Scheme} для {Url}", uri.Scheme, trimmedUrl);
            return (CreateFallbackPageId(), "Wiki Page", trimmedUrl, false);
        }
        
        string pageId = string.Empty;
        string title = "Wiki Page";
        string? spaceKey = null;
        string? friendlyTitle = null;
        var isValid = true;
        
        try
        {
            var query = QueryHelpers.ParseQuery(uri.Query);
            if (query.TryGetValue("pageId", out var pageIdValue) && !string.IsNullOrWhiteSpace(pageIdValue))
            {
                pageId = pageIdValue.ToString();
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка парсинга query параметров URL: {Url}", trimmedUrl);
        }

        // Получаем сегменты URI один раз для использования в нескольких местах
        var uriSegments = uri.Segments;
        
        if (string.IsNullOrWhiteSpace(pageId))
        {
            var lastSegment = uriSegments.Length > 0 ? uriSegments[^1] : string.Empty;
            if (!string.IsNullOrWhiteSpace(lastSegment))
            {
                var match = Regex.Match(lastSegment, @"(\d+)");
                if (match != null && match.Success && match.Groups.Count > 1)
                {
                    pageId = match.Groups[1].Value;
                }
            }
        }

        // Attempt to extract space/title from friendly URLs like /display/SPACE/Title
        var segments = uri.AbsolutePath.Split('/', StringSplitOptions.RemoveEmptyEntries);
        if (segments.Length >= 3 && string.Equals(segments[0], "display", StringComparison.OrdinalIgnoreCase))
        {
            spaceKey = segments[1];
            var titleSegments = segments.Skip(2);
            var rawTitle = string.Join("/", titleSegments);
            friendlyTitle = DecodeUrlSegment(rawTitle.Replace('+', ' '));
            
            // Валидация декодированного значения
            if (!string.IsNullOrWhiteSpace(friendlyTitle) && !IsValidDecodedValue(friendlyTitle))
            {
                _logger.LogWarning("Декодированный friendlyTitle содержит недопустимые символы: {Title}", friendlyTitle);
                friendlyTitle = null;
            }
        }

        var pathSegment = uriSegments.Length > 0 ? uriSegments[^1] : string.Empty;
        if (!string.IsNullOrWhiteSpace(pathSegment))
        {
            var cleaned = pathSegment.Trim('/');
            cleaned = Regex.Replace(cleaned, @"-\d+(\.\w+)?$", string.Empty);
            cleaned = cleaned.Replace('-', ' ');
            cleaned = DecodeUrlSegment(cleaned);
            
            // Валидация декодированного значения
            if (!string.IsNullOrWhiteSpace(cleaned) && IsValidDecodedValue(cleaned))
            {
                title = CultureInfo.InvariantCulture.TextInfo.ToTitleCase(cleaned);
            }
        }

        if (string.IsNullOrWhiteSpace(pageId) && !string.IsNullOrWhiteSpace(spaceKey) && !string.IsNullOrWhiteSpace(friendlyTitle))
        {
            try
            {
                var resolved = await _confluenceService.ResolvePageAsync(spaceKey, friendlyTitle, cancellationToken).ConfigureAwait(false);
                if (resolved.HasValue)
                {
                    var resolvedPage = resolved.Value;
                    pageId = resolvedPage.Id;
                    title = resolvedPage.Title;
                    trimmedUrl = string.IsNullOrWhiteSpace(resolvedPage.Url) ? trimmedUrl : resolvedPage.Url;
                }
                else
                {
                    _logger.LogWarning(
                        "Wiki: не удалось получить pageId по friendly URL. Space={Space}, Title={Title}, Url={Url}",
                        spaceKey,
                        friendlyTitle,
                        trimmedUrl);
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex,
                    "Ошибка при разрешении страницы по friendly URL. Space={Space}, Title={Title}, Url={Url}",
                    spaceKey,
                    friendlyTitle,
                    trimmedUrl);
            }
        }

        if (string.IsNullOrWhiteSpace(pageId))
        {
            pageId = CreateFallbackPageId();
        }
        
        // Валидация формата pageId
        if (!IsValidPageIdFormat(pageId))
        {
            _logger.LogWarning("PageId содержит недопустимые символы, будет создан fallback: {PageId}", pageId);
            pageId = CreateFallbackPageId();
        }

        if (pageId.Length > MigrationConstants.MaxPageIdLength)
        {
            // Использовать SHA256 для более надежного хеша вместо GetHashCode
            string hash;
            using (var sha256 = SHA256.Create())
            {
                var hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(pageId));
                // Использовать Convert.ToHexString для более эффективного преобразования (доступен в .NET 5+)
                hash = Convert.ToHexString(hashBytes);
            }
            
            // Безопасная обрезка хеша до нужной длины
            var hashLength = MigrationConstants.PageIdHashLength;
            hash = hash.Length >= hashLength 
                ? hash.Substring(0, hashLength) 
                : hash.PadRight(hashLength, '0');
            
            var maxHashLength = MigrationConstants.MaxPageIdLength - hash.Length - 1;
            if (maxHashLength < 0)
            {
                _logger.LogError("PageId слишком длинный для обрезки. Length: {Length}, Max: {Max}", 
                    pageId.Length, MigrationConstants.MaxPageIdLength);
                // Безопасная обрезка
                pageId = pageId.Length > MigrationConstants.MaxPageIdLength
                    ? pageId.Substring(0, MigrationConstants.MaxPageIdLength)
                    : pageId;
            }
            else
            {
                // Безопасная обрезка с проверкой длины
                var prefixLength = Math.Min(maxHashLength, pageId.Length);
                pageId = pageId.Substring(0, prefixLength) + "-" + hash;
            }
            
            _logger.LogWarning(
                "PageId обрезан и добавлен хеш из-за превышения длины. Final length: {FinalLength}",
                pageId.Length);
        }

        if (!string.IsNullOrWhiteSpace(pageId) && isValid)
        {
            try
            {
                var metadata = await _confluenceService.GetPageMetadataAsync(pageId, cancellationToken).ConfigureAwait(false);
                if (metadata.HasValue)
                {
                    title = metadata.Value.Title;
                    if (!string.IsNullOrWhiteSpace(metadata.Value.Url))
                    {
                        // Валидация URL перед использованием
                        if (Uri.TryCreate(metadata.Value.Url, UriKind.Absolute, out var validatedUri) &&
                            (validatedUri.Scheme == "http" || validatedUri.Scheme == "https"))
                        {
                            trimmedUrl = metadata.Value.Url;
                        }
                        else
                        {
                            _logger.LogWarning("Полученный URL из метаданных невалиден: {Url}", metadata.Value.Url);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Ошибка при получении метаданных страницы. PageId={PageId}", pageId);
            }
        }

        return (pageId, title, trimmedUrl, isValid);
    }

    /// <summary>
    /// Обновить или создать Wiki страницу в репозитории
    /// </summary>
    public async Task<string?> UpdateWikiPageInRepositoryAsync(
        string clientId,
        string? wikiUrl,
        string migratedBy,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        
        if (string.IsNullOrWhiteSpace(migratedBy))
            throw new ArgumentException("MigratedBy cannot be null or empty", nameof(migratedBy));
        
        try
        {
            _logger.LogInformation(
                "Wiki: старт обновления записи в репозитории для клиента {ClientId}. CandidateUrl={CandidateUrl}",
                clientId,
                wikiUrl ?? "<null>");

            var existingWikiPage = await _wikiPageRepository.GetWikiPageAnyRealmAsync(clientId).ConfigureAwait(false);

            _logger.LogInformation(
                "Wiki: текущая запись в БД для клиента {ClientId}: Exists={Exists}, PageId={PageId}, Url={Url}, Status={Status}",
                clientId,
                existingWikiPage != null,
                existingWikiPage?.WikiPageId ?? "<null>",
                existingWikiPage?.WikiPageUrl ?? "<null>",
                existingWikiPage?.Status ?? "<null>");

            if (!string.IsNullOrWhiteSpace(wikiUrl))
            {
                var metadata = await ExtractWikiMetadataAsync(wikiUrl, cancellationToken).ConfigureAwait(false);
                var finalUrl = metadata.Url;
                
                if (!metadata.IsValid)
                {
                    _logger.LogWarning(
                        "Wiki: ссылка указана в нестандартном формате для клиента {ClientId}. Original={OriginalUrl}, ParsedPageId={PageId}",
                        clientId,
                        wikiUrl,
                        metadata.PageId);
                }

                if (existingWikiPage == null)
                {
                    var newWikiPage = new ClientWikiPage
                    {
                        ClientId = clientId,
                        Realm = MigrationConstants.RealmGlobal,
                        WikiPageId = metadata.PageId,
                        WikiPageTitle = metadata.Title,
                        WikiPageUrl = finalUrl,
                        Status = MigrationConstants.StatusStage,
                        CreatedBy = migratedBy,
                        PageVersion = 1
                    };

                    try
                    {
                        await _wikiPageRepository.SaveWikiPageAsync(newWikiPage).ConfigureAwait(false);

                        _logger.LogInformation(
                            "Wiki: создана новая запись в БД для клиента {ClientId}. PageId={PageId}, Url={Url}",
                            clientId,
                            newWikiPage.WikiPageId,
                            newWikiPage.WikiPageUrl);
                        
                        return finalUrl;
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, 
                            "Ошибка при сохранении новой Wiki страницы для клиента {ClientId}. PageId={PageId}", 
                            clientId, metadata.PageId);
                        throw;
                    }
                }
                else
                {
                    // Создаем копию объекта перед мутацией
                    var updatedWikiPage = new ClientWikiPage
                    {
                        Id = existingWikiPage.Id,
                        ClientId = existingWikiPage.ClientId,
                        Realm = MigrationConstants.RealmGlobal,
                        WikiPageId = metadata.PageId,
                        WikiPageTitle = metadata.Title,
                        WikiPageUrl = finalUrl,
                        Status = MigrationConstants.StatusStage,
                        CreatedBy = existingWikiPage.CreatedBy,
                        CreatedAt = existingWikiPage.CreatedAt,
                        UpdatedAt = DateTime.UtcNow,
                        PageVersion = existingWikiPage.PageVersion <= 0 ? 1 : existingWikiPage.PageVersion
                    };

                    try
                    {
                        await _wikiPageRepository.UpdateWikiPageAsync(updatedWikiPage).ConfigureAwait(false);

                        _logger.LogInformation(
                            "Wiki: обновлена существующая запись в БД для клиента {ClientId}. PageId={PageId}, Url={Url}, Status={Status}",
                            clientId,
                            updatedWikiPage.WikiPageId,
                            updatedWikiPage.WikiPageUrl,
                            updatedWikiPage.Status);
                        
                        return finalUrl;
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, 
                            "Ошибка при обновлении Wiki страницы для клиента {ClientId}. PageId={PageId}", 
                            clientId, metadata.PageId);
                        throw;
                    }
                }
            }
            else if (existingWikiPage != null)
            {
                // Создаем копию объекта перед мутацией
                var updatedWikiPage = new ClientWikiPage
                {
                    Id = existingWikiPage.Id,
                    ClientId = existingWikiPage.ClientId,
                    Realm = MigrationConstants.RealmGlobal,
                    WikiPageId = existingWikiPage.WikiPageId,
                    WikiPageTitle = existingWikiPage.WikiPageTitle,
                    WikiPageUrl = existingWikiPage.WikiPageUrl,
                    Status = MigrationConstants.StatusStage,
                    CreatedBy = existingWikiPage.CreatedBy,
                    CreatedAt = existingWikiPage.CreatedAt,
                    UpdatedAt = DateTime.UtcNow,
                    PageVersion = existingWikiPage.PageVersion
                };
                
                try
                {
                    await _wikiPageRepository.UpdateWikiPageAsync(updatedWikiPage).ConfigureAwait(false);

                    _logger.LogInformation(
                        "Wiki: ссылка не указана, обновили статус существующей записи для клиента {ClientId} на {Status}",
                        clientId,
                        updatedWikiPage.Status);

                    return updatedWikiPage.WikiPageUrl;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, 
                        "Ошибка при обновлении статуса Wiki страницы для клиента {ClientId}", 
                        clientId);
                    throw;
                }
            }
            else
            {
                _logger.LogWarning(
                    "Wiki: ссылка не указана и запись не найдена для клиента {ClientId}.", clientId);
                return null;
            }
        }
        catch (Exception ex)
        {
            var errorContext = new
            {
                ClientId = clientId,
                WikiUrl = wikiUrl,
                Operation = "UpdateWikiPage",
                ErrorType = ex.GetType().Name,
                ErrorMessage = ex.Message
            };
            
            _logger.LogWarning(ex, 
                "Не удалось обновить Wiki страницу для клиента {ClientId}. Context: {@Context}", 
                clientId, errorContext);
            throw;
        }
    }

    /// <summary>
    /// Обновить Wiki страницу в Confluence
    /// </summary>
    public async Task<string?> UpdateWikiPageInConfluenceAsync(
        ClientDetailsDto clientDetails,
        string migratedBy,
        CancellationToken cancellationToken = default)
    {
        if (clientDetails == null)
            throw new ArgumentNullException(nameof(clientDetails));
        
        if (string.IsNullOrWhiteSpace(migratedBy))
            throw new ArgumentException("MigratedBy cannot be null or empty", nameof(migratedBy));
        
        try
        {
            _logger.LogInformation(
                "Wiki: попытка обновления страницы в Confluence для клиента {ClientId}. Realm={Realm}",
                clientDetails.ClientId,
                clientDetails.Realm);

            string? updatedWikiUrl;
            try
            {
                updatedWikiUrl = await _confluenceService.UpdateClientPageAsync(
                    clientDetails,
                    migratedBy,
                    cancellationToken).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, 
                    "Ошибка при вызове UpdateClientPageAsync для клиента {ClientId}. Realm={Realm}", 
                    clientDetails.ClientId, clientDetails.Realm);
                throw;
            }

            if (!string.IsNullOrWhiteSpace(updatedWikiUrl))
            {
                // Валидация полученного URL
                if (Uri.TryCreate(updatedWikiUrl, UriKind.Absolute, out var validatedUri) &&
                    (validatedUri.Scheme == "http" || validatedUri.Scheme == "https"))
                {
                    _logger.LogInformation(
                        "Wiki: страница Confluence обновлена для клиента {ClientId}. Итоговый URL={Url}",
                        clientDetails.ClientId,
                        updatedWikiUrl);
                    return updatedWikiUrl;
                }
                else
                {
                    _logger.LogWarning(
                        "Wiki: Confluence вернул невалидный URL для клиента {ClientId}. Url={Url}", 
                        clientDetails.ClientId, updatedWikiUrl);
                    return null;
                }
            }
            else
            {
                _logger.LogWarning(
                    "Wiki: Confluence вернул пустой URL при обновлении клиента {ClientId}.", clientDetails.ClientId);
                return null;
            }
        }
        catch (Exception ex)
        {
            var errorContext = new
            {
                ClientId = clientDetails.ClientId,
                Realm = clientDetails.Realm,
                Operation = "UpdateConfluencePage",
                ErrorType = ex.GetType().Name,
                ErrorMessage = ex.Message
            };
            
            _logger.LogWarning(ex, 
                "Не удалось синхронизировать Wiki страницу в Confluence для клиента {ClientId}. Context: {@Context}", 
                clientDetails.ClientId, errorContext);
            throw;
        }
    }

    /// <summary>
    /// Декодирование URL сегмента с обработкой различных кодировок
    /// </summary>
    private string DecodeUrlSegment(string segment)
    {
        // Улучшенная проверка на null для большей ясности
        if (segment == null)
            return string.Empty;
        
        if (string.IsNullOrWhiteSpace(segment))
            return string.Empty;
        
        try
        {
            // Попробовать стандартную декодировку
            var decoded = Uri.UnescapeDataString(segment);
            
            // Если результат содержит недопустимые управляющие символы, попробовать другую кодировку
            if (decoded.Any(c => char.IsControl(c) && !char.IsWhiteSpace(c)))
            {
                // Попробовать декодировать через WebUtility (более надежно)
                try
                {
                    decoded = WebUtility.UrlDecode(segment);
                    
                    // Проверка на недопустимые символы после декодирования
                    if (decoded.Any(c => char.IsControl(c) && !char.IsWhiteSpace(c)))
                    {
                        _logger.LogWarning("Декодированный URL сегмент содержит недопустимые символы: {Segment}", segment);
                        return segment;
                    }
                }
                catch (Exception ex)
                {
                    // Если и это не помогло, вернуть исходное значение
                    _logger.LogWarning(ex, "Не удалось декодировать URL сегмент: {Segment}", segment);
                    return segment;
                }
            }
            
            return decoded;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка декодирования URL сегмента: {Segment}", segment);
            return segment; // Вернуть исходное значение при ошибке
        }
    }
    
    /// <summary>
    /// Проверка валидности декодированного значения
    /// </summary>
    private static bool IsValidDecodedValue(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return false;
        
        // Проверка на недопустимые управляющие символы (кроме пробелов)
        return !value.Any(c => char.IsControl(c) && !char.IsWhiteSpace(c));
    }
    
    /// <summary>
    /// Проверка валидности формата pageId
    /// </summary>
    private static bool IsValidPageIdFormat(string pageId)
    {
        if (string.IsNullOrWhiteSpace(pageId))
            return false;
        
        // PageId должен содержать только допустимые символы (буквы, цифры, дефисы, подчеркивания)
        return pageId.All(c => char.IsLetterOrDigit(c) || c == '-' || c == '_');
    }
}

