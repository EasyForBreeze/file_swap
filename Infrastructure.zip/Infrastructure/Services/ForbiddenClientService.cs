using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для работы с запрещенными клиентами (системные + кастомные)
/// </summary>
public class ForbiddenClientService : IForbiddenClientService
{
    private readonly IForbiddenClientRepository _forbiddenRepo;
    private readonly ILogger<ForbiddenClientService>? _logger;
    private readonly IMemoryCache? _cache;
    private readonly HashSet<string> _alwaysForbidden;
    private readonly TimeSpan _cacheExpiration;
    private readonly int _maxCachedItems;
    private readonly SemaphoreSlim _cacheSemaphore;
    private readonly IReadOnlySet<string>? _cachedAlwaysForbiddenSet;
    
    // Константы для валидации
    private const int MaxClientIdLength = 500;
    private const int MaxRealmLength = 500;
    private const long MaxCounterValue = long.MaxValue - 1000; // Запас для предотвращения переполнения
    
    private const string CacheKey = "ForbiddenClients_All";
    
    // Статистика кэша (thread-safe счетчики)
    private long _cacheHits = 0;
    private long _cacheMisses = 0;

    /// <summary>
    /// Инициализирует новый экземпляр <see cref="ForbiddenClientService"/>
    /// </summary>
    /// <param name="forbiddenRepo">Репозиторий для работы с запрещенными клиентами</param>
    /// <param name="forbiddenOptions">Настройки запрещенных клиентов</param>
    /// <param name="logger">Логгер для записи событий (опционально)</param>
    /// <param name="cache">Кэш для хранения данных (опционально)</param>
    /// <exception cref="ArgumentNullException">
    /// Выбрасывается если <paramref name="forbiddenRepo"/> равен <c>null</c>.
    /// </exception>
    public ForbiddenClientService(
        IForbiddenClientRepository forbiddenRepo,
        IOptions<ForbiddenSettings> forbiddenOptions,
        ILogger<ForbiddenClientService>? logger = null,
        IMemoryCache? cache = null)
    {
        _forbiddenRepo = forbiddenRepo ?? throw new ArgumentNullException(nameof(forbiddenRepo));
        _logger = logger;
        _cache = cache;
        _cacheSemaphore = new SemaphoreSlim(1, 1);
        
        // Безопасная обработка null для настроек
        var list = forbiddenOptions?.Value?.AlwaysForbiddenClientIds 
                   ?? new List<string>();
        
        // Фильтрация и нормализация: убираем null, пустые строки, пробелы
        _alwaysForbidden = new HashSet<string>(
            list
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .Select(s => SafeTrim(s))
                .Where(s => s != null && s.Length > 0 && s.Length <= MaxClientIdLength)
                .Select(s => s!),
            StringComparer.OrdinalIgnoreCase);
        
        // Кэшируем копию для GetAlwaysForbiddenSet
        _cachedAlwaysForbiddenSet = _alwaysForbidden.ToHashSet(StringComparer.OrdinalIgnoreCase);
        
        // Конфигурируемое время жизни кэша с валидацией
        var expiration = forbiddenOptions?.Value?.CacheExpiration ?? TimeSpan.FromMinutes(5);
        _cacheExpiration = expiration > TimeSpan.Zero 
            ? expiration 
            : TimeSpan.FromMinutes(5); // Минимальное значение по умолчанию
        
        // Конфигурируемый максимальный размер кэша с валидацией
        var maxItems = forbiddenOptions?.Value?.MaxCachedItems ?? 10000;
        _maxCachedItems = maxItems > 0 ? maxItems : 10000; // Минимальное значение по умолчанию
    }

    /// <summary>
    /// Безопасное обрезание строки с обработкой edge cases
    /// </summary>
    private static string? SafeTrim(string? value)
    {
        if (value == null)
        {
            return null;
        }
        
        try
        {
            return value.Trim();
        }
        catch
        {
            // В случае ошибки возвращаем исходное значение
            return value;
        }
    }
    
    /// <summary>
    /// Валидация параметров clientId и realm
    /// </summary>
    private static void ValidateClientParameters(string clientId, string realm)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(clientId, nameof(clientId));
        ArgumentException.ThrowIfNullOrWhiteSpace(realm, nameof(realm));
        
        if (clientId.Length > MaxClientIdLength)
        {
            throw new ArgumentException(
                $"ClientId превышает максимальную длину {MaxClientIdLength} символов.", 
                nameof(clientId));
        }
        
        if (realm.Length > MaxRealmLength)
        {
            throw new ArgumentException(
                $"Realm превышает максимальную длину {MaxRealmLength} символов.", 
                nameof(realm));
        }
    }
    
    /// <summary>
    /// Проверка, является ли клиент системным запрещенным (общая логика)
    /// </summary>
    private bool IsSystemForbiddenInternal(string? clientId)
    {
        if (string.IsNullOrWhiteSpace(clientId))
        {
            return false;
        }
        
        var normalized = SafeTrim(clientId);
        return normalized != null && _alwaysForbidden.Contains(normalized);
    }
    
    /// <summary>
    /// Безопасное увеличение счетчика с проверкой на переполнение
    /// </summary>
    private static long SafeIncrement(ref long location)
    {
        var current = Interlocked.Read(ref location);
        if (current >= MaxCounterValue)
        {
            // Сбрасываем счетчик при приближении к переполнению
            Interlocked.Exchange(ref location, 0);
            return 0;
        }
        return Interlocked.Increment(ref location);
    }
    
    /// <summary>
    /// Проверить, является ли клиент запрещенным (с учетом системных и кастомных запретов)
    /// </summary>
    /// <param name="clientId">Идентификатор клиента для проверки</param>
    /// <param name="realm">Название реалма, в котором находится клиент</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>
    /// <c>true</c> если клиент запрещен (системный или кастомный запрет), 
    /// <c>false</c> если клиент разрешен.
    /// В случае ошибки при обращении к БД возвращает <c>true</c> (fail-safe стратегия).
    /// </returns>
    /// <exception cref="ArgumentException">
    /// Выбрасывается если <paramref name="clientId"/> или <paramref name="realm"/> 
    /// равны <c>null</c>, пустой строке или превышают максимальную длину.
    /// </exception>
    /// <exception cref="OperationCanceledException">
    /// Выбрасывается если операция была отменена через <paramref name="cancellationToken"/>.
    /// </exception>
    /// <remarks>
    /// <para>
    /// Метод сначала проверяет системные запрещенные клиенты (быстрая проверка в памяти),
    /// затем обращается к БД для проверки кастомных запретов.
    /// </para>
    /// <para>
    /// Системные запрещенные клиенты применяются ко всем реалмам,
    /// кастомные запреты привязаны к конкретному реалму.
    /// </para>
    /// <para>
    /// В случае ошибки при обращении к БД метод возвращает <c>true</c> (fail-safe),
    /// что обеспечивает безопасность - лучше заблокировать клиента, чем разрешить доступ к запрещенному.
    /// </para>
    /// </remarks>
    public async Task<bool> IsForbiddenAsync(
        string clientId, 
        string realm, 
        CancellationToken cancellationToken = default)
    {
        ValidateClientParameters(clientId, realm);
        
        cancellationToken.ThrowIfCancellationRequested();
        
        try
        {
            // Нормализуем clientId для консистентности
            var clientIdNormalized = SafeTrim(clientId);
            if (clientIdNormalized == null)
            {
                return false;
            }
            
            // Быстрая проверка системных запрещенных клиентов
            if (IsSystemForbiddenInternal(clientIdNormalized))
            {
                return true;
            }

            // Проверка кастомных запретов (с привязкой к конкретному реалму)
            return await _forbiddenRepo.IsForbiddenAsync(clientId, realm, cancellationToken)
                .ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger?.LogError(
                ex, 
                "Ошибка при проверке запрещенного клиента. ClientId: {ClientId}, Realm: {Realm}", 
                clientId, realm);
            // Fail-safe: в случае ошибки считаем клиент запрещенным для безопасности
            return true;
        }
    }

    /// <summary>
    /// Проверить, является ли клиент системным запрещенным клиентом
    /// </summary>
    /// <param name="clientId">Идентификатор клиента для проверки</param>
    /// <returns>
    /// <c>true</c> если клиент является системным запрещенным, <c>false</c> в противном случае.
    /// </returns>
    /// <remarks>
    /// Метод выполняет быструю проверку в памяти без обращения к БД.
    /// </remarks>
    public bool IsSystemForbidden(string clientId)
    {
        return IsSystemForbiddenInternal(clientId);
    }

    /// <summary>
    /// Получить копию HashSet системных запрещенных клиентов
    /// </summary>
    /// <returns>
    /// Неизменяемая копия HashSet системных запрещенных клиентов.
    /// Возвращается копия коллекции для обеспечения инкапсуляции.
    /// </returns>
    /// <remarks>
    /// <para>
    /// Системные запрещенные клиенты настраиваются через конфигурацию приложения
    /// и применяются ко всем реалмам без исключений.
    /// </para>
    /// <para>
    /// Метод возвращает кэшированную копию коллекции, чтобы предотвратить изменение внутреннего состояния сервиса.
    /// </para>
    /// </remarks>
    public IReadOnlySet<string> GetAlwaysForbiddenSet()
    {
        return _cachedAlwaysForbiddenSet ?? new HashSet<string>(StringComparer.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Отфильтровать список клиентов, исключив запрещенные
    /// </summary>
    /// <param name="clients">Список клиентов для фильтрации</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>
    /// Отфильтрованный список клиентов без запрещенных.
    /// Элементы с <c>null</c> значениями или пустыми обязательными полями (<see cref="ClientSearchResult.ClientId"/>, 
    /// <see cref="ClientSearchResult.Realm"/>) также исключаются из результата.
    /// </returns>
    /// <exception cref="ArgumentNullException">
    /// Выбрасывается если <paramref name="clients"/> равен <c>null</c>.
    /// </exception>
    /// <exception cref="OperationCanceledException">
    /// Выбрасывается если операция была отменена через <paramref name="cancellationToken"/>.
    /// </exception>
    /// <remarks>
    /// <para>
    /// Метод фильтрует список клиентов, исключая:
    /// <list type="bullet">
    /// <item><description>Системные запрещенные клиенты (из конфигурации)</description></item>
    /// <item><description>Кастомные запрещенные клиенты (из БД, с кэшированием)</description></item>
    /// <item><description>Элементы с <c>null</c> значениями или пустыми обязательными полями</description></item>
    /// </list>
    /// </para>
    /// <para>
    /// Для оптимизации производительности кастомные запрещенные клиенты кэшируются.
    /// </para>
    /// <para>
    /// В случае ошибки при обращении к БД метод возвращает исходный список (fail-safe),
    /// чтобы не потерять данные при временных проблемах с БД.
    /// </para>
    /// </remarks>
    public async Task<IReadOnlyList<ClientSearchResult>> FilterForbiddenClientsAsync(
        IReadOnlyList<ClientSearchResult> clients,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(clients);
        
        if (clients.Count == 0)
        {
            return clients;
        }

        // Фильтруем null элементы и элементы с пустыми обязательными полями, валидируем длину
        var validClients = new List<ClientSearchResult>(clients.Count);
        foreach (var c in clients)
        {
            if (c != null && 
                !string.IsNullOrWhiteSpace(c.ClientId) && 
                !string.IsNullOrWhiteSpace(c.Realm) &&
                c.ClientId.Length <= MaxClientIdLength &&
                c.Realm.Length <= MaxRealmLength)
            {
                validClients.Add(c);
            }
        }
            
        if (validClients.Count == 0)
        {
            return Array.Empty<ClientSearchResult>();
        }

        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            // Получаем кастомные запрещенные клиенты из кэша или БД
            var forbiddenClients = await GetForbiddenClientsCachedAsync(cancellationToken)
                .ConfigureAwait(false);
            
            // Оптимизация: если нет запрещенных клиентов, фильтруем только системные
            if (forbiddenClients.Count == 0)
            {
                var result = new List<ClientSearchResult>(validClients.Count);
                foreach (var c in validClients)
                {
                    var normalizedClientId = SafeTrim(c.ClientId)?.ToLowerInvariant();
                    if (normalizedClientId != null && !_alwaysForbidden.Contains(normalizedClientId))
                    {
                        result.Add(c);
                    }
                }
                return result.AsReadOnly();
            }
            
            // Создаем HashSet с нормализованными данными один раз
            var forbiddenSet = new HashSet<(string ClientId, string Realm)>(
                forbiddenClients.Count,
                new TupleComparer(StringComparer.OrdinalIgnoreCase, StringComparer.OrdinalIgnoreCase));
                
            foreach (var fc in forbiddenClients)
            {
                var normalizedClientId = SafeTrim(fc.ClientId)?.ToLowerInvariant();
                var normalizedRealm = SafeTrim(fc.Realm)?.ToLowerInvariant();
                if (normalizedClientId != null && normalizedRealm != null)
                {
                    forbiddenSet.Add((normalizedClientId, normalizedRealm));
                }
            }

            // Оптимизация: создаем нормализованные версии клиентов один раз и фильтруем
            var resultList = new List<ClientSearchResult>(validClients.Count);
            foreach (var c in validClients)
            {
                var normalizedClientId = SafeTrim(c.ClientId)?.ToLowerInvariant();
                var normalizedRealm = SafeTrim(c.Realm)?.ToLowerInvariant();
                
                if (normalizedClientId != null && normalizedRealm != null &&
                    !_alwaysForbidden.Contains(normalizedClientId) &&
                    !forbiddenSet.Contains((normalizedClientId, normalizedRealm)))
                {
                    resultList.Add(c);
                }
            }
            
            return resultList.AsReadOnly();
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger?.LogError(
                ex, 
                "Ошибка при фильтрации запрещенных клиентов. Количество клиентов: {Count}", 
                validClients.Count);
            // В случае ошибки возвращаем исходный список (fail-safe)
            // validClients уже является List, преобразуем в IReadOnlyList
            return validClients.AsReadOnly();
        }
    }

    /// <summary>
    /// Инвалидировать кэш запрещенных клиентов
    /// </summary>
    /// <remarks>
    /// Вызывайте этот метод после добавления или удаления запрещенных клиентов,
    /// чтобы обеспечить актуальность кэшированных данных.
    /// </remarks>
    public void InvalidateCache()
    {
        if (_cache != null)
        {
            try
            {
                _cache.Remove(CacheKey);
                _logger?.LogDebug("Кэш запрещенных клиентов инвалидирован");
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Ошибка при инвалидации кэша запрещенных клиентов");
            }
        }
    }

    /// <summary>
    /// Получить статистику использования кэша
    /// </summary>
    /// <returns>
    /// Кортеж с количеством попаданий в кэш (Hits), промахов (Misses) и коэффициентом попаданий (HitRatio).
    /// </returns>
    /// <remarks>
    /// Метод использует Interlocked.Read для thread-safe чтения счетчиков.
    /// Статистика может быть немного неточной при одновременных обновлениях кэша.
    /// </remarks>
    public (long Hits, long Misses, double HitRatio) GetCacheStats()
    {
        // Используем Interlocked.Read для thread-safe чтения
        var hits = Interlocked.Read(ref _cacheHits);
        var misses = Interlocked.Read(ref _cacheMisses);
        var total = hits + misses;
        var hitRatio = total > 0 ? (double)hits / total : 0.0;
        return (hits, misses, hitRatio);
    }

    /// <summary>
    /// Получить список запрещенных клиентов из кэша или БД
    /// </summary>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>
    /// Список кортежей (ClientId, Realm) запрещенных клиентов.
    /// В случае ошибки возвращает пустой список.
    /// </returns>
    /// <remarks>
    /// <para>
    /// Метод использует кэш для уменьшения нагрузки на БД.
    /// Время жизни кэша настраивается через конфигурацию.
    /// </para>
    /// <para>
    /// При ошибке доступа к БД возвращается пустой список,
    /// что позволяет продолжить работу без кастомных запретов.
    /// </para>
    /// <para>
    /// Используется double-check locking pattern для предотвращения race condition.
    /// </para>
    /// </remarks>
    private async Task<List<(string ClientId, string Realm)>> GetForbiddenClientsCachedAsync(
        CancellationToken cancellationToken)
    {
        // Первая проверка кэша (без блокировки)
        if (_cache?.TryGetValue(CacheKey, out List<(string ClientId, string Realm)>? cached) == true && cached != null)
        {
            SafeIncrement(ref _cacheHits);
            _logger?.LogDebug(
                "Кэш запрещенных клиентов: попадание (hit). Количество: {Count}", 
                cached.Count);
            return cached;
        }

        // Блокировка для предотвращения race condition
        var semaphoreAcquired = false;
        try
        {
            await _cacheSemaphore.WaitAsync(cancellationToken).ConfigureAwait(false);
            semaphoreAcquired = true;
            
            // Double-check после получения блокировки
            if (_cache?.TryGetValue(CacheKey, out List<(string ClientId, string Realm)>? cachedAfterLock) == true && cachedAfterLock != null)
            {
                SafeIncrement(ref _cacheHits);
                _logger?.LogDebug(
                    "Кэш запрещенных клиентов: попадание (hit) после double-check. Количество: {Count}", 
                    cachedAfterLock.Count);
                return cachedAfterLock;
            }

            SafeIncrement(ref _cacheMisses);
            _logger?.LogDebug("Кэш запрещенных клиентов: промах (miss). Загрузка из БД...");
            
            System.Diagnostics.Stopwatch? stopwatch = null;
            try
            {
                stopwatch = System.Diagnostics.Stopwatch.StartNew();
            }
            catch
            {
                // Если Stopwatch не может быть создан, продолжаем без него
                _logger?.LogWarning("Не удалось создать Stopwatch для измерения времени");
            }
            
            try
            {
                var forbiddenClients = await _forbiddenRepo.GetAllForbiddenClientIdsAsync(cancellationToken)
                    .ConfigureAwait(false);
                
                // Валидация данных из БД с оптимизацией
                var validForbiddenClients = new List<(string ClientId, string Realm)>(forbiddenClients.Count);
                foreach (var fc in forbiddenClients)
                {
                    var clientId = SafeTrim(fc.ClientId);
                    var realm = SafeTrim(fc.Realm);
                    if (!string.IsNullOrWhiteSpace(clientId) && 
                        !string.IsNullOrWhiteSpace(realm) &&
                        clientId.Length <= MaxClientIdLength &&
                        realm.Length <= MaxRealmLength)
                    {
                        validForbiddenClients.Add((clientId, realm));
                    }
                }
                
                if (stopwatch != null)
                {
                    try
                    {
                        stopwatch.Stop();
                        _logger?.LogInformation(
                            "Загружено {Count} запрещенных клиентов из БД за {ElapsedMs}мс (после валидации: {ValidCount})", 
                            forbiddenClients.Count,
                            stopwatch.ElapsedMilliseconds,
                            validForbiddenClients.Count);
                    }
                    catch
                    {
                        _logger?.LogInformation(
                            "Загружено {Count} запрещенных клиентов из БД (после валидации: {ValidCount})", 
                            forbiddenClients.Count,
                            validForbiddenClients.Count);
                    }
                }
                else
                {
                    _logger?.LogInformation(
                        "Загружено {Count} запрещенных клиентов из БД (после валидации: {ValidCount})", 
                        forbiddenClients.Count,
                        validForbiddenClients.Count);
                }
                
                // Проверка на максимальный размер кэша
                if (validForbiddenClients.Count > _maxCachedItems)
                {
                    _logger?.LogWarning(
                        "Количество запрещенных клиентов ({Count}) превышает максимальное для кэширования ({Max}). " +
                        "Кэширование отключено для этого запроса.",
                        validForbiddenClients.Count, 
                        _maxCachedItems);
                    return validForbiddenClients; // Возвращаем без кэширования
                }
                
                // Устанавливаем в кэш только если кэш доступен
                if (_cache != null)
                {
                    try
                    {
                        var cacheOptions = new MemoryCacheEntryOptions
                        {
                            AbsoluteExpirationRelativeToNow = _cacheExpiration,
                            Size = 1 // Указываем размер для MemoryCache с SizeLimit
                        };
                        _cache.Set(CacheKey, validForbiddenClients, cacheOptions);
                    }
                    catch (Exception cacheEx)
                    {
                        _logger?.LogError(cacheEx, "Ошибка при установке данных в кэш");
                    }
                }
                
                return validForbiddenClients;
            }
            catch (Exception ex)
            {
                if (stopwatch != null)
                {
                    try
                    {
                        stopwatch.Stop();
                        _logger?.LogError(
                            ex, 
                            "Ошибка при получении списка запрещенных клиентов из БД за {ElapsedMs}мс", 
                            stopwatch.ElapsedMilliseconds);
                    }
                    catch
                    {
                        _logger?.LogError(ex, "Ошибка при получении списка запрещенных клиентов из БД");
                    }
                }
                else
                {
                    _logger?.LogError(ex, "Ошибка при получении списка запрещенных клиентов из БД");
                }
                // Возвращаем пустой список в случае ошибки
                return new List<(string ClientId, string Realm)>();
            }
        }
        finally
        {
            // Гарантируем освобождение semaphore
            if (semaphoreAcquired)
            {
                try
                {
                    _cacheSemaphore.Release();
                }
                catch (Exception ex)
                {
                    _logger?.LogError(ex, "Ошибка при освобождении semaphore");
                }
            }
        }
    }

    /// <summary>
    /// Вспомогательный класс для сравнения кортежей (ClientId, Realm) с учетом регистра
    /// </summary>
    private sealed class TupleComparer : IEqualityComparer<(string ClientId, string Realm)>
    {
        private readonly StringComparer _clientIdComparer;
        private readonly StringComparer _realmComparer;

        public TupleComparer(StringComparer clientIdComparer, StringComparer realmComparer)
        {
            _clientIdComparer = clientIdComparer ?? throw new ArgumentNullException(nameof(clientIdComparer));
            _realmComparer = realmComparer ?? throw new ArgumentNullException(nameof(realmComparer));
        }

        public bool Equals((string ClientId, string Realm) x, (string ClientId, string Realm) y)
        {
            // Оптимизация: сначала проверяем ссылочное равенство
            if (ReferenceEquals(x.ClientId, y.ClientId) && ReferenceEquals(x.Realm, y.Realm))
            {
                return true;
            }
            
            return _clientIdComparer.Equals(x.ClientId, y.ClientId) &&
                   _realmComparer.Equals(x.Realm, y.Realm);
        }

        public int GetHashCode((string ClientId, string Realm) obj)
        {
            try
            {
                // Используем более надежный алгоритм для вычисления хэш-кода
                var clientIdHash = obj.ClientId != null 
                    ? _clientIdComparer.GetHashCode(obj.ClientId) 
                    : 0;
                var realmHash = obj.Realm != null 
                    ? _realmComparer.GetHashCode(obj.Realm) 
                    : 0;
                
                // Комбинируем хэш-коды с использованием простых чисел для уменьшения коллизий
                unchecked
                {
                    return (clientIdHash * 397) ^ realmHash;
                }
            }
            catch
            {
                // В случае ошибки возвращаем базовый хэш-код
                return HashCode.Combine(obj.ClientId, obj.Realm);
            }
        }
    }
}
