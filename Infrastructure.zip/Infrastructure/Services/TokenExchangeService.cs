using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Text.Json.Serialization;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;
using new_assistant.Core.Models;
using new_assistant.Core.Exceptions;

namespace new_assistant.Infrastructure.Services;

public class TokenExchangeService : ITokenExchangeService, IDisposable, IAsyncDisposable
{
    private readonly int _safetyWindowSeconds;
    private readonly int _maxCacheSize;
    private readonly TimeSpan _defaultTokenCacheTtl;
    private readonly int _maxRetries;
    private readonly TimeSpan _initialRetryDelay;
    private readonly bool _useExponentialBackoff;
    private readonly bool _enableCircuitBreaker;
    private readonly int _circuitBreakerFailureThreshold;
    private readonly TimeSpan _circuitBreakerOpenDuration;
    
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ITokenRefreshService _tokenRefreshService;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly TokenExchangeSettings _settings;
    private readonly ILogger<TokenExchangeService> _logger;
    
    // Кэш с отслеживанием последнего доступа для LRU логики
    private readonly ConcurrentDictionary<string, CacheEntry> _cache = new();
    // Защита от параллельных запросов для одного реалма
    private readonly ConcurrentDictionary<string, SemaphoreSlim> _exchangeLocks = new();
    // Отслеживание последнего использования семафоров для очистки
    private readonly ConcurrentDictionary<string, DateTime> _semaphoreLastUsed = new();
    
    // Circuit breaker для защиты от каскадных сбоев
    private readonly ConcurrentDictionary<string, CircuitBreakerState> _circuitBreakers = new();
    
    // Метрики
    private long _exchangeRequests = 0;
    private long _exchangeSuccesses = 0;
    private long _exchangeFailures = 0;
    private long _cacheHits = 0;
    private long _cacheMisses = 0;
    
    private readonly Timer? _cleanupTimer;
    private volatile int _disposed = 0; // Используем int для Interlocked операций
    private const int MaxRealmLength = 256;
    private const int MaxTokenLength = 10000;
    private const int MaxCacheKeyLength = 512;

    public TokenExchangeService(
        IHttpClientFactory httpClientFactory,
        ITokenRefreshService tokenRefreshService,
        IHttpContextAccessor httpContextAccessor,
        IOptions<TokenExchangeSettings> settings,
        ILogger<TokenExchangeService> logger)
    {
        _httpClientFactory = httpClientFactory ?? throw new ArgumentNullException(nameof(httpClientFactory));
        _tokenRefreshService = tokenRefreshService ?? throw new ArgumentNullException(nameof(tokenRefreshService));
        _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
        _settings = settings?.Value ?? throw new ArgumentNullException(nameof(settings));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        
        // Инициализируем значения из настроек
        _safetyWindowSeconds = _settings.SafetyWindowSeconds > 0 ? _settings.SafetyWindowSeconds : 15;
        _maxCacheSize = _settings.MaxCacheSize > 0 ? _settings.MaxCacheSize : 100;
        
        // Валидация MaxCacheSize
        if (_maxCacheSize == 0)
        {
            _logger.LogWarning("MaxCacheSize равен 0, устанавливаем минимальное значение 1");
            _maxCacheSize = 1;
        }
        _defaultTokenCacheTtl = _settings.DefaultTokenCacheTtl > TimeSpan.Zero 
            ? _settings.DefaultTokenCacheTtl 
            : TimeSpan.FromMinutes(30);
        _maxRetries = _settings.MaxRetryAttempts >= 0 
            ? Math.Min(_settings.MaxRetryAttempts, 10) // Ограничиваем максимум до 10 для защиты от ошибок конфигурации
            : 2;
        
        if (_settings.MaxRetryAttempts > 10)
        {
            _logger.LogWarning("MaxRetryAttempts слишком большое ({Value}), ограничиваем до 10", 
                _settings.MaxRetryAttempts);
        }
        _initialRetryDelay = _settings.InitialRetryDelay > TimeSpan.Zero 
            ? _settings.InitialRetryDelay 
            : TimeSpan.FromSeconds(1);
        _useExponentialBackoff = _settings.UseExponentialBackoff;
        _enableCircuitBreaker = _settings.EnableCircuitBreaker;
        _circuitBreakerFailureThreshold = _settings.CircuitBreakerFailureThreshold > 0 
            ? _settings.CircuitBreakerFailureThreshold 
            : 5;
        _circuitBreakerOpenDuration = _settings.CircuitBreakerOpenDuration > TimeSpan.Zero
            ? _settings.CircuitBreakerOpenDuration
            : TimeSpan.FromMinutes(5);
        
        // Валидация настроек при старте
        ValidateSettings();
        
        // Запускаем периодическую очистку неиспользуемых семафоров
        if (_settings.SemaphoreCleanupInterval > TimeSpan.Zero)
        {
            _cleanupTimer = new Timer(CleanupIdleSemaphores, null, 
                _settings.SemaphoreCleanupInterval, 
                _settings.SemaphoreCleanupInterval);
            _logger.LogDebug("Запущена периодическая очистка семафоров. Интервал: {Interval}, Максимальное время простоя: {MaxIdleTime}",
                _settings.SemaphoreCleanupInterval, _settings.SemaphoreMaxIdleTime);
        }
    }

    /// <summary>
    /// Валидация настроек при старте сервиса
    /// </summary>
    private void ValidateSettings()
    {
        if (_settings.Realms == null || _settings.Realms.Count == 0)
        {
            _logger.LogWarning("TokenExchangeSettings не содержит ни одного реалма");
            return; // Это не ошибка, просто нет настроенных реалмов
        }
        
        foreach (var realm in _settings.Realms)
        {
            if (string.IsNullOrWhiteSpace(realm.Realm))
            {
                throw new TokenExchangeConfigurationException(null,
                    "TokenExchangeSettings содержит реалм с пустым именем Realm");
            }
            
            if (string.IsNullOrWhiteSpace(realm.ClientId))
            {
                throw new TokenExchangeConfigurationException(realm.Realm,
                    $"TokenExchangeSettings для реалма '{realm.Realm}' содержит пустой ClientId");
            }
            
            if (string.IsNullOrWhiteSpace(realm.ClientSecret))
            {
                throw new TokenExchangeConfigurationException(realm.Realm,
                    $"TokenExchangeSettings для реалма '{realm.Realm}' содержит пустой ClientSecret");
            }
            
            if (string.IsNullOrWhiteSpace(realm.TokenEndpoint))
            {
                throw new TokenExchangeConfigurationException(realm.Realm,
                    $"TokenExchangeSettings для реалма '{realm.Realm}' содержит пустой TokenEndpoint");
            }
            
            if (!Uri.TryCreate(realm.TokenEndpoint, UriKind.Absolute, out var tokenUri))
            {
                throw new TokenExchangeConfigurationException(realm.Realm,
                    $"TokenExchangeSettings для реалма '{realm.Realm}' содержит невалидный TokenEndpoint: {realm.TokenEndpoint}");
            }
            
            if (!string.IsNullOrWhiteSpace(realm.SubjectIssuer))
            {
                // Проверяем, что SubjectIssuer является валидным реалмом (может быть в другом источнике)
                if (!_settings.Realms.Any(r => string.Equals(r.Realm, realm.SubjectIssuer, StringComparison.OrdinalIgnoreCase)))
                {
                    _logger.LogWarning(
                        "TokenExchangeSettings для реалма '{Realm}' указывает на SubjectIssuer '{SubjectIssuer}', " +
                        "который не найден в списке реалмов. Это может быть нормально, если SubjectIssuer находится в другом источнике.",
                        realm.Realm, realm.SubjectIssuer);
                }
            }
        }
        
        _logger.LogDebug("TokenExchangeSettings успешно валидированы. Найдено реалмов: {RealmCount}", 
            _settings.Realms.Count);
    }
    
    /// <summary>
    /// Очистка неиспользуемых семафоров и circuit breaker states
    /// </summary>
    private void CleanupIdleSemaphores(object? state)
    {
        if (IsDisposed()) return;
        
        try
        {
            var cutoffTime = DateTime.UtcNow - _settings.SemaphoreMaxIdleTime;
            var keysToRemove = new List<string>();
            
            // Оптимизация: используем snapshot ключей без ToArray для лучшей производительности
            var snapshotKeys = new List<string>(_exchangeLocks.Keys);
            
            // Находим семафоры, которые не используются и не имеют активных записей в кэше
            foreach (var key in snapshotKeys)
            {
                if (!_exchangeLocks.TryGetValue(key, out _))
                {
                    continue; // Ключ уже удален другим потоком
                }
                
                var lastUsed = _semaphoreLastUsed.TryGetValue(key, out var used) ? used : DateTime.MinValue;
                
                // Удаляем семафор, если он не используется и нет записи в кэше
                if (!_cache.TryGetValue(key, out _) && lastUsed < cutoffTime)
                {
                    keysToRemove.Add(key);
                }
            }
            
            // Удаляем найденные семафоры с таймаутом
            var cleanupTimeout = TimeSpan.FromSeconds(30);
            var cleanupStartTime = DateTime.UtcNow;
            
            foreach (var key in keysToRemove)
            {
                // Проверяем таймаут для предотвращения долгой блокировки
                if (DateTime.UtcNow - cleanupStartTime > cleanupTimeout)
                {
                    _logger.LogWarning("Очистка семафоров превысила таймаут {Timeout}, прерываем операцию", cleanupTimeout);
                    break;
                }
                
                if (_exchangeLocks.TryRemove(key, out var semaphore))
                {
                    try
                    {
                        // Пытаемся взять семафор, чтобы убедиться, что он не используется
                        if (semaphore.Wait(0)) // Неблокирующая попытка
                        {
                            semaphore.Release();
                            semaphore.Dispose();
                            _semaphoreLastUsed.TryRemove(key, out _);
                            _logger.LogDebug("Удален неиспользуемый семафор для ключа {Key}", key);
                        }
                        else
                        {
                            // Семафор занят, не возвращаем его - пусть будет создан заново при необходимости
                            // Это безопаснее, чем возвращать занятый семафор
                            _logger.LogDebug("Семафор для ключа {Key} занят, пропускаем удаление", key);
                        }
                    }
                    catch (ObjectDisposedException)
                    {
                        // Семафор уже освобожден, это нормально
                        _semaphoreLastUsed.TryRemove(key, out _);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Ошибка при освобождении семафора для ключа {Key}", key);
                        // Не возвращаем семафор обратно - пусть будет создан заново при необходимости
                    }
                }
            }
            
            if (keysToRemove.Count > 0)
            {
                _logger.LogInformation(
                    "Очищено {Count} неиспользуемых семафоров. Осталось: {Remaining}",
                    keysToRemove.Count, _exchangeLocks.Count);
            }
            
            // Очистка устаревших circuit breaker states
            CleanupOldCircuitBreakers();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при периодической очистке семафоров");
        }
    }
    
    /// <summary>
    /// Очистка устаревших circuit breaker states
    /// </summary>
    private void CleanupOldCircuitBreakers()
    {
        if (!_enableCircuitBreaker) return;
        
        try
        {
            var now = DateTime.UtcNow;
            var cutoffTime = now - TimeSpan.FromHours(24); // Удаляем неиспользуемые больше 24 часов
            
            // Оптимизация: используем snapshot ключей без ToArray
            var keysToRemove = new List<string>();
            foreach (var kvp in _circuitBreakers)
            {
                if (kvp.Value.LastSuccessAt < cutoffTime && 
                    (!kvp.Value.OpenedAt.HasValue || kvp.Value.OpenedAt.Value < cutoffTime))
                {
                    keysToRemove.Add(kvp.Key);
                }
            }
            
            foreach (var key in keysToRemove)
            {
                _circuitBreakers.TryRemove(key, out _);
            }
            
            if (keysToRemove.Count > 0)
            {
                _logger.LogDebug("Очищено {Count} устаревших circuit breaker states. Осталось: {Remaining}",
                    keysToRemove.Count, _circuitBreakers.Count);
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при очистке устаревших circuit breaker states");
        }
    }

    /// <summary>
    /// Проверить, поддерживается ли token exchange для указанного реалма
    /// </summary>
    /// <param name="targetRealm">Название реалма для проверки</param>
    /// <returns>true если реалм настроен в конфигурации TokenExchangeSettings</returns>
    /// <exception cref="ObjectDisposedException">Выбрасывается если сервис был освобожден</exception>
    public bool IsRealmSupported(string targetRealm)
    {
        // Проверка disposed выполняется внутри метода, если нужна блокировка
        return GetRealmSettings(targetRealm) != null;
    }

    /// <summary>
    /// Проверить, разрешен ли доступ к указанному реалму.
    /// Реалм разрешен если он поддерживается или является SubjectIssuer для другого настроенного реалма.
    /// </summary>
    /// <param name="targetRealm">Название реалма для проверки</param>
    /// <returns>true если реалм поддерживается или является SubjectIssuer для другого реалма</returns>
    /// <exception cref="ObjectDisposedException">Выбрасывается если сервис был освобожден</exception>
    public bool IsRealmAllowed(string targetRealm)
    {
        // Проверка disposed выполняется внутри метода, если нужна блокировка
        if (_settings.Realms.Count == 0)
        {
            return true;
        }

        return IsRealmSupported(targetRealm) || IsSubjectIssuer(targetRealm);
    }

    /// <summary>
    /// Получить access token для указанного реалма через token exchange.
    /// Использует кэширование и автоматическое обновление токенов.
    /// </summary>
    /// <param name="targetRealm">Целевой реалм для получения токена (не может быть null или пустым)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>
    /// Результат token exchange с access token и claims, или null при ошибке.
    /// Возвращает null если:
    /// - Реалм не настроен в конфигурации
    /// - Circuit breaker открыт для данного реалма
    /// - Не удалось получить subject_token из HttpContext
    /// - Token exchange запрос завершился ошибкой после всех retry попыток
    /// </returns>
    /// <exception cref="ObjectDisposedException">Выбрасывается если сервис был освобожден</exception>
    /// <exception cref="ArgumentException">Выбрасывается если targetRealm равен null или пустому</exception>
    /// <example>
    /// <code>
    /// var result = await tokenExchangeService.GetTokenForRealmAsync("my-realm");
    /// if (result != null)
    /// {
    ///     var token = result.AccessToken;
    ///     // Использовать token для запросов к API
    /// }
    /// </code>
    /// </example>
    public async Task<TokenExchangeResult?> GetTokenForRealmAsync(string targetRealm, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(targetRealm))
        {
            throw new ArgumentException("Target realm cannot be null or empty", nameof(targetRealm));
        }
        
        // Валидация длины targetRealm
        if (targetRealm.Length > MaxRealmLength)
        {
            throw new ArgumentException($"Target realm length cannot exceed {MaxRealmLength} characters", nameof(targetRealm));
        }
        
        // Проверка disposed выполняется внутри блокировки
        
        var correlationId = GetCorrelationId();
        
        var realmSettings = GetRealmSettings(targetRealm);
        if (realmSettings == null)
        {
            _logger.LogWarning("Запрошен token exchange для не сконфигурированного реалма {Realm}. CorrelationId: {CorrelationId}", 
                targetRealm, correlationId);
            return null;
        }
        
        // Проверяем circuit breaker
        if (IsCircuitBreakerOpen(realmSettings.Realm))
        {
            _logger.LogWarning("Circuit breaker открыт для реалма {Realm}, пропускаем запрос. CorrelationId: {CorrelationId}", 
                realmSettings.Realm, correlationId);
            return null;
        }

        var cacheKey = BuildCacheKey(targetRealm);
        
        // Увеличиваем счетчик запросов с защитой от переполнения
        IncrementMetricSafely(ref _exchangeRequests);
        
        _logger.LogInformation("Начало token exchange для реалма {Realm}. CorrelationId: {CorrelationId}", 
            targetRealm, correlationId);
        
        // Проверяем кэш перед блокировкой
        if (_cache.TryGetValue(cacheKey, out var cachedEntry))
        {
            // Создаем новую запись с обновленным LastAccessed для thread safety
            var updatedEntry = new CacheEntry 
            { 
                Token = cachedEntry.Token, 
                LastAccessed = DateTime.UtcNow 
            };
            _cache[cacheKey] = updatedEntry;
            
            if (!IsExpired(cachedEntry.Token.ExpiresAtUtc))
            {
                IncrementMetricSafely(ref _cacheHits);
                _logger.LogDebug("Токен для реалма {Realm} получен из кэша. CorrelationId: {CorrelationId}", 
                    targetRealm, correlationId);
                return ToResult(cachedEntry.Token);
            }

            if (!string.IsNullOrWhiteSpace(cachedEntry.Token.RefreshToken))
            {
                var refreshed = await TryRefreshAsync(realmSettings, cachedEntry.Token.RefreshToken!, cancellationToken);
                if (refreshed != null)
                {
                    _cache[cacheKey] = new CacheEntry 
                    { 
                        Token = refreshed, 
                        LastAccessed = DateTime.UtcNow 
                    };
                    _logger.LogInformation("Токен для реалма {Realm} обновлен через refresh. CorrelationId: {CorrelationId}", 
                        targetRealm, correlationId);
                    return ToResult(refreshed);
                }
            }

            // Токен истек и не удалось обновить - удаляем из кэша
            TryCleanupCacheEntry(cacheKey);
        }
        else
        {
            IncrementMetricSafely(ref _cacheMisses);
        }
        
        // Периодически очищаем истекшие записи из кэша (каждый 10-й запрос для производительности)
        if (_exchangeRequests % 10 == 0)
        {
            CleanupExpiredCacheEntries();
        }

        // Получаем или создаем семафор для защиты от параллельных запросов
        var semaphore = _exchangeLocks.GetOrAdd(cacheKey, _ => new SemaphoreSlim(1, 1));
        _semaphoreLastUsed[cacheKey] = DateTime.UtcNow; // Отслеживаем использование
        
        await semaphore.WaitAsync(cancellationToken);
        try
        {
            // Проверка disposed внутри блокировки для потокобезопасности
            ThrowIfDisposed();
            
            // Повторная проверка кэша после получения блокировки (double-check pattern)
            if (_cache.TryGetValue(cacheKey, out var cachedAfterLock))
            {
                // Создаем новую запись с обновленным LastAccessed для thread safety
                var updatedAfterLock = new CacheEntry 
                { 
                    Token = cachedAfterLock.Token, 
                    LastAccessed = DateTime.UtcNow 
                };
                _cache[cacheKey] = updatedAfterLock;
                
                if (!IsExpired(cachedAfterLock.Token.ExpiresAtUtc))
                {
                    _logger.LogDebug("Токен для реалма {Realm} получен из кэша после блокировки. CorrelationId: {CorrelationId}", 
                        targetRealm, correlationId);
                    return ToResult(cachedAfterLock.Token);
                }
            }

            // Пытаемся получить токен через ITokenRefreshService (требует Circuit ID)
            _logger.LogDebug("Попытка получения subject_token через CircuitTokenService для реалма {Realm}. CorrelationId: {CorrelationId}", 
                targetRealm, correlationId);
            var subjectToken = await _tokenRefreshService.GetValidAccessTokenAsync();
            
            // Если не удалось получить через Circuit, пробуем напрямую из HttpContext
            if (string.IsNullOrWhiteSpace(subjectToken))
            {
                _logger.LogInformation("Не удалось получить токен через CircuitTokenService (нет Circuit ID), пробуем из HttpContext для реалма {Realm}. CorrelationId: {CorrelationId}", 
                    targetRealm, correlationId);
                subjectToken = await GetTokenFromHttpContextAsync(cancellationToken);
            }
            
            if (string.IsNullOrWhiteSpace(subjectToken))
            {
                _logger.LogError("Не удалось получить subject_token для token exchange (realm {Realm}). Попробованы CircuitTokenService и HttpContext. CorrelationId: {CorrelationId}", 
                    targetRealm, correlationId);
                return null;
            }
            
            // Валидация длины subjectToken
            if (subjectToken.Length > MaxTokenLength)
            {
                _logger.LogError("Subject token слишком длинный ({Length} символов, максимум {MaxLength}) для реалма {Realm}. CorrelationId: {CorrelationId}", 
                    subjectToken.Length, MaxTokenLength, targetRealm, correlationId);
                return null;
            }
            
            _logger.LogInformation("Subject_token для реалма {Realm} получен, длина: {Length}. CorrelationId: {CorrelationId}", 
                targetRealm, subjectToken.Length, correlationId);

            var exchanged = await ExchangeAsync(realmSettings, subjectToken, correlationId, cancellationToken);
            if (exchanged == null)
            {
                IncrementMetricSafely(ref _exchangeFailures);
                RecordCircuitBreakerFailure(realmSettings.Realm);
                _logger.LogWarning("Token exchange вернул null для реалма {Realm}, очищаем кэш. CorrelationId: {CorrelationId}", 
                    targetRealm, correlationId);
                // Очищаем кэш при ошибке, чтобы не использовать невалидный токен
                TryCleanupCacheEntry(cacheKey);
                return null;
            }
            
            RecordCircuitBreakerSuccess(realmSettings.Realm);
            _logger.LogInformation("Token exchange успешно завершен для реалма {Realm}. CorrelationId: {CorrelationId}", 
                targetRealm, correlationId);
            IncrementMetricSafely(ref _exchangeSuccesses);

            // Проверяем размер кэша перед добавлением и применяем LRU логику
            if (_cache.Count >= _maxCacheSize)
            {
                EvictLeastRecentlyUsed();
            }
            
            _cache[cacheKey] = new CacheEntry 
            { 
                Token = exchanged, 
                LastAccessed = DateTime.UtcNow 
            };
            _logger.LogDebug("Токен для реалма {Realm} сохранен в кэш. Размер кэша: {CacheSize}/{MaxSize}", 
                targetRealm, _cache.Count, _maxCacheSize);
            return ToResult(exchanged);
        }
        finally
        {
            semaphore.Release();
        }
    }

    /// <summary>
    /// Определяет, нужно ли повторять запрос при данном HTTP статусе
    /// </summary>
    private static bool ShouldRetry(HttpStatusCode statusCode)
    {
        // Повторяем только для временных ошибок сервера или сетевых проблем
        return statusCode == HttpStatusCode.RequestTimeout ||
               statusCode == HttpStatusCode.ServiceUnavailable ||
               statusCode == HttpStatusCode.GatewayTimeout ||
               statusCode == HttpStatusCode.TooManyRequests;
    }
    
    /// <summary>
    /// Выполнить token exchange с retry логикой при временных сбоях
    /// </summary>
    /// <param name="realmSettings">Настройки реалма</param>
    /// <param name="subjectToken">Subject token для обмена</param>
    /// <param name="correlationId">Корреляционный ID для логирования</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Кэшированный токен или null при ошибке</returns>
    private async Task<CachedToken?> ExchangeAsync(TokenExchangeRealmSettings realmSettings, string subjectToken, string correlationId, CancellationToken cancellationToken)
    {
        try
        {
            // Используем именованный HttpClient для token exchange (с игнорированием SSL ошибок)
            _logger.LogInformation("Создание HttpClient 'TokenExchange' для реалма {Realm}. CorrelationId: {CorrelationId}", 
                realmSettings.Realm, correlationId);
            var httpClient = _httpClientFactory.CreateClient("TokenExchange");
            
            // Убеждаемся, что HttpClient правильно настроен
            if (httpClient == null)
            {
                _logger.LogError("Не удалось создать HttpClient 'TokenExchange' для реалма {Realm}. CorrelationId: {CorrelationId}", 
                    realmSettings.Realm, correlationId);
                return null;
            }
            
            _logger.LogInformation("HttpClient 'TokenExchange' успешно создан для реалма {Realm}, BaseAddress: {BaseAddress}, Timeout: {Timeout}. CorrelationId: {CorrelationId}", 
                realmSettings.Realm, httpClient.BaseAddress?.ToString() ?? "null", httpClient.Timeout, correlationId);
            
            // Маскируем ClientId для безопасности
            var maskedClientId = MaskClientId(realmSettings.ClientId);
            
            // Логируем параметры запроса (без секретов, с маскированным client_id)
            _logger.LogInformation("Параметры token exchange для realm {Realm}: grant_type=urn:ietf:params:oauth:grant-type:token-exchange, client_id={ClientId}, subject_issuer={SubjectIssuer}, endpoint={TokenEndpoint}. CorrelationId: {CorrelationId}", 
                realmSettings.Realm, maskedClientId, realmSettings.SubjectIssuer, realmSettings.TokenEndpoint, correlationId);

            _logger.LogInformation("Отправка token exchange запроса для realm {Realm} на endpoint {TokenEndpoint}. CorrelationId: {CorrelationId}", 
                realmSettings.Realm, realmSettings.TokenEndpoint, correlationId);
            
            HttpResponseMessage? response = null;
            var retryDelay = _initialRetryDelay;
            
            try
            {
                for (int attempt = 0; attempt <= _maxRetries; attempt++)
                {
                    try
                    {
                        if (attempt > 0)
                        {
                            // Проверяем отмену перед задержкой
                            cancellationToken.ThrowIfCancellationRequested();
                            
                            _logger.LogInformation("Повторная попытка {Attempt}/{MaxRetries} token exchange для realm {Realm} после задержки {Delay}ms. CorrelationId: {CorrelationId}", 
                                attempt, _maxRetries, realmSettings.Realm, retryDelay.TotalMilliseconds, correlationId);
                            await Task.Delay(retryDelay, cancellationToken);
                            
                            // Проверяем отмену после задержки
                            cancellationToken.ThrowIfCancellationRequested();
                            
                            // Применяем экспоненциальную задержку, если включена
                            // Используем битовый сдвиг вместо Math.Pow для степеней двойки
                            if (_useExponentialBackoff)
                            {
                                var multiplier = 1L << (attempt - 1); // 2^(attempt-1) через битовый сдвиг
                                retryDelay = TimeSpan.FromMilliseconds(retryDelay.TotalMilliseconds * multiplier);
                            }
                        }
                        
                        // Создаем новый requestContent для каждой попытки (нельзя повторно использовать)
                        using var attemptRequestContent = new FormUrlEncodedContent(new[]
                        {
                            new KeyValuePair<string, string>("grant_type", "urn:ietf:params:oauth:grant-type:token-exchange"),
                            new KeyValuePair<string, string>("client_id", realmSettings.ClientId),
                            new KeyValuePair<string, string>("client_secret", realmSettings.ClientSecret),
                            new KeyValuePair<string, string>("subject_token", subjectToken),
                            new KeyValuePair<string, string>("subject_issuer", realmSettings.SubjectIssuer)
                        });
                        
                        // Логируем Content-Type только для первой попытки
                        if (attempt == 0)
                        {
                            _logger.LogInformation("Content-Type запроса: {ContentType}", attemptRequestContent.Headers.ContentType?.ToString() ?? "null");
                        }
                        
                        // Освобождаем предыдущий response перед новым запросом (если был)
                        response?.Dispose();
                        response = await httpClient.PostAsync(realmSettings.TokenEndpoint, attemptRequestContent, cancellationToken);
                        
                        _logger.LogInformation("Получен ответ от token exchange для realm {Realm}: Status={Status}, Attempt={Attempt}. CorrelationId: {CorrelationId}", 
                            realmSettings.Realm, response.StatusCode, attempt + 1, correlationId);
                        
                        // Если успешный ответ или неуспешный не требующий retry - выходим из цикла
                        if (response.IsSuccessStatusCode || !ShouldRetry(response.StatusCode) || attempt == _maxRetries)
                        {
                            break;
                        }
                        
                        _logger.LogWarning("Неуспешный ответ {StatusCode} при token exchange для realm {Realm}, попытка {Attempt}/{MaxRetries}. CorrelationId: {CorrelationId}", 
                            response.StatusCode, realmSettings.Realm, attempt + 1, _maxRetries + 1, correlationId);
                    }
                    catch (TaskCanceledException) when (cancellationToken.IsCancellationRequested)
                    {
                        _logger.LogWarning("Token exchange отменен для realm {Realm}. CorrelationId: {CorrelationId}", 
                            realmSettings.Realm, correlationId);
                        response?.Dispose();
                        return null;
                    }
                    catch (TaskCanceledException tce) when (tce.InnerException is TimeoutException)
                    {
                        _logger.LogError("Таймаут при token exchange для realm {Realm} на endpoint {TokenEndpoint}. Timeout: {Timeout}, Attempt: {Attempt}/{MaxRetries}. CorrelationId: {CorrelationId}", 
                            realmSettings.Realm, realmSettings.TokenEndpoint, httpClient.Timeout, attempt + 1, _maxRetries + 1, correlationId);
                        
                        if (attempt == _maxRetries)
                        {
                            return null;
                        }
                        // Продолжаем retry для таймаутов
                    }
                    catch (TaskCanceledException tce)
                    {
                        _logger.LogError(tce, "Запрос отменен при token exchange для realm {Realm}, Attempt: {Attempt}/{MaxRetries}. CorrelationId: {CorrelationId}", 
                            realmSettings.Realm, attempt + 1, _maxRetries + 1, correlationId);
                        
                        if (attempt == _maxRetries)
                        {
                            return null;
                        }
                        // Продолжаем retry если не отменено пользователем
                    }
                    catch (HttpRequestException hre)
                    {
                        _logger.LogWarning(hre, "Временная ошибка сети при token exchange для realm {Realm}, Attempt: {Attempt}/{MaxRetries}. CorrelationId: {CorrelationId}", 
                            realmSettings.Realm, attempt + 1, _maxRetries + 1, correlationId);
                        
                        if (attempt == _maxRetries)
                        {
                            return null;
                        }
                        // Продолжаем retry для временных ошибок сети
                    }
                }
                
                // Проверяем, что получили ответ после всех попыток
                if (response == null)
                {
                    _logger.LogError("Token exchange не вернул ответ для realm {Realm} после всех попыток ({MaxRetries} попыток). CorrelationId: {CorrelationId}", 
                        realmSettings.Realm, _maxRetries + 1, correlationId);
                    return null;
                }
                
                if (!response.IsSuccessStatusCode)
                {
                    string error;
                    try
                    {
                        error = await response.Content.ReadAsStringAsync(cancellationToken);
                    }
                    catch (Exception readEx)
                    {
                        _logger.LogWarning(readEx, "Не удалось прочитать содержимое ответа при ошибке для realm {Realm}. CorrelationId: {CorrelationId}",
                            realmSettings.Realm, correlationId);
                        error = "Не удалось прочитать содержимое ответа";
                    }
                    
                    // Используем специфичное исключение для логирования, но не выбрасываем его, так как интерфейс возвращает null
                    var networkException = new TokenExchangeNetworkException(
                        realmSettings.Realm,
                        $"Token exchange завершился ошибкой: {response.StatusCode} {error}",
                        response.StatusCode);
                    
                    _logger.LogError(networkException, "Token exchange завершился ошибкой для realm {Realm}: {Status} {Error}. CorrelationId: {CorrelationId}",
                        realmSettings.Realm, response.StatusCode, error, correlationId);
                    
                    // Дополнительная диагностика: логируем заголовки запроса
                    if (response.RequestMessage != null)
                    {
                        _logger.LogDebug("Request Content-Type: {ContentType}", 
                            response.RequestMessage.Content?.Headers.ContentType?.ToString() ?? "null");
                        
                        // Логируем первые заголовки запроса
                        var requestHeaders = response.RequestMessage.Headers.Take(5).Select(h => $"{h.Key}={string.Join(",", h.Value.Take(1))}");
                        _logger.LogDebug("Request headers (first 5): {Headers}", string.Join("; ", requestHeaders));
                    }
                    
                    return null;
                }

                _logger.LogInformation("Token exchange успешен для realm {Realm}, парсим ответ. CorrelationId: {CorrelationId}", 
                    realmSettings.Realm, correlationId);
                
                TokenResponse? tokenResponse;
                try
                {
                    tokenResponse = await response.Content.ReadFromJsonAsync<TokenResponse>(cancellationToken: cancellationToken);
                }
                catch (Exception jsonEx)
                {
                    _logger.LogError(jsonEx, "Ошибка десериализации ответа token exchange для realm {Realm}. CorrelationId: {CorrelationId}", 
                        realmSettings.Realm, correlationId);
                    return null;
                }
                
                if (tokenResponse == null || string.IsNullOrWhiteSpace(tokenResponse.AccessToken))
                {
                    _logger.LogError("Token exchange вернул пустой ответ для realm {Realm}. CorrelationId: {CorrelationId}", 
                        realmSettings.Realm, correlationId);
                    return null;
                }

                _logger.LogInformation("Token exchange успешно завершен для realm {Realm}, получен access_token длиной {Length}. CorrelationId: {CorrelationId}", 
                    realmSettings.Realm, tokenResponse.AccessToken.Length, correlationId);
                return CreateCacheEntry(tokenResponse, realmSettings);
            }
            finally
            {
                // Гарантируем освобождение response в любом случае
                response?.Dispose();
            }
        }
        catch (HttpRequestException httpEx)
        {
            _logger.LogError(httpEx, "HTTP ошибка при token exchange для realm {Realm}: {Message}. Inner: {InnerException}. CorrelationId: {CorrelationId}", 
                realmSettings.Realm, httpEx.Message, httpEx.InnerException?.Message, correlationId);
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Исключение при token exchange для realm {Realm}: {Message}. Type: {ExceptionType}. CorrelationId: {CorrelationId}", 
                realmSettings.Realm, ex.Message, ex.GetType().Name, correlationId);
            return null;
        }
    }

    private async Task<CachedToken?> TryRefreshAsync(TokenExchangeRealmSettings realmSettings, string refreshToken, CancellationToken cancellationToken)
    {
        try
        {
            // Используем именованный HttpClient для token exchange (с игнорированием SSL ошибок)
            var httpClient = _httpClientFactory.CreateClient("TokenExchange");
            
            using var requestContent = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("grant_type", "refresh_token"),
                new KeyValuePair<string, string>("refresh_token", refreshToken),
                new KeyValuePair<string, string>("client_id", realmSettings.ClientId),
                new KeyValuePair<string, string>("client_secret", realmSettings.ClientSecret)
            });

            _logger.LogDebug("Отправка refresh token запроса для realm {Realm}", realmSettings.Realm);
            var response = await httpClient.PostAsync(realmSettings.TokenEndpoint, requestContent, cancellationToken);
            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync(cancellationToken);
                _logger.LogWarning("Refresh token не удался для realm {Realm}: {Status} {Error}",
                    realmSettings.Realm, response.StatusCode, error);
                return null;
            }

            TokenResponse? tokenResponse;
            try
            {
                tokenResponse = await response.Content.ReadFromJsonAsync<TokenResponse>(cancellationToken: cancellationToken);
            }
            catch (Exception jsonEx)
            {
                _logger.LogWarning(jsonEx, "Ошибка десериализации ответа refresh token для realm {Realm}", realmSettings.Realm);
                return null;
            }
            
            if (tokenResponse == null || string.IsNullOrWhiteSpace(tokenResponse.AccessToken))
            {
                _logger.LogWarning("Refresh token вернул пустой ответ для realm {Realm}", realmSettings.Realm);
                return null;
            }

            return CreateCacheEntry(tokenResponse, realmSettings, refreshToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при обновлении обмененного токена для realm {Realm}", realmSettings.Realm);
            return null;
        }
    }

    private CachedToken CreateCacheEntry(TokenResponse response, TokenExchangeRealmSettings? realmSettings = null, string? fallbackRefreshToken = null)
    {
        // Валидируем токен перед созданием записи
        if (!IsValidJwtToken(response.AccessToken))
        {
            var realm = realmSettings?.Realm ?? "unknown";
            _logger.LogError("Получен невалидный JWT токен от token exchange сервера для реалма {Realm}", realm);
            throw new TokenExchangeValidationException(realm, 
                "Получен невалидный JWT токен от token exchange сервера");
        }
        
        // Используем TTL из настроек реалма или общий TTL по умолчанию
        // Валидируем ExpiresIn на разумные значения (максимум 24 часа)
        const int MaxExpiresInSeconds = 86400; // 24 часа
        
        TimeSpan cacheTtl;
        if (response.ExpiresIn > 0 && response.ExpiresIn <= MaxExpiresInSeconds)
        {
            cacheTtl = TimeSpan.FromSeconds(response.ExpiresIn);
        }
        else if (response.ExpiresIn > MaxExpiresInSeconds)
        {
            _logger.LogWarning("ExpiresIn слишком большое ({ExpiresIn} секунд), ограничиваем до {MaxExpiresIn} секунд для реалма {Realm}",
                response.ExpiresIn, MaxExpiresInSeconds, realmSettings?.Realm ?? "unknown");
            cacheTtl = TimeSpan.FromSeconds(MaxExpiresInSeconds);
        }
        else if (realmSettings?.CacheTtl.HasValue == true)
        {
            cacheTtl = realmSettings.CacheTtl.Value;
        }
        else
        {
            cacheTtl = _defaultTokenCacheTtl;
        }
        
        var expires = DateTime.UtcNow.Add(cacheTtl);
        return new CachedToken
        {
            AccessToken = response.AccessToken,
            RefreshToken = response.RefreshToken ?? fallbackRefreshToken,
            ExpiresAtUtc = expires,
            Claims = ExtractClaims(response.AccessToken)
        };
    }
    
    /// <summary>
    /// Проверяет валидность JWT токена
    /// </summary>
    private bool IsValidJwtToken(string token)
    {
        if (string.IsNullOrWhiteSpace(token))
        {
            return false;
        }
        
        try
        {
            var handler = new JwtSecurityTokenHandler();
            var jwtToken = handler.ReadJwtToken(token);
            
            // Проверяем обязательные поля
            // ValidTo может быть default(DateTime) если токен не содержит exp claim
            // Subject может быть пустым, если токен не содержит sub claim
            // Основная проверка - что токен успешно распарсился и имеет структуру JWT
            return jwtToken != null;
        }
        catch (ArgumentException argEx)
        {
            _logger.LogWarning(argEx, "Невалидный формат JWT токена: {Message}", argEx.Message);
            return false;
        }
        catch (FormatException formatEx)
        {
            _logger.LogWarning(formatEx, "Ошибка формата JWT токена: {Message}", formatEx.Message);
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось распарсить JWT токен для валидации: {Message}", ex.Message);
            return false;
        }
    }

    private TokenExchangeRealmSettings? GetRealmSettings(string targetRealm)
        => _settings.Realms.Find(r =>
            string.Equals(r.Realm, targetRealm, StringComparison.OrdinalIgnoreCase));
    
    /// <summary>
    /// Получить базовый URL для реалма из TokenEndpoint.
    /// Извлекает схему + хост + порт (всё до первого '/' после домена).
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <returns>Базовый URL или null если реалм не найден в конфигурации</returns>
    public string? GetBaseUrlForRealm(string realm)
    {
        // Проверка disposed выполняется внутри метода, если нужна блокировка
        
        var realmSettings = GetRealmSettings(realm);
        if (realmSettings == null || string.IsNullOrWhiteSpace(realmSettings.TokenEndpoint))
        {
            return null;
        }
        
        try
        {
            // Парсим TokenEndpoint как URI
            if (!Uri.TryCreate(realmSettings.TokenEndpoint, UriKind.Absolute, out var tokenUri))
            {
                _logger.LogWarning("Не удалось распарсить TokenEndpoint как URI для реалма {Realm}: {TokenEndpoint}", 
                    realm, realmSettings.TokenEndpoint);
                return null;
            }
            
            // Формируем базовый URL: схема + хост + порт
            var baseUrl = $"{tokenUri.Scheme}://{tokenUri.Authority}";
            _logger.LogDebug("Извлечен базовый URL для реалма {Realm}: {BaseUrl} из TokenEndpoint {TokenEndpoint}", 
                realm, baseUrl, realmSettings.TokenEndpoint);
            
            return baseUrl;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при извлечении базового URL из TokenEndpoint для реалма {Realm}: {TokenEndpoint}", 
                realm, realmSettings.TokenEndpoint);
            return null;
        }
    }

    private bool IsSubjectIssuer(string realm)
        => _settings.Realms.Any(r =>
            string.Equals(r.SubjectIssuer, realm, StringComparison.OrdinalIgnoreCase));
    
    /// <summary>
    /// Получить метрики работы сервиса.
    /// Метрики включают количество запросов, успешных/неуспешных операций и статистику кэша.
    /// </summary>
    /// <returns>
    /// Кортеж с метриками:
    /// - Requests: общее количество запросов token exchange
    /// - Successes: количество успешных операций
    /// - Failures: количество неуспешных операций
    /// - CacheHits: количество попаданий в кэш
    /// - CacheMisses: количество промахов кэша
    /// </returns>
    /// <exception cref="ObjectDisposedException">Выбрасывается если сервис был освобожден</exception>
    /// <example>
    /// <code>
    /// var metrics = tokenExchangeService.GetMetrics();
    /// var hitRate = metrics.CacheHits / (double)(metrics.CacheHits + metrics.CacheMisses);
    /// Console.WriteLine($"Cache hit rate: {hitRate:P2}");
    /// </code>
    /// </example>
    public (long Requests, long Successes, long Failures, long CacheHits, long CacheMisses) GetMetrics()
    {
        // Для long на 64-битных платформах обычное чтение атомарно, но Interlocked.Read безопаснее
        // Оставляем Interlocked.Read для кроссплатформенной совместимости
        return (
            Interlocked.Read(ref _exchangeRequests),
            Interlocked.Read(ref _exchangeSuccesses),
            Interlocked.Read(ref _exchangeFailures),
            Interlocked.Read(ref _cacheHits),
            Interlocked.Read(ref _cacheMisses)
        );
    }
    
    /// <summary>
    /// Получить расширенные метрики работы сервиса, включая использование ресурсов.
    /// </summary>
    /// <returns>
    /// Кортеж с расширенными метриками:
    /// - Requests: общее количество запросов token exchange
    /// - Successes: количество успешных операций
    /// - Failures: количество неуспешных операций
    /// - CacheHits: количество попаданий в кэш
    /// - CacheMisses: количество промахов кэша
    /// - CacheSize: текущий размер кэша
    /// - MaxCacheSize: максимальный размер кэша
    /// - SemaphoreCount: количество активных семафоров
    /// - CircuitBreakerCount: количество активных circuit breakers
    /// </returns>
    /// <exception cref="ObjectDisposedException">Выбрасывается если сервис был освобожден</exception>
    public (long Requests, long Successes, long Failures, long CacheHits, long CacheMisses, 
            int CacheSize, int MaxCacheSize, int SemaphoreCount, int CircuitBreakerCount) GetExtendedMetrics()
    {
        return (
            Interlocked.Read(ref _exchangeRequests),
            Interlocked.Read(ref _exchangeSuccesses),
            Interlocked.Read(ref _exchangeFailures),
            Interlocked.Read(ref _cacheHits),
            Interlocked.Read(ref _cacheMisses),
            _cache.Count,
            _maxCacheSize,
            _exchangeLocks.Count,
            _circuitBreakers.Count
        );
    }

    private TokenExchangeResult ToResult(CachedToken token) => new()
    {
        AccessToken = token.AccessToken,
        RefreshToken = token.RefreshToken,
        ExpiresAtUtc = token.ExpiresAtUtc,
        Claims = token.Claims
    };

    private string BuildCacheKey(string realm)
    {
        var user = _httpContextAccessor.HttpContext?.User;
        var userId = user?.FindFirst("sub")?.Value ?? user?.Identity?.Name ?? "anonymous";
        
        // Санитизируем ключ для безопасности с использованием Regex для эффективности
        var sanitizedUserId = Regex.Replace(userId, @"[:/\\]", "_", RegexOptions.Compiled);
        var cacheKey = $"{sanitizedUserId}:{realm}".ToLowerInvariant();
        
        // Валидация длины ключа кэша
        if (cacheKey.Length > MaxCacheKeyLength)
        {
            _logger.LogWarning("Ключ кэша слишком длинный ({Length} символов, максимум {MaxLength}), обрезаем", 
                cacheKey.Length, MaxCacheKeyLength);
            cacheKey = cacheKey.Substring(0, MaxCacheKeyLength);
        }
        
        return cacheKey;
    }

    private bool IsExpired(DateTime expiresAtUtc)
        => DateTime.UtcNow >= expiresAtUtc.AddSeconds(-_safetyWindowSeconds);
    
    /// <summary>
    /// Маскирует ClientId для безопасного логирования
    /// </summary>
    private static string MaskClientId(string clientId)
    {
        if (string.IsNullOrWhiteSpace(clientId) || clientId.Length <= 8)
        {
            return "****";
        }
        
        return clientId.Substring(0, 4) + "****" + clientId.Substring(clientId.Length - 4);
    }
    
    /// <summary>
    /// Безопасное увеличение метрики с защитой от переполнения
    /// </summary>
    private void IncrementMetricSafely(ref long metric)
    {
        var current = Interlocked.Read(ref metric);
        if (current < long.MaxValue)
        {
            Interlocked.Increment(ref metric);
        }
        else
        {
            // Обнуляем при переполнении и логируем
            _logger.LogWarning("Метрика достигла максимального значения, сбрасываем");
            Interlocked.Exchange(ref metric, 0);
            Interlocked.Increment(ref metric);
        }
    }
    
    /// <summary>
    /// Очистка истекших записей из кэша
    /// </summary>
    private void CleanupExpiredCacheEntries()
    {
        try
        {
            // Оптимизация: используем snapshot ключей без ToArray
            var keysToRemove = new List<string>();
            foreach (var kvp in _cache)
            {
                if (IsExpired(kvp.Value.Token.ExpiresAtUtc))
                {
                    keysToRemove.Add(kvp.Key);
                }
            }
            
            foreach (var key in keysToRemove)
            {
                TryCleanupCacheEntry(key);
            }
            
            if (keysToRemove.Count > 0)
            {
                _logger.LogDebug("Очищено {Count} истекших записей из кэша", keysToRemove.Count);
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при очистке истекших записей из кэша");
        }
    }
    
    /// <summary>
    /// Безопасная очистка записи кэша с проверкой использования
    /// </summary>
    private void TryCleanupCacheEntry(string cacheKey)
    {
        if (string.IsNullOrEmpty(cacheKey))
        {
            return;
        }
        
        // Проверяем, что токен действительно истек и не используется
        if (_cache.TryGetValue(cacheKey, out var entry) && !IsExpired(entry.Token.ExpiresAtUtc))
        {
            return; // Токен еще валиден, не удаляем
        }
        
        if (_cache.TryRemove(cacheKey, out _))
        {
            // Пытаемся удалить семафор, если он не используется
            if (_exchangeLocks.TryRemove(cacheKey, out var semaphore))
            {
                try
                {
                    // Пытаемся взять семафор, чтобы убедиться, что он не используется
                    if (semaphore.Wait(0)) // Неблокирующая попытка
                    {
                        semaphore.Release();
                        semaphore.Dispose();
                        _semaphoreLastUsed.TryRemove(cacheKey, out _);
                        _logger.LogDebug("Удален семафор для ключа {CacheKey} при очистке кэша", cacheKey);
                    }
                    else
                    {
                        // Семафор занят, не возвращаем его - пусть будет создан заново при необходимости
                        _logger.LogDebug("Семафор для ключа {CacheKey} занят, пропускаем удаление", cacheKey);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Ошибка при освобождении семафора для {CacheKey}", cacheKey);
                    // Возвращаем семафор обратно в случае ошибки
                    _exchangeLocks.TryAdd(cacheKey, semaphore);
                }
            }
        }
    }
    
    /// <summary>
    /// Удаляет наименее используемую запись из кэша (LRU)
    /// Оптимизированная версия с использованием более эффективного алгоритма поиска минимума
    /// </summary>
    private void EvictLeastRecentlyUsed()
    {
        try
        {
            if (_cache.IsEmpty)
            {
                return;
            }
            
            // Оптимизация: находим минимальный LastAccessed за один проход вместо OrderBy
            string? oldestKey = null;
            DateTime oldestTime = DateTime.MaxValue;
            int checkedCount = 0;
            const int maxCheckCount = 10; // Ограничиваем количество проверок для производительности
            
            foreach (var kvp in _cache)
            {
                if (kvp.Value.LastAccessed < oldestTime)
                {
                    oldestTime = kvp.Value.LastAccessed;
                    oldestKey = kvp.Key;
                }
                
                checkedCount++;
                if (checkedCount >= maxCheckCount)
                {
                    break; // Ограничиваем количество проверок
                }
            }
            
            if (oldestKey != null)
            {
                if (_cache.TryRemove(oldestKey, out _))
                {
                    _logger.LogDebug("Кэш токенов достиг максимального размера ({MaxSize}), удален LRU токен для {OldestKey}", 
                        _maxCacheSize, oldestKey);
                    
                    // Также удаляем семафор для этого ключа
                    if (_exchangeLocks.TryRemove(oldestKey, out var semaphore))
                    {
                        try
                        {
                            if (semaphore.Wait(0))
                            {
                                semaphore.Release();
                                semaphore.Dispose();
                                _semaphoreLastUsed.TryRemove(oldestKey, out _);
                            }
                            else
                            {
                                // Семафор занят, не возвращаем его - пусть будет создан заново при необходимости
                                _logger.LogDebug("Семафор для ключа {OldestKey} занят при LRU eviction, пропускаем удаление", oldestKey);
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.LogWarning(ex, "Ошибка при освобождении семафора для {OldestKey}", oldestKey);
                            _exchangeLocks.TryAdd(oldestKey, semaphore);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при применении LRU логики кэша");
        }
    }
    
    /// <summary>
    /// Получить access token напрямую из HttpContext через AuthenticationProperties
    /// </summary>
    /// <param name="cancellationToken">Токен отмены операции</param>
    private async Task<string?> GetTokenFromHttpContextAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            var httpContext = _httpContextAccessor.HttpContext;
            if (httpContext == null)
            {
                _logger.LogWarning("HttpContext недоступен для получения токена");
                return null;
            }
            
            // Пробуем получить результат аутентификации через схему Cookie (так как DefaultScheme = Cookie)
            var authResult = await httpContext.AuthenticateAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            if (!authResult.Succeeded || authResult.Properties == null)
            {
                return null;
            }
            
            // Пробуем получить токен через стандартные методы (более эффективно)
            var schemes = new[] 
            { 
                OpenIdConnectDefaults.AuthenticationScheme,
                CookieAuthenticationDefaults.AuthenticationScheme 
            };
            
            foreach (var scheme in schemes)
            {
                try
                {
                    var token = await httpContext.GetTokenAsync(scheme, "access_token");
                    if (!string.IsNullOrWhiteSpace(token))
                    {
                        _logger.LogInformation("Токен получен из HttpContext через схему {Scheme}, длина: {Length}", scheme, token.Length);
                        return token;
                    }
                }
                catch (Exception authEx) when (authEx.GetType().Name.Contains("Authentication"))
                {
                    _logger.LogDebug(authEx, "Ошибка аутентификации при получении токена через схему {Scheme}", scheme);
                    // Продолжаем попытки с другими схемами
                }
                catch (InvalidOperationException invOpEx)
                {
                    _logger.LogDebug(invOpEx, "Недопустимая операция при получении токена через схему {Scheme}", scheme);
                    // Продолжаем попытки с другими схемами
                }
            }
            
            // Если не получилось через схему, пробуем напрямую из Properties
            var tokens = authResult.Properties.GetTokens();
            var accessToken = tokens?.FirstOrDefault(t => t.Name == "access_token")?.Value;
            
            if (!string.IsNullOrWhiteSpace(accessToken))
            {
                _logger.LogInformation("Токен получен из AuthenticationProperties.GetTokens(), длина: {Length}", accessToken.Length);
                return accessToken;
            }
            
            return null;
        }
        catch (ObjectDisposedException)
        {
            _logger.LogWarning("HttpContext был освобожден во время получения токена");
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при получении токена из HttpContext");
            return null;
        }
    }

    private Claim[] ExtractClaims(string accessToken)
    {
        if (string.IsNullOrWhiteSpace(accessToken))
        {
            return Array.Empty<Claim>();
        }

        try
        {
            var handler = new JwtSecurityTokenHandler();
            var token = handler.ReadJwtToken(accessToken);
            
            // Оптимизация: используем более эффективный способ создания массива
            if (token.Claims == null)
            {
                return Array.Empty<Claim>();
            }
            
            // Используем ToArray() напрямую, так как это уже оптимизированный метод для IEnumerable
            return token.Claims.ToArray();
        }
        catch (ArgumentException argEx)
        {
            _logger.LogWarning(argEx, "Невалидный формат JWT токена при извлечении claims: {Message}", argEx.Message);
            return Array.Empty<Claim>();
        }
        catch (FormatException formatEx)
        {
            _logger.LogWarning(formatEx, "Ошибка формата JWT токена при извлечении claims: {Message}", formatEx.Message);
            return Array.Empty<Claim>();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось распарсить claims из access token при token exchange: {Message}", ex.Message);
            return Array.Empty<Claim>();
        }
    }

    /// <summary>
    /// Запись в кэше с токеном и метаданными
    /// </summary>
    private sealed class CacheEntry
    {
        public CachedToken Token { get; set; } = null!;
        public DateTime LastAccessed { get; set; }
    }
    
    /// <summary>
    /// Состояние circuit breaker для реалма
    /// </summary>
    private sealed class CircuitBreakerState
    {
        public int FailureCount { get; set; }
        public DateTime? OpenedAt { get; set; }
        public DateTime LastSuccessAt { get; set; } = DateTime.UtcNow;
        
        public bool IsOpen(TimeSpan openDuration)
        {
            return OpenedAt.HasValue && 
                   DateTime.UtcNow - OpenedAt.Value < openDuration;
        }
        
        public void RecordFailure(int threshold)
        {
            // Защита от переполнения FailureCount
            if (FailureCount < int.MaxValue)
            {
                FailureCount++;
            }
            else
            {
                // При переполнении сбрасываем счетчик, но оставляем circuit breaker открытым
                FailureCount = threshold;
            }
            
            if (FailureCount >= threshold && !OpenedAt.HasValue)
            {
                OpenedAt = DateTime.UtcNow;
            }
        }
        
        public void RecordSuccess()
        {
            FailureCount = 0;
            OpenedAt = null;
            LastSuccessAt = DateTime.UtcNow;
        }
    }
    
    /// <summary>
    /// Кэшированный токен
    /// </summary>
    private sealed class CachedToken
    {
        public string AccessToken { get; set; } = string.Empty;
        public string? RefreshToken { get; set; }
        public DateTime ExpiresAtUtc { get; set; }
        public Claim[] Claims { get; set; } = Array.Empty<Claim>();
    }

    private sealed class TokenResponse
    {
        [JsonPropertyName("access_token")]
        public string AccessToken { get; set; } = string.Empty;

        [JsonPropertyName("refresh_token")]
        public string? RefreshToken { get; set; }

        [JsonPropertyName("expires_in")]
        public int ExpiresIn { get; set; }

        [JsonPropertyName("refresh_expires_in")]
        public int RefreshExpiresIn { get; set; }
    }
    
    /// <summary>
    /// Проверяет, освобожден ли объект
    /// </summary>
    private bool IsDisposed()
    {
        return Interlocked.CompareExchange(ref _disposed, 0, 0) != 0;
    }
    
    /// <summary>
    /// Выбрасывает исключение, если объект освобожден
    /// </summary>
    private void ThrowIfDisposed()
    {
        if (IsDisposed())
        {
            throw new ObjectDisposedException(nameof(TokenExchangeService));
        }
    }
    
    /// <summary>
    /// Длина корреляционного ID
    /// </summary>
    private const int CorrelationIdLength = 8;
    
    /// <summary>
    /// Генерирует корреляционный ID для отслеживания запросов
    /// Использует Guid.NewGuid() который гарантирует уникальность
    /// </summary>
    private static string GetCorrelationId()
    {
        // Guid.NewGuid() гарантирует уникальность, дополнительная проверка не требуется
        // Вероятность коллизии настолько мала, что можно пренебречь
        return Guid.NewGuid().ToString("N")[..CorrelationIdLength];
    }
    
    /// <summary>
    /// Проверяет состояние circuit breaker для реалма
    /// </summary>
    private bool IsCircuitBreakerOpen(string realm)
    {
        if (!_enableCircuitBreaker)
        {
            return false;
        }
        
        if (_circuitBreakers.TryGetValue(realm, out var breaker))
        {
            return breaker.IsOpen(_circuitBreakerOpenDuration);
        }
        
        return false;
    }
    
    /// <summary>
    /// Регистрирует успешный запрос для circuit breaker
    /// </summary>
    private void RecordCircuitBreakerSuccess(string realm)
    {
        if (!_enableCircuitBreaker)
        {
            return;
        }
        
        var breaker = _circuitBreakers.GetOrAdd(realm, _ => new CircuitBreakerState());
        breaker.RecordSuccess();
    }
    
    /// <summary>
    /// Регистрирует неудачный запрос для circuit breaker
    /// </summary>
    private void RecordCircuitBreakerFailure(string realm)
    {
        if (!_enableCircuitBreaker)
        {
            return;
        }
        
        var breaker = _circuitBreakers.GetOrAdd(realm, _ => new CircuitBreakerState());
        breaker.RecordFailure(_circuitBreakerFailureThreshold);
        
        if (breaker.IsOpen(_circuitBreakerOpenDuration))
        {
            _logger.LogWarning(
                "Circuit breaker открыт для реалма {Realm} после {FailureCount} ошибок. " +
                "Будут пропущены запросы в течение {OpenDuration}",
                realm, breaker.FailureCount, _circuitBreakerOpenDuration);
        }
    }
    
    /// <summary>
    /// Освобождаем ресурсы (семафоры и таймер)
    /// </summary>
    public void Dispose()
    {
        // Используем Interlocked.Exchange для атомарной проверки и установки
        if (Interlocked.Exchange(ref _disposed, 1) != 0)
        {
            return; // Уже освобожден
        }
        
        DisposeCore();
        GC.SuppressFinalize(this);
    }
    
    /// <summary>
    /// Общая логика освобождения ресурсов
    /// </summary>
    private void DisposeCore()
    {
        
        // Останавливаем таймер очистки
        try
        {
            _cleanupTimer?.Dispose();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при освобождении таймера очистки в TokenExchangeService");
        }
        
        // Освобождаем все семафоры
        foreach (var semaphore in _exchangeLocks.Values)
        {
            try
            {
                semaphore?.Dispose();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Ошибка при освобождении семафора в TokenExchangeService");
            }
        }
        
        _exchangeLocks.Clear();
        _semaphoreLastUsed.Clear();
        _cache.Clear();
        _circuitBreakers.Clear(); // Очистка circuit breaker states
    }
    
    /// <summary>
    /// Асинхронное освобождение ресурсов
    /// </summary>
    public ValueTask DisposeAsync()
    {
        // Используем Interlocked.Exchange для атомарной проверки и установки
        if (Interlocked.Exchange(ref _disposed, 1) != 0)
        {
            return ValueTask.CompletedTask; // Уже освобожден
        }
        
        // Останавливаем таймер очистки
        try
        {
            _cleanupTimer?.Dispose();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при освобождении таймера очистки в TokenExchangeService");
        }
        
        // Синхронное освобождение семафоров (более эффективно, чем Task.Run)
        foreach (var semaphore in _exchangeLocks.Values)
        {
            try
            {
                semaphore?.Dispose();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Ошибка при освобождении семафора");
            }
        }
        
        _exchangeLocks.Clear();
        _semaphoreLastUsed.Clear();
        _cache.Clear();
        _circuitBreakers.Clear(); // Очистка circuit breaker states
        
        GC.SuppressFinalize(this);
        return ValueTask.CompletedTask;
    }
}

