using System.Collections.Concurrent;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using System.Xml.Linq;
using Microsoft.Extensions.Logging;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services.Confluence;

/// <summary>
/// Парсер для извлечения данных из HTML/XML страниц Confluence
/// </summary>
public class ConfluencePageParser : IConfluencePageParser
{
    private readonly ILogger<ConfluencePageParser> _logger;

    private const string XhtmlNamespace = "http://www.w3.org/1999/xhtml";
    
    // Константы для паттернов регулярных выражений
    private const string HtmlTagPattern = @"<[^>]+>";
    private const string LocalRolesTablePatternString = @"Client Roles\s*\([^)]*Роль клиента[^)]*\)[^<]*</th>\s*<td[^>]*>(.*?)(?:</td>|</table>)";
    private const string LocalRolesTablePatternAltString = @"Client Roles[^<]*Роль клиента[^<]*</th>\s*<td[^>]*>(.*?)(?:</td>|</table>)";
    private const string ServiceRolesTablePatternString = @"Service Account Role[^<]*</th>\s*<td[^>]*>(.*?)(?:</td>|</table>)";
    private const string TableRowPatternString = @"<tr[^>]*>\s*<td[^>]*>(.*?)</td>\s*<td[^>]*>(.*?)</td>\s*<td[^>]*>(.*?)</td>\s*</tr>";
    
    // Предкомпилированные Regex
    private static readonly Regex HtmlTagRemover = new(HtmlTagPattern, RegexOptions.Compiled);
    private static readonly Regex LocalRolesTablePattern = new(LocalRolesTablePatternString,
        RegexOptions.Singleline | RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex LocalRolesTablePatternAlt = new(LocalRolesTablePatternAltString,
        RegexOptions.Singleline | RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex ServiceRolesTablePattern = new(ServiceRolesTablePatternString,
        RegexOptions.Singleline | RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex TableRowPattern = new(TableRowPatternString,
        RegexOptions.Singleline | RegexOptions.IgnoreCase | RegexOptions.Compiled);
    
    // Кэш для динамических Regex паттернов с ограничением размера
    // Ограничение: максимум 1000 паттернов для предотвращения утечки памяти
    private const int MaxRegexCacheSize = 1000;
    private static readonly ConcurrentDictionary<string, Regex> FieldExtractRegexCache = new();
    
    // Lock для синхронизации очистки кэша
    private static readonly object _cacheCleanupLock = new object();

    // Константы для защиты от ReDoS атак
    private const int MaxFieldNameLength = 500;
    private const int MaxHtmlLength = 50_000_000; // 50MB

    public ConfluencePageParser(ILogger<ConfluencePageParser> logger)
    {
        _logger = logger;
    }

    public Dictionary<string, string> ExtractLocalRoles(string html)
    {
        if (string.IsNullOrWhiteSpace(html))
        {
            return new Dictionary<string, string>(0, StringComparer.OrdinalIgnoreCase);
        }

        Dictionary<string, string> roles;

        try
        {
            var tableMatch = LocalRolesTablePattern.Match(html);

            if (!tableMatch.Success)
            {
                tableMatch = LocalRolesTablePatternAlt.Match(html);
            }

            if (!tableMatch.Success)
            {
                return new Dictionary<string, string>(0, StringComparer.OrdinalIgnoreCase);
            }

            var tableContent = tableMatch.Groups[1].Value;
            var rowMatches = TableRowPattern.Matches(tableContent);
            roles = new Dictionary<string, string>(rowMatches.Count, StringComparer.OrdinalIgnoreCase);

            foreach (Match rowMatch in rowMatches)
            {
                var roleName = HtmlTagRemover.Replace(rowMatch.Groups[1].Value, "").Trim();
                var contour = HtmlTagRemover.Replace(rowMatch.Groups[3].Value, "").Trim();

                if (!string.IsNullOrWhiteSpace(roleName))
                {
                    var normalizedContour = contour.Contains("STAGE", StringComparison.OrdinalIgnoreCase) ? "STAGE" : "TEST";
                    roles[roleName] = normalizedContour;
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось извлечь локальные роли из HTML");
            return new Dictionary<string, string>(0, StringComparer.OrdinalIgnoreCase);
        }

        return roles;
    }

    public Dictionary<string, string> ExtractServiceRoles(string html)
    {
        if (string.IsNullOrWhiteSpace(html))
        {
            return new Dictionary<string, string>(0, StringComparer.OrdinalIgnoreCase);
        }

        Dictionary<string, string> roles;

        try
        {
            var tableMatch = ServiceRolesTablePattern.Match(html);

            if (!tableMatch.Success)
            {
                return new Dictionary<string, string>(0, StringComparer.OrdinalIgnoreCase);
            }

            var tableContent = tableMatch.Groups[1].Value;
            var rowMatches = TableRowPattern.Matches(tableContent);
            roles = new Dictionary<string, string>(rowMatches.Count, StringComparer.OrdinalIgnoreCase);

            foreach (Match rowMatch in rowMatches)
            {
                var roleName = HtmlTagRemover.Replace(rowMatch.Groups[1].Value, "").Trim();
                var clientId = HtmlTagRemover.Replace(rowMatch.Groups[2].Value, "").Trim();
                var contour = HtmlTagRemover.Replace(rowMatch.Groups[3].Value, "").Trim();

                if (!string.IsNullOrWhiteSpace(roleName))
                {
                    var key = string.IsNullOrWhiteSpace(clientId) || clientId == "realm"
                        ? roleName
                        : $"{roleName}|{clientId}";

                    var normalizedContour = contour.Contains("STAGE", StringComparison.OrdinalIgnoreCase) ? "STAGE" : "TEST";
                    roles[key] = normalizedContour;
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось извлечь service роли из HTML");
            return new Dictionary<string, string>(0, StringComparer.OrdinalIgnoreCase);
        }

        return roles;
    }

    public string ExtractField(string html, string fieldName)
    {
        if (string.IsNullOrWhiteSpace(fieldName) || string.IsNullOrWhiteSpace(html))
        {
            return string.Empty;
        }

        // Защита от ReDoS атак и валидация длины
        if (fieldName.Length > MaxFieldNameLength)
        {
            _logger.LogWarning("Field name exceeds maximum length: {Length} (max: {MaxLength})", fieldName.Length, MaxFieldNameLength);
            return string.Empty;
        }

        if (html.Length > MaxHtmlLength)
        {
            _logger.LogWarning("HTML content exceeds maximum length: {Length} (max: {MaxLength})", html.Length, MaxHtmlLength);
            return string.Empty;
        }

        try
        {
            string escapedFieldName;
            try
            {
                escapedFieldName = Regex.Escape(fieldName);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to escape field name for Regex: {FieldName}", fieldName);
                return string.Empty;
            }

            var patternKey = $"field_extract_combined_{escapedFieldName}";
            var regex = FieldExtractRegexCache.GetOrAdd(patternKey,
                key =>
                {
                    // Ограничение размера кэша: если превышен лимит, очищаем часть кэша
                    CleanupRegexCacheIfNeeded();

                    return new Regex(
                        $@"<th[^>]*>(?:[^<]*<[^>]*>)*[^<]*{escapedFieldName}[^<]*(?:</[^>]*>[^<]*)*</th>\s*<td[^>]*>(.*?)</td>|" +
                        $@"<th[^>]*>[^<]*{escapedFieldName}[^<]*</th>\s*<td[^>]*>(.*?)</td>|" +
                        $@"<th[^>]*>{escapedFieldName}</th>\s*<td[^>]*>(.*?)</td>",
                        RegexOptions.Singleline | RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.CultureInvariant,
                        TimeSpan.FromSeconds(5)); // Таймаут для защиты от ReDoS
                });

            var match = regex.Match(html);
            if (match.Success)
            {
                for (int i = 1; i <= match.Groups.Count; i++)
                {
                    var cellContent = match.Groups[i].Value;
                    if (!string.IsNullOrWhiteSpace(cellContent))
                    {
                        var textContent = HtmlTagRemover.Replace(cellContent, "").Trim();
                        if (!string.IsNullOrWhiteSpace(textContent))
                            return textContent;
                    }
                }
            }
        }
        catch (RegexMatchTimeoutException ex)
        {
            _logger.LogWarning(ex, "Regex match timeout while extracting field {FieldName} from HTML", fieldName);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось извлечь поле {FieldName} из HTML", fieldName);
        }
        return string.Empty;
    }

    private static void CleanupRegexCacheIfNeeded()
    {
        if (FieldExtractRegexCache.Count < MaxRegexCacheSize)
            return;

        lock (_cacheCleanupLock)
        {
            // Двойная проверка после получения lock
            if (FieldExtractRegexCache.Count >= MaxRegexCacheSize)
            {
                // Используем более эффективный подход: очищаем половину кэша
                // Берем ключи в HashSet для более быстрой работы
                var keysToRemove = new HashSet<string>();
                var halfSize = MaxRegexCacheSize / 2;
                var keys = FieldExtractRegexCache.Keys.Take(halfSize).ToList();
                keysToRemove.UnionWith(keys);

                foreach (var keyToRemove in keysToRemove)
                {
                    FieldExtractRegexCache.TryRemove(keyToRemove, out _);
                }
            }
        }
    }

    public string ExtractLink(string html, string fieldName)
    {
        if (string.IsNullOrWhiteSpace(fieldName) || string.IsNullOrWhiteSpace(html))
        {
            return string.Empty;
        }

        // Защита от ReDoS атак и валидация длины
        if (fieldName.Length > MaxFieldNameLength)
        {
            _logger.LogWarning("Field name exceeds maximum length: {Length} (max: {MaxLength})", fieldName.Length, MaxFieldNameLength);
            return string.Empty;
        }

        if (html.Length > MaxHtmlLength)
        {
            _logger.LogWarning("HTML content exceeds maximum length: {Length} (max: {MaxLength})", html.Length, MaxHtmlLength);
            return string.Empty;
        }

        try
        {
            string escapedFieldName;
            try
            {
                escapedFieldName = Regex.Escape(fieldName);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to escape field name for Regex: {FieldName}", fieldName);
                return string.Empty;
            }

            var patternKey = $"link_extract_{escapedFieldName}";
            var regex = FieldExtractRegexCache.GetOrAdd(patternKey,
                key =>
                {
                    // Ограничение размера кэша: если превышен лимит, очищаем часть кэша
                    CleanupRegexCacheIfNeeded();

                    return new Regex($@"<th[^>]*>{escapedFieldName}</span></th>\s*<td[^>]*><a href=""([^""]*)"">([^<]*)</a></td>",
                        RegexOptions.Compiled | RegexOptions.CultureInvariant,
                        TimeSpan.FromSeconds(5)); // Таймаут для защиты от ReDoS
                });

            var match = regex.Match(html);
            if (match.Success)
            {
                return match.Groups[1].Value.Trim();
            }
        }
        catch (RegexMatchTimeoutException ex)
        {
            _logger.LogWarning(ex, "Regex match timeout while extracting link from field {FieldName}", fieldName);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось извлечь ссылку из поля {FieldName}", fieldName);
        }
        return string.Empty;
    }

    public string ExtractFieldFromXml(string xmlContent, string fieldName)
    {
        if (string.IsNullOrWhiteSpace(xmlContent) || string.IsNullOrWhiteSpace(fieldName))
        {
            return string.Empty;
        }

        // Валидация размера XML перед парсингом
        const int MaxDocumentSizeBytes = 10_000_000; // 10MB
        if (xmlContent.Length > MaxDocumentSizeBytes)
        {
            _logger.LogWarning("XML content exceeds maximum size: {Size} bytes. Field: {FieldName}", xmlContent.Length, fieldName);
            return string.Empty;
        }

        try
        {
            // Безопасный парсинг XML с защитой от XXE атак
            var document = ParseXmlSafely(xmlContent);
            var root = document.Root;
            if (root == null)
                return string.Empty;

            var xhtmlNs = (XNamespace)XhtmlNamespace;
            // Оптимизация: материализуем запрос для предотвращения повторной итерации
            var rows = root.Descendants(xhtmlNs + "tr").Concat(root.Descendants("tr")).ToList();
            
            foreach (var row in rows)
            {
                var header = row.Elements(xhtmlNs + "th").Concat(row.Elements("th")).FirstOrDefault();
                if (header == null)
                    continue;

                var headerText = header.Value ?? string.Empty;
                if (headerText.Length == 0)
                    continue;

                var decodedHeaderText = WebUtility.HtmlDecode(headerText).Trim();
                if (!decodedHeaderText.Contains(fieldName, StringComparison.OrdinalIgnoreCase))
                    continue;

                var cell = row.Elements(xhtmlNs + "td").Concat(row.Elements("td")).FirstOrDefault();
                if (cell == null)
                    continue;

                var cellText = cell.Value ?? string.Empty;
                if (cellText.Length == 0)
                    continue;

                var decodedCellText = WebUtility.HtmlDecode(cellText).Trim();
                return decodedCellText;
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось извлечь поле {FieldName} из XML", fieldName);
        }

        return string.Empty;
    }

    /// <summary>
    /// Безопасный парсинг XML с защитой от XXE атак
    /// </summary>
    private XDocument ParseXmlSafely(string xmlContent)
    {
        const int MaxDocumentSizeBytes = 10_000_000; // 10MB
        
        var settings = new System.Xml.XmlReaderSettings
        {
            DtdProcessing = System.Xml.DtdProcessing.Prohibit,
            XmlResolver = null, // Отключаем внешние сущности
            MaxCharactersFromEntities = 0,
            MaxCharactersInDocument = MaxDocumentSizeBytes
        };

        using var reader = System.Xml.XmlReader.Create(new System.IO.StringReader(xmlContent), settings);
        return XDocument.Load(reader, System.Xml.Linq.LoadOptions.None);
    }
}

