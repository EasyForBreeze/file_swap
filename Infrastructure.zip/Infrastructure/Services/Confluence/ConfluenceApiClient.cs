using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services.Confluence;

/// <summary>
/// Клиент для работы с Confluence API
/// </summary>
public class ConfluenceApiClient : IConfluenceApiClient
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ConfluenceSettings _settings;
    private readonly ILogger<ConfluenceApiClient> _logger;
    private readonly IPerformanceMetricsService? _metricsService;

    // Константы для retry логики
    private const int MaxVersionRetryAttempts = 3;
    private const int VersionRetryDelayMs = 500;
    private const int HttpConflictStatusCode = 409; // Conflict
    private const int HealthCheckTimeoutSeconds = 5;

    // Константы для валидации параметров
    private const int MaxTitleLength = 255;
    private const int MaxPageIdLength = 100;
    private const int MaxSpaceKeyLength = 100;
    private const int MaxContentLength = 50_000_000; // 50MB (лимит Confluence)
    private const int MaxJsonContentLength = 10_000_000; // 10MB для JSON ответов

    public ConfluenceApiClient(
        IHttpClientFactory httpClientFactory,
        IOptions<ConfluenceSettings> settings,
        ILogger<ConfluenceApiClient> logger,
        IPerformanceMetricsService? metricsService = null)
    {
        _httpClientFactory = httpClientFactory;
        _settings = settings.Value;
        _logger = logger;
        _metricsService = metricsService;
    }

    private HttpClient CreateHttpClient()
    {
        var client = _httpClientFactory.CreateClient("Confluence");
        ConfigureHttpClient(client);
        return client;
    }

    private void ConfigureHttpClient(HttpClient client)
    {
        // Валидация настроек
        if (string.IsNullOrWhiteSpace(_settings.BaseUrl))
            throw new InvalidOperationException("Confluence BaseUrl is not configured");

        if (!Uri.TryCreate(_settings.BaseUrl, UriKind.Absolute, out var baseUri))
            throw new InvalidOperationException($"Invalid Confluence BaseUrl: {_settings.BaseUrl}");

        if (_settings.RequestTimeoutSeconds <= 0)
            throw new InvalidOperationException("RequestTimeoutSeconds must be greater than 0");

        client.BaseAddress = baseUri;
        client.Timeout = TimeSpan.FromSeconds(_settings.RequestTimeoutSeconds);

        // Если задан Token — используем Bearer. Иначе — Basic
        if (!string.IsNullOrWhiteSpace(_settings.Token))
        {
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _settings.Token);
        }
        else
        {
            // Basic Auth для Confluence
            if (string.IsNullOrWhiteSpace(_settings.Username) || string.IsNullOrWhiteSpace(_settings.Password))
                throw new InvalidOperationException("Confluence Username and Password must be configured when Token is not provided");

            try
            {
                var authToken = Convert.ToBase64String(
                    Encoding.UTF8.GetBytes($"{_settings.Username}:{_settings.Password}"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to encode authentication credentials", ex);
            }
        }
        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
    }

    #region Validation Helpers

    private static void ValidateParameter(string parameter, string parameterName, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(parameter))
            throw new ArgumentException($"{parameterName} cannot be null or empty", parameterName);

        if (parameter.Length > maxLength)
            throw new ArgumentException($"{parameterName} exceeds maximum length of {maxLength} characters", parameterName);
    }

    private static void ValidateContentLength(string? content, string parameterName)
    {
        if (content == null)
            return;

        if (content.Length > MaxContentLength)
            throw new ArgumentException($"{parameterName} exceeds maximum length of {MaxContentLength} characters", parameterName);
    }

    #endregion

    #region Common HTTP Request Helpers

    private async Task<string> ReadResponseContentAsync(HttpContent content, CancellationToken cancellationToken)
    {
        try
        {
            var responseString = await content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            
            // Валидация размера ответа
            if (responseString.Length > MaxJsonContentLength)
            {
                _logger.LogWarning("Response content exceeds maximum size: {Size} bytes", responseString.Length);
                throw new InvalidOperationException($"Response content exceeds maximum size of {MaxJsonContentLength} bytes");
            }

            return responseString;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Failed to read HTTP response content");
            throw;
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogWarning(ex, "Timeout while reading HTTP response content");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error while reading HTTP response content");
            throw;
        }
    }

    private JsonElement DeserializeJsonSafely(string json, string operationName)
    {
        try
        {
            return JsonSerializer.Deserialize<JsonElement>(json);
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "Failed to deserialize JSON response in {OperationName}", operationName);
            _metricsService?.RecordError(operationName, "JsonDeserializationError");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error during JSON deserialization in {OperationName}", operationName);
            _metricsService?.RecordError(operationName, "JsonDeserializationUnexpectedError");
            throw;
        }
    }

    private string SerializeJsonSafely<T>(T payload, string operationName)
    {
        try
        {
            return JsonSerializer.Serialize(payload);
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "Failed to serialize JSON payload in {OperationName}", operationName);
            _metricsService?.RecordError(operationName, "JsonSerializationError");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error during JSON serialization in {OperationName}", operationName);
            _metricsService?.RecordError(operationName, "JsonSerializationUnexpectedError");
            throw;
        }
    }

    #endregion

    public async Task<ConfluencePageResponse?> CreatePageAsync(
        string title,
        string content,
        string spaceKey,
        string parentPageId,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        const string operationName = "Confluence.CreatePage";

        try
        {
            // Валидация параметров
            ValidateParameter(title, nameof(title), MaxTitleLength);
            ValidateParameter(spaceKey, nameof(spaceKey), MaxSpaceKeyLength);
            ValidateParameter(parentPageId, nameof(parentPageId), MaxPageIdLength);
            ValidateContentLength(content, nameof(content));

            using var client = CreateHttpClient();

            var payload = new
            {
                type = "page",
                title = title,
                space = new { key = spaceKey },
                ancestors = new[] { new { id = parentPageId } },
                body = new
                {
                    storage = new
                    {
                        value = content,
                        representation = "storage"
                    }
                }
            };

            var json = SerializeJsonSafely(payload, operationName);
            var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync("/rest/api/content", httpContent, cancellationToken).ConfigureAwait(false);

            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await ReadResponseContentAsync(response.Content, cancellationToken).ConfigureAwait(false);
                _logger.LogError("Failed to create Confluence page. Status: {Status}, Error: {Error}",
                    response.StatusCode, errorContent);
                
                _metricsService?.RecordError(operationName, $"HTTP_{response.StatusCode}");
                return null;
            }

            var responseJson = await ReadResponseContentAsync(response.Content, cancellationToken).ConfigureAwait(false);
            var result = DeserializeJsonSafely(responseJson, operationName);

            var page = ParseConfluencePageResponse(result, title, content);
            if (page == null)
            {
                _logger.LogError("Failed to parse Confluence page response");
                _metricsService?.RecordError(operationName, "ParseError");
                return null;
            }

            stopwatch.Stop();
            _metricsService?.RecordOperationTime(operationName, stopwatch.ElapsedMilliseconds);
            _metricsService?.RecordSuccess(operationName);

            return page;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP error creating Confluence page");
            _metricsService?.RecordError(operationName, "HttpRequestException");
            return null;
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogWarning(ex, "Request timeout creating Confluence page");
            _metricsService?.RecordError(operationName, "Timeout");
            return null;
        }
        catch (ArgumentException)
        {
            // Валидация параметров - пробрасываем исключение дальше
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error creating Confluence page");
            _metricsService?.RecordError(operationName, "UnexpectedError");
            return null;
        }
    }

    public async Task<ConfluencePageResponse?> GetPageAsync(
        string pageId,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        const string operationName = "Confluence.GetPage";

        try
        {
            // Валидация параметров
            ValidateParameter(pageId, nameof(pageId), MaxPageIdLength);

            using var client = CreateHttpClient();

            var response = await client.GetAsync(
                $"/rest/api/content/{pageId}?expand=body.storage,version",
                cancellationToken).ConfigureAwait(false);

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError("Failed to get Confluence page {PageId}. Status: {Status}",
                    pageId, response.StatusCode);
                _metricsService?.RecordError(operationName, $"HTTP_{response.StatusCode}");
                return null;
            }

            var responseJson = await ReadResponseContentAsync(response.Content, cancellationToken).ConfigureAwait(false);
            var result = DeserializeJsonSafely(responseJson, operationName);

            // Безопасная обработка JSON ответа
            if (!result.TryGetProperty("title", out var titleElement) || string.IsNullOrWhiteSpace(titleElement.GetString()))
            {
                _logger.LogError("Confluence API response missing or invalid 'title' field for page {PageId}", pageId);
                _metricsService?.RecordError(operationName, "ParseError");
                return null;
            }

            if (!result.TryGetProperty("version", out var versionElement) ||
                !versionElement.TryGetProperty("number", out var versionNumber))
            {
                _logger.LogError("Confluence API response missing or invalid 'version' field for page {PageId}", pageId);
                _metricsService?.RecordError(operationName, "ParseError");
                return null;
            }

            if (!result.TryGetProperty("body", out var bodyElement) ||
                !bodyElement.TryGetProperty("storage", out var storageElement) ||
                !storageElement.TryGetProperty("value", out var valueElement) ||
                string.IsNullOrWhiteSpace(valueElement.GetString()))
            {
                _logger.LogError("Confluence API response missing or invalid 'body.storage.value' field for page {PageId}", pageId);
                _metricsService?.RecordError(operationName, "ParseError");
                return null;
            }

            var title = titleElement.GetString()!;
            int version;
            try
            {
                version = versionNumber.GetInt32();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to get version number for page {PageId}", pageId);
                _metricsService?.RecordError(operationName, "VersionParseError");
                return null;
            }

            var body = valueElement.GetString()!;
            var pageUrl = $"{_settings.BaseUrl}/pages/viewpage.action?pageId={pageId}";

            stopwatch.Stop();
            _metricsService?.RecordOperationTime(operationName, stopwatch.ElapsedMilliseconds);
            _metricsService?.RecordSuccess(operationName);

            return new ConfluencePageResponse
            {
                Id = pageId,
                Title = title,
                Version = version,
                Url = pageUrl,
                Body = body
            };
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP error getting Confluence page {PageId}", pageId);
            _metricsService?.RecordError(operationName, "HttpRequestException");
            return null;
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogWarning(ex, "Request timeout getting Confluence page {PageId}", pageId);
            _metricsService?.RecordError(operationName, "Timeout");
            return null;
        }
        catch (ArgumentException)
        {
            // Валидация параметров - пробрасываем исключение дальше
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error getting Confluence page {PageId}", pageId);
            _metricsService?.RecordError(operationName, "UnexpectedError");
            return null;
        }
    }

    public async Task<ConfluencePageResponse?> UpdatePageAsync(
        string pageId,
        string title,
        string content,
        int expectedVersion,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        const string operationName = "Confluence.UpdatePage";
        int currentVersion = expectedVersion;

        // Валидация параметров
        ValidateParameter(pageId, nameof(pageId), MaxPageIdLength);
        ValidateParameter(title, nameof(title), MaxTitleLength);
        ValidateContentLength(content, nameof(content));

        // Retry логика для обработки конфликтов версий (race condition)
        for (int attempt = 0; attempt < MaxVersionRetryAttempts; attempt++)
        {
            try
            {
                using var client = CreateHttpClient();

                // Оптимизация: на первой попытке используем expectedVersion без дополнительного запроса
                // Если получим 409 Conflict, то на следующей попытке получим актуальную версию
                if (attempt > 0)
                {
                    // На повторных попытках получаем актуальную версию
                    var currentPage = await GetPageAsync(pageId, cancellationToken);
                    if (currentPage == null)
                    {
                        _logger.LogError("Failed to get current page from Confluence for page ID {PageId}", pageId);
                        _metricsService?.RecordError(operationName, "GetPageFailed");
                        return null;
                    }

                    currentVersion = currentPage.Version;
                }

                // Выполняем обновление с актуальной версией
                var payload = new
                {
                    version = new { number = currentVersion + 1 },
                    title = title,
                    type = "page",
                    body = new
                    {
                        storage = new
                        {
                            value = content,
                            representation = "storage"
                        }
                    }
                };

                var json = SerializeJsonSafely(payload, operationName);
                var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await client.PutAsync(
                    $"/rest/api/content/{pageId}",
                    httpContent,
                    cancellationToken).ConfigureAwait(false);

                // Обработка конфликта версий (409 Conflict)
                if (response.StatusCode == (HttpStatusCode)HttpConflictStatusCode && attempt < MaxVersionRetryAttempts - 1)
                {
                    _logger.LogWarning(
                        "Version conflict detected (409 Conflict) for page {PageId}, retrying... (Attempt {Attempt}/{MaxAttempts})",
                        pageId, attempt + 1, MaxVersionRetryAttempts);

                    await Task.Delay(TimeSpan.FromMilliseconds(VersionRetryDelayMs), cancellationToken);
                    continue;
                }

                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await ReadResponseContentAsync(response.Content, cancellationToken).ConfigureAwait(false);
                    _logger.LogError("Failed to update Confluence page {PageId}. Status: {Status}, Error: {Error}",
                        pageId, response.StatusCode, errorContent);
                    _metricsService?.RecordError(operationName, $"HTTP_{response.StatusCode}");
                    return null;
                }

                var responseJson = await ReadResponseContentAsync(response.Content, cancellationToken).ConfigureAwait(false);
                var result = DeserializeJsonSafely(responseJson, operationName);

                // Безопасная обработка JSON ответа
                if (!result.TryGetProperty("version", out var versionElement) ||
                    !versionElement.TryGetProperty("number", out var versionNumber))
                {
                    _logger.LogError("Confluence API response missing or invalid 'version' field for page {PageId}", pageId);
                    _metricsService?.RecordError(operationName, "ParseError");
                    return null;
                }

                int version;
                try
                {
                    version = versionNumber.GetInt32();
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Failed to get version number for page {PageId}", pageId);
                    _metricsService?.RecordError(operationName, "VersionParseError");
                    return null;
                }

                var pageUrl = $"{_settings.BaseUrl}/pages/viewpage.action?pageId={pageId}";

                stopwatch.Stop();
                _metricsService?.RecordOperationTime(operationName, stopwatch.ElapsedMilliseconds);
                _metricsService?.RecordSuccess(operationName);

                return new ConfluencePageResponse
                {
                    Id = pageId,
                    Title = title,
                    Version = version,
                    Url = pageUrl,
                    Body = content
                };
            }
            catch (HttpRequestException ex) when (ex.Message.Contains(HttpConflictStatusCode.ToString()) && attempt < MaxVersionRetryAttempts - 1)
            {
                // Конфликт версий в исключении - повторяем
                _logger.LogWarning(ex,
                    "Version conflict detected in exception for page {PageId}, retrying... (Attempt {Attempt}/{MaxAttempts})",
                    pageId, attempt + 1, MaxVersionRetryAttempts);

                await Task.Delay(TimeSpan.FromMilliseconds(VersionRetryDelayMs), cancellationToken);
                continue;
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogWarning(ex, "Request timeout updating Confluence page {PageId}", pageId);
                _metricsService?.RecordError(operationName, "Timeout");
                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception updating Confluence page {PageId}", pageId);
                _metricsService?.RecordError(operationName, "UnexpectedError");
                return null;
            }
        }

        _logger.LogError("Failed to update Confluence page {PageId} after {MaxAttempts} attempts due to version conflicts",
            pageId, MaxVersionRetryAttempts);
        _metricsService?.RecordError(operationName, "MaxRetriesExceeded");
        return null;
    }

    public async Task<bool> AddLabelsAsync(
        string pageId,
        List<string> labels,
        CancellationToken cancellationToken = default)
    {
        // Валидация параметров
        ValidateParameter(pageId, nameof(pageId), MaxPageIdLength);

        if (labels == null || labels.Count == 0)
            return true;

        // Валидация и фильтрация меток
        const int maxLabelLength = 255;
        var validLabels = labels
            .Where(l => !string.IsNullOrWhiteSpace(l) && l.Length <= maxLabelLength)
            .Select(l => l.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (validLabels.Count == 0)
            return true;

        var payload = validLabels
            .Select(l => new { prefix = "global", name = l })
            .ToList();

        try
        {
            using var client = CreateHttpClient();

            var json = SerializeJsonSafely(payload, "Confluence.AddLabels");
            var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync($"/rest/api/content/{pageId}/label", httpContent, cancellationToken).ConfigureAwait(false);

            if (!response.IsSuccessStatusCode)
            {
                var error = await ReadResponseContentAsync(response.Content, cancellationToken).ConfigureAwait(false);
                _logger.LogWarning("Не удалось добавить метки к странице {PageId}. Status: {Status}. Error: {Error}", pageId, response.StatusCode, error);
                return false;
            }

            return true;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogWarning(ex, "HTTP error adding labels to page {PageId}", pageId);
            return false;
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogWarning(ex, "Timeout adding labels to page {PageId}", pageId);
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error adding labels to page {PageId}", pageId);
            return false;
        }
    }

    public async Task<bool> IsAvailableAsync(CancellationToken cancellationToken = default)
    {
        if (!_settings.Enabled)
            return false;

        try
        {
            using var client = CreateHttpClient();
            // Комбинируем переданный токен с таймаутом health check
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            cts.CancelAfter(TimeSpan.FromSeconds(HealthCheckTimeoutSeconds));
            var response = await client.GetAsync("/rest/api/space", cts.Token).ConfigureAwait(false);
            return response.IsSuccessStatusCode;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogDebug(ex, "Confluence API is not available");
            return false;
        }
        catch (TaskCanceledException)
        {
            _logger.LogDebug("Confluence API health check timeout");
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Confluence API is not available");
            return false;
        }
    }

    public async Task<(string Id, string Title, string Url, int Version)?> ResolvePageAsync(
        string spaceKey,
        string title,
        CancellationToken cancellationToken = default)
    {
        // Валидация параметров
        ValidateParameter(spaceKey, nameof(spaceKey), MaxSpaceKeyLength);
        ValidateParameter(title, nameof(title), MaxTitleLength);

        try
        {
            using var client = CreateHttpClient();
            var query = $"/rest/api/content?spaceKey={Uri.EscapeDataString(spaceKey)}&title={Uri.EscapeDataString(title)}&expand=version";
            var response = await client.GetAsync(query, cancellationToken).ConfigureAwait(false);

            if (!response.IsSuccessStatusCode)
            {
                var error = await ReadResponseContentAsync(response.Content, cancellationToken).ConfigureAwait(false);
                _logger.LogWarning("Confluence ResolvePageAsync failed. Space={Space}, Title={Title}, Status={Status}. Error={Error}",
                    spaceKey, title, response.StatusCode, error);
                return null;
            }

            var json = await ReadResponseContentAsync(response.Content, cancellationToken).ConfigureAwait(false);
            
            JsonDocument document;
            try
            {
                document = JsonDocument.Parse(json);
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, "Failed to parse JSON response in ResolvePageAsync for space={Space} title={Title}", spaceKey, title);
                return null;
            }

            using (document)
            {
                var root = document.RootElement;
                if (!root.TryGetProperty("results", out var results) || results.GetArrayLength() == 0)
                {
                    return null;
                }

                var first = results[0];

                // Безопасная обработка JSON ответа
                if (!first.TryGetProperty("id", out var idElement) || string.IsNullOrWhiteSpace(idElement.GetString()))
                {
                    _logger.LogWarning("Confluence API response missing or invalid 'id' field for space={Space} title={Title}", spaceKey, title);
                    return null;
                }

                var id = idElement.GetString()!;
                
                int version = 1;
                if (first.TryGetProperty("version", out var versionElement) && versionElement.TryGetProperty("number", out var versionNumber))
                {
                    try
                    {
                        version = versionNumber.GetInt32();
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Failed to parse version number in ResolvePageAsync for space={Space} title={Title}", spaceKey, title);
                    }
                }

                string url = string.Empty;
                if (first.TryGetProperty("_links", out var links) && links.TryGetProperty("webui", out var webui))
                {
                    try
                    {
                        var webuiString = webui.GetString();
                        if (!string.IsNullOrWhiteSpace(webuiString) && 
                            Uri.TryCreate(_settings.BaseUrl, UriKind.Absolute, out var baseUri) &&
                            Uri.TryCreate(baseUri, webuiString, out var fullUri))
                        {
                            url = fullUri.ToString();
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Failed to construct URL in ResolvePageAsync for space={Space} title={Title}", spaceKey, title);
                    }
                }

                var titleValue = first.TryGetProperty("title", out var titleElement)
                    ? titleElement.GetString()
                    : title;

                return (id, titleValue ?? title, url, version);
            }
        }
        catch (HttpRequestException ex)
        {
            _logger.LogWarning(ex, "HTTP error in ResolvePageAsync for space={Space} title={Title}", spaceKey, title);
            return null;
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogWarning(ex, "Request timeout in ResolvePageAsync for space={Space} title={Title}", spaceKey, title);
            return null;
        }
        catch (ArgumentException)
        {
            // Валидация параметров - пробрасываем исключение дальше
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error in ResolvePageAsync for space={Space} title={Title}", spaceKey, title);
            return null;
        }
    }

    private ConfluencePageResponse? ParseConfluencePageResponse(JsonElement result, string title, string content)
    {
        if (!result.TryGetProperty("id", out var idElement) ||
            string.IsNullOrWhiteSpace(idElement.GetString()))
        {
            _logger.LogError("Confluence API response missing or invalid 'id' field");
            return null;
        }

        var pageId = idElement.GetString()!;

        if (!result.TryGetProperty("version", out var versionElement) ||
            !versionElement.TryGetProperty("number", out var versionNumber))
        {
            _logger.LogError("Confluence API response missing or invalid 'version' field");
            return null;
        }

        int version;
        try
        {
            version = versionNumber.GetInt32();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to parse version number in ParseConfluencePageResponse");
            return null;
        }

        var pageUrl = $"{_settings.BaseUrl}/pages/viewpage.action?pageId={pageId}";

        return new ConfluencePageResponse
        {
            Id = pageId,
            Title = title,
            Version = version,
            Url = pageUrl,
            Body = content
        };
    }
}

