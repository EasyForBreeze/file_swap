using System;
using System.Collections.Generic;
using new_assistant.Core.Interfaces;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис-обертка для статического класса SqlitePerformanceMonitor
/// Позволяет использовать DI вместо статических вызовов
/// </summary>
/// <remarks>
/// Этот сервис предоставляет дополнительный уровень абстракции над статическим классом,
/// добавляя валидацию входных данных, обработку исключений и логирование операций.
/// </remarks>
public class SqlitePerformanceMonitorService : ISqlitePerformanceMonitor
{
    private readonly ILogger<SqlitePerformanceMonitorService> _logger;
    
    // Константы для валидации
    private const int MaxDatabaseNameLength = 255;
    private const long MaxReasonableElapsedMs = 3600000; // 1 час
    
    /// <summary>
    /// Инициализирует новый экземпляр класса SqlitePerformanceMonitorService
    /// </summary>
    /// <param name="logger">Логгер для записи операций и ошибок</param>
    /// <exception cref="ArgumentNullException">Когда logger равен null</exception>
    public SqlitePerformanceMonitorService(ILogger<SqlitePerformanceMonitorService> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }
    
    /// <summary>
    /// Записать время выполнения операции в статистику
    /// </summary>
    /// <param name="databaseName">Название БД (например, "audit", "wiki_pages", "forbidden_clients")</param>
    /// <param name="elapsedMs">Время выполнения в миллисекундах</param>
    /// <exception cref="ArgumentException">Когда databaseName null, пустая строка или превышает максимальную длину</exception>
    /// <exception cref="ArgumentOutOfRangeException">Когда elapsedMs отрицательное или превышает разумное значение</exception>
    public void RecordOperation(string databaseName, long elapsedMs)
    {
        try
        {
            // Валидация входных данных на уровне сервиса
            ValidateDatabaseName(databaseName, nameof(databaseName));
            ValidateElapsedTime(elapsedMs, nameof(elapsedMs));
            
            _logger.LogTrace("Recording operation for database '{DatabaseName}' with elapsed time {ElapsedMs}ms", 
                databaseName, elapsedMs);
            
            SqlitePerformanceMonitor.RecordOperation(databaseName, elapsedMs);
            
            _logger.LogDebug("Successfully recorded operation for database '{DatabaseName}'", databaseName);
        }
        catch (ArgumentOutOfRangeException ex)
        {
            _logger.LogWarning(ex, "Invalid elapsed time {ElapsedMs}ms for database '{DatabaseName}'", elapsedMs, databaseName);
            throw;
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Invalid argument when recording operation for database '{DatabaseName}'", databaseName);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error when recording operation for database '{DatabaseName}' with elapsed time {ElapsedMs}ms", 
                databaseName, elapsedMs);
            throw;
        }
    }

    /// <summary>
    /// Получить общую статистику по всем SQLite БД
    /// </summary>
    /// <returns>Кортеж с общим временем выполнения в миллисекундах, количеством запросов и средним временем выполнения</returns>
    public (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetTotalStats()
    {
        try
        {
            _logger.LogTrace("Retrieving total statistics");
            
            var stats = SqlitePerformanceMonitor.GetTotalStats();
            
            _logger.LogDebug("Retrieved total statistics: TotalTime={TotalTimeMs}ms, RequestCount={RequestCount}, AverageTime={AverageTimeMs:F2}ms", 
                stats.TotalTimeMs, stats.RequestCount, stats.AverageTimeMs);
            
            return stats;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error when retrieving total statistics");
            throw;
        }
    }

    /// <summary>
    /// Получить статистику по конкретной БД
    /// </summary>
    /// <param name="databaseName">Название БД</param>
    /// <returns>Кортеж с общим временем выполнения в миллисекундах, количеством запросов и средним временем выполнения для указанной БД</returns>
    /// <exception cref="ArgumentException">Когда databaseName null, пустая строка или превышает максимальную длину</exception>
    public (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetDatabaseStats(string databaseName)
    {
        try
        {
            // Валидация входных данных на уровне сервиса
            ValidateDatabaseName(databaseName, nameof(databaseName));
            
            _logger.LogTrace("Retrieving statistics for database '{DatabaseName}'", databaseName);
            
            var stats = SqlitePerformanceMonitor.GetDatabaseStats(databaseName);
            
            _logger.LogDebug("Retrieved statistics for database '{DatabaseName}': TotalTime={TotalTimeMs}ms, RequestCount={RequestCount}, AverageTime={AverageTimeMs:F2}ms", 
                databaseName, stats.TotalTimeMs, stats.RequestCount, stats.AverageTimeMs);
            
            return stats;
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Invalid database name when retrieving statistics: '{DatabaseName}'", databaseName);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error when retrieving statistics for database '{DatabaseName}'", databaseName);
            throw;
        }
    }

    /// <summary>
    /// Получить статистику по всем БД
    /// </summary>
    /// <returns>Словарь, где ключ - название БД, значение - кортеж с общей статистикой (время, количество запросов, среднее время)</returns>
    public Dictionary<string, (long TotalTimeMs, long RequestCount, double AverageTimeMs)> GetAllDatabaseStats()
    {
        try
        {
            _logger.LogTrace("Retrieving statistics for all databases");
            
            var stats = SqlitePerformanceMonitor.GetAllDatabaseStats();
            
            _logger.LogDebug("Retrieved statistics for {DatabaseCount} database(s)", stats.Count);
            
            return stats;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error when retrieving statistics for all databases");
            throw;
        }
    }

    /// <summary>
    /// Сбросить всю статистику
    /// </summary>
    public void ResetAllStats()
    {
        try
        {
            _logger.LogInformation("Resetting all statistics");
            
            SqlitePerformanceMonitor.ResetAllStats();
            
            _logger.LogInformation("Successfully reset all statistics");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error when resetting all statistics");
            throw;
        }
    }

    /// <summary>
    /// Сбросить статистику конкретной БД
    /// </summary>
    /// <param name="databaseName">Название БД</param>
    /// <exception cref="ArgumentException">Когда databaseName null, пустая строка или превышает максимальную длину</exception>
    public void ResetDatabaseStats(string databaseName)
    {
        try
        {
            // Валидация входных данных на уровне сервиса
            ValidateDatabaseName(databaseName, nameof(databaseName));
            
            _logger.LogInformation("Resetting statistics for database '{DatabaseName}'", databaseName);
            
            SqlitePerformanceMonitor.ResetDatabaseStats(databaseName);
            
            _logger.LogInformation("Successfully reset statistics for database '{DatabaseName}'", databaseName);
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Invalid database name when resetting statistics: '{DatabaseName}'", databaseName);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error when resetting statistics for database '{DatabaseName}'", databaseName);
            throw;
        }
    }
    
    /// <summary>
    /// Валидирует название базы данных
    /// </summary>
    /// <param name="databaseName">Название БД для валидации</param>
    /// <param name="paramName">Имя параметра для сообщения об ошибке</param>
    /// <exception cref="ArgumentException">Когда databaseName null, пустая строка или превышает максимальную длину</exception>
    private static void ValidateDatabaseName(string? databaseName, string paramName)
    {
        if (string.IsNullOrWhiteSpace(databaseName))
        {
            throw new ArgumentException("Database name cannot be null or whitespace.", paramName);
        }
        
        if (databaseName.Length > MaxDatabaseNameLength)
        {
            throw new ArgumentException($"Database name cannot exceed {MaxDatabaseNameLength} characters.", paramName);
        }
    }
    
    /// <summary>
    /// Валидирует время выполнения операции
    /// </summary>
    /// <param name="elapsedMs">Время выполнения в миллисекундах для валидации</param>
    /// <param name="paramName">Имя параметра для сообщения об ошибке</param>
    /// <exception cref="ArgumentOutOfRangeException">Когда elapsedMs отрицательное или превышает разумное значение</exception>
    private static void ValidateElapsedTime(long elapsedMs, string paramName)
    {
        if (elapsedMs < 0)
        {
            throw new ArgumentOutOfRangeException(paramName, "Elapsed time cannot be negative.");
        }
        
        if (elapsedMs > MaxReasonableElapsedMs)
        {
            throw new ArgumentOutOfRangeException(paramName, 
                $"Elapsed time {elapsedMs}ms exceeds maximum reasonable value {MaxReasonableElapsedMs}ms (1 hour).");
        }
    }
}

