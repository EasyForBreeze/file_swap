using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;
using System.Diagnostics;
using System.Security;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Константы для сервиса очистки архивов
/// </summary>
internal static class ArchiveCleanupConstants
{
    /// <summary>
    /// Максимальное количество дней хранения (10 лет)
    /// </summary>
    public const int MaxRetentionDays = 3650;

    /// <summary>
    /// HRESULT для ERROR_SHARING_VIOLATION (файл используется другим процессом)
    /// </summary>
    public const int ErrorSharingViolation = -2147024864;
}

/// <summary>
/// Фоновый сервис для автоматической очистки старых архивов
/// </summary>
public class ArchiveCleanupService : BackgroundService
{
    private readonly ILogger<ArchiveCleanupService> _logger;
    private readonly IPerformanceMetricsService? _metricsService;
    private readonly string _archivesDirectory;
    private readonly TimeSpan _cleanupInterval;
    private readonly int _archiveRetentionDays;
    private readonly TimeSpan? _initialDelay;
    private readonly int _maxFilesPerPass;
    private readonly int _batchSize;
    private readonly int _maxBatchSize;
    private readonly TimeSpan? _fileOperationTimeout;
    private readonly int _retryCount;
    private readonly TimeSpan _retryDelay;

    private const string OperationName_Cleanup = "ArchiveCleanup.Cleanup";
    private const string OperationName_ProcessFile = "ArchiveCleanup.ProcessFile";
    private const string OperationName_DeleteFile = "ArchiveCleanup.DeleteFile";

    public ArchiveCleanupService(
        IOptions<DataPathsSettings> dataPathsSettingsOptions,
        IOptions<ArchiveCleanupSettings> cleanupSettingsOptions,
        ILogger<ArchiveCleanupService> logger,
        IPerformanceMetricsService? metricsService = null)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _metricsService = metricsService;

        var dataPathsSettings = dataPathsSettingsOptions?.Value 
            ?? throw new ArgumentNullException(nameof(dataPathsSettingsOptions));
        
        var cleanupSettings = cleanupSettingsOptions?.Value 
            ?? throw new ArgumentNullException(nameof(cleanupSettingsOptions));

        _archivesDirectory = dataPathsSettings.GetArchivesDirectoryPath();
        
        if (string.IsNullOrWhiteSpace(_archivesDirectory))
            throw new ArgumentException("Путь к директории архивов не может быть пустым", nameof(dataPathsSettings));

        ValidatePath(_archivesDirectory);
        ValidateSettings(cleanupSettings);

        _cleanupInterval = cleanupSettings.CleanupInterval;
        _archiveRetentionDays = cleanupSettings.ArchiveRetentionDays;
        _initialDelay = cleanupSettings.InitialDelay;
        _maxFilesPerPass = cleanupSettings.MaxFilesPerPass;
        _batchSize = cleanupSettings.BatchSize;
        _maxBatchSize = cleanupSettings.MaxBatchSize;
        _fileOperationTimeout = cleanupSettings.FileOperationTimeout;
        _retryCount = cleanupSettings.RetryCount;
        _retryDelay = cleanupSettings.RetryDelay;
    }

    private void ValidateSettings(ArchiveCleanupSettings settings)
    {
        if (settings.CleanupInterval <= TimeSpan.Zero)
            throw new ArgumentException("Интервал очистки должен быть больше нуля", nameof(settings));

        if (settings.ArchiveRetentionDays < 0)
            throw new ArgumentException("Количество дней хранения не может быть отрицательным", nameof(settings));

        if (settings.ArchiveRetentionDays > ArchiveCleanupConstants.MaxRetentionDays)
            throw new ArgumentException($"Количество дней хранения слишком большое (максимум {ArchiveCleanupConstants.MaxRetentionDays} дней)", nameof(settings));

        if (settings.MaxFilesPerPass < 0)
            throw new ArgumentException("Максимальное количество файлов за проход не может быть отрицательным", nameof(settings));

        if (settings.BatchSize < 0)
            throw new ArgumentException("Размер батча не может быть отрицательным", nameof(settings));

        if (settings.MaxBatchSize < 0)
            throw new ArgumentException("Максимальный размер батча не может быть отрицательным", nameof(settings));

        if (settings.InitialDelay.HasValue && settings.InitialDelay.Value < TimeSpan.Zero)
            throw new ArgumentException("Начальная задержка не может быть отрицательной", nameof(settings));

        if (settings.RetryCount < 0)
            throw new ArgumentException("Количество попыток retry не может быть отрицательным", nameof(settings));

        if (settings.RetryDelay < TimeSpan.Zero)
            throw new ArgumentException("Задержка retry не может быть отрицательной", nameof(settings));

        if (settings.FileOperationTimeout.HasValue && settings.FileOperationTimeout.Value <= TimeSpan.Zero)
            throw new ArgumentException("Таймаут операций с файлами должен быть положительным", nameof(settings));
    }

    private void ValidatePath(string path)
    {
        try
        {
            var fullPath = Path.GetFullPath(path);
            
            // Проверка длины пути: на современных системах (Windows 10+, Linux, macOS) 
            // длинные пути поддерживаются, поэтому проверяем только базовую валидность
            // PathTooLongException будет выброшено автоматически, если путь действительно слишком длинный
            if (!Path.IsPathRooted(fullPath))
            {
                throw new ArgumentException("Путь должен быть абсолютным", nameof(path));
            }
        }
        catch (PathTooLongException ex)
        {
            _logger.LogError(ex, "Путь к директории архивов слишком длинный: {ArchivesDirectory}", path);
            throw;
        }
        catch (ArgumentException ex)
        {
            _logger.LogError(ex, "Некорректный путь к директории архивов: {ArchivesDirectory}", path);
            throw;
        }
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Сервис очистки архивов запущен. Очистка каждые {Interval} дней, хранение {RetentionDays} дней, директория: {ArchivesDirectory}", 
            _cleanupInterval.TotalDays, _archiveRetentionDays, _archivesDirectory);

        // Опциональная задержка перед первой очисткой
        if (_initialDelay.HasValue && _initialDelay.Value > TimeSpan.Zero)
        {
            _logger.LogInformation("Ожидание {InitialDelay} перед первой очисткой", _initialDelay.Value);
            try
            {
                await Task.Delay(_initialDelay.Value, stoppingToken);
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("Сервис очистки архивов остановлен до первой очистки");
                return;
            }
        }

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await PerformCleanupAsync(stoppingToken);
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("Операция очистки архивов отменена");
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при выполнении очистки архивов");
            }

            // Ждем до следующей очистки
            try
            {
                await Task.Delay(_cleanupInterval, stoppingToken);
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("Сервис очистки архивов остановлен");
                break;
            }
        }
    }

    private async Task PerformCleanupAsync(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();

        _logger.LogInformation(
            "Начало очистки архивов. Директория: {ArchivesDirectory}, Retention: {RetentionDays} дней, " +
            "MaxFilesPerPass: {MaxFilesPerPass}, BatchSize: {BatchSize}, MaxBatchSize: {MaxBatchSize}, " +
            "RetryCount: {RetryCount}, FileOperationTimeout: {FileOperationTimeout}",
            _archivesDirectory, _archiveRetentionDays, _maxFilesPerPass, _batchSize, _maxBatchSize, 
            _retryCount, _fileOperationTimeout);

        var stopwatch = Stopwatch.StartNew();
        var cutoffDate = DateTime.UtcNow.AddDays(-_archiveRetentionDays);
        
        // Проверяем существование директории один раз в начале
        if (!Directory.Exists(_archivesDirectory))
        {
            _logger.LogDebug("Папка архивов не существует: {ArchivesDirectory}", _archivesDirectory);
            return;
        }

        // Обрабатываем файлы потоково без материализации всего списка
        IEnumerable<string> archiveFiles;
        try
        {
            archiveFiles = Directory.EnumerateFiles(_archivesDirectory, "*.zip", SearchOption.TopDirectoryOnly);
        }
        catch (DirectoryNotFoundException ex)
        {
            _logger.LogWarning(ex, "Директория архивов стала недоступна: {ArchivesDirectory}", _archivesDirectory);
            return;
        }
        catch (DriveNotFoundException ex)
        {
            _logger.LogWarning(ex, "Диск с директорией архивов недоступен: {ArchivesDirectory}", _archivesDirectory);
            return;
        }
        catch (UnauthorizedAccessException ex)
        {
            _logger.LogError(ex, "Нет доступа к директории архивов: {ArchivesDirectory}", _archivesDirectory);
            return;
        }
        catch (SecurityException ex)
        {
            _logger.LogError(ex, "Нет прав безопасности для доступа к директории архивов: {ArchivesDirectory}", _archivesDirectory);
            return;
        }
        catch (IOException ex)
        {
            _logger.LogWarning(ex, "Ошибка доступа к директории архивов: {ArchivesDirectory}", _archivesDirectory);
            return;
        }

        var deletedCount = 0L;
        var totalSize = 0L;
        var errorCount = 0L;
        var processedCount = 0L;

        // Обрабатываем файлы с ограничением количества, если задано
        var fileEnumerator = archiveFiles.GetEnumerator();
        var filesToProcess = new List<string>();
        
        try
        {
            while (fileEnumerator.MoveNext())
            {
                cancellationToken.ThrowIfCancellationRequested();

                // Ограничение на количество файлов за один проход
                if (_maxFilesPerPass > 0 && processedCount >= _maxFilesPerPass)
                {
                    _logger.LogInformation("Достигнуто ограничение на количество файлов за проход: {MaxFilesPerPass}", _maxFilesPerPass);
                    break;
                }

                var currentFile = fileEnumerator.Current;
                processedCount++;

                // Если батчинг отключен, обрабатываем файлы по одному сразу
                if (_batchSize == 0)
                {
                    var (fileDeleted, fileSize, fileErrors) = await ProcessFileAsync(currentFile, cutoffDate, cancellationToken);
                    
                    // Защита от переполнения при агрегации результатов
                    try
                    {
                        checked
                        {
                            if (fileDeleted) deletedCount++;
                            totalSize += fileSize;
                            errorCount += fileErrors;
                        }
                    }
                    catch (OverflowException ex)
                    {
                        _logger.LogError(ex, "Переполнение при агрегации результатов файла. Пропускаем файл.");
                    }
                }
                else
                {
                    // Батчинг включен - накапливаем файлы
                    filesToProcess.Add(currentFile);

                    // Обрабатываем батч, когда набралось достаточно файлов
                    if (filesToProcess.Count >= _batchSize)
                    {
                        var (batchDeleted, batchSize, batchErrors) = await ProcessBatchAsync(filesToProcess, cutoffDate, cancellationToken);
                        
                        // Защита от переполнения при агрегации результатов
                        try
                        {
                            checked
                            {
                                deletedCount += batchDeleted;
                                totalSize += batchSize;
                                errorCount += batchErrors;
                            }
                        }
                        catch (OverflowException ex)
                        {
                            _logger.LogError(ex, "Переполнение при агрегации результатов батча. Пропускаем батч.");
                        }
                        
                        filesToProcess.Clear();
                    }
                }
            }

            // Обрабатываем оставшиеся файлы (только если батчинг включен)
            if (_batchSize > 0 && filesToProcess.Count > 0)
            {
                var (batchDeleted, batchSize, batchErrors) = await ProcessBatchAsync(filesToProcess, cutoffDate, cancellationToken);
                
                try
                {
                    checked
                    {
                        deletedCount += batchDeleted;
                        totalSize += batchSize;
                        errorCount += batchErrors;
                    }
                }
                catch (OverflowException ex)
                {
                    _logger.LogError(ex, "Переполнение при агрегации результатов последнего батча. Пропускаем батч.");
                }
            }
        }
        finally
        {
            fileEnumerator.Dispose();
        }

        stopwatch.Stop();
        var elapsedMs = stopwatch.ElapsedMilliseconds;

        // Записываем метрики
        try
        {
            _metricsService?.RecordOperationTime(OperationName_Cleanup, elapsedMs);
            if (errorCount == 0 && processedCount > 0)
            {
                _metricsService?.RecordSuccess(OperationName_Cleanup);
            }
            else if (errorCount > 0)
            {
                _metricsService?.RecordError(OperationName_Cleanup, "ErrorsOccurred");
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось записать метрики производительности");
        }

        if (deletedCount > 0)
        {
            var totalSizeMB = totalSize / 1024.0 / 1024.0;
            var elapsedSeconds = stopwatch.Elapsed.TotalSeconds;
            var filesPerSecond = elapsedSeconds > 0 ? processedCount / elapsedSeconds : 0;
            
            _logger.LogInformation(
                "Очистка архивов завершена за {ElapsedMs}ms ({ElapsedSeconds:F2}s): " +
                "обработано {ProcessedCount} файлов, удалено {DeletedCount} файлов, " +
                "освобождено {TotalSizeBytes} байт ({TotalSizeMB:F2} MB), " +
                "ошибок: {ErrorCount}, скорость: {FilesPerSecond:F2} файлов/сек, " +
                "успешность: {SuccessRate:F1}%",
                elapsedMs,
                elapsedSeconds,
                processedCount,
                deletedCount,
                totalSize,
                totalSizeMB,
                errorCount,
                filesPerSecond,
                processedCount > 0 ? (double)(processedCount - errorCount) / processedCount * 100 : 0);
        }
        else if (errorCount > 0)
        {
            _logger.LogWarning(
                "Очистка архивов завершена с ошибками: обработано {ProcessedCount} файлов, ошибок: {ErrorCount}, " +
                "успешность: {SuccessRate:F1}%",
                processedCount, 
                errorCount,
                processedCount > 0 ? (double)(processedCount - errorCount) / processedCount * 100 : 0);
        }
        else
        {
            _logger.LogDebug("Очистка архивов: обработано {ProcessedCount} файлов, файлов для удаления не найдено", processedCount);
        }
    }

    private async Task<(long deletedCount, long totalSize, long errorCount)> ProcessBatchAsync(
        List<string> filePaths, 
        DateTime cutoffDate, 
        CancellationToken cancellationToken)
    {
        if (filePaths.Count == 0)
        {
            return (0, 0, 0);
        }

        long batchDeletedCount = 0;
        long batchTotalSize = 0;
        long batchErrorCount = 0;

        if (_batchSize > 0 && filePaths.Count > 1)
        {
            // Параллельная обработка батча
            var maxConcurrency = _maxBatchSize > 0 
                ? Math.Min(_batchSize, _maxBatchSize) 
                : Math.Min(_batchSize, Environment.ProcessorCount);
            var semaphore = new SemaphoreSlim(maxConcurrency);
            try
            {
                var tasks = filePaths.Select(async filePath =>
                {
                    await semaphore.WaitAsync(cancellationToken);
                    try
                    {
                        return await ProcessFileAsync(filePath, cutoffDate, cancellationToken);
                    }
                    finally
                    {
                        semaphore.Release();
                    }
                });

                var results = await Task.WhenAll(tasks);
                
                // Агрегируем результаты
                foreach (var (deleted, size, errors) in results)
                {
                    if (deleted) batchDeletedCount++;
                    if (size > 0)
                    {
                        try
                        {
                            checked
                            {
                                batchTotalSize += size;
                            }
                        }
                        catch (OverflowException)
                        {
                            // Игнорируем переполнение для отдельного файла
                        }
                    }
                    if (errors > 0) batchErrorCount += errors;
                }
            }
            finally
            {
                semaphore.Dispose();
            }
        }
        else
        {
            // Последовательная обработка
            foreach (var filePath in filePaths)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var (deleted, size, errors) = await ProcessFileAsync(filePath, cutoffDate, cancellationToken);
                if (deleted) batchDeletedCount++;
                if (size > 0)
                {
                    try
                    {
                        checked
                        {
                            batchTotalSize += size;
                        }
                    }
                    catch (OverflowException)
                    {
                        // Игнорируем переполнение для отдельного файла
                    }
                }
                if (errors > 0) batchErrorCount += errors;
            }
        }

        return (batchDeletedCount, batchTotalSize, batchErrorCount);
    }

    private async Task<(bool deleted, long size, int errors)> ProcessFileAsync(
        string filePath,
        DateTime cutoffDate,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            // Используем FileInfo напрямую, без предварительной проверки File.Exists
            var fileInfo = new FileInfo(filePath);
            
            if (!fileInfo.Exists)
            {
                _logger.LogDebug("Файл не существует: {FilePath}", filePath);
                return (false, 0, 0);
            }

            // Используем UTC время для консистентности
            if (fileInfo.CreationTimeUtc >= cutoffDate)
            {
                return (false, 0, 0); // Файл еще не устарел
            }

            var fileSize = fileInfo.Length;
            
            // Снимаем атрибут только для чтения, если он установлен
            if (fileInfo.IsReadOnly)
            {
                try
                {
                    fileInfo.IsReadOnly = false;
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Не удалось снять атрибут только для чтения с файла: {FilePath}", filePath);
                    try
                    {
                        _metricsService?.RecordError(OperationName_ProcessFile, "ReadOnlyAttribute");
                    }
                    catch { }
                    return (false, 0, 1);
                }
            }
            
            // Удаляем файл с retry логикой для временных ошибок
            var deleted = await DeleteFileWithRetryAsync(filePath, cancellationToken);
            
            stopwatch.Stop();
            
            // Записываем метрики для обработки файла
            try
            {
                _metricsService?.RecordOperationTime(OperationName_ProcessFile, stopwatch.ElapsedMilliseconds);
                if (deleted)
                {
                    _metricsService?.RecordSuccess(OperationName_ProcessFile);
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Не удалось записать метрики для обработки файла");
            }
            
            if (deleted)
            {
                _logger.LogDebug(
                    "Удален старый архив: {FileName} (создан: {CreatedAt}, размер: {Size} байт, время обработки: {ElapsedMs}ms)", 
                    fileInfo.Name, fileInfo.CreationTimeUtc, fileSize, stopwatch.ElapsedMilliseconds);
                return (true, fileSize, 0);
            }
            
            return (false, 0, 0);
        }
        catch (IOException ex) when (IsFileLockedException(ex))
        {
            stopwatch.Stop();
            _logger.LogWarning(ex, "Файл заблокирован другим процессом, пропускаем: {FilePath}", filePath);
            try
            {
                _metricsService?.RecordError(OperationName_ProcessFile, "FileLocked");
            }
            catch { }
            return (false, 0, 1);
        }
        catch (UnauthorizedAccessException ex)
        {
            stopwatch.Stop();
            _logger.LogWarning(ex, "Нет прав на удаление файла: {FilePath}", filePath);
            try
            {
                _metricsService?.RecordError(OperationName_ProcessFile, "UnauthorizedAccess");
            }
            catch { }
            return (false, 0, 1);
        }
        catch (SecurityException ex)
        {
            stopwatch.Stop();
            _logger.LogWarning(ex, "Нет прав безопасности на удаление файла: {FilePath}", filePath);
            try
            {
                _metricsService?.RecordError(OperationName_ProcessFile, "SecurityException");
            }
            catch { }
            return (false, 0, 1);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogWarning(ex, "Не удалось обработать архив: {FilePath}", filePath);
            try
            {
                _metricsService?.RecordError(OperationName_ProcessFile, ex.GetType().Name);
            }
            catch { }
            return (false, 0, 1);
        }
    }

    private async Task<bool> DeleteFileWithRetryAsync(string filePath, CancellationToken cancellationToken)
    {
        var stopwatch = Stopwatch.StartNew();
        Exception? lastException = null;

        for (int attempt = 0; attempt <= _retryCount; attempt++)
        {
            try
            {
                if (attempt > 0)
                {
                    // Экспоненциальная задержка для retry
                    var delay = TimeSpan.FromMilliseconds(_retryDelay.TotalMilliseconds * Math.Pow(2, attempt - 1));
                    _logger.LogDebug(
                        "Повторная попытка удаления файла (попытка {Attempt}/{MaxAttempts}): {FilePath}, задержка: {Delay}ms",
                        attempt + 1, _retryCount + 1, filePath, delay.TotalMilliseconds);
                    await Task.Delay(delay, cancellationToken);
                }

                // Используем таймаут, если он задан
                if (_fileOperationTimeout.HasValue)
                {
                    using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                    timeoutCts.CancelAfter(_fileOperationTimeout.Value);
                    
                    await Task.Run(() =>
                    {
                        File.Delete(filePath);
                    }, timeoutCts.Token);
                }
                else
                {
                    await Task.Run(() =>
                    {
                        File.Delete(filePath);
                    }, cancellationToken);
                }

                // Успешное удаление
                stopwatch.Stop();
                try
                {
                    _metricsService?.RecordOperationTime(OperationName_DeleteFile, stopwatch.ElapsedMilliseconds);
                    _metricsService?.RecordSuccess(OperationName_DeleteFile);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Не удалось записать метрики для удаления файла");
                }

                return true;
            }
            catch (FileNotFoundException)
            {
                // Файл уже удален, это нормально
                _logger.LogDebug("Файл уже был удален: {FilePath}", filePath);
                return false;
            }
            catch (DirectoryNotFoundException)
            {
                // Директория удалена, это нормально
                _logger.LogDebug("Директория была удалена: {FilePath}", filePath);
                return false;
            }
            catch (OperationCanceledException)
            {
                // Операция отменена
                _logger.LogDebug("Удаление файла отменено: {FilePath}", filePath);
                throw; // Пробрасываем дальше для корректной обработки отмены
            }
            catch (IOException ex) when (IsFileLockedException(ex))
            {
                lastException = ex;
                // Файл заблокирован - это временная ошибка, можно повторить
                if (attempt < _retryCount)
                {
                    _logger.LogDebug(
                        "Файл заблокирован, будет повторная попытка (попытка {Attempt}/{MaxAttempts}): {FilePath}",
                        attempt + 1, _retryCount + 1, filePath);
                    continue;
                }
                else
                {
                    _logger.LogWarning(ex, "Файл заблокирован после {MaxAttempts} попыток, пропускаем: {FilePath}", 
                        _retryCount + 1, filePath);
                    try
                    {
                        _metricsService?.RecordError(OperationName_DeleteFile, "FileLocked");
                    }
                    catch (Exception metricsEx)
                    {
                        _logger.LogWarning(metricsEx, "Не удалось записать метрику ошибки");
                    }
                    return false;
                }
            }
            catch (Exception ex)
            {
                lastException = ex;
                // Для других исключений не делаем retry
                _logger.LogWarning(ex, "Ошибка при удалении файла: {FilePath}", filePath);
                try
                {
                    _metricsService?.RecordError(OperationName_DeleteFile, ex.GetType().Name);
                }
                catch (Exception metricsEx)
                {
                    _logger.LogWarning(metricsEx, "Не удалось записать метрику ошибки");
                }
                return false;
            }
        }

        // Если дошли сюда, значит все попытки исчерпаны
        if (lastException != null)
        {
            _logger.LogWarning(lastException, 
                "Не удалось удалить файл после {MaxAttempts} попыток: {FilePath}", 
                _retryCount + 1, filePath);
        }
        return false;
    }

    private static bool IsFileLockedException(IOException ex)
    {
        // Используем HResult как основной способ определения блокировки файла
        if (ex.HResult == ArchiveCleanupConstants.ErrorSharingViolation)
        {
            return true;
        }

        // Дополнительная проверка по сообщению об ошибке (для разных локализаций)
        var message = ex.Message;
        return message.Contains("being used by another process", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("used by another process", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("процессом", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("используется", StringComparison.OrdinalIgnoreCase);
    }

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("Сервис очистки архивов остановлен");
        await base.StopAsync(cancellationToken);
    }
}
