using new_assistant.Core.Interfaces;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services.KeycloakAdmin;

/// <summary>
/// Вспомогательный класс для проверки запрещенных клиентов (исправление проблемы #21)
/// Устраняет дублирование кода между KeycloakClientManagementService и KeycloakRolesService
/// </summary>
internal static class ForbiddenClientHelper
{
    /// <summary>
    /// Проверяет, что клиент не находится в списке запрещенных
    /// </summary>
    /// <param name="forbiddenService">Сервис для проверки запрещенных клиентов</param>
    /// <param name="logger">Логгер для записи предупреждений</param>
    /// <param name="clientId">Идентификатор клиента</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <exception cref="InvalidOperationException">Выбрасывается если клиент запрещен</exception>
    public static async Task EnsureClientNotForbiddenAsync(
        IForbiddenClientService forbiddenService,
        ILogger logger,
        string clientId,
        string realm,
        CancellationToken cancellationToken)
    {
        if (forbiddenService == null)
            throw new ArgumentNullException(nameof(forbiddenService));
        if (logger == null)
            throw new ArgumentNullException(nameof(logger));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId не может быть пустым", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm не может быть пустым", nameof(realm));
        
        // Проверяем через централизованный сервис
        if (await forbiddenService.IsForbiddenAsync(clientId, realm, cancellationToken).ConfigureAwait(false))
        {
            // Определяем тип запрета
            var alwaysForbiddenSet = forbiddenService.GetAlwaysForbiddenSet();
            var idLower = clientId?.ToLowerInvariant() ?? string.Empty;
            var isSystemClient = alwaysForbiddenSet.Contains(idLower);
            
            if (isSystemClient)
            {
                logger.LogWarning("Операция отклонена: системный клиент {ClientId} запрещен во всех реалмах", clientId);
                throw new InvalidOperationException($"Клиент '{clientId}' является системным и запрещен для изменений.");
            }
            else
            {
                logger.LogWarning("Операция отклонена: клиент {ClientId} в реалме {Realm} находится в списке запрещенных", clientId, realm);
                throw new InvalidOperationException($"Клиент '{clientId}' в реалме '{realm}' находится в списке запрещенных. Изменения запрещены.");
            }
        }
    }
}

