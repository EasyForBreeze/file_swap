using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services.UsersManagement;

/// <summary>
/// Сервис для поиска пользователей через users-management API
/// </summary>
public class UsersSearchService : UsersManagementBaseService, IUsersSearchService
{
    // Константы для валидации
    private const int MaxResponseSize = 10 * 1024 * 1024; // 10 MB
    private const int MaxSearchTermLength = 500;
    private const int MaxUsersCount = 10000; // Максимальное количество пользователей в результате
    
    public UsersSearchService(
        HttpClient httpClient,
        Microsoft.Extensions.Options.IOptions<new_assistant.Configuration.KeycloakAdminSettings> settings,
        new_assistant.Core.Interfaces.IAuditService auditService,
        Microsoft.AspNetCore.Http.IHttpContextAccessor httpContextAccessor,
        new_assistant.Core.Interfaces.ITokenExchangeService tokenExchangeService,
        new_assistant.Core.Interfaces.IPerformanceMetricsService metricsService,
        ILogger<UsersSearchService> logger)
        : base(httpClient, settings, auditService, httpContextAccessor, tokenExchangeService, metricsService, logger)
    {
    }
    
    /// <summary>
    /// Поиск пользователей в указанном реалме по username, имени, фамилии или email
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса</param>
    /// <param name="realm">Название реалма для поиска пользователей</param>
    /// <param name="searchTerm">Поисковый запрос (username, имя, фамилия или email). Если null или пустой, возвращаются все пользователи с учетом пагинации. Максимальная длина: 500 символов</param>
    /// <param name="exact">Если true, выполняется точный поиск. По умолчанию false</param>
    /// <param name="first">Индекс первого результата для пагинации (0-based). По умолчанию 0</param>
    /// <param name="max">Максимальное количество результатов (от 1 до 1000). По умолчанию 100</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список найденных пользователей (только для чтения). Пустой список возвращается только если пользователи не найдены (404) или при пустом ответе API. Если количество пользователей превышает максимум (10000), результат будет обрезан до максимального количества.</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах (null, пустые строки, недопустимые значения, недопустимые символы в searchTerm)</exception>
    /// <exception cref="ArgumentOutOfRangeException">Выбрасывается если first < 0, max не в диапазоне [1, 1000] или searchTerm превышает максимальную длину</exception>
    /// <exception cref="HttpRequestException">Выбрасывается при ошибках HTTP запроса (кроме 404)</exception>
    /// <exception cref="InvalidOperationException">Выбрасывается при ошибках десериализации, неверном формате ответа, превышении максимального размера ответа, или если request/response.Content равен null</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции через cancellationToken</exception>
    public async Task<IReadOnlyList<UserSearchResultDto>> SearchUsersAsync(
        string accessToken,
        string realm,
        string? searchTerm = null,
        bool exact = false,
        int first = 0,
        int max = 100,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        ValidateCommonParameters(accessToken, realm, "SearchUsers");
        if (first < 0)
            throw new ArgumentOutOfRangeException(nameof(first), "First must be non-negative");
        if (max <= 0 || max > 1000)
            throw new ArgumentOutOfRangeException(nameof(max), "Max must be between 1 and 1000");
        
        // Валидация searchTerm (проблема #4)
        if (!string.IsNullOrEmpty(searchTerm))
        {
            if (searchTerm.Length > MaxSearchTermLength)
                throw new ArgumentOutOfRangeException(nameof(searchTerm), 
                    $"Search term cannot exceed {MaxSearchTermLength} characters");
            
            // Валидация на потенциально опасные символы (оптимизация: используем IndexOfAny)
            if (searchTerm.IndexOfAny(new[] { '\0', '\r', '\n' }) >= 0)
                throw new ArgumentException("Search term contains invalid characters", nameof(searchTerm));
        }
        
        try
        {
            // Формируем endpoint для users-management API
            var endpoint = $"auth/realms/{realm}/users-management/{ApiVersionV2}/users";
            
            // Формируем query string (проблема #11 и #13 - используем Uri.EscapeDataString и улучшенный подход)
            var queryParams = new Dictionary<string, string?>();
            if (!string.IsNullOrEmpty(searchTerm))
            {
                queryParams["search"] = searchTerm;
            }
            if (exact)
            {
                queryParams["exact"] = "true";
            }
            if (first > 0)
            {
                queryParams["first"] = first.ToString();
            }
            if (max != 100)
            {
                queryParams["max"] = max.ToString();
            }
            
            if (queryParams.Any())
            {
                var queryString = string.Join("&", queryParams
                    .Where(kvp => kvp.Value != null)
                    .Select(kvp => $"{Uri.EscapeDataString(kvp.Key)}={Uri.EscapeDataString(kvp.Value!)}"));
                endpoint += "?" + queryString;
            }
            
            // Проблема #12: Проверка на null для HttpClient (дополнительная защита)
            if (HttpClient == null)
            {
                Logger.LogError("HttpClient is not initialized");
                throw new InvalidOperationException("HttpClient is not initialized");
            }
            
            var request = await CreateRequestAsync(HttpMethod.Get, endpoint, accessToken, realm, cancellationToken).ConfigureAwait(false);
            
            // Проверка на null для request (проблема #9)
            if (request == null)
            {
                Logger.LogError("Failed to create request для реалма {Realm}", realm);
                MetricsService.RecordError(MetricsOperationName, "RequestCreationFailed");
                throw new InvalidOperationException("Failed to create HTTP request");
            }
            
            Logger.LogDebug("Поиск пользователей: Realm={Realm}, Search={SearchTerm}, Exact={Exact}", realm, searchTerm, exact);
            
            var stopwatch = Stopwatch.StartNew();
            var response = await SendWithRetryAsync(request, cancellationToken).ConfigureAwait(false);
            stopwatch.Stop();
            var elapsedMs = stopwatch.ElapsedMilliseconds;
            try
            {
                MetricsService.RecordOperationTime(MetricsOperationName, elapsedMs);
            }
            catch (Exception ex)
            {
                Logger.LogWarning(ex, "Ошибка при записи метрик производительности");
            }
            
            // Проверка на null для response.Content (проблема #3)
            if (response.Content == null)
            {
                Logger.LogError("Response content is null для реалма {Realm}", realm);
                MetricsService.RecordError(MetricsOperationName, "NullResponseContent");
                throw new InvalidOperationException("Response content is null");
            }
            
            // Проблема #1: Валидация размера ответа
            var contentLength = response.Content.Headers.ContentLength;
            if (contentLength.HasValue && contentLength.Value > MaxResponseSize)
            {
                Logger.LogError("Размер ответа превышает максимально допустимый: {Size} bytes, максимум: {MaxSize} bytes", 
                    contentLength.Value, MaxResponseSize);
                MetricsService.RecordError(MetricsOperationName, "ResponseSizeExceeded");
                throw new InvalidOperationException($"Размер ответа ({contentLength.Value} bytes) превышает максимально допустимый ({MaxResponseSize} bytes)");
            }
            
            // Проблема #3: Обработка ошибок HTTP
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
                Logger.LogWarning("Ошибка поиска пользователей: StatusCode={StatusCode}, Realm={Realm}, Error={Error}, Duration={Duration}ms", 
                    response.StatusCode, realm, errorContent, elapsedMs);
                
                MetricsService.RecordError(MetricsOperationName, $"HTTP_{((int)response.StatusCode)}");
                
                // Выбрасывать исключение для критических ошибок, возвращать пустой список только для 404
                if (response.StatusCode == HttpStatusCode.NotFound)
                {
                    Logger.LogInformation("Пользователи не найдены для реалма {Realm}, SearchTerm={SearchTerm}", realm, searchTerm);
                    Logger.LogInformation("Запрос поиска пользователей завершен: Realm={Realm}, Status={StatusCode}, Duration={Duration}ms, SearchTerm={SearchTerm}, Results=0",
                        realm, response.StatusCode, elapsedMs, searchTerm ?? "null");
                    return Array.Empty<UserSearchResultDto>();
                }
                
                // Для других ошибок выбрасывать исключение
                throw new HttpRequestException(
                    $"Ошибка при поиске пользователей в реалме {realm}. StatusCode: {response.StatusCode}, Error: {errorContent}");
            }
            
            MetricsService.RecordSuccess(MetricsOperationName);
            
            // Проблема #9: Улучшенная обработка ReadAsStringAsync
            string content;
            try
            {
                using (var stream = await response.Content.ReadAsStreamAsync(cancellationToken).ConfigureAwait(false))
                using (var reader = new StreamReader(stream, Encoding.UTF8, detectEncodingFromByteOrderMarks: true, bufferSize: 8192, leaveOpen: false))
                {
                    content = await reader.ReadToEndAsync().ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Ошибка при чтении содержимого ответа для реалма {Realm}", realm);
                try
                {
                    MetricsService.RecordError(MetricsOperationName, "ReadContentError");
                }
                catch (Exception metricsEx)
                {
                    Logger.LogWarning(metricsEx, "Ошибка при записи метрики ошибки");
                }
                throw new InvalidOperationException("Не удалось прочитать содержимое ответа", ex);
            }
            
            // Проблема #17: Проверка на пустой ответ перед десериализацией
            if (string.IsNullOrWhiteSpace(content))
            {
                Logger.LogInformation("Получен пустой ответ от API для реалма {Realm}, SearchTerm={SearchTerm}", 
                    realm, searchTerm ?? "all");
                Logger.LogInformation("Запрос поиска пользователей завершен: Realm={Realm}, Status={StatusCode}, Duration={Duration}ms, SearchTerm={SearchTerm}, Results=0",
                    realm, response.StatusCode, elapsedMs, searchTerm ?? "null");
                return Array.Empty<UserSearchResultDto>();
            }
            
            // Проблема #1: Дополнительная проверка размера после чтения
            if (content.Length > MaxResponseSize)
            {
                Logger.LogError("Размер ответа превышает максимально допустимый: {Size} bytes", content.Length);
                MetricsService.RecordError(MetricsOperationName, "ResponseSizeExceeded");
                throw new InvalidOperationException($"Размер ответа ({content.Length} bytes) превышает максимально допустимый ({MaxResponseSize} bytes)");
            }
            
            // Проблема #3: Улучшенная обработка исключений при десериализации
            JsonElement rootElement;
            try
            {
                rootElement = JsonSerializer.Deserialize<JsonElement>(content, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch (JsonException ex)
            {
                // Использование Range вместо Substring (проблема #16 - оптимизация)
                var truncatedContent = content.Length > 1000 ? content[..1000] + "..." : content;
                Logger.LogError(ex, "Ошибка десериализации JSON ответа для реалма {Realm}, Content: {Content}", 
                    realm, truncatedContent);
                try
                {
                    MetricsService.RecordError(MetricsOperationName, "JsonDeserializationError");
                }
                catch (Exception metricsEx)
                {
                    Logger.LogWarning(metricsEx, "Ошибка при записи метрики ошибки");
                }
                throw new InvalidOperationException($"Не удалось десериализовать ответ от API: {ex.Message}", ex);
            }
            catch (Exception ex)
            {
                // Обработка других исключений при десериализации (проблема #3)
                var truncatedContent = content.Length > 1000 ? content[..1000] + "..." : content;
                Logger.LogError(ex, "Неожиданная ошибка при десериализации JSON ответа для реалма {Realm}, Content: {Content}", 
                    realm, truncatedContent);
                try
                {
                    MetricsService.RecordError(MetricsOperationName, $"DeserializationError_{ex.GetType().Name}");
                }
                catch (Exception metricsEx)
                {
                    Logger.LogWarning(metricsEx, "Ошибка при записи метрики ошибки");
                }
                throw new InvalidOperationException($"Не удалось десериализовать ответ от API: {ex.Message}", ex);
            }
            
            // Проверка, что это массив
            if (rootElement.ValueKind != JsonValueKind.Array)
            {
                // Использование Range вместо Substring (проблема #1 - оптимизация)
                var truncatedContent = content.Length > 1000 ? content[..1000] + "..." : content;
                Logger.LogError("Ожидался массив JSON, но получен {ValueKind} для реалма {Realm}, Content: {Content}", 
                    rootElement.ValueKind, realm, truncatedContent);
                MetricsService.RecordError(MetricsOperationName, "InvalidJsonFormat");
                throw new InvalidOperationException($"Ожидался массив JSON, но получен {rootElement.ValueKind}");
            }
            
            // Проблема #2: Оптимизация - используем IEnumerable для ленивой обработки
            var usersEnumerable = rootElement.EnumerateArray();
            var usersList = new List<JsonElement>();
            var userCount = 0;
            
            foreach (var user in usersEnumerable)
            {
                if (userCount >= MaxUsersCount)
                {
                    Logger.LogWarning("Достигнуто максимальное количество пользователей: {MaxCount} для реалма {Realm}. Остальные результаты будут пропущены.", 
                        MaxUsersCount, realm);
                    try
                    {
                        MetricsService.RecordError(MetricsOperationName, "MaxUsersCountExceeded");
                    }
                    catch (Exception metricsEx)
                    {
                        Logger.LogWarning(metricsEx, "Ошибка при записи метрики ошибки");
                    }
                    break;
                }
                usersList.Add(user);
                userCount++;
            }
            
            // Проблема #6: Валидация обязательных полей
            var result = new List<UserSearchResultDto>();
            foreach (var user in usersList)
            {
                // Валидация обязательных полей
                // Проблема #5: Улучшенная обработка GetString
                string? idValue = null;
                try
                {
                    if (user.TryGetProperty("id", out var id))
                    {
                        idValue = id.GetString();
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogWarning(ex, "Ошибка при получении ID пользователя из JSON для реалма {Realm}", realm);
                    continue;
                }
                
                if (string.IsNullOrWhiteSpace(idValue))
                {
                    Logger.LogWarning("Пользователь без ID пропущен в результатах поиска для реалма {Realm}", realm);
                    continue; // Пропускаем пользователей без ID
                }
                
                string? usernameValue = null;
                try
                {
                    if (user.TryGetProperty("username", out var username))
                    {
                        usernameValue = username.GetString();
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogWarning(ex, "Ошибка при получении username пользователя из JSON для реалма {Realm}, ID={UserId}", realm, idValue);
                    continue;
                }
                
                if (string.IsNullOrWhiteSpace(usernameValue))
                {
                    Logger.LogWarning("Пользователь без username пропущен в результатах поиска для реалма {Realm}, ID={UserId}", 
                        realm, idValue);
                    continue; // Пропускаем пользователей без username
                }
                
                string? firstNameValue = null;
                string? lastNameValue = null;
                string? emailValue = null;
                
                try
                {
                    if (user.TryGetProperty("firstName", out var firstName))
                    {
                        firstNameValue = firstName.GetString();
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogDebug(ex, "Ошибка при получении firstName пользователя из JSON");
                }
                
                try
                {
                    if (user.TryGetProperty("lastName", out var lastName))
                    {
                        lastNameValue = lastName.GetString();
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogDebug(ex, "Ошибка при получении lastName пользователя из JSON");
                }
                
                try
                {
                    if (user.TryGetProperty("email", out var email))
                    {
                        emailValue = email.GetString();
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogDebug(ex, "Ошибка при получении email пользователя из JSON");
                }
                
                result.Add(new UserSearchResultDto
                {
                    Id = idValue,
                    Username = usernameValue,
                    FirstName = firstNameValue,
                    LastName = lastNameValue,
                    Email = emailValue
                });
            }
            
            // Проблема #2: Корректное логирование результата после получения данных
            Logger.LogInformation("Запрос поиска пользователей завершен: Realm={Realm}, Status={StatusCode}, Duration={Duration}ms, SearchTerm={SearchTerm}, Results={ResultCount}, Exact={Exact}",
                realm, response.StatusCode, elapsedMs, searchTerm ?? "null", result.Count, exact);
            return result;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            Logger.LogWarning("Операция поиска пользователей была отменена для реалма {Realm}", realm);
            MetricsService.RecordError(MetricsOperationName, "OperationCanceled");
            throw;
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, "Ошибка HTTP при поиске пользователей в реалме {Realm}", realm);
            MetricsService.RecordError(MetricsOperationName, "HttpRequestError");
            throw;
        }
        catch (JsonException ex)
        {
            Logger.LogError(ex, "Ошибка десериализации при поиске пользователей в реалме {Realm}", realm);
            MetricsService.RecordError(MetricsOperationName, "JsonException");
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при поиске пользователей в реалме {Realm}", realm);
            MetricsService.RecordError(MetricsOperationName, ex.GetType().Name);
            throw;
        }
    }
}

