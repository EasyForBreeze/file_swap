namespace new_assistant.Configuration;

/// <summary>
/// Настройки страницы управления клиентами
/// </summary>
public sealed class ClientsPageSettings
{
    /// <summary>
    /// Количество элементов на странице
    /// </summary>
    public int ItemsPerPage { get; init; } = 10;

    /// <summary>
    /// Минимальная длина поискового запроса для автоматического поиска
    /// </summary>
    public int MinSearchLength { get; init; } = 2;

    /// <summary>
    /// Задержка перед автоматическим поиском (в миллисекундах)
    /// </summary>
    public int SearchDebounceDelayMs { get; init; } = 500;

    /// <summary>
    /// Таймаут для операций поиска (в секундах)
    /// </summary>
    public int SearchTimeoutSeconds { get; init; } = 300;

    /// <summary>
    /// Максимальное количество попыток при ошибке сети
    /// </summary>
    public int MaxRetryAttempts { get; init; } = 3;
}

