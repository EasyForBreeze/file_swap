namespace new_assistant.Configuration;

/// <summary>
/// Настройки интеграции с Confluence
/// </summary>
public sealed class ConfluenceSettings
{
    /// <summary>
    /// Базовый URL Confluence (например: https://your-domain.atlassian.net/wiki)
    /// </summary>
    public string BaseUrl { get; set; } = string.Empty;

    /// <summary>
    /// Логин или Email пользователя для аутентификации
    /// Для Cloud: используйте email
    /// Для Server/Data Center: используйте username
    /// </summary>
    public string Username { get; set; } = string.Empty;

    /// <summary>
    /// Пароль или API Token для доступа к Confluence
    /// Для Cloud: используйте API Token (получить на https://id.atlassian.com/manage-profile/security/api-tokens)
    /// Для Server/Data Center: используйте обычный пароль
    /// </summary>
    public string Password { get; set; } = string.Empty;

    /// <summary>
    /// Токен для Bearer-авторизации (если задан, используется вместо Basic)
    /// </summary>
    public string? Token { get; set; }

    /// <summary>
    /// Ключ пространства (Space Key) где создаются страницы
    /// </summary>
    public string SpaceKey { get; set; } = string.Empty;

    /// <summary>
    /// ID родительской страницы для страниц клиентов
    /// </summary>
    public string ParentPageId { get; set; } = string.Empty;

    /// <summary>
    /// Название родительской страницы (для логирования)
    /// </summary>
    public string ParentPageTitle { get; set; } = string.Empty;

    /// <summary>
    /// Включена ли интеграция с Confluence
    /// </summary>
    public bool Enabled { get; set; } = true;

    /// <summary>
    /// Таймаут запросов в секундах
    /// </summary>
    public int RequestTimeoutSeconds { get; set; } = 30;

    /// <summary>
    /// Префикс для названий страниц (например: "Client:")
    /// </summary>
    public string PageTitlePrefix { get; set; } = "Client:";

    /// <summary>
    /// Создавать ли Wiki страницу при создании клиента
    /// </summary>
    public bool CreatePageOnClientCreation { get; set; } = true;

    /// <summary>
    /// Обновлять ли Wiki страницу при изменении клиента
    /// </summary>
    public bool UpdatePageOnClientUpdate { get; set; } = true;

    /// <summary>
    /// Помечать ли страницу как архивную при удалении клиента
    /// </summary>
    public bool ArchivePageOnClientDeletion { get; set; } = true;

    /// <summary>
    /// Включать ли историю изменений в страницу
    /// </summary>
    public bool IncludeChangeHistoryInPage { get; set; } = false;

    /// <summary>
    /// Максимальное количество попыток при ошибке
    /// </summary>
    public int MaxRetryAttempts { get; set; } = 3;

    /// <summary>
    /// Задержка между попытками в секундах
    /// </summary>
    public int RetryDelaySeconds { get; set; } = 2;
}

