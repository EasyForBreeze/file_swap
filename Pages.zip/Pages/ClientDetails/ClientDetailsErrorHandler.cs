using System.Net.Http;
using Microsoft.Extensions.Logging;
using new_assistant.Core.Constants;
using new_assistant.Core.Exceptions;
using new_assistant.Core.Interfaces;
using new_assistant.Infrastructure.Services;

namespace new_assistant.Pages.ClientDetails;

/// <summary>
/// Единый обработчик ошибок для компонента ClientDetails
/// </summary>
public static class ClientDetailsErrorHandler
{
    /// <summary>
    /// Обработать ошибку с логированием и возвратом понятного сообщения для пользователя
    /// </summary>
    /// <param name="ex">Исключение для обработки</param>
    /// <param name="logger">Логгер для записи ошибок</param>
    /// <param name="operation">Название операции, при которой произошла ошибка</param>
    /// <param name="context">Дополнительный контекст операции</param>
    /// <param name="username">Имя пользователя (опционально, для структурированного логирования)</param>
    /// <returns>Кортеж с сообщением для пользователя и сообщением для лога</returns>
    public static (string UserMessage, string LogMessage) HandleError(
        Exception ex,
        ILogger logger,
        string operation,
        string? context = null,
        string? username = null)
    {
        // Структурированное логирование с контекстом
        var hasContext = !string.IsNullOrEmpty(context);
        var hasUsername = !string.IsNullOrEmpty(username);
        
        if (hasContext && hasUsername)
        {
            logger.LogError(ex,
                "Ошибка при {Operation}. Контекст: {Context}. User: {User}",
                operation, context, username);
        }
        else if (hasContext)
        {
            logger.LogError(ex,
                "Ошибка при {Operation}. Контекст: {Context}",
                operation, context);
        }
        else if (hasUsername)
        {
            logger.LogError(ex,
                "Ошибка при {Operation}. User: {User}",
                operation, username);
        }
        else
        {
            logger.LogError(ex, "Ошибка при {Operation}", operation);
        }

        var logMessage = context != null
            ? $"Ошибка при {operation} (контекст: {context})"
            : $"Ошибка при {operation}";

        // Возвращаем понятное сообщение для пользователя с расширенной обработкой исключений
        var userMessage = ex switch
        {
            ArgumentException => $"Некорректные параметры: {ex.Message}",
            InvalidOperationException => $"Операция не может быть выполнена: {ex.Message}",
            UnauthorizedAccessException => "Недостаточно прав для выполнения операции",
            TimeoutException => "Операция превысила время ожидания. Попробуйте позже.",
            HttpRequestException httpEx when httpEx.Message.Contains("401") || 
                                            httpEx.Message.Contains("Unauthorized") =>
                "Ошибка авторизации. Перезайдите в систему.",
            HttpRequestException httpEx when httpEx.Message.Contains("404") || 
                                            httpEx.Message.Contains("Not Found") =>
                "Ресурс не найден.",
            HttpRequestException httpEx when httpEx.Message.Contains("403") || 
                                            httpEx.Message.Contains("Forbidden") =>
                "Доступ запрещен. Недостаточно прав для выполнения операции.",
            HttpRequestException => "Ошибка при обращении к серверу. Проверьте подключение.",
            TaskCanceledException => "Операция была отменена",
            KeycloakClientSecretNotFoundException keycloakEx =>
                $"Секрет клиента не найден для реалма '{keycloakEx.Realm}' и клиента '{keycloakEx.ClientInternalId}'",
            TokenExchangeConfigurationException configEx =>
                $"Ошибка конфигурации обмена токенов для реалма '{configEx.Realm}': {configEx.Message}",
            TokenExchangeNetworkException networkEx =>
                $"Сетевая ошибка при обмене токенов для реалма '{networkEx.Realm}': {networkEx.Message}",
            TokenExchangeValidationException validationEx =>
                $"Ошибка валидации токена для реалма '{validationEx.Realm}': {validationEx.Message}",
            TokenExchangeException tokenEx =>
                $"Ошибка обмена токенов для реалма '{tokenEx.Realm}': {tokenEx.Message}",
            AuditLoggingException => $"Ошибка логирования аудита: {ex.Message}",
            _ => $"Произошла ошибка при {operation}. Обратитесь к администратору."
        };

        return (userMessage, logMessage);
    }

    /// <summary>
    /// Обработать ошибку и показать уведомление пользователю
    /// </summary>
    /// <param name="ex">Исключение для обработки</param>
    /// <param name="logger">Логгер для записи ошибок</param>
    /// <param name="showNotificationFunc">Функция для отображения уведомления</param>
    /// <param name="operation">Название операции, при которой произошла ошибка</param>
    /// <param name="context">Дополнительный контекст операции</param>
    /// <param name="username">Имя пользователя (опционально, для структурированного логирования)</param>
    public static async Task HandleAndNotifyAsync(
        Exception ex,
        ILogger logger,
        Func<NotificationType, string, string, Task> showNotificationFunc,
        string operation,
        string? context = null,
        string? username = null)
    {
        var (userMessage, _) = HandleError(ex, logger, operation, context, username);
        await showNotificationFunc(
            NotificationType.Error,
            "Ошибка",
            userMessage).ConfigureAwait(false);
    }
}

