using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using new_assistant.Configuration;
using System.Diagnostics;
using System.IO;

namespace new_assistant.Controllers;

/// <summary>
/// Контроллер для работы с логами приложения
/// </summary>
[Authorize(Roles = "assistant-admin")]
[ApiController]
[Route("api/logs")]
[EnableRateLimiting("admin")]
public class LogsController : ControllerBase
{
    private const long MaxFileSizeBytes = 500 * 1024 * 1024; // 500 MB
    
    private readonly DataPathsSettings _dataPathsSettings;
    private readonly ILogger<LogsController> _logger;

    public LogsController(
        DataPathsSettings dataPathsSettings,
        ILogger<LogsController> logger)
    {
        _dataPathsSettings = dataPathsSettings ?? throw new ArgumentNullException(nameof(dataPathsSettings));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Скачивание файла лога
    /// </summary>
    /// <param name="file">Имя файла лога (без пути)</param>
    /// <returns>Файл лога в формате text/plain</returns>
    /// <response code="200">Файл успешно скачан</response>
    /// <response code="400">Некорректное имя файла или размер файла превышает максимально допустимый</response>
    /// <response code="401">Не авторизован</response>
    /// <response code="403">Нет доступа к файлу или попытка path traversal</response>
    /// <response code="404">Файл не найден</response>
    /// <response code="500">Внутренняя ошибка сервера</response>
    /// <remarks>
    /// Поддерживается потоковая передача больших файлов.
    /// Максимальный размер файла: 500 MB.
    /// Поддерживаются Range-запросы для докачки файлов.
    /// </remarks>
    [HttpGet("download")]
    public IActionResult DownloadLogFile([FromQuery] string file)
    {
        var stopwatch = Stopwatch.StartNew();
        
        try
        {
            if (string.IsNullOrWhiteSpace(file))
            {
                _logger.LogWarning("Попытка скачивания лога без указания имени файла");
                return BadRequest("Имя файла не указано");
            }

            // Защита от path traversal атак
            if (file.Contains("..") || file.Contains("/") || file.Contains("\\"))
            {
                _logger.LogWarning("Попытка скачивания файла с недопустимым именем: {FileName}", file);
                return BadRequest("Недопустимое имя файла");
            }

            var logsDirectory = _dataPathsSettings.GetLogsDirectoryPath();
            var filePath = Path.Combine(logsDirectory, file);

            if (!System.IO.File.Exists(filePath))
            {
                _logger.LogWarning("Файл лога не найден: {FileName}", file);
                return NotFound($"Файл {file} не найден");
            }

            // Проверяем, что файл находится в директории логов (дополнительная защита)
            var normalizedLogsDirectory = Path.GetFullPath(logsDirectory);
            var normalizedFilePath = Path.GetFullPath(filePath);
            
            if (!normalizedFilePath.StartsWith(normalizedLogsDirectory, StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogWarning("Попытка доступа к файлу вне директории логов: {FilePath}", filePath);
                return Forbid();
            }

            // Проверка размера файла
            var fileInfo = new FileInfo(filePath);
            if (fileInfo.Length > MaxFileSizeBytes)
            {
                _logger.LogWarning(
                    "Попытка скачивания слишком большого лог-файла {FileName}: {Size} bytes", 
                    file, 
                    fileInfo.Length);
                return BadRequest($"Размер файла превышает максимально допустимый ({MaxFileSizeBytes / (1024 * 1024)} MB)");
            }

            stopwatch.Stop();
            
            _logger.LogInformation(
                "Скачивание файла лога {FileName} размером {Size} пользователем {User} за {ElapsedMs}ms", 
                file,
                fileInfo.Length,
                User.Identity?.Name ?? "Unknown",
                stopwatch.ElapsedMilliseconds);

            // Используем PhysicalFile для автоматического управления потоком
            return PhysicalFile(
                filePath, 
                GetContentType(file), 
                file, 
                enableRangeProcessing: true);
        }
        catch (UnauthorizedAccessException ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "Нет доступа к файлу лога {FileName}", file);
            return StatusCode(403, "Нет доступа к файлу");
        }
        catch (FileNotFoundException ex)
        {
            stopwatch.Stop();
            _logger.LogWarning(ex, "Файл лога не найден: {FileName}", file);
            return NotFound($"Файл {file} не найден");
        }
        catch (DirectoryNotFoundException ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "Директория логов не найдена");
            return StatusCode(500, "Директория логов не найдена");
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "Ошибка при скачивании файла лога {FileName}", file);
            return StatusCode(500, "Ошибка при скачивании файла");
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
            }
        }
    }

    /// <summary>
    /// Получить список доступных лог-файлов
    /// </summary>
    /// <param name="page">Номер страницы (начиная с 1)</param>
    /// <param name="pageSize">Размер страницы (по умолчанию 50)</param>
    /// <param name="fromDate">Фильтр по дате создания (начало)</param>
    /// <param name="toDate">Фильтр по дате создания (конец)</param>
    /// <returns>Список файлов с пагинацией</returns>
    /// <response code="200">Список файлов успешно получен</response>
    /// <response code="500">Внутренняя ошибка сервера</response>
    [HttpGet("list")]
    public IActionResult ListLogFiles(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 50,
        [FromQuery] DateTime? fromDate = null,
        [FromQuery] DateTime? toDate = null)
    {
        try
        {
            if (page < 1)
            {
                page = 1;
            }
            
            if (pageSize < 1 || pageSize > 100)
            {
                pageSize = 50;
            }

            var logsDirectory = _dataPathsSettings.GetLogsDirectoryPath();
            
            if (!Directory.Exists(logsDirectory))
            {
                return Ok(new 
                { 
                    files = Array.Empty<object>(), 
                    total = 0,
                    page = page,
                    pageSize = pageSize,
                    totalPages = 0
                });
            }

            var allFiles = Directory.GetFiles(logsDirectory, "*.log")
                .Select(f =>
                {
                    var fileInfo = new FileInfo(f);
                    return new
                    {
                        fileName = Path.GetFileName(f),
                        fullPath = f,
                        fileInfo = fileInfo
                    };
                })
                .Where(f => 
                {
                    // Фильтрация по дате
                    if (fromDate.HasValue && f.fileInfo.CreationTimeUtc < fromDate.Value.ToUniversalTime())
                    {
                        return false;
                    }
                    
                    if (toDate.HasValue && f.fileInfo.CreationTimeUtc > toDate.Value.ToUniversalTime())
                    {
                        return false;
                    }
                    
                    return true;
                })
                .OrderByDescending(f => f.fileInfo.CreationTime)
                .ToList();

            var total = allFiles.Count;
            var pagedFiles = allFiles
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(f => new
                {
                    fileName = f.fileName,
                    size = f.fileInfo.Length,
                    sizeFormatted = FormatFileSize(f.fileInfo.Length),
                    created = f.fileInfo.CreationTimeUtc,
                    modified = f.fileInfo.LastWriteTimeUtc,
                    contentType = GetContentType(f.fileName ?? string.Empty)
                })
                .ToList();

            return Ok(new
            {
                files = pagedFiles,
                total = total,
                page = page,
                pageSize = pageSize,
                totalPages = (int)Math.Ceiling(total / (double)pageSize)
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при получении списка лог-файлов");
            return StatusCode(500, "Ошибка при получении списка файлов");
        }
    }

    /// <summary>
    /// Получить метаданные файла лога
    /// </summary>
    /// <param name="file">Имя файла лога (без пути)</param>
    /// <returns>Метаданные файла</returns>
    /// <response code="200">Метаданные успешно получены</response>
    /// <response code="400">Некорректное имя файла</response>
    /// <response code="403">Нет доступа к файлу или попытка path traversal</response>
    /// <response code="404">Файл не найден</response>
    /// <response code="500">Внутренняя ошибка сервера</response>
    [HttpGet("metadata")]
    public IActionResult GetLogFileMetadata([FromQuery] string file)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(file))
            {
                _logger.LogWarning("Попытка получения метаданных лога без указания имени файла");
                return BadRequest("Имя файла не указано");
            }

            // Защита от path traversal атак
            if (file.Contains("..") || file.Contains("/") || file.Contains("\\"))
            {
                _logger.LogWarning("Попытка получения метаданных файла с недопустимым именем: {FileName}", file);
                return BadRequest("Недопустимое имя файла");
            }

            var logsDirectory = _dataPathsSettings.GetLogsDirectoryPath();
            var filePath = Path.Combine(logsDirectory, file);

            // Проверяем, что файл находится в директории логов (дополнительная защита)
            var normalizedLogsDirectory = Path.GetFullPath(logsDirectory);
            var normalizedFilePath = Path.GetFullPath(filePath);
            
            if (!normalizedFilePath.StartsWith(normalizedLogsDirectory, StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogWarning("Попытка доступа к файлу вне директории логов: {FilePath}", filePath);
                return Forbid();
            }

            if (!System.IO.File.Exists(filePath))
            {
                _logger.LogWarning("Файл лога не найден: {FileName}", file);
                return NotFound($"Файл {file} не найден");
            }

            var fileInfo = new FileInfo(filePath);
            return Ok(new
            {
                fileName = file,
                size = fileInfo.Length,
                sizeFormatted = FormatFileSize(fileInfo.Length),
                created = fileInfo.CreationTimeUtc,
                modified = fileInfo.LastWriteTimeUtc,
                contentType = GetContentType(file),
                exceedsMaxSize = fileInfo.Length > MaxFileSizeBytes
            });
        }
        catch (UnauthorizedAccessException ex)
        {
            _logger.LogError(ex, "Нет доступа к файлу лога {FileName}", file);
            return StatusCode(403, "Нет доступа к файлу");
        }
        catch (FileNotFoundException ex)
        {
            _logger.LogWarning(ex, "Файл лога не найден: {FileName}", file);
            return NotFound($"Файл {file} не найден");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при получении метаданных файла лога {FileName}", file);
            return StatusCode(500, "Ошибка при получении метаданных файла");
        }
    }

    /// <summary>
    /// Определяет MIME-тип файла по его расширению
    /// </summary>
    private static string GetContentType(string fileName)
    {
        var extension = Path.GetExtension(fileName).ToLowerInvariant();
        return extension switch
        {
            ".log" => "text/plain",
            ".txt" => "text/plain",
            ".json" => "application/json",
            ".xml" => "application/xml",
            _ => "application/octet-stream"
        };
    }

    /// <summary>
    /// Форматирует размер файла в читаемый вид
    /// </summary>
    private static string FormatFileSize(long bytes)
    {
        string[] sizes = { "B", "KB", "MB", "GB", "TB" };
        double len = bytes;
        int order = 0;
        
        while (len >= 1024 && order < sizes.Length - 1)
        {
            order++;
            len = len / 1024;
        }
        
        return $"{len:F2} {sizes[order]}";
    }
}

