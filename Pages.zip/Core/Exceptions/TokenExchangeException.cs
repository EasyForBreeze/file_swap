using System.Runtime.Serialization;

namespace new_assistant.Core.Exceptions;

/// <summary>
/// Базовое исключение для ошибок token exchange
/// </summary>
[Serializable]
public class TokenExchangeException : Exception
{
    /// <summary>
    /// Реалм, для которого выполнялся token exchange
    /// </summary>
    public string? Realm { get; }
    
    public TokenExchangeException(string? realm, string message) : base(message)
    {
        Realm = realm;
    }
    
    public TokenExchangeException(string? realm, string message, Exception innerException) 
        : base(message, innerException)
    {
        Realm = realm ?? throw new ArgumentNullException(nameof(realm));
    }
    
    /// <summary>
    /// Конструктор для сериализации
    /// </summary>
    protected TokenExchangeException(SerializationInfo info, StreamingContext context)
        : base(info, context)
    {
        Realm = info.GetString(nameof(Realm));
    }
    
    /// <summary>
    /// Переопределение для сериализации
    /// </summary>
    [Obsolete("This method is obsolete. Use serialization attributes instead.")]
    public override void GetObjectData(SerializationInfo info, StreamingContext context)
    {
        base.GetObjectData(info, context);
        info.AddValue(nameof(Realm), Realm);
    }
}

/// <summary>
/// Исключение, возникающее при ошибках конфигурации token exchange
/// </summary>
[Serializable]
public class TokenExchangeConfigurationException : TokenExchangeException
{
    public TokenExchangeConfigurationException(string? realm, string message) 
        : base(realm, message) { }
    
    public TokenExchangeConfigurationException(string? realm, string message, Exception innerException) 
        : base(realm, message, innerException) { }
    
    protected TokenExchangeConfigurationException(SerializationInfo info, StreamingContext context)
        : base(info, context)
    {
    }
}

/// <summary>
/// Исключение, возникающее при сетевых ошибках или ошибках HTTP при token exchange
/// </summary>
[Serializable]
public class TokenExchangeNetworkException : TokenExchangeException
{
    /// <summary>
    /// HTTP статус код ответа (если доступен)
    /// </summary>
    public System.Net.HttpStatusCode? StatusCode { get; }
    
    public TokenExchangeNetworkException(string? realm, string message, System.Net.HttpStatusCode? statusCode = null) 
        : base(realm, message)
    {
        StatusCode = statusCode;
    }
    
    public TokenExchangeNetworkException(string? realm, string message, Exception innerException, System.Net.HttpStatusCode? statusCode = null) 
        : base(realm, message, innerException)
    {
        StatusCode = statusCode;
    }
    
    protected TokenExchangeNetworkException(SerializationInfo info, StreamingContext context)
        : base(info, context)
    {
        var statusCodeValue = info.GetInt32(nameof(StatusCode));
        StatusCode = statusCodeValue >= 0 ? (System.Net.HttpStatusCode?)statusCodeValue : null;
    }
    
    [Obsolete("This method is obsolete. Use serialization attributes instead.")]
    public override void GetObjectData(SerializationInfo info, StreamingContext context)
    {
        base.GetObjectData(info, context);
        info.AddValue(nameof(StatusCode), StatusCode?.GetHashCode() ?? -1);
    }
}

/// <summary>
/// Исключение, возникающее при ошибках валидации токена
/// </summary>
[Serializable]
public class TokenExchangeValidationException : TokenExchangeException
{
    public TokenExchangeValidationException(string? realm, string message) 
        : base(realm, message) { }
    
    public TokenExchangeValidationException(string? realm, string message, Exception innerException) 
        : base(realm, message, innerException) { }
    
    protected TokenExchangeValidationException(SerializationInfo info, StreamingContext context)
        : base(info, context)
    {
    }
}

