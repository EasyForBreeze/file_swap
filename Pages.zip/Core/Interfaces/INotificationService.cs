namespace new_assistant.Core.Interfaces;

/// <summary>
/// Тип уведомления
/// </summary>
public enum NotificationType
{
    Info,
    Success,
    Warning,
    Error
}

/// <summary>
/// Интерфейс сервиса для показа уведомлений
/// </summary>
public interface INotificationService : IDisposable
{
    /// <summary>
    /// Список активных уведомлений
    /// </summary>
    IReadOnlyList<NotificationItem> Notifications { get; }

    /// <summary>
    /// Устанавливает callback для обновления UI при изменении состояния
    /// </summary>
    void SetStateChangedCallback(Func<Task> callback);

    /// <summary>
    /// Очищает callback
    /// </summary>
    void ClearCallback();

    /// <summary>
    /// Показывает уведомление
    /// </summary>
    /// <param name="type">Тип уведомления</param>
    /// <param name="title">Заголовок</param>
    /// <param name="message">Сообщение</param>
    /// <param name="durationMs">Длительность отображения в миллисекундах</param>
    /// <param name="actionLink">Ссылка для действия (опционально)</param>
    /// <param name="actionText">Текст действия (опционально)</param>
    /// <exception cref="ObjectDisposedException">Сервис был удален</exception>
    /// <exception cref="ArgumentException">Некорректные параметры</exception>
    Task ShowNotificationAsync(
        NotificationType type,
        string title,
        string message,
        int durationMs = 5000,
        string? actionLink = null,
        string? actionText = null);

    /// <summary>
    /// Удаляет уведомление по ID
    /// </summary>
    /// <param name="id">ID уведомления</param>
    /// <exception cref="ObjectDisposedException">Сервис был удален</exception>
    void RemoveNotification(int id);
}

/// <summary>
/// Элемент уведомления (immutable с потокобезопасным флагом выхода)
/// </summary>
public sealed class NotificationItem
{
    public int Id { get; init; }
    public NotificationType Type { get; init; }
    public string Title { get; init; } = string.Empty;
    public string Message { get; init; } = string.Empty;
    public string? ActionLink { get; init; }
    public string? ActionText { get; init; }
    public DateTime CreatedAt { get; init; } = DateTime.UtcNow;
    
    private volatile bool _isExiting;
    
    /// <summary>
    /// Флаг, указывающий, что уведомление находится в процессе удаления
    /// </summary>
    public bool IsExiting => _isExiting;

    /// <summary>
    /// Устанавливает флаг выхода (только для внутреннего использования)
    /// </summary>
    internal void SetExiting()
    {
        _isExiting = true;
    }
}

