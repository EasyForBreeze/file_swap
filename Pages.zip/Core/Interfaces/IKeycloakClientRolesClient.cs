using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс клиента для работы с client roles (роли клиентов)
/// </summary>
public interface IKeycloakClientRolesClient
{
    /// <summary>
    /// Получить все роли клиента
    /// </summary>
    Task<List<KeycloakRoleDto>> GetClientRolesAsync(string realm, string clientInternalId, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получение client scopes клиента (default или optional)
    /// </summary>
    Task<List<string>> GetClientScopesAsync(string realm, string clientInternalId, bool isDefault, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить ID service account пользователя для клиента
    /// </summary>
    Task<string?> GetServiceAccountUserIdAsync(string realm, string clientInternalId, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Создать роль клиента
    /// </summary>
    Task CreateClientRoleAsync(string realm, string clientInternalId, string roleName, string? description = null, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Удалить роль клиента
    /// </summary>
    Task DeleteClientRoleAsync(string realm, string clientInternalId, string roleName, CancellationToken cancellationToken = default);
}

