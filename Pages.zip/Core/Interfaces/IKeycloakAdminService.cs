using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для работы с Keycloak Admin API.
/// </summary>
public interface IKeycloakAdminService
{
    /// <summary>
    /// Создать нового клиента в Keycloak.
    /// </summary>
    Task<string> CreateClientAsync(CreateClientRequestDto request, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Удалить клиента из Keycloak.
    /// </summary>
    Task DeleteClientAsync(string clientId, string realm, string internalId, CancellationToken cancellationToken = default);
    
    
    /// <summary>
    /// Сгенерировать новый секрет для клиента (с указанием realm и internal ID).
    /// </summary>
    Task<string?> RegenerateClientSecretAsync(string clientId, string realm, string internalId, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Поиск клиентов по подстроке во всех реалмах (кроме master).
    /// </summary>
    Task<ClientsSearchResponse> SearchClientsAsync(string searchTerm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Поиск клиентов с отслеживанием прогресса.
    /// </summary>
    Task<ClientsSearchResponse> SearchClientsWithProgressAsync(
        string searchTerm, 
        IProgress<SearchProgress> progress, 
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить список всех реалмов (кроме master).
    /// </summary>
    Task<IEnumerable<string>> GetRealmsListAsync(CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить детальную информацию о всех реалмах (с Display Name).
    /// </summary>
    Task<IReadOnlyList<RealmDto>> GetRealmsWithDetailsAsync(CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить детальную информацию о клиенте.
    /// </summary>
    Task<ClientDetailsDto?> GetClientDetailsAsync(string clientId, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Загружает события клиента (для ленивой загрузки).
    /// </summary>
    Task<List<ClientEventDto>> LoadClientEventsAsync(string clientId, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получение событий клиента с пагинацией (first и max)
    /// </summary>
    Task<IEnumerable<ClientEventDto>> GetClientEventsAsync(string clientId, string realm, int first, int maxEvents, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить события клиента.
    /// </summary>
    Task<IEnumerable<ClientEventDto>> GetClientEventsAsync(string clientId, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить все события клиента для фильтрации.
    /// </summary>
    Task<IEnumerable<ClientEventDto>> GetAllClientEventsAsync(string clientId, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить все возможные типы событий из реалма.
    /// </summary>
    Task<IEnumerable<string>> GetAllEventTypesAsync(string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить роли клиента (локальные и сервисные).
    /// </summary>
    Task<(List<string> LocalRoles, List<string> ServiceRoles)> GetClientRolesAsync(string clientId, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить эндпоинты клиента.
    /// </summary>
    Task<List<string>> GetClientEndpointsAsync(string clientId, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Обновить детали клиента в Keycloak.
    /// </summary>
    Task UpdateClientDetailsAsync(ClientDetailsDto clientDetails, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Синхронизировать локальные роли клиента с Keycloak.
    /// </summary>
    Task SyncClientLocalRolesAsync(string clientId, string realm, string internalId, List<string> currentRoles, List<string> newRoles, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Синхронизировать service account роли с Keycloak.
    /// </summary>
    Task SyncServiceAccountRolesAsync(string clientId, string realm, string internalId, List<string> currentRoles, List<string> newRoles, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Поиск ролей для Service Account (realm + client roles).
    /// </summary>
    Task<(List<RoleSearchResult> Roles, List<ClientWithRoles> Clients)> SearchRolesForServiceAccountAsync(string realm, string clientInternalId, string searchTerm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Поиск ролей для нового клиента (без clientInternalId).
    /// </summary>
    Task<(List<RoleSearchResult> Roles, List<ClientWithRoles> Clients)> SearchRolesForNewClientAsync(string realm, string searchTerm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Поиск пользователей в KeyCloak по username.
    /// </summary>
    Task<List<UserSearchResultDto>> SearchUsersAsync(string searchTerm, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Поиск клиентов по Client ID (с опциональной фильтрацией по realm).
    /// </summary>
    Task<List<ClientSearchResult>> SearchClientsByIdAsync(string searchTerm, string? realm = null, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Поиск пользователей по username в конкретном реалме.
    /// </summary>
    Task<List<UserSearchResultDto>> SearchUsersByUsernameAsync(string realm, string username, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Генерация example access token для пользователя.
    /// </summary>
    Task<string> GenerateExampleAccessTokenAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Генерация example ID token для пользователя.
    /// </summary>
    Task<string> GenerateExampleIdTokenAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Генерация example userinfo для пользователя.
    /// </summary>
    Task<string> GenerateExampleUserInfoAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить статистику производительности Keycloak.
    /// </summary>
    (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetPerformanceStats();
    
    /// <summary>
    /// Сбросить статистику производительности Keycloak.
    /// </summary>
    void ResetPerformanceStats();
    
    /// <summary>
    /// Найти пользователя по username в конкретном реалме.
    /// </summary>
    Task<System.Text.Json.JsonElement?> GetUserByUsernameAsync(string realm, string username, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить client role mappings для пользователя.
    /// </summary>
    Task<List<string>> GetUserClientRolesAsync(string realm, string userId, string clientUuid, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить всех клиентов реалма в виде JsonElement.
    /// </summary>
    Task<List<System.Text.Json.JsonElement>> GetAllClientsAsJsonAsync(string realm, CancellationToken cancellationToken = default);
}

/// <summary>
/// DTO для клиента Keycloak.
/// </summary>
public class KeycloakClientDto
{
    public string Id { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool Enabled { get; set; } = true;
    public string Protocol { get; set; } = "openid-connect";
    public bool PublicClient { get; set; } = false;
    public List<string> RedirectUris { get; set; } = new();
    public List<string> WebOrigins { get; set; } = new();
    public Dictionary<string, object> Attributes { get; set; } = new();
}

/// <summary>
/// Запрос на создание клиента.
/// </summary>
public class CreateKeycloakClientRequest
{
    public string ClientId { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool PublicClient { get; set; } = false;
    public List<string> RedirectUris { get; set; } = new();
    public List<string> WebOrigins { get; set; } = new();
    public Dictionary<string, object> Attributes { get; set; } = new();
}

/// <summary>
/// Запрос на обновление клиента.
/// </summary>
public class UpdateKeycloakClientRequest
{
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool Enabled { get; set; } = true;
    public List<string> RedirectUris { get; set; } = new();
    public List<string> WebOrigins { get; set; } = new();
    public Dictionary<string, object> Attributes { get; set; } = new();
}
