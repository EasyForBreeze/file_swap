using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для логирования аудит-событий
/// </summary>
public interface IAuditLogger
{
    /// <summary>
    /// Логирование создания клиента
    /// </summary>
    Task LogClientCreatedAsync(string username, string clientId, string realm, string description);

    /// <summary>
    /// Логирование редактирования клиента
    /// </summary>
    Task LogClientUpdatedAsync(string username, string clientId, string realm, List<FieldChangeDto> changes);

    /// <summary>
    /// Логирование удаления клиента
    /// </summary>
    Task LogClientDeletedAsync(string username, string clientId, string realm);

    /// <summary>
    /// Логирование назначения прав на клиента
    /// </summary>
    Task LogAccessGrantedAsync(string username, string targetUsername, string clientId, string realm);

    /// <summary>
    /// Логирование отзыва прав на клиента
    /// </summary>
    Task LogAccessRevokedAsync(string username, string targetUsername, string clientId, string realm);

    /// <summary>
    /// Логирование добавления роли клиента
    /// </summary>
    Task LogRoleAddedAsync(string username, string clientId, string realm, string roleName);

    /// <summary>
    /// Логирование удаления роли клиента
    /// </summary>
    Task LogRoleRemovedAsync(string username, string clientId, string realm, string roleName);

    /// <summary>
    /// Логирование регенерации Client Secret
    /// </summary>
    Task LogSecretRegeneratedAsync(string username, string clientId, string realm);

    /// <summary>
    /// Логирование входа пользователя
    /// </summary>
    Task LogUserLoginAsync(string username);

    /// <summary>
    /// Логирование добавления клиента в запрещенные
    /// </summary>
    Task LogForbiddenClientAddedAsync(string username, string clientId, string realm);

    /// <summary>
    /// Логирование удаления клиента из запрещенных
    /// </summary>
    Task LogForbiddenClientRemovedAsync(string username, string clientId, string realm);

    /// <summary>
    /// Логирование отправки email с учетными данными
    /// </summary>
    Task LogEmailSentAsync(string username, string clientId, string realm, string description);

    /// <summary>
    /// Логирование переноса клиента из TEST в STAGE
    /// </summary>
    Task LogClientMigrationAsync(string username, string clientId, string sourceRealm, string targetRealm, string status, string? details = null);

    /// <summary>
    /// Логирование действий управления пользователями
    /// </summary>
    Task LogUserManagementActionAsync(string username, string action, string targetUserId, string? targetUsername, string? realm, string description, Dictionary<string, string>? metadata = null);

    /// <summary>
    /// Массовая вставка записей аудита
    /// </summary>
    Task BulkLogEventsAsync(IEnumerable<AuditLogEntry> entries);
}

