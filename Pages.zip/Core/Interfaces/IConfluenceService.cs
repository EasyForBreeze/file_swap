using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Сервис для работы с Confluence Wiki
/// </summary>
public interface IConfluenceService
{
    /// <summary>
    /// Создать страницу в Confluence для нового клиента
    /// </summary>
    /// <param name="clientData">Данные клиента</param>
    /// <param name="createdBy">Кто создает страницу</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>URL созданной страницы или null если создание не удалось</returns>
    Task<string?> CreateClientPageAsync(ClientCreationData clientData, string createdBy, CancellationToken cancellationToken = default);

    /// <summary>
    /// Обновить страницу в Confluence при изменении клиента
    /// </summary>
    /// <param name="clientDetails">Детали клиента</param>
    /// <param name="updatedBy">Кто обновляет страницу</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>URL обновленной страницы или null если обновление не удалось</returns>
    Task<string?> UpdateClientPageAsync(ClientDetailsDto clientDetails, string updatedBy, CancellationToken cancellationToken = default);

    /// <summary>
    /// Пометить страницу как архивную при удалении клиента
    /// </summary>
    /// <param name="clientId">ID клиента</param>
    /// <param name="realm">Realm клиента</param>
    /// <param name="archivedBy">Кто архивирует</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>True если архивация успешна</returns>
    Task<bool> ArchiveClientPageAsync(string clientId, string realm, string archivedBy, CancellationToken cancellationToken = default);
    Task<(string Id, string Title, string Url, int Version)?> ResolvePageAsync(string spaceKey, string title, CancellationToken cancellationToken = default);

    /// <summary>
    /// Получить метаданные страницы по её идентификатору
    /// </summary>
    /// <param name="pageId">Идентификатор страницы</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Метаданные страницы или null, если не найдена</returns>
    Task<(string Id, string Title, string Url)?> GetPageMetadataAsync(string pageId, CancellationToken cancellationToken = default);

    /// <summary>
    /// Получить URL Wiki страницы для клиента
    /// </summary>
    /// <param name="clientId">ID клиента</param>
    /// <param name="realm">Realm клиента</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>URL Wiki страницы или null если не найдена</returns>
    Task<string?> GetWikiPageUrlAsync(string clientId, string realm, CancellationToken cancellationToken = default);

    /// <summary>
    /// Проверить доступность Confluence API
    /// </summary>
    /// <returns>True если API доступен</returns>
    Task<bool> IsAvailableAsync();
}

