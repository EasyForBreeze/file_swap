using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для управления клиентами Keycloak (CRUD операции)
/// </summary>
public interface IKeycloakClientManagementService
{
    /// <summary>
    /// Создать нового клиента в Keycloak
    /// </summary>
    Task<string> CreateClientAsync(CreateClientRequestDto request, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Обновить детали клиента в Keycloak
    /// </summary>
    Task UpdateClientDetailsAsync(ClientDetailsDto clientDetails, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Удалить клиента из Keycloak
    /// </summary>
    Task DeleteClientAsync(string clientId, string realm, string internalId, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Регенерация client secret
    /// </summary>
    Task<string?> RegenerateClientSecretAsync(string clientId, string realm, string internalId, CancellationToken cancellationToken = default);
}

