namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс сервиса для создания архивов с учетными данными клиентов
/// </summary>
public interface IClientArchiveService : IDisposable
{
    /// <summary>
    /// Генерирует случайный пароль для архива
    /// </summary>
    /// <param name="length">Длина пароля (по умолчанию 16)</param>
    /// <returns>Сгенерированный пароль</returns>
    /// <exception cref="ArgumentException">Если длина пароля вне допустимого диапазона</exception>
    string GeneratePassword(int length = 16);
    
    /// <summary>
    /// Создает текстовый файл с учетными данными клиента
    /// </summary>
    /// <param name="clientId">Client ID</param>
    /// <param name="clientSecret">Client Secret</param>
    /// <returns>Путь к созданному файлу</returns>
    /// <exception cref="ArgumentException">Если параметры невалидны</exception>
    string CreateCredentialsFile(string clientId, string clientSecret);
    
    /// <summary>
    /// Создает защищенный паролем ZIP архив
    /// </summary>
    /// <param name="sourceFilePath">Путь к файлу для архивации</param>
    /// <param name="password">Пароль для архива (не может быть пустым)</param>
    /// <returns>Путь к созданному архиву</returns>
    /// <exception cref="ArgumentException">Если параметры невалидны</exception>
    /// <exception cref="FileNotFoundException">Если исходный файл не найден</exception>
    /// <exception cref="UnauthorizedAccessException">Если доступ к файлу запрещен</exception>
    /// <exception cref="IOException">Если произошла ошибка ввода-вывода</exception>
    string CreatePasswordProtectedArchive(string sourceFilePath, string password);
    
    /// <summary>
    /// Удаляет временные файлы (оригинальный файл и архив)
    /// </summary>
    /// <param name="filePaths">Пути к файлам для удаления</param>
    void CleanupFiles(IEnumerable<string> filePaths);
    
    /// <summary>
    /// Создает полный пакет: файл с учетными данными + защищенный архив
    /// </summary>
    /// <param name="clientId">Client ID</param>
    /// <param name="clientSecret">Client Secret</param>
    /// <returns>Tuple с путем к архиву и паролем</returns>
    /// <exception cref="ArgumentException">Если параметры невалидны</exception>
    (string ArchivePath, string Password) CreateClientCredentialsPackage(string clientId, string clientSecret);
    
    /// <summary>
    /// Получает путь к архиву по Client ID
    /// </summary>
    /// <param name="clientId">Client ID</param>
    /// <returns>Путь к архиву или null если не найден</returns>
    /// <exception cref="ArgumentException">Если Client ID невалиден</exception>
    string? GetArchivePath(string clientId);
    
    /// <summary>
    /// Очищает старые архивы
    /// </summary>
    /// <param name="retentionDays">Количество дней хранения (по умолчанию 1)</param>
    /// <returns>Количество удаленных файлов и общий размер</returns>
    /// <exception cref="ArgumentException">Если количество дней вне допустимого диапазона</exception>
    (int DeletedCount, long TotalSizeBytes) CleanupOldArchives(int retentionDays = 1);
    
    /// <summary>
    /// Получает статистику по архивам
    /// </summary>
    /// <returns>Количество файлов, общий размер и дата создания самого старого файла</returns>
    (int FileCount, long TotalSizeBytes, DateTime? OldestFileDate) GetArchiveStats();
}

