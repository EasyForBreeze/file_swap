using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для сервиса создания клиентов Keycloak
/// </summary>
public interface IClientCreationService
{
    /// <summary>
    /// Событие успешного создания клиента (асинхронное)
    /// </summary>
    event Func<string, string, Task>? OnClientCreated;

    /// <summary>
    /// Создать клиента в Keycloak
    /// </summary>
    /// <param name="data">Данные для создания клиента</param>
    /// <param name="username">Имя пользователя, создающего клиента (опционально)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Результат создания клиента</returns>
    Task<CreateClientResponse> CreateClientAsync(
        ClientCreationData data,
        string? username = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Создать клиента с расширенной информацией (для администраторов)
    /// Включает создание архива, отправку email и возврат полной информации
    /// </summary>
    /// <param name="data">Данные для создания клиента</param>
    /// <param name="username">Имя пользователя, создающего клиента (опционально)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Результат создания клиента с полной информацией</returns>
    Task<ClientCreationResultDto> CreateClientWithFullInfoAsync(
        ClientCreationData data,
        string? username = null,
        CancellationToken cancellationToken = default);
}

