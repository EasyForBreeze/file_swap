# Result Pattern - Руководство по использованию

## Обзор

Result Pattern используется для явной обработки ошибок без использования исключений для бизнес-логики.

## Типы Result

### Result<T>

Результат операции с возвращаемым значением.

```csharp
Result<ClientDetailsDto> result = await service.GetClientDetailsAsync(clientId, realm);

if (result.IsSuccess)
{
    var client = result.Value; // Безопасный доступ
    // или
    if (result.TryGetValue(out var client))
    {
        // Использование client
    }
}
else
{
    var error = result.ErrorMessage;
    var exception = result.Exception;
}
```

### Result

Результат операции без возвращаемого значения.

```csharp
Result result = await service.DeleteClientAsync(clientId, realm);

if (result.IsSuccess)
{
    // Операция успешна
}
else
{
    var error = result.ErrorMessage;
}
```

## Создание результатов

### Успешный результат

```csharp
// С значением
return Result<ClientDetailsDto>.Success(clientDetails);

// Без значения
return Result.Success();
```

### Результат с ошибкой

```csharp
// С сообщением об ошибке
return Result<ClientDetailsDto>.Failure("Client not found");

// С исключением
return Result<ClientDetailsDto>.Failure("Operation failed", exception);

// Из HTTP ошибки
return Result<ClientDetailsDto>.FromHttpError(HttpStatusCode.NotFound, "Client not found");
```

## Функциональные методы

### OnSuccess / OnFailure

```csharp
result
    .OnSuccess(client => Console.WriteLine($"Client: {client.Name}"))
    .OnFailure(error => Console.WriteLine($"Error: {error}"));
```

### Map

Преобразование результата в другой тип:

```csharp
Result<string> stringResult = intResult.Map(x => x.ToString());
```

## Миграция существующего кода

### Замена null возвращаемых значений

**Было:**
```csharp
Task<ClientDetailsDto?> GetClientDetailsAsync(string clientId, string realm);
```

**Стало:**
```csharp
Task<Result<ClientDetailsDto>> GetClientDetailsAsync(string clientId, string realm);
```

### Замена bool возвращаемых значений

**Было:**
```csharp
Task<bool> DeleteClientAsync(string clientId, string realm);
```

**Стало:**
```csharp
Task<Result> DeleteClientAsync(string clientId, string realm);
```

## Рекомендации

1. **Используйте Result pattern** для всех операций, которые могут завершиться ошибкой
2. **Не используйте исключения** для бизнес-логики (только для неожиданных ошибок)
3. **Проверяйте IsSuccess** перед доступом к Value
4. **Используйте TryGetValue** для безопасного доступа к значению
5. **Предоставляйте информативные сообщения об ошибках** в ErrorMessage

## Примеры использования

### В сервисах

```csharp
public async Task<Result<ClientDetailsDto>> GetClientDetailsAsync(string clientId, string realm)
{
    try
    {
        var client = await _keycloakService.GetClientAsync(clientId, realm);
        if (client == null)
        {
            return Result<ClientDetailsDto>.Failure($"Client {clientId} not found in realm {realm}");
        }
        return Result<ClientDetailsDto>.Success(client);
    }
    catch (Exception ex)
    {
        return Result<ClientDetailsDto>.Failure($"Error retrieving client: {ex.Message}", ex);
    }
}
```

### В контроллерах

```csharp
[HttpGet("{clientId}")]
public async Task<IActionResult> GetClient(string clientId, string realm)
{
    var result = await _service.GetClientDetailsAsync(clientId, realm);
    
    if (result.IsSuccess)
    {
        return Ok(result.Value);
    }
    
    return result.StatusCode.HasValue
        ? StatusCode((int)result.StatusCode.Value, new { error = result.ErrorMessage })
        : BadRequest(new { error = result.ErrorMessage });
}
```

