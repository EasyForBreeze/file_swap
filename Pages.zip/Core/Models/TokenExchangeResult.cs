using System;
using System.Collections.Generic;
using System.Security.Claims;

namespace new_assistant.Core.Models;

/// <summary>
/// Результат обмена токенов
/// </summary>
/// <remarks>
/// ВАЖНО: Токены хранятся в памяти как обычные строки. 
/// В .NET Core SecureString имеет ограниченную эффективность, поэтому используется обычная строка.
/// Рекомендуется использовать токены сразу после получения и не хранить их дольше необходимого.
/// </remarks>
public record TokenExchangeResult
{
    public string AccessToken { get; init; } = string.Empty;
    public string? RefreshToken { get; init; }
    public DateTime ExpiresAtUtc { get; init; }
    public IReadOnlyCollection<Claim> Claims { get; init; } = Array.Empty<Claim>();
    
    /// <summary>
    /// Проверяет, истек ли токен
    /// </summary>
    public bool IsExpired => DateTime.UtcNow >= ExpiresAtUtc;
    
    /// <summary>
    /// Проверяет, валиден ли токен (не истек)
    /// </summary>
    public bool IsValid => !IsExpired && !string.IsNullOrEmpty(AccessToken);
}

