namespace new_assistant.Core.Models;

/// <summary>
/// Результат операции с явной обработкой ошибок (Result pattern)
/// </summary>
/// <typeparam name="T">Тип возвращаемого значения</typeparam>
public class Result<T>
{
    /// <summary>
    /// Успешно ли выполнена операция
    /// </summary>
    public bool IsSuccess { get; private set; }

    /// <summary>
    /// Значение результата (доступно только при IsSuccess = true)
    /// </summary>
    public T? Value
    {
        get
        {
            if (!IsSuccess)
                throw new InvalidOperationException("Cannot access Value when IsSuccess is false. Use TryGetValue for safe access.");
            return _value;
        }
        private set => _value = value;
    }
    
    private T? _value;

    /// <summary>
    /// Сообщение об ошибке (доступно только при IsSuccess = false)
    /// </summary>
    public string? ErrorMessage { get; private set; }

    /// <summary>
    /// Исключение, если оно было поймано
    /// </summary>
    public Exception? Exception { get; private set; }

    /// <summary>
    /// HTTP статус код, если ошибка связана с HTTP запросом
    /// </summary>
    public System.Net.HttpStatusCode? StatusCode { get; private set; }

    private Result(bool isSuccess, T? value, string? errorMessage, Exception? exception, System.Net.HttpStatusCode? statusCode)
    {
        IsSuccess = isSuccess;
        _value = value;
        ErrorMessage = errorMessage;
        Exception = exception;
        StatusCode = statusCode;
    }
    
    /// <summary>
    /// Безопасно получает значение результата
    /// </summary>
    /// <param name="value">Значение результата, если операция успешна</param>
    /// <returns>true, если операция успешна и значение доступно</returns>
    public bool TryGetValue(out T? value)
    {
        if (IsSuccess)
        {
            value = _value;
            return true;
        }
        value = default;
        return false;
    }

    /// <summary>
    /// Создать успешный результат
    /// </summary>
    public static Result<T> Success(T value)
    {
        return new Result<T>(true, value, null, null, null);
    }

    /// <summary>
    /// Создать результат с ошибкой
    /// </summary>
    public static Result<T> Failure(string errorMessage, Exception? exception = null, System.Net.HttpStatusCode? statusCode = null)
    {
        return new Result<T>(false, default, errorMessage, exception, statusCode);
    }

    /// <summary>
    /// Создать результат с ошибкой из HTTP ответа
    /// </summary>
    public static Result<T> FromHttpError(System.Net.HttpStatusCode statusCode, string errorMessage)
    {
        return new Result<T>(false, default, errorMessage, null, statusCode);
    }

    /// <summary>
    /// Выполняет действие при успешном результате
    /// </summary>
    public Result<T> OnSuccess(Action<T> action)
    {
        if (IsSuccess && action != null)
        {
            action(_value!);
        }
        return this;
    }

    /// <summary>
    /// Выполняет действие при ошибке
    /// </summary>
    public Result<T> OnFailure(Action<string> action)
    {
        if (!IsSuccess && action != null)
        {
            action(ErrorMessage ?? "Unknown error");
        }
        return this;
    }

    /// <summary>
    /// Преобразует результат в другой тип
    /// </summary>
    public Result<TOut> Map<TOut>(Func<T, TOut> mapper)
    {
        if (IsSuccess && mapper != null)
        {
            try
            {
                return Result<TOut>.Success(mapper(_value!));
            }
            catch (Exception ex)
            {
                return Result<TOut>.Failure($"Mapping failed: {ex.Message}", ex);
            }
        }
        return Result<TOut>.Failure(ErrorMessage ?? "Unknown error", Exception, StatusCode);
    }

    /// <summary>
    /// Неявное преобразование в bool для удобства проверки
    /// </summary>
    public static implicit operator bool(Result<T> result) => result.IsSuccess;

    /// <summary>
    /// Неявное преобразование в T? для удобства доступа к значению
    /// </summary>
    /// <remarks>
    /// Используйте TryGetValue для безопасного доступа к значению
    /// </remarks>
    [Obsolete("Use TryGetValue for safe access to Value")]
    public static implicit operator T?(Result<T> result) => result.IsSuccess ? result._value : default;
}

/// <summary>
/// Результат операции без возвращаемого значения
/// </summary>
public class Result
{
    /// <summary>
    /// Успешно ли выполнена операция
    /// </summary>
    public bool IsSuccess { get; private set; }

    /// <summary>
    /// Сообщение об ошибке (доступно только при IsSuccess = false)
    /// </summary>
    public string? ErrorMessage { get; private set; }

    /// <summary>
    /// Исключение, если оно было поймано
    /// </summary>
    public Exception? Exception { get; private set; }

    /// <summary>
    /// HTTP статус код, если ошибка связана с HTTP запросом
    /// </summary>
    public System.Net.HttpStatusCode? StatusCode { get; private set; }

    private Result(bool isSuccess, string? errorMessage, Exception? exception, System.Net.HttpStatusCode? statusCode)
    {
        IsSuccess = isSuccess;
        ErrorMessage = errorMessage;
        Exception = exception;
        StatusCode = statusCode;
    }

    /// <summary>
    /// Создать успешный результат
    /// </summary>
    public static Result Success()
    {
        return new Result(true, null, null, null);
    }

    /// <summary>
    /// Создать результат с ошибкой
    /// </summary>
    public static Result Failure(string errorMessage, Exception? exception = null, System.Net.HttpStatusCode? statusCode = null)
    {
        return new Result(false, errorMessage, exception, statusCode);
    }

    /// <summary>
    /// Создать результат с ошибкой из HTTP ответа
    /// </summary>
    public static Result FromHttpError(System.Net.HttpStatusCode statusCode, string errorMessage)
    {
        return new Result(false, errorMessage, null, statusCode);
    }

    /// <summary>
    /// Выполняет действие при успешном результате
    /// </summary>
    public Result OnSuccess(Action action)
    {
        if (IsSuccess && action != null)
        {
            action();
        }
        return this;
    }

    /// <summary>
    /// Выполняет действие при ошибке
    /// </summary>
    public Result OnFailure(Action<string> action)
    {
        if (!IsSuccess && action != null)
        {
            action(ErrorMessage ?? "Unknown error");
        }
        return this;
    }

    /// <summary>
    /// Преобразует результат в Result<T>
    /// </summary>
    public Result<T> ToResult<T>(T value)
    {
        if (IsSuccess)
        {
            return Result<T>.Success(value);
        }
        return Result<T>.Failure(ErrorMessage ?? "Unknown error", Exception, StatusCode);
    }

    /// <summary>
    /// Неявное преобразование в bool для удобства проверки
    /// </summary>
    public static implicit operator bool(Result result) => result.IsSuccess;
}

