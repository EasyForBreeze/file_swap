using new_assistant.Core.Helpers;

namespace new_assistant.Core.Constants;

/// <summary>
/// Форматирование сообщений для аудит-логов
/// </summary>
public static class AuditMessageFormatter
{
    public static string ClientCreated(string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        // Экранируем HTML для защиты от XSS
        var safeClientId = SecurityHelper.HtmlEncode(clientId);
        var safeRealm = SecurityHelper.HtmlEncode(realm);
        
        return $"Создан клиент {safeClientId} в реалме {safeRealm}";
    }

    public static string ClientDeleted(string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        var safeClientId = SecurityHelper.HtmlEncode(clientId);
        var safeRealm = SecurityHelper.HtmlEncode(realm);
        
        return $"Удален клиент {safeClientId} из реалма {safeRealm}";
    }

    public static string ClientUpdated(string changedFields)
    {
        if (string.IsNullOrWhiteSpace(changedFields))
            throw new ArgumentException("Changed fields cannot be null or empty", nameof(changedFields));
        
        var safeChangedFields = SecurityHelper.HtmlEncode(changedFields);
        
        return $"Изменены поля: {safeChangedFields}";
    }

    public static string AccessGranted(string targetUsername, string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(targetUsername))
            throw new ArgumentException("Target username cannot be null or empty", nameof(targetUsername));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        var safeUsername = SecurityHelper.HtmlEncode(targetUsername);
        var safeClientId = SecurityHelper.HtmlEncode(clientId);
        var safeRealm = SecurityHelper.HtmlEncode(realm);
        
        return $"Пользователю {safeUsername} предоставлен доступ к клиенту {safeClientId} в реалме {safeRealm}";
    }

    public static string AccessRevoked(string targetUsername, string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(targetUsername))
            throw new ArgumentException("Target username cannot be null or empty", nameof(targetUsername));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        var safeUsername = SecurityHelper.HtmlEncode(targetUsername);
        var safeClientId = SecurityHelper.HtmlEncode(clientId);
        var safeRealm = SecurityHelper.HtmlEncode(realm);
        
        return $"У пользователя {safeUsername} отозван доступ к клиенту {safeClientId} в реалме {safeRealm}";
    }

    public static string RoleAdded(string roleName, string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(roleName))
            throw new ArgumentException("Role name cannot be null or empty", nameof(roleName));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        var safeRoleName = SecurityHelper.HtmlEncode(roleName);
        var safeClientId = SecurityHelper.HtmlEncode(clientId);
        var safeRealm = SecurityHelper.HtmlEncode(realm);
        
        return $"Добавлена роль '{safeRoleName}' для клиента {safeClientId} в реалме {safeRealm}";
    }

    public static string RoleRemoved(string roleName, string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(roleName))
            throw new ArgumentException("Role name cannot be null or empty", nameof(roleName));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        var safeRoleName = SecurityHelper.HtmlEncode(roleName);
        var safeClientId = SecurityHelper.HtmlEncode(clientId);
        var safeRealm = SecurityHelper.HtmlEncode(realm);
        
        return $"Удалена роль '{safeRoleName}' для клиента {safeClientId} в реалме {safeRealm}";
    }

    public static string SecretRegenerated(string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        var safeClientId = SecurityHelper.HtmlEncode(clientId);
        var safeRealm = SecurityHelper.HtmlEncode(realm);
        
        return $"Регенерирован Client Secret для клиента {safeClientId} в реалме {safeRealm}";
    }

    public static string UserLogin(string username)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        
        var safeUsername = SecurityHelper.HtmlEncode(username);
        
        return $"Пользователь {safeUsername} вошел в систему";
    }

    public static string ForbiddenClientAdded(string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        var safeClientId = SecurityHelper.HtmlEncode(clientId);
        var safeRealm = SecurityHelper.HtmlEncode(realm);
        
        return $"Клиент {safeClientId} из реалма {safeRealm} добавлен в запрещенные";
    }

    public static string ForbiddenClientRemoved(string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        var safeClientId = SecurityHelper.HtmlEncode(clientId);
        var safeRealm = SecurityHelper.HtmlEncode(realm);
        
        return $"Клиент {safeClientId} из реалма {safeRealm} удален из запрещенных";
    }

    public static string ClientMigrated(string sourceRealm, string targetRealm, string status)
    {
        if (string.IsNullOrWhiteSpace(sourceRealm))
            throw new ArgumentException("Source realm cannot be null or empty", nameof(sourceRealm));
        if (string.IsNullOrWhiteSpace(targetRealm))
            throw new ArgumentException("Target realm cannot be null or empty", nameof(targetRealm));
        if (string.IsNullOrWhiteSpace(status))
            throw new ArgumentException("Status cannot be null or empty", nameof(status));
        
        var safeSourceRealm = SecurityHelper.HtmlEncode(sourceRealm);
        var safeTargetRealm = SecurityHelper.HtmlEncode(targetRealm);
        var safeStatus = SecurityHelper.HtmlEncode(status);
        
        return $"Клиент перенесён из {MigrationConstants.StatusTest} ({safeSourceRealm}) в {MigrationConstants.StatusStage} ({safeTargetRealm}). Статус: {safeStatus}";
    }
}

