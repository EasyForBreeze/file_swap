namespace new_assistant.Core.Constants;

/// <summary>
/// Константы для страницы MyClients
/// </summary>
public static class MyClientsConstants
{
    /// <summary>
    /// Время жизни кэша списка клиентов пользователя
    /// </summary>
    public static readonly TimeSpan UserClientsCacheDuration = TimeSpan.FromMinutes(10);

    /// <summary>
    /// Максимальное количество параллельных запросов при загрузке клиентов
    /// </summary>
    public const int MaxConcurrentClientLoads = 10;

    /// <summary>
    /// Количество попыток повтора при сетевых ошибках
    /// </summary>
    public const int MaxRetryAttempts = 3;

    /// <summary>
    /// Задержка между попытками повтора (в миллисекундах)
    /// </summary>
    public const int RetryDelayMs = 1000;
}

