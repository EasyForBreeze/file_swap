namespace new_assistant.Core.DTOs;

/// <summary>
/// Результат поиска пользователя в Keycloak
/// </summary>
public class UserSearchResultDto
{
    public string Id { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public bool Enabled { get; set; } = true;
    
    public string DisplayName => 
        !string.IsNullOrEmpty(FirstName) || !string.IsNullOrEmpty(LastName)
            ? $"{FirstName} {LastName}".Trim()
            : Username;
}

/// <summary>
/// Результат генерации токена
/// </summary>
public class TokenEvaluationResultDto
{
    public string Token { get; set; } = string.Empty;
    public string TokenType { get; set; } = string.Empty; // "access", "id", "userinfo"
}

