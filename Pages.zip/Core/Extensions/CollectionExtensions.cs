namespace new_assistant.Core.Extensions;

/// <summary>
/// Extension-методы для работы с коллекциями
/// </summary>
public static class CollectionExtensions
{
    // Максимальное количество элементов для проверки на бесконечные последовательности
    private const int MaxCheckCount = 10000;
    
    /// <summary>
    /// Проверяет, является ли коллекция null или пустой
    /// Защищено от бесконечных последовательностей
    /// </summary>
    public static bool IsNullOrEmpty<T>(this IEnumerable<T>? source)
    {
        if (source == null) return true;
        
        // Для коллекций с известным Count - используем его
        if (source is ICollection<T> collection) return collection.Count == 0;
        
        // Для последовательностей - используем TryGetNonEnumeratedCount если доступно
        if (source.TryGetNonEnumeratedCount(out var count))
            return count == 0;
        
        // Для других последовательностей - ограничиваем количество проверяемых элементов
        // для защиты от бесконечных последовательностей
        var enumerator = source.GetEnumerator();
        try
        {
            if (!enumerator.MoveNext())
                return true;
            
            // Если есть хотя бы один элемент, проверяем что последовательность не слишком большая
            // Это защита от DoS через бесконечные последовательности
            var checkedCount = 1;
            while (enumerator.MoveNext() && checkedCount < MaxCheckCount)
            {
                checkedCount++;
            }
            
            // Если достигли лимита, считаем что коллекция не пустая
            // (это безопаснее чем пытаться обработать бесконечную последовательность)
            return false;
        }
        finally
        {
            enumerator.Dispose();
        }
    }
    
    /// <summary>
    /// Проверяет, является ли коллекция не null и не пустой
    /// Защищено от бесконечных последовательностей
    /// </summary>
    public static bool IsNotNullOrEmpty<T>(this IEnumerable<T>? source)
    {
        if (source == null) return false;
        
        // Для коллекций с известным Count - используем его
        if (source is ICollection<T> collection) return collection.Count > 0;
        
        // Для последовательностей - используем TryGetNonEnumeratedCount если доступно
        if (source.TryGetNonEnumeratedCount(out var count))
            return count > 0;
        
        // Для других последовательностей - ограничиваем количество проверяемых элементов
        var enumerator = source.GetEnumerator();
        try
        {
            return enumerator.MoveNext();
        }
        finally
        {
            enumerator.Dispose();
        }
    }
}

