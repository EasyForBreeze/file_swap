using System.Collections.Concurrent;
using System.Diagnostics;
using System.Reflection;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Менеджер для безопасной работы с событиями, предотвращающий утечки памяти
/// Использует слабые ссылки для автоматической очистки подписчиков
/// </summary>
internal class WeakEventManager
{
    private readonly ConcurrentDictionary<object, WeakReference<Action>> _handlers = new();
    private long _handlerCounter = 0;
    private long _operationCount = 0;
    private const int CleanupInterval = 100; // Очистка каждые 100 операций
    private const int MinCleanupInterval = 1; // Минимальный интервал очистки
    private const int CleanupTimeoutMs = 5000; // Таймаут для очистки (5 секунд)
    private readonly ILogger<WeakEventManager>? _logger;
    private readonly object _cleanupLock = new object();
    private volatile bool _isCleaningUp = false;

    // Метрики для мониторинга
    private long _totalHandlersAdded = 0;
    private long _totalHandlersRemoved = 0;
    private long _totalEventsRaised = 0;
    private long _totalExceptions = 0;

    /// <summary>
    /// Инициализирует новый экземпляр WeakEventManager
    /// </summary>
    /// <param name="logger">Опциональный логгер для записи ошибок</param>
    public WeakEventManager(ILogger<WeakEventManager>? logger = null)
    {
        _logger = logger;
        
        // Валидация CleanupInterval (проверка на этапе компиляции не требуется, так как это константа)
        // Если в будущем CleanupInterval станет конфигурируемым, проверка будет актуальна
    }

    /// <summary>
    /// Получает количество активных обработчиков
    /// </summary>
    public int ActiveHandlerCount => _handlers.Count;

    /// <summary>
    /// Получает метрики использования менеджера
    /// </summary>
    public (long TotalAdded, long TotalRemoved, long TotalRaised, long TotalExceptions, int Active) GetMetrics()
    {
        return (Interlocked.Read(ref _totalHandlersAdded),
                Interlocked.Read(ref _totalHandlersRemoved),
                Interlocked.Read(ref _totalEventsRaised),
                Interlocked.Read(ref _totalExceptions),
                _handlers.Count);
    }

    /// <summary>
    /// Валидирует делегат на корректность
    /// </summary>
    private static bool IsValidDelegate(Action? handler)
    {
        if (handler == null)
            return false;

        try
        {
            // Проверяем, что метод не null
            if (handler.Method == null)
                return false;

            // Проверяем, что делегат может быть вызван
            // Это косвенная проверка валидности делегата
            return handler.Method.DeclaringType != null;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Добавляет обработчик события
    /// </summary>
    public void AddEventHandler(Action? handler)
    {
        if (!IsValidDelegate(handler))
        {
            _logger?.LogWarning("Попытка добавить невалидный обработчик события");
            return;
        }

        // Используем уникальные ключи для всех обработчиков, чтобы избежать потери при множественных подписках
        // Безопасная обработка переполнения счетчика
        var newCounter = GetNextHandlerId();

        try
        {
            // handler уже проверен на null и валидность в IsValidDelegate
            var uniqueKey = new HandlerKey(handler!, newCounter);

            if (_handlers.TryAdd(uniqueKey, new WeakReference<Action>(handler!)))
            {
                Interlocked.Increment(ref _totalHandlersAdded);
            }

            // Очищаем мертвые ссылки периодически (каждые CleanupInterval операций)
            var operationCount = Interlocked.Increment(ref _operationCount);
            
            // Безопасная обработка переполнения: используем модуль с проверкой на 0
            var effectiveInterval = Math.Max(CleanupInterval, MinCleanupInterval);
            if (operationCount > 0 && operationCount % effectiveInterval == 0)
            {
                CleanupDeadReferences();
            }
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Ошибка при добавлении обработчика события");
            Interlocked.Increment(ref _totalExceptions);
        }
    }

    /// <summary>
    /// Безопасно получает следующий ID для обработчика с обработкой переполнения
    /// </summary>
    private long GetNextHandlerId()
    {
        var newCounter = Interlocked.Increment(ref _handlerCounter);
        
        // Обработка переполнения: после переполнения long.MaxValue значение становится отрицательным
        if (newCounter <= 0)
        {
            // Атомарно сбрасываем счетчик, если он еще не был сброшен другим потоком
            var original = Interlocked.CompareExchange(ref _handlerCounter, 1, newCounter);
            
            // Если сброс не удался (другой поток уже сбросил), получаем новое значение
            if (original != newCounter)
            {
                // Другой поток уже сбросил, получаем актуальное значение
                newCounter = Interlocked.Read(ref _handlerCounter);
                // Если все еще отрицательное или 0, инкрементируем
                if (newCounter <= 0)
                {
                    newCounter = Interlocked.Increment(ref _handlerCounter);
                }
            }
            else
            {
                // Успешно сбросили на 1
                newCounter = 1;
            }
        }
        
        return newCounter;
    }

    /// <summary>
    /// Создает безопасный snapshot словаря для итерации
    /// </summary>
    private List<KeyValuePair<object, WeakReference<Action>>> CreateSnapshot()
    {
        // Используем более эффективный подход: копируем только ключи и значения
        // Это безопаснее, чем ToArray(), так как мы работаем с ConcurrentDictionary
        var snapshot = new List<KeyValuePair<object, WeakReference<Action>>>(_handlers.Count);
        
        foreach (var kvp in _handlers)
        {
            snapshot.Add(kvp);
        }
        
        return snapshot;
    }

    /// <summary>
    /// Удаляет обработчик события
    /// </summary>
    /// <remarks>
    /// Удаляет все обработчики с одинаковым методом и target.
    /// Если один и тот же метод был подписан несколько раз, все подписки будут удалены.
    /// </remarks>
    public void RemoveEventHandler(Action? handler)
    {
        if (!IsValidDelegate(handler))
        {
            return;
        }

        try
        {
            // handler уже проверен на null и валидность в IsValidDelegate
            var keysToRemove = FindMatchingHandlerKeys(handler!);
            
            // Удаляем найденные ключи
            var removedCount = 0;
            foreach (var key in keysToRemove)
            {
                if (_handlers.TryRemove(key, out _))
                {
                    removedCount++;
                }
            }
            
            if (removedCount > 0)
            {
                Interlocked.Add(ref _totalHandlersRemoved, removedCount);
            }
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Ошибка при удалении обработчика события");
            Interlocked.Increment(ref _totalExceptions);
        }
    }

    /// <summary>
    /// Находит ключи обработчиков, соответствующие указанному делегату
    /// </summary>
    private List<object> FindMatchingHandlerKeys(Action handler)
    {
        var keysToRemove = new List<object>();
        var snapshot = CreateSnapshot();
        
        foreach (var kvp in snapshot)
        {
            if (kvp.Key is HandlerKey handlerKey && handlerKey.Matches(handler))
            {
                keysToRemove.Add(kvp.Key);
            }
        }
        
        return keysToRemove;
    }

    /// <summary>
    /// Вызывает все активные обработчики
    /// </summary>
    public void RaiseEvent()
    {
        Interlocked.Increment(ref _totalEventsRaised);
        
        // Очищаем мертвые ссылки перед вызовом
        CleanupDeadReferences();

        // Создаем snapshot для безопасной итерации
        var handlersToInvoke = CollectActiveHandlers();

        // Вызываем обработчики вне итерации по словарю
        foreach (var handler in handlersToInvoke)
        {
            try
            {
                handler.Invoke();
            }
            catch (OperationCanceledException)
            {
                // Игнорируем отмененные операции
                _logger?.LogDebug("Обработчик события был отменен");
            }
            catch (ThreadAbortException)
            {
                // Пробрасываем ThreadAbortException, так как это критическое исключение
                throw;
            }
            catch (OutOfMemoryException)
            {
                // Пробрасываем OutOfMemoryException, так как это критическое исключение
                throw;
            }
            catch (Exception ex)
            {
                // Логируем ошибки с использованием структурированного логирования
                _logger?.LogError(ex, 
                    "Ошибка при вызове обработчика события в WeakEventManager. Тип исключения: {ExceptionType}",
                    ex.GetType().Name);
                Interlocked.Increment(ref _totalExceptions);
                // Игнорируем ошибки в обработчиках, чтобы не прерывать выполнение других
            }
        }
    }

    /// <summary>
    /// Собирает все активные обработчики из словаря
    /// </summary>
    private List<Action> CollectActiveHandlers()
    {
        var handlersToInvoke = new List<Action>();
        var snapshot = CreateSnapshot();
        
        foreach (var kvp in snapshot)
        {
            if (kvp.Value.TryGetTarget(out var handler))
            {
                handlersToInvoke.Add(handler);
            }
        }
        
        return handlersToInvoke;
    }

    /// <summary>
    /// Очищает все обработчики событий
    /// </summary>
    public void Clear()
    {
        lock (_cleanupLock)
        {
            var count = _handlers.Count;
            _handlers.Clear();
            Interlocked.Exchange(ref _handlerCounter, 0);
            Interlocked.Exchange(ref _operationCount, 0);
            
            if (count > 0)
            {
                Interlocked.Add(ref _totalHandlersRemoved, count);
            }
        }
    }

    /// <summary>
    /// Очищает мертвые ссылки с таймаутом
    /// </summary>
    private void CleanupDeadReferences()
    {
        // Предотвращаем параллельные вызовы очистки
        if (_isCleaningUp)
            return;

        lock (_cleanupLock)
        {
            if (_isCleaningUp)
                return;

            _isCleaningUp = true;
            try
            {
                var stopwatch = Stopwatch.StartNew();
                var keysToRemove = new List<object>();
                var snapshot = CreateSnapshot();
                
                foreach (var kvp in snapshot)
                {
                    // Проверяем таймаут
                    if (stopwatch.ElapsedMilliseconds > CleanupTimeoutMs)
                    {
                        _logger?.LogWarning(
                            "Очистка мертвых ссылок превысила таймаут ({TimeoutMs} мс). Прерывание очистки.",
                            CleanupTimeoutMs);
                        break;
                    }
                    
                    if (!kvp.Value.TryGetTarget(out _))
                    {
                        keysToRemove.Add(kvp.Key);
                    }
                }
                
                // Удаляем вне итерации
                var removedCount = 0;
                foreach (var key in keysToRemove)
                {
                    if (_handlers.TryRemove(key, out _))
                    {
                        removedCount++;
                    }
                }
                
                if (removedCount > 0)
                {
                    Interlocked.Add(ref _totalHandlersRemoved, removedCount);
                    _logger?.LogDebug("Очищено {Count} мертвых ссылок за {ElapsedMs} мс", 
                        removedCount, stopwatch.ElapsedMilliseconds);
                }
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Ошибка при очистке мертвых ссылок");
                Interlocked.Increment(ref _totalExceptions);
            }
            finally
            {
                _isCleaningUp = false;
            }
        }
    }

    /// <summary>
    /// Ключ для обработчиков, обеспечивающий уникальность и предотвращающий утечки памяти
    /// Хранит информацию о методе и target вместо самого делегата
    /// Использует WeakReference для Target, чтобы предотвратить утечки памяти
    /// </summary>
    private class HandlerKey
    {
        public MethodInfo Method { get; }
        private readonly WeakReference<object?>? _targetWeakRef;
        private readonly int _targetHashCode; // Кэшируем hash code для производительности
        public long Id { get; }
        private readonly int _cachedHashCode; // Кэшируем общий hash code

        public HandlerKey(Action handler, long id)
        {
            if (handler == null)
                throw new ArgumentNullException(nameof(handler));
            
            Method = handler.Method ?? throw new ArgumentNullException(nameof(handler.Method), 
                "Метод обработчика не может быть null");
            
            // Используем WeakReference для Target, чтобы предотвратить утечки памяти
            var target = handler.Target;
            if (target != null)
            {
                _targetWeakRef = new WeakReference<object?>(target);
                _targetHashCode = target.GetHashCode();
            }
            else
            {
                _targetWeakRef = null;
                _targetHashCode = 0;
            }
            
            Id = id;
            
            // Кэшируем hash code для производительности
            _cachedHashCode = ComputeHashCode();
        }

        /// <summary>
        /// Проверяет, соответствует ли ключ указанному делегату
        /// </summary>
        public bool Matches(Action handler)
        {
            if (handler == null || handler.Method == null)
                return false;

            // Сравниваем метод
            if (Method != handler.Method)
                return false;

            // Сравниваем target
            var handlerTarget = handler.Target;
            if (handlerTarget == null)
            {
                return _targetWeakRef == null || !_targetWeakRef.TryGetTarget(out _);
            }

            // Если у нас есть weak reference, проверяем его
            if (_targetWeakRef != null && _targetWeakRef.TryGetTarget(out var target))
            {
                return ReferenceEquals(target, handlerTarget);
            }

            // Если weak reference уже мертва, но handlerTarget не null, то не совпадает
            return false;
        }

        /// <summary>
        /// Получает target, если он еще жив
        /// </summary>
        public object? GetTarget()
        {
            if (_targetWeakRef == null)
                return null;
            
            _targetWeakRef.TryGetTarget(out var target);
            return target;
        }

        private int ComputeHashCode()
        {
            // Method никогда не может быть null (проверяется в конструкторе)
            var methodHash = Method.GetHashCode();
            return HashCode.Combine(methodHash, _targetHashCode, Id);
        }

        public override bool Equals(object? obj)
        {
            if (obj is not HandlerKey other)
                return false;
            
            // Проверка на null для безопасности
            if (Method == null || other.Method == null)
                return false;
            
            // Сравниваем метод и ID (быстрая проверка)
            if (Method != other.Method || Id != other.Id)
                return false;
            
            // Сравниваем target через weak references
            var thisTarget = GetTarget();
            var otherTarget = other.GetTarget();
            
            return ReferenceEquals(thisTarget, otherTarget);
        }

        public override int GetHashCode()
        {
            // Возвращаем кэшированный hash code для производительности
            return _cachedHashCode;
        }
    }
}
