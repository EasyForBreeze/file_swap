using Microsoft.Extensions.Logging;
using new_assistant.Core.Extensions;
using new_assistant.Core.Interfaces;
using Polly;
using Polly.Retry;
using System.Net;
using System.Net.Sockets;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для работы с ролями при миграции клиентов
/// </summary>
public class ClientMigrationRolesService : IClientMigrationRolesService
{
    private readonly IKeycloakStageService _stageKeycloak;
    private readonly ILogger<ClientMigrationRolesService> _logger;
    private readonly AsyncRetryPolicy _retryPolicy;
    
    private const int RetryCount = 3;
    private const int ExponentialBackoffBase = 2;
    private const int MaxRetryDelaySeconds = 60; // Максимальная задержка 60 секунд
    private const int MaxStringLength = 1000; // Максимальная длина строковых параметров
    private const int MaxScopesCount = 1000; // Максимальное количество scopes
    private const int MaxRolesCount = 10000; // Максимальное количество ролей для предотвращения переполнения
    
    // Предвычисленные задержки для retry (оптимизация вместо Math.Pow)
    private static readonly TimeSpan[] RetryDelays = new[]
    {
        TimeSpan.FromSeconds(2),   // retryAttempt = 1: 2^1 = 2
        TimeSpan.FromSeconds(4),   // retryAttempt = 2: 2^2 = 4
        TimeSpan.FromSeconds(8)    // retryAttempt = 3: 2^3 = 8
    };

    public ClientMigrationRolesService(
        IKeycloakStageService stageKeycloak,
        ILogger<ClientMigrationRolesService> logger)
    {
        _stageKeycloak = stageKeycloak ?? throw new ArgumentNullException(nameof(stageKeycloak));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        
        // Валидация RetryCount
        if (RetryCount <= 0)
        {
            throw new InvalidOperationException($"RetryCount должен быть больше 0, текущее значение: {RetryCount}");
        }
        
        // Настроить retry политику для сетевых операций
        _retryPolicy = Policy
            .Handle<HttpRequestException>()
            .Or<TaskCanceledException>()
            .Or<TimeoutException>()
            .Or<SocketException>()
            .Or<WebException>()
            .Or<OperationCanceledException>()
            .WaitAndRetryAsync(
                retryCount: RetryCount,
                sleepDurationProvider: retryAttempt =>
                {
                    // Используем предвычисленные задержки вместо Math.Pow
                    var delay = retryAttempt <= RetryDelays.Length 
                        ? RetryDelays[retryAttempt - 1] 
                        : TimeSpan.FromSeconds(Math.Min(Math.Pow(ExponentialBackoffBase, retryAttempt), MaxRetryDelaySeconds));
                    return delay;
                },
                onRetry: (exception, timeSpan, retryCount, context) =>
                {
                    _logger.LogWarning(exception, 
                        "Повторная попытка {RetryCount} через {Delay} секунд", 
                        retryCount, timeSpan.TotalSeconds);
                });
    }
    
    /// <summary>
    /// Валидация строковых параметров
    /// </summary>
    private static void ValidateStringParameter(string? value, string paramName)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new ArgumentException($"{paramName} cannot be null or empty", paramName);
        }
        
        if (value.Length > MaxStringLength)
        {
            throw new ArgumentException($"{paramName} length cannot exceed {MaxStringLength} characters", paramName);
        }
    }
    
    /// <summary>
    /// Оптимизированное получение уникальных строк из коллекции с использованием HashSet
    /// </summary>
    private static List<string> GetUniqueNonEmptyStrings(IEnumerable<string>? source)
    {
        if (source == null)
        {
            return new List<string>(0);
        }
        
        var uniqueSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var item in source)
        {
            if (!string.IsNullOrWhiteSpace(item))
            {
                uniqueSet.Add(item);
            }
        }
        
        return new List<string>(uniqueSet);
    }
    
    /// <summary>
    /// Создание контекста ошибки для логирования
    /// </summary>
    private static object CreateErrorContext(
        string internalId,
        string operation,
        Exception exception,
        int? itemsCount = null,
        string? targetClientId = null)
    {
        return new
        {
            InternalId = internalId,
            TargetClientId = targetClientId,
            Operation = operation,
            ErrorType = exception.GetType().Name,
            ErrorMessage = exception.Message,
            ItemsCount = itemsCount
        };
    }
    
    /// <summary>
    /// Фильтрация пустых строк из списка ошибок
    /// </summary>
    private static List<string> FilterEmptyErrors(List<string> errors)
    {
        return errors.Where(e => !string.IsNullOrWhiteSpace(e)).ToList();
    }
    
    /// <summary>
    /// Выполнение операции с retry и проверкой cancellationToken
    /// </summary>
    private async Task<T> ExecuteWithRetryAsync<T>(
        Func<CancellationToken, Task<T>> operation,
        CancellationToken cancellationToken)
    {
        return await _retryPolicy.ExecuteAsync(async (ct) =>
        {
            // Проверка cancellationToken перед выполнением
            ct.ThrowIfCancellationRequested();
            return await operation(ct).ConfigureAwait(false);
        }, cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Выполнение операции с retry и проверкой cancellationToken (void версия)
    /// </summary>
    private async Task ExecuteWithRetryAsync(
        Func<CancellationToken, Task> operation,
        CancellationToken cancellationToken)
    {
        await _retryPolicy.ExecuteAsync(async (ct) =>
        {
            // Проверка cancellationToken перед выполнением
            ct.ThrowIfCancellationRequested();
            await operation(ct).ConfigureAwait(false);
        }, cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Создать локальные роли клиента
    /// </summary>
    public async Task<int> CreateLocalRolesAsync(
        string internalId,
        IEnumerable<string> roles,
        string targetRealm,
        CancellationToken cancellationToken = default)
    {
        ValidateStringParameter(internalId, nameof(internalId));
        ValidateStringParameter(targetRealm, nameof(targetRealm));
        
        var uniqueRoles = GetUniqueNonEmptyStrings(roles);
        
        if (uniqueRoles.Count == 0)
        {
            return 0;
        }
        
        // Проверка на переполнение
        if (uniqueRoles.Count > MaxRolesCount)
        {
            throw new ArgumentException($"Количество ролей не может превышать {MaxRolesCount}", nameof(roles));
        }
        
        try
        {
            await ExecuteWithRetryAsync(async (ct) =>
                await _stageKeycloak.CreateClientRolesAsync(
                    internalId, uniqueRoles, targetRealm, ct).ConfigureAwait(false),
                cancellationToken);
            
            _logger.LogInformation(
                "Создано {Count} локальных ролей для клиента {InternalId}", 
                uniqueRoles.Count, internalId);
            
            return uniqueRoles.Count;
        }
        catch (Exception ex)
        {
            var errorContext = CreateErrorContext(internalId, "CreateLocalRoles", ex, uniqueRoles.Count);
            
            _logger.LogWarning(ex, 
                "Не все локальные роли были созданы для клиента {InternalId}. Context: {@Context}", 
                internalId, errorContext);
            throw;
        }
    }

    /// <summary>
    /// Назначить realm roles для service account
    /// </summary>
    public async Task<int> AssignRealmRolesToServiceAccountAsync(
        string internalId,
        IEnumerable<string> realmRoles,
        string targetRealm,
        CancellationToken cancellationToken = default)
    {
        ValidateStringParameter(internalId, nameof(internalId));
        ValidateStringParameter(targetRealm, nameof(targetRealm));
        
        var uniqueRealmRoles = GetUniqueNonEmptyStrings(realmRoles);
        
        if (uniqueRealmRoles.Count == 0)
        {
            return 0;
        }
        
        // Проверка на переполнение
        if (uniqueRealmRoles.Count > MaxRolesCount)
        {
            throw new ArgumentException($"Количество realm roles не может превышать {MaxRolesCount}", nameof(realmRoles));
        }
        
        try
        {
            await ExecuteWithRetryAsync(async (ct) =>
                await _stageKeycloak.AssignRealmRolesToServiceAccountAsync(
                    internalId, uniqueRealmRoles, targetRealm, ct).ConfigureAwait(false),
                cancellationToken);
            
            _logger.LogInformation(
                "Назначено {Count} realm roles для service account {InternalId}", 
                uniqueRealmRoles.Count, internalId);
            
            return uniqueRealmRoles.Count;
        }
        catch (Exception ex)
        {
            var errorContext = CreateErrorContext(internalId, "AssignRealmRoles", ex, uniqueRealmRoles.Count);
            
            _logger.LogWarning(ex, 
                "Не все realm roles назначены для service account {InternalId}. Context: {@Context}", 
                internalId, errorContext);
            throw;
        }
    }

    /// <summary>
    /// Назначить client roles для service account
    /// </summary>
    public async Task<int> AssignClientRolesToServiceAccountAsync(
        string internalId,
        Dictionary<string, List<string>> clientRolesByClient,
        string targetRealm,
        CancellationToken cancellationToken = default)
    {
        ValidateStringParameter(internalId, nameof(internalId));
        ValidateStringParameter(targetRealm, nameof(targetRealm));
        
        if (clientRolesByClient == null || clientRolesByClient.Count == 0)
        {
            return 0;
        }
        
        long totalRolesAssigned = 0; // Используем long для предотвращения переполнения
        var errors = new List<string>();
        
        foreach (var kvp in clientRolesByClient)
        {
            // Проверка на null для ключа словаря
            if (string.IsNullOrWhiteSpace(kvp.Key))
            {
                errors.Add("Client ID не может быть null или пустым");
                continue;
            }
            
            var targetClientId = kvp.Key;
            var roles = kvp.Value;
            
            if (roles == null || roles.Count == 0)
            {
                continue;
            }
            
            // Проверка на переполнение перед добавлением
            if (totalRolesAssigned + roles.Count > MaxRolesCount)
            {
                errors.Add($"Превышено максимальное количество ролей ({MaxRolesCount}) для клиента '{targetClientId}'");
                continue;
            }
            
            try
            {
                // Дедупликация ролей перед назначением
                var uniqueRoles = GetUniqueNonEmptyStrings(roles);
                
                if (uniqueRoles.Count == 0)
                {
                    continue;
                }
                
                await ExecuteWithRetryAsync(async (ct) =>
                    await _stageKeycloak.AssignClientRolesToServiceAccountAsync(
                        internalId, targetClientId, uniqueRoles, targetRealm, ct).ConfigureAwait(false),
                    cancellationToken);
                
                totalRolesAssigned += uniqueRoles.Count;
                _logger.LogInformation(
                    "Назначено {Count} client roles от '{ClientId}' для service account {InternalId}", 
                    uniqueRoles.Count, targetClientId, internalId);
            }
            catch (Exception ex)
            {
                var errorContext = CreateErrorContext(internalId, "AssignClientRoles", ex, roles.Count, targetClientId);
                
                _logger.LogWarning(ex, 
                    "Не все client roles назначены для {InternalId} от клиента {TargetClientId}. Context: {@Context}", 
                    internalId, targetClientId, errorContext);
                
                var errorMessage = $"Client roles от '{targetClientId}': {ex.Message}";
                if (!string.IsNullOrWhiteSpace(errorMessage))
                {
                    errors.Add(errorMessage);
                }
            }
        }
        
        // Фильтруем пустые ошибки
        var filteredErrors = FilterEmptyErrors(errors);
        
        // Логируем все ошибки, но не выбрасываем исключение, если хотя бы одна роль назначена
        if (filteredErrors.Count > 0)
        {
            if (totalRolesAssigned == 0)
            {
                // Если не назначено ни одной роли - выбрасываем исключение
                var errorMessage = string.Join("; ", filteredErrors);
                throw new InvalidOperationException(
                    $"Не удалось назначить ни одной client role. Ошибки: {errorMessage}");
            }
            else
            {
                // Если назначена хотя бы одна роль - логируем предупреждение
                var errorMessage = string.Join("; ", filteredErrors);
                _logger.LogWarning(
                    "Частичное назначение client roles для {InternalId}. Назначено: {Assigned}, Ошибки: {Errors}",
                    internalId, totalRolesAssigned, errorMessage);
            }
        }
        
        // Проверка на переполнение int при возврате
        if (totalRolesAssigned > int.MaxValue)
        {
            throw new InvalidOperationException($"Количество назначенных ролей превышает максимальное значение int: {totalRolesAssigned}");
        }
        
        return (int)totalRolesAssigned;
    }

    /// <summary>
    /// Назначить client scopes клиенту
    /// </summary>
    public async Task AssignClientScopesAsync(
        string internalId,
        IEnumerable<string> defaultScopes,
        IEnumerable<string> optionalScopes,
        string targetRealm,
        CancellationToken cancellationToken = default)
    {
        ValidateStringParameter(internalId, nameof(internalId));
        ValidateStringParameter(targetRealm, nameof(targetRealm));
        
        // Дедупликация и валидация scopes
        var defaultScopesList = GetUniqueNonEmptyStrings(defaultScopes);
        var optionalScopesList = GetUniqueNonEmptyStrings(optionalScopes);
        
        // Проверка на максимальное количество scopes
        var totalScopes = defaultScopesList.Count + optionalScopesList.Count;
        if (totalScopes > MaxScopesCount)
        {
            throw new ArgumentException(
                $"Общее количество scopes не может превышать {MaxScopesCount}. Текущее значение: {totalScopes}");
        }
        
        // Назначить default scopes
        if (defaultScopesList.Count > 0)
        {
            try
            {
                await ExecuteWithRetryAsync(async (ct) =>
                    await _stageKeycloak.AssignClientScopesAsync(
                        internalId,
                        defaultScopesList,
                        targetRealm,
                        isDefault: true,
                        ct).ConfigureAwait(false),
                    cancellationToken);
                
                _logger.LogInformation(
                    "Назначено {Count} default client scopes для клиента {InternalId}", 
                    defaultScopesList.Count, internalId);
            }
            catch (Exception ex)
            {
                var errorContext = CreateErrorContext(internalId, "AssignDefaultScopes", ex, defaultScopesList.Count);
                
                _logger.LogWarning(ex, 
                    "Не удалось назначить default client scopes для клиента {InternalId}. Context: {@Context}", 
                    internalId, errorContext);
                throw;
            }
        }
        
        // Назначить optional scopes
        if (optionalScopesList.Count > 0)
        {
            try
            {
                await ExecuteWithRetryAsync(async (ct) =>
                    await _stageKeycloak.AssignClientScopesAsync(
                        internalId,
                        optionalScopesList,
                        targetRealm,
                        isDefault: false,
                        ct).ConfigureAwait(false),
                    cancellationToken);
                
                _logger.LogInformation(
                    "Назначено {Count} optional client scopes для клиента {InternalId}", 
                    optionalScopesList.Count, internalId);
            }
            catch (Exception ex)
            {
                var errorContext = CreateErrorContext(internalId, "AssignOptionalScopes", ex, optionalScopesList.Count);
                
                _logger.LogWarning(ex, 
                    "Не удалось назначить optional client scopes для клиента {InternalId}. Context: {@Context}", 
                    internalId, errorContext);
                throw;
            }
        }
    }
}


