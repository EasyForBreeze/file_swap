using Microsoft.Extensions.Logging;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services.Confluence;

/// <summary>
/// Сервис для работы с метками страниц Confluence
/// </summary>
public class ConfluenceLabelsService
{
    private readonly IConfluenceApiClient _apiClient;
    private readonly ILogger<ConfluenceLabelsService> _logger;

    public ConfluenceLabelsService(
        IConfluenceApiClient apiClient,
        ILogger<ConfluenceLabelsService> logger)
    {
        _apiClient = apiClient;
        _logger = logger;
    }

    /// <summary>
    /// Построить список меток по умолчанию для страницы
    /// </summary>
    public List<string> BuildDefaultLabels(string realm)
    {
        var now = DateTime.UtcNow;
        var month = now.Month.ToString("00");
        var year = now.Year.ToString();

        return new List<string>
        {
            "default-flow",
            "ear-idm-clients",
            realm,
            $"ear-{month}-{year}"
        };
    }

    /// <summary>
    /// Добавить метки к странице Confluence
    /// </summary>
    public async Task AddLabelsAsync(string pageId, List<string> labels, CancellationToken cancellationToken)
    {
        // Валидация входных параметров
        if (string.IsNullOrWhiteSpace(pageId))
        {
            throw new ArgumentException("Page ID cannot be null or empty", nameof(pageId));
        }
        
        if (labels == null || labels.Count == 0)
            return;

        var payload = labels
            .Where(l => !string.IsNullOrWhiteSpace(l))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (payload.Count == 0)
            return;

        var success = await _apiClient.AddLabelsAsync(pageId, payload, cancellationToken).ConfigureAwait(false);
        
        if (!success)
        {
            _logger.LogWarning("Не удалось добавить метки к странице {PageId}", pageId);
        }
    }
}
