namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для работы с пагинацией данных
/// </summary>
public class PaginationService
{
    /// <summary>
    /// Получить страницу элементов из коллекции
    /// </summary>
    /// <typeparam name="T">Тип элементов</typeparam>
    /// <param name="items">Коллекция элементов</param>
    /// <param name="page">Номер страницы (начиная с 0)</param>
    /// <param name="pageSize">Размер страницы</param>
    /// <returns>Элементы страницы</returns>
    public IEnumerable<T> GetPage<T>(IEnumerable<T> items, int page, int pageSize)
    {
        if (page < 0)
            page = 0;
        if (pageSize <= 0)
            pageSize = 10;
            
        return items.Skip(page * pageSize).Take(pageSize);
    }
    
    /// <summary>
    /// Вычислить общее количество страниц
    /// </summary>
    /// <param name="totalItems">Общее количество элементов</param>
    /// <param name="pageSize">Размер страницы</param>
    /// <returns>Общее количество страниц</returns>
    public int CalculateTotalPages(int totalItems, int pageSize)
    {
        if (pageSize <= 0)
            return 0;
        return (int)Math.Ceiling((double)totalItems / pageSize);
    }
}

