using System.Net.Mail;
using Microsoft.Extensions.Configuration;
using new_assistant.Core.Constants;
using new_assistant.Core.DTOs;
using new_assistant.Core.Entities;
using new_assistant.Core.Extensions;
using new_assistant.Core.Helpers;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для валидации миграции клиентов
/// </summary>
public class ClientMigrationValidationService : IClientMigrationValidationService
{
    private readonly IKeycloakAdminService _testKeycloak;
    private readonly IKeycloakStageService _stageKeycloak;
    private readonly IWikiPageRepository _wikiPageRepository;
    private readonly ILogger<ClientMigrationValidationService> _logger;
    
    // Ограничение на количество параллельных запросов для валидации scopes
    private static readonly SemaphoreSlim _scopeValidationSemaphore = new(10, 10);
    
    // Максимальное количество scopes для валидации
    private const int MaxScopesCount = 10000;
    
    // Константы для валидации (используем из MigrationConstants)

    public ClientMigrationValidationService(
        IKeycloakAdminService testKeycloak,
        IKeycloakStageService stageKeycloak,
        IWikiPageRepository wikiPageRepository,
        ILogger<ClientMigrationValidationService> logger)
    {
        _testKeycloak = testKeycloak ?? throw new ArgumentNullException(nameof(testKeycloak));
        _stageKeycloak = stageKeycloak ?? throw new ArgumentNullException(nameof(stageKeycloak));
        _wikiPageRepository = wikiPageRepository ?? throw new ArgumentNullException(nameof(wikiPageRepository));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Валидировать возможность переноса клиента
    /// </summary>
    public async Task<MigrationValidationResult> ValidateMigrationAsync(
        ClientMigrationRequest request, 
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        if (request == null)
            throw new ArgumentNullException(nameof(request));
        
        if (string.IsNullOrWhiteSpace(request.ClientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(request));
        
        if (string.IsNullOrWhiteSpace(request.SourceRealm))
            throw new ArgumentException("SourceRealm cannot be null or empty", nameof(request));
        
        if (string.IsNullOrWhiteSpace(request.TargetRealm))
            throw new ArgumentException("TargetRealm cannot be null or empty", nameof(request));
        
        // Валидация длины строк
        ValidateRequestLengths(request);
        
        // Валидация формата email, если указан
        if (!string.IsNullOrWhiteSpace(request.NotificationEmail) && 
            !IsValidEmail(request.NotificationEmail))
        {
            throw new ArgumentException("Invalid email format", nameof(request));
        }
        
        var result = new MigrationValidationResult();

        try
        {
            _logger.LogInformation("Начата валидация переноса клиента {ClientId} из {Source} в {Target}", 
                request.ClientId, request.SourceRealm, request.TargetRealm);

            // 1. Проверка существования клиента в целевом realm
            try
            {
                result.ClientExistsInTarget = await _stageKeycloak.ClientExistsAsync(
                    request.ClientId, request.TargetRealm, cancellationToken).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при проверке существования клиента {ClientId} в STAGE realm {TargetRealm}", 
                    request.ClientId, request.TargetRealm);
                result.CanMigrate = false;
                result.Messages.Add($"❌ Ошибка при проверке существования клиента в STAGE: {ex.Message}");
                return result;
            }

            if (result.ClientExistsInTarget)
            {
                result.CanMigrate = false;
                result.Messages.Add($"❌ Клиент '{request.ClientId}' уже существует в STAGE realm '{request.TargetRealm}'");
                return result;
            }

            // 2. Получить детали клиента из TEST
            ClientDetailsDto? clientDetails;
            try
            {
                clientDetails = await _testKeycloak.GetClientDetailsAsync(
                    request.ClientId, request.SourceRealm, cancellationToken).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при получении деталей клиента {ClientId} из TEST realm {SourceRealm}", 
                    request.ClientId, request.SourceRealm);
                result.CanMigrate = false;
                result.Messages.Add($"❌ Ошибка при получении деталей клиента из TEST: {ex.Message}");
                return result;
            }

            if (clientDetails == null)
            {
                result.CanMigrate = false;
                result.Messages.Add($"❌ Клиент '{request.ClientId}' не найден в TEST realm '{request.SourceRealm}'");
                return result;
            }

            // 3. Проверка Wiki страницы
            var requestedWikiUrl = string.IsNullOrWhiteSpace(request.WikiPageUrl)
                ? null
                : request.WikiPageUrl.Trim();
            
            // Проверка длины WikiPageUrl после Trim
            if (requestedWikiUrl != null && requestedWikiUrl.Length > MigrationConstants.MaxUrlLength)
            {
                result.CanMigrate = false;
                result.Messages.Add($"❌ WikiPageUrl превышает максимальную длину {MigrationConstants.MaxUrlLength} символов после обработки");
                return result;
            }

            ClientWikiPage? existingWikiPage;
            try
            {
                existingWikiPage = await _wikiPageRepository.GetWikiPageAnyRealmAsync(request.ClientId).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Ошибка при получении Wiki страницы для клиента {ClientId}, продолжаем валидацию", request.ClientId);
                existingWikiPage = null;
            }

            var existingWikiUrl = existingWikiPage?.WikiPageUrl?.Trim();
            result.ExistingWikiPageUrl = existingWikiUrl ?? existingWikiPage?.WikiPageUrl;

            if (existingWikiPage == null)
            {
                if (string.IsNullOrWhiteSpace(requestedWikiUrl))
                {
                    result.Messages.Add("⚠️  Wiki страница не найдена в репозитории. Укажите ссылку перед переносом, если страница существует.");
                }
                else
                {
                    result.Messages.Add("⚠️  Wiki страница отсутствует в репозитории. Указанная ссылка будет сохранена при переносе.");
                }
            }
            else if (!string.IsNullOrWhiteSpace(requestedWikiUrl) &&
                     existingWikiUrl != null &&
                     !string.Equals(existingWikiUrl, requestedWikiUrl, StringComparison.OrdinalIgnoreCase))
            {
                result.Messages.Add("⚠️  Ссылка на Wiki страницу будет обновлена на указанное значение.");
            }
            else if (existingWikiPage != null && string.IsNullOrWhiteSpace(requestedWikiUrl))
            {
                result.Messages.Add("⚠️  Wiki страница существует только для исходного окружения. Ссылка будет перенесена автоматически.");
            }

            // 4. Проверка service account roles (realm roles) с дедупликацией и null safety
            var serviceRoles = clientDetails?.ServiceRoles ?? Enumerable.Empty<string>();
            // Кешируем результат для избежания повторного перечисления
            var serviceRolesList = serviceRoles
                .Where(r => !string.IsNullOrWhiteSpace(r))
                .Distinct()
                .ToList();
            
            if (serviceRolesList.Count > 0)
            {
                // Используем HashSet для оптимизации проверки наличия ':'
                var rolesWithColon = new HashSet<string>(serviceRolesList.Where(r => r.Contains(':')));
                
                foreach (var role in serviceRolesList)
                {
                    if (string.IsNullOrWhiteSpace(role))
                        continue;
                    
                    // Парсим формат "realmRole" или "clientId:clientRole"
                    var parsedClientRole = ClientRoleParser.ParseClientRole(role);
                    if (parsedClientRole.HasValue)
                    {
                        var (targetClientId, roleName) = parsedClientRole.Value;
                        
                        if (string.IsNullOrWhiteSpace(targetClientId) || string.IsNullOrWhiteSpace(roleName))
                        {
                            result.Messages.Add($"⚠️  Некорректный формат client role '{role}': пустые значения после парсинга");
                            continue;
                        }

                        try
                        {
                            var exists = await _stageKeycloak.ClientRoleExistsAsync(
                                targetClientId, roleName, request.TargetRealm, cancellationToken).ConfigureAwait(false);

                            if (!exists)
                            {
                                result.MissingClientRoles.Add(role);
                                result.Messages.Add($"⚠️  Client role '{roleName}' клиента '{targetClientId}' не найдена в STAGE");
                            }
                            else
                            {
                                // Роль существует - добавляем в валидированные
                                result.ValidatedClientRoles.Add(role);
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.LogWarning(ex, "Ошибка при проверке client role {Role} для клиента {ClientId}", role, targetClientId);
                            result.Messages.Add($"⚠️  Ошибка при проверке client role '{role}': {ex.Message}");
                        }
                    }
                    else if (rolesWithColon.Contains(role))
                    {
                        // Некорректный формат, но содержит ':'
                        result.Messages.Add($"⚠️  Некорректный формат client role '{role}'");
                    }
                    else
                    {
                        try
                        {
                            var exists = await _stageKeycloak.RealmRoleExistsAsync(
                                role, request.TargetRealm, cancellationToken).ConfigureAwait(false);

                            if (!exists)
                            {
                                result.MissingRealmRoles.Add(role);
                                result.Messages.Add($"⚠️  Realm role '{role}' не найдена в STAGE");
                            }
                            else
                            {
                                // Роль существует - добавляем в валидированные
                                result.ValidatedRealmRoles.Add(role);
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.LogWarning(ex, "Ошибка при проверке realm role {Role}", role);
                            result.Messages.Add($"⚠️  Ошибка при проверке realm role '{role}': {ex.Message}");
                        }
                    }
                }
            }

            // 5. Проверка client scopes (устранение дублирования кода)
            List<string> missingDefault = new();
            List<string> missingOptional = new();
            
            if (clientDetails != null)
            {
                var (validatedDefault, missingDefaultScopes) = await ValidateClientScopesAsync(
                    clientDetails.DefaultClientScopes ?? new List<string>(), 
                    MigrationConstants.ScopeTypeDefault, 
                    request.TargetRealm, 
                    cancellationToken).ConfigureAwait(false);
                
                var (validatedOptional, missingOptionalScopes) = await ValidateClientScopesAsync(
                    clientDetails.OptionalClientScopes ?? new List<string>(), 
                    MigrationConstants.ScopeTypeOptional, 
                    request.TargetRealm, 
                    cancellationToken).ConfigureAwait(false);
                
                result.ValidatedDefaultClientScopes.AddRange(validatedDefault);
                result.ValidatedOptionalClientScopes.AddRange(validatedOptional);
                missingDefault = missingDefaultScopes;
                missingOptional = missingOptionalScopes;
            }
            
            result.MissingClientScopes.AddRange(missingDefault);
            result.MissingClientScopes.AddRange(missingOptional);
            
            // Добавить сообщения для отсутствующих scopes (кэшируем результаты Split)
            foreach (var missing in missingDefault)
            {
                var scopeName = ExtractScopeName(missing);
                result.Messages.Add($"⚠️  Default client scope '{scopeName}' не найден в STAGE");
            }
            
            foreach (var missing in missingOptional)
            {
                var scopeName = ExtractScopeName(missing);
                result.Messages.Add($"⚠️  Optional client scope '{scopeName}' не найден в STAGE");
            }

            // 6. Итоговое решение
            result.CanMigrate = !result.ClientExistsInTarget;

            _logger.LogInformation("Валидация завершена: CanMigrate={CanMigrate}, Warnings={Warnings}", 
                result.CanMigrate, result.WarningCount);

            return result;
        }
        catch (ArgumentNullException ex)
        {
            // Критические исключения перебрасываем для правильной обработки вызывающим кодом
            _logger.LogError(ex, "Критическая ошибка валидации: отсутствует обязательный параметр для клиента {ClientId}", request.ClientId);
            throw;
        }
        catch (ArgumentException ex)
        {
            // Критические исключения валидации перебрасываем
            _logger.LogError(ex, "Ошибка валидации параметров для клиента {ClientId}", request.ClientId);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка валидации переноса клиента {ClientId}", request.ClientId);
            result.CanMigrate = false;
            result.Messages.Add($"❌ Ошибка валидации: {ex.Message}");
            return result;
        }
    }

    /// <summary>
    /// Валидация длины строковых полей запроса
    /// </summary>
    public void ValidateRequestLengths(ClientMigrationRequest request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));
        
        // Валидация ClientId с проверкой на null перед проверкой длины
        if (request.ClientId == null)
            throw new ArgumentException("ClientId cannot be null", nameof(request));
        
        if (request.ClientId.Length > MigrationConstants.MaxClientIdLength)
            throw new ArgumentException(
                $"ClientId превышает максимальную длину {MigrationConstants.MaxClientIdLength} символов", 
                nameof(request));
        
        // Валидация SourceRealm с проверкой на null перед проверкой длины
        if (request.SourceRealm == null)
            throw new ArgumentException("SourceRealm cannot be null", nameof(request));
        
        if (request.SourceRealm.Length > MigrationConstants.MaxRealmLength)
            throw new ArgumentException(
                $"SourceRealm превышает максимальную длину {MigrationConstants.MaxRealmLength} символов", 
                nameof(request));
        
        // Валидация TargetRealm с проверкой на null перед проверкой длины
        if (request.TargetRealm == null)
            throw new ArgumentException("TargetRealm cannot be null", nameof(request));
        
        if (request.TargetRealm.Length > MigrationConstants.MaxRealmLength)
            throw new ArgumentException(
                $"TargetRealm превышает максимальную длину {MigrationConstants.MaxRealmLength} символов", 
                nameof(request));
        
        // Валидация NotificationEmail с проверкой на null перед проверкой длины
        if (!string.IsNullOrWhiteSpace(request.NotificationEmail))
        {
            if (request.NotificationEmail.Length > MigrationConstants.MaxEmailLength)
                throw new ArgumentException(
                    $"NotificationEmail превышает максимальную длину {MigrationConstants.MaxEmailLength} символов", 
                    nameof(request));
        }
        
        // Валидация WikiPageUrl с проверкой на null перед проверкой длины
        if (!string.IsNullOrWhiteSpace(request.WikiPageUrl))
        {
            if (request.WikiPageUrl.Length > MigrationConstants.MaxUrlLength)
                throw new ArgumentException(
                    $"WikiPageUrl превышает максимальную длину {MigrationConstants.MaxUrlLength} символов", 
                    nameof(request));
        }
    }

    /// <summary>
    /// Проверка валидности email адреса
    /// </summary>
    public bool IsValidEmail(string email)
    {
        if (string.IsNullOrWhiteSpace(email))
            return false;
        
        // Дополнительная проверка длины перед парсингом
        if (email.Length > MigrationConstants.MaxEmailLength)
            return false;
        
        try
        {
            var addr = new MailAddress(email);
            // Проверяем, что адрес совпадает с исходным (без пробелов и нормализации)
            // Также проверяем, что нет недопустимых символов
            return addr.Address == email.Trim() && 
                   !email.Contains('\n') && 
                   !email.Contains('\r') &&
                   !email.Contains('\t');
        }
        catch
        {
            return false;
        }
    }
    
    /// <summary>
    /// Извлекает имя scope из строки формата "type:scopeName" или просто "scopeName"
    /// </summary>
    private static string ExtractScopeName(string scope)
    {
        if (string.IsNullOrWhiteSpace(scope))
            return scope ?? string.Empty;
        
        var colonIndex = scope.IndexOf(':', StringComparison.Ordinal);
        return colonIndex >= 0 && colonIndex < scope.Length - 1
            ? scope.Substring(colonIndex + 1)
            : scope;
    }

    /// <summary>
    /// Валидация client scopes (устранение дублирования кода с batch обработкой)
    /// </summary>
    private async Task<(List<string> Validated, List<string> Missing)> ValidateClientScopesAsync(
        IEnumerable<string>? scopes,
        string scopeType,
        string targetRealm,
        CancellationToken cancellationToken)
    {
        var validated = new List<string>();
        var missing = new List<string>();
        
        // Используем extension-метод для проверки коллекции
        if (scopes.IsNullOrEmpty())
            return (validated, missing);
        
        // Дедупликация scopes (scopes уже проверен на null выше)
        var uniqueScopes = scopes!
            .Where(s => !string.IsNullOrWhiteSpace(s))
            .Distinct()
            .ToList();
        
        // Проверка на максимальное количество scopes
        if (uniqueScopes.Count > MaxScopesCount)
        {
            _logger.LogWarning("Количество scopes ({Count}) превышает максимальное значение {MaxCount}, будут обработаны первые {MaxCount}",
                uniqueScopes.Count, MaxScopesCount, MaxScopesCount);
            uniqueScopes = uniqueScopes.Take(MaxScopesCount).ToList();
        }
        
        // Проверка валидности BatchSize
        var batchSize = MigrationConstants.BatchSize;
        if (batchSize <= 0)
        {
            _logger.LogWarning("BatchSize имеет невалидное значение {BatchSize}, используется значение по умолчанию 50", batchSize);
            batchSize = 50;
        }
        
        // Batch обработка для больших списков
        for (int i = 0; i < uniqueScopes.Count; i += batchSize)
        {
            // Проверка отмены перед обработкой батча
            cancellationToken.ThrowIfCancellationRequested();
            
            var batch = uniqueScopes.Skip(i).Take(batchSize).ToList();
            var batchTasks = new List<Task<(string Scope, bool Exists)>>();
            
            foreach (var scope in batch)
            {
                // Проверка отмены перед созданием задачи
                cancellationToken.ThrowIfCancellationRequested();
                
                if (string.IsNullOrWhiteSpace(scope))
                {
                    batchTasks.Add(Task.FromResult((scope ?? string.Empty, false)));
                    continue;
                }
                
                // Создаем задачу с использованием SemaphoreSlim для ограничения параллелизма
                var task = ValidateScopeWithSemaphoreAsync(scope, targetRealm, cancellationToken);
                batchTasks.Add(task);
            }
            
            var batchResults = await Task.WhenAll(batchTasks).ConfigureAwait(false);
            
            foreach (var result in batchResults)
            {
                if (string.IsNullOrWhiteSpace(result.Scope))
                    continue;
                
                if (result.Exists)
                {
                    validated.Add(result.Scope);
                }
                else
                {
                    missing.Add($"{scopeType}:{result.Scope}");
                }
            }
            
            // Проверка на отмену между батчами
            cancellationToken.ThrowIfCancellationRequested();
        }
        
        return (validated, missing);
    }
    
    /// <summary>
    /// Валидирует scope с использованием SemaphoreSlim для ограничения параллелизма
    /// </summary>
    private async Task<(string Scope, bool Exists)> ValidateScopeWithSemaphoreAsync(
        string scope,
        string targetRealm,
        CancellationToken cancellationToken)
    {
        await _scopeValidationSemaphore.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            
            var exists = await _stageKeycloak.ClientScopeExistsAsync(
                scope, targetRealm, cancellationToken).ConfigureAwait(false);
            return (scope, exists);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при валидации scope {Scope}", scope);
            return (scope, false);
        }
        finally
        {
            _scopeValidationSemaphore.Release();
        }
    }
}

