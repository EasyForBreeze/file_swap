using System.Diagnostics;
using System.Text;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Фоновый сервис для автоматической очистки старых аудит логов
/// </summary>
public class AuditLogCleanupService : BackgroundService
{
    private readonly ILogger<AuditLogCleanupService> _logger;
    private readonly DataPathsSettings _dataPathsSettings;
    private readonly AuditLogCleanupSettings _settings;
    private readonly string _connectionString;
    private readonly string _lockFilePath;
    private FileStream? _lockFileStream;
    
    // Константа для логирования прогресса
    private const int ProgressLogBatchInterval = 10;
    
    // Константы для retry логики
    private const int MaxRetryAttempts = 3;
    private const int RetryDelayMs = 100;
    
    // Таймаут для VACUUM операции (по умолчанию 30 минут)
    private static readonly TimeSpan DefaultVacuumTimeout = TimeSpan.FromMinutes(30);
    
    // Таймаут для операции очистки (по умолчанию 2 часа)
    private static readonly TimeSpan DefaultCleanupTimeout = TimeSpan.FromHours(2);

    // Схема таблицы вынесена в константу для устранения дублирования
    private const string CreateTableSql = @"
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            username TEXT NOT NULL,
            client_id TEXT,
            realm TEXT,
            target_username TEXT,
            description TEXT NOT NULL,
            change_details TEXT,
            created_at TEXT NOT NULL
        );
    ";

    // Индексы создаются отдельно и только при первой инициализации
    private const string CreateIndexesSql = @"
        CREATE INDEX IF NOT EXISTS idx_audit_event_type ON audit_logs(event_type);
        CREATE INDEX IF NOT EXISTS idx_audit_username ON audit_logs(username);
        CREATE INDEX IF NOT EXISTS idx_audit_client_id ON audit_logs(client_id);
        CREATE INDEX IF NOT EXISTS idx_audit_realm ON audit_logs(realm);
        CREATE INDEX IF NOT EXISTS idx_audit_created_at ON audit_logs(created_at DESC);
    ";

    public AuditLogCleanupService(
        ILogger<AuditLogCleanupService> logger,
        DataPathsSettings dataPathsSettings,
        IOptions<AuditLogCleanupSettings> settings)
    {
        _logger = logger;
        _dataPathsSettings = dataPathsSettings;
        _settings = settings.Value;

        // Валидация параметров
        if (_settings.RetentionDays <= 0)
            throw new ArgumentException("RetentionDays must be greater than 0", nameof(settings));

        if (_settings.CleanupInterval <= TimeSpan.Zero)
            throw new ArgumentException("CleanupInterval must be greater than TimeSpan.Zero", nameof(settings));

        if (_settings.BatchSize <= 0)
            throw new ArgumentException("BatchSize must be greater than 0", nameof(settings));

        if (_settings.VacuumThresholdPercent < 0 || _settings.VacuumThresholdPercent > 100)
            throw new ArgumentException("VacuumThresholdPercent must be between 0 and 100", nameof(settings));

        if (_settings.ProgressLogIntervalSeconds < 0)
            throw new ArgumentException("ProgressLogIntervalSeconds must be greater than or equal to 0", nameof(settings));

        // Проверка и создание директории для БД
        EnsureDatabaseDirectoryExists();

        var dbPath = _dataPathsSettings.GetAuditDbPath();
        _connectionString = $"Data Source={dbPath};Mode=ReadWriteCreate;Cache=Shared;Pooling=True";

        // Путь к файлу блокировки
        var directory = Path.GetDirectoryName(dbPath) ?? ".";
        _lockFilePath = Path.Combine(directory, "audit_cleanup.lock");
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // Проверка, включен ли сервис
        if (!_settings.Enabled)
        {
            _logger.LogInformation("AuditLogCleanupService отключен через конфигурацию");
            return;
        }

        _logger.LogInformation(
            "🔄 AuditLogCleanupService запущен. Период проверки: {Interval}, Срок хранения: {Retention} дней",
            _settings.CleanupInterval, _settings.RetentionDays);

        // Используем настройку InitialDelay вместо хардкода
        var initialDelay = _settings.InitialDelay ?? TimeSpan.FromMinutes(1);
        await Task.Delay(initialDelay, stoppingToken);

        // Гарантируем, что БД и таблица существуют (может не быть, если ещё не писали аудит)
        try
        {
            await EnsureDatabaseExistsAsync(stoppingToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось инициализировать БД аудита перед очисткой. Продолжаем с последующими попытками.");
        }

        while (!stoppingToken.IsCancellationRequested)
        {
            var lockAcquired = false;
            try
            {
                // Пытаемся получить блокировку перед очисткой
                if (_settings.EnableFileLock)
                {
                    lockAcquired = await TryAcquireLockAsync(stoppingToken);
                    if (!lockAcquired)
                    {
                        _logger.LogDebug("Не удалось получить блокировку для очистки. Другой процесс уже выполняет очистку. Пропускаем итерацию.");
                        await Task.Delay(_settings.CleanupInterval, stoppingToken);
                        continue;
                    }
                }

                await CleanupOldLogsAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Ошибка при очистке старых аудит логов");
            }
            finally
            {
                // Освобождаем блокировку только если она была получена
                if (lockAcquired || !_settings.EnableFileLock)
                {
                    ReleaseLock();
                }
            }

            // Ждём до следующей проверки
            try
            {
                await Task.Delay(_settings.CleanupInterval, stoppingToken);
            }
            catch (TaskCanceledException)
            {
                // Приложение останавливается, выходим из цикла
                break;
            }
        }

        ReleaseLock();
        _logger.LogInformation("⏹️ AuditLogCleanupService остановлен");
    }

    /// <summary>
    /// Удаляет аудит логи старше указанного количества дней
    /// </summary>
    private async Task<CleanupMetrics> CleanupOldLogsAsync(CancellationToken cancellationToken)
    {
        var metrics = new CleanupMetrics { StartTime = DateTime.UtcNow };
        var stopwatch = Stopwatch.StartNew();
        var cutoffDate = DateTime.UtcNow.AddDays(-_settings.RetentionDays);

        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync(cancellationToken);

            // Гарантируем существование схемы
            await EnsureSchemaAsync(connection, cancellationToken);

            // Получаем размер БД до очистки
            metrics.DatabaseSizeBeforeMB = await GetDatabaseSizeMBAsync(connection, cancellationToken);

            // Получаем общее количество записей ДО удаления (для расчета процента VACUUM)
            var totalCountBefore = await GetTotalLogCountAsync(connection, cancellationToken);

            // Сначала узнаём, сколько записей будет удалено (опционально)
            // Используем ISO 8601 формат для совместимости с AuditService
            var cutoffDateString = cutoffDate.ToUniversalTime().ToString("O");
            long countToDelete = 0;

            if (!_settings.SkipCountQuery)
            {
                countToDelete = await GetOldLogsCountAsync(connection, cutoffDateString, cancellationToken);
                metrics.RecordsToDelete = countToDelete;

                if (countToDelete == 0)
                {
                    _logger.LogDebug("✅ Старых логов для удаления не найдено (старше {CutoffDate:yyyy-MM-dd})", cutoffDate);
                    metrics.EndTime = DateTime.UtcNow;
                    metrics.Duration = stopwatch.Elapsed;
                    return metrics;
                }

                _logger.LogInformation(
                    "Найдено {Count} записей для удаления (старше {CutoffDate:yyyy-MM-dd})",
                    countToDelete, cutoffDate);
            }
            else
            {
                _logger.LogInformation(
                    "Пропущен COUNT запрос для оптимизации. Начинаем удаление записей старше {CutoffDate:yyyy-MM-dd}",
                    cutoffDate);
            }

            // Удаляем старые записи батчами
            var deletedCount = await DeleteInBatchesAsync(connection, cutoffDateString, cancellationToken);
            metrics.RecordsDeleted = deletedCount;

            // Выполняем VACUUM только если включен и удалено достаточно записей
            // Используем totalCountBefore для правильного расчета процента
            if (_settings.EnableVacuum && deletedCount > 0 && totalCountBefore > 0)
            {
                // Правильный расчет: процент от общего количества ДО удаления
                var deletedPercent = (deletedCount * 100.0) / totalCountBefore;
                metrics.VacuumExecuted = deletedPercent >= _settings.VacuumThresholdPercent;
                
                if (metrics.VacuumExecuted)
                {
                    await ExecuteVacuumAsync(connection, cancellationToken);
                }
                else
                {
                    _logger.LogDebug(
                        "VACUUM пропущен: удалено {DeletedPercent:F2}% записей (удалено: {Deleted}, было всего: {Total}), требуется минимум {Threshold}%",
                        deletedPercent, deletedCount, totalCountBefore, _settings.VacuumThresholdPercent);
                }
            }

            // Получаем размер БД после очистки
            metrics.DatabaseSizeAfterMB = await GetDatabaseSizeMBAsync(connection, cancellationToken);
            metrics.SizeReductionMB = metrics.DatabaseSizeBeforeMB - metrics.DatabaseSizeAfterMB;

            stopwatch.Stop();
            metrics.EndTime = DateTime.UtcNow;
            metrics.Duration = stopwatch.Elapsed;

            // Логируем метрики
            _logger.LogInformation(
                "🗑️ Очистка аудит логов завершена: удалено {DeletedCount} записей старше {CutoffDate:yyyy-MM-dd}, " +
                "время: {ElapsedMs}мс, размер БД: {SizeBefore:F2}MB → {SizeAfter:F2}MB (уменьшение: {SizeReduction:F2}MB), " +
                "VACUUM: {VacuumExecuted}",
                deletedCount, cutoffDate, metrics.Duration.TotalMilliseconds,
                metrics.DatabaseSizeBeforeMB, metrics.DatabaseSizeAfterMB, metrics.SizeReductionMB,
                metrics.VacuumExecuted ? "выполнен" : "пропущен");

            return metrics;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            metrics.EndTime = DateTime.UtcNow;
            metrics.Duration = stopwatch.Elapsed;
            _logger.LogError(ex, "❌ Ошибка при очистке старых логов, время: {ElapsedMs}мс", metrics.Duration.TotalMilliseconds);
            throw;
        }
    }

    /// <summary>
    /// Получает размер базы данных в мегабайтах
    /// </summary>
    private async Task<double> GetDatabaseSizeMBAsync(
        SqliteConnection connection,
        CancellationToken cancellationToken)
    {
        try
        {
            // Получаем page_count и page_size отдельными запросами
            await using var pageCountCommand = connection.CreateCommand();
            pageCountCommand.CommandText = "PRAGMA page_count";
            var pageCountResult = await pageCountCommand.ExecuteScalarAsync(cancellationToken);
            var pageCount = pageCountResult != null && pageCountResult != DBNull.Value
                ? Convert.ToInt64(pageCountResult)
                : 0L;

            await using var pageSizeCommand = connection.CreateCommand();
            pageSizeCommand.CommandText = "PRAGMA page_size";
            var pageSizeResult = await pageSizeCommand.ExecuteScalarAsync(cancellationToken);
            var pageSize = pageSizeResult != null && pageSizeResult != DBNull.Value
                ? Convert.ToInt64(pageSizeResult)
                : 0L;

            var sizeBytes = pageCount * pageSize;
            return sizeBytes / (1024.0 * 1024.0); // Конвертируем в MB
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось получить размер БД. Возвращаем 0.");
            return 0;
        }
    }

    /// <summary>
    /// Получает количество старых логов для удаления
    /// </summary>
    private async Task<long> GetOldLogsCountAsync(
        SqliteConnection connection,
        string cutoffDateString,
        CancellationToken cancellationToken)
    {
        await using var countCommand = connection.CreateCommand();
        countCommand.CommandText = @"
            SELECT COUNT(*) 
            FROM audit_logs 
            WHERE created_at < @cutoffDate
        ";
        countCommand.Parameters.AddWithValue("@cutoffDate", cutoffDateString);

        var result = await countCommand.ExecuteScalarAsync(cancellationToken);
        return result != null && result != DBNull.Value
            ? Convert.ToInt64(result)
            : 0;
    }

    /// <summary>
    /// Получает общее количество логов в БД
    /// </summary>
    private async Task<long> GetTotalLogCountAsync(
        SqliteConnection connection,
        CancellationToken cancellationToken)
    {
        await using var countCommand = connection.CreateCommand();
        countCommand.CommandText = "SELECT COUNT(*) FROM audit_logs";

        var result = await countCommand.ExecuteScalarAsync(cancellationToken);
        return result != null && result != DBNull.Value
            ? Convert.ToInt64(result)
            : 0;
    }

    /// <summary>
    /// Удаляет записи батчами для оптимизации производительности
    /// </summary>
    private async Task<long> DeleteInBatchesAsync(
        SqliteConnection connection,
        string cutoffDateString,
        CancellationToken cancellationToken)
    {
        long totalDeleted = 0;
        int batchNumber = 0;
        var lastProgressLogTime = DateTime.UtcNow;
        var progressLogInterval = TimeSpan.FromSeconds(_settings.ProgressLogIntervalSeconds);
        var cleanupStartTime = DateTime.UtcNow;
        
        // Создаем CancellationTokenSource с таймаутом для операции очистки
        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutCts.CancelAfter(DefaultCleanupTimeout);
        var effectiveCancellationToken = timeoutCts.Token;

        while (!effectiveCancellationToken.IsCancellationRequested)
        {
            effectiveCancellationToken.ThrowIfCancellationRequested();

            // Проверяем таймаут операции очистки
            if (DateTime.UtcNow - cleanupStartTime > DefaultCleanupTimeout)
            {
                _logger.LogWarning(
                    "Операция очистки превысила максимальное время выполнения ({Timeout}). Прерываем операцию. Удалено {Total} записей в {BatchNumber} батчах",
                    DefaultCleanupTimeout, totalDeleted, batchNumber);
                break;
            }

            await using var transaction = (SqliteTransaction)await connection.BeginTransactionAsync(effectiveCancellationToken);
            try
            {
                await using var deleteCommand = connection.CreateCommand();
                deleteCommand.Transaction = transaction;
                deleteCommand.CommandText = @"
                    DELETE FROM audit_logs 
                    WHERE id IN (
                        SELECT id FROM audit_logs 
                        WHERE created_at < @cutoffDate 
                        LIMIT @batchSize
                    )";
                deleteCommand.Parameters.AddWithValue("@cutoffDate", cutoffDateString);
                deleteCommand.Parameters.AddWithValue("@batchSize", _settings.BatchSize);

                var deleted = await ExecuteWithRetryAsync(
                    async () => await deleteCommand.ExecuteNonQueryAsync(effectiveCancellationToken),
                    $"удаления батча #{batchNumber + 1}",
                    effectiveCancellationToken);
                
                await transaction.CommitAsync(effectiveCancellationToken);

                if (deleted == 0)
                    break;

                totalDeleted += deleted;
                batchNumber++;

                // Логируем прогресс
                if (ShouldLogProgress(batchNumber, lastProgressLogTime, progressLogInterval))
                {
                    lastProgressLogTime = DateTime.UtcNow;
                    _logger.LogInformation(
                        "Прогресс очистки: батч #{BatchNumber}, удалено в батче: {Deleted}, всего удалено: {Total}",
                        batchNumber, deleted, totalDeleted);
                }

                // Небольшая задержка между батчами для снижения нагрузки
                if (_settings.BatchDelayMs > 0)
                {
                    await Task.Delay(_settings.BatchDelayMs, effectiveCancellationToken);
                }
            }
            catch (OperationCanceledException)
            {
                await transaction.RollbackAsync(effectiveCancellationToken);
                _logger.LogWarning("Удаление прервано по запросу отмены. Удалено {Total} записей в {BatchNumber} батчах", totalDeleted, batchNumber);
                throw;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync(effectiveCancellationToken);
                _logger.LogError(ex, "Ошибка при удалении батча #{BatchNumber}", batchNumber);
                throw;
            }
        }

        return totalDeleted;
    }

    /// <summary>
    /// Определяет, нужно ли логировать прогресс
    /// </summary>
    private bool ShouldLogProgress(int batchNumber, DateTime lastProgressLogTime, TimeSpan progressLogInterval)
    {
        if (_settings.ProgressLogIntervalSeconds > 0)
        {
            return DateTime.UtcNow - lastProgressLogTime >= progressLogInterval;
        }
        
        return batchNumber % ProgressLogBatchInterval == 0;
    }

    /// <summary>
    /// Выполняет VACUUM с обработкой ошибок и таймаутом
    /// </summary>
    private async Task ExecuteVacuumAsync(SqliteConnection connection, CancellationToken cancellationToken)
    {
        try
        {
            _logger.LogInformation("Выполняется VACUUM для оптимизации БД...");
            var vacuumStopwatch = Stopwatch.StartNew();

            cancellationToken.ThrowIfCancellationRequested();

            // Создаем CancellationTokenSource с таймаутом для VACUUM
            using var vacuumTimeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            vacuumTimeoutCts.CancelAfter(DefaultVacuumTimeout);
            var vacuumCancellationToken = vacuumTimeoutCts.Token;

            await using var vacuumCommand = connection.CreateCommand();
            vacuumCommand.CommandText = "VACUUM";
            
            try
            {
                await ExecuteWithRetryAsync(
                    async () => await vacuumCommand.ExecuteNonQueryAsync(vacuumCancellationToken),
                    "VACUUM",
                    vacuumCancellationToken);
            }
            catch (OperationCanceledException) when (vacuumTimeoutCts.IsCancellationRequested && !cancellationToken.IsCancellationRequested)
            {
                _logger.LogWarning(
                    "VACUUM прерван по таймауту ({Timeout}). Это не критично, БД продолжит работать нормально.",
                    DefaultVacuumTimeout);
                return; // Не пробрасываем исключение, т.к. VACUUM не критичен
            }

            vacuumStopwatch.Stop();
            _logger.LogInformation(
                "VACUUM выполнен успешно за {ElapsedMs}мс",
                vacuumStopwatch.ElapsedMilliseconds);
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("VACUUM прерван по запросу отмены");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                ex,
                "Не удалось выполнить VACUUM. Это не критично, БД продолжит работать нормально.");
            // Не пробрасываем исключение, т.к. VACUUM не критичен
        }
    }

    /// <summary>
    /// Пытается получить файловую блокировку для предотвращения одновременного выполнения
    /// </summary>
    private async Task<bool> TryAcquireLockAsync(CancellationToken cancellationToken, int retryCount = 0)
    {
        const int maxRetryCount = 1; // Максимум одна попытка повтора при обнаружении мертвой блокировки
        
        FileStream? tempStream = null;
        try
        {
            // Освобождаем предыдущую блокировку, если есть
            ReleaseLock();

            // Пытаемся создать файл с эксклюзивной блокировкой
            // Используем локальную переменную для гарантированного освобождения при исключении
            tempStream = new FileStream(
                _lockFilePath,
                FileMode.Create,
                FileAccess.Write,
                FileShare.None,
                bufferSize: 1,
                useAsync: true);

            // Записываем PID процесса для отладки (используем ASCII для числового значения)
            var pid = Process.GetCurrentProcess().Id;
            var pidBytes = Encoding.ASCII.GetBytes(pid.ToString());
            await tempStream.WriteAsync(new ReadOnlyMemory<byte>(pidBytes), cancellationToken);
            await tempStream.FlushAsync(cancellationToken);

            // Только после успешной записи присваиваем полю
            _lockFileStream = tempStream;
            tempStream = null; // Предотвращаем освобождение в finally

            return true;
        }
        catch (OperationCanceledException)
        {
            // Освобождаем временный поток при отмене
            tempStream?.Dispose();
            ReleaseLock();
            return false;
        }
        catch (IOException)
        {
            // Файл уже заблокирован другим процессом
            tempStream?.Dispose();
            
            // Проверяем, не является ли блокировка "мертвой" (процесс больше не существует)
            if (await IsLockStaleAsync() && retryCount < maxRetryCount)
            {
                _logger.LogWarning("Обнаружена мертвая блокировка. Пытаемся удалить файл блокировки и повторить попытку.");
                try
                {
                    File.Delete(_lockFilePath);
                    // Повторная попытка получить блокировку (с защитой от бесконечной рекурсии)
                    return await TryAcquireLockAsync(cancellationToken, retryCount + 1);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Не удалось удалить мертвую блокировку");
                    return false;
                }
            }
            
            return false;
        }
        catch (Exception ex)
        {
            tempStream?.Dispose();
            _logger.LogWarning(ex, "Неожиданная ошибка при попытке получить блокировку");
            return false;
        }
        finally
        {
            // Освобождаем временный поток, если он не был присвоен полю
            tempStream?.Dispose();
        }
    }

    /// <summary>
    /// Проверяет, является ли блокировка "мертвой" (процесс больше не существует)
    /// </summary>
    private async Task<bool> IsLockStaleAsync()
    {
        try
        {
            if (!File.Exists(_lockFilePath))
                return false;

            // Читаем PID из файла блокировки
            var pidBytes = await File.ReadAllBytesAsync(_lockFilePath);
            if (pidBytes.Length == 0)
                return true; // Пустой файл - считаем мертвой блокировкой

            var pidString = Encoding.ASCII.GetString(pidBytes);
            if (!int.TryParse(pidString, out var pid))
                return true; // Невалидный PID - считаем мертвой блокировкой

            // Проверяем, существует ли процесс с этим PID
            try
            {
                var process = Process.GetProcessById(pid);
                // Процесс существует, проверяем, что это не текущий процесс
                return process.Id != Process.GetCurrentProcess().Id && process.HasExited;
            }
            catch (ArgumentException)
            {
                // Процесс не существует - блокировка мертвая
                return true;
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Ошибка при проверке блокировки на мертвость");
            // В случае ошибки считаем блокировку валидной (безопаснее)
            return false;
        }
    }

    /// <summary>
    /// Освобождает файловую блокировку
    /// </summary>
    private void ReleaseLock()
    {
        try
        {
            _lockFileStream?.Dispose();
            _lockFileStream = null;

            // Удаляем файл блокировки, если он существует
            if (File.Exists(_lockFilePath))
            {
                File.Delete(_lockFilePath);
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при освобождении блокировки");
        }
    }

    /// <summary>
    /// Гарантирует существование файла БД и схемы таблицы аудита
    /// </summary>
    private async Task EnsureDatabaseExistsAsync(CancellationToken cancellationToken)
    {
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await EnsureSchemaAsync(connection, cancellationToken);
    }

    /// <summary>
    /// Гарантирует существование схемы таблицы и индексов
    /// </summary>
    private async Task EnsureSchemaAsync(SqliteConnection connection, CancellationToken cancellationToken)
    {
        // Создаем таблицу всегда (идемпотентно)
        await using var tableCommand = connection.CreateCommand();
        tableCommand.CommandText = CreateTableSql;
        await ExecuteWithRetryAsync(
            async () => await tableCommand.ExecuteNonQueryAsync(cancellationToken),
            "создания таблицы",
            cancellationToken);

        // Создаем индексы идемпотентно (IF NOT EXISTS защищает от дублирования)
        // CREATE INDEX IF NOT EXISTS атомарен и не требует дополнительных проверок
        await using var indexCommand = connection.CreateCommand();
        indexCommand.CommandText = CreateIndexesSql;
        await ExecuteWithRetryAsync(
            async () => await indexCommand.ExecuteNonQueryAsync(cancellationToken),
            "создания индексов",
            cancellationToken);
    }

    /// <summary>
    /// Выполняет операцию с retry логикой для обработки SQLite busy exceptions
    /// </summary>
    private async Task<T> ExecuteWithRetryAsync<T>(
        Func<Task<T>> operation,
        string operationName,
        CancellationToken cancellationToken)
    {
        var attempt = 0;
        while (true)
        {
            try
            {
                return await operation();
            }
            catch (SqliteException ex) when (ex.SqliteErrorCode == 5 && attempt < MaxRetryAttempts) // SQLITE_BUSY
            {
                attempt++;
                _logger.LogDebug(
                    "SQLite busy при {OperationName}, попытка {Attempt}/{MaxAttempts}. Повтор через {DelayMs}мс",
                    operationName, attempt, MaxRetryAttempts, RetryDelayMs);
                
                await Task.Delay(RetryDelayMs * attempt, cancellationToken); // Exponential backoff
            }
            catch (SqliteException ex) when (ex.SqliteErrorCode == 6 && attempt < MaxRetryAttempts) // SQLITE_LOCKED
            {
                attempt++;
                _logger.LogDebug(
                    "SQLite locked при {OperationName}, попытка {Attempt}/{MaxAttempts}. Повтор через {DelayMs}мс",
                    operationName, attempt, MaxRetryAttempts, RetryDelayMs);
                
                await Task.Delay(RetryDelayMs * attempt, cancellationToken); // Exponential backoff
            }
        }
    }

    /// <summary>
    /// Выполняет операцию с retry логикой для обработки SQLite busy exceptions (void версия)
    /// </summary>
    private async Task ExecuteWithRetryAsync(
        Func<Task> operation,
        string operationName,
        CancellationToken cancellationToken)
    {
        await ExecuteWithRetryAsync(
            async () => { await operation(); return 0; },
            operationName,
            cancellationToken);
    }

    /// <summary>
    /// Проверяет и создает директорию для БД, если она не существует
    /// </summary>
    private void EnsureDatabaseDirectoryExists()
    {
        var dbPath = _dataPathsSettings.GetAuditDbPath();
        var directory = Path.GetDirectoryName(dbPath);
        if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
        {
            Directory.CreateDirectory(directory);
            _logger.LogInformation("Создана директория для БД аудита: {Directory}", directory);
        }
    }

    /// <summary>
    /// Метрики очистки для мониторинга
    /// </summary>
    private class CleanupMetrics
    {
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public TimeSpan Duration { get; set; }
        public long RecordsToDelete { get; set; }
        public long RecordsDeleted { get; set; }
        public double DatabaseSizeBeforeMB { get; set; }
        public double DatabaseSizeAfterMB { get; set; }
        public double SizeReductionMB { get; set; }
        public bool VacuumExecuted { get; set; }
    }

    public override void Dispose()
    {
        ReleaseLock();
        base.Dispose();
    }
}
