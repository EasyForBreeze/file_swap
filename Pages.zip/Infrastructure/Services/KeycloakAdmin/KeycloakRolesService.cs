using System.Diagnostics;
using System.Text.Json;
using new_assistant.Core.Interfaces;
using new_assistant.Core.DTOs;
using System.Linq;
using Microsoft.Extensions.Logging;
using new_assistant.Infrastructure.Services.KeycloakAdmin;
using static new_assistant.Infrastructure.Services.KeycloakAdmin.KeycloakClientConstants;

namespace new_assistant.Infrastructure.Services.KeycloakAdmin;

/// <summary>
/// Сервис для управления ролями Keycloak
/// </summary>
public class KeycloakRolesService : IKeycloakRolesService
{
    private readonly KeycloakHttpClient _httpClient;
    private readonly ILogger<KeycloakRolesService> _logger;
    private readonly IForbiddenClientService _forbiddenService;
    private readonly IPerformanceMetricsService _metricsService;

    public KeycloakRolesService(
        KeycloakHttpClient httpClient,
        ILogger<KeycloakRolesService> logger,
        IForbiddenClientService forbiddenService,
        IPerformanceMetricsService metricsService)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _forbiddenService = forbiddenService ?? throw new ArgumentNullException(nameof(forbiddenService));
        _metricsService = metricsService ?? throw new ArgumentNullException(nameof(metricsService));
    }

    private async Task EnsureClientNotForbiddenAsync(string clientId, string realm, CancellationToken cancellationToken)
    {
        // Используем общий helper для устранения дублирования кода (исправление проблемы #21)
        await ForbiddenClientHelper.EnsureClientNotForbiddenAsync(
            _forbiddenService, 
            _logger, 
            clientId, 
            realm, 
            cancellationToken);
    }

    /// <summary>
    /// Синхронизировать локальные роли клиента с Keycloak
    /// </summary>
    public async Task SyncClientLocalRolesAsync(string clientId, string realm, string internalId, List<string> currentRoles, List<string> newRoles, CancellationToken cancellationToken = default)
    {
        if (currentRoles == null)
            throw new ArgumentNullException(nameof(currentRoles));
        
        if (newRoles == null)
            throw new ArgumentNullException(nameof(newRoles));
        
        var stopwatch = Stopwatch.StartNew();
        try
        {
            await EnsureClientNotForbiddenAsync(clientId, realm, cancellationToken).ConfigureAwait(false);
            // Оптимизация: используем HashSet для эффективного сравнения (исправление проблемы #4)
            var currentRolesSet = new HashSet<string>(currentRoles, StringComparer.Ordinal);
            var newRolesSet = new HashSet<string>(newRoles, StringComparer.Ordinal);
            
            // Определяем роли которые нужно добавить
            var rolesToAdd = newRolesSet.Except(currentRolesSet).ToList();
            
            // Определяем роли которые нужно удалить
            var rolesToDelete = currentRolesSet.Except(newRolesSet).ToList();
            
            var deletionErrors = new List<string>();
            var creationErrors = new List<string>();
            
            // Удаляем роли
            foreach (var role in rolesToDelete)
            {
                try
                {
                    await _httpClient.DeleteClientRoleAsync(realm, internalId, role, cancellationToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Ошибка при удалении роли '{Role}' для клиента {ClientId}", role, clientId);
                    deletionErrors.Add(role);
                }
            }
            
            // Добавляем новые роли
            foreach (var role in rolesToAdd)
            {
                try
                {
                    await _httpClient.CreateClientRoleAsync(realm, internalId, role, cancellationToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Ошибка при создании роли '{Role}' для клиента {ClientId}", role, clientId);
                    creationErrors.Add(role);
                }
            }
            
            if (deletionErrors.Any() || creationErrors.Any())
            {
                _logger.LogWarning("Синхронизация ролей завершена с ошибками. " +
                    "Успешно добавлено: {AddedCount}, успешно удалено: {DeletedCount}. " +
                    "Ошибки при удалении: {DeletionErrors}, ошибки при создании: {CreationErrors}",
                    rolesToAdd.Count - creationErrors.Count,
                    rolesToDelete.Count - deletionErrors.Count,
                    string.Join(", ", deletionErrors),
                    string.Join(", ", creationErrors));
            }
            else
            {
                _logger.LogInformation("Синхронизация ролей завершена: добавлено {AddedCount}, удалено {DeletedCount}", 
                    rolesToAdd.Count, rolesToDelete.Count);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при синхронизации локальных ролей клиента {ClientId} в реалме {Realm}", clientId, realm);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            _metricsService.RecordOperationTime("KeycloakRoles.SyncClientLocalRoles", stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Синхронизировать service account роли с Keycloak (оптимизированная версия с batch операциями)
    /// </summary>
    public async Task SyncServiceAccountRolesAsync(string clientId, string realm, string internalId, List<string> currentRoles, List<string> newRoles, CancellationToken cancellationToken = default)
    {
        if (currentRoles == null)
            throw new ArgumentNullException(nameof(currentRoles));
        
        if (newRoles == null)
            throw new ArgumentNullException(nameof(newRoles));
        
        var stopwatch = Stopwatch.StartNew();
        try
        {
            await EnsureClientNotForbiddenAsync(clientId, realm, cancellationToken).ConfigureAwait(false);
            // Получаем service account пользователя
            var serviceAccountUserId = await _httpClient.GetServiceAccountUserIdAsync(realm, internalId, cancellationToken).ConfigureAwait(false);
            
            if (serviceAccountUserId == null)
            {
                _logger.LogWarning("Service account не найден для клиента {ClientId}", clientId);
                throw new InvalidOperationException($"Service account не включен для клиента {clientId}");
            }
            
            // Оптимизация: используем HashSet для эффективного сравнения (исправление проблемы #4)
            var currentRolesSet = new HashSet<string>(currentRoles, StringComparer.Ordinal);
            var newRolesSet = new HashSet<string>(newRoles, StringComparer.Ordinal);
            
            // Определяем роли которые нужно добавить
            var rolesToAdd = newRolesSet.Except(currentRolesSet).ToList();
            
            // Определяем роли которые нужно удалить
            var rolesToDelete = currentRolesSet.Except(newRolesSet).ToList();
            
            var batchErrors = new List<string>();
            
            // ========== УДАЛЕНИЕ РОЛЕЙ (с группировкой) ==========
            if (rolesToDelete.Any())
            {
                // Роли уже содержат clientInternalId (UUID), маппинг не нужен!
                var (realmRolesToDelete, clientRolesToDelete) = GroupRolesByType(rolesToDelete);
                
                // Удаляем realm роли батчем
                if (realmRolesToDelete.Any())
                {
                    try
                    {
                        await _httpClient.RemoveMultipleRealmRolesFromUserAsync(realm, serviceAccountUserId, realmRolesToDelete, cancellationToken);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Ошибка при batch удалении realm ролей для клиента {ClientId}", clientId);
                        batchErrors.Add($"Ошибка удаления realm ролей: {ex.Message}");
                    }
                }
                
                // Удаляем client роли батчем (группируем по clientInternalId)
                foreach (var clientGroup in clientRolesToDelete.GroupBy(r => r.clientInternalId))
                {
                    try
                    {
                        var roles = clientGroup.Select(r => (r.roleId, r.roleName)).ToList();
                        await _httpClient.RemoveMultipleClientRolesFromUserAsync(realm, serviceAccountUserId, clientGroup.Key, roles, cancellationToken).ConfigureAwait(false);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Ошибка при batch удалении client ролей для клиента {ClientId}", clientId);
                        batchErrors.Add($"Ошибка удаления client ролей для клиента {clientGroup.Key}: {ex.Message}");
                    }
                }
            }
            
            // ========== ДОБАВЛЕНИЕ РОЛЕЙ (с группировкой) ==========
            if (rolesToAdd.Any())
            {
                // Роли уже содержат clientInternalId (UUID), маппинг не нужен!
                var (realmRolesToAdd, clientRolesToAdd) = GroupRolesByType(rolesToAdd);
                
                // Добавляем realm роли батчем
                if (realmRolesToAdd.Any())
                {
                    try
                    {
                        await _httpClient.AssignMultipleRealmRolesToUserAsync(realm, serviceAccountUserId, realmRolesToAdd, cancellationToken).ConfigureAwait(false);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Ошибка при batch назначении realm ролей для клиента {ClientId}", clientId);
                        batchErrors.Add($"Ошибка назначения realm ролей: {ex.Message}");
                    }
                }
                
                // Добавляем client роли батчем (группируем по clientInternalId)
                foreach (var clientGroup in clientRolesToAdd.GroupBy(r => r.clientInternalId))
                {
                    try
                    {
                        var roles = clientGroup.Select(r => (r.roleId, r.roleName)).ToList();
                        await _httpClient.AssignMultipleClientRolesToUserAsync(realm, serviceAccountUserId, clientGroup.Key, roles, cancellationToken);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Ошибка при batch назначении client ролей для клиента {ClientId}", clientId);
                        batchErrors.Add($"Ошибка назначения client ролей для клиента {clientGroup.Key}: {ex.Message}");
                    }
                }
            }
            
            if (batchErrors.Any())
            {
                _logger.LogWarning("Синхронизация service account ролей завершена с ошибками. " +
                    "Добавлено: {AddedCount}, удалено: {DeletedCount}. Ошибки: {Errors}",
                    rolesToAdd.Count, rolesToDelete.Count, string.Join("; ", batchErrors));
                throw new InvalidOperationException($"Ошибки при синхронизации ролей: {string.Join("; ", batchErrors)}");
            }
            
            _logger.LogInformation("Синхронизация service account ролей завершена: добавлено {AddedCount}, удалено {DeletedCount}", 
                rolesToAdd.Count, rolesToDelete.Count);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при синхронизации service account ролей клиента {ClientId} в реалме {Realm}", clientId, realm);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            _metricsService.RecordOperationTime("KeycloakRoles.SyncServiceAccountRoles", stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Поиск ролей для Service Account (realm + client roles) - ОПТИМИЗИРОВАННАЯ ВЕРСИЯ
    /// </summary>
    public async Task<(List<RoleSearchResult> Roles, List<ClientWithRoles> Clients)> SearchRolesForServiceAccountAsync(
        string realm, string clientInternalId, string searchTerm, CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            var matchedRoles = new List<RoleSearchResult>();
            var matchedClients = new List<ClientWithRoles>();
            
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                return (matchedRoles, matchedClients);
            }
            
            // Получаем service account user ID для клиента
            var serviceAccountUserId = await _httpClient.GetServiceAccountUserIdAsync(realm, clientInternalId, cancellationToken);
            
            if (string.IsNullOrEmpty(serviceAccountUserId))
            {
                _logger.LogWarning("Не удалось получить service account user ID для клиента {ClientId}", clientInternalId);
                return (matchedRoles, matchedClients);
            }
            
            // ОПТИМИЗАЦИЯ: Используем новый ui-ext эндпоинт для получения всех доступных ролей
            var availableRoles = await _httpClient.GetAvailableRolesForUserAsync(
                realm, 
                serviceAccountUserId, 
                searchTerm, 
                first: 0, 
                max: MaxRoleSearchResults,
                cancellationToken);
            
            var term = searchTerm.ToLowerInvariant();
            var clientsGrouped = new Dictionary<string, ClientWithRoles>();
            
            // Обрабатываем полученные роли
            foreach (var role in availableRoles)
            {
                var roleName = role.Name;
                var roleId = role.Id;
                var description = role.Description;
                
                // Определяем тип роли: если есть ContainerId и ClientRole = true - это client role
                var hasClient = role.ClientRole && !string.IsNullOrEmpty(role.ContainerId);
                var roleClientId = role.ContainerId; // ContainerId содержит clientId (название клиента)
                var roleClientInternalId = role.Attributes?.TryGetValue("_clientInternalId", out var internalIdList) == true 
                    && internalIdList?.Count > 0 
                    ? internalIdList[0] 
                    : null;
                
                if (string.IsNullOrEmpty(roleName))
                    continue;
                
                // Для client roles используем ContainerId как clientId (название клиента)
                if (hasClient && !string.IsNullOrEmpty(roleClientId))
                {
                    // Это client role
                    var roleResult = new RoleSearchResult
                    {
                        RoleName = roleName,
                        RoleId = roleId ?? "",
                        Description = description,
                        Source = "client",
                        ClientId = roleClientId,
                        ClientName = roleClientId,
                        ClientInternalId = roleClientInternalId ?? string.Empty
                    };
                    
                    matchedRoles.Add(roleResult);
                    
                    // Группируем роли по клиентам
                    if (!clientsGrouped.ContainsKey(roleClientId))
                    {
                        clientsGrouped[roleClientId] = new ClientWithRoles
                        {
                            ClientId = roleClientId,
                            ClientName = roleClientId,
                            InternalId = roleClientInternalId ?? string.Empty,
                            Roles = new List<RoleSearchResult>()
                        };
                    }
                    
                    clientsGrouped[roleClientId].Roles.Add(roleResult);
                }
                else
                {
                    // Это realm role
                    matchedRoles.Add(new RoleSearchResult
                    {
                        RoleName = roleName,
                        RoleId = roleId ?? "",
                        Description = description,
                        Source = "realm"
                    });
                }
            }
            
            // Фильтруем клиентов: добавляем только те, у которых clientId содержит поисковый термин
            matchedClients = clientsGrouped.Values
                .Where(c => c.ClientId.ToLowerInvariant().Contains(term) && c.Roles.Any())
                .ToList();
            
            _logger.LogInformation("Поиск ролей завершен: найдено {RoleCount} ролей, {ClientCount} клиентов", 
                matchedRoles.Count, matchedClients.Count);
            
            return (matchedRoles, matchedClients);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при поиске ролей в реалме {Realm} через ui-ext API", realm);
            return (new List<RoleSearchResult>(), new List<ClientWithRoles>());
        }
        finally
        {
            stopwatch.Stop();
            _metricsService.RecordOperationTime("KeycloakRoles.SearchRolesForServiceAccount", stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Поиск ролей для нового клиента (без clientInternalId)
    /// </summary>
    public async Task<(List<RoleSearchResult> Roles, List<ClientWithRoles> Clients)> SearchRolesForNewClientAsync(
        string realm, string searchTerm, CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        var errorCount = 0;
        try
        {
            var matchedRoles = new List<RoleSearchResult>();
            var matchedClients = new List<ClientWithRoles>();
            
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                return (matchedRoles, matchedClients);
            }
            
            var term = searchTerm.ToLowerInvariant();
            
            // 1. Поиск в realm ролях
            var realmRoles = await _httpClient.GetAvailableRealmRolesAsync(realm, cancellationToken);
            foreach (var role in realmRoles)
            {
                var roleName = role.Name;
                var description = role.Description;
                var roleId = role.Id;
                
                if (!string.IsNullOrEmpty(roleName) && roleName.ToLowerInvariant().Contains(term))
                {
                    matchedRoles.Add(new RoleSearchResult
                    {
                        RoleId = roleId ?? "",
                        RoleName = roleName,
                        Description = description ?? "",
                        Source = "realm",
                        ClientId = "",
                        ClientInternalId = ""
                    });
                }
            }
            
            // 2. Поиск в client ролях - получаем все клиенты
            var clientsElements = await _httpClient.GetAllClientsAsJsonAsync(realm, cancellationToken);
            
            var clientsGrouped = new Dictionary<string, ClientWithRoles>();
            
            using var semaphore = new SemaphoreSlim(MaxParallelSearchRequests, MaxParallelSearchRequests);
            
            var roleSearchTasks = clientsElements.Select(async clientJson =>
            {
                // Обработка исключений при ожидании семафора (исправление проблемы #11)
                try
                {
                    await semaphore.WaitAsync(cancellationToken);
                }
                catch (ObjectDisposedException)
                {
                    _logger.LogWarning("Semaphore disposed во время поиска ролей для нового клиента в реалме {Realm}", realm);
                    return new List<(string ClientId, string ClientInternalId, RoleSearchResult Role)>();
                }
                catch (OperationCanceledException)
                {
                    throw; // Пробрасываем OperationCanceledException
                }
                try
                {
                    var clientIdVal = clientJson.TryGetProperty("clientId", out var cidProp) ? cidProp.GetString() : null;
                    var clientInternalId = clientJson.TryGetProperty("id", out var idProp) ? idProp.GetString() : null;
                    
                    if (string.IsNullOrEmpty(clientIdVal) || string.IsNullOrEmpty(clientInternalId))
                        return new List<(string ClientId, string ClientInternalId, RoleSearchResult Role)>();
                    
                    // Получаем роли клиента
                    var clientRoles = await _httpClient.GetClientRolesAsync(realm, clientInternalId, cancellationToken);
                    
                    var matchedRolesForClient = new List<(string ClientId, string ClientInternalId, RoleSearchResult Role)>();
                    
                    foreach (var role in clientRoles)
                    {
                        var roleName = role.Name;
                        var description = role.Description;
                        var roleId = role.Id;
                        
                        if (string.IsNullOrEmpty(roleName) || string.IsNullOrEmpty(roleId))
                            continue;
                        
                        if (roleName.ToLowerInvariant().Contains(term))
                        {
                            matchedRolesForClient.Add((clientIdVal, clientInternalId, new RoleSearchResult
                            {
                                RoleId = roleId,
                                RoleName = roleName,
                                Description = description ?? "",
                                Source = "client",
                                ClientId = clientIdVal,
                                ClientInternalId = clientInternalId
                            }));
                        }
                    }
                    
                    return matchedRolesForClient;
                }
                catch (Exception ex)
                {
                    Interlocked.Increment(ref errorCount);
                    _logger.LogWarning(ex, "Ошибка при поиске ролей для клиента в реалме {Realm}", realm);
                    return new List<(string ClientId, string ClientInternalId, RoleSearchResult Role)>();
                }
                finally
                {
                    try
                    {
                        semaphore.Release();
                    }
                    catch (ObjectDisposedException)
                    {
                        // Игнорируем, если semaphore уже disposed
                    }
                }
            });
            
            var allMatchedRoles = await Task.WhenAll(roleSearchTasks);
            var flattenedRoles = allMatchedRoles.SelectMany(r => r).ToList();
            
            // Группируем результаты
            foreach (var (clientId, clientInternalId, role) in flattenedRoles)
            {
                matchedRoles.Add(role);
                
                if (!clientsGrouped.ContainsKey(clientId))
                {
                    clientsGrouped[clientId] = new ClientWithRoles
                    {
                        ClientId = clientId,
                        Roles = new List<RoleSearchResult>()
                    };
                }
                
                clientsGrouped[clientId].Roles.Add(new RoleSearchResult
                {
                    RoleId = role.RoleId,
                    RoleName = role.RoleName,
                    Description = role.Description
                });
            }
            
            matchedClients = clientsGrouped.Values
                .Where(c => c.ClientId.ToLowerInvariant().Contains(term) && c.Roles.Any())
                .ToList();
            
            if (errorCount > 0)
            {
                _logger.LogWarning("Поиск ролей завершен с ошибками в {ErrorCount} клиентах. Найдено {RoleCount} ролей, {ClientCount} клиентов", 
                    errorCount, matchedRoles.Count, matchedClients.Count);
            }
            else
            {
                _logger.LogInformation("Поиск ролей завершен: найдено {RoleCount} ролей, {ClientCount} клиентов", 
                    matchedRoles.Count, matchedClients.Count);
            }
            
            return (matchedRoles, matchedClients);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при поиске ролей для нового клиента в реалме {Realm}", realm);
            return (new List<RoleSearchResult>(), new List<ClientWithRoles>());
        }
        finally
        {
            stopwatch.Stop();
            _metricsService.RecordOperationTime("KeycloakRoles.SearchRolesForNewClient", stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Группирует роли по типу (realm vs client)
    /// Формат: realm роли - "roleName", client роли - "clientId|clientInternalId:roleId:roleName"
    /// </summary>
    private (List<string> realmRoles, List<(string clientInternalId, string roleId, string roleName)> clientRoles) 
        GroupRolesByType(List<string> roles)
    {
        if (roles == null)
            throw new ArgumentNullException(nameof(roles));
        
        var realmRoles = new List<string>();
        var clientRoles = new List<(string clientInternalId, string roleId, string roleName)>();
        
        foreach (var roleStr in roles)
        {
            var parsed = RoleFormatHelper.ParseClientRole(roleStr);
            if (parsed.ClientId != null)
            {
                // Это client role
                clientRoles.Add((parsed.ClientInternalId!, parsed.RoleId!, parsed.RoleName!));
            }
            else
            {
                // Realm role (просто имя, без разделителей)
                realmRoles.Add(roleStr);
            }
        }
        
        return (realmRoles, clientRoles);
    }
}

