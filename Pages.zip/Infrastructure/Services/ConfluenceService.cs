using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.DTOs;
using new_assistant.Core.Entities;
using new_assistant.Core.Interfaces;
using new_assistant.Infrastructure.Services.Confluence;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для работы с Confluence Wiki API
/// </summary>
public class ConfluenceService : IConfluenceService
{
    private readonly IConfluenceApiClient _apiClient;
    private readonly IConfluencePageBuilder _pageBuilder;
    private readonly IConfluencePageParser _pageParser;
    private readonly ConfluenceSettings _settings;
    private readonly IWikiPageRepository _wikiPageRepository;
    private readonly IConfluenceTemplateProvider _templateProvider;
    private readonly ConfluenceLabelsService _labelsService;
    private readonly ILogger<ConfluenceService> _logger;
    private readonly IAuditService? _auditService;
    private readonly IPerformanceMetricsService? _metricsService;

    private const int MaxClientIdLength = 255;
    private const int MaxUserNameLength = 1000;
    private const string DefaultRealm = "GLOBAL";
    private const int HealthCheckTimeoutSeconds = 5;
    private const int MinHealthCheckTimeoutSeconds = 1;
    private const int MaxRetryAttempts = 3;
    private static readonly Regex UrlValidationRegex = new(@"^https?://.+", RegexOptions.Compiled | RegexOptions.IgnoreCase);

    public ConfluenceService(
        IConfluenceApiClient apiClient,
        IConfluencePageBuilder pageBuilder,
        IConfluencePageParser pageParser,
        IOptions<ConfluenceSettings> settings,
        IWikiPageRepository wikiPageRepository,
        IConfluenceTemplateProvider templateProvider,
        ConfluenceLabelsService labelsService,
        ILogger<ConfluenceService> logger,
        IAuditService? auditService = null,
        IPerformanceMetricsService? metricsService = null)
    {
        _apiClient = apiClient ?? throw new ArgumentNullException(nameof(apiClient));
        _pageBuilder = pageBuilder ?? throw new ArgumentNullException(nameof(pageBuilder));
        _pageParser = pageParser ?? throw new ArgumentNullException(nameof(pageParser));
        _settings = settings?.Value ?? throw new ArgumentNullException(nameof(settings));
        _wikiPageRepository = wikiPageRepository ?? throw new ArgumentNullException(nameof(wikiPageRepository));
        _templateProvider = templateProvider ?? throw new ArgumentNullException(nameof(templateProvider));
        _labelsService = labelsService ?? throw new ArgumentNullException(nameof(labelsService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _auditService = auditService;
        _metricsService = metricsService;
    }


    public async Task<string?> CreateClientPageAsync(
        ClientCreationData clientData,
        string createdBy,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        if (clientData == null)
            throw new ArgumentNullException(nameof(clientData));
        
        if (string.IsNullOrWhiteSpace(clientData.ClientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientData));
        
        ValidateUserName(createdBy, nameof(createdBy));
        
        // Валидация длины
        if (clientData.ClientId.Length > MaxClientIdLength)
            throw new ArgumentException($"Client ID exceeds maximum length of {MaxClientIdLength} characters", nameof(clientData));
        
        if (!_settings.Enabled || !_settings.CreatePageOnClientCreation)
        {
            return null;
        }

        const string operation = "CreateClientPage";
        ConfluencePageResponse? confluencePageResponse = null;

        try
        {
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            // Проверить, не существует ли уже страница
            var existingPage = await _wikiPageRepository.GetWikiPageAnyRealmAsync(clientData.ClientId).ConfigureAwait(false);
            if (existingPage != null)
            {
                _logger.LogWarning("Wiki page already exists for client {ClientId} in realm {Realm}", 
                    clientData.ClientId, clientData.Realm);
                return existingPage.WikiPageUrl;
            }

            // Заполнить шаблон
            var pageContent = _pageBuilder.BuildPageContent(clientData);
            var realmPrefix = _pageBuilder.BuildRealmPrefix(clientData.Realm);
            
            // Безопасное формирование заголовка страницы
            var pageTitle = _templateProvider.GetTitle(realmPrefix, clientData.ClientId);

            // Создать страницу через API
            confluencePageResponse = await _apiClient.CreatePageAsync(
                pageTitle,
                pageContent,
                _settings.SpaceKey,
                _settings.ParentPageId,
                cancellationToken).ConfigureAwait(false);

            if (confluencePageResponse == null)
            {
                _logger.LogError("Failed to create Confluence page for client {ClientId}", clientData.ClientId);
                _metricsService?.RecordError($"Confluence.{operation}", "CreatePageFailed");
                return null;
            }

            // Валидация URL
            if (!IsValidUrl(confluencePageResponse.Url))
            {
                _logger.LogError("Invalid URL returned from Confluence API for client {ClientId}: {Url}", 
                    clientData.ClientId, confluencePageResponse.Url);
                _metricsService?.RecordError($"Confluence.{operation}", "InvalidUrl");
                await TryCompensatePageCreationAsync(confluencePageResponse.Id, cancellationToken).ConfigureAwait(false);
                return null;
            }

            // Добавить метки к созданной странице (не критично, ошибки логируем)
            try
            {
                var labels = _labelsService.BuildDefaultLabels(clientData.Realm);
                await _labelsService.AddLabelsAsync(confluencePageResponse.Id, labels, cancellationToken).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Не удалось добавить метки для страницы Confluence {PageId}", confluencePageResponse.Id);
            }

            // Сохранить связь в БД
            var wikiPage = new ClientWikiPage
            {
                ClientId = clientData.ClientId,
                Realm = clientData.Realm ?? DefaultRealm,
                WikiPageId = confluencePageResponse.Id,
                WikiPageTitle = pageTitle,
                WikiPageUrl = confluencePageResponse.Url,
                Status = "Active",
                CreatedBy = createdBy,
                PageVersion = confluencePageResponse.Version
            };

            try
            {
                await _wikiPageRepository.SaveWikiPageAsync(wikiPage).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to save wiki page to database after creating page in Confluence for client {ClientId}", 
                    clientData.ClientId);
                // Попытка компенсировать создание страницы
                await TryCompensatePageCreationAsync(confluencePageResponse.Id, cancellationToken).ConfigureAwait(false);
                throw;
            }

            // Логирование в аудит
            try
            {
                if (_auditService != null)
                {
                    await _auditService.LogClientCreatedAsync(
                        createdBy,
                        clientData.ClientId,
                        clientData.Realm ?? string.Empty,
                        $"Wiki page created: {confluencePageResponse.Url}").ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to log audit event for client {ClientId}", clientData.ClientId);
            }

            stopwatch.Stop();
            _metricsService?.RecordOperationTime($"Confluence.{operation}", stopwatch.ElapsedMilliseconds);
            _metricsService?.RecordSuccess($"Confluence.{operation}");
            _logger.LogInformation("Wiki страница успешно создана для клиента {ClientId} - {Time}мс", 
                clientData.ClientId, stopwatch.ElapsedMilliseconds);

            return confluencePageResponse.Url;
        }
        catch (HttpRequestException ex)
        {
            LogHttpError(ex, operation, clientData.ClientId);
            if (confluencePageResponse != null)
            {
                await TryCompensatePageCreationAsync(confluencePageResponse.Id, cancellationToken).ConfigureAwait(false);
            }
            return null;
        }
        catch (TaskCanceledException ex)
        {
            LogTimeoutError(ex, operation, clientData.ClientId);
            if (confluencePageResponse != null)
            {
                await TryCompensatePageCreationAsync(confluencePageResponse.Id, cancellationToken).ConfigureAwait(false);
            }
            return null;
        }
        catch (Exception ex)
        {
            LogUnexpectedError(ex, operation, clientData.ClientId);
            if (confluencePageResponse != null)
            {
                await TryCompensatePageCreationAsync(confluencePageResponse.Id, cancellationToken).ConfigureAwait(false);
            }
            return null;
        }
    }

    public async Task<string?> UpdateClientPageAsync(
        ClientDetailsDto clientDetails,
        string updatedBy,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        if (clientDetails == null)
            throw new ArgumentNullException(nameof(clientDetails));
        
        if (string.IsNullOrWhiteSpace(clientDetails.ClientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientDetails));
        
        ValidateUserName(updatedBy, nameof(updatedBy));
        
        if (clientDetails.ClientId.Length > MaxClientIdLength)
            throw new ArgumentException($"Client ID exceeds maximum length of {MaxClientIdLength} characters", nameof(clientDetails));
        
        if (!_settings.Enabled || !_settings.UpdatePageOnClientUpdate)
        {
            return null;
        }

        const string operation = "UpdateClientPage";
        ConfluencePageResponse? updatedPage = null;
        ClientWikiPage? originalWikiPage = null;

        try
        {
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            // Получить существующую страницу
            var wikiPage = await _wikiPageRepository.GetWikiPageAnyRealmAsync(clientDetails.ClientId).ConfigureAwait(false);
            if (wikiPage == null)
            {
                _logger.LogWarning("No Wiki page found for client {ClientId} in realm {Realm}",
                    clientDetails.ClientId, clientDetails.Realm);
                return null;
            }

            // Проверка realm
            var expectedRealm = clientDetails.Realm ?? DefaultRealm;
            if (!string.IsNullOrEmpty(wikiPage.Realm) && !string.Equals(wikiPage.Realm, expectedRealm, StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogWarning("Wiki page realm mismatch for client {ClientId}. Expected: {ExpectedRealm}, Found: {FoundRealm}",
                    clientDetails.ClientId, expectedRealm, wikiPage.Realm);
            }

            // Сохранить оригинальную версию для отката
            originalWikiPage = new ClientWikiPage
            {
                ClientId = wikiPage.ClientId,
                Realm = wikiPage.Realm,
                WikiPageId = wikiPage.WikiPageId,
                WikiPageTitle = wikiPage.WikiPageTitle,
                WikiPageUrl = wikiPage.WikiPageUrl,
                Status = wikiPage.Status,
                CreatedBy = wikiPage.CreatedBy,
                PageVersion = wikiPage.PageVersion,
                UpdatedAt = wikiPage.UpdatedAt
            };

            // Получить текущую версию страницы из Confluence
            var currentPage = await _apiClient.GetPageAsync(wikiPage.WikiPageId, cancellationToken).ConfigureAwait(false);
            if (currentPage == null)
            {
                _logger.LogError("Failed to get current page from Confluence for page ID {PageId}. Page may have been deleted.", 
                    wikiPage.WikiPageId);
                _metricsService?.RecordError($"Confluence.{operation}", "GetPageFailed");
                return null;
            }

            // Заполнить шаблон (передаём текущий контент для извлечения полей владельца)
            var pageContent = await _pageBuilder.UpdatePageContent(clientDetails, currentPage.Body).ConfigureAwait(false);

            // Обновить страницу через API с retry логикой
            updatedPage = await UpdatePageWithRetryAsync(
                wikiPage.WikiPageId,
                wikiPage.WikiPageTitle,
                pageContent,
                currentPage.Version,
                cancellationToken).ConfigureAwait(false);

            if (updatedPage == null)
            {
                _logger.LogError("Failed to update Confluence page for client {ClientId} after retries", clientDetails.ClientId);
                _metricsService?.RecordError($"Confluence.{operation}", "UpdatePageFailed");
                return null;
            }

            // Обновить версию в БД
            wikiPage.PageVersion = updatedPage.Version;
            wikiPage.UpdatedAt = DateTime.UtcNow;
            
            try
            {
                await _wikiPageRepository.UpdateWikiPageAsync(wikiPage).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to update wiki page in database after updating page in Confluence for client {ClientId}", 
                    clientDetails.ClientId);
                // Попытка откатить обновление страницы (восстановить старую версию)
                try
                {
                    await _apiClient.UpdatePageAsync(
                        wikiPage.WikiPageId,
                        originalWikiPage.WikiPageTitle,
                        currentPage.Body,
                        updatedPage.Version,
                        cancellationToken).ConfigureAwait(false);
                }
                catch (Exception rollbackEx)
                {
                    _logger.LogError(rollbackEx, "Failed to rollback page update for client {ClientId}", clientDetails.ClientId);
                }
                throw;
            }

            stopwatch.Stop();
            _metricsService?.RecordOperationTime($"Confluence.{operation}", stopwatch.ElapsedMilliseconds);
            _metricsService?.RecordSuccess($"Confluence.{operation}");
            _logger.LogInformation("Wiki страница успешно обновлена для клиента {ClientId} - {Time}мс", 
                clientDetails.ClientId, stopwatch.ElapsedMilliseconds);

            return wikiPage.WikiPageUrl;
        }
        catch (HttpRequestException ex)
        {
            LogHttpError(ex, operation, clientDetails.ClientId);
            return null;
        }
        catch (TaskCanceledException ex)
        {
            LogTimeoutError(ex, operation, clientDetails.ClientId);
            return null;
        }
        catch (Exception ex)
        {
            LogUnexpectedError(ex, operation, clientDetails.ClientId);
            return null;
        }
    }

    public async Task<(string Id, string Title, string Url, int Version)?> ResolvePageAsync(string spaceKey, string title, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(spaceKey))
            throw new ArgumentException("Space key cannot be null or empty", nameof(spaceKey));
        
        if (string.IsNullOrWhiteSpace(title))
            throw new ArgumentException("Title cannot be null or empty", nameof(title));

        try
        {
            var result = await _apiClient.ResolvePageAsync(spaceKey, title, cancellationToken).ConfigureAwait(false);
            if (result == null)
            {
                _logger.LogDebug("Page not found for space {SpaceKey} and title {Title}", spaceKey, title);
            }
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error resolving page for space {SpaceKey} and title {Title}", spaceKey, title);
            return null;
        }
    }

    public async Task<(string Id, string Title, string Url)?> GetPageMetadataAsync(string pageId, CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        if (string.IsNullOrWhiteSpace(pageId))
            throw new ArgumentException("Page ID cannot be null or empty", nameof(pageId));

        try
        {
            var page = await _apiClient.GetPageAsync(pageId, cancellationToken).ConfigureAwait(false);
            if (page == null)
            {
                _logger.LogDebug("Page not found for page ID {PageId}", pageId);
                return null;
            }

            return (page.Id, page.Title, page.Url);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting page metadata for page ID {PageId}", pageId);
            return null;
        }
    }

    public async Task<bool> ArchiveClientPageAsync(
        string clientId,
        string realm,
        string archivedBy,
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        
        ValidateUserName(archivedBy, nameof(archivedBy));
        
        var archived = false;

        try
        {
            if (_settings.Enabled && _settings.ArchivePageOnClientDeletion)
            {
                var stopwatch = System.Diagnostics.Stopwatch.StartNew();
                var wikiPage = await _wikiPageRepository.GetWikiPageAnyRealmAsync(clientId).ConfigureAwait(false);
                
                if (wikiPage == null)
                {
                    _logger.LogWarning("No Wiki page found for client {ClientId} in realm {Realm}", clientId, realm);
                }
                else
                {
                    // Проверка realm
                    var expectedRealm = realm ?? DefaultRealm;
                    if (!string.IsNullOrEmpty(wikiPage.Realm) && !string.Equals(wikiPage.Realm, expectedRealm, StringComparison.OrdinalIgnoreCase))
                    {
                        _logger.LogWarning("Wiki page realm mismatch for client {ClientId}. Expected: {ExpectedRealm}, Found: {FoundRealm}",
                            clientId, expectedRealm, wikiPage.Realm);
                    }

                    // Получить текущую версию страницы
                    var currentPage = await _apiClient.GetPageAsync(wikiPage.WikiPageId, cancellationToken).ConfigureAwait(false);
                    if (currentPage == null)
                    {
                        _logger.LogError("Failed to get current page from Confluence for page ID {PageId}. Page may have been deleted.", 
                            wikiPage.WikiPageId);
                    }
                    else
                    {
                        // Кэшировать значения для производительности
                        var archiveDate = DateTime.UtcNow;
                        var encodedArchivedBy = WebUtility.HtmlEncode(archivedBy);
                        var archiveDateString = archiveDate.ToString("yyyy-MM-dd HH:mm:ss");

                        // Использовать StringBuilder для эффективной конкатенации
                        var archiveNoticeBuilder = new StringBuilder();
                        archiveNoticeBuilder.Append(@"<ac:structured-macro ac:name=""panel"" ac:schema-version=""1"">");
                        archiveNoticeBuilder.Append(@"<ac:parameter ac:name=""bgColor"">#FFF3CD</ac:parameter>");
                        archiveNoticeBuilder.Append(@"<ac:parameter ac:name=""borderColor"">#FFC107</ac:parameter>");
                        archiveNoticeBuilder.Append(@"<ac:rich-text-body>");
                        archiveNoticeBuilder.Append(@"<p><strong>⚠️ АРХИВИРОВАНО</strong></p>");
                        archiveNoticeBuilder.Append(@"<p>Этот клиент был удалён из Keycloak. Страница сохранена для истории.</p>");
                        archiveNoticeBuilder.AppendFormat(@"<p>Дата архивации: {0} UTC</p>", archiveDateString);
                        archiveNoticeBuilder.AppendFormat(@"<p>Архивировал: {0}</p>", encodedArchivedBy);
                        archiveNoticeBuilder.Append(@"</ac:rich-text-body>");
                        archiveNoticeBuilder.Append(@"</ac:structured-macro>");
                        archiveNoticeBuilder.Append(@"<br/>");

                        var archivedContent = archiveNoticeBuilder.ToString() + currentPage.Body;
                        var archivedTitle = $"[ARCHIVED] {wikiPage.WikiPageTitle}";

                        // Обновить страницу с маркером архивации с retry логикой
                        var updatedPage = await UpdatePageWithRetryAsync(
                            wikiPage.WikiPageId,
                            archivedTitle,
                            archivedContent,
                            currentPage.Version,
                            cancellationToken).ConfigureAwait(false);

                        if (updatedPage == null)
                        {
                            _logger.LogError("Failed to archive Confluence page for client {ClientId} after retries", clientId);
                        }
                        else
                        {
                            archived = true;
                            stopwatch.Stop();
                            _metricsService?.RecordOperationTime("Confluence.ArchiveClientPage", stopwatch.ElapsedMilliseconds);
                            _metricsService?.RecordSuccess("Confluence.ArchiveClientPage");
                            _logger.LogInformation("Wiki страница успешно архивирована для клиента {ClientId} - {Time}мс", 
                                clientId, stopwatch.ElapsedMilliseconds);
                        }
                    }
                }
            }
        }
        catch (HttpRequestException ex)
        {
            LogHttpError(ex, "ArchiveClientPage", clientId);
        }
        catch (TaskCanceledException ex)
        {
            LogTimeoutError(ex, "ArchiveClientPage", clientId);
        }
        catch (Exception ex)
        {
            LogUnexpectedError(ex, "ArchiveClientPage", clientId);
        }
        finally
        {
            // Удалять запись из БД только если архивация успешна
            if (archived)
            {
                await RemoveWikiRecordAsync(clientId, realm).ConfigureAwait(false);
            }
            else
            {
                _logger.LogWarning("Skipping wiki record removal for client {ClientId} because archiving was not successful", clientId);
            }
        }

        return archived;
    }

    public async Task<string?> GetWikiPageUrlAsync(string clientId, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", nameof(clientId));
        
        try
        {
            var wikiPage = await _wikiPageRepository.GetWikiPageAnyRealmAsync(clientId).ConfigureAwait(false);
            return wikiPage?.WikiPageUrl;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting Wiki page URL for client {ClientId}", clientId);
            return null;
        }
    }

    public async Task<bool> IsAvailableAsync()
    {
        if (!_settings.Enabled)
            return false;

        try
        {
            var timeout = GetValidHealthCheckTimeout();
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(timeout));
            var result = await _apiClient.IsAvailableAsync(cts.Token).ConfigureAwait(false);
            
            if (!result)
            {
                _logger.LogDebug("Confluence API health check returned false");
            }
            
            return result;
        }
        catch (TaskCanceledException)
        {
            _logger.LogDebug("Confluence API health check timed out after {TimeoutSeconds} seconds", GetValidHealthCheckTimeout());
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Confluence API is not available");
            return false;
        }
    }

    #region Private Helper Methods

    private static void ValidateUserName(string userName, string parameterName)
    {
        if (string.IsNullOrWhiteSpace(userName))
            throw new ArgumentException($"{parameterName} cannot be null or empty", parameterName);
        
        if (userName.Length > MaxUserNameLength)
            throw new ArgumentException($"{parameterName} exceeds maximum length of {MaxUserNameLength} characters", parameterName);
    }

    private static bool IsValidUrl(string? url)
    {
        if (string.IsNullOrWhiteSpace(url))
            return false;
        
        return UrlValidationRegex.IsMatch(url);
    }

    private static int GetValidHealthCheckTimeout()
    {
        return Math.Max(MinHealthCheckTimeoutSeconds, HealthCheckTimeoutSeconds);
    }

    private void LogHttpError(Exception ex, string operation, string clientId)
    {
        _logger.LogError(ex, "HTTP error {Operation} for client {ClientId}", operation, clientId);
        _metricsService?.RecordError($"Confluence.{operation}", "HttpError");
    }

    private void LogTimeoutError(Exception ex, string operation, string clientId)
    {
        _logger.LogWarning(ex, "Request timeout {Operation} for client {ClientId}", operation, clientId);
        _metricsService?.RecordError($"Confluence.{operation}", "Timeout");
    }

    private void LogUnexpectedError(Exception ex, string operation, string clientId)
    {
        _logger.LogError(ex, "Unexpected error {Operation} for client {ClientId}", operation, clientId);
        _metricsService?.RecordError($"Confluence.{operation}", "UnexpectedError");
    }

    private async Task<ConfluencePageResponse?> UpdatePageWithRetryAsync(
        string pageId,
        string title,
        string content,
        int initialVersion,
        CancellationToken cancellationToken,
        int maxAttempts = MaxRetryAttempts)
    {
        for (int attempt = 1; attempt <= maxAttempts; attempt++)
        {
            try
            {
                // Получить текущую версию страницы перед обновлением
                var currentPage = await _apiClient.GetPageAsync(pageId, cancellationToken).ConfigureAwait(false);
                if (currentPage == null)
                {
                    _logger.LogError("Failed to get current page for retry attempt {Attempt} of {MaxAttempts}", attempt, maxAttempts);
                    return null;
                }

                var updatedPage = await _apiClient.UpdatePageAsync(
                    pageId,
                    title,
                    content,
                    currentPage.Version,
                    cancellationToken).ConfigureAwait(false);

                if (updatedPage != null)
                {
                    if (attempt > 1)
                    {
                        _logger.LogInformation("Successfully updated page after {Attempt} attempts", attempt);
                    }
                    return updatedPage;
                }
            }
            catch (HttpRequestException ex) when (ex.Message.Contains("version") || ex.Message.Contains("conflict"))
            {
                if (attempt < maxAttempts)
                {
                    _logger.LogWarning("Version conflict on attempt {Attempt} of {MaxAttempts}, retrying...", attempt, maxAttempts);
                    await Task.Delay(100 * attempt, cancellationToken).ConfigureAwait(false);
                    continue;
                }
                _logger.LogError(ex, "Version conflict after {MaxAttempts} attempts", maxAttempts);
                throw;
            }
        }

        return null;
    }

    private async Task<bool> TryCompensatePageCreationAsync(string pageId, CancellationToken cancellationToken)
    {
        try
        {
            // Попытка удалить страницу, если она была создана, но сохранение в БД не удалось
            // Примечание: Confluence API может не поддерживать удаление, поэтому это может не сработать
            _logger.LogWarning("Attempting to compensate for failed page creation. Page ID: {PageId}", pageId);
            // Здесь можно добавить логику удаления страницы, если API поддерживает
            await Task.CompletedTask.ConfigureAwait(false);
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to compensate for page creation. Page ID: {PageId}", pageId);
            return false;
        }
    }

    private async Task RemoveWikiRecordAsync(string clientId, string realm)
    {
        try
        {
            await _wikiPageRepository.DeleteWikiPageAsync(clientId, realm).ConfigureAwait(false);
            _logger.LogInformation("Wiki page record removed for client {ClientId}", clientId);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to remove Wiki page record for client {ClientId}", clientId);
        }
    }

    #endregion
}

