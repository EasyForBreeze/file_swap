using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Реализация сервиса для форматирования типов событий аудита
/// </summary>
public class EventFormatterService : IEventFormatterService
{
    private const string BaseBadgeClass = "inline-flex items-center px-4 py-1.5 rounded-full text-xs font-medium";
    
    private static readonly Dictionary<string, string> EventTypeDisplayNames = new()
    {
        { "ClientCreated", "Создание клиента" },
        { "ClientUpdated", "Редактирование клиента" },
        { "ClientDeleted", "Удаление клиента" },
        { "ClientMigrated", "Миграция клиента" },
        { "AccessGranted", "Назначение прав" },
        { "AccessRevoked", "Отзыв прав" },
        { "RoleAdded", "Добавление роли" },
        { "RoleRemoved", "Удаление роли" },
        { "SecretRegenerated", "Регенерация Secret" },
        { "UserLogin", "Вход пользователя" },
        { "UserInfoUpdated", "Обновление информации пользователя" },
        { "UserRealmRoleAdded", "Добавление realm роли пользователю" },
        { "UserRealmRoleRemoved", "Удаление realm роли у пользователя" },
        { "UserClientRoleAdded", "Добавление client роли пользователю" },
        { "UserClientRoleRemoved", "Удаление client роли у пользователя" },
        { "UserPasswordUpdate", "Инициировано обновление пароля" },
        { "UserOtpConfigured", "Инициирована настройка OTP" },
        { "UserBlocked", "Блокировка пользователя" },
        { "UserUnblocked", "Разблокировка пользователя" },
        { "UserCertificateAdded", "Загрузка сертификата пользователя" },
        { "UserCertificateDeleted", "Удаление сертификата пользователя" }
    };

    private static readonly Dictionary<string, string> EventTypeBadgeClasses = new()
    {
        { "ClientCreated", $"{BaseBadgeClass} bg-green-500/10 text-green-400 border border-green-500/20" },
        { "ClientUpdated", $"{BaseBadgeClass} bg-orange-500/10 text-orange-400 border border-orange-500/20" },
        { "ClientDeleted", $"{BaseBadgeClass} bg-red-500/10 text-red-400 border border-red-500/20" },
        { "ClientMigrated", $"{BaseBadgeClass} bg-purple-500/10 text-purple-300 border border-purple-500/20 shadow-lg shadow-purple-500/10" },
        { "AccessGranted", $"{BaseBadgeClass} bg-green-500/10 text-green-400 border border-green-500/20" },
        { "AccessRevoked", $"{BaseBadgeClass} bg-red-500/10 text-red-400 border border-red-500/20" },
        { "RoleAdded", $"{BaseBadgeClass} bg-green-500/10 text-green-400 border border-green-500/20" },
        { "RoleRemoved", $"{BaseBadgeClass} bg-red-500/10 text-red-400 border border-red-500/20" },
        { "SecretRegenerated", $"{BaseBadgeClass} bg-orange-500/10 text-orange-400 border border-orange-500/20" },
        { "UserLogin", $"{BaseBadgeClass} bg-cyan-500/10 text-cyan-400 border border-cyan-500/20" },
        { "UserInfoUpdated", $"{BaseBadgeClass} bg-orange-500/10 text-orange-400 border border-orange-500/20" },
        { "UserRealmRoleAdded", $"{BaseBadgeClass} bg-green-500/10 text-green-400 border border-green-500/20" },
        { "UserRealmRoleRemoved", $"{BaseBadgeClass} bg-red-500/10 text-red-400 border border-red-500/20" },
        { "UserClientRoleAdded", $"{BaseBadgeClass} bg-green-500/10 text-green-400 border border-green-500/20" },
        { "UserClientRoleRemoved", $"{BaseBadgeClass} bg-red-500/10 text-red-400 border border-red-500/20" },
        { "UserPasswordUpdate", $"{BaseBadgeClass} bg-orange-500/10 text-orange-400 border border-orange-500/20" },
        { "UserOtpConfigured", $"{BaseBadgeClass} bg-purple-500/10 text-purple-300 border border-purple-500/20" },
        { "UserBlocked", $"{BaseBadgeClass} bg-orange-500/10 text-orange-400 border border-orange-500/20" },
        { "UserUnblocked", $"{BaseBadgeClass} bg-orange-500/10 text-orange-400 border border-orange-500/20" },
        { "UserCertificateAdded", $"{BaseBadgeClass} bg-green-500/10 text-green-400 border border-green-500/20" },
        { "UserCertificateDeleted", $"{BaseBadgeClass} bg-red-500/10 text-red-400 border border-red-500/20" }
    };

    private const string DefaultBadgeClass = $"{BaseBadgeClass} bg-gray-500/10 text-gray-400 border border-gray-500/20";

    /// <summary>
    /// Получает отображаемое название типа события
    /// </summary>
    public string GetEventTypeDisplay(string eventType)
    {
        if (string.IsNullOrWhiteSpace(eventType))
            return eventType ?? string.Empty;

        return EventTypeDisplayNames.TryGetValue(eventType, out var displayName) 
            ? displayName 
            : eventType;
    }

    /// <summary>
    /// Получает CSS класс для badge типа события
    /// </summary>
    public string GetEventTypeBadgeClass(string eventType)
    {
        if (string.IsNullOrWhiteSpace(eventType))
            return DefaultBadgeClass;

        return EventTypeBadgeClasses.TryGetValue(eventType, out var badgeClass) 
            ? badgeClass 
            : DefaultBadgeClass;
    }
}

