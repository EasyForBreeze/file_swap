using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using new_assistant.Configuration;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;
using new_assistant.Core.Models;

namespace new_assistant.Infrastructure.Services.Keycloak;

/// <summary>
/// Клиент для работы с realm roles (роли реалма)
/// </summary>
public class KeycloakRealmRolesClient : KeycloakRolesClientBase, IKeycloakRealmRolesClient
{
    
    private int DefaultMaxRolesPerRequest
    {
        get
        {
            if (Settings.Roles != null)
                return Settings.Roles.DefaultMaxRolesPerRequest;
            
            var defaultValue = 101;
            Logger.LogWarning("Settings.Roles is null, using default value {DefaultValue} for DefaultMaxRolesPerRequest", defaultValue);
            return defaultValue;
        }
    }
    
    private TimeSpan RolesCacheDuration
    {
        get
        {
            if (Settings.Roles != null)
                return Settings.Roles.CacheDuration;
            
            var defaultValue = TimeSpan.FromMinutes(30);
            Logger.LogWarning("Settings.Roles is null, using default value {DefaultValue} for CacheDuration", defaultValue);
            return defaultValue;
        }
    }
    
    
    public KeycloakRealmRolesClient(
        HttpClient httpClient,
        KeycloakAdminSettings settings,
        ILogger logger,
        IKeycloakCacheService cacheService,
        IPerformanceMetricsService metricsService)
        : base(httpClient, settings, logger, cacheService, metricsService)
    {
        if (settings.Roles == null)
        {
            Logger.LogWarning("Settings.Roles is null. Default values will be used for all role-related settings.");
        }
    }
    
    // Все методы валидации, выполнения запросов и вспомогательные методы теперь в базовом классе KeycloakRolesClientBase
    
    private KeycloakRoleDto MapUiExtRoleToRoleDto(KeycloakUiExtRoleDto r)
    {
        var roleName = r.GetRoleName();
        if (string.IsNullOrWhiteSpace(roleName))
        {
            // Это не должно происходить, так как метод вызывается только после фильтрации,
            // но добавим проверку для безопасности
            Logger.LogWarning("GetRoleName() returned null or empty for role with Id={RoleId}, using fallback value", r.Id);
            roleName = r.Id?.ToString() ?? "Unknown";
        }
        
        var role = new KeycloakRoleDto
        {
            Id = r.Id ?? string.Empty,
            Name = roleName,
            Description = r.Description,
            ClientRole = !string.IsNullOrEmpty(r.Client),
            ContainerId = r.Client
        };
        
        if (!string.IsNullOrEmpty(r.ClientId))
        {
            role.Attributes ??= new Dictionary<string, List<string>>();
            role.Attributes["_clientInternalId"] = new List<string> { r.ClientId };
        }
        
        return role;
    }
    
    /// <summary>
    /// Получить доступные realm роли для назначения пользователю
    /// </summary>
    public async Task<List<KeycloakRoleDto>> GetAvailableRealmRolesAsync(string realm, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        
        var cacheKey = $"realm-roles:{realm}";
        var cachedRoles = await CacheService.GetAsync<List<KeycloakRoleDto>>(cacheKey, cancellationToken).ConfigureAwait(false);
        if (cachedRoles != null)
        {
            RecordCacheHit(cacheKey);
            RecordSuccess(nameof(GetAvailableRealmRolesAsync));
            return cachedRoles;
        }
        
        RecordCacheMiss(cacheKey);
        
        var endpoint = $"admin/realms/{realm}/roles";
        var result = await GetListAsync<KeycloakRoleDto>(endpoint, cancellationToken).ConfigureAwait(false);
        
        if (!result.IsSuccess)
        {
            Logger.LogWarning("Не удалось получить realm роли: {Error}", result.ErrorMessage);
            return new List<KeycloakRoleDto>();
        }
        
        var roles = result.Value ?? new List<KeycloakRoleDto>();
        
        if (roles.Any())
        {
            await CacheService.SetAsync(cacheKey, roles, RolesCacheDuration, cancellationToken).ConfigureAwait(false);
        }
        
        return roles;
    }
    
    /// <summary>
    /// Получить доступные роли для назначения пользователю (через ui-ext endpoint, оптимизированный метод)
    /// </summary>
    public async Task<List<KeycloakRoleDto>> GetAvailableRolesForUserAsync(
        string realm, 
        string userId, 
        string searchTerm = "", 
        int first = 0, 
        int? max = null, 
        CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateUserId(userId);
        ValidateSearchTerm(searchTerm);
        
        if (first < 0)
            throw new ArgumentException("First cannot be negative", nameof(first));
        
        var actualMax = max ?? DefaultMaxRolesPerRequest;
        if (actualMax < 1 || actualMax > 1000)
            throw new ArgumentException("Max must be between 1 and 1000", nameof(max));
        
        var endpoint = $"admin/realms/{realm}/ui-ext/available-roles/users/{userId}?first={first}&max={actualMax}";
        if (!string.IsNullOrWhiteSpace(searchTerm))
        {
            endpoint += $"&search={Uri.EscapeDataString(searchTerm)}";
        }
        
        var result = await GetListAsync<KeycloakUiExtRoleDto>(endpoint, cancellationToken);
        if (!result.IsSuccess || result.Value == null)
        {
            return new List<KeycloakRoleDto>();
        }
        
        return result.Value
            .Where(r => !string.IsNullOrWhiteSpace(r.GetRoleName()))
            .Select(r => MapUiExtRoleToRoleDto(r))
            .ToList();
    }
    
    /// <summary>
    /// Получить все доступные роли для пользователя (с автоматической пагинацией)
    /// </summary>
    public async Task<List<KeycloakRoleDto>> GetAllAvailableRolesForUserAsync(
        string realm, 
        string userId, 
        string searchTerm = "", 
        CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateUserId(userId);
        ValidateSearchTerm(searchTerm);
        
        var allRoles = new List<KeycloakRoleDto>();
        int first = 0;
        int pageSize = DefaultMaxRolesPerRequest;
        
        while (true)
        {
            var page = await GetAvailableRolesForUserAsync(realm, userId, searchTerm, first, pageSize, cancellationToken).ConfigureAwait(false);
            
            if (page.Count == 0)
                break;
            
            allRoles.AddRange(page);
            
            if (page.Count < pageSize)
                break;
            
            first += pageSize;
        }
        
        return allRoles;
    }
    
    /// <summary>
    /// Получает информацию о realm роли по имени
    /// </summary>
    public async Task<KeycloakRoleDto> GetRealmRoleByNameAsync(string realm, string roleName, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateRoleName(roleName);
        
        var endpoint = $"admin/realms/{realm}/roles/{roleName}";
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            throw new InvalidOperationException("Semaphore disposed, cannot get realm role");
        }
        
        try
        {
            using var request = await CreateAuthorizedRequestWithAcceptAsync(HttpMethod.Get, endpoint, cancellationToken).ConfigureAwait(false);
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await ReadErrorContentAsync(response, cancellationToken).ConfigureAwait(false);
                throw new HttpRequestException($"Не удалось получить realm роль '{roleName}': {response.StatusCode} - {errorContent}");
            }
            
            if (response.Content == null)
            {
                throw new InvalidOperationException($"Response content is null for realm role '{roleName}'");
            }
            
            var content = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            if (string.IsNullOrWhiteSpace(content))
            {
                throw new InvalidOperationException($"Empty response content for realm role '{roleName}'");
            }
            
            try
            {
                var result = JsonSerializer.Deserialize<KeycloakRoleDto>(content, DefaultJsonOptions);
                if (result == null)
                {
                    throw new InvalidOperationException($"Deserialization returned null for realm role '{roleName}'");
                }
                
                return result;
            }
            catch (JsonException ex)
            {
                Logger.LogError(ex, "Ошибка десериализации realm роли {RoleName} для реалма {Realm}", roleName, realm);
                throw new InvalidOperationException($"Ошибка десериализации realm роли '{roleName}': {ex.Message}", ex);
            }
        }
        catch (HttpRequestException)
        {
            // Пробрасываем HttpRequestException как есть
            throw;
        }
        catch (InvalidOperationException)
        {
            // Пробрасываем InvalidOperationException как есть
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при получении realm роли {RoleName} для реалма {Realm}", roleName, realm);
            throw;
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
}

