using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Net; // Используется для HttpStatusCode
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services.Keycloak;

/// <summary>
/// Клиент для работы с событиями Keycloak
/// </summary>
public class KeycloakEventsClient : KeycloakHttpClientBase
{
    // Используем JsonSerializerOptions из базового класса (исправление проблемы #6)
    private static JsonSerializerOptions DefaultJsonOptions => KeycloakHttpClientBase.DefaultJsonSerializerOptions;
    
    // Статический список дефолтных типов событий для переиспользования (оптимизация производительности)
    private static readonly List<string> DefaultEventTypes = new List<string>
    {
        "LOGIN", "LOGIN_ERROR", "LOGOUT", "LOGOUT_ERROR",
        "REGISTER", "REGISTER_ERROR",
        "CODE_TO_TOKEN", "CODE_TO_TOKEN_ERROR",
        "CLIENT_LOGIN", "CLIENT_LOGIN_ERROR",
        "REFRESH_TOKEN", "REFRESH_TOKEN_ERROR",
        "VALIDATE_ACCESS_TOKEN", "VALIDATE_ACCESS_TOKEN_ERROR",
        "INTROSPECT_TOKEN", "INTROSPECT_TOKEN_ERROR",
        "FEDERATED_IDENTITY_LINK", "FEDERATED_IDENTITY_LINK_ERROR",
        "REMOVE_FEDERATED_IDENTITY", "REMOVE_FEDERATED_IDENTITY_ERROR",
        "UPDATE_EMAIL", "UPDATE_EMAIL_ERROR",
        "UPDATE_PASSWORD", "UPDATE_PASSWORD_ERROR",
        "UPDATE_PROFILE", "UPDATE_PROFILE_ERROR",
        "UPDATE_TOTP", "UPDATE_TOTP_ERROR",
        "VERIFY_EMAIL", "VERIFY_EMAIL_ERROR",
        "VERIFY_PROFILE", "VERIFY_PROFILE_ERROR",
        "SEND_VERIFY_EMAIL", "SEND_VERIFY_EMAIL_ERROR",
        "SEND_RESET_PASSWORD", "SEND_RESET_PASSWORD_ERROR",
        "SEND_IDENTITY_PROVIDER_LINK", "SEND_IDENTITY_PROVIDER_LINK_ERROR",
        "RESET_PASSWORD", "RESET_PASSWORD_ERROR",
        "RESTART_AUTHENTICATION", "RESTART_AUTHENTICATION_ERROR",
        "IDENTITY_PROVIDER_LINK_ACCOUNT", "IDENTITY_PROVIDER_LINK_ACCOUNT_ERROR",
        "IDENTITY_PROVIDER_LOGIN", "IDENTITY_PROVIDER_LOGIN_ERROR",
        "IDENTITY_PROVIDER_FIRST_LOGIN", "IDENTITY_PROVIDER_FIRST_LOGIN_ERROR",
        "IDENTITY_PROVIDER_POST_LOGIN", "IDENTITY_PROVIDER_POST_LOGIN_ERROR",
        "IMPERSONATE", "IMPERSONATE_ERROR",
        "CUSTOM_REQUIRED_ACTION", "CUSTOM_REQUIRED_ACTION_ERROR",
        "EXECUTE_ACTIONS", "EXECUTE_ACTIONS_ERROR",
        "EXECUTE_ACTION_TOKEN", "EXECUTE_ACTION_TOKEN_ERROR",
        "CLIENT_INFO", "CLIENT_INFO_ERROR",
        "CLIENT_REGISTER", "CLIENT_REGISTER_ERROR",
        "CLIENT_UPDATE", "CLIENT_UPDATE_ERROR",
        "CLIENT_DELETE", "CLIENT_DELETE_ERROR",
        "PERMISSION_TOKEN", "PERMISSION_TOKEN_ERROR"
    };
    
    // Кэшированная отсортированная копия дефолтных типов событий для оптимизации
    // Используем Lazy для отложенной инициализации (экономит память, если метод не вызывается)
    private static readonly Lazy<IReadOnlyList<string>> CachedDefaultEventTypes = 
        new Lazy<IReadOnlyList<string>>(() => InitializeCachedDefaultEventTypes(), 
            System.Threading.LazyThreadSafetyMode.ExecutionAndPublication);
    
    private static IReadOnlyList<string> InitializeCachedDefaultEventTypes()
    {
        var result = new List<string>(DefaultEventTypes);
        result.Sort();
        return new ReadOnlyCollection<string>(result);
    }
    
    // Константы для валидации
    // Примечание: эти константы должны быть синхронизированы с константами в KeycloakHttpClientBase
    /// <summary>
    /// Максимальная длина названия реалма
    /// </summary>
    private new const int MaxRealmLength = 100;
    /// <summary>
    /// Максимальная длина ID клиента
    /// </summary>
    private new const int MaxClientIdLength = 200;
    /// <summary>
    /// Максимальная длина endpoint
    /// </summary>
    private new const int MaxEndpointLength = 2000;
    /// <summary>
    /// Максимальное значение параметра first для пагинации
    /// </summary>
    private const int MaxFirstValue = 100000;
    /// <summary>
    /// Максимальное количество событий в одном запросе
    /// </summary>
    private const int MaxEventsValue = 1000;
    /// <summary>
    /// Максимальная длина контента для логирования (в символах)
    /// </summary>
    private new const int MaxContentLengthForLogging = 200;
    /// <summary>
    /// Значение по умолчанию для максимального количества событий
    /// </summary>
    private const int DefaultMaxEvents = 100;
    /// <summary>
    /// Константа для конвертации мегабайт в байты
    /// </summary>
    private const int MegabytesToBytes = 1024 * 1024;
    /// <summary>
    /// Максимальный размер контента в мегабайтах
    /// </summary>
    private const int MaxContentLengthMB = 10;
    /// <summary>
    /// Максимальный размер контента в байтах (10 MB)
    /// </summary>
    private const int MaxContentLength = MaxContentLengthMB * MegabytesToBytes;
    /// <summary>
    /// Максимальная длина типа события
    /// </summary>
    private const int MaxEventTypeLength = 100;
    
    // Константы для построения endpoint
    /// <summary>
    /// Начальная емкость StringBuilder для построения endpoint (128 байт достаточно для большинства endpoint'ов)
    /// </summary>
    private const int EndpointBuilderInitialCapacity = 128;
    /// <summary>
    /// Путь к административным реалмам в API Keycloak
    /// </summary>
    private const string AdminRealmsPath = "admin/realms";
    /// <summary>
    /// Путь к событиям в API Keycloak
    /// </summary>
    private const string EventsPath = "/events";
    /// <summary>
    /// Путь к конфигурации событий в API Keycloak
    /// </summary>
    private const string EventsConfigPath = "/events/config";
    
    // Статические пустые списки для оптимизации (избегаем создания новых списков при каждом вызове)
    private static readonly IReadOnlyList<JsonElement> EmptyJsonElementList = Array.Empty<JsonElement>();
    private static readonly IReadOnlyList<string> EmptyStringList = Array.Empty<string>();
    
    // Массив опасных одиночных символов для оптимизации проверок
    private static readonly char[] DangerousSingleChars = { '\n', '\r' };
    
    // Используем KeycloakParameterValidator для унификации валидации (исправление проблемы #2)
    // Метод ValidateRealm удален, используется KeycloakParameterValidator.ValidateRealm()
    
    /// <summary>
    /// Логирование и запись метрик для ошибок HTTP
    /// </summary>
    private async Task LogAndRecordHttpError(
        HttpResponseMessage response,
        string operationName,
        CancellationToken cancellationToken)
    {
        var errorContent = response.Content != null 
            ? await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false)
            : string.Empty;
        
        if (Logger.IsEnabled(LogLevel.Warning))
        {
            var truncatedContent = errorContent.Length > MaxContentLengthForLogging 
                ? errorContent[..MaxContentLengthForLogging] + "..." 
                : errorContent;
            
            Logger.LogWarning(
                "Error executing {OperationName}: {StatusCode} {ReasonPhrase}. Response: {ErrorContent}",
                operationName,
                response.StatusCode,
                response.ReasonPhrase,
                truncatedContent);
        }
        
        RecordError(operationName, $"HttpError_{(int)response.StatusCode:D}");
    }
    
    /// <summary>
    /// Валидация endpoint на наличие опасных символов и корректность формата
    /// </summary>
    private void ValidateEndpoint(string endpoint)
    {
        if (string.IsNullOrWhiteSpace(endpoint))
        {
            throw new ArgumentException("Endpoint cannot be null or empty", nameof(endpoint));
        }
        
        // Проверка на максимальную длину endpoint
        if (endpoint.Length > MaxEndpointLength)
        {
            throw new InvalidOperationException($"Endpoint length ({endpoint.Length}) exceeds maximum allowed length ({MaxEndpointLength})");
        }
        
        // Проверка на опасные символы
        // Примечание: проверка на ".." и "//" выполняется отдельно, так как IndexOfAny не может проверить последовательности символов
        // Uri.EscapeDataString защищает от большинства проблем, но дополнительная проверка повышает безопасность
        // Используем IndexOfAny для одиночных символов для лучшей производительности
        if (endpoint.IndexOfAny(DangerousSingleChars) >= 0 || endpoint.Contains("..") || endpoint.Contains("//"))
        {
            throw new ArgumentException($"Endpoint contains dangerous characters: {endpoint}", nameof(endpoint));
        }
        
        // Проверка на валидность относительного URI
        if (!Uri.TryCreate(endpoint, UriKind.Relative, out _))
        {
            throw new InvalidOperationException($"Invalid endpoint format: {endpoint}");
        }
    }
    
    public KeycloakEventsClient(
        System.Net.Http.HttpClient httpClient,
        new_assistant.Configuration.KeycloakAdminSettings settings,
        ILogger<KeycloakEventsClient> logger,
        new_assistant.Core.Interfaces.IKeycloakCacheService cacheService,
        new_assistant.Core.Interfaces.IPerformanceMetricsService metricsService)
        : base(httpClient, settings, logger, cacheService, metricsService)
    {
    }
    
    /// <summary>
    /// Получение событий из реалма
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список событий в формате JsonElement</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидном параметре realm</exception>
    public async Task<IReadOnlyList<JsonElement>> GetRealmEventsAsync(string realm, CancellationToken cancellationToken = default)
    {
        return await GetRealmEventsAsync(realm, DefaultMaxEvents, null, cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Получение событий из реалма с указанием количества и опциональным фильтром по clientId
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="maxEvents">Максимальное количество событий для возврата</param>
    /// <param name="clientId">Опциональный фильтр по ID клиента</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список событий в формате JsonElement</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    public async Task<IReadOnlyList<JsonElement>> GetRealmEventsAsync(string realm, int maxEvents, string? clientId = null, CancellationToken cancellationToken = default)
    {
        return await GetRealmEventsAsync(realm, first: 0, maxEvents, clientId, cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Получение событий из реалма с пагинацией (first и max) и опциональным фильтром по clientId
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="first">Индекс первого события (для пагинации)</param>
    /// <param name="maxEvents">Максимальное количество событий для возврата</param>
    /// <param name="clientId">Опциональный фильтр по ID клиента</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список событий в формате JsonElement</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="InvalidOperationException">Выбрасывается при ошибках построения endpoint</exception>
    /// <exception cref="UnauthorizedAccessException">Выбрасывается при ошибках авторизации (401, 403)</exception>
    public async Task<IReadOnlyList<JsonElement>> GetRealmEventsAsync(string realm, int first, int maxEvents, string? clientId = null, CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        KeycloakParameterValidator.ValidateRealm(realm);
        if (first < 0)
        {
            throw new ArgumentException("First cannot be negative", nameof(first));
        }
        if (first > MaxFirstValue)
        {
            throw new ArgumentException($"First ({first}) exceeds maximum allowed value ({MaxFirstValue})", nameof(first));
        }
        if (maxEvents <= 0)
        {
            throw new ArgumentException("Max events must be greater than zero", nameof(maxEvents));
        }
        if (maxEvents > MaxEventsValue)
        {
            throw new ArgumentException($"Max events ({maxEvents}) exceeds maximum allowed value ({MaxEventsValue})", nameof(maxEvents));
        }
        
        // Валидация clientId ДО использования
        if (clientId != null)
        {
            if (clientId.Length > MaxClientIdLength)
            {
                throw new ArgumentException($"ClientId length ({clientId.Length}) exceeds maximum allowed length ({MaxClientIdLength})", nameof(clientId));
            }
            
            // Проверка на опасные символы в clientId для защиты от injection атак
            // Используем IndexOfAny для одиночных символов для лучшей производительности
            // Проверка на ".." выполняется отдельно, так как это последовательность символов
            if (clientId.IndexOfAny(DangerousSingleChars) >= 0 || 
                clientId.Contains("..") || clientId.Contains("/") || 
                clientId.Contains("&") || clientId.Contains("?"))
            {
                throw new ArgumentException($"ClientId contains dangerous characters: {clientId}", nameof(clientId));
            }
        }
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation");
            return EmptyJsonElementList;
        }
        try
        {
            // Безопасное построение endpoint (исправление проблемы #38)
            // Для коротких строк используем string interpolation вместо StringBuilder
            // Это более эффективно и читаемо для простых случаев
            string endpoint;
            if (string.IsNullOrEmpty(clientId))
            {
                endpoint = $"{AdminRealmsPath}/{Uri.EscapeDataString(realm)}{EventsPath}?first={first.ToString(System.Globalization.CultureInfo.InvariantCulture)}&max={maxEvents.ToString(System.Globalization.CultureInfo.InvariantCulture)}";
            }
            else
            {
                endpoint = $"{AdminRealmsPath}/{Uri.EscapeDataString(realm)}{EventsPath}?first={first.ToString(System.Globalization.CultureInfo.InvariantCulture)}&max={maxEvents.ToString(System.Globalization.CultureInfo.InvariantCulture)}&client={Uri.EscapeDataString(clientId)}";
            }
            
            // Валидация endpoint перед использованием
            ValidateEndpoint(endpoint);
            
            using var request = await CreateAuthorizedRequestAsync(HttpMethod.Get, endpoint, cancellationToken).ConfigureAwait(false);
            
            var networkTime = Stopwatch.StartNew();
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            networkTime.Stop();
            MetricsService.RecordOperationTime($"{MetricsOperationName}.GetRealmEvents.Network", networkTime.ElapsedMilliseconds);
            
            // Обработка rate limiting
            var finalResponse = await HandleRateLimitAsync(
                response,
                async () => 
                {
                    using var retryRequest = await CreateAuthorizedRequestAsync(HttpMethod.Get, endpoint, cancellationToken).ConfigureAwait(false);
                    return await HttpClient.SendAsync(retryRequest, cancellationToken).ConfigureAwait(false);
                },
                cancellationToken).ConfigureAwait(false);
            
            if (finalResponse == null)
            {
                Logger.LogError("HandleRateLimitAsync returned null response");
                RecordError("GetRealmEvents", "NullResponse");
                return EmptyJsonElementList;
            }
            
            if (!finalResponse.IsSuccessStatusCode)
            {
                await LogAndRecordHttpError(finalResponse, "GetRealmEvents", cancellationToken).ConfigureAwait(false);
                
                // Выбрасываем исключение для критических ошибок авторизации
                if (finalResponse.StatusCode == HttpStatusCode.Unauthorized || 
                    finalResponse.StatusCode == HttpStatusCode.Forbidden)
                {
                    throw new UnauthorizedAccessException($"Access denied: {finalResponse.StatusCode}");
                }
                
                return EmptyJsonElementList;
            }
            
            if (finalResponse.Content == null)
            {
                Logger.LogWarning("Response.Content is null");
                RecordError("GetRealmEvents", "NullContent");
                return EmptyJsonElementList;
            }
            
            var content = await finalResponse.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            
            // Запись метрики размера ответа
            RecordResponseSize("GetRealmEvents", content.Length);
            
            // Проверка на максимальную длину content перед десериализацией
            if (content.Length > MaxContentLength)
            {
                Logger.LogWarning("Response content length ({ContentLength}) exceeds maximum allowed length ({MaxLength})", content.Length, MaxContentLength);
                RecordError("GetRealmEvents", "ContentTooLarge");
                return EmptyJsonElementList;
            }
            
            // Проверка на пустой контент перед десериализацией
            if (string.IsNullOrWhiteSpace(content))
            {
                Logger.LogWarning("Received empty response when retrieving events");
                RecordError("GetRealmEvents", "EmptyContent");
                return EmptyJsonElementList;
            }
            
            // Проверка cancellation token перед долгой операцией десериализации
            cancellationToken.ThrowIfCancellationRequested();
            
            // Предварительная проверка валидности JSON структуры (исправление проблемы #39)
            // Проверяем базовую структуру перед полным парсингом
            var trimmedContent = content.TrimStart();
            if (!trimmedContent.StartsWith("[", StringComparison.Ordinal) && !trimmedContent.StartsWith("{", StringComparison.Ordinal))
            {
                Logger.LogError("Invalid JSON structure: content does not start with '[' or '{{'");
                RecordError("GetRealmEvents", "InvalidJsonStructure");
                return EmptyJsonElementList;
            }
            
            var deserializationTime = Stopwatch.StartNew();
            JsonElement rootElement;
            try
            {
                rootElement = JsonSerializer.Deserialize<JsonElement>(content, DefaultJsonOptions);
            }
            catch (JsonException ex)
            {
                if (Logger.IsEnabled(LogLevel.Error))
                {
                    var truncatedContent = content.Length > MaxContentLengthForLogging
                        ? content[..MaxContentLengthForLogging] + "..."
                        : content;
                    Logger.LogError(
                        ex,
                        "Error deserializing JSON when retrieving events. JSON path: {Path}, Line: {LineNumber}, Position: {BytePosition}. Content preview: {Content}",
                        ex.Path ?? "unknown",
                        ex.LineNumber ?? 0,
                        ex.BytePositionInLine ?? 0,
                        truncatedContent);
                }
                var errorType = !string.IsNullOrEmpty(ex.Path) 
                    ? $"JsonDeserializationError_Path_{ex.Path}" 
                    : "JsonDeserializationError";
                RecordError("GetRealmEvents", errorType);
                return EmptyJsonElementList;
            }
            
            // Проверка структуры JSON - должен быть массив
            if (rootElement.ValueKind != JsonValueKind.Array)
            {
                Logger.LogWarning("Expected JSON array but got {ValueKind} when retrieving events", rootElement.ValueKind);
                RecordError("GetRealmEvents", "InvalidJsonStructure");
                return EmptyJsonElementList;
            }
            
            // Используем EnumerateArray для эффективной итерации
            var arrayLength = rootElement.GetArrayLength();
            if (arrayLength == 0)
            {
                return EmptyJsonElementList;
            }
            
            // Защита от слишком больших списков
            var maxAllowed = Math.Min(MaxEventsValue, maxEvents);
            var eventsToTake = Math.Min(arrayLength, maxAllowed);
            if (arrayLength > MaxEventsValue)
            {
                Logger.LogWarning(
                    "Received {Count} events, which exceeds maximum allowed {MaxEvents}. Truncating to {MaxEvents}",
                    arrayLength, MaxEventsValue, MaxEventsValue);
                RecordError("GetRealmEvents", "TooManyEvents");
            }
            
            var events = new List<JsonElement>(eventsToTake);
            
            // Оптимизация проверки cancellation token (исправление проблемы #8)
            const int CancellationCheckInterval = 10;
            int iterationCount = 0;
            
            foreach (var element in rootElement.EnumerateArray())
            {
                // Проверяем cancellation token раз в N итераций для улучшения производительности
                if (++iterationCount % CancellationCheckInterval == 0)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                }
                
                if (events.Count >= eventsToTake)
                {
                    break;
                }
                events.Add(element);
            }
            
            var result = new ReadOnlyCollection<JsonElement>(events);
            deserializationTime.Stop();
            MetricsService.RecordOperationTime($"{MetricsOperationName}.GetRealmEvents.Deserialization", deserializationTime.ElapsedMilliseconds);
            
            // Логирование успешных операций на уровне Debug
            if (Logger.IsEnabled(LogLevel.Debug))
            {
                Logger.LogDebug(
                    "Successfully retrieved {Count} events from realm {Realm}",
                    result.Count,
                    realm);
            }
            
            // Запись метрик успешной операции
            RecordSuccess("GetRealmEvents");
            
            return result;
        }
        catch (UnauthorizedAccessException)
        {
            // Пробрасываем исключение авторизации дальше
            throw;
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout when retrieving events from realm {Realm}", realm);
            RecordError("GetRealmEvents", "Timeout");
            return EmptyJsonElementList;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Operation to retrieve events was cancelled");
            RecordError("GetRealmEvents", "Cancelled");
            return EmptyJsonElementList;
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning("Operation to retrieve events was cancelled");
            RecordError("GetRealmEvents", "Cancelled");
            return EmptyJsonElementList;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Error when retrieving events from realm {Realm}", realm);
            RecordError("GetRealmEvents", "UnexpectedError");
            return EmptyJsonElementList;
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                MetricsService.RecordOperationTime($"{MetricsOperationName}.GetRealmEvents.Total", stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Получение всех доступных типов событий из реалма (с кэшированием)
    /// Использует официальный Keycloak API endpoint /admin/realms/{realm}/events/config
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="forceRefresh">Принудительное обновление кэша (по умолчанию false)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список типов событий</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидном параметре realm</exception>
    public async Task<IReadOnlyList<string>> GetEventTypesAsync(string realm, bool forceRefresh = false, CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        KeycloakParameterValidator.ValidateRealm(realm);
        
        // Инвалидируем кэш если требуется принудительное обновление
        if (forceRefresh)
        {
            CacheService.InvalidateEventTypes(realm);
        }
        
        // Используем кэш с фабричной функцией
        // Преобразуем IReadOnlyList<string> в List<string> для совместимости с кэшем
        return await CacheService.GetOrCreateEventTypesAsync(
            realm,
            async () => (await LoadEventTypesFromKeycloakAsync(realm, cancellationToken).ConfigureAwait(false)).ToList(),
            cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Загрузка типов событий непосредственно из Keycloak (без кэша)
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список типов событий</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидном параметре realm</exception>
    private async Task<IReadOnlyList<string>> LoadEventTypesFromKeycloakAsync(string realm, CancellationToken cancellationToken = default)
    {
        // Валидация удалена - она уже выполнена в GetEventTypesAsync
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation");
            return EmptyStringList;
        }
        try
        {
            // Безопасное построение endpoint (исправление проблемы #38)
            // Используем string interpolation для коротких строк
            var endpoint = $"{AdminRealmsPath}/{Uri.EscapeDataString(realm)}{EventsConfigPath}";
            
            // Валидация endpoint перед использованием
            ValidateEndpoint(endpoint);
            
            using var request = await CreateAuthorizedRequestAsync(HttpMethod.Get, endpoint, cancellationToken).ConfigureAwait(false);
            
            var networkTime = Stopwatch.StartNew();
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            networkTime.Stop();
            MetricsService.RecordOperationTime($"{MetricsOperationName}.GetEventTypes.Network", networkTime.ElapsedMilliseconds);
            
            // Обработка rate limiting
            var finalResponse = await HandleRateLimitAsync(
                response,
                async () => 
                {
                    using var retryRequest = await CreateAuthorizedRequestAsync(HttpMethod.Get, endpoint, cancellationToken).ConfigureAwait(false);
                    return await HttpClient.SendAsync(retryRequest, cancellationToken).ConfigureAwait(false);
                },
                cancellationToken).ConfigureAwait(false);
            
            if (finalResponse == null)
            {
                Logger.LogError("HandleRateLimitAsync returned null response");
                RecordError("GetEventTypes", "NullResponse");
                return GetDefaultEventTypes();
            }
            
            if (!finalResponse.IsSuccessStatusCode)
            {
                await LogAndRecordHttpError(finalResponse, "GetEventTypes", cancellationToken).ConfigureAwait(false);
                return GetDefaultEventTypes();
            }
            
            if (finalResponse.Content == null)
            {
                Logger.LogWarning("Response.Content is null");
                RecordError("GetEventTypes", "NullContent");
                return GetDefaultEventTypes();
            }
            
            var content = await finalResponse.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            
            // Запись метрики размера ответа
            RecordResponseSize("GetEventTypes", content.Length);
            
            // Проверка на максимальную длину content перед десериализацией
            if (content.Length > MaxContentLength)
            {
                Logger.LogWarning("Response content length ({ContentLength}) exceeds maximum allowed length ({MaxLength})", content.Length, MaxContentLength);
                RecordError("GetEventTypes", "ContentTooLarge");
                return GetDefaultEventTypes();
            }
            
            // Проверка на пустой контент перед десериализацией
            if (string.IsNullOrWhiteSpace(content))
            {
                Logger.LogWarning("Received empty response when retrieving event types configuration");
                RecordError("GetEventTypes", "EmptyContent");
                return GetDefaultEventTypes();
            }
            
            // Проверка cancellation token перед долгой операцией десериализации
            cancellationToken.ThrowIfCancellationRequested();
            
            var deserializationTime = Stopwatch.StartNew();
            JsonElement config;
            try
            {
                config = JsonSerializer.Deserialize<JsonElement>(content, DefaultJsonOptions);
                deserializationTime.Stop();
                MetricsService.RecordOperationTime($"{MetricsOperationName}.GetEventTypes.Deserialization", deserializationTime.ElapsedMilliseconds);
            }
            catch (JsonException ex)
            {
                deserializationTime.Stop();
                MetricsService.RecordOperationTime($"{MetricsOperationName}.GetEventTypes.Deserialization", deserializationTime.ElapsedMilliseconds);
                if (Logger.IsEnabled(LogLevel.Error))
                {
                    var truncatedContent = content.Length > MaxContentLengthForLogging
                        ? content[..MaxContentLengthForLogging] + "..."
                        : content;
                    Logger.LogError(
                        ex,
                        "Error deserializing JSON when retrieving event types configuration. JSON path: {Path}, Line: {LineNumber}, Position: {BytePosition}. Content preview: {Content}",
                        ex.Path ?? "unknown",
                        ex.LineNumber ?? 0,
                        ex.BytePositionInLine ?? 0,
                        truncatedContent);
                }
                var errorType = !string.IsNullOrEmpty(ex.Path) 
                    ? $"JsonDeserializationError_Path_{ex.Path}" 
                    : "JsonDeserializationError";
                RecordError("GetEventTypes", errorType);
                return GetDefaultEventTypes();
            }
            
            // Проверка ValueKind для валидности config
            if (config.ValueKind == JsonValueKind.Null || config.ValueKind == JsonValueKind.Undefined)
            {
                Logger.LogWarning("Deserialized config is null or undefined");
                RecordError("GetEventTypes", "InvalidConfig");
                return GetDefaultEventTypes();
            }
            
            // Предварительная оценка емкости для оптимизации (используем размер дефолтного списка как базу)
            int estimatedCapacity = DefaultEventTypes.Count;
            
            // Пытаемся получить enabledEventTypes из конфигурации
            if (config.TryGetProperty("enabledEventTypes", out var enabledTypes) && 
                enabledTypes.ValueKind == JsonValueKind.Array)
            {
                // Получаем длину массива из JSON для оптимального выделения памяти
                var arrayLength = enabledTypes.GetArrayLength();
                estimatedCapacity = Math.Max(DefaultEventTypes.Count, arrayLength);
                var eventTypes = new List<string>(estimatedCapacity);
                
                foreach (var eventType in enabledTypes.EnumerateArray())
                {
                    var type = eventType.GetString();
                    if (!string.IsNullOrEmpty(type))
                    {
                        if (type.Length > MaxEventTypeLength)
                        {
                            Logger.LogWarning("Event type length ({Length}) exceeds maximum allowed length ({MaxLength}), skipping", type.Length, MaxEventTypeLength);
                            continue;
                        }
                        eventTypes.Add(type);
                    }
                }
                
                // Если список пустой, возвращаем копию дефолтных типов
                if (eventTypes.Count == 0)
                {
                    if (Logger.IsEnabled(LogLevel.Debug))
                    {
                        Logger.LogDebug("No event types found in response, returning default event types for realm {Realm}", realm);
                    }
                    return GetDefaultEventTypes();
                }
                
                // Используем in-place сортировку вместо OrderBy().ToList() для оптимизации производительности
                eventTypes.Sort();
                
                // Логирование успешных операций на уровне Debug
                if (Logger.IsEnabled(LogLevel.Debug))
                {
                    Logger.LogDebug(
                        "Successfully retrieved {Count} event types from realm {Realm}",
                        eventTypes.Count,
                        realm);
                }
                
                // Запись метрик успешной операции
                RecordSuccess("GetEventTypes");
                
                return new ReadOnlyCollection<string>(eventTypes);
            }
            
            // Если свойство не найдено или не является массивом, возвращаем дефолтные типы
            return GetDefaultEventTypes();
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout when retrieving event types from realm {Realm}", realm);
            RecordError("GetEventTypes", "Timeout");
            return GetDefaultEventTypes();
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Operation to retrieve event types was cancelled");
            RecordError("GetEventTypes", "Cancelled");
            return GetDefaultEventTypes();
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning("Operation to retrieve event types was cancelled");
            RecordError("GetEventTypes", "Cancelled");
            return GetDefaultEventTypes();
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Error when retrieving event types from realm {Realm}", realm);
            RecordError("GetEventTypes", "UnexpectedError");
            return GetDefaultEventTypes();
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                MetricsService.RecordOperationTime($"{MetricsOperationName}.GetEventTypes.Total", stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Возвращает копию базового списка типов событий Keycloak
    /// </summary>
    private IReadOnlyList<string> GetDefaultEventTypes()
    {
        // Возвращаем предварительно отсортированный список напрямую, так как он readonly
        return CachedDefaultEventTypes.Value;
    }
    
    /// <summary>
    /// Записать метрику размера ответа
    /// </summary>
    private void RecordResponseSize(string methodName, int sizeInBytes)
    {
        if (MetricsService != null)
        {
            // Используем RecordOperationTime для записи размера ответа как метрики времени
            // (хотя это не время, но позволяет записать числовое значение)
            // В будущем можно добавить отдельный метод RecordGauge в IPerformanceMetricsService
            MetricsService.RecordOperationTime($"{MetricsOperationName}.{methodName}.ResponseSize", sizeInBytes);
        }
    }
}

