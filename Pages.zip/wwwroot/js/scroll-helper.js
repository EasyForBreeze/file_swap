// Функция для плавного скролла к элементу по ID с задержкой
window.scrollToElementId = function(elementId, delay, duration) {
    setTimeout(function() {
        const element = document.getElementById(elementId);
        if (!element) {
            return;
        }

        const targetPosition = element.getBoundingClientRect().top + window.pageYOffset - 80;
        const startPosition = window.pageYOffset;
        const distance = targetPosition - startPosition;
        const animationDuration = (typeof duration === 'number' ? duration : 600);
        let startTime = null;

        function easeInOutQuad(t) {
            return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
        }

        function animationStep(currentTime) {
            if (startTime === null) {
                startTime = currentTime;
            }

            const timeElapsed = currentTime - startTime;
            const progress = Math.min(timeElapsed / animationDuration, 1);
            const easedProgress = easeInOutQuad(progress);

            window.scrollTo(0, startPosition + distance * easedProgress);

            if (timeElapsed < animationDuration) {
                window.requestAnimationFrame(animationStep);
            }
        }

        window.requestAnimationFrame(animationStep);
    }, delay || 0);
};

window.centerModalVertically = function(modalId) {
    const modal = document.getElementById(modalId);
    if (!modal) {
        return;
    }

    const overlay = modal.parentElement;
    if (!overlay) {
        return;
    }

    const viewportHeight = window.innerHeight;
    const modalHeight = modal.offsetHeight;
    const offset = Math.max((viewportHeight - modalHeight) / 2, 20);

    overlay.style.alignItems = 'flex-start';
    modal.style.marginTop = `${offset}px`;
};

// Функция для прокрутки элемента в начало
window.scrollElementToTop = function(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.scrollTop = 0;
    }
};

// Функция для прокрутки элемента в конец
window.scrollElementToBottom = function(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.scrollTop = element.scrollHeight;
    }
};

