namespace new_assistant.Configuration;

/// <summary>
/// Настройки для сервиса очистки аудит логов
/// </summary>
public class AuditLogCleanupSettings
{
    /// <summary>
    /// Включен ли сервис очистки
    /// </summary>
    public bool Enabled { get; set; } = true;

    /// <summary>
    /// Интервал между очистками
    /// </summary>
    public TimeSpan CleanupInterval { get; set; } = TimeSpan.FromHours(24);

    /// <summary>
    /// Количество дней хранения логов
    /// </summary>
    public int RetentionDays { get; set; } = 90;

    /// <summary>
    /// Задержка перед первой очисткой после запуска сервиса
    /// </summary>
    public TimeSpan? InitialDelay { get; set; } = TimeSpan.FromMinutes(1);

    /// <summary>
    /// Включить ли выполнение VACUUM для оптимизации БД
    /// </summary>
    public bool EnableVacuum { get; set; } = true;

    /// <summary>
    /// Минимальный процент удаленных записей для выполнения VACUUM (0-100)
    /// </summary>
    public double VacuumThresholdPercent { get; set; } = 10.0;

    /// <summary>
    /// Размер батча для удаления записей
    /// </summary>
    public int BatchSize { get; set; } = 10000;

    /// <summary>
    /// Задержка между батчами в миллисекундах
    /// </summary>
    public int BatchDelayMs { get; set; } = 100;

    /// <summary>
    /// Пропускать COUNT запрос перед удалением (для оптимизации на больших таблицах)
    /// </summary>
    public bool SkipCountQuery { get; set; } = false;

    /// <summary>
    /// Включить файловую блокировку для предотвращения одновременного выполнения
    /// </summary>
    public bool EnableFileLock { get; set; } = true;

    /// <summary>
    /// Интервал логирования прогресса в секундах (0 = отключено)
    /// </summary>
    public int ProgressLogIntervalSeconds { get; set; } = 30;
}

