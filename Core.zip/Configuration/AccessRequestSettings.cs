namespace new_assistant.Configuration;

/// <summary>
/// Настройки для отправки заявок на доступ
/// </summary>
public sealed class AccessRequestSettings
{
    /// <summary>
    /// Email адрес администратора для отправки заявок на доступ
    /// </summary>
    public string AdminEmail { get; init; } = string.Empty;
    
    /// <summary>
    /// Время в минутах между отправками заявок одним пользователем (rate limiting)
    /// </summary>
    public int CooldownMinutes { get; init; } = 60;
}

