namespace new_assistant.Configuration;

/// <summary>
/// Настройки кэширования Keycloak данных
/// </summary>
public class KeycloakCacheSettings
{
    /// <summary>
    /// Время жизни кэша списка реалмов (в минутах)
    /// </summary>
    public int RealmsListTtlMinutes { get; set; } = 15;
    
    /// <summary>
    /// Время жизни кэша типов событий (в минутах)
    /// </summary>
    public int EventTypesTtlMinutes { get; set; } = 30;
    
    /// <summary>
    /// Время жизни кэша well-known endpoints (в минутах)
    /// </summary>
    public int WellKnownEndpointsTtlMinutes { get; set; } = 60;
    
    /// <summary>
    /// Включен ли кэш
    /// </summary>
    public bool Enabled { get; set; } = true;
}

