namespace new_assistant.Configuration;

/// <summary>
/// Настройки для сервиса очистки архивов
/// </summary>
public class ArchiveCleanupSettings
{
    /// <summary>
    /// Интервал между очистками
    /// </summary>
    public TimeSpan CleanupInterval { get; set; } = TimeSpan.FromDays(1);

    /// <summary>
    /// Количество дней хранения архивов
    /// </summary>
    public int ArchiveRetentionDays { get; set; } = 1;

    /// <summary>
    /// Задержка перед первой очисткой после запуска сервиса
    /// </summary>
    public TimeSpan? InitialDelay { get; set; } = null;

    /// <summary>
    /// Максимальное количество файлов для обработки за один проход (0 = без ограничения)
    /// </summary>
    public int MaxFilesPerPass { get; set; } = 0;

    /// <summary>
    /// Размер батча для параллельной обработки файлов (0 = последовательная обработка)
    /// </summary>
    public int BatchSize { get; set; } = 0;

    /// <summary>
    /// Максимальный размер батча для параллельной обработки (0 = без ограничения, используется Environment.ProcessorCount)
    /// </summary>
    public int MaxBatchSize { get; set; } = 0;

    /// <summary>
    /// Таймаут для операций с файлами (0 = без таймаута)
    /// </summary>
    public TimeSpan? FileOperationTimeout { get; set; } = null;

    /// <summary>
    /// Количество попыток retry для временных ошибок (0 = без retry)
    /// </summary>
    public int RetryCount { get; set; } = 0;

    /// <summary>
    /// Базовая задержка для retry (используется экспоненциальная задержка)
    /// </summary>
    public TimeSpan RetryDelay { get; set; } = TimeSpan.FromSeconds(1);
}

