namespace new_assistant.Configuration;

/// <summary>
/// Настройки шаблона Confluence
/// </summary>
public sealed class ConfluenceTemplateSettings
{
    /// <summary>
    /// Путь к файлу шаблона (опционально)
    /// Если не указан, используется встроенный шаблон
    /// </summary>
    public string? TemplatePath { get; set; }

    /// <summary>
    /// Директория с шаблонами (опционально)
    /// Если указана, загружаются все шаблоны из этой директории
    /// Структура: TemplatesDirectory/{culture}/{templateName}.html
    /// Пример: Templates/ru-RU/default.html, Templates/en-US/default.html
    /// </summary>
    public string? TemplatesDirectory { get; set; }

    /// <summary>
    /// Формат заголовка страницы
    /// {0} - префикс realm, {1} - ClientID
    /// По умолчанию: "{0}-BNK. {1}"
    /// </summary>
    public string TitleFormat { get; set; } = "{0}-BNK. {1}";

    /// <summary>
    /// Версия шаблона
    /// </summary>
    public string Version { get; set; } = "1.0";

    /// <summary>
    /// Культура по умолчанию для шаблонов
    /// Если не указана, используется CultureInfo.CurrentCulture
    /// </summary>
    public string? DefaultCulture { get; set; }

    /// <summary>
    /// Культура для fallback, если шаблон для запрошенной культуры не найден
    /// По умолчанию: "en-US"
    /// </summary>
    public string FallbackCulture { get; set; } = "en-US";
}

