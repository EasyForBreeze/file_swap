namespace new_assistant.Configuration;

/// <summary>
/// Настройки страницы просмотра логов
/// </summary>
public sealed class LogsPageSettings
{
    /// <summary>
    /// Максимальное количество строк для отображения
    /// </summary>
    public int MaxLinesShown { get; init; } = 10000;

    /// <summary>
    /// Максимальный размер файла для просмотра в байтах (по умолчанию 100 МБ)
    /// </summary>
    public long MaxFileSizeBytes { get; init; } = 100 * 1024 * 1024;

    /// <summary>
    /// Время жизни кэша списка файлов (в минутах)
    /// </summary>
    public int FileListCacheTtlMinutes { get; init; } = 1;

    /// <summary>
    /// Таймаут для чтения файла (в секундах)
    /// </summary>
    public int FileReadTimeoutSeconds { get; init; } = 60;
}

