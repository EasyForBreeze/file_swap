using Microsoft.Extensions.Diagnostics.HealthChecks;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.HealthChecks;

/// <summary>
/// Health check для проверки доступности Confluence
/// </summary>
public class ConfluenceHealthCheck : IHealthCheck
{
    private readonly IConfluenceService _confluenceService;
    private readonly ILogger<ConfluenceHealthCheck> _logger;

    public ConfluenceHealthCheck(IConfluenceService confluenceService, ILogger<ConfluenceHealthCheck> logger)
    {
        _confluenceService = confluenceService;
        _logger = logger;
    }

    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            // Используем публичный метод IsAvailableAsync для проверки доступности
            var isAvailable = await _confluenceService.IsAvailableAsync().ConfigureAwait(false);
            
            if (isAvailable)
            {
                return HealthCheckResult.Healthy(
                    "Confluence доступен",
                    data: new Dictionary<string, object>
                    {
                        { "timestamp", DateTime.UtcNow }
                    });
            }

            return HealthCheckResult.Degraded(
                "Confluence недоступен",
                data: new Dictionary<string, object>
                {
                    { "timestamp", DateTime.UtcNow }
                });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при проверке Confluence");
            return HealthCheckResult.Unhealthy(
                $"Не удалось проверить Confluence: {ex.Message}",
                ex,
                data: new Dictionary<string, object>
                {
                    { "error", ex.GetType().Name },
                    { "message", ex.Message },
                    { "timestamp", DateTime.UtcNow }
                });
        }
    }
}

