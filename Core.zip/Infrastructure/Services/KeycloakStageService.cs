using System.Collections.Concurrent;
using System.Net;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для работы с Keycloak STAGE контуром.
/// Предоставляет высокоуровневые методы для управления клиентами, ролями, scopes и другими ресурсами Keycloak в STAGE окружении.
/// </summary>
/// <remarks>
/// <para>Сервис обеспечивает:</para>
/// <list type="bullet">
/// <item><description>Создание и управление клиентами Keycloak</description></item>
/// <item><description>Работу с realm и client ролями</description></item>
/// <item><description>Назначение ролей service account</description></item>
/// <item><description>Управление client scopes и protocol mappers</description></item>
/// <item><description>Проверку существования различных ресурсов</description></item>
/// </list>
/// <para>Все методы асинхронны и поддерживают cancellation tokens для отмены операций.</para>
/// </remarks>
public class KeycloakStageService : IKeycloakStageService
{
    private readonly IKeycloakStageHttpClient _httpClient;
    private readonly KeycloakStageSettings _settings;
    private readonly ILogger<KeycloakStageService> _logger;
    
    // Константы для валидации
    private const int MaxStringLength = 10000;
    private const int MaxUrlLength = 2048;
    private const int MaxRegexInputLength = 1000;
    
    // Кэш для URL encoding (опционально, для оптимизации)
    private static readonly ConcurrentDictionary<string, string> UrlEncodeCache = new(StringComparer.Ordinal);

    public KeycloakStageService(
        IKeycloakStageHttpClient httpClient,
        IOptions<KeycloakStageSettings> settings,
        ILogger<KeycloakStageService> logger)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _settings = settings?.Value ?? throw new ArgumentNullException(nameof(settings));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Получает список всех реалмов в STAGE окружении, исключая реалмы из списка исключений (обычно master).
    /// </summary>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>Список имен реалмов. Возвращает пустой список при ошибках (ошибки логируются).</returns>
    /// <remarks>
    /// Метод обрабатывает ошибки внутренне и возвращает пустой список при возникновении исключений.
    /// Реалмы из настроек ExcludedRealms будут автоматически исключены из результата.
    /// </remarks>
    public async Task<IEnumerable<string>> GetRealmsListAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            var endpoint = "admin/realms";
            var realms = await _httpClient.GetAsync<List<JsonElement>>(endpoint, cancellationToken).ConfigureAwait(false);
            
            if (realms == null)
                return Array.Empty<string>();

            // Оптимизация: используем HashSet для быстрой проверки исключений
            var excludedSet = _settings.ExcludedRealms != null 
                ? new HashSet<string>(_settings.ExcludedRealms, StringComparer.OrdinalIgnoreCase)
                : new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            
            var result = new List<string>(realms.Count);
            
            foreach (var r in realms)
            {
                try
                {
                    if (r.TryGetProperty("realm", out var realmProp))
                    {
                        var realmName = GetStringSafely(realmProp);
                        if (!string.IsNullOrEmpty(realmName) && !excludedSet.Contains(realmName))
                        {
                            result.Add(realmName);
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Ошибка обработки realm элемента");
                }
            }
            
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка получения списка реалмов из STAGE");
            return Array.Empty<string>();
        }
    }

    /// <summary>
    /// Проверяет существование клиента с указанным ClientId в указанном realm STAGE окружения.
    /// </summary>
    /// <param name="clientId">Идентификатор клиента для проверки (clientId, не internal ID)</param>
    /// <param name="realm">Имя realm для проверки</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>true, если клиент существует, иначе false. Возвращает false при ошибках (ошибки логируются).</returns>
    /// <exception cref="ArgumentException">Если clientId или realm пусты или содержат только пробелы</exception>
    public async Task<bool> ClientExistsAsync(string clientId, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        ValidateParameter(clientId, nameof(clientId), MaxStringLength);
        ValidateParameter(realm, nameof(realm), MaxStringLength);
        
        try
        {
            _logger.LogDebug("Проверка существования клиента {ClientId} в STAGE realm {Realm}", clientId, realm);
            
            var encodedClientId = UrlEncodeCached(clientId);
            var endpoint = $"admin/realms/{UrlEncodeCached(realm)}/clients?clientId={encodedClientId}";
            
            var clients = await _httpClient.GetAsync<List<JsonElement>>(endpoint, cancellationToken).ConfigureAwait(false);
            var exists = clients != null && clients.Count > 0;
            
            _logger.LogDebug("Клиент {ClientId} в STAGE realm {Realm} существует: {Exists}", clientId, realm, exists);
            
            return exists;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка проверки существования клиента {ClientId} в STAGE realm {Realm}", clientId, realm);
            return false;
        }
    }

    /// <summary>
    /// Создает нового клиента в указанном realm STAGE окружения на основе предоставленных деталей.
    /// </summary>
    /// <param name="clientDetails">Детали клиента для создания (ClientId, настройки протокола, redirect URIs и т.д.)</param>
    /// <param name="realm">Имя realm, в котором будет создан клиент</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>Internal ID созданного клиента (UUID), извлекаемый из Location header ответа</returns>
    /// <exception cref="ArgumentNullException">Если clientDetails равен null</exception>
    /// <exception cref="ArgumentException">Если ClientId в clientDetails или realm пусты</exception>
    /// <exception cref="HttpRequestException">При ошибках HTTP запроса (ошибки создания клиента)</exception>
    /// <exception cref="InvalidOperationException">Если не удалось извлечь internal ID из Location header ответа</exception>
    /// <remarks>
    /// Метод автоматически извлекает internal ID клиента из Location header ответа Keycloak.
    /// Если извлечение не удалось, будет выброшено исключение с детальной информацией об ошибке.
    /// </remarks>
    public async Task<string> CreateClientAsync(ClientDetailsDto clientDetails, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        if (clientDetails == null)
            throw new ArgumentNullException(nameof(clientDetails));
        
        ValidateParameter(clientDetails.ClientId, nameof(clientDetails.ClientId), MaxStringLength);
        ValidateParameter(realm, nameof(realm), MaxStringLength);
        
        try
        {
            _logger.LogInformation("Создание клиента {ClientId} в STAGE realm {Realm}", clientDetails.ClientId, realm);
            
            var endpoint = $"admin/realms/{realm}/clients";
            var clientPayload = BuildClientCreationPayload(clientDetails);

            using var response = await _httpClient.PostAsync(endpoint, clientPayload, cancellationToken).ConfigureAwait(false);
            
            if (!response.IsSuccessStatusCode)
            {
                string error = await ReadResponseContentSafelyAsync(response, cancellationToken, clientDetails.ClientId, "создании клиента");
                
                _logger.LogError("Ошибка создания клиента {ClientId} в STAGE realm {Realm}: {StatusCode} - {Error}", 
                    clientDetails.ClientId, realm, response.StatusCode, error);
                
                var httpEx = new HttpRequestException($"Ошибка создания клиента в STAGE: {response.StatusCode} - {error}");
                httpEx.Data["StatusCode"] = response.StatusCode;
                httpEx.Data["Realm"] = realm;
                httpEx.Data["ClientId"] = clientDetails.ClientId;
                throw httpEx;
            }

            // Получаем Location header для извлечения internal ID
            var location = response.Headers.Location?.ToString();
            if (string.IsNullOrEmpty(location))
            {
                throw new InvalidOperationException("Не удалось получить internal ID созданного клиента: Location header отсутствует");
            }

            string internalId;
            try
            {
                // Оптимизация: используем TryCreate для более эффективного парсинга
                if (Uri.TryCreate(location, UriKind.RelativeOrAbsolute, out var locationUri) && locationUri != null)
                {
                    var segments = locationUri.Segments;
                    if (segments != null && segments.Length > 0)
                    {
                        var lastSegment = segments[segments.Length - 1];
                        internalId = SafeTrimEnd(lastSegment, '/');
                        
                        if (!string.IsNullOrWhiteSpace(internalId) && internalId != "clients")
                        {
                            // Успешно извлекли из segments
                        }
                        else
                        {
                            internalId = string.Empty;
                        }
                    }
                    else
                    {
                        internalId = string.Empty;
                    }
                }
                else
                {
                    internalId = string.Empty;
                }

                if (string.IsNullOrWhiteSpace(internalId) || internalId == "clients")
                {
                    // Попробуем извлечь ID из пути (UUID формат, поддерживает заглавные и строчные буквы)
                    // Ограничиваем длину входной строки для защиты от ReDoS
                    if (location.Length > MaxRegexInputLength)
                    {
                        throw new InvalidOperationException($"Location header слишком длинный для безопасной обработки: {location.Length} символов");
                    }
                    
                    try
                    {
                        var match = Regex.Match(location, @"/([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})(?:/|$)", RegexOptions.IgnoreCase | RegexOptions.Compiled, TimeSpan.FromSeconds(1));
                        if (match.Success && match.Groups.Count > 1)
                        {
                            internalId = match.Groups[1].Value;
                        }
                        else
                        {
                            throw new InvalidOperationException($"Не удалось извлечь internal ID из Location header: {location}");
                        }
                    }
                    catch (RegexMatchTimeoutException ex)
                    {
                        _logger.LogError(ex, "Timeout при обработке Location header: {Location}", location);
                        throw new InvalidOperationException($"Timeout при извлечении internal ID из Location header: {location}", ex);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Ошибка при обработке Location header: {Location}", location);
                        throw new InvalidOperationException($"Не удалось извлечь internal ID из Location header: {location}", ex);
                    }
                }
            }
            catch (UriFormatException ex)
            {
                _logger.LogError(ex, "Неверный формат Location header: {Location}", location);
                throw new InvalidOperationException($"Неверный формат Location header: {location}", ex);
            }
            _logger.LogInformation("Клиент {ClientId} успешно создан в STAGE realm {Realm} с ID {InternalId}", 
                clientDetails.ClientId, realm, internalId);

            return internalId;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка создания клиента {ClientId} в STAGE realm {Realm}", clientDetails.ClientId, realm);
            throw;
        }
    }

    private static object BuildClientCreationPayload(ClientDetailsDto clientDetails)
    {
        var redirectUris = SanitizeStringList(clientDetails.RedirectUris);
        var webOrigins = SanitizeStringList(clientDetails.WebOrigins);
        var attributes = BuildAttributesPayload(clientDetails.Attributes);

        var baseUrl = NormalizeUrl(clientDetails.BaseUrl);
        var rootUrl = NormalizeUrl(clientDetails.RootUrl);
        var adminUrl = NormalizeUrl(clientDetails.AdminUrl);

        return new
        {
            clientId = clientDetails.ClientId,
            name = clientDetails.Name,
            description = clientDetails.Description,
            enabled = clientDetails.Enabled,
            protocol = clientDetails.Protocol ?? "openid-connect",
            publicClient = clientDetails.ClientType == "public" || clientDetails.AccessType == "public",
            serviceAccountsEnabled = clientDetails.ServiceAccountsEnabled,
            directAccessGrantsEnabled = clientDetails.DirectAccessGrantsEnabled,
            standardFlowEnabled = clientDetails.StandardFlow,
            implicitFlowEnabled = false,
            authorizationServicesEnabled = clientDetails.AuthorizationServicesEnabled,
            frontchannelLogout = true,
            redirectUris,
            webOrigins,
            baseUrl,
            rootUrl,
            adminUrl,
            attributes
        };
    }

    private static List<string> SanitizeStringList(IEnumerable<string?>? source)
    {
        if (source == null)
            return new List<string>();
        
        // Оптимизация: используем HashSet для дедупликации
        var seen = new HashSet<string>(StringComparer.Ordinal);
        var result = new List<string>();
        
        foreach (var value in source)
        {
            try
            {
                var trimmed = SafeTrim(value);
                if (!string.IsNullOrEmpty(trimmed) && seen.Add(trimmed))
                {
                    result.Add(trimmed);
                }
            }
            catch
            {
                // Игнорируем некорректные значения
            }
        }
        
        return result;
    }

    private static Dictionary<string, object> BuildAttributesPayload(Dictionary<string, List<string>>? attributes)
    {
        if (attributes == null || attributes.Count == 0)
        {
            return new Dictionary<string, object>();
        }

        var result = new Dictionary<string, object>(StringComparer.Ordinal);

        foreach (var kvp in attributes)
        {
            try
            {
                var key = SafeTrim(kvp.Key);
                if (string.IsNullOrEmpty(key))
                {
                    continue;
                }

                var sourceValues = kvp.Value ?? new List<string>();
                // Оптимизация: используем HashSet для дедупликации
                var seen = new HashSet<string>(StringComparer.Ordinal);
                var values = new List<string>();
                
                foreach (var value in sourceValues)
                {
                    var trimmed = SafeTrim(value);
                    if (!string.IsNullOrEmpty(trimmed) && seen.Add(trimmed))
                    {
                        values.Add(trimmed);
                    }
                }

                if (values.Count > 0)
                {
                    result[key] = values.Count == 1
                        ? values[0]
                        : values;
                }
            }
            catch
            {
                // Игнорируем некорректные пары ключ-значение
            }
        }

        return result;
    }

    private static string? NormalizeUrl(string? url)
    {
        if (string.IsNullOrWhiteSpace(url))
        {
            return null;
        }

        try
        {
            var trimmed = SafeTrim(url);
            if (string.IsNullOrEmpty(trimmed))
            {
                return null;
            }
            
            // Базовая валидация URL (опционально, зависит от требований)
            // Keycloak может принимать как абсолютные, так и относительные URL
            // Поэтому проверяем только, что это не пустая строка после trim
            // Если требуется строгая валидация, можно добавить проверку через Uri.TryCreate
            
            return trimmed;
        }
        catch
        {
            return null;
        }
    }

    /// <summary>
    /// Получает Client Secret для указанного клиента по его internal ID.
    /// </summary>
    /// <param name="clientInternalId">Internal ID клиента (UUID)</param>
    /// <param name="realm">Имя realm, в котором находится клиент</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>Client Secret в виде строки, или null, если secret не найден или произошла ошибка</returns>
    /// <exception cref="ArgumentException">Если clientInternalId или realm пусты</exception>
    /// <remarks>
    /// Метод обрабатывает ошибки внутренне и возвращает null при возникновении проблем.
    /// Все ошибки логируются для последующего анализа.
    /// </remarks>
    public async Task<string?> GetClientSecretAsync(string clientInternalId, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        ValidateParameter(clientInternalId, nameof(clientInternalId), MaxStringLength);
        ValidateParameter(realm, nameof(realm), MaxStringLength);
        
        try
        {
            _logger.LogDebug("Получение client secret для клиента {ClientInternalId} в STAGE realm {Realm}", clientInternalId, realm);
            
            var endpoint = $"admin/realms/{realm}/clients/{clientInternalId}/client-secret";

            var secretData = await _httpClient.GetAsync<JsonElement>(endpoint, cancellationToken).ConfigureAwait(false);
            
            if (secretData.ValueKind == JsonValueKind.Undefined)
            {
                _logger.LogDebug("Client secret не найден для клиента {ClientInternalId} в STAGE realm {Realm}", clientInternalId, realm);
                return null;
            }

            if (!secretData.TryGetProperty("value", out var valueProp))
            {
                _logger.LogWarning("Client secret response does not contain 'value' property for client {ClientInternalId}", clientInternalId);
                return null;
            }

            var secret = GetStringSafely(valueProp);
            if (string.IsNullOrEmpty(secret))
            {
                _logger.LogWarning("Client secret 'value' is null or empty for client {ClientInternalId}", clientInternalId);
                return null;
            }
            
            _logger.LogDebug("Client secret успешно получен для клиента {ClientInternalId} в STAGE realm {Realm}", clientInternalId, realm);
            
            return secret;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка получения client secret для {ClientInternalId} в STAGE realm {Realm}", clientInternalId, realm);
            return null;
        }
    }

    /// <summary>
    /// Проверяет существование realm роли с указанным именем в указанном realm STAGE окружения.
    /// </summary>
    /// <param name="roleName">Имя realm роли для проверки</param>
    /// <param name="realm">Имя realm для проверки</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>true, если роль существует, иначе false. Возвращает false при ошибках (ошибки логируются).</returns>
    /// <exception cref="ArgumentException">Если roleName или realm пусты или содержат только пробелы</exception>
    /// <remarks>
    /// Метод использует HEAD запрос для проверки существования роли без загрузки её данных.
    /// HttpRequestException обрабатываются как "роль не найдена" и возвращают false.
    /// </remarks>
    public async Task<bool> RealmRoleExistsAsync(string roleName, string realm, CancellationToken cancellationToken = default)
    {
        ValidateParameter(roleName, nameof(roleName), MaxStringLength);
        ValidateParameter(realm, nameof(realm), MaxStringLength);
        
        try
        {
            var endpoint = $"admin/realms/{UrlEncodeCached(realm)}/roles/{UrlEncodeCached(roleName)}";
            var roleJson = await _httpClient.GetAsync<JsonElement>(endpoint, cancellationToken).ConfigureAwait(false);
            return roleJson.ValueKind != JsonValueKind.Undefined;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogDebug(ex, "Realm role {RoleName} не найдена в realm {Realm}", roleName, realm);
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка проверки существования realm role {RoleName} в realm {Realm}", roleName, realm);
            return false;
        }
    }

    /// <summary>
    /// Проверяет существование client роли с указанным именем для указанного клиента в STAGE окружении.
    /// </summary>
    /// <param name="clientId">ClientId клиента (не internal ID)</param>
    /// <param name="roleName">Имя client роли для проверки</param>
    /// <param name="realm">Имя realm, в котором находится клиент</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>true, если роль существует, иначе false. Возвращает false при ошибках (ошибки логируются).</returns>
    /// <exception cref="ArgumentException">Если clientId, roleName или realm пусты</exception>
    /// <remarks>
    /// Метод сначала находит клиента по ClientId, затем проверяет существование роли.
    /// Если клиент не найден или произошла ошибка, возвращается false.
    /// </remarks>
    public async Task<bool> ClientRoleExistsAsync(string clientId, string roleName, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        ValidateParameter(clientId, nameof(clientId), MaxStringLength);
        ValidateParameter(roleName, nameof(roleName), MaxStringLength);
        ValidateParameter(realm, nameof(realm), MaxStringLength);
        
        try
        {
            _logger.LogDebug("Проверка существования client роли {RoleName} для клиента {ClientId} в STAGE realm {Realm}", 
                roleName, clientId, realm);
            
            // Сначала найти internal ID клиента
            var clientEndpoint = $"admin/realms/{UrlEncodeCached(realm)}/clients?clientId={UrlEncodeCached(clientId)}";
            var clients = await _httpClient.GetAsync<List<JsonElement>>(clientEndpoint, cancellationToken).ConfigureAwait(false);
            if (clients == null || !clients.Any())
            {
                _logger.LogDebug("Клиент {ClientId} не найден в STAGE realm {Realm}", clientId, realm);
                return false;
            }

            JsonElement matchingClient = default;
            foreach (var c in clients)
            {
                if (c.TryGetProperty("clientId", out var cid))
                {
                    var cidValue = GetStringSafely(cid);
                    if (StringEqualsSafely(cidValue, clientId, StringComparison.OrdinalIgnoreCase))
                    {
                        matchingClient = c;
                        break;
                    }
                }
            }

            if (matchingClient.ValueKind == JsonValueKind.Undefined)
            {
                if (clients.Count > 0)
                {
                    matchingClient = clients[0];
                }
                else
                {
                    _logger.LogDebug("Клиент {ClientId} не найден в STAGE realm {Realm}", clientId, realm);
                    return false;
                }
            }

            if (!matchingClient.TryGetProperty("id", out var idProp))
            {
                _logger.LogWarning("Клиент {ClientId} найден, но не содержит 'id' property", clientId);
                return false;
            }
            
            var clientInternalId = GetStringSafely(idProp);
            if (string.IsNullOrEmpty(clientInternalId))
            {
                _logger.LogWarning("Клиент {ClientId} найден, но 'id' property пустое", clientId);
                return false;
            }
            var roleEndpoint = $"admin/realms/{UrlEncodeCached(realm)}/clients/{clientInternalId}/roles/{UrlEncodeCached(roleName)}";
            var roleJson = await _httpClient.GetAsync<JsonElement>(roleEndpoint, cancellationToken).ConfigureAwait(false);
            var exists = roleJson.ValueKind != JsonValueKind.Undefined;
            
            _logger.LogDebug("Client роль {RoleName} для клиента {ClientId} в STAGE realm {Realm} существует: {Exists}", 
                roleName, clientId, realm, exists);
            
            return exists;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка проверки существования client роли {RoleName} для клиента {ClientId} в STAGE realm {Realm}", 
                roleName, clientId, realm);
            return false;
        }
    }

    /// <summary>
    /// Создает одну или несколько client ролей для указанного клиента в STAGE окружении.
    /// </summary>
    /// <param name="clientInternalId">Internal ID клиента (UUID), для которого создаются роли</param>
    /// <param name="roleNames">Список имен ролей для создания</param>
    /// <param name="realm">Имя realm, в котором находится клиент</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <exception cref="ArgumentException">Если clientInternalId или realm пусты</exception>
    /// <exception cref="ArgumentNullException">Если roleNames равен null</exception>
    /// <remarks>
    /// <para>Метод обрабатывает роли последовательно и логирует результаты для каждой роли:</para>
    /// <list type="bullet">
    /// <item><description>Успешно созданные роли</description></item>
    /// <item><description>Роли, которые уже существуют (конфликт)</description></item>
    /// <item><description>Роли, которые не удалось создать (ошибки)</description></item>
    /// </list>
    /// <para>Пустой список roleNames не приводит к ошибке - метод просто завершается без действий.</para>
    /// <para>В конце операции выводится сводная статистика по созданию ролей.</para>
    /// </remarks>
    public async Task CreateClientRolesAsync(string clientInternalId, List<string> roleNames, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        ValidateParameter(clientInternalId, nameof(clientInternalId), MaxStringLength);
        ValidateParameter(realm, nameof(realm), MaxStringLength);
        
        if (roleNames == null)
            throw new ArgumentNullException(nameof(roleNames));
        
        if (roleNames.Count == 0)
        {
            _logger.LogWarning("Пустой список roleNames для клиента {ClientId}", clientInternalId);
            return;
        }
        
        // Валидация длины всех имен ролей
        foreach (var roleName in roleNames)
        {
            ValidateParameter(roleName, nameof(roleNames), MaxStringLength);
        }
        
        try
        {
            _logger.LogInformation("Создание {Count} client ролей для клиента {ClientInternalId} в STAGE realm {Realm}", 
                roleNames.Count, clientInternalId, realm);
            
            var endpoint = $"admin/realms/{UrlEncodeCached(realm)}/clients/{clientInternalId}/roles";

            int successCount = 0;
            int conflictCount = 0;
            int failedCount = 0;

            // Оптимизация: параллельное выполнение с ограничением параллелизма
            const int maxConcurrency = 10;
            var semaphore = new SemaphoreSlim(maxConcurrency);
            var tasks = roleNames.Select(async roleName =>
            {
                await semaphore.WaitAsync(cancellationToken).ConfigureAwait(false);
                try
                {
                    var roleData = new
                    {
                        name = roleName,
                        description = $"Роль {roleName}",
                        clientRole = true
                    };

                    HttpResponseMessage? response = null;
                    try
                    {
                        response = await _httpClient.PostAsync(endpoint, roleData, cancellationToken).ConfigureAwait(false);
                        
                        if (response.IsSuccessStatusCode)
                        {
                            Interlocked.Increment(ref successCount);
                            _logger.LogDebug("Роль {RoleName} создана для клиента {ClientId} в STAGE", roleName, clientInternalId);
                        }
                        else if (response.StatusCode == System.Net.HttpStatusCode.Conflict)
                        {
                            Interlocked.Increment(ref conflictCount);
                            _logger.LogDebug("Роль {RoleName} уже существует для клиента {ClientId} в STAGE", roleName, clientInternalId);
                        }
                        else
                        {
                            Interlocked.Increment(ref failedCount);
                            _logger.LogWarning("Не удалось создать роль {RoleName} для клиента {ClientId}: {StatusCode}", 
                                roleName, clientInternalId, response.StatusCode);
                        }
                    }
                    finally
                    {
                        response?.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    Interlocked.Increment(ref failedCount);
                    _logger.LogWarning(ex, "Ошибка создания роли {RoleName} для клиента {ClientId}", roleName, clientInternalId);
                }
                finally
                {
                    semaphore.Release();
                }
            });

            await Task.WhenAll(tasks).ConfigureAwait(false);

            _logger.LogInformation("Создание ролей завершено для клиента {ClientId}: создано {Success}, конфликтов {Conflict}, ошибок {Failed}", 
                clientInternalId, successCount, conflictCount, failedCount);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка создания ролей для клиента {ClientId} в STAGE", clientInternalId);
            throw;
        }
    }

    /// <summary>
    /// Назначает указанные realm роли service account пользователю указанного клиента в STAGE окружении.
    /// </summary>
    /// <param name="clientInternalId">Internal ID клиента (UUID), service account которого получает роли</param>
    /// <param name="roleNames">Список имен realm ролей для назначения</param>
    /// <param name="realm">Имя realm, в котором находится клиент</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <exception cref="ArgumentException">Если clientInternalId или realm пусты</exception>
    /// <exception cref="ArgumentNullException">Если roleNames равен null</exception>
    /// <exception cref="InvalidOperationException">Если service account не найден или не найдено ни одной роли для назначения</exception>
    /// <exception cref="HttpRequestException">При ошибках HTTP запроса при назначении ролей</exception>
    /// <remarks>
    /// <para>Метод выполняет следующие шаги:</para>
    /// <list type="number">
    /// <item><description>Получает service account пользователя для указанного клиента</description></item>
    /// <item><description>Параллельно получает информацию о всех запрошенных realm ролях</description></item>
    /// <item><description>Фильтрует только найденные роли (роли, которых нет, логируются как предупреждения)</description></item>
    /// <item><description>Назначает все найденные роли service account пользователю</description></item>
    /// </list>
    /// <para>Если ни одна из запрошенных ролей не найдена, выбрасывается InvalidOperationException.</para>
    /// </remarks>
    public async Task AssignRealmRolesToServiceAccountAsync(string clientInternalId, List<string> roleNames, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        ValidateParameter(clientInternalId, nameof(clientInternalId), MaxStringLength);
        ValidateParameter(realm, nameof(realm), MaxStringLength);
        
        if (roleNames == null)
            throw new ArgumentNullException(nameof(roleNames));
        
        // Валидация длины всех имен ролей
        foreach (var roleName in roleNames)
        {
            ValidateParameter(roleName, nameof(roleNames), MaxStringLength);
        }
        
        try
        {
            _logger.LogInformation("Назначение {Count} realm ролей service account клиента {ClientInternalId} в STAGE realm {Realm}", 
                roleNames.Count, clientInternalId, realm);
            
            // Получить ID service account пользователя
            var saUserEndpoint = $"admin/realms/{realm}/clients/{clientInternalId}/service-account-user";

            var saUser = await _httpClient.GetAsync<JsonElement>(saUserEndpoint, cancellationToken).ConfigureAwait(false);
            if (saUser.ValueKind == JsonValueKind.Undefined)
            {
                throw new InvalidOperationException("Service account user не найден");
            }

            if (!saUser.TryGetProperty("id", out var saUserIdProp))
            {
                throw new InvalidOperationException("Service account user не содержит 'id' property");
            }
            
            var saUserId = GetStringSafely(saUserIdProp);
            if (string.IsNullOrEmpty(saUserId))
            {
                throw new InvalidOperationException("Service account user содержит пустое значение 'id' property");
            }

            // Получить realm roles для назначения (параллельно с батчингом для оптимизации)
            const int batchSize = 20;
            var allRoles = new List<object>();
            
            for (int i = 0; i < roleNames.Count; i += batchSize)
            {
                var batch = roleNames.Skip(i).Take(batchSize);
                var roleTasks = batch.Select(async roleName =>
                {
                    try
                    {
                        var roleEndpoint = $"admin/realms/{UrlEncodeCached(realm)}/roles/{UrlEncodeCached(roleName)}";
                        var role = await _httpClient.GetAsync<JsonElement>(roleEndpoint, cancellationToken).ConfigureAwait(false);
                        
                        if (role.ValueKind != JsonValueKind.Undefined)
                        {
                            if (!role.TryGetProperty("id", out var idProp) || !role.TryGetProperty("name", out var nameProp))
                            {
                                _logger.LogWarning("Realm role {RoleName} не содержит обязательных полей 'id' или 'name'", roleName);
                                return null;
                            }
                            
                            var idValue = GetStringSafely(idProp);
                            var nameValue = GetStringSafely(nameProp);
                            
                            if (string.IsNullOrEmpty(idValue) || string.IsNullOrEmpty(nameValue))
                            {
                                _logger.LogWarning("Realm role {RoleName} содержит null или пустые значения для 'id' или 'name'", roleName);
                                return null;
                            }
                            
                            return new
                            {
                                id = idValue,
                                name = nameValue
                            } as object;
                        }
                        
                        _logger.LogDebug("Realm role {RoleName} не найдена в realm {Realm}", roleName, realm);
                        return null;
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Ошибка получения realm role {RoleName} из realm {Realm}", roleName, realm);
                        return null;
                    }
                });
                
                var batchResults = await Task.WhenAll(roleTasks).ConfigureAwait(false);
                allRoles.AddRange(batchResults.Where(r => r != null)!);
            }

            if (allRoles.Count == 0)
            {
                string roleNamesStr;
                try
                {
                    roleNamesStr = string.Join(", ", roleNames);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Ошибка форматирования списка ролей");
                    roleNamesStr = "не удалось получить список";
                }
                
                _logger.LogWarning("Не найдено ни одной realm роли для назначения service account {ClientId}. Запрошенные роли: {RoleNames}", 
                    clientInternalId, roleNamesStr);
                throw new InvalidOperationException($"Не найдено ни одной realm роли из запрошенных: {roleNamesStr}");
            }
            
            var roles = allRoles;

            var assignEndpoint = $"admin/realms/{UrlEncodeCached(realm)}/users/{saUserId}/role-mappings/realm";
            HttpResponseMessage? response = null;
            try
            {
                response = await _httpClient.PostAsync(assignEndpoint, roles, cancellationToken).ConfigureAwait(false);

                if (!response.IsSuccessStatusCode)
                {
                    string error = await ReadResponseContentSafelyAsync(response, cancellationToken, clientInternalId, "назначении realm roles");
                    
                    _logger.LogError("Ошибка назначения realm roles для service account {ClientId}: {StatusCode} - {Error}", 
                        clientInternalId, response.StatusCode, error);
                    throw new HttpRequestException($"Не удалось назначить realm roles: {response.StatusCode} - {error}");
                }
            }
            finally
            {
                response?.Dispose();
            }
            _logger.LogInformation("Назначено {Count} realm roles для service account клиента {ClientId} в STAGE", 
                roles.Count, clientInternalId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка назначения realm roles для service account {ClientId} в STAGE", clientInternalId);
            throw;
        }
    }

    /// <summary>
    /// Назначает указанные client роли от другого клиента (targetClient) service account пользователю указанного клиента в STAGE окружении.
    /// </summary>
    /// <param name="clientInternalId">Internal ID клиента (UUID), service account которого получает роли</param>
    /// <param name="targetClientId">ClientId клиента (не internal ID), от которого берутся роли</param>
    /// <param name="roleNames">Список имен client ролей для назначения</param>
    /// <param name="realm">Имя realm, в котором находятся клиенты</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <exception cref="ArgumentException">Если clientInternalId, targetClientId или realm пусты</exception>
    /// <exception cref="ArgumentNullException">Если roleNames равен null</exception>
    /// <exception cref="InvalidOperationException">Если service account не найден</exception>
    /// <exception cref="HttpRequestException">При ошибках HTTP запроса при назначении ролей</exception>
    /// <remarks>
    /// <para>Метод выполняет следующие шаги:</para>
    /// <list type="number">
    /// <item><description>Получает service account пользователя для указанного клиента</description></item>
    /// <item><description>Находит target клиент по ClientId и получает его internal ID</description></item>
    /// <item><description>Последовательно получает информацию о каждой запрошенной client роли</description></item>
    /// <item><description>Фильтрует только найденные роли (роли, которых нет, логируются как предупреждения)</description></item>
    /// <item><description>Назначает все найденные роли service account пользователю</description></item>
    /// </list>
    /// <para>Если target клиент не найден или ни одна из ролей не найдена, метод завершается без ошибок (логируется предупреждение).</para>
    /// </remarks>
    public async Task AssignClientRolesToServiceAccountAsync(string clientInternalId, string targetClientId, List<string> roleNames, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        ValidateParameter(clientInternalId, nameof(clientInternalId), MaxStringLength);
        ValidateParameter(targetClientId, nameof(targetClientId), MaxStringLength);
        ValidateParameter(realm, nameof(realm), MaxStringLength);
        
        if (roleNames == null)
            throw new ArgumentNullException(nameof(roleNames));
        
        // Валидация длины всех имен ролей
        foreach (var roleName in roleNames)
        {
            ValidateParameter(roleName, nameof(roleNames), MaxStringLength);
        }
        
        try
        {
            _logger.LogInformation("Назначение {Count} client ролей service account клиента {ClientInternalId} для клиента {TargetClientId} в STAGE realm {Realm}", 
                roleNames.Count, clientInternalId, targetClientId, realm);
            
            // Получить ID service account пользователя
            var saUserEndpoint = $"admin/realms/{realm}/clients/{clientInternalId}/service-account-user";

            var saUser = await _httpClient.GetAsync<JsonElement>(saUserEndpoint, cancellationToken).ConfigureAwait(false);
            if (saUser.ValueKind == JsonValueKind.Undefined)
            {
                throw new InvalidOperationException("Service account user не найден");
            }

            if (!saUser.TryGetProperty("id", out var saUserIdProp))
            {
                throw new InvalidOperationException("Service account user не содержит 'id' property");
            }
            
            var saUserId = GetStringSafely(saUserIdProp);
            if (string.IsNullOrEmpty(saUserId))
            {
                throw new InvalidOperationException("Service account user содержит пустое значение 'id' property");
            }

            // Найти target client internal ID
            var clientEndpoint = $"admin/realms/{UrlEncodeCached(realm)}/clients?clientId={UrlEncodeCached(targetClientId)}";
            
            var clients = await _httpClient.GetAsync<List<JsonElement>>(clientEndpoint, cancellationToken).ConfigureAwait(false);
            if (clients == null || !clients.Any())
            {
                _logger.LogWarning("Target client {TargetClientId} не найден в STAGE", targetClientId);
                return;
            }

            JsonElement matchingClient = default;
            foreach (var c in clients)
            {
                if (c.TryGetProperty("clientId", out var cid))
                {
                    var cidValue = GetStringSafely(cid);
                    if (StringEqualsSafely(cidValue, targetClientId, StringComparison.OrdinalIgnoreCase))
                    {
                        matchingClient = c;
                        break;
                    }
                }
            }

            if (matchingClient.ValueKind == JsonValueKind.Undefined)
            {
                if (clients.Count > 0)
                {
                    matchingClient = clients[0];
                }
                else
                {
                    _logger.LogWarning("Target client {TargetClientId} не найден в STAGE", targetClientId);
                    return;
                }
            }

            if (!matchingClient.TryGetProperty("id", out var targetIdProp))
            {
                _logger.LogWarning("Target client {TargetClientId} найден, но не содержит 'id' property", targetClientId);
                return;
            }
            
            var targetClientInternalId = GetStringSafely(targetIdProp);
            if (string.IsNullOrEmpty(targetClientInternalId))
            {
                _logger.LogWarning("Target client {TargetClientId} найден, но 'id' property пустое", targetClientId);
                return;
            }

            // Получить client roles для назначения
            var roles = new List<object>();
            foreach (var roleName in roleNames)
            {
                var roleEndpoint = $"admin/realms/{UrlEncodeCached(realm)}/clients/{targetClientInternalId}/roles/{UrlEncodeCached(roleName)}";

                var role = await _httpClient.GetAsync<JsonElement>(roleEndpoint, cancellationToken).ConfigureAwait(false);
                if (role.ValueKind != JsonValueKind.Undefined)
                {
                    if (!role.TryGetProperty("id", out var roleIdProp) || !role.TryGetProperty("name", out var roleNameProp))
                    {
                        _logger.LogWarning("Client role {RoleName} не содержит обязательных полей 'id' или 'name'", roleName);
                        continue;
                    }
                    
                    var roleId = GetStringSafely(roleIdProp);
                    var roleNameValue = GetStringSafely(roleNameProp);
                    
                    if (string.IsNullOrEmpty(roleId) || string.IsNullOrEmpty(roleNameValue))
                    {
                        _logger.LogWarning("Client role {RoleName} содержит пустые значения для 'id' или 'name'", roleName);
                        continue;
                    }
                    
                    roles.Add(new
                    {
                        id = roleId,
                        name = roleNameValue,
                        clientRole = true,
                        containerId = targetClientInternalId
                    });
                }
            }

            if (!roles.Any())
            {
                _logger.LogWarning("Не найдено ни одной client роли для назначения service account {ClientId}", clientInternalId);
                return;
            }

            var assignEndpoint = $"admin/realms/{UrlEncodeCached(realm)}/users/{saUserId}/role-mappings/clients/{targetClientInternalId}";
            HttpResponseMessage? response = null;
            try
            {
                response = await _httpClient.PostAsync(assignEndpoint, roles, cancellationToken).ConfigureAwait(false);

                if (response.IsSuccessStatusCode)
                {
                    _logger.LogInformation("Назначено {Count} client roles от {TargetClient} для service account {ClientId} в STAGE", 
                        roles.Count, targetClientId, clientInternalId);
                }
                else
                {
                    string error = await ReadResponseContentSafelyAsync(response, cancellationToken, clientInternalId, "назначении client roles");
                    
                    _logger.LogError("Ошибка назначения client roles для service account {ClientId}: {StatusCode} - {Error}", 
                        clientInternalId, response.StatusCode, error);
                    throw new HttpRequestException($"Не удалось назначить client roles: {response.StatusCode} - {error}");
                }
            }
            finally
            {
                response?.Dispose();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка назначения client roles для service account {ClientId} в STAGE", clientInternalId);
            throw;
        }
    }

    /// <summary>
    /// Проверяет существование client scope с указанным именем в указанном realm STAGE окружения.
    /// </summary>
    /// <param name="scopeName">Имя client scope для проверки</param>
    /// <param name="realm">Имя realm для проверки</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>true, если scope существует, иначе false. Возвращает false при ошибках (ошибки логируются).</returns>
    /// <exception cref="ArgumentException">Если scopeName или realm пусты или содержат только пробелы</exception>
    /// <remarks>
    /// Метод получает список всех client scopes в realm и проверяет наличие scope с указанным именем (без учета регистра).
    /// HttpRequestException обрабатываются как "scope не найден" и возвращают false.
    /// </remarks>
    public async Task<bool> ClientScopeExistsAsync(string scopeName, string realm, CancellationToken cancellationToken = default)
    {
        ValidateParameter(scopeName, nameof(scopeName), MaxStringLength);
        ValidateParameter(realm, nameof(realm), MaxStringLength);
        
        try
        {
            var endpoint = $"admin/realms/{realm}/client-scopes";

            var scopes = await _httpClient.GetAsync<List<JsonElement>>(endpoint, cancellationToken).ConfigureAwait(false);
            
            if (scopes == null)
                return false;

            foreach (var s in scopes)
            {
                if (s.TryGetProperty("name", out var nameProp))
                {
                    var nameValue = GetStringSafely(nameProp);
                    if (StringEqualsSafely(nameValue, scopeName, StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogDebug(ex, "Client scope {ScopeName} не найден в realm {Realm}", scopeName, realm);
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка проверки существования client scope {ScopeName} в realm {Realm}", scopeName, realm);
            return false;
        }
    }

    /// <summary>
    /// Проверяет существование authentication flow с указанным алиасом в указанном realm STAGE окружения.
    /// </summary>
    /// <param name="flowAlias">Алиас authentication flow для проверки</param>
    /// <param name="realm">Имя realm для проверки</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>true, если flow существует, иначе false. Возвращает false при ошибках (ошибки логируются).</returns>
    /// <exception cref="ArgumentException">Если flowAlias или realm пусты или содержат только пробелы</exception>
    /// <remarks>
    /// Метод получает список всех authentication flows в realm и проверяет наличие flow с указанным алиасом (без учета регистра).
    /// HttpRequestException обрабатываются как "flow не найден" и возвращают false.
    /// </remarks>
    public async Task<bool> AuthenticationFlowExistsAsync(string flowAlias, string realm, CancellationToken cancellationToken = default)
    {
        ValidateParameter(flowAlias, nameof(flowAlias), MaxStringLength);
        ValidateParameter(realm, nameof(realm), MaxStringLength);
        
        try
        {
            var endpoint = $"admin/realms/{realm}/authentication/flows";

            var flows = await _httpClient.GetAsync<List<JsonElement>>(endpoint, cancellationToken).ConfigureAwait(false);
            
            if (flows == null)
                return false;

            foreach (var f in flows)
            {
                if (f.TryGetProperty("alias", out var aliasProp))
                {
                    var aliasValue = GetStringSafely(aliasProp);
                    if (StringEqualsSafely(aliasValue, flowAlias, StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogDebug(ex, "Authentication flow {FlowAlias} не найден в realm {Realm}", flowAlias, realm);
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка проверки существования authentication flow {FlowAlias} в realm {Realm}", flowAlias, realm);
            return false;
        }
    }

    /// <summary>
    /// Копирует protocol mappers в указанный клиент в STAGE окружении.
    /// </summary>
    /// <param name="clientInternalId">Internal ID клиента (UUID), в который копируются mappers</param>
    /// <param name="mappers">Список protocol mappers для копирования (JsonElement объектов)</param>
    /// <param name="realm">Имя realm, в котором находится клиент</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <exception cref="ArgumentException">Если clientInternalId или realm пусты</exception>
    /// <exception cref="ArgumentNullException">Если mappers равен null</exception>
    /// <remarks>
    /// <para>Метод обрабатывает mappers последовательно:</para>
    /// <list type="bullet">
    /// <item><description>Пропускает mappers с неверным типом (не объекты)</description></item>
    /// <item><description>Успешно созданные mappers логируются</description></item>
    /// <item><description>Конфликты (уже существующие mappers) игнорируются</description></item>
    /// <item><description>Другие ошибки логируются как предупреждения</description></item>
    /// </list>
    /// <para>Метод не выбрасывает исключения при ошибках - все ошибки логируются, но выполнение продолжается.</para>
    /// <para>Это связано с тем, что protocol mappers не являются критичными для работы клиента.</para>
    /// </remarks>
    public async Task CopyProtocolMappersAsync(string clientInternalId, List<JsonElement> mappers, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        ValidateParameter(clientInternalId, nameof(clientInternalId), MaxStringLength);
        ValidateParameter(realm, nameof(realm), MaxStringLength);
        
        if (mappers == null)
        {
            throw new ArgumentNullException(nameof(mappers));
        }
        
        try
        {
            var endpoint = $"admin/realms/{realm}/clients/{clientInternalId}/protocol-mappers/models";

            foreach (var mapper in mappers)
            {
                if (mapper.ValueKind != JsonValueKind.Object)
                {
                    _logger.LogWarning("Protocol mapper имеет неверный тип: {ValueKind}", mapper.ValueKind);
                    continue;
                }
                
                using var response = await _httpClient.PostAsync(endpoint, mapper, cancellationToken).ConfigureAwait(false);
                
                if (response.IsSuccessStatusCode)
                {
                    _logger.LogDebug("Protocol mapper скопирован для клиента {ClientId} в STAGE", clientInternalId);
                }
                else if (response.StatusCode != System.Net.HttpStatusCode.Conflict)
                {
                    var statusCode = (int)response.StatusCode;
                    _logger.LogWarning("Не удалось скопировать protocol mapper для {ClientId}: {StatusCode}", 
                        clientInternalId, statusCode);
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка копирования protocol mappers для клиента {ClientId} в STAGE", clientInternalId);
            // Не бросаем исключение - mappers не критичны
        }
    }

    /// <summary>
    /// Назначает указанные client scopes указанному клиенту в STAGE окружении как default или optional scopes.
    /// </summary>
    /// <param name="clientInternalId">Internal ID клиента (UUID), которому назначаются scopes</param>
    /// <param name="scopeNames">Список имен client scopes для назначения</param>
    /// <param name="realm">Имя realm, в котором находится клиент</param>
    /// <param name="isDefault">Если true, scopes назначаются как default, иначе как optional</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <exception cref="ArgumentException">Если clientInternalId или realm пусты</exception>
    /// <exception cref="ArgumentNullException">Если scopeNames равен null</exception>
    /// <remarks>
    /// <para>Метод выполняет следующие шаги:</para>
    /// <list type="number">
    /// <item><description>Получает список всех доступных client scopes в realm</description></item>
    /// <item><description>Для каждого запрошенного scope находит соответствующий scope по имени (без учета регистра)</description></item>
    /// <item><description>Назначает найденные scopes клиенту как default или optional (в зависимости от параметра isDefault)</description></item>
    /// </list>
    /// <para>Scopes, которые не найдены, логируются как предупреждения и пропускаются.</para>
    /// <para>Пустой список scopeNames не приводит к ошибке - метод просто завершается без действий.</para>
    /// <para>Метод не выбрасывает исключения при ошибках - все ошибки логируются, но выполнение продолжается.</para>
    /// <para>Это связано с тем, что client scopes не являются критичными для работы клиента.</para>
    /// </remarks>
    public async Task AssignClientScopesAsync(string clientInternalId, List<string> scopeNames, string realm, bool isDefault, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        ValidateParameter(clientInternalId, nameof(clientInternalId), MaxStringLength);
        ValidateParameter(realm, nameof(realm), MaxStringLength);
        
        if (scopeNames == null)
        {
            throw new ArgumentNullException(nameof(scopeNames));
        }
        
        if (scopeNames.Count == 0)
        {
            _logger.LogDebug("Пустой список scopeNames для клиента {ClientId}", clientInternalId);
            return;
        }
        
        // Валидация длины всех имен scopes
        foreach (var scopeName in scopeNames)
        {
            ValidateParameter(scopeName, nameof(scopeNames), MaxStringLength);
        }
        
        try
        {
            // Получить все доступные scopes
            var scopesEndpoint = $"admin/realms/{realm}/client-scopes";

            var allScopes = await _httpClient.GetAsync<List<JsonElement>>(scopesEndpoint, cancellationToken).ConfigureAwait(false);
            
            if (allScopes == null)
                return;

            // Оптимизация: создаем Dictionary для быстрого поиска
            var scopeDict = new Dictionary<string, JsonElement>(StringComparer.OrdinalIgnoreCase);
            foreach (var scope in allScopes)
            {
                if (scope.TryGetProperty("name", out var nameProp))
                {
                    var nameValue = GetStringSafely(nameProp);
                    if (!string.IsNullOrEmpty(nameValue))
                    {
                        scopeDict[nameValue] = scope;
                    }
                }
            }
            
            foreach (var scopeName in scopeNames)
            {
                if (!scopeDict.TryGetValue(scopeName, out var scope))
                {
                    _logger.LogWarning("Client scope {ScopeName} не найден в STAGE", scopeName);
                    continue;
                }

                if (!scope.TryGetProperty("id", out var idProp))
                {
                    _logger.LogWarning("Client scope {ScopeName} найден, но не содержит 'id' property", scopeName);
                    continue;
                }
                
                var scopeId = GetStringSafely(idProp);
                if (string.IsNullOrEmpty(scopeId))
                {
                    _logger.LogWarning("Client scope {ScopeName} найден, но 'id' property пустое", scopeName);
                    continue;
                }
                var assignType = isDefault ? "default-client-scopes" : "optional-client-scopes";
                
                var assignEndpoint = $"admin/realms/{UrlEncodeCached(realm)}/clients/{clientInternalId}/{assignType}/{scopeId}";

                HttpResponseMessage? response = null;
                try
                {
                    response = await _httpClient.PutAsync(assignEndpoint, new { }, cancellationToken).ConfigureAwait(false);
                    
                    if (response.IsSuccessStatusCode)
                    {
                        _logger.LogDebug("Client scope {ScopeName} назначен клиенту {ClientId} в STAGE ({Type})", 
                            scopeName, clientInternalId, isDefault ? "default" : "optional");
                    }
                }
                finally
                {
                    response?.Dispose();
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка назначения client scopes для клиента {ClientId} в STAGE", clientInternalId);
            // Не бросаем исключение - scopes не критичны
        }
    }

    /// <summary>
    /// Удаляет клиента из указанного realm STAGE окружения по его internal ID.
    /// </summary>
    /// <param name="clientInternalId">Internal ID клиента (UUID) для удаления</param>
    /// <param name="realm">Имя realm, в котором находится клиент</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <exception cref="ArgumentException">Если clientInternalId или realm пусты</exception>
    /// <exception cref="HttpRequestException">При ошибках HTTP запроса (ошибки удаления клиента)</exception>
    /// <remarks>
    /// Метод выполняет DELETE запрос к Keycloak Admin API для удаления клиента.
    /// Если клиент не найден (404), метод не выбрасывает исключение, а только логирует предупреждение.
    /// </remarks>
    public async Task DeleteClientAsync(string clientInternalId, string realm, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        ValidateParameter(clientInternalId, nameof(clientInternalId), MaxStringLength);
        ValidateParameter(realm, nameof(realm), MaxStringLength);
        
        try
        {
            _logger.LogInformation("Удаление клиента {ClientInternalId} из STAGE realm {Realm}", clientInternalId, realm);
            
            var endpoint = $"admin/realms/{realm}/clients/{clientInternalId}";

            using var response = await _httpClient.DeleteAsync(endpoint, cancellationToken).ConfigureAwait(false);
            
            if (response.IsSuccessStatusCode)
            {
                _logger.LogInformation("Клиент {ClientInternalId} успешно удален из STAGE realm {Realm}", clientInternalId, realm);
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                _logger.LogWarning("Клиент {ClientInternalId} не найден в STAGE realm {Realm} для удаления", clientInternalId, realm);
                // Не выбрасываем исключение, так как клиент уже не существует
            }
            else
            {
                string error = await ReadResponseContentSafelyAsync(response, cancellationToken, clientInternalId, "удалении клиента");
                
                _logger.LogError("Ошибка удаления клиента {ClientInternalId} из STAGE realm {Realm}: {StatusCode} - {Error}", 
                    clientInternalId, realm, response.StatusCode, error);
                
                var httpEx = new HttpRequestException($"Ошибка удаления клиента в STAGE: {response.StatusCode} - {error}");
                httpEx.Data["StatusCode"] = response.StatusCode;
                httpEx.Data["Realm"] = realm;
                httpEx.Data["ClientInternalId"] = clientInternalId;
                throw httpEx;
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка удаления клиента {ClientInternalId} из STAGE realm {Realm}", clientInternalId, realm);
            throw;
        }
    }
    
    // Вспомогательные методы для валидации и безопасной обработки
    
    /// <summary>
    /// Валидирует параметр на null, пустоту и максимальную длину.
    /// </summary>
    private static void ValidateParameter(string? value, string paramName, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new ArgumentException($"{paramName} не может быть пустым", paramName);
        }
        
        if (value.Length > maxLength)
        {
            throw new ArgumentException($"{paramName} превышает максимальную длину {maxLength} символов", paramName);
        }
    }
    
    /// <summary>
    /// Безопасно получает строку из JsonElement с обработкой исключений.
    /// </summary>
    private static string? GetStringSafely(JsonElement element)
    {
        try
        {
            return element.GetString();
        }
        catch
        {
            return null;
        }
    }
    
    /// <summary>
    /// Безопасно обрезает строку с обработкой исключений.
    /// </summary>
    private static string? SafeTrim(string? value)
    {
        if (value == null)
            return null;
        
        try
        {
            return value.Trim();
        }
        catch
        {
            return value;
        }
    }
    
    /// <summary>
    /// Безопасно обрезает конец строки с указанным символом.
    /// </summary>
    private static string SafeTrimEnd(string value, char trimChar)
    {
        if (string.IsNullOrEmpty(value))
            return value;
        
        try
        {
            return value.TrimEnd(trimChar);
        }
        catch
        {
            return value;
        }
    }
    
    /// <summary>
    /// Безопасно сравнивает строки с обработкой исключений.
    /// </summary>
    private static bool StringEqualsSafely(string? str1, string? str2, StringComparison comparison)
    {
        if (str1 == null && str2 == null)
            return true;
        
        if (str1 == null || str2 == null)
            return false;
        
        try
        {
            return string.Equals(str1, str2, comparison);
        }
        catch
        {
            return false;
        }
    }
    
    /// <summary>
    /// Кэширует результат URL encoding для оптимизации производительности.
    /// </summary>
    private static string UrlEncodeCached(string value)
    {
        if (string.IsNullOrEmpty(value))
            return value;
        
        // Для коротких строк кэширование может быть избыточным, но для длинных - полезно
        if (value.Length > 100)
        {
            return UrlEncodeCache.GetOrAdd(value, v => WebUtility.UrlEncode(v));
        }
        
        return WebUtility.UrlEncode(value);
    }
    
    /// <summary>
    /// Безопасно читает содержимое ответа с обработкой исключений.
    /// </summary>
    private async Task<string> ReadResponseContentSafelyAsync(
        HttpResponseMessage response, 
        CancellationToken cancellationToken, 
        string contextId, 
        string operation)
    {
        try
        {
            return await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось прочитать содержимое ошибки при {Operation} для {ContextId}", operation, contextId);
            return $"Unable to read error content: {ex.Message}";
        }
    }
}

