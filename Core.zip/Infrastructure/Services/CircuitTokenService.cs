using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components.Server.Circuits;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для хранения и обновления токенов в рамках Blazor Circuit
/// </summary>
public class CircuitTokenService : CircuitHandler, ITokenRefreshService, IDisposable
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IConfiguration _configuration;
    private readonly ILogger<CircuitTokenService> _logger;
    private readonly IDataProtector _dataProtector;
    private readonly ConcurrentDictionary<string, TokenInfo> _circuitTokens = new();
    private readonly ConcurrentDictionary<string, SemaphoreSlim> _refreshSemaphores = new();
    
    // Используем AsyncLocal для потокобезопасного хранения circuit ID в контексте выполнения
    // Примечание: AsyncLocal - правильный подход для CircuitHandler в Blazor Server,
    // так как Circuit ID связан с контекстом выполнения, а не с HTTP контекстом.
    // AsyncLocal сохраняет значение в контексте выполнения и автоматически передается
    // через async/await границы в рамках одного Circuit.
    private static readonly AsyncLocal<string?> _currentCircuitId = new();
    
    // Статический экземпляр JwtSecurityTokenHandler для переиспользования
    private static readonly JwtSecurityTokenHandler _tokenHandler = new();
    
    // Таймаут для HTTP запросов (настраивается через конфигурацию)
    private readonly TimeSpan _httpClientTimeout;
    
    // Параметры retry логики (настраиваются через конфигурацию)
    private readonly int _maxRetries;
    private readonly TimeSpan _initialRetryDelay;
    private readonly TimeSpan _maxRetryDuration;
    
    // Время кэширования результата проверки истечения токена (настраивается через конфигурацию)
    private readonly TimeSpan _expirationCheckCacheDuration;
    
    // Запас времени для проверки истечения токена (настраивается через конфигурацию)
    private readonly int _tokenExpirationBufferSeconds;
    
    // Параметры для периодической очистки старых токенов
    private readonly TimeSpan _tokenMaxAge;
    private readonly TimeSpan _cleanupInterval;
    private Timer? _cleanupTimer;
    
    // Ограничение на количество токенов в памяти (LRU политика)
    private readonly int _maxTokensInMemory;
    private readonly object _metricsLock = new object();
    
    // Метрики (защищены lock для атомарного чтения)
    private long _tokenRefreshCount = 0;
    private long _tokenRefreshSuccesses = 0;
    private long _tokenRefreshFailures = 0;
    private long _activeTokensCount = 0;
    
    // Кэшированные скомпилированные Regex для санитизации
    private static readonly Regex _refreshTokenRegex = new Regex(@"""refresh_token""\s*:\s*""[^""]+""", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex _accessTokenRegex = new Regex(@"""access_token""\s*:\s*""[^""]+""", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex _clientSecretRegex = new Regex(@"""client_secret""\s*:\s*""[^""]+""", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    
    // Флаг для отслеживания состояния Dispose (volatile для потокобезопасности)
    private volatile bool _disposed = false;

    public CircuitTokenService(
        IHttpClientFactory httpClientFactory,
        IConfiguration configuration,
        ILogger<CircuitTokenService> logger,
        IDataProtectionProvider dataProtectionProvider)
    {
        _httpClientFactory = httpClientFactory ?? throw new ArgumentNullException(nameof(httpClientFactory));
        _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _dataProtector = dataProtectionProvider?.CreateProtector("CircuitTokenService.Tokens") 
            ?? throw new ArgumentNullException(nameof(dataProtectionProvider));
        
        // Получаем таймаут HTTP клиента из конфигурации (по умолчанию 30 секунд)
        var httpClientTimeoutSeconds = configuration.GetValue<int>(
            "TokenRefresh:HttpClientTimeoutSeconds",
            defaultValue: 30);
        _httpClientTimeout = TimeSpan.FromSeconds(httpClientTimeoutSeconds);
        
        // Получаем запас времени из конфигурации (по умолчанию 30 секунд)
        _tokenExpirationBufferSeconds = configuration.GetValue<int>(
            "TokenRefresh:ExpirationBufferSeconds", 
            defaultValue: 30);
        
        // Получаем параметры retry логики из конфигурации
        _maxRetries = configuration.GetValue<int>(
            "TokenRefresh:MaxRetries",
            defaultValue: 3);
        var initialRetryDelaySeconds = configuration.GetValue<int>(
            "TokenRefresh:InitialRetryDelaySeconds",
            defaultValue: 1);
        _initialRetryDelay = TimeSpan.FromSeconds(initialRetryDelaySeconds);
        
        // Максимальное время для всех попыток retry (по умолчанию 5 минут)
        var maxRetryDurationMinutes = configuration.GetValue<int>(
            "TokenRefresh:MaxRetryDurationMinutes",
            defaultValue: 5);
        _maxRetryDuration = TimeSpan.FromMinutes(maxRetryDurationMinutes);
        
        // Получаем время кэширования проверки истечения (по умолчанию 30 секунд)
        var cacheDurationSeconds = configuration.GetValue<int>(
            "TokenRefresh:ExpirationCheckCacheDurationSeconds",
            defaultValue: 30);
        _expirationCheckCacheDuration = TimeSpan.FromSeconds(cacheDurationSeconds);
        
        // Параметры периодической очистки старых токенов
        var tokenMaxAgeHours = configuration.GetValue<int>(
            "TokenRefresh:TokenMaxAgeHours",
            defaultValue: 24);
        _tokenMaxAge = TimeSpan.FromHours(tokenMaxAgeHours);
        
        var cleanupIntervalHours = configuration.GetValue<int>(
            "TokenRefresh:CleanupIntervalHours",
            defaultValue: 1);
        _cleanupInterval = TimeSpan.FromHours(cleanupIntervalHours);
        
        // Ограничение на количество токенов в памяти (по умолчанию 1000)
        _maxTokensInMemory = configuration.GetValue<int>(
            "TokenRefresh:MaxTokensInMemory",
            defaultValue: 1000);
        
        // Проверяем конфигурацию при инициализации
        ValidateConfiguration();
        
        // Запускаем периодическую очистку старых токенов
        StartCleanupTimer();
    }
    
    /// <summary>
    /// Запускает таймер для периодической очистки старых токенов
    /// </summary>
    private void StartCleanupTimer()
    {
        if (_cleanupInterval <= TimeSpan.Zero)
        {
            _logger.LogDebug("Периодическая очистка токенов отключена");
            return;
        }
        
        try
        {
            _cleanupTimer = new Timer(CleanupExpiredTokens, null, _cleanupInterval, _cleanupInterval);
            _logger.LogDebug(
                "Запущена периодическая очистка токенов. Интервал: {CleanupInterval}, Максимальный возраст токена: {TokenMaxAge}",
                _cleanupInterval, _tokenMaxAge);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при создании таймера очистки токенов");
            throw;
        }
    }
    
    /// <summary>
    /// Очищает старые токены, которые не использовались длительное время
    /// </summary>
    private void CleanupExpiredTokens(object? state)
    {
        if (_disposed)
        {
            return;
        }
        
        try
        {
            var now = DateTimeOffset.UtcNow;
            var cutoffTime = now - _tokenMaxAge;
            var removedCount = 0;
            var removedCircuitIds = new List<string>();
            
            // Оптимизированная итерация: используем батчинг вместо ToArray()
            const int batchSize = 100;
            var keysToCheck = new List<string>(batchSize);
            
            foreach (var kvp in _circuitTokens)
            {
                if (kvp.Value.StoredAt < cutoffTime)
                {
                    keysToCheck.Add(kvp.Key);
                    
                    if (keysToCheck.Count >= batchSize)
                    {
                        ProcessCleanupBatch(keysToCheck, ref removedCount, removedCircuitIds);
                        keysToCheck.Clear();
                    }
                }
            }
            
            // Обрабатываем оставшиеся ключи
            if (keysToCheck.Count > 0)
            {
                ProcessCleanupBatch(keysToCheck, ref removedCount, removedCircuitIds);
            }
            
            // Очищаем семафоры для удалённых circuits
            CleanupSemaphores(removedCircuitIds);
            
            // Проверяем ограничение на количество токенов и удаляем старые при необходимости
            EnforceMaxTokensLimit();
            
            if (removedCount > 0)
            {
                _logger.LogInformation(
                    "Очищено {RemovedCount} старых токенов (старше {TokenMaxAge})",
                    removedCount, _tokenMaxAge);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при периодической очистке токенов");
        }
    }
    
    /// <summary>
    /// Обрабатывает батч ключей для очистки
    /// </summary>
    private void ProcessCleanupBatch(List<string> keysToCheck, ref int removedCount, List<string> removedCircuitIds)
    {
        foreach (var circuitId in keysToCheck)
        {
            if (_circuitTokens.TryRemove(circuitId, out var tokenInfo))
            {
                // Очищаем зашифрованные токены напрямую
                tokenInfo.ClearEncryptedTokens();
                removedCircuitIds.Add(circuitId);
                removedCount++;
                Interlocked.Decrement(ref _activeTokensCount);
            }
        }
    }
    
    /// <summary>
    /// Очищает семафоры для удалённых circuits
    /// </summary>
    private void CleanupSemaphores(List<string> removedCircuitIds)
    {
        foreach (var circuitId in removedCircuitIds)
        {
            // Используем более безопасный механизм: проверяем, не используется ли семафор
            if (_refreshSemaphores.TryRemove(circuitId, out var semaphore))
            {
                try
                {
                    // Проверяем, не используется ли семафор в данный момент
                    if (semaphore.CurrentCount == 1)
                    {
                        semaphore.Dispose();
                    }
                    else
                    {
                        // Если семафор используется, возвращаем его обратно и отложим очистку
                        _refreshSemaphores.TryAdd(circuitId, semaphore);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Ошибка при освобождении семафора для Circuit {CircuitId} при очистке", circuitId);
                }
            }
        }
    }
    
    /// <summary>
    /// Применяет ограничение на максимальное количество токенов (LRU политика)
    /// </summary>
    private void EnforceMaxTokensLimit()
    {
        var currentCount = _circuitTokens.Count;
        if (currentCount <= _maxTokensInMemory)
        {
            return;
        }
        
        var toRemove = currentCount - _maxTokensInMemory;
        var removedCount = 0;
        
        // Сортируем по времени последнего использования (StoredAt) и удаляем самые старые
        var sortedTokens = _circuitTokens
            .OrderBy(kvp => kvp.Value.StoredAt)
            .Take(toRemove)
            .ToList();
        
        foreach (var kvp in sortedTokens)
        {
            if (_circuitTokens.TryRemove(kvp.Key, out var tokenInfo))
            {
                tokenInfo.ClearEncryptedTokens();
                removedCount++;
                Interlocked.Decrement(ref _activeTokensCount);
            }
        }
        
        if (removedCount > 0)
        {
            _logger.LogInformation(
                "Удалено {RemovedCount} токенов для соблюдения ограничения MaxTokensInMemory ({MaxTokens})",
                removedCount, _maxTokensInMemory);
        }
    }
    
    /// <summary>
    /// Проверяет корректность конфигурации Keycloak
    /// </summary>
    private void ValidateConfiguration()
    {
        var authority = _configuration["Authentication:Keycloak:Authority"];
        var clientId = _configuration["Authentication:Keycloak:ClientId"];
        
        if (string.IsNullOrEmpty(authority))
        {
            throw new InvalidOperationException(
                "Не указан Authentication:Keycloak:Authority в конфигурации");
        }
        
        if (string.IsNullOrEmpty(clientId))
        {
            throw new InvalidOperationException(
                "Не указан Authentication:Keycloak:ClientId в конфигурации");
        }
        
        if (!Uri.TryCreate(authority, UriKind.Absolute, out _))
        {
            throw new InvalidOperationException(
                $"Некорректный формат Authority: {authority}");
        }
        
        if (_tokenExpirationBufferSeconds < 0)
        {
            throw new InvalidOperationException(
                $"TokenRefresh:ExpirationBufferSeconds не может быть отрицательным. Текущее значение: {_tokenExpirationBufferSeconds}");
        }
        
        if (_maxRetries < 1)
        {
            throw new InvalidOperationException(
                $"TokenRefresh:MaxRetries должен быть >= 1. Текущее значение: {_maxRetries}");
        }
        
        if (_initialRetryDelay <= TimeSpan.Zero)
        {
            throw new InvalidOperationException(
                $"TokenRefresh:InitialRetryDelaySeconds должен быть > 0. Текущее значение: {_initialRetryDelay.TotalSeconds}");
        }
        
        if (_expirationCheckCacheDuration <= TimeSpan.Zero)
        {
            throw new InvalidOperationException(
                $"TokenRefresh:ExpirationCheckCacheDurationSeconds должен быть > 0. Текущее значение: {_expirationCheckCacheDuration.TotalSeconds}");
        }
        
        if (_maxRetryDuration <= TimeSpan.Zero)
        {
            throw new InvalidOperationException(
                $"TokenRefresh:MaxRetryDurationMinutes должен быть > 0. Текущее значение: {_maxRetryDuration.TotalMinutes}");
        }
        
        if (_maxTokensInMemory < 1)
        {
            throw new InvalidOperationException(
                $"TokenRefresh:MaxTokensInMemory должен быть >= 1. Текущее значение: {_maxTokensInMemory}");
        }
        
        if (_httpClientTimeout <= TimeSpan.Zero)
        {
            throw new InvalidOperationException(
                $"TokenRefresh:HttpClientTimeoutSeconds должен быть > 0. Текущее значение: {_httpClientTimeout.TotalSeconds}");
        }
        
        _logger.LogDebug(
            "CircuitTokenService инициализирован с параметрами: Authority={Authority}, ClientId={ClientId}, " +
            "ExpirationBufferSeconds={ExpirationBufferSeconds}, MaxRetries={MaxRetries}, " +
            "InitialRetryDelay={InitialRetryDelay}, MaxRetryDuration={MaxRetryDuration}, " +
            "ExpirationCheckCacheDuration={ExpirationCheckCacheDuration}, HttpClientTimeout={HttpClientTimeout}, " +
            "MaxTokensInMemory={MaxTokensInMemory}",
            authority, clientId, _tokenExpirationBufferSeconds, _maxRetries, _initialRetryDelay, 
            _maxRetryDuration, _expirationCheckCacheDuration, _httpClientTimeout, _maxTokensInMemory);
    }

    public override Task OnCircuitOpenedAsync(Circuit circuit, CancellationToken cancellationToken)
    {
        _currentCircuitId.Value = circuit.Id;
        return base.OnCircuitOpenedAsync(circuit, cancellationToken);
    }

    public override Task OnCircuitClosedAsync(Circuit circuit, CancellationToken cancellationToken)
    {
        if (_circuitTokens.TryRemove(circuit.Id, out var tokenInfo))
        {
            // Очищаем зашифрованные токены напрямую
            tokenInfo.ClearEncryptedTokens();
            Interlocked.Decrement(ref _activeTokensCount);
        }
        
        // Очищаем семафор для этого circuit
        if (_refreshSemaphores.TryRemove(circuit.Id, out var semaphore))
        {
            try
            {
                // Проверяем, не используется ли семафор в данный момент
                if (semaphore.CurrentCount == 1)
                {
                    semaphore.Dispose();
                }
                else
                {
                    // Если семафор используется, отложим очистку
                    _logger.LogWarning("Семафор для Circuit {CircuitId} все еще используется, очистка отложена", circuit.Id);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при освобождении семафора для Circuit {CircuitId}", circuit.Id);
            }
        }
        
        return base.OnCircuitClosedAsync(circuit, cancellationToken);
    }

    public override Task OnConnectionUpAsync(Circuit circuit, CancellationToken cancellationToken)
    {
        _currentCircuitId.Value = circuit.Id;
        return base.OnConnectionUpAsync(circuit, cancellationToken);
    }

    public override Task OnConnectionDownAsync(Circuit circuit, CancellationToken cancellationToken)
    {
        // При разрыве соединения не очищаем _currentCircuitId - он останется для повторного подключения
        return base.OnConnectionDownAsync(circuit, cancellationToken);
    }

    /// <summary>
    /// Сохранить токены для текущего circuit
    /// </summary>
    public void StoreTokens(string accessToken, string? refreshToken)
    {
        if (_disposed)
        {
            throw new ObjectDisposedException(nameof(CircuitTokenService));
        }
        
        // Валидация access token
        if (string.IsNullOrWhiteSpace(accessToken))
        {
            _logger.LogError("Попытка сохранить пустой access token");
            throw new ArgumentException("Access token не может быть пустым", nameof(accessToken));
        }

        if (!IsValidJwtToken(accessToken))
        {
            _logger.LogError("Попытка сохранить некорректный JWT токен");
            throw new ArgumentException("Access token имеет некорректный формат", nameof(accessToken));
        }

        var circuitId = _currentCircuitId.Value;
        if (string.IsNullOrEmpty(circuitId))
        {
            _logger.LogWarning("Нет активного Circuit ID для сохранения токенов");
            return;
        }

        var tokenInfo = new TokenInfo(_dataProtector)
        {
            AccessToken = accessToken,
            RefreshToken = refreshToken,
            StoredAt = DateTimeOffset.UtcNow
        };

        // Проверяем ограничение на количество токенов перед добавлением
        if (_circuitTokens.Count >= _maxTokensInMemory && !_circuitTokens.ContainsKey(circuitId))
        {
            EnforceMaxTokensLimit();
        }

        var wasNew = !_circuitTokens.ContainsKey(circuitId);
        _circuitTokens[circuitId] = tokenInfo;
        
        if (wasNew)
        {
            Interlocked.Increment(ref _activeTokensCount);
        }
    }

    /// <summary>
    /// Получить актуальный access token (обновит если истёк)
    /// </summary>
    public async Task<string?> GetValidAccessTokenAsync(CancellationToken cancellationToken = default)
    {
        if (_disposed)
        {
            throw new ObjectDisposedException(nameof(CircuitTokenService));
        }
        
        var circuitId = _currentCircuitId.Value;
        if (string.IsNullOrEmpty(circuitId))
        {
            _logger.LogWarning("Нет активного Circuit ID");
            return null;
        }

            if (!_circuitTokens.TryGetValue(circuitId, out var tokenInfo))
            {
                _logger.LogWarning("Токены не найдены для Circuit {CircuitId}", circuitId);
                return null;
            }
            
            // Получаем access token с обработкой ошибок расшифровки
            string? accessToken = SafeGetAccessToken(tokenInfo, circuitId);
            if (accessToken == null)
            {
                return null;
            }
            
            // Проверяем срок действия с учётом кэширования
            if (IsTokenExpired(accessToken, tokenInfo))
        {
            // Получаем refresh token с обработкой ошибок расшифровки
            string? refreshToken = SafeGetRefreshToken(tokenInfo, circuitId);
            if (refreshToken == null && tokenInfo.HasEncryptedRefreshToken)
            {
                // Если refresh token не удалось расшифровать, удаляем токены
                _circuitTokens.TryRemove(circuitId, out _);
                Interlocked.Decrement(ref _activeTokensCount);
                return null;
            }
            
            // Проверяем, есть ли refresh token
            if (string.IsNullOrEmpty(refreshToken))
            {
                _logger.LogWarning(
                    "Access token истёк, но refresh token отсутствует для Circuit {CircuitId}. " +
                    "Очищаем токены, так как восстановление невозможно.", 
                    circuitId);
                _circuitTokens.TryRemove(circuitId, out _);
                Interlocked.Decrement(ref _activeTokensCount);
                return null;
            }
            
            // Проверяем, не истёк ли refresh token
            // Примечание: refresh token может быть непрозрачным (не JWT), 
            // поэтому проверяем только если это JWT токен
            if (IsRefreshTokenExpired(refreshToken))
            {
                _logger.LogWarning(
                    "Refresh token также истёк для Circuit {CircuitId}. Очищаем токены.", 
                    circuitId);
                _circuitTokens.TryRemove(circuitId, out _);
                Interlocked.Decrement(ref _activeTokensCount);
                return null;
            }
            
            var refreshed = await RefreshTokenAsync(tokenInfo, circuitId, cancellationToken);
            if (!refreshed)
            {
                _logger.LogError("Не удалось обновить токен для Circuit {CircuitId}", circuitId);
                // Не очищаем токены сразу - может быть временная ошибка сети
                return null;
            }

            // Получаем обновлённый токен
            if (!_circuitTokens.TryGetValue(circuitId, out tokenInfo))
            {
                return null;
            }
            
            // Получаем обновлённый access token с обработкой ошибок
            accessToken = SafeGetAccessToken(tokenInfo, circuitId);
            if (accessToken == null)
            {
                return null;
            }
        }

        return accessToken;
    }

    /// <summary>
    /// Безопасно получает access token с обработкой ошибок расшифровки и логированием
    /// </summary>
    private string? SafeGetAccessToken(TokenInfo tokenInfo, string circuitId)
    {
        try
        {
            var accessToken = tokenInfo.AccessToken;
            if (string.IsNullOrEmpty(accessToken))
            {
                _logger.LogWarning("Не удалось расшифровать access token для Circuit {CircuitId}. Зашифрованные данные пусты или расшифровка вернула пустую строку", circuitId);
                _circuitTokens.TryRemove(circuitId, out _);
                Interlocked.Decrement(ref _activeTokensCount);
                return null;
            }
            return accessToken;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, 
                "Ошибка при расшифровке access token для Circuit {CircuitId}. Тип исключения: {ExceptionType}, Сообщение: {Message}", 
                circuitId, ex.GetType().Name, ex.Message);
            _circuitTokens.TryRemove(circuitId, out _);
            Interlocked.Decrement(ref _activeTokensCount);
            return null;
        }
    }

    /// <summary>
    /// Безопасно получает refresh token с обработкой ошибок расшифровки и логированием
    /// </summary>
    private string? SafeGetRefreshToken(TokenInfo tokenInfo, string circuitId)
    {
        try
        {
            var refreshToken = tokenInfo.RefreshToken;
            // null - нормальное значение, если refresh token отсутствует
            return refreshToken;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, 
                "Ошибка при расшифровке refresh token для Circuit {CircuitId}. Тип исключения: {ExceptionType}, Сообщение: {Message}", 
                circuitId, ex.GetType().Name, ex.Message);
            return null;
        }
    }

    private bool IsTokenExpired(string token, TokenInfo tokenInfo)
    {
        var now = DateTimeOffset.UtcNow;
        
        // Проверяем кэш, если он валиден
        if (tokenInfo.LastExpirationCheck.HasValue && 
            tokenInfo.LastExpirationResult.HasValue &&
            now - tokenInfo.LastExpirationCheck.Value < _expirationCheckCacheDuration)
        {
            // Если кэш говорит, что токен истёк, возвращаем результат
            if (tokenInfo.LastExpirationResult.Value)
            {
                return true;
            }
            
            // Токен валиден по кэшу, но проверяем, не истекает ли он в ближайшее время
            if (ShouldInvalidateCache(token, now))
            {
                // Инвалидируем кэш и проверяем заново
                tokenInfo.LastExpirationCheck = null;
                tokenInfo.LastExpirationResult = null;
            }
            else
            {
                // Используем кэшированный результат
                return false;
            }
        }
        
        // Выполняем проверку истечения токена
        return CheckTokenExpiration(token, tokenInfo, now);
    }
    
    /// <summary>
    /// Проверяет, нужно ли инвалидировать кэш (токен близок к истечению)
    /// </summary>
    private bool ShouldInvalidateCache(string token, DateTimeOffset now)
    {
        try
        {
            var jwtToken = _tokenHandler.ReadJwtToken(token);
            var expirationTime = new DateTimeOffset(jwtToken.ValidTo.ToUniversalTime(), TimeSpan.Zero)
                .AddSeconds(-_tokenExpirationBufferSeconds);
            var timeUntilExpiration = expirationTime - now;
            
            // Если токен истекает в течение времени кэширования, перепроверяем сейчас
            return timeUntilExpiration <= _expirationCheckCacheDuration;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, 
                "Ошибка при чтении JWT токена для проверки времени истечения. Тип исключения: {ExceptionType}, Сообщение: {Message}. Продолжаем с обычной проверкой", 
                ex.GetType().Name, ex.Message);
            // В случае ошибки продолжаем с обычной проверкой
            return true;
        }
    }
    
    /// <summary>
    /// Проверяет, истёк ли токен, и обновляет кэш
    /// </summary>
    private bool CheckTokenExpiration(string token, TokenInfo tokenInfo, DateTimeOffset now)
    {
        try
        {
            var jwtToken = _tokenHandler.ReadJwtToken(token);
            
            // Используем DateTimeOffset для консистентности
            // ValidTo возвращает DateTime в UTC, конвертируем в DateTimeOffset
            var expirationTime = new DateTimeOffset(jwtToken.ValidTo.ToUniversalTime(), TimeSpan.Zero)
                .AddSeconds(-_tokenExpirationBufferSeconds);
            var isExpired = expirationTime <= now;
            
            // Сохраняем результат в кэш
            tokenInfo.LastExpirationCheck = now;
            tokenInfo.LastExpirationResult = isExpired;
            
            return isExpired;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, 
                "Ошибка при проверке срока действия токена. Тип исключения: {ExceptionType}, Сообщение: {Message}. Токен будет считаться истёкшим", 
                ex.GetType().Name, ex.Message);
            // В случае ошибки считаем токен истёкшим для безопасности
            tokenInfo.LastExpirationCheck = now;
            tokenInfo.LastExpirationResult = true;
            return true;
        }
    }

    /// <summary>
    /// Проверяет, не истёк ли refresh token (если он является JWT)
    /// </summary>
    private bool IsRefreshTokenExpired(string? refreshToken)
    {
        if (string.IsNullOrEmpty(refreshToken))
        {
            return true;
        }
        
        try
        {
            // Проверяем, является ли токен JWT (три части, разделённые точками)
            var parts = refreshToken.Split('.');
            if (parts.Length != 3)
            {
                // Не JWT токен (непрозрачный) - считаем, что он не истёк
                // Срок действия будет проверен сервером при обновлении
                return false;
            }
            
            // Проверяем срок действия JWT refresh token
            var jwtToken = _tokenHandler.ReadJwtToken(refreshToken);
            if (jwtToken.ValidTo == default)
            {
                // Нет срока действия - считаем валидным
                return false;
            }
            
            // Используем DateTimeOffset для консистентности
            // ValidTo возвращает DateTime в UTC, конвертируем в DateTimeOffset
            var expirationTime = new DateTimeOffset(jwtToken.ValidTo.ToUniversalTime(), TimeSpan.Zero).AddSeconds(-_tokenExpirationBufferSeconds);
            return expirationTime <= DateTimeOffset.UtcNow;
        }
        catch (Exception ex)
        {
            // Если не удалось прочитать как JWT, считаем, что токен валиден
            // (может быть непрозрачный токен)
            _logger.LogDebug(ex, 
                "Не удалось прочитать refresh token как JWT. Тип исключения: {ExceptionType}, Сообщение: {Message}. Токен будет считаться валидным (возможно, непрозрачный токен)", 
                ex.GetType().Name, ex.Message);
            return false;
        }
    }

    /// <summary>
    /// Проверяет, является ли строка валидным JWT токеном
    /// </summary>
    private bool IsValidJwtToken(string token)
    {
        try
        {
            // Проверяем базовую структуру JWT (три части, разделённые точками)
            var parts = token.Split('.');
            if (parts.Length != 3)
            {
                return false;
            }

            // Проверяем, что можем прочитать токен
            var jwtToken = _tokenHandler.ReadJwtToken(token);
            
            // Проверяем наличие обязательных полей
            if (jwtToken.ValidTo == default)
            {
                return false;
            }

            return true;
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, 
                "Ошибка при валидации JWT токена. Тип исключения: {ExceptionType}, Сообщение: {Message}. Токен считается невалидным", 
                ex.GetType().Name, ex.Message);
            return false;
        }
    }

    private async Task<bool> RefreshTokenAsync(TokenInfo tokenInfo, string circuitId, CancellationToken cancellationToken)
    {
        if (string.IsNullOrEmpty(tokenInfo.RefreshToken))
        {
            _logger.LogWarning("Refresh token отсутствует");
            return false;
        }

        // Создаём семафор для конкретного circuit для предотвращения одновременных обновлений
        SemaphoreSlim semaphore;
        try
        {
            semaphore = _refreshSemaphores.GetOrAdd(circuitId, _ => new SemaphoreSlim(1, 1));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при создании семафора для Circuit {CircuitId}", circuitId);
            return false;
        }
        
        await semaphore.WaitAsync(cancellationToken);
        try
        {
            // Проверяем, не обновил ли токен другой поток пока мы ждали
            if (_circuitTokens.TryGetValue(circuitId, out var currentTokenInfo) &&
                !IsTokenExpired(currentTokenInfo.AccessToken, currentTokenInfo))
            {
                return true; // Токен уже обновлён другим потоком
            }

            // Выполняем обновление с retry логикой
            return await RefreshTokenInternalAsync(tokenInfo, circuitId, cancellationToken);
        }
        finally
        {
            semaphore.Release();
            // Не удаляем семафор здесь - он будет очищен в OnCircuitClosedAsync
            // Автоматическое удаление может привести к race condition
        }
    }

    private async Task<bool> RefreshTokenInternalAsync(TokenInfo tokenInfo, string circuitId, CancellationToken cancellationToken)
    {
        Interlocked.Increment(ref _tokenRefreshCount);
        
        var delay = _initialRetryDelay;
        var originalRefreshToken = tokenInfo.RefreshToken; // Сохраняем оригинальный refresh token
        var retryStartTime = DateTimeOffset.UtcNow;
        
        for (int attempt = 1; attempt <= _maxRetries; attempt++)
        {
            try
            {
                // Конфигурация уже проверена при инициализации, но для безопасности
                // можно добавить проверку (хотя это не должно произойти)
                var authority = _configuration["Authentication:Keycloak:Authority"];
                var clientId = _configuration["Authentication:Keycloak:ClientId"];
                var clientSecret = _configuration["Authentication:Keycloak:ClientSecret"];

                if (string.IsNullOrEmpty(authority) || string.IsNullOrEmpty(clientId))
                {
                    _logger.LogError("Отсутствуют параметры Keycloak в конфигурации (это не должно происходить после валидации)");
                    Interlocked.Increment(ref _tokenRefreshFailures);
                    return false;
                }

                // Используем Uri для правильного построения URL
                if (!Uri.TryCreate(authority, UriKind.Absolute, out var authorityUri))
                {
                    _logger.LogError("Некорректный формат Authority: {Authority}", authority);
                    Interlocked.Increment(ref _tokenRefreshFailures);
                    return false;
                }
                
                var tokenEndpoint = new Uri(authorityUri, "/protocol/openid-connect/token").ToString();
                
                // Используем using для явного управления жизненным циклом HttpClient
                using var httpClient = _httpClientFactory.CreateClient();
                
                if (httpClient == null)
                {
                    _logger.LogError("HttpClientFactory.CreateClient() вернул null");
                    Interlocked.Increment(ref _tokenRefreshFailures);
                    return false;
                }
                
                // Устанавливаем таймаут для HTTP запроса
                httpClient.Timeout = _httpClientTimeout;

                // Валидация параметров перед созданием FormUrlEncodedContent
                var refreshTokenValue = tokenInfo.RefreshToken ?? originalRefreshToken ?? string.Empty;
                var clientSecretValue = clientSecret ?? string.Empty;
                
                if (string.IsNullOrEmpty(refreshTokenValue))
                {
                    _logger.LogError("Refresh token отсутствует для Circuit {CircuitId}", circuitId);
                    Interlocked.Increment(ref _tokenRefreshFailures);
                    return false;
                }
                
                // Используем текущий refresh token (может быть обновлён предыдущей попыткой)
                var requestContent = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("grant_type", "refresh_token"),
                    new KeyValuePair<string, string>("refresh_token", refreshTokenValue),
                    new KeyValuePair<string, string>("client_id", clientId),
                    new KeyValuePair<string, string>("client_secret", clientSecretValue)
                });

                _logger.LogDebug("Отправка запроса на обновление токена к {TokenEndpoint}, попытка {Attempt}/{MaxRetries}", 
                    tokenEndpoint, attempt, _maxRetries);
                
                // Создаём комбинированный CancellationToken
                // Проверяем, не отменен ли уже cancellationToken
                if (cancellationToken.IsCancellationRequested)
                {
                    _logger.LogWarning("Операция обновления токена уже отменена для Circuit {CircuitId}", circuitId);
                    Interlocked.Increment(ref _tokenRefreshFailures);
                    return false;
                }
                
                using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                cts.CancelAfter(_httpClientTimeout);
                
                var response = await httpClient.PostAsync(tokenEndpoint, requestContent, cts.Token);
                
                if (response.IsSuccessStatusCode)
                {
                    var tokenResponse = await response.Content.ReadFromJsonAsync<TokenResponse>(cancellationToken: cts.Token);
                    if (tokenResponse == null || string.IsNullOrEmpty(tokenResponse.AccessToken))
                    {
                        _logger.LogError("Некорректный ответ от сервера токенов");
                        return false;
                    }

                    // Обработка refresh token rotation
                    var newRefreshToken = tokenResponse.RefreshToken;
                    if (string.IsNullOrEmpty(newRefreshToken))
                    {
                        // Если сервер не вернул новый refresh token, используем старый
                        newRefreshToken = tokenInfo.RefreshToken ?? originalRefreshToken;
                        _logger.LogWarning(
                            "Сервер не вернул новый refresh token для Circuit {CircuitId} (попытка {Attempt}). " +
                            "Используется существующий. Это может быть проблемой, если сервер инвалидирует старые токены.",
                            circuitId, attempt);
                    }
                    else
                    {
                        // Обновляем refresh token для следующих попыток (если будут)
                        tokenInfo.RefreshToken = newRefreshToken;
                        _logger.LogDebug("Получен новый refresh token для Circuit {CircuitId}", circuitId);
                    }

                    // Сохраняем новые токены
                    StoreTokens(tokenResponse.AccessToken, newRefreshToken);
                    
                    Interlocked.Increment(ref _tokenRefreshSuccesses);
                    return true;
                }
                
                // Обрабатываем HTTP ошибки
                var errorContent = await response.Content.ReadAsStringAsync();
                var sanitizedError = SanitizeErrorContent(errorContent);
                
                // Для некоторых ошибок не имеет смысла повторять
                if (response.StatusCode == HttpStatusCode.Unauthorized || 
                    response.StatusCode == HttpStatusCode.BadRequest ||
                    response.StatusCode == HttpStatusCode.Forbidden)
                {
                    _logger.LogError("Ошибка обновления токена (неповторяемая): {StatusCode}, {Error}", 
                        response.StatusCode, sanitizedError);
                    Interlocked.Increment(ref _tokenRefreshFailures);
                    return false;
                }
                
                // Для других ошибок пытаемся повторить
                if (attempt < _maxRetries)
                {
                    // Проверяем максимальное время retry
                    var elapsedTime = DateTimeOffset.UtcNow - retryStartTime;
                    if (elapsedTime >= _maxRetryDuration)
                    {
                        _logger.LogError(
                            "Превышено максимальное время retry ({MaxRetryDuration}) для Circuit {CircuitId}. " +
                            "Ошибка: {StatusCode}, {Error}",
                            _maxRetryDuration, circuitId, response.StatusCode, sanitizedError);
                        Interlocked.Increment(ref _tokenRefreshFailures);
                        return false;
                    }
                    
                    _logger.LogWarning("Ошибка обновления токена: {StatusCode}, {Error}. Попытка {Attempt}/{MaxRetries}", 
                        response.StatusCode, sanitizedError, attempt, _maxRetries);
                    await Task.Delay(delay, cancellationToken);
                    delay = TimeSpan.FromMilliseconds(delay.TotalMilliseconds * 2); // Exponential backoff
                    continue;
                }
                
                _logger.LogError("Ошибка обновления токена после {MaxRetries} попыток: {StatusCode}, {Error}", 
                    _maxRetries, response.StatusCode, sanitizedError);
                Interlocked.Increment(ref _tokenRefreshFailures);
                return false;
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                _logger.LogWarning("Обновление токена отменено для Circuit {CircuitId}", circuitId);
                Interlocked.Increment(ref _tokenRefreshFailures);
                return false;
            }
            catch (TaskCanceledException ex) when (attempt < _maxRetries)
            {
                // Проверяем максимальное время retry
                var elapsedTime = DateTimeOffset.UtcNow - retryStartTime;
                if (elapsedTime >= _maxRetryDuration)
                {
                    _logger.LogError(ex, 
                        "Превышено максимальное время retry ({MaxRetryDuration}) для Circuit {CircuitId}",
                        _maxRetryDuration, circuitId);
                    Interlocked.Increment(ref _tokenRefreshFailures);
                    return false;
                }
                
                _logger.LogWarning(ex, "Таймаут при обновлении токена, попытка {Attempt}/{MaxRetries} для Circuit {CircuitId}", 
                    attempt, _maxRetries, circuitId);
                await Task.Delay(delay, cancellationToken);
                delay = TimeSpan.FromMilliseconds(delay.TotalMilliseconds * 2);
                continue;
            }
            catch (HttpRequestException ex) when (attempt < _maxRetries)
            {
                // Проверяем максимальное время retry
                var elapsedTime = DateTimeOffset.UtcNow - retryStartTime;
                if (elapsedTime >= _maxRetryDuration)
                {
                    _logger.LogError(ex, 
                        "Превышено максимальное время retry ({MaxRetryDuration}) для Circuit {CircuitId}",
                        _maxRetryDuration, circuitId);
                    Interlocked.Increment(ref _tokenRefreshFailures);
                    return false;
                }
                
                _logger.LogWarning(ex, "Ошибка сети при обновлении токена, попытка {Attempt}/{MaxRetries} для Circuit {CircuitId}", 
                    attempt, _maxRetries, circuitId);
                await Task.Delay(delay, cancellationToken);
                delay = TimeSpan.FromMilliseconds(delay.TotalMilliseconds * 2);
                continue;
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogError(ex, "Таймаут при обновлении токена после {MaxRetries} попыток для Circuit {CircuitId}", 
                    _maxRetries, circuitId);
                Interlocked.Increment(ref _tokenRefreshFailures);
                return false;
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "Ошибка сети при обновлении токена после {MaxRetries} попыток для Circuit {CircuitId}", 
                    _maxRetries, circuitId);
                Interlocked.Increment(ref _tokenRefreshFailures);
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Неожиданная ошибка при обновлении токена для Circuit {CircuitId}", circuitId);
                Interlocked.Increment(ref _tokenRefreshFailures);
                return false;
            }
        }
        
        Interlocked.Increment(ref _tokenRefreshFailures);
        return false;
    }

    /// <summary>
    /// Удаляет чувствительные данные из сообщения об ошибке перед логированием
    /// Использует предкомпилированные Regex для производительности
    /// </summary>
    private string SanitizeErrorContent(string errorContent)
    {
        if (string.IsNullOrEmpty(errorContent))
        {
            return errorContent;
        }

        // Удаляем токены из JSON ответа, используя предкомпилированные Regex
        var sanitized = _refreshTokenRegex.Replace(errorContent, "\"refresh_token\":\"***\"");
        sanitized = _accessTokenRegex.Replace(sanitized, "\"access_token\":\"***\"");
        sanitized = _clientSecretRegex.Replace(sanitized, "\"client_secret\":\"***\"");
        
        return sanitized;
    }

    /// <summary>
    /// Получить метрики работы сервиса
    /// Использует lock для атомарного чтения всех метрик одновременно
    /// </summary>
    public (long Total, long Successes, long Failures, long ActiveTokens) GetMetrics()
    {
        lock (_metricsLock)
        {
            return (
                Interlocked.Read(ref _tokenRefreshCount),
                Interlocked.Read(ref _tokenRefreshSuccesses),
                Interlocked.Read(ref _tokenRefreshFailures),
                Interlocked.Read(ref _activeTokensCount)
            );
        }
    }

    public void Dispose()
    {
        DisposeCore();
    }
    
    public ValueTask DisposeAsync()
    {
        DisposeCore();
        return ValueTask.CompletedTask;
    }
    
    /// <summary>
    /// Общая логика для Dispose и DisposeAsync
    /// </summary>
    private void DisposeCore()
    {
        if (_disposed)
        {
            return;
        }
        
        // Останавливаем таймер очистки
        _cleanupTimer?.Dispose();
        _cleanupTimer = null;
        
        // Очищаем семафоры
        foreach (var semaphore in _refreshSemaphores.Values)
        {
            try
            {
                semaphore.Dispose();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при освобождении семафора");
            }
        }
        _refreshSemaphores.Clear();
        
        // Очищаем токены (зашифрованные данные)
        ClearTokens();
        
        _disposed = true;
    }
    
    /// <summary>
    /// Очищает все токены, включая зашифрованные данные
    /// </summary>
    private void ClearTokens()
    {
        foreach (var tokenInfo in _circuitTokens.Values)
        {
            try
            {
                // Очищаем зашифрованные токены напрямую
                tokenInfo.ClearEncryptedTokens();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при очистке токенов");
            }
        }
        _circuitTokens.Clear();
        _activeTokensCount = 0;
    }

    private class TokenInfo
    {
        private readonly IDataProtector _dataProtector;
        private string _encryptedAccessToken = string.Empty;
        private string? _encryptedRefreshToken;
        
        public TokenInfo(IDataProtector dataProtector)
        {
            _dataProtector = dataProtector ?? throw new ArgumentNullException(nameof(dataProtector));
        }
        
        /// <summary>
        /// Проверяет, есть ли зашифрованный refresh token (даже если расшифровка не удалась)
        /// </summary>
        public bool HasEncryptedRefreshToken => !string.IsNullOrEmpty(_encryptedRefreshToken);
        
        public string AccessToken
        {
            get
            {
                if (string.IsNullOrEmpty(_encryptedAccessToken))
                {
                    return string.Empty;
                }
                
                try
                {
                    return _dataProtector.Unprotect(_encryptedAccessToken);
                }
                catch (Exception)
                {
                    // Если не удалось расшифровать (например, ключ защиты изменился),
                    // возвращаем пустую строку
                    // Логирование ошибок расшифровки выполняется в SafeGetAccessToken/SafeGetRefreshToken
                    return string.Empty;
                }
            }
            set => _encryptedAccessToken = string.IsNullOrEmpty(value) ? string.Empty : _dataProtector.Protect(value);
        }
        
        public string? RefreshToken
        {
            get
            {
                if (string.IsNullOrEmpty(_encryptedRefreshToken))
                {
                    return null;
                }
                
                try
                {
                    return _dataProtector.Unprotect(_encryptedRefreshToken);
                }
                catch (Exception)
                {
                    // Если не удалось расшифровать (например, ключ защиты изменился),
                    // возвращаем null
                    // Логирование ошибок расшифровки выполняется в SafeGetAccessToken/SafeGetRefreshToken
                    return null;
                }
            }
            set => _encryptedRefreshToken = string.IsNullOrEmpty(value) ? null : _dataProtector.Protect(value);
        }
        
        /// <summary>
        /// Очищает зашифрованные токены напрямую для безопасного удаления из памяти
        /// </summary>
        public void ClearEncryptedTokens()
        {
            _encryptedAccessToken = string.Empty;
            _encryptedRefreshToken = null;
            // Также очищаем свойства для дополнительной безопасности
            AccessToken = string.Empty;
            RefreshToken = null;
        }
        
        public DateTimeOffset StoredAt { get; set; }
        
        // Кэширование результата проверки истечения токена
        public DateTimeOffset? LastExpirationCheck { get; set; }
        public bool? LastExpirationResult { get; set; }
    }

    private class TokenResponse
    {
        [System.Text.Json.Serialization.JsonPropertyName("access_token")]
        public string AccessToken { get; set; } = string.Empty;
        
        [System.Text.Json.Serialization.JsonPropertyName("refresh_token")]
        public string? RefreshToken { get; set; }
        
        [System.Text.Json.Serialization.JsonPropertyName("expires_in")]
        public int ExpiresIn { get; set; }
    }
}

