using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Threading;
using Microsoft.Data.Sqlite;
using new_assistant.Configuration;
using new_assistant.Core.Constants;
using new_assistant.Core.DTOs;
using new_assistant.Core.Exceptions;
using new_assistant.Core.Helpers;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для работы с аудит-логами в SQLite
/// </summary>
public class AuditService : IAuditService, IDisposable
{
    private readonly string _connectionString;
    private readonly ILogger<AuditService> _logger;
    private readonly AuditLoggingSettings? _auditLoggingSettings;
    private readonly IAuditMessageFormatter _messageFormatter;
    private readonly Lazy<Task> _initializeTask;
    private readonly SemaphoreSlim _initSemaphore = new SemaphoreSlim(1, 1);
    private volatile bool _isInitialized = false;
    private volatile bool _initializationFailed = false;
    private DateTime? _lastInitializationAttempt = null;
    private const string DatabaseName = "audit";
    
    // Константы для валидации длины данных
    /// <summary>Максимальная длина строковых полей (username, clientId, realm, targetUsername)</summary>
    private const int MaxStringLength = 1000;
    /// <summary>Максимальная длина описания события</summary>
    private const int MaxDescriptionLength = 5000;
    /// <summary>Максимальная длина деталей изменений</summary>
    private const int MaxChangeDetailsLength = 10000;
    /// <summary>Максимальный размер страницы для пагинации</summary>
    private const int MaxPageSize = 10000;
    /// <summary>Максимальное количество записей для экспорта</summary>
    private const int MaxExportRecords = 100000;
    
    // Константы для батчей и лимитов
    /// <summary>Размер батча для экспорта CSV</summary>
    private const int ExportBatchSize = 10000;
    /// <summary>Размер батча для массовой вставки записей</summary>
    private const int BulkInsertBatchSize = 500;
    /// <summary>Максимальное количество записей для удаления за одну операцию</summary>
    private const int MaxDeleteRecordsPerOperation = 1000000;
    /// <summary>Задержка перед повтором инициализации БД (минуты)</summary>
    private const int RetryDelayMinutes = 5;
    /// <summary>Максимальное количество записей для массовой вставки</summary>
    private const int MaxBulkInsertRecords = 100000;
    /// <summary>Максимальное количество записей, которые можно получить за сеанс</summary>
    private const int MaxRecordsPerSession = 1000000;
    
    // Константы для retry логики SQLite
    /// <summary>Максимальное количество попыток при SQLITE_BUSY</summary>
    private const int MaxRetryAttempts = 5;
    /// <summary>Базовая задержка для retry (миллисекунды)</summary>
    private const int BaseRetryDelayMs = 50;
    /// <summary>SQLite код ошибки SQLITE_BUSY</summary>
    private const int SqliteErrorBusy = 5;

    public AuditService(
        DataPathsSettings dataPathsSettings, 
        ILogger<AuditService> logger, 
        IAuditMessageFormatter messageFormatter,
        AuditLoggingSettings? auditLoggingSettings = null)
    {
        var dbPath = dataPathsSettings.GetAuditDbPath();
        _connectionString = $"Data Source={dbPath};Mode=ReadWriteCreate;Cache=Shared;Pooling=True";
        _logger = logger;
        _messageFormatter = messageFormatter ?? throw new ArgumentNullException(nameof(messageFormatter));
        _auditLoggingSettings = auditLoggingSettings;
        
        // Lazy initialization - БД инициализируется только при первом использовании
        _initializeTask = new Lazy<Task>(() => InitializeDatabaseAsync(), LazyThreadSafetyMode.ExecutionAndPublication);
    }

    /// <summary>
    /// Асинхронная инициализация базы данных (вызывается автоматически при первом использовании)
    /// </summary>
    private async Task InitializeDatabaseAsync()
    {
        try
        {
            await ExecuteWithRetryAsync(async () =>
            {
                await using var connection = new SqliteConnection(_connectionString);
                await connection.OpenAsync().ConfigureAwait(false);
                
                // Включаем WAL режим для лучшей производительности
                await using var walCommand = connection.CreateCommand();
                walCommand.CommandText = "PRAGMA journal_mode=WAL;";
                await walCommand.ExecuteNonQueryAsync().ConfigureAwait(false);
                
                // Дополнительные оптимизации
                // cache_size = -64000 означает 64MB кеша (64000 страниц по 1KB)
                await using var pragmaCommand = connection.CreateCommand();
                pragmaCommand.CommandText = @"
                    PRAGMA synchronous = NORMAL;
                    PRAGMA temp_store = MEMORY;
                    PRAGMA cache_size = -64000;
                ";
                await pragmaCommand.ExecuteNonQueryAsync().ConfigureAwait(false);

                await using var command = connection.CreateCommand();
                command.CommandText = @"
                    CREATE TABLE IF NOT EXISTS audit_logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        event_type TEXT NOT NULL,
                        username TEXT NOT NULL,
                        client_id TEXT,
                        realm TEXT,
                        target_username TEXT,
                        description TEXT NOT NULL,
                        change_details TEXT,
                        created_at TEXT NOT NULL
                    );

                    CREATE INDEX IF NOT EXISTS idx_audit_event_type ON audit_logs(event_type);
                    CREATE INDEX IF NOT EXISTS idx_audit_username ON audit_logs(username);
                    CREATE INDEX IF NOT EXISTS idx_audit_client_id ON audit_logs(client_id);
                    CREATE INDEX IF NOT EXISTS idx_audit_realm ON audit_logs(realm);
                    CREATE INDEX IF NOT EXISTS idx_audit_created_at ON audit_logs(created_at DESC);
                ";
                await command.ExecuteNonQueryAsync().ConfigureAwait(false);
            }).ConfigureAwait(false);
            
            _logger.LogDebug("База данных audit успешно инициализирована");
        }
        catch (Exception ex)
        {
            HandleDatabaseException(ex, "database initialization");
            _logger.LogError(ex, "Ошибка инициализации базы данных audit");
            throw;
        }
    }

    /// <summary>
    /// Гарантирует, что БД инициализирована перед выполнением операции
    /// </summary>
    private async Task EnsureInitializedAsync()
    {
        if (_isInitialized)
            return;
        
        // Если недавно была неудачная попытка, не пытаемся снова сразу
        if (_initializationFailed && _lastInitializationAttempt.HasValue)
        {
            var timeSinceLastAttempt = DateTime.UtcNow - _lastInitializationAttempt.Value;
            if (timeSinceLastAttempt.TotalMinutes < RetryDelayMinutes)
            {
                throw new InvalidOperationException("Database initialization failed recently. Retry later.");
            }
            _initializationFailed = false;
        }
            
        await _initSemaphore.WaitAsync().ConfigureAwait(false);
        try
        {
            if (_isInitialized)
                return;
            
            _lastInitializationAttempt = DateTime.UtcNow;
            try
            {
                await _initializeTask.Value.ConfigureAwait(false);
                _isInitialized = true;
                _initializationFailed = false;
            }
            catch
            {
                _initializationFailed = true;
                throw;
            }
        }
        finally
        {
            _initSemaphore.Release();
        }
    }
    
    /// <summary>
    /// Освобождение ресурсов
    /// </summary>
    public void Dispose()
    {
        _initSemaphore?.Dispose();
    }
    
    /// <summary>
    /// Выполняет операцию с retry логикой для обработки SQLITE_BUSY ошибок
    /// </summary>
    private async Task<T> ExecuteWithRetryAsync<T>(Func<Task<T>> operation, CancellationToken cancellationToken = default)
    {
        int attempt = 0;
        while (true)
        {
            try
            {
                return await operation().ConfigureAwait(false);
            }
            catch (SqliteException ex) when (ex.SqliteErrorCode == SqliteErrorBusy && attempt < MaxRetryAttempts)
            {
                attempt++;
                var delay = BaseRetryDelayMs * (int)Math.Pow(2, attempt - 1); // Экспоненциальная задержка
                _logger.LogWarning("SQLite busy exception (attempt {Attempt}/{MaxAttempts}), retrying after {Delay}ms: {Error}",
                    attempt, MaxRetryAttempts, delay, ex.Message);
                await Task.Delay(delay, cancellationToken).ConfigureAwait(false);
            }
        }
    }
    
    /// <summary>
    /// Выполняет операцию с retry логикой для обработки SQLITE_BUSY ошибок (void версия)
    /// </summary>
    private async Task ExecuteWithRetryAsync(Func<Task> operation, CancellationToken cancellationToken = default)
    {
        await ExecuteWithRetryAsync(async () =>
        {
            await operation().ConfigureAwait(false);
            return true;
        }, cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Обрабатывает исключения доступа к БД с понятными сообщениями
    /// </summary>
    private void HandleDatabaseException(Exception ex, string operation)
    {
        if (ex is IOException ioEx)
        {
            _logger.LogError(ioEx, "IO error during {Operation}. Database file may be locked or inaccessible.", operation);
            throw new InvalidOperationException($"Database file is locked or inaccessible during {operation}", ioEx);
        }
        
        if (ex is UnauthorizedAccessException authEx)
        {
            _logger.LogError(authEx, "Access denied during {Operation}. Check file permissions.", operation);
            throw new UnauthorizedAccessException($"Access denied to database file during {operation}", authEx);
        }
    }
    
    /// <summary>
    /// Валидация длины строки
    /// </summary>
    private static void ValidateStringLength(string? value, string paramName, int maxLength)
    {
        if (value != null && value.Length > maxLength)
            throw new ArgumentException($"{paramName} exceeds maximum length of {maxLength} characters", paramName);
    }
    
    /// <summary>
    /// Валидация типа события - проверяет, что eventType является одним из разрешенных типов
    /// </summary>
    private void ValidateEventType(string eventType)
    {
        if (string.IsNullOrWhiteSpace(eventType))
            throw new ArgumentException("EventType cannot be null or empty", nameof(eventType));
        
        var allowedEventTypes = GetEventTypes();
        if (!allowedEventTypes.Contains(eventType))
        {
            _logger.LogWarning("Unknown event type: {EventType}. Allowed types: {AllowedTypes}", 
                eventType, string.Join(", ", allowedEventTypes));
            // Не выбрасываем исключение, так как это может быть новый тип события
        }
    }
    
    /// <summary>
    /// Проверка на переполнение offset при вычислении пагинации
    /// </summary>
    private static long CalculateOffset(int page, int pageSize)
    {
        // Используем умножение в long контексте для предотвращения переполнения
        var pageLong = (long)(page - 1);
        var pageSizeLong = (long)pageSize;
        var offset = pageLong * pageSizeLong;
        
        if (offset > int.MaxValue)
        {
            throw new ArgumentException($"Offset exceeds maximum value (calculated: {offset}, max: {int.MaxValue})");
        }
        
        return offset;
    }
    
    /// <summary>
    /// Конвертирует DateTime в UTC, правильно обрабатывая уже UTC даты
    /// </summary>
    private static DateTime ToUniversalTimeSafe(DateTime dateTime)
    {
        if (dateTime.Kind == DateTimeKind.Utc)
        {
            return dateTime;
        }
        
        if (dateTime.Kind == DateTimeKind.Unspecified)
        {
            // Для Unspecified считаем локальным временем
            return DateTime.SpecifyKind(dateTime, DateTimeKind.Local).ToUniversalTime();
        }
        
        return dateTime.ToUniversalTime();
    }
    
    /// <summary>
    /// Получает строку из reader, конвертируя пустые строки в null
    /// </summary>
    private static string? GetStringOrNull(Microsoft.Data.Sqlite.SqliteDataReader reader, int ordinal)
    {
        if (reader.IsDBNull(ordinal))
            return null;
        
        var value = reader.GetString(ordinal);
        return string.IsNullOrWhiteSpace(value) ? null : value;
    }
    
    /// <summary>
    /// Проверка является ли событие критическим
    /// </summary>
    private static bool IsCriticalEvent(string eventType)
    {
        return eventType switch
        {
            AuditEventTypes.ClientDeleted => true,
            AuditEventTypes.AccessGranted => true,
            AuditEventTypes.AccessRevoked => true,
            AuditEventTypes.SecretRegenerated => true,
            AuditEventTypes.UserBlocked => true,
            AuditEventTypes.UserUnblocked => true,
            _ => false
        };
    }
    
    /// <summary>
    /// Парсинг DateTime с обработкой ошибок
    /// </summary>
    private DateTime ParseDateTime(string dateTimeString)
    {
        if (string.IsNullOrWhiteSpace(dateTimeString))
            throw new ArgumentException("DateTime string cannot be null or empty", nameof(dateTimeString));
        
        if (DateTime.TryParse(dateTimeString, null, DateTimeStyles.RoundtripKind, out var parsedDate))
        {
            // Если дата не имеет Kind, считаем её UTC
            if (parsedDate.Kind == DateTimeKind.Unspecified)
            {
                parsedDate = DateTime.SpecifyKind(parsedDate, DateTimeKind.Utc);
            }
            return parsedDate;
        }
        
        _logger.LogWarning("Failed to parse datetime: {DateTimeString}, using current UTC time", dateTimeString);
        return DateTime.UtcNow;
    }
    
    /// <summary>
    /// Экранирование поля для CSV
    /// </summary>
    private static string EscapeCsvField(string? field)
    {
        if (string.IsNullOrEmpty(field))
            return string.Empty;
        
        // Если поле содержит кавычки, запятые или переносы строк
        if (field.Contains('"') || field.Contains(',') || field.Contains('\n') || field.Contains('\r'))
        {
            // Экранируем кавычки удвоением и оборачиваем в кавычки
            return $"\"{field.Replace("\"", "\"\"")}\"";
        }
        return field;
    }
    
    /// <summary>
    /// Форматирование строки CSV
    /// </summary>
    private static string FormatCsvRow(AuditLogDto log)
    {
        return string.Join(",",
            EscapeCsvField(log.CreatedAt.ToString("yyyy-MM-dd HH:mm:ss")),
            EscapeCsvField(log.EventTypeDisplay),
            EscapeCsvField(log.Username),
            EscapeCsvField(log.ClientId ?? ""),
            EscapeCsvField(log.Realm ?? ""),
            EscapeCsvField(log.TargetUsername ?? ""),
            EscapeCsvField(log.Description));
    }
    
    /// <summary>
    /// Добавление параметров в команду
    /// </summary>
    private static void AddParameters(SqliteCommand command, IEnumerable<SqliteParameter> parameters)
    {
        foreach (var param in parameters)
        {
            command.Parameters.Add(new SqliteParameter(param.ParameterName, param.Value));
        }
    }

    public async Task LogClientCreatedAsync(string username, string clientId, string realm, string description)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        if (string.IsNullOrWhiteSpace(description))
            throw new ArgumentException("Description cannot be null or empty", nameof(description));
            
        ValidateStringLength(username, nameof(username), MaxStringLength);
        ValidateStringLength(clientId, nameof(clientId), MaxStringLength);
        ValidateStringLength(realm, nameof(realm), MaxStringLength);
        ValidateStringLength(description, nameof(description), MaxDescriptionLength);
            
        await LogEventAsync(AuditEventTypes.ClientCreated, username, clientId, realm, null, description, null);
    }

    public async Task LogClientUpdatedAsync(string username, string clientId, string realm, List<FieldChangeDto> changes)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        if (changes == null || changes.Count == 0)
            throw new ArgumentException("Changes cannot be null or empty", nameof(changes));
            
        ValidateStringLength(username, nameof(username), MaxStringLength);
        ValidateStringLength(clientId, nameof(clientId), MaxStringLength);
        ValidateStringLength(realm, nameof(realm), MaxStringLength);
            
        var changeDetails = JsonSerializer.Serialize(changes);
        ValidateStringLength(changeDetails, nameof(changeDetails), MaxChangeDetailsLength);
        
        // Маскируем чувствительные данные в changeDetails перед сохранением
        var maskedChangeDetails = LogMaskingHelper.MaskSensitiveData(changeDetails);
        
        var changedFields = string.Join(", ", changes.Select(c => c.FieldName));
        var description = _messageFormatter.ClientUpdated(changedFields);
        ValidateStringLength(description, nameof(description), MaxDescriptionLength);
        
        await LogEventAsync(AuditEventTypes.ClientUpdated, username, clientId, realm, null, description, maskedChangeDetails);
    }

    public async Task LogClientDeletedAsync(string username, string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
            
        ValidateStringLength(username, nameof(username), MaxStringLength);
        ValidateStringLength(clientId, nameof(clientId), MaxStringLength);
        ValidateStringLength(realm, nameof(realm), MaxStringLength);
            
        var description = _messageFormatter.ClientDeleted(clientId, realm);
        await LogEventAsync(AuditEventTypes.ClientDeleted, username, clientId, realm, null, description, null);
    }

    public async Task LogAccessGrantedAsync(string username, string targetUsername, string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        if (string.IsNullOrWhiteSpace(targetUsername))
            throw new ArgumentException("TargetUsername cannot be null or empty", nameof(targetUsername));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
            
        ValidateStringLength(username, nameof(username), MaxStringLength);
        ValidateStringLength(targetUsername, nameof(targetUsername), MaxStringLength);
        ValidateStringLength(clientId, nameof(clientId), MaxStringLength);
        ValidateStringLength(realm, nameof(realm), MaxStringLength);
            
        var description = _messageFormatter.AccessGranted(targetUsername, clientId, realm);
        await LogEventAsync(AuditEventTypes.AccessGranted, username, clientId, realm, targetUsername, description, null);
    }

    public async Task LogAccessRevokedAsync(string username, string targetUsername, string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        if (string.IsNullOrWhiteSpace(targetUsername))
            throw new ArgumentException("TargetUsername cannot be null or empty", nameof(targetUsername));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
            
        ValidateStringLength(username, nameof(username), MaxStringLength);
        ValidateStringLength(targetUsername, nameof(targetUsername), MaxStringLength);
        ValidateStringLength(clientId, nameof(clientId), MaxStringLength);
        ValidateStringLength(realm, nameof(realm), MaxStringLength);
            
        var description = _messageFormatter.AccessRevoked(targetUsername, clientId, realm);
        await LogEventAsync(AuditEventTypes.AccessRevoked, username, clientId, realm, targetUsername, description, null);
    }

    public async Task LogRoleAddedAsync(string username, string clientId, string realm, string roleName)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        if (string.IsNullOrWhiteSpace(roleName))
            throw new ArgumentException("RoleName cannot be null or empty", nameof(roleName));
            
        ValidateStringLength(username, nameof(username), MaxStringLength);
        ValidateStringLength(clientId, nameof(clientId), MaxStringLength);
        ValidateStringLength(realm, nameof(realm), MaxStringLength);
            
        var description = _messageFormatter.RoleAdded(roleName, clientId, realm);
        await LogEventAsync(AuditEventTypes.RoleAdded, username, clientId, realm, null, description, null);
    }

    public async Task LogRoleRemovedAsync(string username, string clientId, string realm, string roleName)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        if (string.IsNullOrWhiteSpace(roleName))
            throw new ArgumentException("RoleName cannot be null or empty", nameof(roleName));
            
        ValidateStringLength(username, nameof(username), MaxStringLength);
        ValidateStringLength(clientId, nameof(clientId), MaxStringLength);
        ValidateStringLength(realm, nameof(realm), MaxStringLength);
            
        var description = _messageFormatter.RoleRemoved(roleName, clientId, realm);
        await LogEventAsync(AuditEventTypes.RoleRemoved, username, clientId, realm, null, description, null);
    }

    public async Task LogSecretRegeneratedAsync(string username, string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
            
        ValidateStringLength(username, nameof(username), MaxStringLength);
        ValidateStringLength(clientId, nameof(clientId), MaxStringLength);
        ValidateStringLength(realm, nameof(realm), MaxStringLength);
            
        var description = _messageFormatter.SecretRegenerated(clientId, realm);
        await LogEventAsync(AuditEventTypes.SecretRegenerated, username, clientId, realm, null, description, null);
    }

    public async Task LogUserLoginAsync(string username)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
            
        ValidateStringLength(username, nameof(username), MaxStringLength);
            
        var description = _messageFormatter.UserLogin(username);
        await LogEventAsync(AuditEventTypes.UserLogin, username, null, null, null, description, null);
    }

    public async Task LogForbiddenClientAddedAsync(string username, string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
            
        ValidateStringLength(username, nameof(username), MaxStringLength);
        ValidateStringLength(clientId, nameof(clientId), MaxStringLength);
        ValidateStringLength(realm, nameof(realm), MaxStringLength);
            
        var description = _messageFormatter.ForbiddenClientAdded(clientId, realm);
        await LogEventAsync(AuditEventTypes.ForbiddenClientAdded, username, clientId, realm, null, description, null);
    }

    public async Task LogForbiddenClientRemovedAsync(string username, string clientId, string realm)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
            
        ValidateStringLength(username, nameof(username), MaxStringLength);
        ValidateStringLength(clientId, nameof(clientId), MaxStringLength);
        ValidateStringLength(realm, nameof(realm), MaxStringLength);
            
        var description = _messageFormatter.ForbiddenClientRemoved(clientId, realm);
        await LogEventAsync(AuditEventTypes.ForbiddenClientRemoved, username, clientId, realm, null, description, null);
    }

    public async Task LogEmailSentAsync(string username, string clientId, string realm, string description)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        if (string.IsNullOrWhiteSpace(description))
            throw new ArgumentException("Description cannot be null or empty", nameof(description));
            
        ValidateStringLength(username, nameof(username), MaxStringLength);
        ValidateStringLength(clientId, nameof(clientId), MaxStringLength);
        ValidateStringLength(realm, nameof(realm), MaxStringLength);
        ValidateStringLength(description, nameof(description), MaxDescriptionLength);
            
        await LogEventAsync(AuditEventTypes.EmailSent, username, clientId, realm, null, description, null);
    }

    public async Task LogClientMigrationAsync(string username, string clientId, string sourceRealm, string targetRealm, string status, string? details = null)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        if (string.IsNullOrWhiteSpace(sourceRealm))
            throw new ArgumentException("SourceRealm cannot be null or empty", nameof(sourceRealm));
        if (string.IsNullOrWhiteSpace(targetRealm))
            throw new ArgumentException("TargetRealm cannot be null or empty", nameof(targetRealm));
        if (string.IsNullOrWhiteSpace(status))
            throw new ArgumentException("Status cannot be null or empty", nameof(status));
            
        ValidateStringLength(username, nameof(username), MaxStringLength);
        ValidateStringLength(clientId, nameof(clientId), MaxStringLength);
        ValidateStringLength(sourceRealm, nameof(sourceRealm), MaxStringLength);
        ValidateStringLength(targetRealm, nameof(targetRealm), MaxStringLength);
        ValidateStringLength(details, nameof(details), MaxChangeDetailsLength);
            
        var description = _messageFormatter.ClientMigrated(sourceRealm, targetRealm, status);
        await LogEventAsync(AuditEventTypes.ClientMigrated, username, clientId, targetRealm, null, description, details);
    }

    public async Task LogUserManagementActionAsync(string username, string action, string targetUserId, string? targetUsername, string? realm, string description, Dictionary<string, string>? metadata = null)
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        if (string.IsNullOrWhiteSpace(action))
            throw new ArgumentException("Action cannot be null or empty", nameof(action));
        if (string.IsNullOrWhiteSpace(description))
            throw new ArgumentException("Description cannot be null or empty", nameof(description));
            
        ValidateStringLength(username, nameof(username), MaxStringLength);
        ValidateStringLength(action, nameof(action), MaxStringLength);
        ValidateStringLength(targetUsername, nameof(targetUsername), MaxStringLength);
        ValidateStringLength(realm, nameof(realm), MaxStringLength);
        ValidateStringLength(description, nameof(description), MaxDescriptionLength);
            
        var details = metadata != null
            ? new Dictionary<string, string>(metadata)
            : new Dictionary<string, string>();

        if (!string.IsNullOrWhiteSpace(targetUserId))
        {
            details["targetUserId"] = targetUserId;
        }

        string? changeDetails = details.Count > 0
            ? JsonSerializer.Serialize(details)
            : null;
            
        ValidateStringLength(changeDetails, nameof(changeDetails), MaxChangeDetailsLength);
        
        // Валидация типа события
        ValidateEventType(action);

        await LogEventAsync(action, username, null, realm, targetUsername, description, changeDetails);
    }

    private async Task LogEventAsync(string eventType, string username, string? clientId, string? realm, 
        string? targetUsername, string description, string? changeDetails, CancellationToken cancellationToken = default)
    {
        // Валидация входных данных
        if (string.IsNullOrWhiteSpace(eventType))
            throw new ArgumentException("EventType cannot be null or empty", nameof(eventType));
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", nameof(username));
        if (string.IsNullOrWhiteSpace(description))
            throw new ArgumentException("Description cannot be null or empty", nameof(description));
        
        ValidateStringLength(eventType, nameof(eventType), MaxStringLength);
        ValidateStringLength(username, nameof(username), MaxStringLength);
        ValidateStringLength(clientId, nameof(clientId), MaxStringLength);
        ValidateStringLength(realm, nameof(realm), MaxStringLength);
        ValidateStringLength(targetUsername, nameof(targetUsername), MaxStringLength);
        ValidateStringLength(description, nameof(description), MaxDescriptionLength);
        ValidateStringLength(changeDetails, nameof(changeDetails), MaxChangeDetailsLength);
        
        // Маскируем чувствительные данные в description и changeDetails перед сохранением
        var maskedDescription = LogMaskingHelper.MaskSensitiveData(description);
        var maskedChangeDetails = changeDetails != null ? LogMaskingHelper.MaskSensitiveData(changeDetails) : null;
        
        // Валидация типа события
        ValidateEventType(eventType);
        
        // Гарантируем инициализацию БД перед использованием
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        _logger.LogDebug("Logging audit event: Type={EventType}, User={Username}, ClientId={ClientId}, Realm={Realm}",
            eventType, username, clientId ?? "N/A", realm ?? "N/A");
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await ExecuteWithRetryAsync(async () =>
            {
                await using var connection = new SqliteConnection(_connectionString);
                await connection.OpenAsync(cancellationToken).ConfigureAwait(false);

                await using var command = connection.CreateCommand();
                command.CommandText = @"
                    INSERT INTO audit_logs (event_type, username, client_id, realm, target_username, description, change_details, created_at)
                    VALUES (@eventType, @username, @clientId, @realm, @targetUsername, @description, @changeDetails, @createdAt)
                ";

                command.Parameters.AddWithValue("@eventType", eventType);
                command.Parameters.AddWithValue("@username", username);
                command.Parameters.AddWithValue("@clientId", (object?)clientId ?? DBNull.Value);
                command.Parameters.AddWithValue("@realm", (object?)realm ?? DBNull.Value);
                command.Parameters.AddWithValue("@targetUsername", (object?)targetUsername ?? DBNull.Value);
                command.Parameters.AddWithValue("@description", maskedDescription);
                command.Parameters.AddWithValue("@changeDetails", (object?)maskedChangeDetails ?? DBNull.Value);
                // Сохраняем время создания события в UTC
                var createdAtUtc = DateTime.UtcNow;
                command.Parameters.AddWithValue("@createdAt", createdAtUtc.ToString("O"));

                await command.ExecuteNonQueryAsync(cancellationToken).ConfigureAwait(false);
            }, cancellationToken).ConfigureAwait(false);
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogDebug("Audit event logged successfully in {ElapsedMs}ms: Type={EventType}, User={Username}",
                stopwatch.ElapsedMilliseconds, eventType, username);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            HandleDatabaseException(ex, "logging audit event");
            _logger.LogError(ex, "Ошибка при логировании события {EventType} для пользователя {Username} за {ElapsedMs}ms",
                eventType, username, stopwatch.ElapsedMilliseconds);
            
            // Для критических событий пробрасываем исключение
            if (IsCriticalEvent(eventType))
            {
                throw new AuditLoggingException($"Failed to log critical event {eventType}", ex);
            }
            // Для некритических - только логируем и продолжаем
        }
    }

    public async Task<AuditLogPagedResult> GetAuditLogsAsync(AuditLogFilterDto filter)
    {
        // Валидация входных данных
        if (filter == null)
            throw new ArgumentNullException(nameof(filter));
        
        if (filter.Page < 1)
            throw new ArgumentException("Page must be greater than 0", nameof(filter));
        
        if (filter.PageSize < 1)
            throw new ArgumentException("PageSize must be greater than 0", nameof(filter));
        
        if (filter.PageSize > MaxPageSize)
            throw new ArgumentException($"PageSize cannot exceed {MaxPageSize}", nameof(filter));
        
        // Проверка логики дат
        if (filter.DateFrom.HasValue && filter.DateTo.HasValue && filter.DateFrom.Value > filter.DateTo.Value)
            throw new ArgumentException("DateFrom cannot be greater than DateTo", nameof(filter));
        
        // Проверка на переполнение offset - используем улучшенный метод
        try
        {
            CalculateOffset(filter.Page, filter.PageSize);
        }
        catch (ArgumentException ex)
        {
            throw new ArgumentException(ex.Message, nameof(filter), ex);
        }
        
        // Добавляем ограничение на общее количество записей за сеанс
        // Это предотвращает получение слишком большого количества записей через множественные запросы
        // Проверка выполняется через максимальное количество страниц
        var maxPossiblePages = MaxRecordsPerSession / filter.PageSize;
        if (filter.Page > maxPossiblePages)
        {
            throw new ArgumentException($"Page {filter.Page} exceeds maximum allowed page {maxPossiblePages} for PageSize {filter.PageSize}", nameof(filter));
        }
        
        _logger.LogDebug("Getting audit logs with filter: Page={Page}, PageSize={PageSize}, EventType={EventType}",
            filter.Page, filter.PageSize, filter.EventType);
        
        // Гарантируем инициализацию БД перед использованием
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync().ConfigureAwait(false);

            var whereClauses = new List<string>();
            var parameters = new List<SqliteParameter>();

            if (!string.IsNullOrWhiteSpace(filter.EventType))
            {
                whereClauses.Add("event_type = @eventType");
                parameters.Add(new SqliteParameter("@eventType", filter.EventType));
            }

            // Используем префиксный поиск для username, если возможно, для использования индексов
            if (!string.IsNullOrWhiteSpace(filter.Username))
            {
                var usernameFilter = filter.Username.Trim();
                if (usernameFilter.Length > 0 && !usernameFilter.StartsWith("%"))
                {
                    // Префиксный поиск - может использовать индекс
                    whereClauses.Add("username LIKE @username");
                    parameters.Add(new SqliteParameter("@username", $"{usernameFilter}%"));
                }
                else
                {
                    // Полный поиск - не может использовать индекс эффективно
                    whereClauses.Add("username LIKE @username");
                    parameters.Add(new SqliteParameter("@username", $"%{usernameFilter.Trim('%')}%"));
                }
            }

            // Используем префиксный поиск для clientId, если возможно
            if (!string.IsNullOrWhiteSpace(filter.ClientId))
            {
                var clientIdFilter = filter.ClientId.Trim();
                if (clientIdFilter.Length > 0 && !clientIdFilter.StartsWith("%"))
                {
                    // Префиксный поиск - может использовать индекс
                    whereClauses.Add("client_id LIKE @clientId");
                    parameters.Add(new SqliteParameter("@clientId", $"{clientIdFilter}%"));
                }
                else
                {
                    // Полный поиск
                    whereClauses.Add("client_id LIKE @clientId");
                    parameters.Add(new SqliteParameter("@clientId", $"%{clientIdFilter.Trim('%')}%"));
                }
            }

            if (!string.IsNullOrWhiteSpace(filter.Realm))
            {
                whereClauses.Add("realm = @realm");
                parameters.Add(new SqliteParameter("@realm", filter.Realm));
            }

            if (filter.DateFrom.HasValue)
            {
                whereClauses.Add("created_at >= @dateFrom");
                var dateFromUtc = ToUniversalTimeSafe(filter.DateFrom.Value);
                parameters.Add(new SqliteParameter("@dateFrom", dateFromUtc.ToString("O")));
            }

            if (filter.DateTo.HasValue)
            {
                whereClauses.Add("created_at <= @dateTo");
                var dateTo = filter.DateTo.Value.AddDays(1);
                var dateToUtc = ToUniversalTimeSafe(dateTo);
                parameters.Add(new SqliteParameter("@dateTo", dateToUtc.ToString("O")));
            }

            var whereClause = whereClauses.Any() ? $"WHERE {string.Join(" AND ", whereClauses)}" : "";

            // Получаем общее количество записей
            await using var countCommand = connection.CreateCommand();
            var sqlBuilder = new StringBuilder("SELECT COUNT(*) FROM audit_logs");
            if (!string.IsNullOrEmpty(whereClause))
            {
                sqlBuilder.Append(" ");
                sqlBuilder.Append(whereClause);
            }
            countCommand.CommandText = sqlBuilder.ToString();
            AddParameters(countCommand, parameters);
            var countResult = await countCommand.ExecuteScalarAsync();
            var totalCount = Convert.ToInt32(countResult ?? 0);

            // Получаем записи с пагинацией
            var offset = CalculateOffset(filter.Page, filter.PageSize);
            await using var selectCommand = connection.CreateCommand();
            var selectSqlBuilder = new StringBuilder(@"
                SELECT id, event_type, username, client_id, realm, target_username, description, change_details, created_at
                FROM audit_logs");
            if (!string.IsNullOrEmpty(whereClause))
            {
                selectSqlBuilder.Append(" ");
                selectSqlBuilder.Append(whereClause);
            }
            selectSqlBuilder.Append(@"
                ORDER BY created_at DESC
                LIMIT @pageSize OFFSET @offset");
            selectCommand.CommandText = selectSqlBuilder.ToString();
            AddParameters(selectCommand, parameters);
            selectCommand.Parameters.AddWithValue("@pageSize", filter.PageSize);
            selectCommand.Parameters.AddWithValue("@offset", (int)offset);

            var logs = new List<AuditLogDto>();
            await using var reader = await selectCommand.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                logs.Add(new AuditLogDto
                {
                    Id = reader.GetInt64(0),
                    EventType = reader.GetString(1),
                    EventTypeDisplay = GetEventTypeDisplay(reader.GetString(1)),
                    Username = reader.GetString(2),
                    ClientId = GetStringOrNull(reader, 3),
                    Realm = GetStringOrNull(reader, 4),
                    TargetUsername = GetStringOrNull(reader, 5),
                    Description = reader.GetString(6),
                    ChangeDetails = GetStringOrNull(reader, 7),
                    // Используем безопасный парсинг DateTime
                    CreatedAt = ParseDateTime(reader.GetString(8))
                });
            }

            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            
            _logger.LogInformation("Retrieved {Count} audit logs in {ElapsedMs}ms",
                logs.Count, stopwatch.ElapsedMilliseconds);
            
            return new AuditLogPagedResult
            {
                Items = logs,
                TotalCount = totalCount,
                Page = filter.Page,
                PageSize = filter.PageSize
            };
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "Error getting audit logs after {ElapsedMs}ms", stopwatch.ElapsedMilliseconds);
            throw;
        }
    }

    public async Task<string> ExportToCsvAsync(AuditLogFilterDto filter)
    {
        if (filter == null)
            throw new ArgumentNullException(nameof(filter));
        
        _logger.LogInformation("Starting CSV export for audit logs");
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        
        try
        {
            // Гарантируем инициализацию БД перед использованием
            await EnsureInitializedAsync().ConfigureAwait(false);
            
            // Оптимизированный подсчет записей через отдельный COUNT запрос
            await using var countConnection = new SqliteConnection(_connectionString);
            await countConnection.OpenAsync().ConfigureAwait(false);
            
            var countWhereClauses = new List<string>();
            var countParameters = new List<SqliteParameter>();
            
            if (!string.IsNullOrWhiteSpace(filter.EventType))
            {
                countWhereClauses.Add("event_type = @eventType");
                countParameters.Add(new SqliteParameter("@eventType", filter.EventType));
            }
            
            if (!string.IsNullOrWhiteSpace(filter.Username))
            {
                countWhereClauses.Add("username LIKE @username");
                countParameters.Add(new SqliteParameter("@username", $"%{filter.Username}%"));
            }
            
            if (!string.IsNullOrWhiteSpace(filter.ClientId))
            {
                countWhereClauses.Add("client_id LIKE @clientId");
                countParameters.Add(new SqliteParameter("@clientId", $"%{filter.ClientId}%"));
            }
            
            if (!string.IsNullOrWhiteSpace(filter.Realm))
            {
                countWhereClauses.Add("realm = @realm");
                countParameters.Add(new SqliteParameter("@realm", filter.Realm));
            }
            
            if (filter.DateFrom.HasValue)
            {
                countWhereClauses.Add("created_at >= @dateFrom");
                var dateFrom = filter.DateFrom.Value;
                if (dateFrom.Kind == DateTimeKind.Unspecified)
                {
                    dateFrom = DateTime.SpecifyKind(dateFrom, DateTimeKind.Local);
                }
                var dateFromUtc = dateFrom.ToUniversalTime();
                countParameters.Add(new SqliteParameter("@dateFrom", dateFromUtc.ToString("O")));
            }
            
            if (filter.DateTo.HasValue)
            {
                countWhereClauses.Add("created_at <= @dateTo");
                var dateTo = filter.DateTo.Value.AddDays(1);
                if (dateTo.Kind == DateTimeKind.Unspecified)
                {
                    dateTo = DateTime.SpecifyKind(dateTo, DateTimeKind.Local);
                }
                var dateToUtc = dateTo.ToUniversalTime();
                countParameters.Add(new SqliteParameter("@dateTo", dateToUtc.ToString("O")));
            }
            
            var countWhereClause = countWhereClauses.Any() ? $"WHERE {string.Join(" AND ", countWhereClauses)}" : "";
            
            await using var countCommand = countConnection.CreateCommand();
            countCommand.CommandText = $"SELECT COUNT(*) FROM audit_logs {countWhereClause}";
            AddParameters(countCommand, countParameters);
            
            var countResult = await countCommand.ExecuteScalarAsync();
            var totalCount = Convert.ToInt32(countResult ?? 0);
            
            if (totalCount > MaxExportRecords)
            {
                throw new InvalidOperationException(
                    $"Export limit exceeded. Maximum {MaxExportRecords} records allowed, found {totalCount}");
            }
            
            _logger.LogDebug("Exporting {TotalCount} audit log records", totalCount);
            
            // Создаем копию фильтра для экспорта порциями
            var exportFilter = new AuditLogFilterDto
            {
                EventType = filter.EventType,
                Username = filter.Username,
                ClientId = filter.ClientId,
                Realm = filter.Realm,
                DateFrom = filter.DateFrom,
                DateTo = filter.DateTo,
                Page = 1,
                PageSize = ExportBatchSize
            };
            
            var csv = new StringBuilder();

            // Заголовки
            csv.AppendLine("Дата и время,Тип события,Пользователь,Client ID,Реалм,Целевой пользователь,Описание");

            // Экспортируем порциями
            bool hasMore = true;
            int exportedCount = 0;
            while (hasMore)
            {
                var result = await GetAuditLogsAsync(exportFilter);
                foreach (var log in result.Items)
                {
                    csv.AppendLine(FormatCsvRow(log));
                    exportedCount++;
                }
                
                hasMore = result.Items.Count == exportFilter.PageSize;
                exportFilter.Page++;
            }
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogInformation("CSV export completed successfully: {ExportedCount} records exported in {ElapsedMs}ms",
                exportedCount, stopwatch.ElapsedMilliseconds);

            return csv.ToString();
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Ошибка при экспорте аудит-логов в CSV после {ElapsedMs}ms", stopwatch.ElapsedMilliseconds);
            throw;
        }
    }
    
    /// <summary>
    /// Экспорт записей аудита в CSV с указанием кодировки
    /// </summary>
    public async Task<CsvExportResult> ExportToCsvBytesAsync(AuditLogFilterDto filter)
    {
        if (filter == null)
            throw new ArgumentNullException(nameof(filter));
        
        // Не логируем здесь, т.к. ExportToCsvAsync уже логирует
        try
        {
            var csvString = await ExportToCsvAsync(filter);
            
            // Используем UTF-8 с BOM опционально (по умолчанию включено для совместимости с Excel)
            var useBom = _auditLoggingSettings?.UseBomInCsvExport ?? true;
            var encoding = new UTF8Encoding(encoderShouldEmitUTF8Identifier: useBom);
            var csvBytes = encoding.GetBytes(csvString);
            
            _logger.LogDebug("CSV bytes export completed, size: {Size} bytes", csvBytes.Length);
            
            return new CsvExportResult
            {
                Content = csvBytes,
                Encoding = "UTF-8",
                FileName = $"audit_logs_{DateTime.UtcNow:yyyyMMdd_HHmmss}.csv",
                ContentType = "text/csv; charset=utf-8"
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при экспорте аудит-логов в CSV bytes");
            throw;
        }
    }

    public List<string> GetEventTypes()
    {
        return new List<string>
        {
            AuditEventTypes.ClientCreated,
            AuditEventTypes.ClientUpdated,
            AuditEventTypes.ClientDeleted,
            AuditEventTypes.AccessGranted,
            AuditEventTypes.AccessRevoked,
            AuditEventTypes.RoleAdded,
            AuditEventTypes.RoleRemoved,
            AuditEventTypes.SecretRegenerated,
            AuditEventTypes.UserLogin,
            AuditEventTypes.ForbiddenClientAdded,
            AuditEventTypes.ForbiddenClientRemoved,
            AuditEventTypes.ClientMigrated,
            AuditEventTypes.UserInfoUpdated,
            AuditEventTypes.UserRealmRoleAdded,
            AuditEventTypes.UserRealmRoleRemoved,
            AuditEventTypes.UserClientRoleAdded,
            AuditEventTypes.UserClientRoleRemoved,
            AuditEventTypes.UserPasswordUpdate,
            AuditEventTypes.UserOtpConfigured,
            AuditEventTypes.UserBlocked,
            AuditEventTypes.UserUnblocked,
            AuditEventTypes.UserCertificateAdded,
            AuditEventTypes.UserCertificateDeleted
        };
    }

    private string GetEventTypeDisplay(string eventType)
    {
        return eventType switch
        {
            AuditEventTypes.ClientCreated => "Создание клиента",
            AuditEventTypes.ClientUpdated => "Редактирование клиента",
            AuditEventTypes.ClientDeleted => "Удаление клиента",
            AuditEventTypes.AccessGranted => "Назначение прав",
            AuditEventTypes.AccessRevoked => "Отзыв прав",
            AuditEventTypes.RoleAdded => "Добавление роли",
            AuditEventTypes.RoleRemoved => "Удаление роли",
            AuditEventTypes.SecretRegenerated => "Регенерация Secret",
            AuditEventTypes.UserLogin => "Вход пользователя",
            AuditEventTypes.ForbiddenClientAdded => "Добавление в запрещенные",
            AuditEventTypes.ForbiddenClientRemoved => "Удаление из запрещенных",
            AuditEventTypes.ClientMigrated => "Перенос клиента в STAGE",
            AuditEventTypes.EmailSent => "Отправка email",
            AuditEventTypes.UserInfoUpdated => "Обновление информации пользователя",
            AuditEventTypes.UserRealmRoleAdded => "Добавление realm роли пользователю",
            AuditEventTypes.UserRealmRoleRemoved => "Удаление realm роли у пользователя",
            AuditEventTypes.UserClientRoleAdded => "Добавление client роли пользователю",
            AuditEventTypes.UserClientRoleRemoved => "Удаление client роли у пользователя",
            AuditEventTypes.UserPasswordUpdate => "Инициировано обновление пароля",
            AuditEventTypes.UserOtpConfigured => "Инициирована настройка OTP",
            AuditEventTypes.UserBlocked => "Блокировка пользователя",
            AuditEventTypes.UserUnblocked => "Разблокировка пользователя",
            AuditEventTypes.UserCertificateAdded => "Загрузка сертификата пользователя",
            AuditEventTypes.UserCertificateDeleted => "Удаление сертификата пользователя",
            _ => eventType
        };
    }

    /// <summary>
    /// Массовая вставка записей аудита
    /// </summary>
    public async Task BulkLogEventsAsync(IEnumerable<AuditLogEntry> entries)
    {
        if (entries == null)
            throw new ArgumentNullException(nameof(entries));

        var entriesList = entries.ToList();
        if (entriesList.Count == 0)
        {
            _logger.LogWarning("BulkLogEventsAsync called with empty entries collection");
            return;
        }
        
        // Валидация на максимальное количество записей
        if (entriesList.Count > MaxBulkInsertRecords)
        {
            throw new ArgumentException($"Maximum {MaxBulkInsertRecords} records allowed per bulk insert operation, but {entriesList.Count} were provided", nameof(entries));
        }

        _logger.LogInformation("Starting bulk insert of {Count} audit log entries", entriesList.Count);

        await EnsureInitializedAsync().ConfigureAwait(false);

        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        
        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync().ConfigureAwait(false);

        await using var transaction = (Microsoft.Data.Sqlite.SqliteTransaction)await connection.BeginTransactionAsync();
        try
        {
            // Предварительно валидируем все записи с указанием индекса
            foreach (var (entry, index) in entriesList.Select((e, i) => (e, i)))
            {
                if (string.IsNullOrWhiteSpace(entry.EventType))
                    throw new ArgumentException($"Entry at index {index}: EventType cannot be null or empty", nameof(entries));
                if (string.IsNullOrWhiteSpace(entry.Username))
                    throw new ArgumentException($"Entry at index {index}: Username cannot be null or empty", nameof(entries));
                if (string.IsNullOrWhiteSpace(entry.Description))
                    throw new ArgumentException($"Entry at index {index}: Description cannot be null or empty", nameof(entries));

                ValidateStringLength(entry.Username, $"entries[{index}].Username", MaxStringLength);
                ValidateStringLength(entry.ClientId, $"entries[{index}].ClientId", MaxStringLength);
                ValidateStringLength(entry.Realm, $"entries[{index}].Realm", MaxStringLength);
                ValidateStringLength(entry.TargetUsername, $"entries[{index}].TargetUsername", MaxStringLength);
                ValidateStringLength(entry.Description, $"entries[{index}].Description", MaxDescriptionLength);
                ValidateStringLength(entry.ChangeDetails, $"entries[{index}].ChangeDetails", MaxChangeDetailsLength);
            }

            // Создаем время один раз для всех записей в транзакции для консистентности
            var createdAtUtc = DateTime.UtcNow;
            var createdAtUtcString = createdAtUtc.ToString("O");
            
            int insertedCount = 0;
            
            // Разбиваем на батчи для эффективной массовой вставки
            for (int batchStart = 0; batchStart < entriesList.Count; batchStart += BulkInsertBatchSize)
            {
                var batchEnd = Math.Min(batchStart + BulkInsertBatchSize, entriesList.Count);
                var batch = entriesList.Skip(batchStart).Take(batchEnd - batchStart).ToList();
                
                await using var command = connection.CreateCommand();
                command.Transaction = transaction;
                
                // Строим множественную вставку: INSERT INTO ... VALUES (...), (...), ...
                var valuesParts = new List<string>();
                var parameters = new List<SqliteParameter>();
                
                for (int i = 0; i < batch.Count; i++)
                {
                    var entry = batch[i];
                    var suffix = i.ToString();
                    
                    valuesParts.Add($"(@eventType{suffix}, @username{suffix}, @clientId{suffix}, @realm{suffix}, @targetUsername{suffix}, @description{suffix}, @changeDetails{suffix}, @createdAt{suffix})");
                    
                    parameters.Add(new SqliteParameter($"@eventType{suffix}", entry.EventType));
                    parameters.Add(new SqliteParameter($"@username{suffix}", entry.Username));
                    parameters.Add(new SqliteParameter($"@clientId{suffix}", (object?)entry.ClientId ?? DBNull.Value));
                    parameters.Add(new SqliteParameter($"@realm{suffix}", (object?)entry.Realm ?? DBNull.Value));
                    parameters.Add(new SqliteParameter($"@targetUsername{suffix}", (object?)entry.TargetUsername ?? DBNull.Value));
                    parameters.Add(new SqliteParameter($"@description{suffix}", entry.Description));
                    parameters.Add(new SqliteParameter($"@changeDetails{suffix}", (object?)entry.ChangeDetails ?? DBNull.Value));
                    parameters.Add(new SqliteParameter($"@createdAt{suffix}", createdAtUtcString));
                }
                
                command.CommandText = $@"
                    INSERT INTO audit_logs (event_type, username, client_id, realm, target_username, description, change_details, created_at)
                    VALUES {string.Join(", ", valuesParts)}
                ";
                
                foreach (var param in parameters)
                {
                    command.Parameters.Add(param);
                }
                
                await command.ExecuteNonQueryAsync();
                insertedCount += batch.Count;
            }

            await transaction.CommitAsync();
            
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogInformation("Bulk insert completed successfully: {InsertedCount} records inserted in {ElapsedMs}ms",
                insertedCount, stopwatch.ElapsedMilliseconds);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            _logger.LogError(ex, "Error during bulk insert of audit log entries after {ElapsedMs}ms", stopwatch.ElapsedMilliseconds);
            await transaction.RollbackAsync();
            throw;
        }
    }

    /// <summary>
    /// Очистка старых записей аудита
    /// </summary>
    public async Task<int> CleanupOldRecordsAsync(DateTime olderThan)
    {
        // Валидация входных данных
        if (olderThan > DateTime.UtcNow)
        {
            throw new ArgumentException("olderThan cannot be in the future", nameof(olderThan));
        }
        
        _logger.LogInformation("Starting cleanup of audit log records older than {Date}", olderThan);

        await EnsureInitializedAsync().ConfigureAwait(false);

        var stopwatch = System.Diagnostics.Stopwatch.StartNew();

        try
        {
            return await ExecuteWithRetryAsync(async () =>
            {
                await using var connection = new SqliteConnection(_connectionString);
                await connection.OpenAsync().ConfigureAwait(false);

                // Сначала получаем количество записей для удаления
                await using var countCommand = connection.CreateCommand();
                countCommand.CommandText = "SELECT COUNT(*) FROM audit_logs WHERE created_at < @olderThan";
                var olderThanUtc = ToUniversalTimeSafe(olderThan);
                countCommand.Parameters.AddWithValue("@olderThan", olderThanUtc.ToString("O"));
                
                var countResult = await countCommand.ExecuteScalarAsync();
                var countToDelete = Convert.ToInt32(countResult ?? 0);
                
                if (countToDelete == 0)
                {
                    _logger.LogInformation("No old audit log records found to delete");
                    return 0;
                }
                
                // Проверка лимита безопасности
                if (countToDelete > MaxDeleteRecordsPerOperation)
                {
                    throw new InvalidOperationException(
                        $"Too many records to delete ({countToDelete}). Maximum {MaxDeleteRecordsPerOperation} allowed per operation.");
                }

                _logger.LogInformation("Found {Count} audit log records to delete", countToDelete);

                await using var deleteCommand = connection.CreateCommand();
                deleteCommand.CommandText = "DELETE FROM audit_logs WHERE created_at < @olderThan";
                deleteCommand.Parameters.AddWithValue("@olderThan", olderThanUtc.ToString("O"));

                var deletedCount = await deleteCommand.ExecuteNonQueryAsync();
                
                stopwatch.Stop();
                SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
                
                _logger.LogInformation("Deleted {DeletedCount} old audit log records older than {Date} in {ElapsedMs}ms",
                    deletedCount, olderThan, stopwatch.ElapsedMilliseconds);

                return deletedCount;
            }).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
            HandleDatabaseException(ex, "cleanup old records");
            _logger.LogError(ex, "Error during cleanup of old audit log records after {ElapsedMs}ms", stopwatch.ElapsedMilliseconds);
            throw;
        }
    }
}

