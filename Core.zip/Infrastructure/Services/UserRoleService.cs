using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Security.Claims;
using System.Threading;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using new_assistant.Core.Interfaces;
using new_assistant.Core.Constants;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Реализация сервиса для работы с ролями пользователей.
/// Внимание: Сервис требует наличия HttpContext и должен использоваться только в контексте HTTP-запроса.
/// Зарегистрирован как Scoped для корректной работы с HttpContext.
/// </summary>
public class UserRoleService : IUserRoleService
{
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly ILogger<UserRoleService> _logger;
    private readonly object _cacheLock = new object();
    
    // Константы для валидации
    private const int MaxPathLength = 2048; // RFC 7230 максимальная длина URI
    private const int MaxUsernameLength = 256; // Разумный лимит для имени пользователя
    
    // Кэш для проверки ролей в рамках одного запроса
    // Используем lock для обеспечения потокобезопасности (volatile не поддерживается для nullable типов)
    private bool? _cachedIsAdmin;
    private bool? _cachedIsUser;
    private bool? _cachedIsOperator;
    private ClaimsPrincipal? _cachedUser;
    
    // Статические readonly ImmutableHashSet для оптимизации производительности проверки доступа к страницам
    // Использование ImmutableHashSet обеспечивает O(1) поиск и гарантирует thread-safety
    private static readonly ImmutableHashSet<string> UserAllowedPages = 
        ImmutableHashSet.Create(StringComparer.OrdinalIgnoreCase,
            NormalizePath(PagePaths.Home),
            NormalizePath(PagePaths.MyClients));
    
    private static readonly ImmutableHashSet<string> OperatorAllowedPages = 
        ImmutableHashSet.Create(StringComparer.OrdinalIgnoreCase,
            NormalizePath(PagePaths.UserManagementInfo),
            NormalizePath(PagePaths.UserManagementAdd));
    
    // Кэш для нормализованных путей (только для статических путей)
    private static readonly Dictionary<string, string> PathNormalizationCache = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    
    /// <summary>
    /// Нормализует путь для использования в HashSet.
    /// Удаляет query string и fragment, приводит к нижнему регистру, нормализует trailing slash.
    /// Оптимизирован для производительности с использованием кэширования и эффективных операций со строками.
    /// </summary>
    private static string NormalizePath(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
            return string.Empty;
        
        // Проверка максимальной длины
        if (path.Length > MaxPathLength)
        {
            path = path.Substring(0, MaxPathLength);
        }
        
        // Проверка кэша для статических путей
        if (PathNormalizationCache.TryGetValue(path, out var cached))
        {
            return cached;
        }
        
        // Оптимизированная обработка query string и fragment
        int queryIndex = path.IndexOf('?');
        int fragmentIndex = path.IndexOf('#');
        
        int endIndex = path.Length;
        if (queryIndex >= 0 && (fragmentIndex < 0 || queryIndex < fragmentIndex))
        {
            endIndex = queryIndex;
        }
        else if (fragmentIndex >= 0)
        {
            endIndex = fragmentIndex;
        }
        
        var cleanPath = path.Substring(0, endIndex).Trim();
        
        // Обработка пути только из слэшей
        if (cleanPath.Length > 0 && cleanPath.All(c => c == '/' || c == '\\'))
        {
            var result = "/";
            // Кэшируем только для коротких путей
            if (path.Length < 100)
            {
                lock (PathNormalizationCache)
                {
                    if (PathNormalizationCache.Count < 1000) // Ограничение размера кэша
                    {
                        PathNormalizationCache[path] = result;
                    }
                }
            }
            return result;
        }
        
        // Оптимизированная нормализация слэшей
        if (cleanPath.IndexOf('\\') >= 0)
        {
            cleanPath = cleanPath.Replace('\\', '/');
        }
        
        // Удаляем trailing slash (кроме корня) - оптимизированная версия
        if (cleanPath.Length > 1 && cleanPath[cleanPath.Length - 1] == '/')
        {
            cleanPath = cleanPath.Substring(0, cleanPath.Length - 1);
        }
        
        // Убеждаемся, что путь начинается со слэша
        if (cleanPath.Length == 0 || cleanPath[0] != '/')
        {
            cleanPath = '/' + cleanPath;
        }
        
        var resultPath = cleanPath.ToLowerInvariant();
        
        // Кэшируем только для коротких путей
        if (path.Length < 100)
        {
            lock (PathNormalizationCache)
            {
                if (PathNormalizationCache.Count < 1000) // Ограничение размера кэша
                {
                    PathNormalizationCache[path] = resultPath;
                }
            }
        }
        
        return resultPath;
    }
    
    /// <summary>
    /// Нормализует путь страницы: удаляет query string и fragment, нормализует слэши и регистр.
    /// </summary>
    /// <param name="pagePath">Исходный путь страницы</param>
    /// <returns>Нормализованный путь или пустую строку, если нормализация не удалась</returns>
    private static string NormalizePagePath(string pagePath)
    {
        // Используем общий метод нормализации
        var normalized = NormalizePath(pagePath);
        
        // Проверка результата нормализации
        if (string.IsNullOrEmpty(normalized))
        {
            return string.Empty;
        }
        
        return normalized;
    }
    
    public UserRoleService(IHttpContextAccessor httpContextAccessor, ILogger<UserRoleService> logger)
    {
        _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }
    
    /// <summary>
    /// Получает текущего пользователя из HttpContext.
    /// </summary>
    /// <returns>ClaimsPrincipal текущего пользователя или null, если HttpContext недоступен</returns>
    private ClaimsPrincipal? GetCurrentUser()
    {
        var httpContext = _httpContextAccessor.HttpContext;
        if (httpContext == null)
        {
            _logger.LogWarning("Попытка получить пользователя вне контекста HTTP-запроса");
            return null;
        }
        
        return httpContext.User;
    }
    
    /// <summary>
    /// Проверяет, аутентифицирован ли текущий пользователь.
    /// </summary>
    private bool IsAuthenticated()
    {
        var user = GetCurrentUser();
        return user?.Identity?.IsAuthenticated == true && user.Identity != null;
    }
    
    /// <summary>
    /// Общий метод для проверки наличия роли у пользователя.
    /// </summary>
    /// <param name="role">Роль для проверки</param>
    /// <returns>True, если пользователь аутентифицирован и имеет указанную роль</returns>
    private bool HasRole(string role)
    {
        if (!IsAuthenticated())
        {
            return false;
        }
        
        var user = GetCurrentUser();
        if (user == null)
        {
            return false;
        }
        
        try
        {
            return user.IsInRole(role);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при проверке роли {Role} для пользователя {UserName}", 
                role, user.Identity?.Name);
            return false;
        }
    }
    
    /// <summary>
    /// Обеспечивает актуальность кэша проверки ролей для текущего пользователя.
    /// Использует блокировку для обеспечения потокобезопасности.
    /// </summary>
    private void EnsureRoleCache()
    {
        var user = GetCurrentUser();
        
        // Используем двойную проверку для оптимизации производительности
        if (user == _cachedUser && _cachedIsAdmin.HasValue)
        {
            return; // Кэш актуален
        }
        
        lock (_cacheLock)
        {
            // Повторная проверка после получения блокировки (double-check pattern)
            if (user == _cachedUser && _cachedIsAdmin.HasValue)
            {
                return;
            }
            
            // Явно обрабатываем случай, когда пользователь изменился (включая null -> не null и наоборот)
            if (user != _cachedUser || (user == null && _cachedUser != null) || (user != null && _cachedUser == null))
            {
                _cachedUser = user;
                _cachedIsAdmin = null;
                _cachedIsUser = null;
                _cachedIsOperator = null;
            }
            
            // Если пользователь null, явно устанавливаем false
            if (user == null)
            {
                _cachedIsAdmin = false;
                _cachedIsUser = false;
                _cachedIsOperator = false;
                return;
            }
            
            // Безопасная проверка ролей с обработкой исключений
            try
            {
                _cachedIsAdmin ??= user.IsInRole(Roles.Admin);
                _cachedIsUser ??= user.IsInRole(Roles.User);
                _cachedIsOperator ??= user.IsInRole(Roles.Operator);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при проверке ролей пользователя {UserName}", user.Identity?.Name);
                // В случае ошибки считаем, что пользователь не имеет ролей
                _cachedIsAdmin = false;
                _cachedIsUser = false;
                _cachedIsOperator = false;
            }
        }
    }
    
    /// <summary>
    /// Проверяет, является ли текущий пользователь администратором.
    /// Возвращает false, если пользователь не аутентифицирован или не имеет роли.
    /// </summary>
    /// <returns>True, если пользователь аутентифицирован и имеет роль Assistant-Admin, иначе False</returns>
    public bool IsAdmin()
    {
        return HasRole(Roles.Admin);
    }
    
    /// <summary>
    /// Проверяет, является ли текущий пользователь обычным пользователем.
    /// Возвращает false, если пользователь не аутентифицирован или не имеет роли.
    /// </summary>
    /// <returns>True, если пользователь аутентифицирован и имеет роль Assistant-User, иначе False</returns>
    public bool IsUser()
    {
        return HasRole(Roles.User);
    }
    
    /// <summary>
    /// Проверяет, является ли текущий пользователь оператором.
    /// Возвращает false, если пользователь не аутентифицирован или не имеет роли.
    /// </summary>
    /// <returns>True, если пользователь аутентифицирован и имеет роль Assistant-Operator, иначе False</returns>
    public bool IsOperator()
    {
        return HasRole(Roles.Operator);
    }
    
    /// <summary>
    /// Общий метод для подготовки и валидации ролей перед проверкой.
    /// </summary>
    /// <param name="roles">Роли для проверки</param>
    /// <param name="user">Текущий пользователь</param>
    /// <returns>Массив валидных ролей или null, если проверка невозможна</returns>
    private string[]? PrepareRolesForCheck(string[]? roles, ClaimsPrincipal? user)
    {
        if (roles == null || roles.Length == 0)
            return null;
        
        if (!IsAuthenticated() || user == null)
            return null;
        
        // Используем HashSet для эффективного удаления дубликатов
        var validRolesSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var role in roles)
        {
            if (!string.IsNullOrWhiteSpace(role))
            {
                validRolesSet.Add(role);
            }
        }
        
        if (validRolesSet.Count == 0)
            return null;
        
        // Преобразуем в массив только один раз
        return validRolesSet.ToArray();
    }
    
    /// <summary>
    /// Проверяет, имеет ли пользователь хотя бы одну из указанных ролей.
    /// </summary>
    /// <param name="roles">Роли для проверки</param>
    /// <returns>True, если пользователь аутентифицирован и имеет хотя бы одну из указанных ролей</returns>
    public bool HasAnyRole(params string[] roles)
    {
        var user = GetCurrentUser();
        var validRoles = PrepareRolesForCheck(roles, user);
        
        if (validRoles == null || validRoles.Length == 0)
            return false;
        
        try
        {
            return validRoles.Any(role => user!.IsInRole(role));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при проверке ролей для пользователя {UserName}", 
                user?.Identity?.Name);
            return false;
        }
    }
    
    /// <summary>
    /// Проверяет, имеет ли пользователь все указанные роли.
    /// </summary>
    /// <param name="roles">Роли для проверки</param>
    /// <returns>True, если пользователь аутентифицирован и имеет все указанные роли</returns>
    public bool HasAllRoles(params string[] roles)
    {
        var user = GetCurrentUser();
        var validRoles = PrepareRolesForCheck(roles, user);
        
        if (validRoles == null || validRoles.Length == 0)
            return false;
        
        try
        {
            return validRoles.All(role => user!.IsInRole(role));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при проверке ролей для пользователя {UserName}", 
                user?.Identity?.Name);
            return false;
        }
    }
    
    /// <summary>
    /// Получает роль текущего пользователя.
    /// Проверяет роли в порядке приоритета: Admin, User, Operator.
    /// </summary>
    /// <returns>Роль пользователя или null, если роль не найдена или пользователь не аутентифицирован</returns>
    public string? GetUserRole()
    {
        var user = GetCurrentUser();
        if (!IsAuthenticated() || user == null)
        {
            _logger.LogWarning("Попытка получить роль неаутентифицированного пользователя");
            return null;
        }
        
        try
        {
            // Проверяем роли в порядке приоритета
            if (user.IsInRole(Roles.Admin))
            {
                if (_logger.IsEnabled(LogLevel.Trace))
                {
                    _logger.LogTrace("Пользователь {UserName} имеет роль {Role}", 
                        user.Identity?.Name, Roles.Admin);
                }
                return Roles.Admin;
            }
            
            if (user.IsInRole(Roles.User))
            {
                if (_logger.IsEnabled(LogLevel.Trace))
                {
                    _logger.LogTrace("Пользователь {UserName} имеет роль {Role}", 
                        user.Identity?.Name, Roles.User);
                }
                return Roles.User;
            }
            
            if (user.IsInRole(Roles.Operator))
            {
                if (_logger.IsEnabled(LogLevel.Trace))
                {
                    _logger.LogTrace("Пользователь {UserName} имеет роль {Role}", 
                        user.Identity?.Name, Roles.Operator);
                }
                return Roles.Operator;
            }
            
            // Логируем только если действительно не найдена ожидаемая роль
            var allRolesClaims = user.FindAll(ClaimTypes.Role);
            if (allRolesClaims != null)
            {
                // Оптимизированная материализация только при необходимости
                var rolesEnumerable = allRolesClaims.Select(c => c.Value);
                if (rolesEnumerable.Any())
                {
                    // Материализуем только для логирования
                    var rolesList = new List<string>();
                    foreach (var role in rolesEnumerable)
                    {
                        if (!string.IsNullOrWhiteSpace(role))
                        {
                            rolesList.Add(role);
                        }
                    }
                    
                    if (rolesList.Count > 0)
                    {
                        _logger.LogWarning(
                            "Пользователь {UserName} не имеет ни одной из ожидаемых ролей. " +
                            "Доступные роли: {Roles}. Ожидаемые: {ExpectedRoles}",
                            user.Identity?.Name,
                            string.Join(", ", rolesList),
                            string.Join(", ", new[] { Roles.Admin, Roles.User, Roles.Operator }));
                    }
                }
                else
                {
                    _logger.LogWarning("Пользователь {UserName} не имеет ни одной роли", 
                        user.Identity?.Name);
                }
            }
            else
            {
                _logger.LogWarning("Не удалось получить роли для пользователя {UserName}", 
                    user.Identity?.Name);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при получении роли пользователя {UserName}", 
                user.Identity?.Name);
            return null;
        }
        
        return null;
    }
    
    /// <summary>
    /// Получает имя текущего пользователя из claims.
    /// </summary>
    /// <returns>Имя пользователя или null, если пользователь не аутентифицирован или имя не найдено</returns>
    public string? GetUserName()
    {
        var user = GetCurrentUser();
        var userName = user?.Identity?.Name;
        
        // Валидация длины имени пользователя
        if (userName != null && userName.Length > MaxUsernameLength)
        {
            _logger.LogWarning("Имя пользователя превышает максимальную длину: {Length} символов", 
                userName.Length);
            return null;
        }
        
        return userName;
    }
    
    /// <summary>
    /// Получает ID текущего пользователя.
    /// Приоритет проверки claims: сначала стандартный ClaimTypes.NameIdentifier, затем Keycloak-specific Claims.Subject.
    /// </summary>
    /// <returns>ID пользователя или null, если не найден</returns>
    public string? GetUserId()
    {
        var user = GetCurrentUser();
        if (user == null)
            return null;
        
        if (!IsAuthenticated())
        {
            _logger.LogWarning("Попытка получить ID неаутентифицированного пользователя");
            return null;
        }
        
        // Сначала пробуем стандартный claim, затем Keycloak-specific
        var userId = user.FindFirst(ClaimTypes.NameIdentifier)?.Value 
            ?? user.FindFirst(Claims.Subject)?.Value;
        
        if (userId == null)
        {
            _logger.LogWarning("ID пользователя не найден для аутентифицированного пользователя {UserName}", 
                user.Identity?.Name);
        }
        
        return userId;
    }
    
    /// <summary>
    /// Получает все роли текущего пользователя.
    /// Внимание: Результат является ленивым IEnumerable и материализуется при первом перечислении.
    /// Для множественного использования рекомендуется использовать GetRolesList().
    /// </summary>
    /// <returns>Перечисление всех ролей пользователя или пустое перечисление, если пользователь не аутентифицирован</returns>
    public IEnumerable<string> GetRoles()
    {
        var user = GetCurrentUser();
        if (!IsAuthenticated() || user == null)
            return Enumerable.Empty<string>();
            
        return user.FindAll(ClaimTypes.Role).Select(c => c.Value);
    }
    
    /// <summary>
    /// Получает все роли текущего пользователя как материализованный список.
    /// Используйте этот метод, если роли будут использоваться несколько раз.
    /// </summary>
    /// <returns>Материализованный список всех ролей пользователя или пустой список, если пользователь не аутентифицирован</returns>
    public IReadOnlyList<string> GetRolesList()
    {
        var user = GetCurrentUser();
        if (!IsAuthenticated() || user == null)
            return Array.Empty<string>();
        
        try
        {
            var rolesClaims = user.FindAll(ClaimTypes.Role);
            if (rolesClaims == null)
                return Array.Empty<string>();
            
            // Оптимизированное создание списка с предварительным размером
            var rolesList = new List<string>();
            foreach (var claim in rolesClaims)
            {
                if (claim?.Value != null && !string.IsNullOrWhiteSpace(claim.Value))
                {
                    rolesList.Add(claim.Value);
                }
            }
            
            return rolesList.AsReadOnly();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при получении списка ролей пользователя {UserName}", 
                user.Identity?.Name);
            return Array.Empty<string>();
        }
    }
    
    // Кэш для страниц администратора (статический, создается один раз)
    private static readonly ImmutableHashSet<string> AdminAllowedPages = 
        ImmutableHashSet.Create(StringComparer.OrdinalIgnoreCase,
            NormalizePath(PagePaths.Home),
            NormalizePath(PagePaths.MyClients),
            NormalizePath(PagePaths.UserManagementInfo),
            NormalizePath(PagePaths.UserManagementAdd),
            NormalizePath(PagePaths.Logs),
            NormalizePath(PagePaths.Audit),
            NormalizePath(PagePaths.Clients),
            NormalizePath(PagePaths.AdminForbiddenClients),
            NormalizePath(PagePaths.ClientMigration));
    
    /// <summary>
    /// Получает список всех страниц, к которым у текущего пользователя есть доступ.
    /// </summary>
    /// <returns>Коллекция путей к доступным страницам</returns>
    public IReadOnlySet<string> GetAccessiblePages()
    {
        if (!IsAuthenticated())
            return ImmutableHashSet<string>.Empty;
        
        var user = GetCurrentUser();
        if (user == null)
        {
            _logger.LogWarning("Попытка получить доступные страницы для null пользователя");
            return ImmutableHashSet<string>.Empty;
        }
        
        // Используем кэш для оптимизации
        EnsureRoleCache();
        
        // Проверяем актуальность кэша
        if (!_cachedIsAdmin.HasValue && !_cachedIsUser.HasValue && !_cachedIsOperator.HasValue)
        {
            _logger.LogWarning("Кэш ролей не был обновлен для пользователя {UserName}", 
                user.Identity?.Name);
            return ImmutableHashSet<string>.Empty;
        }
        
        if (_cachedIsAdmin == true)
        {
            // Администраторы имеют доступ ко всем страницам
            return AdminAllowedPages;
        }
        
        // Оптимизированное создание HashSet с предварительным размером
        var accessiblePages = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        
        if (_cachedIsUser == true)
        {
            accessiblePages.UnionWith(UserAllowedPages);
        }
        
        if (_cachedIsOperator == true)
        {
            accessiblePages.UnionWith(OperatorAllowedPages);
        }
        
        // Возвращаем ImmutableHashSet для thread-safety
        return accessiblePages.Count > 0 
            ? accessiblePages.ToImmutableHashSet(StringComparer.OrdinalIgnoreCase)
            : ImmutableHashSet<string>.Empty;
    }
    
    /// <summary>
    /// Проверяет валидность пути на наличие path traversal атак и других небезопасных последовательностей.
    /// Оптимизирован для производительности с использованием эффективных операций со строками.
    /// </summary>
    /// <param name="path">Путь для проверки</param>
    /// <returns>True, если путь валиден, иначе False</returns>
    private static bool IsValidPath(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
            return false;
        
        // Проверка максимальной длины
        if (path.Length > MaxPathLength)
            return false;
        
        // Оптимизированная проверка на path traversal
        if (path.IndexOf("..", StringComparison.Ordinal) >= 0)
            return false;
        
        // Проверка на абсолютные пути Windows (C:\, D:\ и т.д.)
        if (path.Length >= 2 && char.IsLetter(path[0]) && path[1] == ':')
            return false;
        
        // Оптимизированная проверка на множественные слэши (более двух подряд)
        if (path.IndexOf("///", StringComparison.Ordinal) >= 0)
            return false;
        
        // Оптимизированная проверка на двойные слэши
        if (path.Length > 0 && path[0] == '/')
        {
            // Разрешаем только один слэш в начале, но не двойные слэши в середине пути
            var doubleSlashIndex = path.IndexOf("//", 1, StringComparison.Ordinal);
            if (doubleSlashIndex > 0)
                return false;
        }
        else
        {
            // Для относительных путей не должно быть двойных слэшей
            if (path.IndexOf("//", StringComparison.Ordinal) >= 0)
                return false;
        }
        
        return true;
    }
    
    
    /// <summary>
    /// Проверяет, имеет ли пользователь доступ к указанной странице на основе его ролей.
    /// Администраторы имеют доступ ко всем страницам.
    /// Пользователи с ролью User имеют доступ только к страницам "Мои клиенты" и главной.
    /// Пользователи с ролью Operator имеют доступ только к страницам управления пользователями.
    /// Пользователи с обеими ролями (User и Operator) имеют доступ к страницам обеих групп.
    /// </summary>
    /// <param name="pagePath">Путь к странице для проверки доступа</param>
    /// <returns>True, если доступ разрешен, иначе False</returns>
    public bool HasAccessToPage(string pagePath)
    {
        if (string.IsNullOrWhiteSpace(pagePath))
        {
            _logger.LogWarning("Попытка проверить доступ к странице с пустым путем");
            return false;
        }
        
        // Валидация длины пути
        if (pagePath.Length > MaxPathLength)
        {
            _logger.LogWarning("Попытка проверить доступ к странице с слишком длинным путем: {Length} символов", 
                pagePath.Length);
            return false;
        }
        
        // Проверка на path traversal и другие небезопасные последовательности
        if (!IsValidPath(pagePath))
        {
            _logger.LogWarning("Попытка проверить доступ к невалидному пути: {Path}", pagePath);
            return false;
        }
        
        var user = GetCurrentUser();
        if (!IsAuthenticated() || user == null)
        {
            return false;
        }
        
        // Нормализуем путь: удаляем query string и fragment
        var normalizedPath = NormalizePagePath(pagePath);
        
        // Проверка результата нормализации
        if (string.IsNullOrEmpty(normalizedPath))
        {
            _logger.LogWarning("Нормализация пути привела к пустой строке: {Path}", pagePath);
            return false;
        }
        
        // Используем кэшированные результаты проверки ролей для оптимизации производительности
        EnsureRoleCache();
        
        if (_cachedIsAdmin == true)
        {
            if (_logger.IsEnabled(LogLevel.Debug))
            {
                _logger.LogDebug("Администратор {UserName} имеет доступ к странице {PagePath}", 
                    user.Identity?.Name, pagePath);
            }
            return true;
        }
        
        bool hasAccess = false;
        
        // Если пользователь имеет обе роли, проверяем доступ к обеим группам страниц
        if (_cachedIsUser == true && _cachedIsOperator == true)
        {
            hasAccess = IsUserPageAccessible(normalizedPath) || IsOperatorPageAccessible(normalizedPath);
        }
        // Если только assistant-user - только "Мои клиенты"
        else if (_cachedIsUser == true)
        {
            hasAccess = IsUserPageAccessible(normalizedPath);
        }
        // Если только assistant-operator - только user-management
        else if (_cachedIsOperator == true)
        {
            hasAccess = IsOperatorPageAccessible(normalizedPath);
        }
        
        if (!hasAccess && _logger.IsEnabled(LogLevel.Debug))
        {
            _logger.LogDebug("Пользователь {UserName} не имеет доступа к странице {PagePath}", 
                user.Identity?.Name, pagePath);
        }
        
        return hasAccess;
    }
    
    /// <summary>
    /// Проверяет, имеет ли пользователь с ролью User доступ к указанной странице.
    /// Использует HashSet для оптимизации производительности (O(1) поиск).
    /// </summary>
    /// <param name="normalizedPath">Нормализованный путь к странице (в нижнем регистре)</param>
    /// <returns>True, если доступ разрешен</returns>
    private static bool IsUserPageAccessible(string normalizedPath)
    {
        return UserAllowedPages.Contains(normalizedPath);
    }
    
    /// <summary>
    /// Проверяет, имеет ли пользователь с ролью Operator доступ к указанной странице.
    /// Использует HashSet для оптимизации производительности (O(1) поиск).
    /// </summary>
    /// <param name="normalizedPath">Нормализованный путь к странице (в нижнем регистре)</param>
    /// <returns>True, если доступ разрешен</returns>
    private static bool IsOperatorPageAccessible(string normalizedPath)
    {
        return OperatorAllowedPages.Contains(normalizedPath);
    }
}
