using System.Data;
using Microsoft.Data.Sqlite;
using new_assistant.Configuration;
using new_assistant.Core.Entities;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Репозиторий для управления связями клиентов и Wiki страниц в SQLite
/// </summary>
public class WikiPageRepository : IWikiPageRepository
{
    private readonly string _connectionString;
    private readonly ILogger<WikiPageRepository> _logger;
    private readonly Lazy<Task> _initializeTask;
    private const string DatabaseName = "wiki_pages";
    
    // Максимальное количество записей для методов без пагинации (проблема #4, #20)
    private const int MaxRecordsWithoutPagination = 10000;
    
    // Размер батча для массовых обновлений (проблема #8)
    private const int BatchSize = 1000;

    public WikiPageRepository(DataPathsSettings dataPathsSettings, ILogger<WikiPageRepository> logger)
    {
        var dbPath = dataPathsSettings.GetWikiPagesDbPath();
        _connectionString = $"Data Source={dbPath};Mode=ReadWriteCreate;Cache=Shared;Pooling=True";
        _logger = logger;
        
        // Lazy initialization - БД инициализируется только при первом использовании
        _initializeTask = new Lazy<Task>(() => InitializeDatabaseAsync());
    }

    /// <summary>
    /// Асинхронная инициализация базы данных (вызывается автоматически при первом использовании)
    /// </summary>
    private async Task InitializeDatabaseAsync()
    {
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            // Проблема #10: Улучшенная обработка исключений подключения
            try
            {
                await connection.OpenAsync().ConfigureAwait(false);
            }
            catch (SqliteException ex)
            {
                _logger.LogError(ex, 
                    "Failed to open database connection during initialization: {ErrorCode}", 
                    ex.SqliteErrorCode);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, 
                    "Unexpected error opening database connection during initialization");
                throw;
            }

            await using var command = connection.CreateCommand();
            command.CommandText = @"
                CREATE TABLE IF NOT EXISTS client_wiki_pages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    client_id TEXT NOT NULL,
                    realm TEXT NOT NULL DEFAULT 'GLOBAL',
                    wiki_page_id TEXT NOT NULL,
                    wiki_page_title TEXT NOT NULL,
                    wiki_page_url TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'Active',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    created_by TEXT NOT NULL,
                    page_version INTEGER NOT NULL DEFAULT 1,
                    UNIQUE(client_id, realm)
                );

                CREATE INDEX IF NOT EXISTS idx_wiki_client_realm ON client_wiki_pages(client_id, realm);
                CREATE INDEX IF NOT EXISTS idx_wiki_page_id ON client_wiki_pages(wiki_page_id);
                CREATE INDEX IF NOT EXISTS idx_wiki_status ON client_wiki_pages(status);
                CREATE INDEX IF NOT EXISTS idx_wiki_updated_at ON client_wiki_pages(updated_at DESC);
            ";
            await command.ExecuteNonQueryAsync().ConfigureAwait(false);
            
            _logger.LogDebug("База данных wiki_pages успешно инициализирована");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка инициализации базы данных wiki_pages");
            throw;
        }
    }

    /// <summary>
    /// Гарантирует, что БД инициализирована перед выполнением операции
    /// </summary>
    private async Task EnsureInitializedAsync()
    {
        await _initializeTask.Value.ConfigureAwait(false);
    }

    /// <summary>
    /// Нормализует значение realm (пустое значение заменяется на "GLOBAL")
    /// </summary>
    private static string NormalizeRealm(string? realm)
    {
        var normalized = string.IsNullOrWhiteSpace(realm) ? "GLOBAL" : realm.Trim();
        // Проблема #22: Проверка максимальной длины после нормализации
        if (normalized.Length > 255)
        {
            throw new ArgumentException("Realm exceeds maximum length of 255 after normalization", nameof(realm));
        }
        return normalized;
    }
    
    /// <summary>
    /// Оптимизированное форматирование даты в ISO 8601 формат (проблема #1, #3)
    /// Использует более эффективный метод вместо ToString("O")
    /// </summary>
    private static string FormatDateTimeUtc(DateTime dateTime)
    {
        // Используем более эффективный метод форматирования
        return dateTime.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ", System.Globalization.CultureInfo.InvariantCulture);
    }
    
    /// <summary>
    /// Получить текущее время в UTC в отформатированном виде
    /// </summary>
    private static string GetCurrentUtcTimeString() => FormatDateTimeUtc(DateTime.UtcNow);

    /// <summary>
    /// Допустимые значения статуса Wiki страницы
    /// </summary>
    private static readonly HashSet<string> ValidStatuses = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
    {
        "Active",
        "Archived",
        "Failed"
    };
    
    // Кэш для строки с допустимыми статусами (проблема #13)
    private static readonly string ValidStatusesString = string.Join(", ", ValidStatuses);

    /// <summary>
    /// Валидация объекта ClientWikiPage перед операциями с БД
    /// </summary>
    private void ValidateWikiPage(ClientWikiPage wikiPage)
    {
        ArgumentNullException.ThrowIfNull(wikiPage);
        
        if (string.IsNullOrWhiteSpace(wikiPage.ClientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(wikiPage));
        
        if (string.IsNullOrWhiteSpace(wikiPage.WikiPageId))
            throw new ArgumentException("WikiPageId cannot be null or empty", nameof(wikiPage));
        
        if (string.IsNullOrWhiteSpace(wikiPage.WikiPageTitle))
            throw new ArgumentException("WikiPageTitle cannot be null or empty", nameof(wikiPage));
        
        if (string.IsNullOrWhiteSpace(wikiPage.WikiPageUrl))
            throw new ArgumentException("WikiPageUrl cannot be null or empty", nameof(wikiPage));
        
        if (string.IsNullOrWhiteSpace(wikiPage.CreatedBy))
            throw new ArgumentException("CreatedBy cannot be null or empty", nameof(wikiPage));
        
        // Проблема #14: Валидация после нормализации realm
        var normalizedRealm = NormalizeRealm(wikiPage.Realm);
        if (normalizedRealm != wikiPage.Realm)
        {
            // Обновляем realm на нормализованное значение
            wikiPage.Realm = normalizedRealm;
        }
        
        // Проверка длины строк согласно атрибутам Entity
        if (wikiPage.ClientId.Length > 255)
            throw new ArgumentException("ClientId exceeds maximum length of 255", nameof(wikiPage));
        
        if (wikiPage.Realm.Length > 255)
            throw new ArgumentException("Realm exceeds maximum length of 255", nameof(wikiPage));
        
        if (wikiPage.WikiPageId.Length > 50)
            throw new ArgumentException("WikiPageId exceeds maximum length of 50", nameof(wikiPage));
        
        if (wikiPage.WikiPageTitle.Length > 500)
            throw new ArgumentException("WikiPageTitle exceeds maximum length of 500", nameof(wikiPage));
        
        if (wikiPage.WikiPageUrl.Length > 1000)
            throw new ArgumentException("WikiPageUrl exceeds maximum length of 1000", nameof(wikiPage));
        
        if (wikiPage.CreatedBy.Length > 255)
            throw new ArgumentException("CreatedBy exceeds maximum length of 255", nameof(wikiPage));
        
        // Валидация статуса
        ValidateStatus(wikiPage.Status);
    }

    /// <summary>
    /// Валидация статуса Wiki страницы
    /// </summary>
    private void ValidateStatus(string status)
    {
        if (string.IsNullOrWhiteSpace(status))
            throw new ArgumentException("Status cannot be null or empty", nameof(status));
        
        if (status.Length > 50)
            throw new ArgumentException("Status exceeds maximum length of 50", nameof(status));
        
        if (!ValidStatuses.Contains(status))
        {
            // Проблема #13: Используем кэшированную строку вместо string.Join
            throw new ArgumentException(
                $"Status '{status}' is not valid. Valid values are: {ValidStatusesString}", 
                nameof(status));
        }
    }

    /// <summary>
    /// Добавляет строковый параметр к команде SQLite
    /// </summary>
    private static void AddStringParameter(SqliteCommand command, string name, string? value)
    {
        var param = command.CreateParameter();
        param.ParameterName = name;
        param.Value = string.IsNullOrWhiteSpace(value) ? (object)DBNull.Value : value;
        param.DbType = DbType.String;
        command.Parameters.Add(param);
    }

    /// <summary>
    /// Добавляет целочисленный параметр к команде SQLite
    /// </summary>
    private static void AddIntParameter(SqliteCommand command, string name, int value)
    {
        var param = command.CreateParameter();
        param.ParameterName = name;
        param.Value = value;
        param.DbType = DbType.Int32;
        command.Parameters.Add(param);
    }

    /// <summary>
    /// Безопасное чтение DateTime из reader с обработкой ошибок
    /// </summary>
    private DateTime SafeParseDateTime(SqliteDataReader reader, int ordinal, string clientId, string fieldName)
    {
        if (reader.IsDBNull(ordinal))
        {
            _logger.LogWarning(
                "Null {FieldName} for client {ClientId}, using current UTC time as fallback", 
                fieldName, clientId);
            return DateTime.UtcNow;
        }

        var dateTimeStr = reader.GetString(ordinal);
        if (DateTime.TryParse(dateTimeStr, null, System.Globalization.DateTimeStyles.RoundtripKind, out var dateTime))
        {
            return dateTime;
        }

        _logger.LogWarning(
            "Invalid {FieldName} format for client {ClientId}: {Value}, using current UTC time as fallback", 
            fieldName, clientId, dateTimeStr);
        return DateTime.UtcNow;
    }

    /// <summary>
    /// Безопасное чтение строки из reader с обработкой null
    /// </summary>
    private static string SafeGetString(SqliteDataReader reader, int ordinal) => 
        reader.IsDBNull(ordinal) ? string.Empty : reader.GetString(ordinal);

    /// <summary>
    /// Безопасное чтение int из reader с обработкой null
    /// </summary>
    private static int SafeGetInt32(SqliteDataReader reader, int ordinal, int defaultValue = 0)
    {
        if (reader.IsDBNull(ordinal))
        {
            return defaultValue;
        }
        return reader.GetInt32(ordinal);
    }

    /// <summary>
    /// Создает объект ClientWikiPage из SqliteDataReader
    /// Проблема #12, #27: Улучшена обработка обязательных полей
    /// </summary>
    private ClientWikiPage MapReaderToWikiPage(SqliteDataReader reader)
    {
        var clientIdValue = SafeGetString(reader, 1);
        var wikiPageId = SafeGetString(reader, 3);
        var wikiPageTitle = SafeGetString(reader, 4);
        var wikiPageUrl = SafeGetString(reader, 5);
        var createdBy = SafeGetString(reader, 9);
        
        // Проблема #12, #27: Проверка обязательных полей
        if (string.IsNullOrWhiteSpace(clientIdValue))
            throw new InvalidOperationException("ClientId is required but was null or empty in database");
        if (string.IsNullOrWhiteSpace(wikiPageId))
            throw new InvalidOperationException("WikiPageId is required but was null or empty in database");
        if (string.IsNullOrWhiteSpace(wikiPageTitle))
            throw new InvalidOperationException("WikiPageTitle is required but was null or empty in database");
        if (string.IsNullOrWhiteSpace(wikiPageUrl))
            throw new InvalidOperationException("WikiPageUrl is required but was null or empty in database");
        if (string.IsNullOrWhiteSpace(createdBy))
            throw new InvalidOperationException("CreatedBy is required but was null or empty in database");
        
        var id = SafeGetInt32(reader, 0, 0);
        // Проблема #27: Проверка обязательного поля Id
        if (id <= 0)
            throw new InvalidOperationException("Id is required but was invalid in database");
        
        return new ClientWikiPage
        {
            Id = id,
            ClientId = clientIdValue,
            Realm = SafeGetString(reader, 2),
            WikiPageId = wikiPageId,
            WikiPageTitle = wikiPageTitle,
            WikiPageUrl = wikiPageUrl,
            Status = SafeGetString(reader, 6),
            CreatedAt = SafeParseDateTime(reader, 7, clientIdValue, "CreatedAt"),
            UpdatedAt = SafeParseDateTime(reader, 8, clientIdValue, "UpdatedAt"),
            CreatedBy = createdBy,
            PageVersion = SafeGetInt32(reader, 10, 1)
        };
    }

    /// <summary>
    /// Безопасное преобразование результата ExecuteScalarAsync в int с проверкой на переполнение
    /// Проблема #2: Улучшена обработка отрицательных значений
    /// </summary>
    private int SafeConvertToInt32(object? result, string context)
    {
        if (result == null || result == DBNull.Value)
        {
            _logger.LogError("{Context} returned null value", context);
            throw new InvalidOperationException($"{context} returned null value");
        }

        if (result is int intResult)
        {
            // Проблема #2: Явная проверка на отрицательные значения для COUNT операций
            if (intResult < 0)
            {
                _logger.LogWarning("{Context} returned negative value: {Value}, treating as 0", context, intResult);
                return 0;
            }
            return intResult;
        }

        if (result is long longResult)
        {
            if (longResult > int.MaxValue || longResult < int.MinValue)
            {
                _logger.LogError("{Context} value overflow: {Value}", context, longResult);
                throw new OverflowException($"{context} value {longResult} exceeds int range");
            }
            var intValue = (int)longResult;
            // Проблема #2: Явная проверка на отрицательные значения
            if (intValue < 0)
            {
                _logger.LogWarning("{Context} returned negative value: {Value}, treating as 0", context, intValue);
                return 0;
            }
            return intValue;
        }

        _logger.LogError("{Context} unexpected return type: {Type}", context, result.GetType());
        throw new InvalidOperationException($"{context} unexpected return type: {result.GetType()}");
    }

    public async Task<int> SaveWikiPageAsync(ClientWikiPage wikiPage)
    {
        // Пункт 2: Валидация входных параметров
        ValidateWikiPage(wikiPage);
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        
        try
        {
            // Пункт 8: Использование транзакции для атомарности операции
            await using var connection = new SqliteConnection(_connectionString);
            // Проблема #10: Улучшенная обработка исключений подключения
            try
            {
                await connection.OpenAsync().ConfigureAwait(false);
            }
            catch (SqliteException ex)
            {
                _logger.LogError(ex, 
                    "Failed to open database connection while saving wiki page for client {ClientId}: {ErrorCode}", 
                    wikiPage.ClientId, ex.SqliteErrorCode);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, 
                    "Unexpected error opening database connection while saving wiki page for client {ClientId}", 
                    wikiPage.ClientId);
                throw;
            }
            
            await using var transaction = (SqliteTransaction)await connection.BeginTransactionAsync();
            try
            {
                var command = connection.CreateCommand();
                command.Transaction = transaction;
                command.CommandText = @"
                    INSERT INTO client_wiki_pages 
                    (client_id, realm, wiki_page_id, wiki_page_title, wiki_page_url, status, created_at, updated_at, created_by, page_version)
                    VALUES 
                    (@clientId, @realm, @wikiPageId, @wikiPageTitle, @wikiPageUrl, @status, @createdAt, @updatedAt, @createdBy, @pageVersion)
                    RETURNING id";

                // Пункт 6: Типизированные параметры вместо AddWithValue
                // Проблема #16: Проверка на существование записи перед вставкой
                var normalizedRealm = NormalizeRealm(wikiPage.Realm);
                var existsCommand = connection.CreateCommand();
                existsCommand.Transaction = transaction;
                existsCommand.CommandText = @"
                    SELECT COUNT(1)
                    FROM client_wiki_pages
                    WHERE client_id = @clientId AND realm = @realm";
                AddStringParameter(existsCommand, "@clientId", wikiPage.ClientId);
                AddStringParameter(existsCommand, "@realm", normalizedRealm);
                var existsResult = await existsCommand.ExecuteScalarAsync();
                if (SafeConvertToInt32(existsResult, "CheckDuplicate") > 0)
                {
                    throw new InvalidOperationException(
                        $"Wiki page already exists for client {wikiPage.ClientId} in realm {normalizedRealm}");
                }
                
                var currentTime = GetCurrentUtcTimeString();
                AddStringParameter(command, "@clientId", wikiPage.ClientId);
                AddStringParameter(command, "@realm", normalizedRealm);
                AddStringParameter(command, "@wikiPageId", wikiPage.WikiPageId);
                AddStringParameter(command, "@wikiPageTitle", wikiPage.WikiPageTitle);
                AddStringParameter(command, "@wikiPageUrl", wikiPage.WikiPageUrl);
                AddStringParameter(command, "@status", wikiPage.Status);
                AddStringParameter(command, "@createdAt", currentTime);
                AddStringParameter(command, "@updatedAt", currentTime);
                AddStringParameter(command, "@createdBy", wikiPage.CreatedBy);
                AddIntParameter(command, "@pageVersion", wikiPage.PageVersion);

                var result = await command.ExecuteScalarAsync();
                
                // Использование SafeConvertToInt32 вместо дублирования логики
                var id = SafeConvertToInt32(result, "SaveWikiPageAsync");

                await transaction.CommitAsync();
                return id;
            }
            catch
            {
                // Улучшенная обработка ошибок транзакции
                try
                {
                    await transaction.RollbackAsync();
                }
                catch (Exception rollbackEx)
                {
                    // Проблема #18: Улучшенная обработка ошибок rollback
                    _logger.LogError(rollbackEx, 
                        "Critical error during transaction rollback in SaveWikiPageAsync for client {ClientId}. " +
                        "Database may be in inconsistent state.", 
                        wikiPage.ClientId);
                    // Не пробрасываем исключение rollback, чтобы не скрыть оригинальную ошибку
                }
                throw;
            }
        }
        catch (SqliteException ex) when (ex.SqliteErrorCode == 19) // UNIQUE constraint
        {
            // Пункт 3: Обработка специфичных исключений SQLite
            _logger.LogWarning(ex, 
                "Attempted to insert duplicate wiki page for client {ClientId} in realm {Realm}", 
                wikiPage.ClientId, NormalizeRealm(wikiPage.Realm));
            throw new InvalidOperationException(
                $"Wiki page already exists for client {wikiPage.ClientId} in realm {NormalizeRealm(wikiPage.Realm)}", ex);
        }
        catch (SqliteException ex)
        {
            _logger.LogError(ex, 
                "SQLite error while saving wiki page for client {ClientId}: {ErrorCode}", 
                wikiPage.ClientId, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, 
                "Unexpected error while saving wiki page for client {ClientId}", 
                wikiPage.ClientId);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    public Task<ClientWikiPage?> GetWikiPageByClientAsync(string clientId, string realm)
    {
        // realm игнорируется — ссылка уникальна для клиента
        return GetWikiPageAnyRealmAsync(clientId);
    }

    public async Task<ClientWikiPage?> GetWikiPageAnyRealmAsync(string clientId)
    {
        // Пункт 2: Валидация входных параметров
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        // Пункт 1: Исправление stopwatch - использование try-finally
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            // Проблема #10: Улучшенная обработка исключений подключения
            try
            {
                await connection.OpenAsync().ConfigureAwait(false);
            }
            catch (SqliteException ex)
            {
                _logger.LogError(ex, 
                    "Failed to open database connection while getting wiki page for client {ClientId}: {ErrorCode}", 
                    clientId, ex.SqliteErrorCode);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, 
                    "Unexpected error opening database connection while getting wiki page for client {ClientId}", 
                    clientId);
                throw;
            }

            var command = connection.CreateCommand();
            command.CommandText = @"
                SELECT id, client_id, realm, wiki_page_id, wiki_page_title, wiki_page_url, 
                       status, created_at, updated_at, created_by, page_version
                FROM client_wiki_pages
                WHERE client_id = @clientId
                ORDER BY updated_at DESC
                LIMIT 1";

            AddStringParameter(command, "@clientId", clientId);

            await using var reader = await command.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                // Использование MapReaderToWikiPage для устранения дублирования
                return MapReaderToWikiPage(reader);
            }
            
            return null;
        }
        catch (SqliteException ex)
        {
            // Пункт 3: Обработка исключений
            _logger.LogError(ex, 
                "SQLite error while getting wiki page for client {ClientId}: {ErrorCode}", 
                clientId, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, 
                "Unexpected error while getting wiki page for client {ClientId}", 
                clientId);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    public async Task UpdateWikiPageAsync(ClientWikiPage wikiPage)
    {
        // Пункт 2: Валидация входных параметров
        ValidateWikiPage(wikiPage);
        
        if (wikiPage.Id <= 0)
            throw new ArgumentException("WikiPage Id must be greater than 0", nameof(wikiPage));
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            // Проблема #10: Улучшенная обработка исключений подключения
            try
            {
                await connection.OpenAsync().ConfigureAwait(false);
            }
            catch (SqliteException ex)
            {
                _logger.LogError(ex, 
                    "Failed to open database connection while updating wiki page with id {Id}: {ErrorCode}", 
                    wikiPage.Id, ex.SqliteErrorCode);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, 
                    "Unexpected error opening database connection while updating wiki page with id {Id}", 
                    wikiPage.Id);
                throw;
            }

            var command = connection.CreateCommand();
            command.CommandText = @"
                UPDATE client_wiki_pages
                SET realm = @realm,
                    wiki_page_id = @wikiPageId,
                    wiki_page_title = @wikiPageTitle,
                    wiki_page_url = @wikiPageUrl,
                    status = @status,
                    updated_at = @updatedAt,
                    page_version = @pageVersion
                WHERE id = @id";

            // Пункт 6: Типизированные параметры
            AddIntParameter(command, "@id", wikiPage.Id);
            AddStringParameter(command, "@realm", NormalizeRealm(wikiPage.Realm));
            AddStringParameter(command, "@wikiPageId", wikiPage.WikiPageId);
            AddStringParameter(command, "@wikiPageTitle", wikiPage.WikiPageTitle);
            AddStringParameter(command, "@wikiPageUrl", wikiPage.WikiPageUrl);
            AddStringParameter(command, "@status", wikiPage.Status);
            AddStringParameter(command, "@updatedAt", GetCurrentUtcTimeString());
            AddIntParameter(command, "@pageVersion", wikiPage.PageVersion);

            var rowsAffected = await command.ExecuteNonQueryAsync();
            
            // Пункт 5: Проверка существования записи перед обновлением
            if (rowsAffected == 0)
            {
                _logger.LogWarning(
                    "No wiki page found with id {Id} to update", 
                    wikiPage.Id);
                throw new InvalidOperationException(
                    $"Wiki page with id {wikiPage.Id} not found");
            }
        }
        catch (SqliteException ex)
        {
            // Пункт 3: Обработка исключений
            _logger.LogError(ex, 
                "SQLite error while updating wiki page with id {Id}: {ErrorCode}", 
                wikiPage.Id, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, 
                "Unexpected error while updating wiki page with id {Id}", 
                wikiPage.Id);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    public async Task UpdateWikiPageStatusAsync(string clientId, string realm, string status)
    {
        // Пункт 2: Валидация входных параметров
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        
        // Валидация статуса
        ValidateStatus(status);
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            // Проблема #10: Улучшенная обработка исключений подключения
            try
            {
                await connection.OpenAsync().ConfigureAwait(false);
            }
            catch (SqliteException ex)
            {
                _logger.LogError(ex, 
                    "Failed to open database connection while getting wiki page for client {ClientId}: {ErrorCode}", 
                    clientId, ex.SqliteErrorCode);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, 
                    "Unexpected error opening database connection while getting wiki page for client {ClientId}", 
                    clientId);
                throw;
            }

            var command = connection.CreateCommand();
            // Пункт 4: Исправление использования параметра realm
            command.CommandText = @"
                UPDATE client_wiki_pages
                SET status = @status,
                    updated_at = @updatedAt
                WHERE client_id = @clientId AND realm = @realm";

            var normalizedRealm = NormalizeRealm(realm);
            AddStringParameter(command, "@realm", normalizedRealm);
            AddStringParameter(command, "@status", status);
            AddStringParameter(command, "@updatedAt", GetCurrentUtcTimeString());
            AddStringParameter(command, "@clientId", clientId);

            var rowsAffected = await command.ExecuteNonQueryAsync();
            
            if (rowsAffected == 0)
            {
                _logger.LogWarning(
                    "No wiki page found to update for client {ClientId} in realm {Realm}", 
                    clientId, normalizedRealm);
            }
        }
        catch (SqliteException ex)
        {
            // Пункт 3: Обработка исключений
            _logger.LogError(ex, 
                "SQLite error while updating wiki page status for client {ClientId}: {ErrorCode}", 
                clientId, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, 
                "Unexpected error while updating wiki page status for client {ClientId}", 
                clientId);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    public async Task DeleteWikiPageAsync(string clientId, string realm)
    {
        // Пункт 2: Валидация входных параметров
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            // Проблема #10: Улучшенная обработка исключений подключения
            try
            {
                await connection.OpenAsync().ConfigureAwait(false);
            }
            catch (SqliteException ex)
            {
                _logger.LogError(ex, 
                    "Failed to open database connection while getting wiki page for client {ClientId}: {ErrorCode}", 
                    clientId, ex.SqliteErrorCode);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, 
                    "Unexpected error opening database connection while getting wiki page for client {ClientId}", 
                    clientId);
                throw;
            }

            var command = connection.CreateCommand();
            // Пункт 4: Исправление использования параметра realm
            command.CommandText = @"
                DELETE FROM client_wiki_pages
                WHERE client_id = @clientId AND realm = @realm";

            var normalizedRealm = NormalizeRealm(realm);
            AddStringParameter(command, "@clientId", clientId);
            AddStringParameter(command, "@realm", normalizedRealm);

            var rowsAffected = await command.ExecuteNonQueryAsync();
            
            if (rowsAffected == 0)
            {
                _logger.LogWarning(
                    "No wiki page found to delete for client {ClientId} in realm {Realm}", 
                    clientId, normalizedRealm);
            }
        }
        catch (SqliteException ex)
        {
            // Пункт 3: Обработка исключений
            _logger.LogError(ex, 
                "SQLite error while deleting wiki page for client {ClientId}: {ErrorCode}", 
                clientId, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, 
                "Unexpected error while deleting wiki page for client {ClientId}", 
                clientId);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    public async Task<bool> WikiPageExistsAsync(string clientId, string realm)
    {
        // Пункт 2: Валидация входных параметров
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            // Проблема #10: Улучшенная обработка исключений подключения
            try
            {
                await connection.OpenAsync().ConfigureAwait(false);
            }
            catch (SqliteException ex)
            {
                _logger.LogError(ex, 
                    "Failed to open database connection while getting wiki page for client {ClientId}: {ErrorCode}", 
                    clientId, ex.SqliteErrorCode);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, 
                    "Unexpected error opening database connection while getting wiki page for client {ClientId}", 
                    clientId);
                throw;
            }

            var command = connection.CreateCommand();
            // Пункт 4: Исправление использования параметра realm
            command.CommandText = @"
                SELECT COUNT(1)
                FROM client_wiki_pages
                WHERE client_id = @clientId AND realm = @realm";

            var normalizedRealm = NormalizeRealm(realm);
            AddStringParameter(command, "@clientId", clientId);
            AddStringParameter(command, "@realm", normalizedRealm);

            var result = await command.ExecuteScalarAsync();
            // Пункт 11: Безопасное преобразование с проверкой на переполнение
            return SafeConvertToInt32(result, "WikiPageExistsAsync") > 0;
        }
        catch (SqliteException ex)
        {
            // Пункт 3: Обработка исключений
            _logger.LogError(ex, 
                "SQLite error while checking wiki page existence for client {ClientId}: {ErrorCode}", 
                clientId, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, 
                "Unexpected error while checking wiki page existence for client {ClientId}", 
                clientId);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Проверить, существует ли Wiki страница по id
    /// </summary>
    /// <param name="id">Идентификатор записи</param>
    /// <returns>True, если запись существует</returns>
    public async Task<bool> WikiPageExistsByIdAsync(int id)
    {
        // Пункт 13: Метод для проверки существования по id
        if (id <= 0)
            return false;
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            // Проблема #10: Улучшенная обработка исключений подключения
            try
            {
                await connection.OpenAsync().ConfigureAwait(false);
            }
            catch (SqliteException ex)
            {
                _logger.LogError(ex, 
                    "Failed to open database connection while checking wiki page existence by id {Id}: {ErrorCode}", 
                    id, ex.SqliteErrorCode);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, 
                    "Unexpected error opening database connection while checking wiki page existence by id {Id}", 
                    id);
                throw;
            }

            var command = connection.CreateCommand();
            command.CommandText = "SELECT COUNT(1) FROM client_wiki_pages WHERE id = @id";
            AddIntParameter(command, "@id", id);

            var result = await command.ExecuteScalarAsync();
            return SafeConvertToInt32(result, "WikiPageExistsByIdAsync") > 0;
        }
        catch (SqliteException ex)
        {
            _logger.LogError(ex, 
                "SQLite error while checking wiki page existence by id {Id}: {ErrorCode}", 
                id, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error checking wiki page existence by id {Id}", id);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Получить все Wiki страницы для указанного realm
    /// </summary>
    /// <param name="realm">Realm для поиска</param>
    /// <returns>Список Wiki страниц</returns>
    public async Task<List<ClientWikiPage>> GetWikiPagesByRealmAsync(string realm)
    {
        // Пункт 14: Метод для получения всех записей по realm
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        // Проблема #5: Оптимизация создания списка с предварительной оценкой размера
        // Проблема #20: Ограничение на максимальное количество записей
        var pages = new List<ClientWikiPage>(Math.Min(1000, MaxRecordsWithoutPagination));
        
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            // Проблема #10: Улучшенная обработка исключений подключения
            try
            {
                await connection.OpenAsync().ConfigureAwait(false);
            }
            catch (SqliteException ex)
            {
                _logger.LogError(ex, 
                    "Failed to open database connection while getting wiki pages for realm {Realm}: {ErrorCode}", 
                    realm, ex.SqliteErrorCode);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, 
                    "Unexpected error opening database connection while getting wiki pages for realm {Realm}", 
                    realm);
                throw;
            }

            var command = connection.CreateCommand();
            // Проблема #20: Добавлено ограничение на количество записей
            command.CommandText = @"
                SELECT id, client_id, realm, wiki_page_id, wiki_page_title, wiki_page_url, 
                       status, created_at, updated_at, created_by, page_version
                FROM client_wiki_pages
                WHERE realm = @realm
                ORDER BY updated_at DESC
                LIMIT @limit";
            
            AddStringParameter(command, "@realm", realm);
            AddIntParameter(command, "@limit", MaxRecordsWithoutPagination);

            await using var reader = await command.ExecuteReaderAsync();
            int count = 0;
            while (await reader.ReadAsync() && count < MaxRecordsWithoutPagination)
            {
                // Использование MapReaderToWikiPage для устранения дублирования
                pages.Add(MapReaderToWikiPage(reader));
                count++;
            }
            
            if (count >= MaxRecordsWithoutPagination)
            {
                _logger.LogWarning(
                    "GetWikiPagesByRealmAsync returned maximum number of records ({MaxRecords}) for realm {Realm}. " +
                    "There may be more records available.", 
                    MaxRecordsWithoutPagination, realm);
            }
            
            return pages;
        }
        catch (SqliteException ex)
        {
            _logger.LogError(ex, 
                "SQLite error while getting wiki pages for realm {Realm}: {ErrorCode}", 
                realm, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting wiki pages for realm {Realm}", realm);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Массовое обновление статуса Wiki страниц для указанного realm
    /// </summary>
    /// <param name="realm">Realm для обновления</param>
    /// <param name="status">Новый статус</param>
    /// <returns>Количество обновленных записей</returns>
    public async Task<int> UpdateWikiPagesStatusByRealmAsync(string realm, string status)
    {
        // Пункт 15: Метод для массового обновления статуса
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        // Валидация статуса
        ValidateStatus(status);
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            // Проблема #10: Улучшенная обработка исключений подключения
            try
            {
                await connection.OpenAsync().ConfigureAwait(false);
            }
            catch (SqliteException ex)
            {
                _logger.LogError(ex, 
                    "Failed to open database connection while updating wiki pages status for realm {Realm}: {ErrorCode}", 
                    realm, ex.SqliteErrorCode);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, 
                    "Unexpected error opening database connection while updating wiki pages status for realm {Realm}", 
                    realm);
                throw;
            }

            // Проблема #8: Батчинг для массовых обновлений
            int totalRowsAffected = 0;
            var currentTime = GetCurrentUtcTimeString();
            
            while (true)
            {
                var command = connection.CreateCommand();
                command.CommandText = @"
                    UPDATE client_wiki_pages
                    SET status = @status,
                        updated_at = @updatedAt
                    WHERE realm = @realm
                    AND id IN (
                        SELECT id FROM client_wiki_pages
                        WHERE realm = @realm
                        AND (status != @status OR updated_at != @updatedAt)
                        LIMIT @batchSize
                    )";

                AddStringParameter(command, "@realm", realm);
                AddStringParameter(command, "@status", status);
                AddStringParameter(command, "@updatedAt", currentTime);
                AddIntParameter(command, "@batchSize", BatchSize);

                var rowsAffected = await command.ExecuteNonQueryAsync();
                totalRowsAffected += rowsAffected;
                
                // Если обновлено меньше записей, чем размер батча, значит это последний батч
                if (rowsAffected < BatchSize)
                {
                    break;
                }
                
                // Небольшая задержка между батчами для снижения нагрузки на БД
                await Task.Delay(10).ConfigureAwait(false);
            }
            
            _logger.LogInformation(
                "Updated status to {Status} for {Count} wiki pages in realm {Realm}", 
                status, totalRowsAffected, realm);
            
            return totalRowsAffected;
        }
        catch (SqliteException ex)
        {
            _logger.LogError(ex, 
                "SQLite error while updating wiki pages status for realm {Realm}: {ErrorCode}", 
                realm, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating wiki pages status for realm {Realm}", realm);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Получить Wiki страницу по id
    /// </summary>
    /// <param name="id">Идентификатор записи</param>
    /// <returns>Wiki страница или null, если не найдена</returns>
    public async Task<ClientWikiPage?> GetWikiPageByIdAsync(int id)
    {
        if (id <= 0)
            throw new ArgumentException("Id must be greater than 0", nameof(id));
        
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            // Проблема #10: Улучшенная обработка исключений подключения
            try
            {
                await connection.OpenAsync().ConfigureAwait(false);
            }
            catch (SqliteException ex)
            {
                _logger.LogError(ex, 
                    "Failed to open database connection while getting wiki page by id {Id}: {ErrorCode}", 
                    id, ex.SqliteErrorCode);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, 
                    "Unexpected error opening database connection while getting wiki page by id {Id}", 
                    id);
                throw;
            }

            var command = connection.CreateCommand();
            command.CommandText = @"
                SELECT id, client_id, realm, wiki_page_id, wiki_page_title, wiki_page_url, 
                       status, created_at, updated_at, created_by, page_version
                FROM client_wiki_pages
                WHERE id = @id
                LIMIT 1";

            AddIntParameter(command, "@id", id);

            await using var reader = await command.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                return MapReaderToWikiPage(reader);
            }
            
            return null;
        }
        catch (SqliteException ex)
        {
            _logger.LogError(ex, 
                "SQLite error while getting wiki page by id {Id}: {ErrorCode}", 
                id, ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting wiki page by id {Id}", id);
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }

    /// <summary>
    /// Получить все Wiki страницы
    /// </summary>
    /// <returns>Список всех Wiki страниц</returns>
    public async Task<List<ClientWikiPage>> GetAllWikiPagesAsync()
    {
        await EnsureInitializedAsync().ConfigureAwait(false);
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        // Проблема #4, #5: Оптимизация создания списка с предварительной оценкой размера и ограничение
        var pages = new List<ClientWikiPage>(Math.Min(1000, MaxRecordsWithoutPagination));
        
        try
        {
            await using var connection = new SqliteConnection(_connectionString);
            // Проблема #10: Улучшенная обработка исключений подключения
            try
            {
                await connection.OpenAsync().ConfigureAwait(false);
            }
            catch (SqliteException ex)
            {
                _logger.LogError(ex, 
                    "Failed to open database connection while getting all wiki pages: {ErrorCode}", 
                    ex.SqliteErrorCode);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, 
                    "Unexpected error opening database connection while getting all wiki pages");
                throw;
            }

            var command = connection.CreateCommand();
            // Проблема #4: Добавлено ограничение на количество записей
            command.CommandText = @"
                SELECT id, client_id, realm, wiki_page_id, wiki_page_title, wiki_page_url, 
                       status, created_at, updated_at, created_by, page_version
                FROM client_wiki_pages
                ORDER BY updated_at DESC
                LIMIT @limit";
            
            AddIntParameter(command, "@limit", MaxRecordsWithoutPagination);

            await using var reader = await command.ExecuteReaderAsync();
            int count = 0;
            while (await reader.ReadAsync() && count < MaxRecordsWithoutPagination)
            {
                pages.Add(MapReaderToWikiPage(reader));
                count++;
            }
            
            if (count >= MaxRecordsWithoutPagination)
            {
                _logger.LogWarning(
                    "GetAllWikiPagesAsync returned maximum number of records ({MaxRecords}). " +
                    "There may be more records available.", 
                    MaxRecordsWithoutPagination);
            }
            
            return pages;
        }
        catch (SqliteException ex)
        {
            _logger.LogError(ex, "SQLite error while getting all wiki pages: {ErrorCode}", ex.SqliteErrorCode);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting all wiki pages");
            throw;
        }
        finally
        {
            stopwatch.Stop();
            SqlitePerformanceMonitor.RecordOperation(DatabaseName, stopwatch.ElapsedMilliseconds);
        }
    }
}
