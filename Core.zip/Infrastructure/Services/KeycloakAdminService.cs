using new_assistant.Core.Interfaces;
using new_assistant.Core.DTOs;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Фасад для работы с Keycloak Admin API
/// Делегирует вызовы специализированным сервисам
/// </summary>
public class KeycloakAdminService : IKeycloakAdminService
{
    /// <summary>
    /// Имя операции для метрик производительности Keycloak Admin API
    /// </summary>
    private const string MetricsOperationName = "Keycloak.AdminAPI";
    
    /// <summary>
    /// Имя операции для метрик самого сервиса KeycloakAdminService
    /// </summary>
    private const string ServiceMetricsOperationName = "KeycloakAdminService";

    private readonly IKeycloakClientManagementService _clientManagementService;
    private readonly IKeycloakClientSearchService _clientSearchService;
    private readonly IKeycloakClientDetailsService _clientDetailsService;
    private readonly IKeycloakClientEventsService _clientEventsService;
    private readonly IKeycloakRolesService _rolesService;
    private readonly IKeycloakUsersService _usersService;
    private readonly IKeycloakRealmService _realmService;
    private readonly IKeycloakTokenExamplesService _tokenExamplesService;
    private readonly IPerformanceMetricsService _metricsService;
    private readonly ILogger<KeycloakAdminService>? _logger;

    public KeycloakAdminService(
        IKeycloakClientManagementService clientManagementService,
        IKeycloakClientSearchService clientSearchService,
        IKeycloakClientDetailsService clientDetailsService,
        IKeycloakClientEventsService clientEventsService,
        IKeycloakRolesService rolesService,
        IKeycloakUsersService usersService,
        IKeycloakRealmService realmService,
        IKeycloakTokenExamplesService tokenExamplesService,
        IPerformanceMetricsService metricsService,
        ILogger<KeycloakAdminService>? logger = null)
    {
        _clientManagementService = ThrowIfNull(clientManagementService, nameof(clientManagementService));
        _clientSearchService = ThrowIfNull(clientSearchService, nameof(clientSearchService));
        _clientDetailsService = ThrowIfNull(clientDetailsService, nameof(clientDetailsService));
        _clientEventsService = ThrowIfNull(clientEventsService, nameof(clientEventsService));
        _rolesService = ThrowIfNull(rolesService, nameof(rolesService));
        _usersService = ThrowIfNull(usersService, nameof(usersService));
        _realmService = ThrowIfNull(realmService, nameof(realmService));
        _tokenExamplesService = ThrowIfNull(tokenExamplesService, nameof(tokenExamplesService));
        _metricsService = ThrowIfNull(metricsService, nameof(metricsService));
        _logger = logger;
        
        _logger?.LogDebug("KeycloakAdminService initialized successfully");
    }

    /// <summary>
    /// Вспомогательный метод для проверки на null и выбрасывания ArgumentNullException
    /// </summary>
    private static T ThrowIfNull<T>(T? value, string paramName) where T : class
    {
        return value ?? throw new ArgumentNullException(paramName);
    }

    // ========== Client Management ==========
    /// <summary>
    /// Создать нового клиента в Keycloak.
    /// </summary>
    /// <param name="request">Данные для создания клиента</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Внутренний ID созданного клиента</returns>
    public Task<string> CreateClientAsync(CreateClientRequestDto request, CancellationToken cancellationToken = default)
    {
        ValidateRequest(request, nameof(request));
        return ExecuteWithMetricsAsync(
            () => _clientManagementService.CreateClientAsync(request, cancellationToken),
            nameof(CreateClientAsync));
    }

    /// <summary>
    /// Обновить детали клиента в Keycloak.
    /// </summary>
    /// <param name="clientDetails">Детальная информация о клиенте для обновления</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    public Task UpdateClientDetailsAsync(ClientDetailsDto clientDetails, CancellationToken cancellationToken = default)
        => _clientManagementService.UpdateClientDetailsAsync(clientDetails, cancellationToken);

    /// <summary>
    /// Удалить клиента из Keycloak.
    /// </summary>
    /// <param name="clientId">Идентификатор клиента</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="internalId">Внутренний ID клиента (UUID)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    public Task DeleteClientAsync(string clientId, string realm, string internalId, CancellationToken cancellationToken = default)
    {
        ValidateStringParameter(clientId, nameof(clientId));
        ValidateStringParameter(realm, nameof(realm));
        ValidateStringParameter(internalId, nameof(internalId));
        return ExecuteWithMetricsAsync(
            () => _clientManagementService.DeleteClientAsync(clientId, realm, internalId, cancellationToken),
            nameof(DeleteClientAsync));
    }

    /// <summary>
    /// Сгенерировать новый секрет для клиента (с указанием realm и internal ID).
    /// </summary>
    /// <param name="clientId">Идентификатор клиента</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="internalId">Внутренний ID клиента (UUID)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Новый секрет клиента или null, если операция не удалась</returns>
    public Task<string?> RegenerateClientSecretAsync(string clientId, string realm, string internalId, CancellationToken cancellationToken = default)
        => _clientManagementService.RegenerateClientSecretAsync(clientId, realm, internalId, cancellationToken);

    // ========== Client Search ==========
    /// <summary>
    /// Поиск клиентов по подстроке во всех реалмах (кроме master).
    /// </summary>
    /// <param name="searchTerm">Поисковый запрос</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Результаты поиска клиентов</returns>
    public Task<ClientsSearchResponse> SearchClientsAsync(string searchTerm, CancellationToken cancellationToken = default)
        => _clientSearchService.SearchClientsAsync(searchTerm, cancellationToken);

    /// <summary>
    /// Поиск клиентов с отслеживанием прогресса.
    /// </summary>
    /// <param name="searchTerm">Поисковый запрос</param>
    /// <param name="progress">Объект для отслеживания прогресса поиска</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Результаты поиска клиентов</returns>
    public Task<ClientsSearchResponse> SearchClientsWithProgressAsync(
        string searchTerm,
        IProgress<SearchProgress> progress,
        CancellationToken cancellationToken = default)
        => _clientSearchService.SearchClientsWithProgressAsync(searchTerm, progress, cancellationToken);

    /// <summary>
    /// Поиск клиентов по Client ID (с опциональной фильтрацией по realm).
    /// </summary>
    /// <param name="searchTerm">Поисковый запрос</param>
    /// <param name="realm">Опциональное название реалма для фильтрации</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список найденных клиентов</returns>
    public Task<List<ClientSearchResult>> SearchClientsByIdAsync(string searchTerm, string? realm = null, CancellationToken cancellationToken = default)
        => _clientSearchService.SearchClientsByIdAsync(searchTerm, realm, cancellationToken);

    // ========== Client Details ==========
    /// <summary>
    /// Получить детальную информацию о клиенте.
    /// </summary>
    /// <param name="clientId">Идентификатор клиента</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Детальная информация о клиенте или null, если клиент не найден</returns>
    public Task<ClientDetailsDto?> GetClientDetailsAsync(string clientId, string realm, CancellationToken cancellationToken = default)
        => _clientDetailsService.GetClientDetailsAsync(clientId, realm, cancellationToken);

    /// <summary>
    /// Получить роли клиента (локальные и сервисные).
    /// </summary>
    /// <param name="clientId">Идентификатор клиента</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Кортеж с локальными и сервисными ролями клиента</returns>
    public Task<(List<string> LocalRoles, List<string> ServiceRoles)> GetClientRolesAsync(string clientId, string realm, CancellationToken cancellationToken = default)
        => _clientDetailsService.GetClientRolesAsync(clientId, realm, cancellationToken);

    /// <summary>
    /// Получить эндпоинты клиента.
    /// </summary>
    /// <param name="clientId">Идентификатор клиента</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список эндпоинтов клиента</returns>
    public Task<List<string>> GetClientEndpointsAsync(string clientId, string realm, CancellationToken cancellationToken = default)
        => _clientDetailsService.GetClientEndpointsAsync(clientId, realm, cancellationToken);

    /// <summary>
    /// Получить всех клиентов реалма в виде JsonElement.
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список клиентов в формате JsonElement</returns>
    public Task<List<System.Text.Json.JsonElement>> GetAllClientsAsJsonAsync(string realm, CancellationToken cancellationToken = default)
        => _clientDetailsService.GetAllClientsAsJsonAsync(realm, cancellationToken);

    // ========== Client Events ==========
    /// <summary>
    /// Загружает события клиента (для ленивой загрузки).
    /// </summary>
    /// <param name="clientId">Идентификатор клиента</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список событий клиента</returns>
    public Task<List<ClientEventDto>> LoadClientEventsAsync(string clientId, string realm, CancellationToken cancellationToken = default)
        => _clientEventsService.LoadClientEventsAsync(clientId, realm, cancellationToken);

    /// <summary>
    /// Получить события клиента.
    /// </summary>
    /// <param name="clientId">Идентификатор клиента</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Перечисление событий клиента</returns>
    public Task<IEnumerable<ClientEventDto>> GetClientEventsAsync(string clientId, string realm, CancellationToken cancellationToken = default)
        => _clientEventsService.GetClientEventsAsync(clientId, realm, cancellationToken);

    /// <summary>
    /// Получение событий клиента с пагинацией (first и max).
    /// </summary>
    /// <param name="clientId">Идентификатор клиента</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="first">Индекс первого элемента для пагинации</param>
    /// <param name="maxEvents">Максимальное количество событий для возврата</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Перечисление событий клиента</returns>
    public Task<IEnumerable<ClientEventDto>> GetClientEventsAsync(string clientId, string realm, int first, int maxEvents, CancellationToken cancellationToken = default)
        => _clientEventsService.GetClientEventsAsync(clientId, realm, first, maxEvents, cancellationToken);

    /// <summary>
    /// Получить все события клиента для фильтрации.
    /// </summary>
    /// <param name="clientId">Идентификатор клиента</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Перечисление всех событий клиента</returns>
    public Task<IEnumerable<ClientEventDto>> GetAllClientEventsAsync(string clientId, string realm, CancellationToken cancellationToken = default)
        => _clientEventsService.GetAllClientEventsAsync(clientId, realm, cancellationToken);

    /// <summary>
    /// Получить все возможные типы событий из реалма.
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Перечисление типов событий</returns>
    public Task<IEnumerable<string>> GetAllEventTypesAsync(string realm, CancellationToken cancellationToken = default)
        => _clientEventsService.GetAllEventTypesAsync(realm, cancellationToken);

    // ========== Roles ==========
    /// <summary>
    /// Синхронизировать локальные роли клиента с Keycloak.
    /// </summary>
    /// <param name="clientId">Идентификатор клиента</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="internalId">Внутренний ID клиента (UUID)</param>
    /// <param name="currentRoles">Текущий список ролей</param>
    /// <param name="newRoles">Новый список ролей для синхронизации</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    public Task SyncClientLocalRolesAsync(string clientId, string realm, string internalId, List<string> currentRoles, List<string> newRoles, CancellationToken cancellationToken = default)
        => _rolesService.SyncClientLocalRolesAsync(clientId, realm, internalId, currentRoles, newRoles, cancellationToken);

    /// <summary>
    /// Синхронизировать service account роли с Keycloak.
    /// </summary>
    /// <param name="clientId">Идентификатор клиента</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="internalId">Внутренний ID клиента (UUID)</param>
    /// <param name="currentRoles">Текущий список ролей</param>
    /// <param name="newRoles">Новый список ролей для синхронизации</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    public Task SyncServiceAccountRolesAsync(string clientId, string realm, string internalId, List<string> currentRoles, List<string> newRoles, CancellationToken cancellationToken = default)
        => _rolesService.SyncServiceAccountRolesAsync(clientId, realm, internalId, currentRoles, newRoles, cancellationToken);

    /// <summary>
    /// Поиск ролей для Service Account (realm + client roles).
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="searchTerm">Поисковый запрос</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Кортеж с найденными ролями и клиентами с ролями</returns>
    public Task<(List<RoleSearchResult> Roles, List<ClientWithRoles> Clients)> SearchRolesForServiceAccountAsync(string realm, string clientInternalId, string searchTerm, CancellationToken cancellationToken = default)
        => _rolesService.SearchRolesForServiceAccountAsync(realm, clientInternalId, searchTerm, cancellationToken);

    /// <summary>
    /// Поиск ролей для нового клиента (без clientInternalId).
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="searchTerm">Поисковый запрос</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Кортеж с найденными ролями и клиентами с ролями</returns>
    public Task<(List<RoleSearchResult> Roles, List<ClientWithRoles> Clients)> SearchRolesForNewClientAsync(string realm, string searchTerm, CancellationToken cancellationToken = default)
        => _rolesService.SearchRolesForNewClientAsync(realm, searchTerm, cancellationToken);

    // ========== Users ==========
    /// <summary>
    /// Найти пользователя по username в конкретном реалме.
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="username">Имя пользователя</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Данные пользователя в формате JsonElement или null, если пользователь не найден</returns>
    public Task<System.Text.Json.JsonElement?> GetUserByUsernameAsync(string realm, string username, CancellationToken cancellationToken = default)
        => _usersService.GetUserByUsernameAsync(realm, username, cancellationToken);

    /// <summary>
    /// Получить client role mappings для пользователя.
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="clientUuid">UUID клиента</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список ролей клиента для пользователя</returns>
    public Task<List<string>> GetUserClientRolesAsync(string realm, string userId, string clientUuid, CancellationToken cancellationToken = default)
        => _usersService.GetUserClientRolesAsync(realm, userId, clientUuid, cancellationToken);

    /// <summary>
    /// Поиск пользователей в KeyCloak по username.
    /// </summary>
    /// <param name="searchTerm">Поисковый запрос</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список найденных пользователей</returns>
    public Task<List<UserSearchResultDto>> SearchUsersAsync(string searchTerm, string realm, CancellationToken cancellationToken = default)
        => _usersService.SearchUsersAsync(searchTerm, realm, cancellationToken);

    /// <summary>
    /// Поиск пользователей по username в конкретном реалме.
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="username">Имя пользователя для поиска</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список найденных пользователей</returns>
    public Task<List<UserSearchResultDto>> SearchUsersByUsernameAsync(string realm, string username, CancellationToken cancellationToken = default)
        => _usersService.SearchUsersByUsernameAsync(realm, username, cancellationToken);

    // ========== Realms ==========
    /// <summary>
    /// Получить список всех реалмов (кроме master).
    /// </summary>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Перечисление названий реалмов</returns>
    public Task<IEnumerable<string>> GetRealmsListAsync(CancellationToken cancellationToken = default)
        => _realmService.GetRealmsListAsync(cancellationToken);

    /// <summary>
    /// Получить детальную информацию о всех реалмах (с Display Name).
    /// </summary>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список реалмов с детальной информацией</returns>
    public Task<IReadOnlyList<RealmDto>> GetRealmsWithDetailsAsync(CancellationToken cancellationToken = default)
        => _realmService.GetRealmsWithDetailsAsync(cancellationToken);

    // ========== Token Examples ==========
    /// <summary>
    /// Генерация example access token для пользователя.
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="scope">Опциональный scope для токена</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Пример access token в виде строки</returns>
    public Task<string> GenerateExampleAccessTokenAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default)
        => _tokenExamplesService.GenerateExampleAccessTokenAsync(realm, clientInternalId, userId, scope, cancellationToken);

    /// <summary>
    /// Генерация example ID token для пользователя.
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="scope">Опциональный scope для токена</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Пример ID token в виде строки</returns>
    public Task<string> GenerateExampleIdTokenAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default)
        => _tokenExamplesService.GenerateExampleIdTokenAsync(realm, clientInternalId, userId, scope, cancellationToken);

    /// <summary>
    /// Генерация example userinfo для пользователя.
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента (UUID)</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="scope">Опциональный scope для токена</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Пример userinfo в виде строки</returns>
    public Task<string> GenerateExampleUserInfoAsync(string realm, string clientInternalId, string userId, string? scope = null, CancellationToken cancellationToken = default)
        => _tokenExamplesService.GenerateExampleUserInfoAsync(realm, clientInternalId, userId, scope, cancellationToken);

    // ========== Performance Stats ==========
    /// <summary>
    /// Получить статистику производительности Keycloak.
    /// </summary>
    /// <returns>Кортеж с общей статистикой: общее время в миллисекундах, количество запросов, среднее время в миллисекундах</returns>
    public (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetPerformanceStats()
    {
        try
        {
            var metrics = _metricsService.GetMetrics(MetricsOperationName);
            
            // Обработка edge case: если метрики не найдены, GetMetrics возвращает пустой объект
            // Это нормальное поведение, но мы гарантируем корректные значения
            if (metrics == null)
            {
                _logger?.LogWarning("GetMetrics returned null for operation {OperationName}, returning zero values", MetricsOperationName);
                return (0, 0, 0);
            }
            
            return (metrics.TotalTimeMs, metrics.TotalCalls, metrics.AverageTimeMs);
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Error getting performance stats for operation {OperationName}", MetricsOperationName);
            // Возвращаем нулевые значения вместо выбрасывания исключения для более устойчивого поведения
            return (0, 0, 0);
        }
    }

    /// <summary>
    /// Сбросить статистику производительности Keycloak.
    /// </summary>
    /// <remarks>
    /// Внимание: Метод сбрасывает все метрики производительности в системе, а не только метрики Keycloak.
    /// Это связано с ограничениями интерфейса IPerformanceMetricsService, который не предоставляет
    /// возможность сброса метрик для конкретной операции.
    /// </remarks>
    public void ResetPerformanceStats()
    {
        try
        {
            _metricsService.Reset();
            _logger?.LogInformation("Performance stats reset successfully");
        }
        catch (ObjectDisposedException ex)
        {
            _logger?.LogWarning(ex, "Attempted to reset performance stats on disposed service");
            throw;
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Error resetting performance stats");
            throw;
        }
    }
    
    // ========== Helper Methods ==========
    
    /// <summary>
    /// Валидация строкового параметра на null или пустоту
    /// </summary>
    private static void ValidateStringParameter(string? value, string paramName)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new ArgumentException($"Parameter {paramName} cannot be null or empty", paramName);
        }
    }
    
    /// <summary>
    /// Валидация объекта запроса на null
    /// </summary>
    private static void ValidateRequest<T>(T? request, string paramName) where T : class
    {
        if (request == null)
        {
            throw new ArgumentNullException(paramName, $"Parameter {paramName} cannot be null");
        }
    }
    
    /// <summary>
    /// Выполнение операции с отслеживанием метрик и обработкой исключений
    /// </summary>
    private async Task<T> ExecuteWithMetricsAsync<T>(Func<Task<T>> operation, string operationName)
    {
        var startTime = DateTime.UtcNow;
        try
        {
            var result = await operation();
            var elapsedMs = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
            _metricsService.RecordOperationTime(ServiceMetricsOperationName, elapsedMs);
            _metricsService.RecordSuccess(ServiceMetricsOperationName);
            return result;
        }
        catch (Exception ex)
        {
            var elapsedMs = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
            _metricsService.RecordOperationTime(ServiceMetricsOperationName, elapsedMs);
            _metricsService.RecordError(ServiceMetricsOperationName, ex.GetType().Name);
            _logger?.LogError(ex, "Error executing operation {OperationName}", operationName);
            throw;
        }
    }
    
    /// <summary>
    /// Выполнение операции без возвращаемого значения с отслеживанием метрик и обработкой исключений
    /// </summary>
    private async Task ExecuteWithMetricsAsync(Func<Task> operation, string operationName)
    {
        var startTime = DateTime.UtcNow;
        try
        {
            await operation();
            var elapsedMs = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
            _metricsService.RecordOperationTime(ServiceMetricsOperationName, elapsedMs);
            _metricsService.RecordSuccess(ServiceMetricsOperationName);
        }
        catch (Exception ex)
        {
            var elapsedMs = (long)(DateTime.UtcNow - startTime).TotalMilliseconds;
            _metricsService.RecordOperationTime(ServiceMetricsOperationName, elapsedMs);
            _metricsService.RecordError(ServiceMetricsOperationName, ex.GetType().Name);
            _logger?.LogError(ex, "Error executing operation {OperationName}", operationName);
            throw;
        }
    }
}

