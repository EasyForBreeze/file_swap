using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using new_assistant.Core.Interfaces;
using Microsoft.Extensions.Logging;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для сбора метрик производительности (thread-safe)
/// Исправленная версия с устранением всех выявленных проблем
/// </summary>
public class PerformanceMetricsService : IPerformanceMetricsService, IDisposable
{
    private class MetricsInternal
    {
        public long TotalCalls;
        public long SuccessfulCalls;
        public long FailedCalls;
        public long TotalTimeMs;
        public long MinTimeMs = long.MaxValue;
        public long MaxTimeMs;
        // Используем ConcurrentDictionary вместо обычного Dictionary + lock
        public readonly ConcurrentDictionary<string, int> ErrorCounts = new();
        // Thread-safe хранение времени последнего обновления через ticks
        private long _lastUpdateTimeTicks = DateTime.UtcNow.Ticks;
        
        public DateTime LastUpdateTime
        {
            get => new DateTime(Volatile.Read(ref _lastUpdateTimeTicks));
            set => Volatile.Write(ref _lastUpdateTimeTicks, value.Ticks);
        }
    }

    // Константы для валидации
    private const int MaxOperationNameLength = 500;
    private const int MaxErrorTypeLength = 200;
    private const int MaxOperationsCount = 10000;
    private const long MaxReasonableTimeMs = 365L * 24 * 60 * 60 * 1000; // 1 год в миллисекундах
    private const int CleanupTimeoutMs = 30000; // 30 секунд для очистки

    private readonly ConcurrentDictionary<string, MetricsInternal> _metrics = new();
    private readonly ILogger<PerformanceMetricsService> _logger;
    private readonly Timer? _cleanupTimer;
    private readonly TimeSpan _metricsRetentionPeriod = TimeSpan.FromHours(24);
    // Используем int вместо bool для атомарных операций через Interlocked
    private int _disposed; // 0 = не освобожден, 1 = освобожден

    // Метрики для мониторинга самого сервиса
    private long _totalRecordedOperations;
    private long _totalRecordedErrors;
    private long _totalRecordedSuccesses;
    private long _cleanupExecutions;
    private long _cleanupRemovedCount;

    public PerformanceMetricsService(ILogger<PerformanceMetricsService> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        
        // Периодическая очистка старых метрик для предотвращения утечки памяти
        _cleanupTimer = new Timer(CleanupOldMetrics, null, TimeSpan.FromHours(1), TimeSpan.FromHours(1));
    }

    public void RecordOperationTime(string operationName, long elapsedMilliseconds)
    {
        if (IsDisposed())
            return;
            
        ValidateOperationName(operationName);
        
        if (elapsedMilliseconds < 0)
        {
            throw new ArgumentOutOfRangeException(
                nameof(elapsedMilliseconds), 
                "Elapsed time cannot be negative");
        }

        // Защита от неразумно больших значений (например, > 1 года)
        if (elapsedMilliseconds > MaxReasonableTimeMs)
        {
            _logger.LogWarning(
                "Unusually large elapsed time {ElapsedMs}ms for operation {OperationName}. " +
                "This might indicate a problem with time measurement.",
                elapsedMilliseconds, operationName);
        }

        // Проверка ограничения на количество операций
        if (_metrics.Count >= MaxOperationsCount)
        {
            _logger.LogWarning(
                "Maximum operations count ({MaxCount}) reached. Operation {OperationName} will not be tracked.",
                MaxOperationsCount, operationName);
            return;
        }

        var metrics = _metrics.GetOrAdd(operationName, _ => new MetricsInternal());
        metrics.LastUpdateTime = DateTime.UtcNow;

        try
        {
            checked
            {
                Interlocked.Increment(ref metrics.TotalCalls);
                Interlocked.Add(ref metrics.TotalTimeMs, elapsedMilliseconds);
                Interlocked.Increment(ref _totalRecordedOperations);
            }
        }
        catch (OverflowException ex)
        {
            _logger.LogError(ex, 
                "Overflow detected for operation {OperationName}. Resetting metrics for this operation.", 
                operationName);
            // Сбрасываем только метрики для конкретной операции, а не все метрики
            if (_metrics.TryRemove(operationName, out _))
            {
                _logger.LogInformation("Removed metrics for operation {OperationName} due to overflow", operationName);
            }
            // Не пробрасываем исключение, чтобы не нарушить работу приложения
            return;
        }

        // Update min/max (thread-safe, оптимизированная версия)
        UpdateMin(ref metrics.MinTimeMs, elapsedMilliseconds);
        UpdateMax(ref metrics.MaxTimeMs, elapsedMilliseconds);
    }

    public void RecordSuccess(string operationName)
    {
        if (IsDisposed())
            return;
            
        ValidateOperationName(operationName);

        // Проверка ограничения на количество операций
        if (_metrics.Count >= MaxOperationsCount)
        {
            return;
        }

        var metrics = _metrics.GetOrAdd(operationName, _ => new MetricsInternal());
        metrics.LastUpdateTime = DateTime.UtcNow;

        try
        {
            checked
            {
                Interlocked.Increment(ref metrics.SuccessfulCalls);
                Interlocked.Increment(ref _totalRecordedSuccesses);
            }
        }
        catch (OverflowException ex)
        {
            _logger.LogError(ex, 
                "Overflow detected for operation {OperationName} success counter.", 
                operationName);
            // Не пробрасываем исключение, чтобы не нарушить работу приложения
            return;
        }
    }

    public void RecordError(string operationName, string errorType)
    {
        if (IsDisposed())
            return;
            
        ValidateOperationName(operationName);
        ValidateErrorType(errorType);

        // Проверка ограничения на количество операций
        if (_metrics.Count >= MaxOperationsCount)
        {
            return;
        }

        var metrics = _metrics.GetOrAdd(operationName, _ => new MetricsInternal());
        metrics.LastUpdateTime = DateTime.UtcNow;

        try
        {
            checked
            {
                Interlocked.Increment(ref metrics.FailedCalls);
                Interlocked.Increment(ref _totalRecordedErrors);
            }
        }
        catch (OverflowException ex)
        {
            _logger.LogError(ex, 
                "Overflow detected for operation {OperationName} failed counter.", 
                operationName);
            // Не пробрасываем исключение, чтобы не нарушить работу приложения
            return;
        }

        // Thread-safe без lock, используя ConcurrentDictionary
        // Валидация errorType уже выполнена выше
        metrics.ErrorCounts.AddOrUpdate(errorType, 1, (key, oldValue) => 
        {
            try
            {
                checked
                {
                    return oldValue + 1;
                }
            }
            catch (OverflowException)
            {
                _logger.LogWarning(
                    "Error count overflow for operation {OperationName}, error type {ErrorType}. Resetting to 1.",
                    operationName, errorType);
                return 1;
            }
        });

        // Логирование при достижении порога ошибок
        var failedCount = Volatile.Read(ref metrics.FailedCalls);
        if (failedCount > 0 && failedCount % 100 == 0)
        {
            _logger.LogWarning(
                "Operation {OperationName} has reached {ErrorCount} errors", 
                operationName, failedCount);
        }
    }

    public OperationMetrics GetMetrics(string operationName)
    {
        if (IsDisposed())
            throw new ObjectDisposedException(nameof(PerformanceMetricsService));
            
        ValidateOperationName(operationName);

        if (!_metrics.TryGetValue(operationName, out var internalMetrics))
        {
            return new OperationMetrics { OperationName = operationName };
        }

        return ConvertToOperationMetrics(operationName, internalMetrics);
    }

    public Dictionary<string, OperationMetrics> GetAllMetrics()
    {
        if (IsDisposed())
            throw new ObjectDisposedException(nameof(PerformanceMetricsService));
            
        // Оптимизированное создание snapshot без ToArray()
        // Используем Select для создания словаря напрямую
        var result = new Dictionary<string, OperationMetrics>(_metrics.Count);
        foreach (var kvp in _metrics)
        {
            result[kvp.Key] = ConvertToOperationMetrics(kvp.Key, kvp.Value);
        }
        return result;
    }

    public void Reset()
    {
        if (IsDisposed())
            throw new ObjectDisposedException(nameof(PerformanceMetricsService));

        var count = _metrics.Count;
        _metrics.Clear();
        _logger.LogInformation(
            "Метрики производительности сброшены. Удалено {Count} операций.", 
            count);
    }

    public void Dispose()
    {
        // Атомарная проверка и установка disposed через Interlocked
        if (Interlocked.Exchange(ref _disposed, 1) == 1)
        {
            // Уже был вызван Dispose
            return;
        }

        _cleanupTimer?.Dispose();
    }

    /// <summary>
    /// Thread-safe проверка disposed состояния
    /// </summary>
    private bool IsDisposed()
    {
        return Volatile.Read(ref _disposed) == 1;
    }

    private static void ValidateOperationName(string? operationName)
    {
        if (string.IsNullOrWhiteSpace(operationName))
        {
            throw new ArgumentException(
                "Operation name cannot be null or empty", 
                nameof(operationName));
        }

        if (operationName.Length > MaxOperationNameLength)
        {
            throw new ArgumentException(
                $"Operation name length cannot exceed {MaxOperationNameLength} characters", 
                nameof(operationName));
        }

        // Валидация на недопустимые символы (базовая защита)
        if (operationName.Any(c => char.IsControl(c) && c != '\t' && c != '\n' && c != '\r'))
        {
            throw new ArgumentException(
                "Operation name contains invalid control characters", 
                nameof(operationName));
        }
    }

    private static void ValidateErrorType(string? errorType)
    {
        if (string.IsNullOrWhiteSpace(errorType))
        {
            throw new ArgumentException(
                "Error type cannot be null or empty", 
                nameof(errorType));
        }

        if (errorType.Length > MaxErrorTypeLength)
        {
            throw new ArgumentException(
                $"Error type length cannot exceed {MaxErrorTypeLength} characters", 
                nameof(errorType));
        }

        // Валидация на недопустимые символы (базовая защита)
        if (errorType.Any(c => char.IsControl(c) && c != '\t' && c != '\n' && c != '\r'))
        {
            throw new ArgumentException(
                "Error type contains invalid control characters", 
                nameof(errorType));
        }
    }

    private static OperationMetrics ConvertToOperationMetrics(
        string operationName, 
        MetricsInternal internalMetrics)
    {
        // Безопасное копирование ErrorCounts (ConcurrentDictionary уже thread-safe)
        var errorCountsCopy = new Dictionary<string, int>(internalMetrics.ErrorCounts);
        
        // Исправление MinTimeMs: если значение не было установлено, возвращаем 0
        var minTime = internalMetrics.MinTimeMs == long.MaxValue 
            ? 0 
            : internalMetrics.MinTimeMs;

        // Исправление MaxTimeMs: если значение не было установлено, возвращаем 0
        var maxTime = internalMetrics.MaxTimeMs == 0 && internalMetrics.TotalCalls == 0
            ? 0
            : internalMetrics.MaxTimeMs;

        // Примечание: значения могут быть немного несогласованными из-за многопоточности,
        // но это приемлемо для метрик производительности (снимок состояния)
        return new OperationMetrics
        {
            OperationName = operationName,
            TotalCalls = internalMetrics.TotalCalls,
            SuccessfulCalls = internalMetrics.SuccessfulCalls,
            FailedCalls = internalMetrics.FailedCalls,
            TotalTimeMs = internalMetrics.TotalTimeMs,
            MinTimeMs = minTime,
            MaxTimeMs = maxTime,
            ErrorCounts = errorCountsCopy
        };
    }

    /// <summary>
    /// Оптимизированная версия UpdateMin с быстрой проверкой
    /// </summary>
    private static void UpdateMin(ref long currentMin, long newValue)
    {
        long initialValue, computedValue;
        do
        {
            // Читаем актуальное значение в каждой итерации для thread-safety
            initialValue = Volatile.Read(ref currentMin);
            if (newValue >= initialValue)
                return;
            
            computedValue = Math.Min(initialValue, newValue);
        }
        while (initialValue != Interlocked.CompareExchange(ref currentMin, computedValue, initialValue));
    }

    /// <summary>
    /// Оптимизированная версия UpdateMax с быстрой проверкой
    /// </summary>
    private static void UpdateMax(ref long currentMax, long newValue)
    {
        long initialValue, computedValue;
        do
        {
            // Читаем актуальное значение в каждой итерации для thread-safety
            initialValue = Volatile.Read(ref currentMax);
            if (newValue <= initialValue)
                return;
            
            computedValue = Math.Max(initialValue, newValue);
        }
        while (initialValue != Interlocked.CompareExchange(ref currentMax, computedValue, initialValue));
    }

    /// <summary>
    /// Очистка метрик, которые не обновлялись более указанного периода
    /// </summary>
    private void CleanupOldMetrics(object? state)
    {
        if (IsDisposed())
            return;

        var stopwatch = Stopwatch.StartNew();
        var removedCount = 0;

        try
        {
            Interlocked.Increment(ref _cleanupExecutions);

            var cutoffTime = DateTime.UtcNow - _metricsRetentionPeriod;
            var keysToRemove = new List<string>();

            // Собираем ключи для удаления с таймаутом
            foreach (var kvp in _metrics)
            {
                if (stopwatch.ElapsedMilliseconds > CleanupTimeoutMs)
                {
                    _logger.LogWarning(
                        "Metrics cleanup timeout reached ({TimeoutMs}ms). Stopping cleanup to prevent blocking.",
                        CleanupTimeoutMs);
                    break;
                }

                if (kvp.Value.LastUpdateTime < cutoffTime)
                {
                    keysToRemove.Add(kvp.Key);
                }
            }

            // Удаляем метрики с повторной проверкой
            foreach (var key in keysToRemove)
            {
                if (stopwatch.ElapsedMilliseconds > CleanupTimeoutMs)
                {
                    _logger.LogWarning(
                        "Metrics cleanup timeout reached during removal. Stopping cleanup.");
                    break;
                }

                // Повторная проверка перед удалением - метрика могла обновиться между проверкой и удалением
                if (_metrics.TryGetValue(key, out var metrics))
                {
                    if (metrics.LastUpdateTime < cutoffTime)
                    {
                        if (_metrics.TryRemove(key, out _))
                        {
                            removedCount++;
                            _logger.LogDebug(
                                "Removed stale metrics for operation {OperationName}", 
                                key);
                        }
                    }
                }
            }

            if (removedCount > 0)
            {
                Interlocked.Add(ref _cleanupRemovedCount, removedCount);
                _logger.LogInformation(
                    "Cleaned up {Count} stale metric entries in {ElapsedMs}ms", 
                    removedCount, stopwatch.ElapsedMilliseconds);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during metrics cleanup");
        }
        finally
        {
            stopwatch.Stop();
        }
    }

    /// <summary>
    /// Получить метрики самого сервиса для мониторинга
    /// </summary>
    public ServiceMetrics GetServiceMetrics()
    {
        return new ServiceMetrics
        {
            TotalOperations = Volatile.Read(ref _totalRecordedOperations),
            TotalSuccesses = Volatile.Read(ref _totalRecordedSuccesses),
            TotalErrors = Volatile.Read(ref _totalRecordedErrors),
            CurrentOperationsCount = _metrics.Count,
            CleanupExecutions = Volatile.Read(ref _cleanupExecutions),
            CleanupRemovedCount = Volatile.Read(ref _cleanupRemovedCount)
        };
    }

    /// <summary>
    /// Метрики самого сервиса PerformanceMetricsService
    /// </summary>
    public class ServiceMetrics
    {
        public long TotalOperations { get; set; }
        public long TotalSuccesses { get; set; }
        public long TotalErrors { get; set; }
        public int CurrentOperationsCount { get; set; }
        public long CleanupExecutions { get; set; }
        public long CleanupRemovedCount { get; set; }
    }
}
