using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Configuration;
using new_assistant.Core.Constants;
using new_assistant.Core.DTOs;
using new_assistant.Core.Entities;
using new_assistant.Core.Helpers;
using new_assistant.Core.Interfaces;
using Polly;
using Polly.Retry;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для переноса клиентов из TEST в STAGE
/// </summary>
public class ClientMigrationService : IClientMigrationService
{
    private readonly IKeycloakAdminService _testKeycloak;
    private readonly IKeycloakStageService _stageKeycloak;
    private readonly IAuditService _auditService;
    private readonly IClientArchiveService _archiveService;
    private readonly IEmailService _emailService;
    private readonly IConfiguration _configuration;
    private readonly ILogger<ClientMigrationService> _logger;
    private readonly IClientMigrationValidationService _validationService;
    private readonly IClientMigrationRolesService _rolesService;
    private readonly IClientMigrationWikiService _wikiService;
    private readonly IKeycloakUrlBuilderService _urlBuilder;
    private readonly IUserMenuService? _userMenuService;
    private readonly AsyncRetryPolicy _retryPolicy;
    
    // Константы
    private const int MigrationTimeoutSeconds = 300; // 5 минут
    private const int RetryCount = 3;
    private const int ExponentialBackoffBase = 2;
    private const int SecretHashLength = 16; // Длина хеша для логирования
    private const int MinLengthForMasking = 9; // Минимальная длина для маскировки секрета

    public ClientMigrationService(
        IKeycloakAdminService testKeycloak,
        IKeycloakStageService stageKeycloak,
        IAuditService auditService,
        IClientArchiveService archiveService,
        IEmailService emailService,
        IConfiguration configuration,
        ILogger<ClientMigrationService> logger,
        IClientMigrationValidationService validationService,
        IClientMigrationRolesService rolesService,
        IClientMigrationWikiService wikiService,
        IKeycloakUrlBuilderService urlBuilder,
        IUserMenuService? userMenuService = null)
    {
        _testKeycloak = testKeycloak ?? throw new ArgumentNullException(nameof(testKeycloak));
        _stageKeycloak = stageKeycloak ?? throw new ArgumentNullException(nameof(stageKeycloak));
        _auditService = auditService ?? throw new ArgumentNullException(nameof(auditService));
        _archiveService = archiveService ?? throw new ArgumentNullException(nameof(archiveService));
        _emailService = emailService ?? throw new ArgumentNullException(nameof(emailService));
        _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _validationService = validationService ?? throw new ArgumentNullException(nameof(validationService));
        _rolesService = rolesService ?? throw new ArgumentNullException(nameof(rolesService));
        _wikiService = wikiService ?? throw new ArgumentNullException(nameof(wikiService));
        _urlBuilder = urlBuilder ?? throw new ArgumentNullException(nameof(urlBuilder));
        _userMenuService = userMenuService;
        
        // Настроить retry политику для сетевых операций
        _retryPolicy = Policy
            .Handle<HttpRequestException>()
            .Or<TaskCanceledException>()
            .Or<TimeoutException>()
            .WaitAndRetryAsync(
                retryCount: RetryCount,
                sleepDurationProvider: retryAttempt => TimeSpan.FromSeconds(Math.Pow(ExponentialBackoffBase, retryAttempt)),
                onRetry: (exception, timeSpan, retryCount, context) =>
                {
                    _logger.LogWarning(exception, 
                        "Повторная попытка {RetryCount} через {Delay} секунд", 
                        retryCount, timeSpan.TotalSeconds);
                });
    }

    /// <summary>
    /// Валидировать возможность переноса клиента
    /// </summary>
    public async Task<MigrationValidationResult> ValidateMigrationAsync(
        ClientMigrationRequest request, 
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        if (request == null)
            throw new ArgumentNullException(nameof(request));
        
        if (string.IsNullOrWhiteSpace(request.ClientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(request));
        
        if (string.IsNullOrWhiteSpace(request.SourceRealm))
            throw new ArgumentException("SourceRealm cannot be null or empty", nameof(request));
        
        if (string.IsNullOrWhiteSpace(request.TargetRealm))
            throw new ArgumentException("TargetRealm cannot be null or empty", nameof(request));
        
        // Валидация длины строк
        _validationService.ValidateRequestLengths(request);
        
        // Валидация формата email, если указан
        if (!string.IsNullOrWhiteSpace(request.NotificationEmail) && 
            !_validationService.IsValidEmail(request.NotificationEmail))
        {
            throw new ArgumentException("Invalid email format", nameof(request));
        }
        
        return await _validationService.ValidateMigrationAsync(request, cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Выполнить перенос клиента из TEST в STAGE
    /// </summary>
    public async Task<ClientMigrationResult> MigrateClientAsync(
        ClientMigrationRequest request, 
        string migratedBy, 
        CancellationToken cancellationToken = default)
    {
        // Валидация входных параметров
        if (request == null)
            throw new ArgumentNullException(nameof(request));
        
        if (string.IsNullOrWhiteSpace(request.ClientId))
            throw new ArgumentException("ClientId cannot be null or empty", nameof(request));
        
        if (string.IsNullOrWhiteSpace(request.SourceRealm))
            throw new ArgumentException("SourceRealm cannot be null or empty", nameof(request));
        
        if (string.IsNullOrWhiteSpace(request.TargetRealm))
            throw new ArgumentException("TargetRealm cannot be null or empty", nameof(request));
        
        if (string.IsNullOrWhiteSpace(migratedBy))
            throw new ArgumentException("migratedBy cannot be null or empty", nameof(migratedBy));
        
        // Валидация migratedBy длины
        if (migratedBy.Length > MigrationConstants.MaxMigratedByLength)
            throw new ArgumentException(
                $"migratedBy превышает максимальную длину {MigrationConstants.MaxMigratedByLength} символов", 
                nameof(migratedBy));
        
        var result = new ClientMigrationResult
        {
            ClientId = request.ClientId
        };
        
        // Создать CancellationTokenSource с таймаутом
        // Проверяем, не отменен ли cancellationToken перед созданием связанного источника
        if (cancellationToken.IsCancellationRequested)
        {
            result.Success = false;
            result.Errors.Add("Операция была отменена до начала выполнения");
            return result;
        }
        
        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutCts.CancelAfter(TimeSpan.FromSeconds(MigrationTimeoutSeconds));
        var timeoutToken = timeoutCts.Token;
        
        // Стек для rollback операций
        var rollbackActions = new Stack<Func<Task>>();
        
            // Инициализировать переменные заранее для использования в catch блоках
            System.Diagnostics.Stopwatch? stopwatch = null;
            Dictionary<string, object>? metrics = null;

            try
            {
                _logger.LogWarning("Начат перенос клиента {ClientId} из {Source} в {Target} пользователем {User}", 
                    request.ClientId, request.SourceRealm, request.TargetRealm, migratedBy);

                stopwatch = System.Diagnostics.Stopwatch.StartNew();

                // Метрики для мониторинга
                metrics = InitializeMetrics(request.ClientId, request.SourceRealm, request.TargetRealm, migratedBy);

            // 0. Проверка прав доступа (опционально, через конфигурацию)
            var requireMigrationPermission = _configuration.GetValue<bool>("Migration:RequirePermission", defaultValue: false);
            if (requireMigrationPermission)
            {
                if (!await HasMigrationPermissionAsync(migratedBy, request.TargetRealm, timeoutToken).ConfigureAwait(false))
                {
                    result.Success = false;
                    result.Errors.Add($"Пользователь '{migratedBy}' не имеет прав на выполнение миграции");
                    _logger.LogWarning("Пользователь {User} не имеет прав на миграцию клиента {ClientId}", 
                        migratedBy, request.ClientId);
                    return result;
                }
            }

            // 1. Валидация перед миграцией (включает валидацию входных параметров)
            var validationResult = await ValidateMigrationAsync(request, timeoutToken).ConfigureAwait(false);
            
            if (validationResult == null)
            {
                result.Success = false;
                result.Errors.Add("Ошибка валидации: результат валидации пуст");
                _logger.LogError("ValidateMigrationAsync вернул null для клиента {ClientId}", request.ClientId);
                return result;
            }
            
            if (validationResult.ClientExistsInTarget)
            {
                result.Success = false;
                result.Errors.Add($"Клиент '{request.ClientId}' уже существует в STAGE realm '{request.TargetRealm}'");
                return result;
            }

            // 2. Получить полные детали клиента из TEST (с retry)
            var clientDetails = await GetSourceClientDetailsAsync(
                request.ClientId, request.SourceRealm, timeoutToken).ConfigureAwait(false);

            if (clientDetails == null)
            {
                result.Success = false;
                result.Errors.Add("Клиент не найден в TEST");
                return result;
            }
            
            var requestedWikiUrl = string.IsNullOrWhiteSpace(request.WikiPageUrl)
                ? null
                : request.WikiPageUrl.Trim();
            var wikiUrlCandidate = requestedWikiUrl
                ?? validationResult.ExistingWikiPageUrl?.Trim();

            // Дополнительная проверка непосредственно перед созданием (защита от race condition)
            if (await _stageKeycloak.ClientExistsAsync(
                request.ClientId, request.TargetRealm, timeoutToken).ConfigureAwait(false))
            {
                result.Success = false;
                result.Errors.Add($"Клиент '{request.ClientId}' был создан между валидацией и миграцией");
                return result;
            }

            // 2. Создать клиента в STAGE (с retry и обработкой конфликта)
            string newInternalId;
            try
            {
                newInternalId = await CreateClientInStageAsync(
                    clientDetails, request.TargetRealm, timeoutToken).ConfigureAwait(false);
                
                // Добавить rollback действие
                rollbackActions.Push(async () => 
                {
                    try
                    {
                        _logger.LogWarning("Выполняется откат: удаление клиента {ClientId} (internalId: {InternalId}) из STAGE", 
                            request.ClientId, newInternalId);
                        
                        await _stageKeycloak.DeleteClientAsync(
                            newInternalId, request.TargetRealm, CancellationToken.None).ConfigureAwait(false);
                        
                        _logger.LogInformation("Клиент {ClientId} успешно удален при откате", request.ClientId);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Ошибка при откате: не удалось удалить клиента {ClientId} (internalId: {InternalId}) из STAGE realm {Realm}. " +
                            "ТРЕБУЕТСЯ РУЧНОЕ УДАЛЕНИЕ", request.ClientId, newInternalId, request.TargetRealm);
                        // Пробрасываем исключение для логирования в ExecuteRollbackAsync
                        throw;
                    }
                });
            }
            catch (Exception ex) when (ex.Message.Contains("already exists", StringComparison.OrdinalIgnoreCase) ||
                                      ex.Message.Contains("409", StringComparison.OrdinalIgnoreCase) ||
                                      ex is HttpRequestException httpEx && httpEx.Message.Contains("409"))
            {
                result.Success = false;
                result.Errors.Add($"Клиент '{request.ClientId}' уже существует в STAGE (race condition)");
                return result;
            }

            result.NewInternalId = newInternalId;
            result.RedirectUris = clientDetails.RedirectUris;

            // 3. Получить новый Client Secret (с retry)
            string? newSecret;
            try
            {
                newSecret = await _retryPolicy.ExecuteAsync(async () =>
                    await _stageKeycloak.GetClientSecretAsync(
                        newInternalId, request.TargetRealm, timeoutToken).ConfigureAwait(false));
            }
            catch (Exception ex)
            {
                // Обрабатываем все исключения после исчерпания retry попыток
                _logger.LogError(ex, "Все попытки получения Client Secret для клиента {ClientId} исчерпаны после {RetryCount} попыток", 
                    request.ClientId, RetryCount);
                result.Errors.Add($"Не удалось получить Client Secret после {RetryCount} попыток: {ex.Message}");
                throw;
            }

            result.NewClientSecret = newSecret ?? string.Empty;
            
            // Безопасное логирование секрета (только факт получения, без хеша для безопасности)
            // Не логируем хеш, так как даже хеш без соли может быть уязвим для rainbow table атак
            if (!string.IsNullOrWhiteSpace(result.NewClientSecret))
            {
                _logger.LogInformation("Client Secret успешно получен для клиента {ClientId}", request.ClientId);
            }

            string? archivePassword = null;
            if (!string.IsNullOrWhiteSpace(result.NewClientSecret))
            {
                try
                {
                    var archiveResult = _archiveService.CreateClientCredentialsPackage(
                        request.ClientId,
                        result.NewClientSecret);

                    result.ArchivePath = archiveResult.ArchivePath;
                    archivePassword = archiveResult.Password;
                }
                catch (Exception ex)
                {
                    var errorContext = new
                    {
                        ClientId = request.ClientId,
                        Operation = "CreateArchive",
                        ErrorType = ex.GetType().Name,
                        ErrorMessage = ex.Message
                    };
                    
                    _logger.LogError(ex, 
                        "Ошибка при формировании архива учетных данных для клиента {ClientId}. Context: {@Context}", 
                        request.ClientId, errorContext);
                    result.Warnings.Add("Не удалось сформировать архив с учетными данными.");
                }
            }
            else
            {
                _logger.LogWarning("Новый Client Secret не получен для клиента {ClientId} в STAGE", request.ClientId);
            }

            result.ArchivePassword = archivePassword ?? string.Empty;

            // 4. Создать локальные роли клиента
            var localRoles = clientDetails?.LocalRoles ?? Enumerable.Empty<string>();
            if (localRoles.Any())
            {
                try
                {
                    result.LocalRolesMigrated = await _rolesService.CreateLocalRolesAsync(
                        newInternalId, localRoles, request.TargetRealm, timeoutToken).ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, 
                        "Не все локальные роли были созданы для клиента {ClientId}", 
                        request.ClientId);
                    result.Warnings.Add($"Частичное создание локальных ролей: {ex.Message}");
                }
            }

            // 5. Назначить service account roles (только валидированные)
            var serviceAccountsEnabled = clientDetails?.ServiceAccountsEnabled ?? false;
            var serviceRoles = clientDetails?.ServiceRoles ?? Enumerable.Empty<string>();
            if (serviceAccountsEnabled && serviceRoles.Any())
            {
                // Дедупликация realm roles
                var realmRoles = validationResult.ValidatedRealmRoles
                    .Where(r => !string.IsNullOrWhiteSpace(r))
                    .Distinct()
                    .ToList();
                
                // Парсим валидированные client roles (с дедупликацией)
                var uniqueClientRoles = validationResult.ValidatedClientRoles
                    .Where(r => !string.IsNullOrWhiteSpace(r))
                    .Distinct()
                    .ToList();
                
                // Группируем client roles по clientId используя утилитный класс
                // Используем метод для обратной совместимости с существующим интерфейсом
                var clientRolesByClient = ClientRoleParser.GroupByClientIdAsList(uniqueClientRoles);

                // Логируем пропущенные роли (с ограничением для больших списков)
                // Кешируем результаты для избежания множественных перечислений
                var missingRealmRolesCached = validationResult.MissingRealmRoles.ToList();
                if (missingRealmRolesCached.Count > 0)
                {
                    var count = missingRealmRolesCached.Count;
                    var rolesToShow = missingRealmRolesCached.Take(10).ToList();
                    var rolesText = string.Join(", ", rolesToShow);
                    if (count > 10)
                    {
                        rolesText += $" и еще {count - 10}";
                    }
                    
                    _logger.LogInformation("Пропущено {Count} realm roles (не существуют в STAGE): {Roles}", 
                        count, 
                        rolesText);
                    
                    result.Warnings.Add($"Пропущено {count} realm roles: {rolesText}");
                }
                
                var missingClientRolesCached = validationResult.MissingClientRoles.ToList();
                if (missingClientRolesCached.Count > 0)
                {
                    var count = missingClientRolesCached.Count;
                    var rolesToShow = missingClientRolesCached.Take(10).ToList();
                    var rolesText = string.Join(", ", rolesToShow);
                    if (count > 10)
                    {
                        rolesText += $" и еще {count - 10}";
                    }
                    
                    _logger.LogInformation("Пропущено {Count} client roles (не существуют в STAGE): {Roles}", 
                        count, 
                        rolesText);
                    
                    result.Warnings.Add($"Пропущено {count} client roles: {rolesText}");
                }

                // Назначить realm roles
                // Кешируем результат для избежания повторного перечисления
                var realmRolesList = realmRoles.ToList();
                if (realmRolesList.Count > 0)
                {
                    try
                    {
                        var realmRolesCount = await _rolesService.AssignRealmRolesToServiceAccountAsync(
                            newInternalId, realmRolesList, request.TargetRealm, timeoutToken).ConfigureAwait(false);
                        
                        // Проверка на переполнение с использованием long для предотвращения потери данных
                        var currentCount = (long)result.ServiceRolesMigrated;
                        var newCount = currentCount + realmRolesCount;
                        
                        if (newCount > int.MaxValue)
                        {
                            _logger.LogError("Переполнение счетчика ServiceRolesMigrated для клиента {ClientId}. Текущее значение: {Current}, Добавляется: {Adding}", 
                                request.ClientId, currentCount, realmRolesCount);
                            throw new InvalidOperationException(
                                $"Переполнение счетчика ServiceRolesMigrated: невозможно добавить {realmRolesCount} ролей к текущему значению {currentCount}");
                        }
                        
                        result.ServiceRolesMigrated = (int)newCount;
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, 
                            "Не все realm roles назначены для клиента {ClientId}", 
                            request.ClientId);
                        result.Warnings.Add($"Некоторые realm roles не назначены: {ex.Message}");
                    }
                }

                // Назначить client roles
                // Кешируем результат для избежания повторного перечисления
                var clientRolesDictCount = clientRolesByClient.Count;
                if (clientRolesDictCount > 0)
                {
                    try
                    {
                        var clientRolesCount = await _rolesService.AssignClientRolesToServiceAccountAsync(
                            newInternalId, clientRolesByClient, request.TargetRealm, timeoutToken).ConfigureAwait(false);
                        
                        // Проверка на переполнение с использованием long для предотвращения потери данных
                        var currentCount = (long)result.ServiceRolesMigrated;
                        var newCount = currentCount + clientRolesCount;
                        
                        if (newCount > int.MaxValue)
                        {
                            _logger.LogError("Переполнение счетчика ServiceRolesMigrated для клиента {ClientId}. Текущее значение: {Current}, Добавляется: {Adding}", 
                                request.ClientId, currentCount, clientRolesCount);
                            throw new InvalidOperationException(
                                $"Переполнение счетчика ServiceRolesMigrated: невозможно добавить {clientRolesCount} ролей к текущему значению {currentCount}");
                        }
                        
                        result.ServiceRolesMigrated = (int)newCount;
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, 
                            "Не все client roles назначены для клиента {ClientId}", 
                            request.ClientId);
                        result.Warnings.Add($"Некоторые client roles не назначены: {ex.Message}");
                    }
                }
            }

            // 6. Назначить client scopes
            var validatedDefaultScopes = validationResult?.ValidatedDefaultClientScopes ?? Enumerable.Empty<string>();
            var validatedOptionalScopes = validationResult?.ValidatedOptionalClientScopes ?? Enumerable.Empty<string>();
            
            try
            {
                await _rolesService.AssignClientScopesAsync(
                    newInternalId,
                    validatedDefaultScopes,
                    validatedOptionalScopes,
                    request.TargetRealm,
                    timeoutToken).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, 
                    "Не удалось назначить client scopes для клиента {ClientId}", 
                    request.ClientId);
                result.Warnings.Add($"Client scopes не назначены полностью: {ex.Message}");
            }

            var missingScopes = validationResult?.MissingClientScopes ?? Enumerable.Empty<string>();
            // Кешируем результат для избежания повторного перечисления
            var missingScopesCached = missingScopes.ToList();
            if (missingScopesCached.Count > 0)
            {
                var count = missingScopesCached.Count;
                var scopesToShow = missingScopesCached.Take(10).ToList();
                var scopesText = string.Join(", ", scopesToShow);
                if (count > 10)
                {
                    scopesText += $" и еще {count - 10}";
                }
                
                result.Warnings.Add($"Пропущено client scopes: {scopesText}");
            }

            // 7. Отправить уведомление по email (если указано)
            if (!string.IsNullOrWhiteSpace(request.NotificationEmail) &&
                !string.IsNullOrWhiteSpace(result.NewClientSecret) &&
                !string.IsNullOrWhiteSpace(archivePassword))
            {
                try
                {
                    // Получаем URL через сервис
                    var realmUrlForEmail = _urlBuilder.GetStageRealmUrl(request.TargetRealm);
                    var endpointsUrlForEmail = _urlBuilder.GetStageEndpointsUrl(request.TargetRealm);
                    
                    // Логируем для отладки
                    _logger.LogDebug("Сформированы URL для email в STAGE: Realm={RealmUrl}, Endpoints={EndpointsUrl}", 
                        realmUrlForEmail, endpointsUrlForEmail);

                    var emailSent = await _emailService.SendClientCredentialsEmailAsync(
                        request.NotificationEmail,
                        request.ClientId,
                        request.TargetRealm,
                        archivePassword,
                        request.TicketNumber,
                        request.TicketUrl,
                        wikiUrlCandidate,
                        environment: MigrationConstants.EnvironmentStage,
                        baseUrl: realmUrlForEmail,
                        endpointsUrl: endpointsUrlForEmail).ConfigureAwait(false);

                    if (emailSent)
                    {
                        await _auditService.LogEmailSentAsync(
                            migratedBy,
                            request.ClientId,
                            request.TargetRealm,
                            $"Email с учетными данными отправлен на {request.NotificationEmail}. Ticket: {request.TicketNumber ?? "не указан"}").ConfigureAwait(false);
                    }
                    else
                    {
                        _logger.LogWarning("Не удалось отправить email уведомление на {Email} после миграции клиента {ClientId}",
                            request.NotificationEmail,
                            request.ClientId);
                        result.Warnings.Add($"Не удалось отправить email на {request.NotificationEmail}");
                    }
                }
                catch (Exception emailEx)
                {
                    var errorContext = new
                    {
                        ClientId = request.ClientId,
                        Email = request.NotificationEmail,
                        Operation = "SendEmail",
                        ErrorType = emailEx.GetType().Name,
                        ErrorMessage = emailEx.Message
                    };
                    
                    _logger.LogError(emailEx, 
                        "Ошибка при отправке email уведомления на {Email} после миграции клиента {ClientId}. Context: {@Context}",
                        request.NotificationEmail,
                        request.ClientId,
                        errorContext);
                    result.Warnings.Add($"Ошибка при отправке email: {emailEx.Message}");
                }
            }

            // 8. Обновить или создать Wiki страницу в репозитории
            try
            {
                result.WikiPageUrl = await _wikiService.UpdateWikiPageInRepositoryAsync(
                    request.ClientId,
                    wikiUrlCandidate,
                    migratedBy,
                    timeoutToken).ConfigureAwait(false);
                
                if (result.WikiPageUrl == null)
                {
                    result.Warnings.Add("Wiki страница не указана и не найдена в репозитории. Добавьте ссылку вручную при необходимости.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, 
                    "Не удалось обновить Wiki страницу для клиента {ClientId}", 
                    request.ClientId);
                result.Warnings.Add($"Wiki не обновлена: {ex.Message}");
            }

            // 9. Обновить Wiki страницу в Confluence
            try
            {
                if (clientDetails != null && validationResult != null)
                {
                    // Создаем копию clientDetails для избежания мутации исходного объекта
                    var clientDetailsCopy = new ClientDetailsDto
                    {
                        ClientId = clientDetails.ClientId,
                        Name = clientDetails.Name,
                        Description = clientDetails.Description,
                        Enabled = clientDetails.Enabled,
                        Protocol = clientDetails.Protocol,
                        ClientType = clientDetails.ClientType ?? string.Empty,
                        AccessType = clientDetails.AccessType ?? string.Empty,
                        ServiceAccountsEnabled = clientDetails.ServiceAccountsEnabled,
                        DirectAccessGrantsEnabled = clientDetails.DirectAccessGrantsEnabled,
                        StandardFlow = clientDetails.StandardFlow,
                        AuthorizationServicesEnabled = clientDetails.AuthorizationServicesEnabled,
                        RedirectUris = clientDetails.RedirectUris?.ToList() ?? new List<string>(),
                        WebOrigins = clientDetails.WebOrigins?.ToList() ?? new List<string>(),
                        BaseUrl = clientDetails.BaseUrl,
                        RootUrl = clientDetails.RootUrl,
                        AdminUrl = clientDetails.AdminUrl,
                        Attributes = clientDetails.Attributes != null 
                            ? new Dictionary<string, List<string>>(clientDetails.Attributes) 
                            : new Dictionary<string, List<string>>(),
                        LocalRoles = clientDetails.LocalRoles?.ToList() ?? new List<string>(),
                        ServiceRoles = clientDetails.ServiceRoles?.ToList() ?? new List<string>(),
                        Realm = request.TargetRealm,
                        DefaultClientScopes = validationResult.ValidatedDefaultClientScopes?.ToList() ?? new List<string>(),
                        OptionalClientScopes = validationResult.ValidatedOptionalClientScopes?.ToList() ?? new List<string>(),
                        PublicationStatus = MigrationConstants.PublicationStatusStage,
                        TicketNumber = request.TicketNumber,
                        TicketUrl = request.TicketUrl
                    };

                    var updatedWikiUrl = await _wikiService.UpdateWikiPageInConfluenceAsync(
                        clientDetailsCopy,
                        migratedBy,
                        timeoutToken).ConfigureAwait(false);

                    if (!string.IsNullOrWhiteSpace(updatedWikiUrl))
                    {
                        result.WikiPageUrl = updatedWikiUrl;
                    }
                }

            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, 
                    "Не удалось синхронизировать Wiki страницу в Confluence для клиента {ClientId}", 
                    request.ClientId);
                result.Warnings.Add($"Wiki страница в Confluence не обновлена: {ex.Message}");
            }

            // 9. Audit логирование (с null safety)
            var hasErrors = result?.Errors?.Any() == true;
            var hasWarnings = result?.Warnings?.Any() == true;
            var migrationStatus = hasErrors 
                ? MigrationConstants.MigrationStatusFailed 
                : (hasWarnings 
                    ? MigrationConstants.MigrationStatusPartialSuccess 
                    : MigrationConstants.MigrationStatusSuccess);
            var auditDetails = $"Локальных ролей: {result?.LocalRolesMigrated ?? 0}, Service roles: {result?.ServiceRolesMigrated ?? 0}. " +
                              $"Продолжительность: {stopwatch.ElapsedMilliseconds}мс";
            
            await _auditService.LogClientMigrationAsync(
                migratedBy,
                request.ClientId,
                request.SourceRealm,
                request.TargetRealm,
                migrationStatus,
                auditDetails
            ).ConfigureAwait(false);

            if (result != null)
            {
                result.Success = !(result.Errors?.Any() == true);
            }
            
            if (stopwatch != null)
            {
                stopwatch.Stop();
            }

            var warningsCount = result?.Warnings?.Count ?? 0;
            var errorsCount = result?.Errors?.Count ?? 0;
            
            // Записать метрики успеха
            if (metrics != null && stopwatch != null && result != null)
            {
                metrics["duration_ms"] = stopwatch.ElapsedMilliseconds;
                metrics["success"] = result.Success;
                metrics["local_roles_migrated"] = result.LocalRolesMigrated;
                metrics["service_roles_migrated"] = result.ServiceRolesMigrated;
                metrics["warnings_count"] = warningsCount;
                metrics["errors_count"] = errorsCount;
                
                _logger.LogInformation(
                    "Миграция завершена. Duration: {Duration}ms, Success: {Success}, " +
                    "LocalRoles: {LocalRoles}, ServiceRoles: {ServiceRoles}, " +
                    "Warnings: {Warnings}, Errors: {Errors}. Metrics: {@Metrics}",
                    stopwatch.ElapsedMilliseconds,
                    result.Success,
                    result.LocalRolesMigrated,
                    result.ServiceRolesMigrated,
                    warningsCount,
                    errorsCount,
                    metrics);
            }
            else if (result != null)
            {
                _logger.LogInformation(
                    "Миграция завершена. Success: {Success}, " +
                    "LocalRoles: {LocalRoles}, ServiceRoles: {ServiceRoles}, " +
                    "Warnings: {Warnings}, Errors: {Errors}",
                    result.Success,
                    result.LocalRolesMigrated,
                    result.ServiceRolesMigrated,
                    warningsCount,
                    errorsCount);
            }

            return result ?? throw new InvalidOperationException("Migration result is null");
        }
        catch (OperationCanceledException) when (timeoutCts.Token.IsCancellationRequested && !cancellationToken.IsCancellationRequested)
        {
            // Инициализировать переменные, если они еще не созданы
            if (stopwatch == null)
                stopwatch = System.Diagnostics.Stopwatch.StartNew();
            
            if (metrics == null)
            {
                metrics = new Dictionary<string, object>
                {
                    ["client_id"] = request.ClientId,
                    ["source_realm"] = request.SourceRealm,
                    ["target_realm"] = request.TargetRealm,
                    ["migrated_by"] = migratedBy
                };
            }
            
            // Метрики для таймаута
            metrics["error"] = "TimeoutException";
            metrics["error_type"] = "Timeout";
            metrics["duration_ms"] = stopwatch.ElapsedMilliseconds;
            metrics["success"] = false;
            
            var errorContext = new
            {
                ClientId = request.ClientId,
                SourceRealm = request.SourceRealm,
                TargetRealm = request.TargetRealm,
                Operation = "Migration",
                ErrorType = "TimeoutException",
                ErrorMessage = $"Операция превысила таймаут ({MigrationTimeoutSeconds} секунд)",
                Duration = stopwatch.ElapsedMilliseconds,
                MigratedBy = migratedBy
            };
            
            _logger.LogError(
                "Операция миграции клиента {ClientId} превысила таймаут ({Timeout} секунд). Context: {@Context}", 
                request.ClientId, MigrationTimeoutSeconds, errorContext);
            
            result.Success = false;
            result.Errors.Add($"Операция превысила таймаут ({MigrationTimeoutSeconds} секунд)");
            
            // Выполнить откат при таймауте
            await ExecuteRollbackAsync(rollbackActions, request.ClientId).ConfigureAwait(false);
            
            await _auditService.LogClientMigrationAsync(
                migratedBy,
                request.ClientId,
                request.SourceRealm,
                request.TargetRealm,
                MigrationConstants.MigrationStatusFailed,
                $"Таймаут: {MigrationTimeoutSeconds} секунд"
            ).ConfigureAwait(false);

            return result;
        }
        catch (Exception ex)
        {
            // Инициализировать переменные, если они еще не созданы
            if (stopwatch == null)
                stopwatch = System.Diagnostics.Stopwatch.StartNew();
            
            if (metrics == null)
            {
                metrics = InitializeMetrics(request.ClientId, request.SourceRealm, request.TargetRealm, migratedBy);
            }
            
            // Метрики для ошибки
            metrics["error"] = ex.GetType().Name;
            metrics["error_type"] = "Exception";
            metrics["error_message"] = ex.Message;
            metrics["duration_ms"] = stopwatch.ElapsedMilliseconds;
            metrics["success"] = false;
            
            var errorContext = new
            {
                ClientId = request.ClientId,
                SourceRealm = request.SourceRealm,
                TargetRealm = request.TargetRealm,
                Operation = "Migration",
                ErrorType = ex.GetType().Name,
                ErrorMessage = ex.Message,
                InnerException = ex.InnerException?.Message,
                StackTrace = _logger.IsEnabled(LogLevel.Debug) ? ex.StackTrace : null,
                Duration = stopwatch.ElapsedMilliseconds,
                MigratedBy = migratedBy
            };
            
            _logger.LogError(ex, 
                "Критическая ошибка при переносе клиента {ClientId}. Context: {@Context}", 
                request.ClientId, errorContext);
            
            result.Success = false;
            result.Errors.Add($"Критическая ошибка: {ex.Message}");

            // Выполнить откат при ошибке
            await ExecuteRollbackAsync(rollbackActions, request.ClientId).ConfigureAwait(false);

            // Логируем неудачную попытку
            await _auditService.LogClientMigrationAsync(
                migratedBy,
                request.ClientId,
                request.SourceRealm,
                request.TargetRealm,
                MigrationConstants.MigrationStatusFailed,
                $"Ошибка переноса: {ex.Message}"
            ).ConfigureAwait(false);

            return result;
        }
        finally
        {
            if (stopwatch != null)
            {
                stopwatch.Stop();
            }
        }
    }



    /// <summary>
    /// Выполнение отката операций при ошибке
    /// </summary>
    private async Task ExecuteRollbackAsync(Stack<Func<Task>> rollbackActions, string clientId)
    {
        if (rollbackActions == null || rollbackActions.Count == 0)
            return;
        
        if (string.IsNullOrWhiteSpace(clientId))
            clientId = "unknown";
        
        _logger.LogWarning("Выполняется откат операций для клиента {ClientId}. Количество операций: {Count}", 
            clientId, rollbackActions.Count);
        
        var rollbackErrors = new List<Exception>();
        
        while (rollbackActions.Count > 0)
        {
            var rollback = rollbackActions.Pop();
            if (rollback == null)
                continue;
                
            try
            {
                await rollback().ConfigureAwait(false);
            }
            catch (Exception rollbackEx)
            {
                rollbackErrors.Add(rollbackEx);
                _logger.LogError(rollbackEx, "Ошибка при выполнении отката для клиента {ClientId}", clientId);
                // Продолжаем выполнение остальных rollback операций даже при ошибке
            }
        }
        
        // Логируем сводку ошибок rollback
        if (rollbackErrors.Count > 0)
        {
            _logger.LogError("При выполнении отката для клиента {ClientId} произошло {ErrorCount} ошибок. " +
                "Может потребоваться ручное вмешательство для восстановления консистентности состояния.",
                clientId, rollbackErrors.Count);
        }
    }

    /// <summary>
    /// Получить детали клиента из исходного realm (TEST)
    /// </summary>
    private async Task<ClientDetailsDto?> GetSourceClientDetailsAsync(
        string clientId, 
        string sourceRealm, 
        CancellationToken cancellationToken)
    {
        var clientDetails = await _retryPolicy.ExecuteAsync(async () =>
            await _testKeycloak.GetClientDetailsAsync(
                clientId, sourceRealm, cancellationToken).ConfigureAwait(false));
        
        if (clientDetails == null)
        {
            _logger.LogWarning("Клиент {ClientId} не найден в realm {Realm}", clientId, sourceRealm);
        }
        
        return clientDetails;
    }

    /// <summary>
    /// Создать клиента в STAGE realm
    /// </summary>
    private async Task<string> CreateClientInStageAsync(
        ClientDetailsDto clientDetails,
        string targetRealm,
        CancellationToken cancellationToken)
    {
        var newInternalId = await _retryPolicy.ExecuteAsync(async () =>
            await _stageKeycloak.CreateClientAsync(
                clientDetails, targetRealm, cancellationToken).ConfigureAwait(false));
        
        if (string.IsNullOrWhiteSpace(newInternalId))
        {
            throw new InvalidOperationException(
                $"Не удалось получить internal ID для созданного клиента '{clientDetails.ClientId}'");
        }
        
        return newInternalId;
    }

    /// <summary>
    /// Проверка прав доступа пользователя на выполнение миграции
    /// </summary>
    private async Task<bool> HasMigrationPermissionAsync(
        string userId, 
        string targetRealm, 
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(userId) || string.IsNullOrWhiteSpace(targetRealm))
        {
            _logger.LogWarning("Не удалось проверить права доступа: userId или targetRealm пустые");
            return false;
        }
        
        try
        {
            // Получаем требуемые роли из конфигурации
            var requiredRoles = _configuration.GetSection("Migration:RequiredRoles")
                .Get<string[]>() ?? new[] { "admin", "migration-manager" };
            
            _logger.LogDebug("Проверка прав доступа для пользователя {UserId} в realm {Realm}. Требуемые роли: {Roles}", 
                userId, targetRealm, string.Join(", ", requiredRoles));
            
            // Используем IUserMenuService для проверки ролей пользователя
            if (_userMenuService == null)
            {
                _logger.LogWarning("IUserMenuService не зарегистрирован, проверка прав доступа пропущена для пользователя {UserId}", userId);
                // Если сервис не зарегистрирован, разрешаем доступ (для обратной совместимости)
                return true;
            }
            
            // Получаем роли пользователя из всех реалмов
            var userRoles = await _userMenuService.GetUserRolesFromAllRealmsAsync(userId, cancellationToken)
                .ConfigureAwait(false);
            
            if (userRoles == null || userRoles.Count == 0)
            {
                _logger.LogWarning("Пользователь {UserId} не имеет ролей", userId);
                return false;
            }
            
            // Проверяем, есть ли у пользователя хотя бы одна из требуемых ролей
            var userRoleNames = userRoles
                .Select(r => r.RoleName)
                .Where(r => !string.IsNullOrWhiteSpace(r))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
            
            var hasRequiredRole = requiredRoles.Any(requiredRole => 
                userRoleNames.Any(userRole => 
                    string.Equals(userRole, requiredRole, StringComparison.OrdinalIgnoreCase)));
            
            if (hasRequiredRole)
            {
                _logger.LogInformation("Пользователь {UserId} имеет необходимые права для миграции в realm {Realm}", 
                    userId, targetRealm);
                return true;
            }
            else
            {
                _logger.LogWarning("Пользователь {UserId} не имеет необходимых прав для миграции в realm {Realm}. " +
                    "Требуемые роли: {RequiredRoles}, Роли пользователя: {UserRoles}",
                    userId, targetRealm, string.Join(", ", requiredRoles), string.Join(", ", userRoleNames));
                return false;
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при проверке прав доступа для пользователя {UserId}", userId);
            // В случае ошибки проверки прав, отказываем в доступе для безопасности
            return false;
        }
    }

    /// <summary>
    /// Инициализирует метрики для мониторинга миграции
    /// </summary>
    private static Dictionary<string, object> InitializeMetrics(
        string clientId, 
        string sourceRealm, 
        string targetRealm, 
        string migratedBy)
    {
        return new Dictionary<string, object>
        {
            ["client_id"] = clientId,
            ["source_realm"] = sourceRealm,
            ["target_realm"] = targetRealm,
            ["migrated_by"] = migratedBy
        };
    }

}

