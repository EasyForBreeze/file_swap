using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Polly;
using Polly.Retry;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services.UsersManagement;

/// <summary>
/// Базовый класс для сервисов users-management API
/// Содержит общие методы для работы с HTTP запросами, токенами и валидацией
/// </summary>
public abstract class UsersManagementBaseService
{
    protected readonly HttpClient HttpClient;
    protected readonly KeycloakAdminSettings Settings;
    protected readonly IAuditService AuditService;
    protected readonly IHttpContextAccessor HttpContextAccessor;
    protected readonly ITokenExchangeService TokenExchangeService;
    protected readonly IPerformanceMetricsService MetricsService;
    protected readonly ILogger Logger;
    
    // Константы для версий API users-management
    protected const string ApiVersionV1 = "v1";
    protected const string ApiVersionV2 = "v2";
    protected const string MetricsOperationName = "UsersManagement.API";
    
    // Константы для валидации
    protected const int MaxRealmLength = 100;
    protected const int MaxEndpointLength = 2000;
    protected const int MaxTokenLength = 10000; // JWT токены могут быть длинными
    protected const int MaxUserIdLength = 200;
    protected const int MaxClientIdLength = 255;
    
    // Константы для retry логики
    private const int MaxRetryAttempts = 3;
    private const int BaseRetryDelayMs = 1000;
    private const int MaxRetryDelayMs = 10000;
    
    // Retry policy для transient ошибок
    private readonly AsyncRetryPolicy<HttpResponseMessage> _retryPolicy;
    
    // Константы для значений по умолчанию (проблема #14)
    private static class DefaultUsernames
    {
        public const string System = "system";
        public const string Anonymous = "anonymous";
        public const string Unknown = "unknown-user";
        public const string Error = "error-getting-username";
    }
    
    // Чувствительные типы claims для фильтрации (проблема #12)
    private static readonly HashSet<string> SensitiveClaimTypes = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
    {
        "access_token", "refresh_token", "id_token", "password", "secret", 
        "authorization", "cookie", "x-api-key", "token", "bearer"
    };
    
    protected UsersManagementBaseService(
        HttpClient httpClient,
        IOptions<KeycloakAdminSettings> settings,
        IAuditService auditService,
        IHttpContextAccessor httpContextAccessor,
        ITokenExchangeService tokenExchangeService,
        IPerformanceMetricsService metricsService,
        ILogger logger)
    {
        HttpClient = httpClient;
        Settings = settings?.Value ?? throw new ArgumentNullException(nameof(settings));
        AuditService = auditService;
        HttpContextAccessor = httpContextAccessor;
        TokenExchangeService = tokenExchangeService;
        MetricsService = metricsService ?? throw new ArgumentNullException(nameof(metricsService));
        Logger = logger;
        
        // Настраиваем HttpClient
        // Не изменяем Timeout, так как HttpClient может переиспользоваться (проблема #3)
        // Timeout будет управляться через CancellationTokenSource в методах
        
        // Безопасное добавление заголовка Accept (проблема #2)
        if (!HttpClient.DefaultRequestHeaders.Contains("Accept"))
        {
            HttpClient.DefaultRequestHeaders.TryAddWithoutValidation("Accept", "application/json");
        }
        
        // Настройка retry policy для transient ошибок (проблема #1)
        _retryPolicy = Policy
            .HandleResult<HttpResponseMessage>(r => !r.IsSuccessStatusCode && IsTransientError(r))
            .Or<HttpRequestException>()
            .Or<TaskCanceledException>(ex => ex.InnerException is TimeoutException)
            .Or<SocketException>()
            .WaitAndRetryAsync(
                retryCount: MaxRetryAttempts,
                sleepDurationProvider: retryAttempt => TimeSpan.FromMilliseconds(
                    Math.Min(BaseRetryDelayMs * Math.Pow(2, retryAttempt - 1), MaxRetryDelayMs)),
                onRetry: (outcome, timespan, retryCount, context) =>
                {
                    if (outcome.Exception != null)
                    {
                        Logger.LogWarning(
                            outcome.Exception,
                            "Retry attempt {RetryCount}/{MaxRetries} after {Delay}ms due to exception: {ExceptionType}",
                            retryCount, MaxRetryAttempts, timespan.TotalMilliseconds, outcome.Exception.GetType().Name);
                    }
                    else if (outcome.Result != null)
                    {
                        Logger.LogWarning(
                            "Retry attempt {RetryCount}/{MaxRetries} after {Delay}ms due to HTTP status {StatusCode}",
                            retryCount, MaxRetryAttempts, timespan.TotalMilliseconds, outcome.Result.StatusCode);
                    }
                });
    }
    
    /// <summary>
    /// Проверяет, является ли ошибка transient (временной) и подлежит ли retry
    /// </summary>
    private static bool IsTransientError(HttpResponseMessage response)
    {
        // Retry для 5xx ошибок (кроме 501 Not Implemented и 505 HTTP Version Not Supported)
        if ((int)response.StatusCode >= 500 && (int)response.StatusCode < 600)
        {
            var statusCode = (int)response.StatusCode;
            return statusCode != 501 && statusCode != 505;
        }
        
        // Retry для 408 Request Timeout и 429 Too Many Requests
        return response.StatusCode == System.Net.HttpStatusCode.RequestTimeout ||
               response.StatusCode == System.Net.HttpStatusCode.TooManyRequests;
    }
    
    /// <summary>
    /// Выполняет HTTP запрос с retry логикой для transient ошибок
    /// </summary>
    protected async Task<HttpResponseMessage> SendWithRetryAsync(
        HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        return await _retryPolicy.ExecuteAsync(async ct =>
        {
            try
            {
                return await HttpClient.SendAsync(request, ct).ConfigureAwait(false);
            }
            catch (Exception ex) when (ex is HttpRequestException || 
                                      (ex is TaskCanceledException tce && tce.InnerException is TimeoutException) ||
                                      ex is SocketException)
            {
                // Пробрасываем исключения, которые должны обрабатываться retry policy
                throw;
            }
        }, cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Валидация общих параметров запроса
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации. Не может быть null или пустым, максимальная длина: 10000 символов</param>
    /// <param name="realm">Название реалма. Не может быть null или пустым, максимальная длина: 100 символов, допустимые символы: буквы, цифры, дефисы, подчеркивания, точки</param>
    /// <param name="operationName">Необязательное имя операции для логирования</param>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах (null, пустая строка, недопустимые символы, превышение максимальной длины)</exception>
    protected void ValidateCommonParameters(string? accessToken, string? realm, string? operationName = null)
    {
        if (string.IsNullOrWhiteSpace(accessToken))
            throw new ArgumentException("Access token cannot be null or empty", nameof(accessToken));
        
        // Валидация длины accessToken (проблема #10)
        if (accessToken.Length > MaxTokenLength)
            throw new ArgumentException($"Access token cannot exceed {MaxTokenLength} characters", nameof(accessToken));
        
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", nameof(realm));
        
        // Валидация realm на инъекции (проблема #4)
        if (!IsValidRealm(realm))
            throw new ArgumentException("Realm contains invalid characters", nameof(realm));
        
        if (realm.Length > MaxRealmLength)
            throw new ArgumentException($"Realm cannot exceed {MaxRealmLength} characters", nameof(realm));
        
        if (!string.IsNullOrWhiteSpace(operationName))
        {
            Logger.LogDebug("Валидация параметров для операции {Operation}: Realm={Realm}", operationName, realm);
        }
    }
    
    /// <summary>
    /// Получить базовый URL для конкретного реалма с валидацией
    /// Приоритет: TokenEndpoint из token-exchange.json > KeycloakAdminSettings.BaseUrl
    /// </summary>
    /// <param name="realm">Название реалма для получения базового URL</param>
    /// <returns>Базовый URL для указанного реалма (нормализованный и валидированный)</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидном значении realm</exception>
    /// <exception cref="InvalidOperationException">Выбрасывается если BaseUrl не настроен ни в TokenEndpoint, ни в KeycloakAdminSettings, или имеет неверный формат</exception>
    protected string GetBaseUrlForRealm(string realm)
    {
        // Пытаемся получить базовый URL из TokenEndpoint для этого реалма
        var baseUrlFromTokenExchange = TokenExchangeService.GetBaseUrlForRealm(realm);
        if (!string.IsNullOrWhiteSpace(baseUrlFromTokenExchange))
        {
            // Валидация URL и использование validatedUri (проблема #6)
            if (!Uri.TryCreate(baseUrlFromTokenExchange, UriKind.Absolute, out var validatedUri))
            {
                Logger.LogWarning("Неверный формат базового URL из TokenEndpoint для реалма {Realm}: {BaseUrl}, используется fallback", 
                    realm, baseUrlFromTokenExchange);
            }
            else
            {
                Logger.LogDebug("Используется базовый URL из TokenEndpoint для реалма {Realm}: {BaseUrl}", 
                    realm, validatedUri.ToString());
                return validatedUri.ToString(); // Использовать нормализованный URL
            }
        }
        
        // Fallback на KeycloakAdminSettings.BaseUrl
        var fallbackBaseUrl = Settings.BaseUrl?.TrimEnd('/');
        if (string.IsNullOrWhiteSpace(fallbackBaseUrl))
        {
            Logger.LogError("BaseUrl не настроен ни в TokenEndpoint, ни в KeycloakAdminSettings для реалма {Realm}", realm);
            throw new InvalidOperationException($"BaseUrl не настроен для реалма {realm}");
        }
        
        // Валидация fallback URL
        if (!Uri.TryCreate(fallbackBaseUrl, UriKind.Absolute, out _))
        {
            Logger.LogError("Неверный формат BaseUrl в KeycloakAdminSettings: {BaseUrl}", fallbackBaseUrl);
            throw new InvalidOperationException($"Неверный формат BaseUrl: {fallbackBaseUrl}");
        }
        
        Logger.LogDebug("Используется базовый URL из KeycloakAdminSettings для реалма {Realm}: {BaseUrl}", 
            realm, fallbackBaseUrl);
        return fallbackBaseUrl;
    }
    
    /// <summary>
    /// Создать HTTP запрос с правильным токеном и URL
    /// </summary>
    /// <param name="method">HTTP метод запроса</param>
    /// <param name="endpoint">Endpoint для запроса (относительный путь)</param>
    /// <param name="accessToken">Access token для аутентификации</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>HTTP запрос с настроенными заголовками</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="InvalidOperationException">Выбрасывается при ошибках конфигурации</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции</exception>
    protected async Task<HttpRequestMessage> CreateRequestAsync(
        HttpMethod method,
        string endpoint,
        string accessToken,
        string realm,
        CancellationToken cancellationToken)
    {
        try
        {
            // Валидация входных параметров
            if (method == null)
                throw new ArgumentNullException(nameof(method));
            
            if (string.IsNullOrWhiteSpace(endpoint))
                throw new ArgumentException("Endpoint cannot be null or empty", nameof(endpoint));
            
            // Валидация endpoint на инъекции (проблема #7)
            if (!IsValidEndpoint(endpoint))
                throw new ArgumentException("Endpoint contains invalid characters", nameof(endpoint));
            
            if (endpoint.Length > MaxEndpointLength)
                throw new ArgumentException($"Endpoint cannot exceed {MaxEndpointLength} characters", nameof(endpoint));
            
            var token = await ResolveAccessTokenAsync(accessToken, realm, cancellationToken).ConfigureAwait(false);
            
            // Получаем базовый URL для этого реалма
            var baseUrl = GetBaseUrlForRealm(realm);
            
            // Безопасное формирование URL с использованием Uri (проблема #5)
            var baseUrlNormalized = baseUrl.TrimEnd('/');
            var endpointNormalized = endpoint.TrimStart('/');
            var fullUrl = $"{baseUrlNormalized}/{endpointNormalized}";
            
            // Валидация результата
            if (!Uri.TryCreate(fullUrl, UriKind.Absolute, out var validatedUri))
            {
                Logger.LogError("Неверный формат URL: {FullUrl}", fullUrl);
                throw new InvalidOperationException($"Неверный формат URL: {fullUrl}");
            }
            
            fullUrl = validatedUri.ToString();
            
            // Логируем только метод и endpoint, без полного URL (проблема #8)
            Logger.LogDebug("Создание запроса для реалма {Realm}: {Method} {Endpoint}", realm, method, endpoint);
            
            // HttpRequestMessage освобождается автоматически при отправке через HttpClient.SendAsync() (проблема #13)
            var request = new HttpRequestMessage(method, fullUrl);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            return request;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            Logger.LogWarning("Операция создания запроса была отменена для реалма {Realm}", realm);
            throw;
        }
    }

    /// <summary>
    /// Разрешить access token (выполнить token exchange если необходимо)
    /// </summary>
    /// <param name="accessToken">Исходный access token</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Access token для использования в запросе</returns>
    /// <exception cref="ArgumentException">Выбрасывается при невалидных параметрах</exception>
    /// <exception cref="InvalidOperationException">Выбрасывается при ошибках получения токена</exception>
    /// <exception cref="OperationCanceledException">Выбрасывается при отмене операции</exception>
    protected async Task<string> ResolveAccessTokenAsync(
        string accessToken,
        string realm,
        CancellationToken cancellationToken)
    {
        try
        {
            ValidateCommonParameters(accessToken, realm, "ResolveAccessToken");

            if (!TokenExchangeService.IsRealmSupported(realm))
            {
                Logger.LogDebug("Реалм {Realm} не поддерживает token exchange, используется оригинальный токен", realm);
                return accessToken;
            }

            var exchanged = await TokenExchangeService
                .GetTokenForRealmAsync(realm, cancellationToken)
                .ConfigureAwait(false);

            if (exchanged == null || string.IsNullOrWhiteSpace(exchanged.AccessToken))
            {
                Logger.LogError("Не удалось получить токен через token exchange для реалма {Realm}", realm);
                throw new InvalidOperationException($"Не удалось получить токен для реалма {realm}.");
            }

            // Валидация длины полученного токена (проблема #15)
            if (exchanged.AccessToken.Length > MaxTokenLength)
            {
                Logger.LogError("Полученный токен слишком длинный для реалма {Realm}", realm);
                throw new InvalidOperationException($"Токен для реалма {realm} имеет недопустимую длину.");
            }

            Logger.LogDebug("Токен успешно получен через token exchange для реалма {Realm}", realm);
            return exchanged.AccessToken;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            Logger.LogWarning("Операция получения токена была отменена для реалма {Realm}", realm);
            throw;
        }
    }
    
    /// <summary>
    /// Получить имя текущего пользователя для аудита с улучшенной обработкой ошибок
    /// </summary>
    /// <returns>
    /// Имя пользователя из claims в следующем приоритете:
    /// 1. preferred_username
    /// 2. name
    /// 3. Identity.Name
    /// 4. sub
    /// Если пользователь не аутентифицирован или имя не найдено, возвращается значение по умолчанию:
    /// - "system" - если HttpContext недоступен
    /// - "anonymous" - если пользователь не аутентифицирован
    /// - "unknown-user" - если не удалось извлечь username из claims
    /// - "error-getting-username" - если произошла ошибка при получении имени
    /// </returns>
    /// <remarks>
    /// Метод безопасно обрабатывает все возможные ошибки и никогда не выбрасывает исключения.
    /// Чувствительные данные (токены, пароли) фильтруются перед логированием.
    /// </remarks>
    protected string GetActingUsername()
    {
        try
        {
            var httpContext = HttpContextAccessor.HttpContext;
            if (httpContext == null)
            {
                Logger.LogWarning("HttpContext недоступен для получения имени пользователя");
                return DefaultUsernames.System;
            }
            
            var user = httpContext.User;
            // Исправление логической ошибки в проверке аутентификации (проблема #1)
            if (user == null || user.Identity?.IsAuthenticated != true)
            {
                Logger.LogWarning("Пользователь не аутентифицирован или User недоступен");
                return DefaultUsernames.Anonymous;
            }

            // Приоритет: preferred_username > name > Identity.Name > sub > неизвестный
            var username = user.FindFirst("preferred_username")?.Value
                ?? user.FindFirst("name")?.Value
                ?? user.Identity?.Name
                ?? user.FindFirst("sub")?.Value
                ?? null;

            if (string.IsNullOrWhiteSpace(username))
            {
                // Фильтрация чувствительных claims перед логированием (проблема #12)
                // Проверка уровня логирования для оптимизации производительности (проблема #19)
                if (Logger.IsEnabled(LogLevel.Warning))
                {
                    var safeClaims = user.Claims
                        .Where(c => !SensitiveClaimTypes.Contains(c.Type))
                        .Select(c => $"{c.Type}={c.Value}")
                        .ToList();
                    
                    Logger.LogWarning("Не удалось извлечь username из claims. Доступные безопасные claims: {Claims}",
                        string.Join(", ", safeClaims));
                }
                return DefaultUsernames.Unknown;
            }

            return username;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при получении имени пользователя для аудита");
            return DefaultUsernames.Error;
        }
    }

    /// <summary>
    /// Форматировать отображение целевого пользователя для аудита
    /// </summary>
    /// <param name="targetUsername">Имя целевого пользователя (может быть null или пустым)</param>
    /// <param name="fallbackIdentifier">Идентификатор для использования, если targetUsername не указан (обычно userId)</param>
    /// <returns>targetUsername, если он не пустой, иначе fallbackIdentifier</returns>
    protected static string FormatTargetDisplay(string? targetUsername, string fallbackIdentifier)
    {
        // Проблема #29: Обработка исключений при форматировании
        try
        {
            return string.IsNullOrWhiteSpace(targetUsername) ? fallbackIdentifier : targetUsername;
        }
        catch (Exception)
        {
            // В случае ошибки возвращаем fallbackIdentifier
            return fallbackIdentifier ?? string.Empty;
        }
    }
    
    #region Вспомогательные методы валидации
    
    /// <summary>
    /// Валидация realm на инъекции (проблема #4, #21)
    /// Проверяет, что значение содержит только допустимые символы и не превышает максимальную длину
    /// </summary>
    /// <param name="value">Значение для валидации</param>
    /// <returns>true, если значение валидно (содержит только буквы, цифры, дефисы, подчеркивания, точки), иначе false</returns>
    protected static bool IsValidRealm(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return false;
        
        if (value.Length > MaxRealmLength)
            return false;
        
        // Проверка на допустимые символы (буквы, цифры, дефисы, подчеркивания, точки)
        return value.All(c => char.IsLetterOrDigit(c) || c == '-' || c == '_' || c == '.');
    }
    
    /// <summary>
    /// Валидация endpoint на инъекции (проблема #7, #21)
    /// Проверяет, что значение содержит только допустимые символы для пути URL
    /// </summary>
    /// <param name="value">Значение для валидации</param>
    /// <returns>true, если значение валидно (содержит только буквы, цифры, дефисы, подчеркивания, точки, слеши), иначе false</returns>
    protected static bool IsValidEndpoint(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return false;
        
        if (value.Length > MaxEndpointLength)
            return false;
        
        // Проверка на допустимые символы для пути URL
        // Разрешаем буквы, цифры, дефисы, подчеркивания, точки, слеши
        return value.All(c => char.IsLetterOrDigit(c) || c == '-' || c == '_' || c == '.' || c == '/');
    }
    
    /// <summary>
    /// Валидация userId на инъекции и длину (проблема #21, #22)
    /// </summary>
    protected static bool IsValidUserId(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return false;
        
        if (value.Length > MaxUserIdLength)
            return false;
        
        // Проверка на допустимые символы (буквы, цифры, дефисы, подчеркивания, точки)
        return value.All(c => char.IsLetterOrDigit(c) || c == '-' || c == '_' || c == '.');
    }
    
    /// <summary>
    /// Валидация clientId на инъекции и длину (проблема #21, #22)
    /// </summary>
    protected static bool IsValidClientId(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return false;
        
        if (value.Length > MaxClientIdLength)
            return false;
        
        // Проверка на допустимые символы (буквы, цифры, дефисы, подчеркивания, точки)
        return value.All(c => char.IsLetterOrDigit(c) || c == '-' || c == '_' || c == '.');
    }
    
    #endregion
}

