using System;
using System.Linq;

namespace new_assistant.Infrastructure.Services.Keycloak;

/// <summary>
/// Валидатор параметров для Keycloak HTTP клиента
/// Содержит методы валидации и константы для проверки входных параметров
/// </summary>
public static class KeycloakParameterValidator
{
    // Константы для валидации параметров
    public const int MaxRealmLength = 100;
    public const int MaxClientIdLength = 200;
    public const int MaxUserIdLength = 200;
    public const int MaxUsernameLength = 200;
    public const int MaxRoleNameLength = 200;
    public const int MaxClientInternalIdLength = 200;
    public const int MaxSearchTermLength = 200;
    public const int MaxScopeLength = 1000;
    public const int MaxEventsLimit = 10000; // Разумный предел для событий
    public const int MaxBatchSize = 1000; // Разумный предел для batch операций
    
    /// <summary>
    /// Валидация параметра realm
    /// </summary>
    /// <param name="realm">Название реалма для валидации</param>
    /// <param name="paramName">Имя параметра для сообщения об ошибке</param>
    /// <exception cref="ArgumentException">Выбрасывается если realm null, empty или превышает максимальную длину</exception>
    public static void ValidateRealm(string realm, string paramName = "realm")
    {
        if (string.IsNullOrWhiteSpace(realm))
            throw new ArgumentException("Realm cannot be null or empty", paramName);
        
        if (realm.Length > MaxRealmLength)
            throw new ArgumentException(
                $"Realm length ({realm.Length}) exceeds maximum allowed length ({MaxRealmLength})", 
                paramName);
        
        // Проверка на недопустимые символы (control characters)
        if (realm.Any(c => char.IsControl(c)))
            throw new ArgumentException("Realm cannot contain control characters", paramName);
    }

    /// <summary>
    /// Валидация параметра clientId
    /// </summary>
    /// <param name="clientId">Client ID для валидации</param>
    /// <param name="paramName">Имя параметра для сообщения об ошибке</param>
    /// <exception cref="ArgumentException">Выбрасывается если clientId null, empty или превышает максимальную длину</exception>
    public static void ValidateClientId(string clientId, string paramName = "clientId")
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty", paramName);
        
        if (clientId.Length > MaxClientIdLength)
            throw new ArgumentException(
                $"Client ID length ({clientId.Length}) exceeds maximum allowed length ({MaxClientIdLength})", 
                paramName);
    }

    /// <summary>
    /// Валидация UUID формата для clientInternalId и userId
    /// </summary>
    /// <param name="uuid">UUID для валидации</param>
    /// <param name="paramName">Имя параметра для сообщения об ошибке</param>
    /// <exception cref="ArgumentException">Выбрасывается если uuid null, empty или превышает максимальную длину</exception>
    private static void ValidateUuid(string uuid, string paramName)
    {
        if (string.IsNullOrWhiteSpace(uuid))
            throw new ArgumentException($"{paramName} cannot be null or empty", paramName);
        
        if (uuid.Length > MaxClientInternalIdLength)
            throw new ArgumentException(
                $"{paramName} length ({uuid.Length}) exceeds maximum allowed length ({MaxClientInternalIdLength})", 
                paramName);
        
        // Проверка формата UUID
        if (!Guid.TryParse(uuid, out _))
        {
            throw new ArgumentException(
                $"{paramName} must be a valid UUID format. Value: {uuid}", 
                paramName);
        }
    }
    
    /// <summary>
    /// Валидация параметра userId
    /// </summary>
    /// <param name="userId">User ID для валидации</param>
    /// <param name="paramName">Имя параметра для сообщения об ошибке</param>
    /// <exception cref="ArgumentException">Выбрасывается если userId null, empty или превышает максимальную длину</exception>
    public static void ValidateUserId(string userId, string paramName = "userId")
    {
        ValidateUuid(userId, paramName);
    }
    
    /// <summary>
    /// Валидация параметра clientInternalId
    /// </summary>
    /// <param name="clientInternalId">Client internal ID для валидации</param>
    /// <param name="paramName">Имя параметра для сообщения об ошибке</param>
    /// <exception cref="ArgumentException">Выбрасывается если clientInternalId null, empty или превышает максимальную длину</exception>
    public static void ValidateClientInternalId(string clientInternalId, string paramName = "clientInternalId")
    {
        ValidateUuid(clientInternalId, paramName);
    }

    /// <summary>
    /// Валидация параметра username
    /// </summary>
    /// <param name="username">Username для валидации</param>
    /// <param name="paramName">Имя параметра для сообщения об ошибке</param>
    /// <exception cref="ArgumentException">Выбрасывается если username null, empty или превышает максимальную длину</exception>
    public static void ValidateUsername(string username, string paramName = "username")
    {
        if (string.IsNullOrWhiteSpace(username))
            throw new ArgumentException("Username cannot be null or empty", paramName);
        
        if (username.Length > MaxUsernameLength)
            throw new ArgumentException(
                $"Username length ({username.Length}) exceeds maximum allowed length ({MaxUsernameLength})", 
                paramName);
    }

    /// <summary>
    /// Валидация параметра roleName
    /// </summary>
    /// <param name="roleName">Role name для валидации</param>
    /// <param name="paramName">Имя параметра для сообщения об ошибке</param>
    /// <exception cref="ArgumentException">Выбрасывается если roleName null, empty или превышает максимальную длину</exception>
    public static void ValidateRoleName(string roleName, string paramName = "roleName")
    {
        if (string.IsNullOrWhiteSpace(roleName))
            throw new ArgumentException("Role name cannot be null or empty", paramName);
        
        if (roleName.Length > MaxRoleNameLength)
            throw new ArgumentException(
                $"Role name length ({roleName.Length}) exceeds maximum allowed length ({MaxRoleNameLength})", 
                paramName);
    }
    
    /// <summary>
    /// Валидация параметра searchTerm
    /// </summary>
    /// <param name="searchTerm">Search term для валидации</param>
    /// <param name="paramName">Имя параметра для сообщения об ошибке</param>
    /// <exception cref="ArgumentNullException">Выбрасывается если searchTerm равен null</exception>
    /// <exception cref="ArgumentException">Выбрасывается если searchTerm превышает максимальную длину или содержит control characters</exception>
    public static void ValidateSearchTerm(string searchTerm, string paramName = "searchTerm")
    {
        if (searchTerm == null)
            throw new ArgumentNullException(paramName);
        
        if (searchTerm.Length > MaxSearchTermLength)
            throw new ArgumentException(
                $"Search term length ({searchTerm.Length}) exceeds maximum allowed length ({MaxSearchTermLength})", 
                paramName);
        
        // Проверка на control characters (кроме стандартных символов новой строки)
        if (searchTerm.Any(c => char.IsControl(c) && c != '\r' && c != '\n'))
            throw new ArgumentException("Search term cannot contain control characters", paramName);
    }
    
    /// <summary>
    /// Валидация параметра scope
    /// </summary>
    /// <param name="scope">Scope для валидации</param>
    /// <param name="paramName">Имя параметра для сообщения об ошибке</param>
    /// <exception cref="ArgumentException">Выбрасывается если scope пустой, превышает максимальную длину или содержит control characters</exception>
    public static void ValidateScope(string? scope, string paramName = "scope")
    {
        if (scope == null)
            return; // null допустим
        
        if (string.IsNullOrWhiteSpace(scope))
            throw new ArgumentException("Scope cannot be empty or whitespace", paramName);
        
        if (scope.Length > MaxScopeLength)
            throw new ArgumentException(
                $"Scope length ({scope.Length}) exceeds maximum allowed length ({MaxScopeLength})", 
                paramName);
        
        // Проверка на control characters (кроме пробела)
        if (scope.Any(c => char.IsControl(c) && c != ' '))
            throw new ArgumentException("Scope cannot contain control characters", paramName);
    }
}

