using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using new_assistant.Configuration;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;
using new_assistant.Core.Models;

namespace new_assistant.Infrastructure.Services.Keycloak;

/// <summary>
/// Клиент для работы с client roles (роли клиентов)
/// </summary>
public class KeycloakClientRolesClient : KeycloakRolesClientBase, IKeycloakClientRolesClient
{
    
    private int MaxRoleNameLengthConfig
    {
        get
        {
            if (Settings.Roles != null)
                return Settings.Roles.MaxRoleNameLength;
            
            Logger.LogWarning("Settings.Roles is null, using default value {DefaultValue} for MaxRoleNameLength", MaxRoleNameLength);
            return MaxRoleNameLength;
        }
    }
    
    private int MaxRoleDescriptionLengthConfig
    {
        get
        {
            if (Settings.Roles != null)
                return Settings.Roles.MaxRoleDescriptionLength;
            
            Logger.LogWarning("Settings.Roles is null, using default value {DefaultValue} for MaxRoleDescriptionLength", MaxRoleDescriptionLength);
            return MaxRoleDescriptionLength;
        }
    }
    
    private TimeSpan RolesCacheDuration
    {
        get
        {
            if (Settings.Roles != null)
                return Settings.Roles.CacheDuration;
            
            var defaultValue = TimeSpan.FromMinutes(30);
            Logger.LogWarning("Settings.Roles is null, using default value {DefaultValue} for CacheDuration", defaultValue);
            return defaultValue;
        }
    }
    
    protected override int GetMaxRoleNameLength() => MaxRoleNameLengthConfig;
    protected override int GetMaxRoleDescriptionLength() => MaxRoleDescriptionLengthConfig;
    
    public KeycloakClientRolesClient(
        HttpClient httpClient,
        KeycloakAdminSettings settings,
        ILogger logger,
        IKeycloakCacheService cacheService,
        IPerformanceMetricsService metricsService)
        : base(httpClient, settings, logger, cacheService, metricsService)
    {
        if (settings.Roles == null)
        {
            Logger.LogWarning("Settings.Roles is null. Default values will be used for all role-related settings.");
        }
    }
    
    // Все методы валидации, выполнения запросов и вспомогательные методы теперь в базовом классе KeycloakRolesClientBase
    
    /// <summary>
    /// Получение ролей клиента
    /// </summary>
    public async Task<List<KeycloakRoleDto>> GetClientRolesAsync(string realm, string clientInternalId, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateClientInternalId(clientInternalId);
        
        var cacheKey = $"client-roles:{realm}:{clientInternalId}";
        var cachedRoles = await CacheService.GetAsync<List<KeycloakRoleDto>>(cacheKey, cancellationToken).ConfigureAwait(false);
        if (cachedRoles != null)
        {
            RecordCacheHit(cacheKey);
            RecordSuccess(nameof(GetClientRolesAsync));
            return cachedRoles;
        }
        
        RecordCacheMiss(cacheKey);
        
        var endpoint = $"admin/realms/{realm}/clients/{clientInternalId}/roles";
        var result = await GetListAsync<KeycloakRoleDto>(endpoint, cancellationToken).ConfigureAwait(false);
        
        if (!result.IsSuccess)
        {
            Logger.LogWarning("Не удалось получить роли клиента: {Error}", result.ErrorMessage);
            return new List<KeycloakRoleDto>();
        }
        
        var roles = result.Value ?? new List<KeycloakRoleDto>();
        
        if (roles.Any())
        {
            await CacheService.SetAsync(cacheKey, roles, RolesCacheDuration, cancellationToken).ConfigureAwait(false);
        }
        
        RecordSuccess(nameof(GetClientRolesAsync));
        return roles;
    }
    
    /// <summary>
    /// Получение client scopes клиента (default или optional)
    /// </summary>
    public async Task<List<string>> GetClientScopesAsync(string realm, string clientInternalId, bool isDefault, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateClientInternalId(clientInternalId);
        
        var scopeType = isDefault ? "default-client-scopes" : "optional-client-scopes";
        var endpoint = $"admin/realms/{realm}/clients/{clientInternalId}/{scopeType}";
        
        var result = await GetListAsync<KeycloakClientScopeDto>(endpoint, cancellationToken);
        
        if (!result.IsSuccess || result.Value == null)
        {
            return new List<string>();
        }
        
        var scopes = result.Value
            .Where(s => !string.IsNullOrWhiteSpace(s.Name))
            .Select(s => s.Name)
            .ToList();
        
        RecordSuccess(nameof(GetClientScopesAsync));
        return scopes;
    }
    
    /// <summary>
    /// Получение service account пользователя для клиента
    /// </summary>
    public async Task<string?> GetServiceAccountUserIdAsync(string realm, string clientInternalId, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateClientInternalId(clientInternalId);
        
        var endpoint = $"admin/realms/{realm}/clients/{clientInternalId}/service-account-user";
        
        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation");
            return null;
        }
        
        try
        {
            if (!ValidateEndpoint(endpoint, out var endpointError))
            {
                Logger.LogError("Invalid endpoint: {EndpointError}", endpointError);
                return null;
            }
            
            using var request = await CreateAuthorizedRequestWithAcceptAsync(HttpMethod.Get, endpoint, cancellationToken).ConfigureAwait(false);
            using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await ReadErrorContentAsync(response, cancellationToken).ConfigureAwait(false);
                if (Logger.IsEnabled(LogLevel.Debug))
                {
                    Logger.LogDebug("Не удалось получить service account: {StatusCode} - {ErrorContent}", response.StatusCode, errorContent);
                }
                return null;
            }
            
            if (response.Content == null)
            {
                return null;
            }
            
            var content = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            if (string.IsNullOrWhiteSpace(content))
            {
                return null;
            }
            
            try
            {
                var user = JsonSerializer.Deserialize<UserDto>(content, DefaultJsonOptions);
                var userId = user?.Id;
                
                if (userId != null)
                {
                    RecordSuccess(nameof(GetServiceAccountUserIdAsync));
                }
                
                return userId;
            }
            catch (JsonException ex)
            {
                Logger.LogError(ex, "Ошибка десериализации service account для {Endpoint}", endpoint);
                return null;
            }
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при получении service account из {Endpoint}", endpoint);
            return null;
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Создать роль клиента
    /// </summary>
    public async Task CreateClientRoleAsync(string realm, string clientInternalId, string roleName, string? description = null, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateClientInternalId(clientInternalId);
        ValidateRoleName(roleName);
        ValidateRoleDescription(description);
        
        var existingRoles = await GetClientRolesAsync(realm, clientInternalId, cancellationToken).ConfigureAwait(false);
        if (existingRoles.Any(r => string.Equals(r.Name, roleName, StringComparison.OrdinalIgnoreCase)))
        {
            Logger.LogInformation("Роль {RoleName} уже существует для клиента {ClientInternalId} в реалме {Realm}", 
                roleName, clientInternalId, realm);
            throw new InvalidOperationException($"Роль {roleName} уже существует");
        }
        
        var finalDescription = description?.Length > MaxRoleDescriptionLengthConfig 
            ? description.Substring(0, MaxRoleDescriptionLengthConfig) 
            : description ?? $"Role {roleName}";
        
        var endpoint = $"admin/realms/{realm}/clients/{clientInternalId}/roles";
        var roleData = new CreateKeycloakRoleRequest
        {
            Name = roleName,
            Description = finalDescription,
            ClientRole = true
        };
        
        // Выполняем операцию создания роли
        await ExecuteOperationAsync(endpoint, HttpMethod.Post, roleData, cancellationToken);
        
        // Инвалидируем кэш только после успешного создания роли
        var cacheKey = $"client-roles:{realm}:{clientInternalId}";
        await CacheService.RemoveAsync(cacheKey, cancellationToken).ConfigureAwait(false);
        
        RecordSuccess(nameof(CreateClientRoleAsync));
    }

    /// <summary>
    /// Удалить роль клиента
    /// </summary>
    public async Task DeleteClientRoleAsync(string realm, string clientInternalId, string roleName, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateClientInternalId(clientInternalId);
        ValidateRoleName(roleName);
        
        var endpoint = $"admin/realms/{realm}/clients/{clientInternalId}/roles/{roleName}";
        
        // Выполняем операцию удаления роли
        await ExecuteOperationAsync(endpoint, HttpMethod.Delete, null, cancellationToken);
        
        // Инвалидируем кэш только после успешного удаления роли
        var cacheKey = $"client-roles:{realm}:{clientInternalId}";
        await CacheService.RemoveAsync(cacheKey, cancellationToken).ConfigureAwait(false);
        
        RecordSuccess(nameof(DeleteClientRoleAsync));
    }
}

