using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using new_assistant.Configuration;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;
using new_assistant.Core.Models;

namespace new_assistant.Infrastructure.Services.Keycloak;

/// <summary>
/// Клиент для назначения и удаления ролей пользователям
/// </summary>
public class KeycloakRoleMappingClient : KeycloakRolesClientBase, IKeycloakRoleMappingClient
{
    private const string NameProperty = "name";
    private const string IdProperty = "id";
    private const string RealmMappingsProperty = "realmMappings";
    private const string ClientMappingsProperty = "clientMappings";
    private const string MappingsProperty = "mappings";
    
    private readonly KeycloakRealmRolesClient _realmRolesClient;
    private int MaxRoleNameLengthConfig
    {
        get
        {
            if (Settings.Roles != null)
                return Settings.Roles.MaxRoleNameLength;
            
            Logger.LogWarning("Settings.Roles is null, using default value {DefaultValue} for MaxRoleNameLength", MaxRoleNameLength);
            return MaxRoleNameLength;
        }
    }
    
    private int MaxRoleIdLengthConfig
    {
        get
        {
            if (Settings.Roles != null)
                return Settings.Roles.MaxRoleIdLength;
            
            Logger.LogWarning("Settings.Roles is null, using default value {DefaultValue} for MaxRoleIdLength", MaxRoleIdLength);
            return MaxRoleIdLength;
        }
    }
    
    
    public KeycloakRoleMappingClient(
        HttpClient httpClient,
        KeycloakAdminSettings settings,
        ILogger logger,
        IKeycloakCacheService cacheService,
        IPerformanceMetricsService metricsService,
        KeycloakRealmRolesClient realmRolesClient)
        : base(httpClient, settings, logger, cacheService, metricsService)
    {
        _realmRolesClient = realmRolesClient ?? throw new ArgumentNullException(nameof(realmRolesClient));
        
        if (settings.Roles == null)
        {
            Logger.LogWarning("Settings.Roles is null. Default values will be used for all role-related settings.");
        }
    }
    
    protected override int GetMaxRoleNameLength() => MaxRoleNameLengthConfig;
    protected override int GetMaxRoleIdLength() => MaxRoleIdLengthConfig;
    
    // Все методы валидации, выполнения запросов и вспомогательные методы теперь в базовом классе KeycloakRolesClientBase
    
    /// <summary>
    /// Получение role mappings для пользователя
    /// </summary>
    public async Task<List<KeycloakClientRoleDto>> GetUserRoleMappingsAsync(string realm, string userId, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateUserId(userId);
        
        var endpoint = $"admin/realms/{realm}/users/{userId}/role-mappings";
        
        var result = await ExecuteRequestAsync<KeycloakRoleMappingsDto>(
            endpoint, 
            HttpMethod.Get, 
            ErrorHandlingStrategy.ReturnEmpty, 
            null, 
            cancellationToken);
        
        if (!result.IsSuccess || result.Value == null)
        {
            if (Logger.IsEnabled(LogLevel.Debug))
            {
                Logger.LogDebug("Не удалось получить role mappings для пользователя {UserId} в реалме {Realm}", userId, realm);
            }
            return new List<KeycloakClientRoleDto>();
        }
        
        var roleMappings = result.Value;
        
        var estimatedCapacity = (roleMappings.RealmMappings?.Count ?? 0) +
            (roleMappings.ClientMappings?.Values
                .Sum(cm => cm.Mappings?.Count ?? 0) ?? 0);
        
        var allRoles = new List<KeycloakClientRoleDto>(Math.Max(estimatedCapacity, 16) + 10);
        
        if (roleMappings.RealmMappings != null)
        {
            foreach (var realmRole in roleMappings.RealmMappings)
            {
                allRoles.Add(new KeycloakClientRoleDto
                {
                    Id = realmRole.Id,
                    Name = realmRole.Name,
                    Description = realmRole.Description,
                    ClientRole = realmRole.ClientRole,
                    Composite = realmRole.Composite,
                    ContainerId = realmRole.ContainerId,
                    Attributes = realmRole.Attributes,
                    ClientId = null
                });
            }
        }
        
        if (roleMappings.ClientMappings != null)
        {
            foreach (var clientMapping in roleMappings.ClientMappings)
            {
                var clientId = clientMapping.Key;
                if (clientMapping.Value.Mappings != null)
                {
                    foreach (var clientRole in clientMapping.Value.Mappings)
                    {
                        allRoles.Add(new KeycloakClientRoleDto
                        {
                            Id = clientRole.Id,
                            Name = clientRole.Name,
                            Description = clientRole.Description,
                            ClientRole = clientRole.ClientRole,
                            Composite = clientRole.Composite,
                            ContainerId = clientRole.ContainerId,
                            Attributes = clientRole.Attributes,
                            ClientId = clientId
                        });
                    }
                }
            }
        }
        
        if (Logger.IsEnabled(LogLevel.Debug))
        {
            Logger.LogDebug("Получено {Count} ролей для пользователя {UserId} в реалме {Realm}", 
                allRoles.Count, userId, realm);
        }
        
        return allRoles;
    }
    
    /// <summary>
    /// Получить роли клиента для пользователя
    /// </summary>
    public async Task<List<string>> GetUserClientRolesAsync(string realm, string userId, string clientUuid, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateUserId(userId);
        ValidateClientInternalId(clientUuid);
        
        var endpoint = $"admin/realms/{realm}/users/{userId}/role-mappings/clients/{clientUuid}";
        
        var result = await GetListAsync<KeycloakRoleDto>(endpoint, cancellationToken);
        
        if (!result.IsSuccess || result.Value == null)
        {
            if (result.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                if (Logger.IsEnabled(LogLevel.Debug))
                {
                    Logger.LogDebug("У пользователя {UserId} нет ролей клиента {ClientUuid} в реалме {Realm}", 
                        userId, clientUuid, realm);
                }
            }
            return new List<string>();
        }
        
        // Явная проверка на null для безопасности
        return (result.Value ?? new List<KeycloakRoleDto>())
            .Where(r => !string.IsNullOrWhiteSpace(r.Name))
            .Select(r => r.Name)
            .ToList();
    }
    
    // Используем метод GetRealmRoleByNameAsync из _realmRolesClient вместо прямого HTTP запроса
    
    /// <summary>
    /// Назначить realm роль пользователю
    /// </summary>
    public async Task AssignRealmRoleToUserAsync(string realm, string userId, string roleName, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateUserId(userId);
        ValidateRoleName(roleName);
        
        var roleData = await _realmRolesClient.GetRealmRoleByNameAsync(realm, roleName, cancellationToken).ConfigureAwait(false);
        
        var endpoint = $"admin/realms/{realm}/users/{userId}/role-mappings/realm";
        await ExecuteOperationAsync(endpoint, HttpMethod.Post, new[] { roleData }, cancellationToken).ConfigureAwait(false);
        
        // Инвалидируем связанные ключи кэша
        await InvalidateUserRoleCacheAsync(realm, userId, cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Инвалидирует связанные ключи кэша для пользователя (user-role-mappings и available-roles)
    /// </summary>
    private async Task InvalidateUserRoleCacheAsync(string realm, string userId, CancellationToken cancellationToken)
    {
        var userRoleMappingsCacheKey = $"user-role-mappings:{realm}:{userId}";
        var availableRolesCacheKey = $"available-roles:{realm}:{userId}";
        
        // Создаем CancellationTokenSource с timeout для защиты от зависаний
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        cts.CancelAfter(TimeSpan.FromSeconds(5)); // 5 секунд timeout для операций инвалидации кэша
        
        try
        {
            // Выполняем инвалидацию параллельно для лучшей производительности
            await Task.WhenAll(
                CacheService.RemoveAsync(userRoleMappingsCacheKey, cts.Token),
                CacheService.RemoveAsync(availableRolesCacheKey, cts.Token)
            ).ConfigureAwait(false);
        }
        catch (OperationCanceledException ex) when (cts.Token.IsCancellationRequested && !cancellationToken.IsCancellationRequested)
        {
            // Timeout при инвалидации кэша (не критично, но логируем)
            Logger.LogWarning(ex, "Timeout при инвалидации кэша для пользователя {UserId} в реалме {Realm}. Ключи: {Key1}, {Key2}", 
                userId, realm, userRoleMappingsCacheKey, availableRolesCacheKey);
        }
    }
    
    private JsonElement? FindRealmRoleInMappings(JsonElement roleMappingsJson, string roleName)
    {
        if (!roleMappingsJson.TryGetProperty(RealmMappingsProperty, out var realmMappings) || 
            realmMappings.ValueKind != JsonValueKind.Array)
        {
            return null;
        }
        
        foreach (var role in realmMappings.EnumerateArray())
        {
            if (role.TryGetProperty(NameProperty, out var name) && name.GetString() == roleName)
            {
                return role;
            }
        }
        
        return null;
    }
    
    private (JsonElement role, string? clientId)? FindClientRoleInMappings(JsonElement roleMappingsJson, string roleName)
    {
        if (!roleMappingsJson.TryGetProperty(ClientMappingsProperty, out var clientMappings) || 
            clientMappings.ValueKind != JsonValueKind.Object)
        {
            return null;
        }
        
        foreach (var clientMapping in clientMappings.EnumerateObject())
        {
            if (!clientMapping.Value.TryGetProperty(MappingsProperty, out var mappings) || 
                mappings.ValueKind != JsonValueKind.Array)
            {
                continue;
            }
            
            foreach (var role in mappings.EnumerateArray())
            {
                if (role.TryGetProperty(NameProperty, out var name) && name.GetString() == roleName)
                {
                    var clientId = clientMapping.Value.TryGetProperty(IdProperty, out var idProp) 
                        ? idProp.GetString() 
                        : null;
                    return (role, clientId);
                }
            }
        }
        
        return null;
    }
    
    private async Task<JsonElement?> GetUserRoleMappingsJsonAsync(string realm, string userId, CancellationToken cancellationToken)
    {
        var endpoint = $"admin/realms/{realm}/users/{userId}/role-mappings";
        
        JsonDocument? doc = null;
        try
        {
            var result = await ExecuteRequestAsync<JsonDocument>(
                endpoint, 
                HttpMethod.Get, 
                ErrorHandlingStrategy.ReturnNull, 
                null, 
                cancellationToken);
            
            if (!result.IsSuccess || result.Value == null)
            {
                return null;
            }
            
            doc = result.Value;
            var rootElement = doc.RootElement;
            // Клонируем элемент, чтобы он был независим от JsonDocument
            return rootElement.Clone();
        }
        finally
        {
            // Гарантируем освобождение ресурсов даже при исключениях
            doc?.Dispose();
        }
    }
    
    private async Task RemoveRealmRoleFromUserAsync(string realm, string userId, JsonElement role, CancellationToken cancellationToken)
    {
        var deleteEndpoint = $"admin/realms/{realm}/users/{userId}/role-mappings/realm";
        if (!ValidateEndpoint(deleteEndpoint, out var deleteEndpointError))
        {
            Logger.LogError(deleteEndpointError);
            throw new InvalidOperationException(deleteEndpointError ?? "Invalid endpoint");
        }
        
        using var request = await CreateAuthorizedRequestWithAcceptAsync(HttpMethod.Delete, deleteEndpoint, cancellationToken).ConfigureAwait(false);
        request.Content = JsonContent.Create(new[] { role });
        
        using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
        
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await ReadErrorContentAsync(response, cancellationToken).ConfigureAwait(false);
            var roleName = role.TryGetProperty(NameProperty, out var nameProp) ? nameProp.GetString() : "unknown";
            Logger.LogError("Ошибка удаления realm роли {RoleName}: {StatusCode} - {ErrorContent}", roleName, response.StatusCode, errorContent);
            throw new HttpRequestException($"Не удалось удалить realm роль: {response.StatusCode}");
        }
    }
    
    private async Task RemoveClientRoleFromUserAsync(string realm, string userId, string clientId, JsonElement role, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(clientId))
        {
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        }
        
        var deleteEndpoint = $"admin/realms/{realm}/users/{userId}/role-mappings/clients/{clientId}";
        if (!ValidateEndpoint(deleteEndpoint, out var clientDeleteEndpointError))
        {
            Logger.LogError(clientDeleteEndpointError);
            throw new InvalidOperationException(clientDeleteEndpointError ?? "Invalid endpoint");
        }
        
        using var request = await CreateAuthorizedRequestWithAcceptAsync(HttpMethod.Delete, deleteEndpoint, cancellationToken).ConfigureAwait(false);
        request.Content = JsonContent.Create(new[] { role });
        
        using var response = await HttpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
        
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await ReadErrorContentAsync(response, cancellationToken).ConfigureAwait(false);
            var roleName = role.TryGetProperty(NameProperty, out var nameProp) ? nameProp.GetString() : "unknown";
            Logger.LogError("Ошибка удаления client роли {RoleName}: {StatusCode} - {ErrorContent}", roleName, response.StatusCode, errorContent);
            throw new HttpRequestException($"Не удалось удалить client роль: {response.StatusCode}");
        }
    }
    
    /// <summary>
    /// Удалить любую роль у пользователя (realm или client role)
    /// </summary>
    public async Task RemoveRoleFromUserAsync(string realm, string userId, string roleName, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateUserId(userId);
        ValidateRoleName(roleName);
        
        cancellationToken.ThrowIfCancellationRequested();
        
        var stopwatch = Stopwatch.StartNew();
        var acquired = await SafeWaitSemaphore(cancellationToken).ConfigureAwait(false);
        if (!acquired)
        {
            Logger.LogWarning("Semaphore disposed, cannot execute operation");
            return;
        }
        
        try
        {
            var roleMappingsJson = await GetUserRoleMappingsJsonAsync(realm, userId, cancellationToken).ConfigureAwait(false);
            if (!roleMappingsJson.HasValue)
            {
                throw new InvalidOperationException($"Не удалось получить role mappings для пользователя {userId}");
            }
            
            var realmRole = FindRealmRoleInMappings(roleMappingsJson.Value, roleName);
            if (realmRole.HasValue)
            {
                await RemoveRealmRoleFromUserAsync(realm, userId, realmRole.Value, cancellationToken).ConfigureAwait(false);
                
                // Инвалидируем связанные ключи кэша
                await InvalidateUserRoleCacheAsync(realm, userId, cancellationToken).ConfigureAwait(false);
                
                return;
            }
            
            var clientRoleResult = FindClientRoleInMappings(roleMappingsJson.Value, roleName);
            if (clientRoleResult.HasValue)
            {
                var (clientRole, clientId) = clientRoleResult.Value;
                if (!string.IsNullOrWhiteSpace(clientId))
                {
                    await RemoveClientRoleFromUserAsync(realm, userId, clientId, clientRole, cancellationToken).ConfigureAwait(false);
                    
                    // Инвалидируем связанные ключи кэша
                    await InvalidateUserRoleCacheAsync(realm, userId, cancellationToken).ConfigureAwait(false);
                    
                    return;
                }
            }
            
            Logger.LogWarning("Роль {RoleName} не найдена ни в realm, ни в client roles для пользователя {UserId}", roleName, userId);
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            Logger.LogError("Timeout при удалении роли у пользователя");
            throw;
        }
        catch (TaskCanceledException)
        {
            Logger.LogWarning("Операция удаления роли у пользователя была отменена (TaskCanceledException)");
            throw;
        }
        catch (OperationCanceledException)
        {
            Logger.LogWarning("Операция удаления роли у пользователя была отменена");
            throw;
        }
        catch (HttpRequestException)
        {
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при удалении роли {RoleName} у пользователя {UserId} в реалме {Realm}", roleName, userId, realm);
            throw;
        }
        finally
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                RecordRequestTime(stopwatch.ElapsedMilliseconds);
            }
            SafeReleaseSemaphore();
        }
    }
    
    /// <summary>
    /// Назначает client роль пользователю
    /// </summary>
    public async Task AssignClientRoleToUserAsync(string realm, string userId, string clientInternalId, string roleId, string roleName, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateUserId(userId);
        ValidateClientInternalId(clientInternalId);
        ValidateRoleId(roleId);
        ValidateRoleName(roleName);
        
        var endpoint = $"admin/realms/{realm}/users/{userId}/role-mappings/clients/{clientInternalId}";
        var roleMapping = new RoleMappingRequest
        {
            Id = roleId,
            Name = roleName
        };
        
        await ExecuteOperationAsync(endpoint, HttpMethod.Post, new[] { roleMapping }, cancellationToken).ConfigureAwait(false);
        
        // Инвалидируем связанные ключи кэша
        await InvalidateUserRoleCacheAsync(realm, userId, cancellationToken).ConfigureAwait(false);
    }
    
    /// <summary>
    /// Удаляет client роль у пользователя
    /// </summary>
    public async Task RemoveClientRoleFromUserAsync(string realm, string userId, string clientInternalId, string roleId, string roleName, CancellationToken cancellationToken = default)
    {
        ValidateRealm(realm);
        ValidateUserId(userId);
        ValidateClientInternalId(clientInternalId);
        ValidateRoleId(roleId);
        ValidateRoleName(roleName);
        
        var endpoint = $"admin/realms/{realm}/users/{userId}/role-mappings/clients/{clientInternalId}";
        var roleMapping = new RoleMappingRequest
        {
            Id = roleId,
            Name = roleName
        };
        
        await ExecuteOperationAsync(endpoint, HttpMethod.Delete, new[] { roleMapping }, cancellationToken).ConfigureAwait(false);
        
        // Инвалидируем связанные ключи кэша
        await InvalidateUserRoleCacheAsync(realm, userId, cancellationToken).ConfigureAwait(false);
    }
}

