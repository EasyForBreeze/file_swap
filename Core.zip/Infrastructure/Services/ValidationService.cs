using new_assistant.Core.Interfaces;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using System.Net;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для валидации данных клиентов Keycloak
/// </summary>
public class ValidationService : IValidationService
{
    // Константы для валидации
    private const int MaxRoleNameLength = 255; // Keycloak ограничение (также настраивается через конфигурацию)
    private const int MinRoleNameLength = 1; // Минимальная длина имени роли
    private const int MaxRedirectUriLength = 2048; // Разумное ограничение для браузеров
    private const int MinRedirectUriLength = 1; // Минимальная длина URI
    private const int MaxRoleNameLengthForRegex = 1000; // Защита от ReDoS атак
    private static readonly TimeSpan RegexMatchTimeout = TimeSpan.FromMilliseconds(100); // Таймаут для Regex
    
    private readonly ILogger<ValidationService> _logger;
    private readonly int _maxRoleNameLength;
    
    /// <summary>
    /// Зарезервированные имена ролей Keycloak, которые нельзя использовать
    /// </summary>
    private static readonly HashSet<string> ReservedRoleNames = new(StringComparer.OrdinalIgnoreCase)
    {
        "offline_access",
        "uma_authorization",
        "uma_protection"
    };
    
    /// <summary>
    /// Регулярное выражение для валидации имени роли
    /// Разрешает: латинские буквы (a-z, A-Z), цифры (0-9), дефисы (-), подчёркивания (_) и точки (.)
    /// </summary>
    private static readonly Regex RoleNameRegex = 
        new(@"^[a-zA-Z0-9_.-]+$", 
            RegexOptions.Compiled | RegexOptions.CultureInvariant,
            RegexMatchTimeout);

    /// <summary>
    /// Конструктор сервиса валидации
    /// </summary>
    /// <param name="logger">Логгер для записи событий</param>
    /// <param name="keycloakSettings">Настройки Keycloak (опционально, может быть null)</param>
    public ValidationService(
        ILogger<ValidationService> logger,
        IOptions<KeycloakAdminSettings>? keycloakSettings = null)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        
        // Используем значение из конфигурации, если доступно, иначе константу
        var configuredMaxLength = keycloakSettings?.Value?.Roles?.MaxRoleNameLength;
        var maxLength = configuredMaxLength > 0 ? configuredMaxLength.Value : MaxRoleNameLength;
        
        // Проверка согласованности констант
        if (MaxRoleNameLengthForRegex < maxLength)
        {
            _logger.LogWarning(
                "MaxRoleNameLengthForRegex ({MaxRegex}) меньше _maxRoleNameLength ({MaxLength}). " +
                "Это может привести к неправильной валидации длинных имен ролей.",
                MaxRoleNameLengthForRegex, maxLength);
        }
        
        if (maxLength < MinRoleNameLength)
        {
            _logger.LogWarning(
                "Максимальная длина имени роли ({MaxLength}) меньше минимальной ({MinLength}). " +
                "Используется минимальное значение.",
                maxLength, MinRoleNameLength);
            maxLength = MinRoleNameLength;
        }
        
        _maxRoleNameLength = maxLength;
    }

    /// <inheritdoc />
    /// <remarks>
    /// Валидные примеры: "admin", "user_role", "my.role", "role-123"
    /// Невалидные примеры: "role name" (пробелы), "role@admin" (спецсимволы), "" (пустая строка)
    /// Максимальная длина: 255 символов (настраивается через KeycloakAdminSettings.Roles.MaxRoleNameLength)
    /// </remarks>
    public bool IsValidRoleName(string? roleName)
    {
        try
        {
            // Проверка на null или пустую строку
            if (string.IsNullOrWhiteSpace(roleName))
                return false;
            
            // Убираем пробелы для проверки (после Trim может остаться пустая строка)
            var trimmedName = roleName.Trim();
            if (trimmedName.Length == 0)
                return false;
            
            // Проверка минимальной длины
            if (trimmedName.Length < MinRoleNameLength)
            {
                _logger.LogDebug("Имя роли отклонено: меньше минимальной длины. Длина: {Length}, Минимум: {MinLength}", 
                    trimmedName.Length, MinRoleNameLength);
                return false;
            }
            
            // Проверка максимальной длины
            if (trimmedName.Length > _maxRoleNameLength)
            {
                _logger.LogDebug("Имя роли отклонено: превышена максимальная длина. Длина: {Length}, Максимум: {MaxLength}", 
                    trimmedName.Length, _maxRoleNameLength);
                return false;
            }
            
            // Защита от ReDoS: не проверяем слишком длинные строки через Regex
            if (trimmedName.Length > MaxRoleNameLengthForRegex)
            {
                _logger.LogDebug("Имя роли отклонено: превышена длина для Regex проверки. Длина: {Length}, Максимум: {MaxRegexLength}", 
                    trimmedName.Length, MaxRoleNameLengthForRegex);
                return false;
            }
            
            // Проверка на зарезервированные имена ролей Keycloak
            if (ReservedRoleNames.Contains(trimmedName))
            {
                _logger.LogDebug("Имя роли отклонено: зарезервированное имя Keycloak. Роль: {RoleName}", trimmedName);
                return false;
            }
            
            // Проверка на имена, состоящие только из точек или дефисов
            if (IsOnlySpecialCharacters(trimmedName))
            {
                _logger.LogDebug("Имя роли отклонено: состоит только из специальных символов. Роль: {RoleName}", trimmedName);
                return false;
            }
            
            // Проверка через Regex с таймаутом
            return RoleNameRegex.IsMatch(trimmedName);
        }
        catch (RegexMatchTimeoutException ex)
        {
            // При таймауте Regex считаем невалидным
            _logger.LogWarning(ex, "Таймаут Regex при валидации имени роли: {RoleName}", roleName);
            return false;
        }
        catch (Exception ex)
        {
            // Логирование неожиданных исключений
            _logger.LogError(ex, "Неожиданная ошибка при валидации имени роли: {RoleName}", roleName);
            return false;
        }
    }
    
    /// <summary>
    /// Проверяет, состоит ли строка только из специальных символов (точек и дефисов)
    /// </summary>
    private static bool IsOnlySpecialCharacters(string value)
    {
        if (string.IsNullOrEmpty(value))
            return false;
        
        foreach (var ch in value)
        {
            if (char.IsLetterOrDigit(ch))
                return false;
        }
        
        return true;
    }

    /// <inheritdoc />
    /// <remarks>
    /// Валидные примеры: "https://example.com/callback", "http://localhost:3000/callback", "urn:ietf:wg:oauth:2.0:oob"
    /// Невалидные примеры: "*" (wildcard небезопасен), "javascript:alert(1)" (опасная схема), "" (пустая строка)
    /// Максимальная длина: 2048 символов
    /// </remarks>
    public bool IsValidRedirectUri(string? uri)
    {
        try
        {
            // Проверка на null или пустую строку
            if (string.IsNullOrWhiteSpace(uri))
                return false;
            
            var trimmedUri = uri.Trim();
            
            // Проверка минимальной длины
            if (trimmedUri.Length < MinRedirectUriLength)
            {
                _logger.LogDebug("Redirect URI отклонен: меньше минимальной длины. Длина: {Length}, Минимум: {MinLength}", 
                    trimmedUri.Length, MinRedirectUriLength);
                return false;
            }
            
            // Проверка максимальной длины
            if (trimmedUri.Length > MaxRedirectUriLength)
            {
                _logger.LogDebug("Redirect URI отклонен: превышена максимальная длина. Длина: {Length}, Максимум: {MaxLength}", 
                    trimmedUri.Length, MaxRedirectUriLength);
                return false;
            }
            
            // Проверка на недопустимые символы (контрольные символы)
            if (ContainsInvalidCharacters(trimmedUri))
            {
                _logger.LogDebug("Redirect URI отклонен: содержит недопустимые символы. URI: {Uri}", trimmedUri);
                return false;
            }
            
            // Блокируем опасные схемы (case-insensitive, без создания промежуточной строки)
            if (IsDangerousScheme(trimmedUri))
            {
                _logger.LogDebug("Redirect URI отклонен: опасная схема. URI: {Uri}", trimmedUri);
                return false;
            }
            
            // Разрешаем URN схемы (для OAuth 2.0)
            if (trimmedUri.StartsWith("urn:", StringComparison.OrdinalIgnoreCase))
                return true;
            
            // Wildcard удален - это небезопасно (Open Redirect уязвимость)
            // if (trimmedUri == "*")
            //     return true;
            
            // Проверяем, что URI является абсолютным
            if (!Uri.TryCreate(trimmedUri, UriKind.Absolute, out var uriResult))
            {
                _logger.LogDebug("Redirect URI отклонен: не является абсолютным URI. URI: {Uri}", trimmedUri);
                return false;
            }
            
            // Разрешаем только HTTP и HTTPS схемы
            if (uriResult.Scheme != Uri.UriSchemeHttp && uriResult.Scheme != Uri.UriSchemeHttps)
            {
                _logger.LogDebug("Redirect URI отклонен: недопустимая схема. Схема: {Scheme}, URI: {Uri}", 
                    uriResult.Scheme, trimmedUri);
                return false;
            }
            
            // Проверка на валидность порта
            if (!IsValidPort(uriResult))
            {
                _logger.LogDebug("Redirect URI отклонен: недопустимый порт. Порт: {Port}, URI: {Uri}", 
                    uriResult.Port, trimmedUri);
                return false;
            }
            
            // Проверка на использование IP адресов (может быть небезопасно)
            if (IsIpAddress(uriResult.Host))
            {
                _logger.LogDebug("Redirect URI отклонен: использование IP адреса. Host: {Host}, URI: {Uri}", 
                    uriResult.Host, trimmedUri);
                return false;
            }
            
            // Проверка на безопасность query параметров и фрагментов
            if (!IsSafeQueryAndFragment(uriResult))
            {
                _logger.LogDebug("Redirect URI отклонен: небезопасные query параметры или фрагменты. URI: {Uri}", trimmedUri);
                return false;
            }
            
            return true;
        }
        catch (Exception ex)
        {
            // Логирование неожиданных исключений
            _logger.LogError(ex, "Неожиданная ошибка при валидации Redirect URI: {Uri}", uri);
            return false;
        }
    }
    
    /// <summary>
    /// Проверяет, содержит ли строка недопустимые символы (контрольные символы)
    /// </summary>
    private static bool ContainsInvalidCharacters(string value)
    {
        foreach (var ch in value)
        {
            // Блокируем контрольные символы (кроме пробелов, табуляции и переноса строки, которые уже обработаны)
            if (char.IsControl(ch) && ch != '\t' && ch != '\n' && ch != '\r')
                return true;
        }
        return false;
    }
    
    /// <summary>
    /// Проверяет, является ли схема URI опасной
    /// </summary>
    private static bool IsDangerousScheme(string uri)
    {
        return uri.StartsWith("javascript:", StringComparison.OrdinalIgnoreCase) ||
               uri.StartsWith("data:", StringComparison.OrdinalIgnoreCase) ||
               uri.StartsWith("vbscript:", StringComparison.OrdinalIgnoreCase) ||
               uri.StartsWith("file:", StringComparison.OrdinalIgnoreCase);
    }
    
    /// <summary>
    /// Проверяет валидность порта в URI
    /// </summary>
    private static bool IsValidPort(Uri uri)
    {
        // Порт -1 означает, что используется порт по умолчанию для схемы
        if (uri.Port == -1)
            return true;
        
        // Валидные порты: 1-65535
        return uri.Port >= 1 && uri.Port <= 65535;
    }
    
    /// <summary>
    /// Проверяет, является ли host IP адресом
    /// </summary>
    private static bool IsIpAddress(string host)
    {
        if (string.IsNullOrWhiteSpace(host))
            return false;
        
        // Проверяем IPv4
        if (IPAddress.TryParse(host, out var ipAddress))
        {
            // Разрешаем localhost (127.0.0.1, ::1) для разработки
            if (IPAddress.IsLoopback(ipAddress))
                return false;
            
            return true;
        }
        
        return false;
    }
    
    /// <summary>
    /// Проверяет безопасность query параметров и фрагментов
    /// </summary>
    private static bool IsSafeQueryAndFragment(Uri uri)
    {
        // Проверяем query параметры на наличие потенциально опасных значений
        if (!string.IsNullOrEmpty(uri.Query))
        {
            var query = uri.Query;
            // Блокируем javascript: и data: в query параметрах
            if (query.Contains("javascript:", StringComparison.OrdinalIgnoreCase) ||
                query.Contains("data:", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }
        }
        
        // Проверяем фрагменты на наличие потенциально опасных значений
        if (!string.IsNullOrEmpty(uri.Fragment))
        {
            var fragment = uri.Fragment;
            // Блокируем javascript: и data: во фрагментах
            if (fragment.Contains("javascript:", StringComparison.OrdinalIgnoreCase) ||
                fragment.Contains("data:", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }
        }
        
        return true;
    }
}

