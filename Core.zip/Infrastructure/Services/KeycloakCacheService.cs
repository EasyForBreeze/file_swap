using System.Collections.Concurrent;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для кэширования статических данных из Keycloak
/// Потокобезопасен: IMemoryCache.GetOrCreateAsync обеспечивает thread-safety для операций кэширования
/// </summary>
public class KeycloakCacheService : IKeycloakCacheService
{
    private readonly IMemoryCache _cache;
    private readonly ILogger<KeycloakCacheService> _logger;
    private readonly KeycloakCacheSettings _settings;
    
    // Реестр активных ключей для полной очистки кэша
    private readonly ConcurrentDictionary<string, bool> _activeKeys = new();
    
    // Метрики кэша
    private readonly CacheMetrics _metrics = new();
    
    // Ключи для кэша (кэшируем для производительности)
    private const string RealmsListKey = "keycloak:realms:list";
    private const string EventTypesKeyPrefix = "keycloak:events:types:";
    private const string WellKnownKeyPrefix = "keycloak:wellknown:";
    
    // TTL для разных типов данных (из настроек)
    private readonly TimeSpan _realmsListTtl;
    private readonly TimeSpan _eventTypesTtl;
    private readonly TimeSpan _wellKnownTtl;
    
    // Константы для валидации
    private const int MaxKeyLength = 1000; // Максимальная длина ключа
    private const int MaxContextInfoLength = 500; // Максимальная длина contextInfo
    private const long MaxCounterValue = long.MaxValue - 1; // Максимальное значение счетчика перед переполнением
    
    public KeycloakCacheService(
        IMemoryCache cache,
        ILogger<KeycloakCacheService> logger,
        IOptions<KeycloakCacheSettings> settings)
    {
        _cache = cache ?? throw new ArgumentNullException(nameof(cache));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _settings = settings?.Value ?? throw new ArgumentNullException(nameof(settings));
        
        // Валидация настроек
        if (_settings.RealmsListTtlMinutes <= 0)
        {
            throw new ArgumentException("RealmsListTtlMinutes must be greater than 0", nameof(settings));
        }
        
        if (_settings.EventTypesTtlMinutes <= 0)
        {
            throw new ArgumentException("EventTypesTtlMinutes must be greater than 0", nameof(settings));
        }
        
        if (_settings.WellKnownEndpointsTtlMinutes <= 0)
        {
            throw new ArgumentException("WellKnownEndpointsTtlMinutes must be greater than 0", nameof(settings));
        }
        
        // Инициализируем TTL из настроек
        _realmsListTtl = TimeSpan.FromMinutes(_settings.RealmsListTtlMinutes);
        _eventTypesTtl = TimeSpan.FromMinutes(_settings.EventTypesTtlMinutes);
        _wellKnownTtl = TimeSpan.FromMinutes(_settings.WellKnownEndpointsTtlMinutes);
        
        _logger.LogInformation("KeycloakCacheService инициализирован: Enabled={Enabled}, RealmsListTtl={RealmsTtl}, EventTypesTtl={EventTtl}, WellKnownTtl={WellKnownTtl}", 
            _settings.Enabled, _realmsListTtl, _eventTypesTtl, _wellKnownTtl);
    }
    
    #region Realms List
    
    /// <summary>
    /// Получить список реалмов из кэша или выполнить функцию загрузки
    /// </summary>
    public async Task<List<string>> GetOrCreateRealmsListAsync(
        Func<Task<List<string>>> factory,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            return await GetOrCreateInternalAsync(
                RealmsListKey,
                factory,
                _realmsListTtl,
                CacheItemPriority.High,
                cancellationToken);
        }
        finally
        {
            stopwatch.Stop();
            if (_logger.IsEnabled(LogLevel.Trace))
            {
                _logger.LogTrace("Операция GetOrCreateRealmsListAsync заняла {ElapsedMs}ms", 
                    stopwatch.ElapsedMilliseconds);
            }
        }
    }
    
    /// <summary>
    /// Инвалидировать кэш списка реалмов
    /// </summary>
    public void InvalidateRealmsList()
    {
        InvalidateCacheKey(RealmsListKey);
    }
    
    #endregion
    
    #region Event Types
    
    /// <summary>
    /// Получить типы событий для реалма из кэша или выполнить функцию загрузки
    /// </summary>
    public async Task<List<string>> GetOrCreateEventTypesAsync(
        string realm,
        Func<Task<List<string>>> factory,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(realm);
        ArgumentNullException.ThrowIfNull(factory);
        
        if (string.IsNullOrWhiteSpace(realm))
        {
            throw new ArgumentException("Realm cannot be empty or whitespace.", nameof(realm));
        }
        
        ValidateKeyLength(realm, nameof(realm));
        
        var stopwatch = Stopwatch.StartNew();
        try
        {
            // Используем интерполяцию строк - компилятор оптимизирует это
            var key = $"{EventTypesKeyPrefix}{realm}";
            
            return await GetOrCreateInternalAsync(
                key,
                factory,
                _eventTypesTtl,
                CacheItemPriority.Normal,
                cancellationToken,
                realm);
        }
        finally
        {
            stopwatch.Stop();
            if (_logger.IsEnabled(LogLevel.Trace))
            {
                _logger.LogTrace("Операция GetOrCreateEventTypesAsync для реалма {Realm} заняла {ElapsedMs}ms", 
                    realm, stopwatch.ElapsedMilliseconds);
            }
        }
    }
    
    /// <summary>
    /// Инвалидировать кэш типов событий для реалма
    /// </summary>
    public void InvalidateEventTypes(string realm)
    {
        ArgumentNullException.ThrowIfNull(realm);
        
        if (string.IsNullOrWhiteSpace(realm))
        {
            throw new ArgumentException("Realm cannot be empty or whitespace.", nameof(realm));
        }
        
        ValidateKeyLength(realm, nameof(realm));
        
        var key = $"{EventTypesKeyPrefix}{realm}";
        InvalidateCacheKey(key);
    }
    
    #endregion
    
    #region Well-Known Endpoints
    
    /// <summary>
    /// Получить well-known endpoints для реалма из кэша или выполнить функцию загрузки
    /// </summary>
    public async Task<Dictionary<string, string>> GetOrCreateWellKnownEndpointsAsync(
        string realm,
        Func<Task<Dictionary<string, string>>> factory,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(realm);
        ArgumentNullException.ThrowIfNull(factory);
        
        if (string.IsNullOrWhiteSpace(realm))
        {
            throw new ArgumentException("Realm cannot be empty or whitespace.", nameof(realm));
        }
        
        ValidateKeyLength(realm, nameof(realm));
        
        var stopwatch = Stopwatch.StartNew();
        try
        {
            // Используем интерполяцию строк - компилятор оптимизирует это
            var key = $"{WellKnownKeyPrefix}{realm}";
            
            return await GetOrCreateInternalAsync(
                key,
                factory,
                _wellKnownTtl,
                CacheItemPriority.Normal,
                cancellationToken,
                realm);
        }
        finally
        {
            stopwatch.Stop();
            if (_logger.IsEnabled(LogLevel.Trace))
            {
                _logger.LogTrace("Операция GetOrCreateWellKnownEndpointsAsync для реалма {Realm} заняла {ElapsedMs}ms", 
                    realm, stopwatch.ElapsedMilliseconds);
            }
        }
    }
    
    /// <summary>
    /// Инвалидировать кэш well-known endpoints для реалма
    /// </summary>
    public void InvalidateWellKnownEndpoints(string realm)
    {
        ArgumentNullException.ThrowIfNull(realm);
        
        if (string.IsNullOrWhiteSpace(realm))
        {
            throw new ArgumentException("Realm cannot be empty or whitespace.", nameof(realm));
        }
        
        ValidateKeyLength(realm, nameof(realm));
        
        var key = $"{WellKnownKeyPrefix}{realm}";
        InvalidateCacheKey(key);
    }
    
    #endregion
    
    #region Generic методы кэширования
    
    /// <summary>
    /// Получить значение из кэша по ключу
    /// </summary>
    /// <typeparam name="T">Тип кэшируемого значения</typeparam>
    /// <param name="key">Ключ кэша</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Кэшированное значение или null, если не найдено или кэш отключен</returns>
    public Task<T?> GetAsync<T>(string key, CancellationToken cancellationToken = default) where T : class
    {
        ArgumentNullException.ThrowIfNull(key);
        
        if (string.IsNullOrWhiteSpace(key))
        {
            throw new ArgumentException("Key cannot be empty or whitespace.", nameof(key));
        }
        
        ValidateKeyLength(key, nameof(key));
        
        cancellationToken.ThrowIfCancellationRequested();
        
        if (!_settings.Enabled)
        {
            // Не записываем метрику, если кэш отключен - это не miss, а просто отключенный кэш
            return Task.FromResult<T?>(null);
        }
        
        try
        {
            if (_cache.TryGetValue(key, out var cachedValue) && cachedValue is T typedValue)
            {
                _metrics.RecordHit();
                if (_logger.IsEnabled(LogLevel.Debug))
                {
                    _logger.LogDebug("Значение найдено в кэше для ключа: {Key}", key);
                }
                return Task.FromResult<T?>(typedValue);
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при попытке получить значение из кэша для ключа: {Key}", key);
        }
        
        // Записываем miss только один раз
        _metrics.RecordMiss();
        return Task.FromResult<T?>(null);
    }
    
    /// <summary>
    /// Сохранить значение в кэш с указанным TTL
    /// </summary>
    /// <typeparam name="T">Тип кэшируемого значения</typeparam>
    /// <param name="key">Ключ кэша</param>
    /// <param name="value">Значение для кэширования</param>
    /// <param name="ttl">Время жизни кэша</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    public Task SetAsync<T>(string key, T value, TimeSpan ttl, CancellationToken cancellationToken = default) where T : class
    {
        ArgumentNullException.ThrowIfNull(key);
        ArgumentNullException.ThrowIfNull(value);
        
        if (string.IsNullOrWhiteSpace(key))
        {
            throw new ArgumentException("Key cannot be empty or whitespace.", nameof(key));
        }
        
        ValidateKeyLength(key, nameof(key));
        
        if (ttl <= TimeSpan.Zero)
        {
            throw new ArgumentException("TTL must be greater than zero.", nameof(ttl));
        }
        
        if (ttl == TimeSpan.MaxValue)
        {
            throw new ArgumentException("TTL cannot be TimeSpan.MaxValue.", nameof(ttl));
        }
        
        if (ttl > TimeSpan.FromDays(365))
        {
            throw new ArgumentException("TTL cannot exceed 365 days.", nameof(ttl));
        }
        
        cancellationToken.ThrowIfCancellationRequested();
        
        if (!_settings.Enabled)
        {
            return Task.CompletedTask;
        }
        
        try
        {
            _activeKeys.TryAdd(key, true);
            
            var options = new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = ttl,
                Priority = CacheItemPriority.Normal,
                Size = CalculateCacheSize(value)
            };
            
            try
            {
                // Кэшируем ключ как строку для callback
                var keyForCallback = key;
                options.RegisterPostEvictionCallback((k, v, reason, state) =>
                {
                    try
                    {
                        var callbackKey = k?.ToString() ?? keyForCallback;
                        if (!string.IsNullOrEmpty(callbackKey))
                        {
                            _activeKeys.TryRemove(callbackKey, out _);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Логируем, но не пробрасываем исключение из callback
                        if (_logger.IsEnabled(LogLevel.Warning))
                        {
                            _logger.LogWarning(ex, "Ошибка в post-eviction callback для ключа");
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Ошибка при регистрации post-eviction callback для ключа: {Key}", key);
            }
            
            _cache.Set(key, value, options);
            _metrics.RecordSet();
            
            if (_logger.IsEnabled(LogLevel.Debug))
            {
                _logger.LogDebug("Значение сохранено в кэш для ключа: {Key}, TTL: {Ttl}", key, ttl);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при сохранении значения в кэш для ключа: {Key}", key);
            throw;
        }
        
        return Task.CompletedTask;
    }
    
    /// <summary>
    /// Удалить значение из кэша по ключу
    /// </summary>
    /// <param name="key">Ключ кэша</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    public Task RemoveAsync(string key, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(key);
        
        if (string.IsNullOrWhiteSpace(key))
        {
            throw new ArgumentException("Key cannot be empty or whitespace.", nameof(key));
        }
        
        ValidateKeyLength(key, nameof(key));
        
        cancellationToken.ThrowIfCancellationRequested();
        
        if (!_settings.Enabled)
        {
            return Task.CompletedTask;
        }
        
        try
        {
            _cache.Remove(key);
            try
            {
                _activeKeys.TryRemove(key, out _);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Ошибка при удалении ключа из реестра: {Key}", key);
            }
            
            _metrics.RecordRemove();
            
            if (_logger.IsEnabled(LogLevel.Debug))
            {
                _logger.LogDebug("Значение удалено из кэша для ключа: {Key}", key);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при удалении значения из кэша для ключа: {Key}", key);
            throw;
        }
        
        return Task.CompletedTask;
    }
    
    /// <summary>
    /// Получить или создать значение в кэше (GetOrCreate pattern)
    /// Потокобезопасен: IMemoryCache.GetOrCreateAsync обеспечивает синхронизацию доступа
    /// </summary>
    /// <typeparam name="T">Тип кэшируемого значения</typeparam>
    /// <param name="key">Ключ кэша</param>
    /// <param name="factory">Фабрика для создания значения, если его нет в кэше</param>
    /// <param name="ttl">Время жизни кэша</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Кэшированное или созданное значение</returns>
    public async Task<T> GetOrCreateAsync<T>(
        string key,
        Func<Task<T>> factory,
        TimeSpan ttl,
        CancellationToken cancellationToken = default) where T : class
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            return await GetOrCreateInternalAsync(
                key,
                factory,
                ttl,
                CacheItemPriority.Normal,
                cancellationToken);
        }
        finally
        {
            stopwatch.Stop();
            if (_logger.IsEnabled(LogLevel.Trace))
            {
                _logger.LogTrace("Операция GetOrCreateAsync для ключа {Key} заняла {ElapsedMs}ms", 
                    key, stopwatch.ElapsedMilliseconds);
            }
        }
    }
    
    #endregion
    
    #region Общие методы
    
    /// <summary>
    /// Очистить весь кэш Keycloak
    /// </summary>
    public void ClearAll()
    {
        _logger.LogInformation("Полная очистка кэша Keycloak");
        
        var removedCount = 0;
        
        try
        {
            // Используем более эффективную итерацию без ToList
            // Итерируемся напрямую по ключам для лучшей производительности
            var keys = _activeKeys.Keys;
            foreach (var key in keys)
            {
                try
                {
                    _cache.Remove(key);
                    if (_activeKeys.TryRemove(key, out _))
                    {
                        removedCount++;
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Ошибка при удалении ключа из кэша: {Key}", key);
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при итерации по ключам кэша");
        }
        
        // Используем Compact если доступен (для MemoryCache)
        // Это удалит все элементы, включая те, которые не были в реестре
        if (_cache is MemoryCache memoryCache)
        {
            try
            {
                memoryCache.Compact(1.0); // Удаляет все элементы
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Ошибка при вызове Compact для MemoryCache");
            }
        }
        
        // Очищаем реестр на случай, если остались ключи
        try
        {
            _activeKeys.Clear();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при очистке реестра активных ключей");
        }
        
        // Защита от бесконечного роста: если реестр все еще большой, принудительно очищаем
        if (_activeKeys.Count > 10000)
        {
            _logger.LogWarning("Обнаружен большой размер реестра ключей ({Count}), выполняем принудительную очистку", _activeKeys.Count);
            try
            {
                // Очищаем все оставшиеся ключи
                var keysToRemove = new List<string>(_activeKeys.Keys);
                foreach (var key in keysToRemove)
                {
                    _activeKeys.TryRemove(key, out _);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при принудительной очистке реестра");
            }
        }
        
        _logger.LogInformation("Кэш Keycloak очищен. Удалено записей: {Count}", removedCount);
    }
    
    /// <summary>
    /// Получить статистику кэша
    /// </summary>
    public CacheStatistics GetStatistics()
    {
        // Используем snapshot для thread-safe чтения
        var totalEntries = _activeKeys.Count;
        var stats = _metrics.GetStatistics(totalEntries);
        
        // Оптимизированная оценка памяти кэша с ограничением итерации
        long estimatedCacheMemory = 0;
        var keysProcessed = 0;
        const int maxKeysToProcess = 10000; // Ограничиваем количество обрабатываемых ключей для производительности
        
        try
        {
            foreach (var key in _activeKeys.Keys)
            {
                if (keysProcessed >= maxKeysToProcess)
                {
                    // Для больших кэшей используем приблизительную оценку
                    estimatedCacheMemory = (long)(estimatedCacheMemory * ((double)totalEntries / keysProcessed));
                    break;
                }
                
                try
                {
                    if (_cache.TryGetValue(key, out var value))
                    {
                        var size = EstimateValueSize(value);
                        if (size > 0)
                        {
                            estimatedCacheMemory += size;
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogTrace(ex, "Ошибка при оценке размера значения для ключа: {Key}", key);
                }
                
                keysProcessed++;
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при вычислении статистики памяти кэша");
        }
        
        return new CacheStatistics
        {
            TotalEntries = totalEntries,
            TotalMemoryBytes = estimatedCacheMemory,
            TotalHits = stats.TotalHits,
            TotalMisses = stats.TotalMisses,
            TotalSets = stats.TotalSets,
            TotalRemoves = stats.TotalRemoves,
            HitRate = stats.HitRate,
            Message = _settings.Enabled 
                ? $"Кэш активен. Записей: {totalEntries}, Hit rate: {stats.HitRate:F2}%" 
                : "Кэш отключен"
        };
    }
    
    /// <summary>
    /// Оценить размер значения для статистики памяти
    /// </summary>
    private long EstimateValueSize(object? value)
    {
        if (value == null) return 0;
        
        try
        {
            // Приблизительная оценка размера объекта
            if (value is string str)
            {
                var size = str.Length * 2L; // UTF-16
                return Math.Max(0, size); // Защита от отрицательных значений
            }
            
            if (value is List<string> list)
            {
                long size = 0;
                var count = list.Count;
                // Используем for для лучшей производительности на больших коллекциях
                for (int i = 0; i < count; i++)
                {
                    var s = list[i];
                    size += (s?.Length * 2L ?? 0L);
                }
                size += count * 8L; // + указатели
                return Math.Max(0, size);
            }
            
            if (value is Dictionary<string, string> dict)
            {
                long size = 0;
                foreach (var kvp in dict)
                {
                    size += (kvp.Key?.Length * 2L ?? 0L);
                    size += (kvp.Value?.Length * 2L ?? 0L);
                    size += 16L; // + overhead для пары ключ-значение
                }
                return Math.Max(0, size);
            }
            
            if (value is IEnumerable<string> enumerable)
            {
                // Однопроходное вычисление размера
                long size = 0;
                int count = 0;
                foreach (var s in enumerable)
                {
                    size += (s?.Length * 2L ?? 0L);
                    count++;
                }
                size += count * 8L; // + указатели
                return Math.Max(0, size);
            }
            
            // Для других типов используем приблизительную оценку
            return 100; // Базовый размер объекта
        }
        catch (Exception ex)
        {
            _logger.LogTrace(ex, "Ошибка при оценке размера значения");
            return 100; // Возвращаем безопасное значение по умолчанию
        }
    }
    
    #endregion
    
    #region Вспомогательные методы
    
    /// <summary>
    /// Внутренний метод для получения или создания значения в кэше
    /// Устраняет дублирование кода между различными GetOrCreate методами
    /// Потокобезопасен: использует IMemoryCache.GetOrCreateAsync, который обеспечивает синхронизацию
    /// </summary>
    private async Task<T> GetOrCreateInternalAsync<T>(
        string key,
        Func<Task<T>> factory,
        TimeSpan ttl,
        CacheItemPriority priority = CacheItemPriority.Normal,
        CancellationToken cancellationToken = default,
        string? contextInfo = null) where T : class
    {
        ArgumentNullException.ThrowIfNull(key);
        ArgumentNullException.ThrowIfNull(factory);
        
        if (string.IsNullOrWhiteSpace(key))
        {
            throw new ArgumentException("Key cannot be empty or whitespace.", nameof(key));
        }
        
        ValidateKeyLength(key, nameof(key));
        
        // Валидация contextInfo
        if (contextInfo != null)
        {
            ValidateContextInfo(contextInfo);
        }
        
        cancellationToken.ThrowIfCancellationRequested();
        
        if (!_settings.Enabled)
        {
            return await factory();
        }
        
        try
        {
            // Кэшируем ключ для callback
            var keyForCallback = key;
            
            // IMemoryCache.GetOrCreateAsync потокобезопасен и предотвращает множественные вызовы factory
            // для одного и того же ключа при конкурентном доступе
            var result = await _cache.GetOrCreateAsync(
                key,
                async entry =>
                {
                    entry.AbsoluteExpirationRelativeToNow = ttl;
                    entry.SetPriority(priority);
                    
                    try
                    {
                        _activeKeys.TryAdd(key, true);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Ошибка при добавлении ключа в реестр: {Key}", key);
                    }
                    
                    try
                    {
                        entry.RegisterPostEvictionCallback((k, v, reason, state) =>
                        {
                            try
                            {
                                var callbackKey = k?.ToString() ?? keyForCallback;
                                if (!string.IsNullOrEmpty(callbackKey))
                                {
                                    _activeKeys.TryRemove(callbackKey, out _);
                                }
                            }
                            catch (Exception ex)
                            {
                                // Логируем, но не пробрасываем исключение из callback
                                if (_logger.IsEnabled(LogLevel.Warning))
                                {
                                    _logger.LogWarning(ex, "Ошибка в post-eviction callback для ключа");
                                }
                            }
                        });
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Ошибка при регистрации post-eviction callback для ключа: {Key}", key);
                    }
                    
                    try
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                        var factoryResult = await factory();
                        
                        // Проверка на null для reference types
                        if (factoryResult == null)
                        {
                            throw new InvalidOperationException($"Factory returned null for key: {key}");
                        }
                        
                        var cacheSize = CalculateCacheSize(factoryResult);
                        if (cacheSize > 0)
                        {
                            entry.Size = cacheSize;
                        }
                        
                        if (contextInfo != null)
                        {
                            _logger.LogDebug("Данные для {Context} успешно загружены и кэшированы", contextInfo);
                        }
                        else
                        {
                            _logger.LogDebug("Данные для ключа {Key} успешно загружены и кэшированы", key);
                        }
                        
                        _metrics.RecordSet();
                        return factoryResult;
                    }
                    catch (OperationCanceledException)
                    {
                        // Отмена операции - не ошибка, а нормальная ситуация
                        if (contextInfo != null)
                        {
                            _logger.LogInformation("Операция кэширования отменена для {Context}", contextInfo);
                        }
                        else
                        {
                            _logger.LogInformation("Операция кэширования отменена для ключа: {Key}", key);
                        }
                        _metrics.RecordMiss();
                        throw; // Пробрасываем дальше
                    }
                    catch (Exception ex)
                    {
                        if (contextInfo != null)
                        {
                            _logger.LogError(ex, "Ошибка при загрузке данных для {Context} для кэширования", contextInfo);
                        }
                        else
                        {
                            _logger.LogError(ex, "Ошибка при загрузке данных для кэширования. Ключ: {Key}", key);
                        }
                        _metrics.RecordMiss();
                        throw; // Пробрасываем исключение, чтобы не кэшировать ошибку
                    }
                });
            
            // GetOrCreateAsync не должен возвращать null для reference types,
            // но на всякий случай проверяем
            if (result == null)
            {
                throw new InvalidOperationException($"Failed to create cache entry for key: {key}. GetOrCreateAsync returned null.");
            }
            
            return result;
        }
        catch (OperationCanceledException)
        {
            // Отмена операции - пробрасываем дальше без fallback
            throw;
        }
        catch (Exception ex)
        {
            if (contextInfo != null)
            {
                _logger.LogError(ex, "Ошибка при получении данных для {Context} из кэша", contextInfo);
            }
            else
            {
                _logger.LogError(ex, "Ошибка при получении данных из кэша. Ключ: {Key}", key);
            }
            
            // Fallback: пытаемся получить данные напрямую
            try
            {
                cancellationToken.ThrowIfCancellationRequested();
                return await factory();
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch
            {
                if (contextInfo != null)
                {
                    _logger.LogError("Не удалось получить данные для {Context} даже без кэша", contextInfo);
                }
                else
                {
                    _logger.LogError("Не удалось получить данные для ключа {Key} даже без кэша", key);
                }
                throw;
            }
        }
    }
    
    /// <summary>
    /// Вычислить размер кэшируемого значения для управления памятью
    /// </summary>
    private int CalculateCacheSize<T>(T value)
    {
        try
        {
            if (value == null) return 1;
            
            // Простая оценка размера для основных типов
            if (value is List<string> list)
            {
                // Используем long для предотвращения переполнения
                long size = 0;
                var count = list.Count;
                // Используем for для лучшей производительности
                for (int i = 0; i < count; i++)
                {
                    var s = list[i];
                    size += (s?.Length * 2L ?? 0L);
                }
                size += count * 8L; // UTF-16 + указатели
                var result = (int)Math.Min(size / 1024, int.MaxValue); // Конвертируем в KB с защитой от переполнения
                return Math.Max(1, result); // Минимум 1 KB
            }
            
            if (value is Dictionary<string, string> dict)
            {
                // Используем long для предотвращения переполнения
                long size = 0;
                foreach (var kvp in dict)
                {
                    size += (kvp.Key?.Length * 2L ?? 0L);
                    size += (kvp.Value?.Length * 2L ?? 0L);
                    size += 16L; // + overhead для пары ключ-значение
                }
                var result = (int)Math.Min(size / 1024, int.MaxValue); // Конвертируем в KB с защитой от переполнения
                return Math.Max(1, result); // Минимум 1 KB
            }
            
            if (value is IEnumerable<string> enumerable)
            {
                // Однопроходное вычисление размера для избежания двойного перечисления
                long size = 0;
                int count = 0;
                foreach (var s in enumerable)
                {
                    size += (s?.Length * 2L ?? 0L);
                    count++;
                }
                size += count * 8L; // + указатели
                var result = (int)Math.Min(size / 1024, int.MaxValue); // Конвертируем в KB с защитой от переполнения
                return Math.Max(1, result); // Минимум 1 KB
            }
            
            if (value is string str)
            {
                var size = str.Length * 2L; // UTF-16
                var result = (int)Math.Min(size / 1024, int.MaxValue); // Конвертируем в KB с защитой от переполнения
                return Math.Max(1, result); // Минимум 1 KB
            }
            
            // Для других типов используем минимальный размер
            return 1;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при вычислении размера кэша. Используется значение по умолчанию.");
            return 1; // Возвращаем безопасное значение по умолчанию
        }
    }
    
    /// <summary>
    /// Валидация длины ключа
    /// </summary>
    private void ValidateKeyLength(string key, string paramName)
    {
        if (key.Length > MaxKeyLength)
        {
            throw new ArgumentException($"Key length cannot exceed {MaxKeyLength} characters.", paramName);
        }
    }
    
    /// <summary>
    /// Валидация contextInfo
    /// </summary>
    private void ValidateContextInfo(string contextInfo)
    {
        if (contextInfo.Length > MaxContextInfoLength)
        {
            _logger.LogWarning("ContextInfo слишком длинный ({Length} символов), будет обрезан", contextInfo.Length);
        }
        
        // Проверка на небезопасные символы для логирования
        if (contextInfo.IndexOfAny(new[] { '\r', '\n', '\0' }) >= 0)
        {
            _logger.LogWarning("ContextInfo содержит небезопасные символы");
        }
    }
    
    /// <summary>
    /// Общий метод для инвалидации ключа кэша (устраняет дублирование кода)
    /// </summary>
    private void InvalidateCacheKey(string key)
    {
        try
        {
            _cache.Remove(key);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при удалении ключа из кэша: {Key}", key);
        }
        
        try
        {
            _activeKeys.TryRemove(key, out _);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка при удалении ключа из реестра: {Key}", key);
        }
    }
    
    #endregion
}


/// <summary>
/// Метрики производительности кэша
/// Thread-safe счетчики с защитой от переполнения
/// </summary>
internal class CacheMetrics
{
    private long _hits;
    private long _misses;
    private long _sets;
    private long _removes;
    
    /// <summary>
    /// Записать попадание в кэш с защитой от переполнения
    /// </summary>
    public void RecordHit()
    {
        var newValue = Interlocked.Increment(ref _hits);
        if (newValue >= MaxCounterValue)
        {
            // Сбрасываем счетчик при приближении к переполнению
            Interlocked.Exchange(ref _hits, 0);
        }
    }
    
    /// <summary>
    /// Записать промах кэша с защитой от переполнения
    /// </summary>
    public void RecordMiss()
    {
        var newValue = Interlocked.Increment(ref _misses);
        if (newValue >= MaxCounterValue)
        {
            // Сбрасываем счетчик при приближении к переполнению
            Interlocked.Exchange(ref _misses, 0);
        }
    }
    
    /// <summary>
    /// Записать установку значения в кэш с защитой от переполнения
    /// </summary>
    public void RecordSet()
    {
        var newValue = Interlocked.Increment(ref _sets);
        if (newValue >= MaxCounterValue)
        {
            // Сбрасываем счетчик при приближении к переполнению
            Interlocked.Exchange(ref _sets, 0);
        }
    }
    
    /// <summary>
    /// Записать удаление из кэша с защитой от переполнения
    /// </summary>
    public void RecordRemove()
    {
        var newValue = Interlocked.Increment(ref _removes);
        if (newValue >= MaxCounterValue)
        {
            // Сбрасываем счетчик при приближении к переполнению
            Interlocked.Exchange(ref _removes, 0);
        }
    }
    
    /// <summary>
    /// Получить статистику метрик (thread-safe чтение)
    /// </summary>
    public (long TotalHits, long TotalMisses, long TotalSets, long TotalRemoves, double HitRate) GetStatistics(int totalEntries)
    {
        // Используем Volatile.Read для thread-safe чтения
        var hits = Volatile.Read(ref _hits);
        var misses = Volatile.Read(ref _misses);
        var sets = Volatile.Read(ref _sets);
        var removes = Volatile.Read(ref _removes);
        
        var total = hits + misses;
        var hitRate = total > 0 ? (double)hits / total * 100 : 0;
        
        return (hits, misses, sets, removes, hitRate);
    }
    
    // Константа для защиты от переполнения
    private const long MaxCounterValue = long.MaxValue - 1;
}

