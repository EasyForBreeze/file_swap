using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Net.Mail;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
using new_assistant.Core.Interfaces;

namespace new_assistant.Infrastructure.Services;

/// <summary>
/// Сервис для отправки email уведомлений
/// </summary>
/// <remarks>
/// Примечание о метриках и мониторинге:
/// Для улучшения мониторинга можно добавить сбор метрик отправки писем:
/// - Счетчики успешных/неуспешных отправок по типам
/// - Время выполнения операций
/// - Размеры сообщений
/// Это можно реализовать через IMetricsCollector или аналогичный интерфейс.
/// </remarks>
public class EmailService : IEmailService, IDisposable
{
    private readonly IConfiguration _configuration;
    private readonly ILogger<EmailService>? _logger;

    // Rate limiting: ограничение одновременных отправок для защиты от спама
    private readonly SemaphoreSlim _sendSemaphore;
    private bool _disposed;

    // Константы для таймаутов
    private static readonly TimeSpan DefaultSmtpTimeout = TimeSpan.FromSeconds(30);
    private static readonly TimeSpan TestSmtpTimeout = TimeSpan.FromSeconds(10);
    private const int MaxRetries = 3;

    // Константы для валидации
    private const int MaxUsernameLength = 255;
    private const int MaxEmailLength = 320; // RFC 5321
    private const int MaxClientIdLength = 255;
    private const int MaxRealmLength = 255;
    private const int MaxSubjectLength = 200; // RFC 5322 recommends max 78 chars, but we use 200 for flexibility
    private const int MaxMessageSize = 10 * 1024 * 1024; // 10 MB - typical SMTP server limit
    private const int MaxUrlLength = 2048; // RFC 7230 рекомендует максимум 8000, но 2048 безопаснее
    private const int MaxPasswordLength = 1000; // Разумный предел для паролей
    private const int MaxTicketNumberLength = 100;

    // Rate limiting: максимальное количество одновременных отправок
    private const int MaxConcurrentSends = 5;

    // Retry delay: базовая задержка для exponential backoff
    private static readonly TimeSpan BaseRetryDelay = TimeSpan.FromSeconds(1);

    public EmailService(IConfiguration configuration, ILogger<EmailService>? logger = null)
    {
        _configuration = configuration;
        _logger = logger;
        _sendSemaphore = new SemaphoreSlim(MaxConcurrentSends, MaxConcurrentSends);
    }

    /// <summary>
    /// Освобождает ресурсы, используемые сервисом
    /// </summary>
    public void Dispose()
    {
        if (_disposed)
            return;

        _sendSemaphore?.Dispose();
        _disposed = true;
    }

    /// <summary>
    /// Отправляет заявку на получение доступа
    /// </summary>
    /// <param name="username">Имя пользователя, запрашивающего доступ</param>
    /// <param name="adminEmail">Email адрес администратора для отправки заявки</param>
    /// <returns>True если письмо успешно отправлено, иначе False</returns>
    public async Task<bool> SendAccessRequestAsync(string username, string adminEmail)
    {
        // Валидация входных параметров
        if (string.IsNullOrWhiteSpace(username))
        {
            _logger?.LogWarning("Username is null or empty");
            return false;
        }

        if (string.IsNullOrWhiteSpace(adminEmail))
        {
            _logger?.LogWarning("Admin email is null or empty");
            return false;
        }

        if (!IsValidEmail(adminEmail))
        {
            _logger?.LogWarning("Invalid admin email format: {Email}", adminEmail);
            return false;
        }

        if (username.Length > MaxUsernameLength)
        {
            _logger?.LogWarning("Username too long: {Length} characters", username.Length);
            return false;
        }

        // Структурированное логирование с корреляционным ID
        var correlationId = Guid.NewGuid();
        using var scope = _logger?.BeginScope(new Dictionary<string, object>
        {
            ["EmailRecipient"] = adminEmail,
            ["Username"] = username,
            ["CorrelationId"] = correlationId.ToString(),
            ["EmailType"] = "access_request"
        });

        // Rate limiting: ограничение одновременных отправок
        await _sendSemaphore.WaitAsync().ConfigureAwait(false);
        try
        {
            var smtpSettings = GetSmtpSettings();
            
            if (smtpSettings == null)
            {
                _logger?.LogWarning("SMTP настройки не сконфигурированы");
                return false;
            }

            _logger?.LogInformation("Подключение к SMTP серверу: {Host}:{Port}, SSL: {EnableSsl}", 
                smtpSettings.Host, smtpSettings.Port, smtpSettings.EnableSsl);

            // Экранирование пользовательских данных для безопасности
            var encodedUsername = WebUtility.HtmlEncode(username);
            var dateTime = DateTime.UtcNow.ToString("dd.MM.yyyy HH:mm:ss", CultureInfo.InvariantCulture);

            var message = new MimeMessage();
            message.From.Add(CreateMailboxAddress("KeyCloak Assistant", smtpSettings.FromEmail));
            message.To.Add(CreateMailboxAddress("", adminEmail));
            
            var subject = $"Заявка на доступ к Assistant от {encodedUsername}";
            if (subject.Length > MaxSubjectLength)
            {
                _logger?.LogWarning("Subject too long: {Length} characters, truncating to {MaxLength}", 
                    subject.Length, MaxSubjectLength);
                subject = subject.Substring(0, MaxSubjectLength - 3) + "...";
            }
            message.Subject = subject;

            // HTML шаблон для письма
            // Примечание: HTML шаблоны встроены в код для простоты.
            // Для улучшения конфигурируемости можно вынести шаблоны в отдельные файлы
            // или использовать шаблонизатор (например, Razor Engine).
            // Все пользовательские данные экранируются через WebUtility.HtmlEncode
            // для защиты от XSS атак. Валидация HTML структуры не выполняется,
            // так как шаблоны статичны и контролируются разработчиками.
            var bodyBuilder = new BodyBuilder
            {
                HtmlBody = $@"
<!DOCTYPE html>
<html lang=""ru"">
<head>
  <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8"" />
  <meta name=""viewport"" content=""width=device-width, initial-scale=1"" />
  <meta http-equiv=""X-UA-Compatible"" content=""IE=edge"" />
  <title>Заявка на доступ - KeyCloak Assistant</title>
</head>
<body style=""margin:0; padding:0; background-color:#E1E2E3;"">
  <center style=""width:100%; background-color:#E1E2E3;"">
    <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" width=""100%"">
      <tr>
        <td align=""center"" style=""padding:20px;"">
          <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" width=""600"" style=""width:600px; max-width:600px; background:#ffffff; border:1px solid #e9ecef;"">
            <tr>
              <td align=""center"" bgcolor=""#6c757d"" style=""padding:24px 20px; color:#ffffff; font-family:Arial, sans-serif;"">
                <div style=""font-size:20px; font-weight:bold; line-height:1.2;"">🔐 Новая заявка на доступ</div>
              </td>
            </tr>
            <tr>
              <td style=""padding:24px 20px; font-family:Arial, sans-serif;"">
                <table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"">
                  <tr>
                    <td align=""center"" style=""background:#28a745; color:#ffffff; padding:12px 14px; font-weight:bold;"">✅ Получена новая заявка на предоставление доступа к KeyCloak Assistant</td>
                  </tr>
                </table>

                <table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""margin-top:20px; border:1px solid #e9ecef;"">
                  <tr>
                    <td colspan=""2"" style=""padding:14px 16px; font-weight:bold; color:#495057; background:#f8f9fa; border-bottom:1px solid #e9ecef;"">📋 Информация о пользователе</td>
                  </tr>
                  <tr>
                    <td width=""35%"" style=""padding:12px 16px; color:#6c757d; font-size:12px; border-bottom:1px solid #e9ecef;"">Username</td>
                    <td style=""padding:12px 16px; color:#212529; font-weight:bold; border-bottom:1px solid #e9ecef;"">{encodedUsername}</td>
                  </tr>
                  <tr>
                    <td width=""35%"" style=""padding:12px 16px; color:#6c757d; font-size:12px;"">Дата запроса</td>
                    <td style=""padding:12px 16px; color:#212529; font-weight:bold;"">{dateTime}</td>
                  </tr>
                </table>

                <table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""margin-top:20px; border:1px solid #e9ecef;"">
                  <tr>
                    <td style=""padding:14px 16px; font-weight:bold; color:#495057; background:#f8f9fa; border-bottom:1px solid #e9ecef;"">👥 Доступные роли для назначения</td>
                  </tr>
                  <tr>
                    <td style=""padding:10px 16px; color:#6c757d;""><span style=""font-weight:bold; color:#212529;"">assistant-admin</span> — для полного доступа администратора</td>
                  </tr>
                  <tr>
                    <td style=""padding:10px 16px; color:#6c757d;""><span style=""font-weight:bold; color:#212529;"">assistant-user</span> — для базового доступа пользователя (Мои клиенты)</td>
                  </tr>
                  <tr>
                    <td style=""padding:10px 16px; color:#6c757d;""><span style=""font-weight:bold; color:#212529;"">assistant-operator</span> — для доступа к управлению пользователями</td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td align=""center"" bgcolor=""#f8f9fa"" style=""padding:16px 12px; color:#6c757d; font-size:12px; border-top:1px solid #e9ecef; font-family:Arial, sans-serif;"">KeyCloak Assistant<br/>Автоматическое сообщение системы • Не отвечайте на это письмо</td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </center>
</body>
</html>"
            };

            // Проверка размера сообщения
            var messageSize = Encoding.UTF8.GetByteCount(bodyBuilder.HtmlBody);
            if (messageSize > MaxMessageSize)
            {
                _logger?.LogWarning("Message size {Size} bytes exceeds maximum {MaxSize} bytes for access request from {Username}", 
                    messageSize, MaxMessageSize, username);
                return false;
            }

            message.Body = bodyBuilder.ToMessageBody();

            // Использование retry механизма с таймаутом
            var success = await SendWithRetryAsync(async cancellationToken =>
            {
                await SendEmailAsync(message, cancellationToken).ConfigureAwait(false);
            }, CancellationToken.None).ConfigureAwait(false);

            if (success)
            {
                _logger?.LogInformation("Заявка на доступ успешно отправлена на {Email} от пользователя {Username}", adminEmail, username);
            }

            return success;
        }
        catch (SmtpCommandException ex)
        {
            _logger?.LogError(ex, "SMTP command error sending access request from {Username}: {StatusCode}", 
                username, ex.StatusCode);
            return false;
        }
        catch (SmtpProtocolException ex)
        {
            _logger?.LogError(ex, "SMTP protocol error sending access request from {Username}: {Message}", 
                username, ex.Message);
            return false;
        }
        catch (MailKit.Security.AuthenticationException ex)
        {
            _logger?.LogError(ex, "SMTP authentication failed sending access request from {Username}: {Message}", 
                username, ex.Message);
            return false;
        }
        catch (SocketException ex)
        {
            _logger?.LogError(ex, "Network error connecting to SMTP server for access request from {Username}: {Message}", 
                username, ex.Message);
            return false;
        }
        catch (TimeoutException ex)
        {
            _logger?.LogError(ex, "SMTP operation timed out for access request from {Username}: {Message}", 
                username, ex.Message);
            return false;
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Не удалось отправить заявку на доступ от {Username}", username);
            return false;
        }
        finally
        {
            _sendSemaphore.Release();
        }
    }

    /// <summary>
    /// Отправляет учетные данные клиента (пароль от архива) на указанный email
    /// </summary>
    /// <param name="recipientEmail">Email адрес получателя</param>
    /// <param name="clientId">Идентификатор клиента</param>
    /// <param name="realm">Realm клиента</param>
    /// <param name="archivePassword">Пароль от архива с учетными данными</param>
    /// <param name="ticketNumber">Номер тикета (опционально)</param>
    /// <param name="ticketUrl">URL тикета (опционально)</param>
    /// <param name="wikiPageUrl">URL Wiki страницы (опционально)</param>
    /// <param name="environment">Окружение (TEST/PROD, по умолчанию TEST)</param>
    /// <param name="baseUrl">Base URL для подключения (опционально)</param>
    /// <param name="endpointsUrl">URL endpoints (опционально)</param>
    /// <param name="creatioUrl">URL Creatio (опционально)</param>
    /// <returns>True если письмо успешно отправлено, иначе False</returns>
    public async Task<bool> SendClientCredentialsEmailAsync(
        string recipientEmail, 
        string clientId, 
        string realm, 
        string archivePassword,
        string? ticketNumber = null,
        string? ticketUrl = null,
        string? wikiPageUrl = null,
        string environment = "TEST",
        string? baseUrl = null,
        string? endpointsUrl = null,
        string? creatioUrl = null)
    {
        // Валидация входных параметров
        if (string.IsNullOrWhiteSpace(recipientEmail))
        {
            _logger?.LogWarning("Recipient email is null or empty");
            return false;
        }

        if (!IsValidEmail(recipientEmail))
        {
            _logger?.LogWarning("Invalid recipient email format: {Email}", recipientEmail);
            return false;
        }

        if (string.IsNullOrWhiteSpace(clientId))
        {
            _logger?.LogWarning("Client ID is null or empty");
            return false;
        }

        if (string.IsNullOrWhiteSpace(realm))
        {
            _logger?.LogWarning("Realm is null or empty");
            return false;
        }

        if (string.IsNullOrWhiteSpace(archivePassword))
        {
            _logger?.LogWarning("Archive password is null or empty");
            return false;
        }

        if (archivePassword.Length > MaxPasswordLength)
        {
            _logger?.LogWarning("Archive password too long: {Length} characters", archivePassword.Length);
            return false;
        }

        if (clientId.Length > MaxClientIdLength)
        {
            _logger?.LogWarning("Client ID too long: {Length} characters", clientId.Length);
            return false;
        }

        if (realm.Length > MaxRealmLength)
        {
            _logger?.LogWarning("Realm too long: {Length} characters", realm.Length);
            return false;
        }

        // Валидация опциональных параметров
        if (ticketNumber != null && ticketNumber.Length > MaxTicketNumberLength)
        {
            _logger?.LogWarning("Ticket number too long: {Length} characters, truncating", ticketNumber.Length);
            ticketNumber = ticketNumber.Substring(0, MaxTicketNumberLength);
        }

        // Валидация URL параметров
        if (ticketUrl != null && !IsValidUrl(ticketUrl))
        {
            _logger?.LogWarning("Invalid ticket URL format: {Url}", ticketUrl);
            ticketUrl = null; // Игнорируем некорректный URL
        }

        if (ticketUrl != null && ticketUrl.Length > MaxUrlLength)
        {
            _logger?.LogWarning("Ticket URL too long: {Length} characters", ticketUrl.Length);
            ticketUrl = null;
        }

        if (wikiPageUrl != null && !IsValidUrl(wikiPageUrl))
        {
            _logger?.LogWarning("Invalid wiki page URL format: {Url}", wikiPageUrl);
            wikiPageUrl = null;
        }

        if (wikiPageUrl != null && wikiPageUrl.Length > MaxUrlLength)
        {
            _logger?.LogWarning("Wiki page URL too long: {Length} characters", wikiPageUrl.Length);
            wikiPageUrl = null;
        }

        if (baseUrl != null && !IsValidUrl(baseUrl))
        {
            _logger?.LogWarning("Invalid base URL format: {Url}", baseUrl);
            baseUrl = null;
        }

        if (baseUrl != null && baseUrl.Length > MaxUrlLength)
        {
            _logger?.LogWarning("Base URL too long: {Length} characters", baseUrl.Length);
            baseUrl = null;
        }

        if (endpointsUrl != null && !IsValidUrl(endpointsUrl))
        {
            _logger?.LogWarning("Invalid endpoints URL format: {Url}", endpointsUrl);
            endpointsUrl = null;
        }

        if (endpointsUrl != null && endpointsUrl.Length > MaxUrlLength)
        {
            _logger?.LogWarning("Endpoints URL too long: {Length} characters", endpointsUrl.Length);
            endpointsUrl = null;
        }

        if (creatioUrl != null && !IsValidUrl(creatioUrl))
        {
            _logger?.LogWarning("Invalid Creatio URL format: {Url}", creatioUrl);
            creatioUrl = null;
        }

        if (creatioUrl != null && creatioUrl.Length > MaxUrlLength)
        {
            _logger?.LogWarning("Creatio URL too long: {Length} characters", creatioUrl.Length);
            creatioUrl = null;
        }

        if (environment == null)
        {
            environment = "TEST";
        }
        else if (environment.Length > 50)
        {
            _logger?.LogWarning("Environment too long: {Length} characters, truncating", environment.Length);
            environment = environment.Substring(0, 50);
        }

        // Структурированное логирование с корреляционным ID
        var correlationId = Guid.NewGuid();
        using var scope = _logger?.BeginScope(new Dictionary<string, object>
        {
            ["EmailRecipient"] = recipientEmail,
            ["ClientId"] = clientId,
            ["Realm"] = realm,
            ["Environment"] = environment,
            ["CorrelationId"] = correlationId.ToString(),
            ["EmailType"] = "client_credentials"
        });

        // Rate limiting: ограничение одновременных отправок
        await _sendSemaphore.WaitAsync().ConfigureAwait(false);
        try
        {
            var smtpSettings = GetSmtpSettings();
            
            if (smtpSettings == null)
            {
                _logger?.LogWarning("SMTP настройки не сконфигурированы");
                return false;
            }

            _logger?.LogInformation("Подключение к SMTP серверу для отправки учетных данных: {Host}:{Port}, SSL: {EnableSsl}", 
                smtpSettings.Host, smtpSettings.Port, smtpSettings.EnableSsl);

            var ticketCellContent = BuildTicketCellContent(ticketNumber, ticketUrl);
            var ticketRow = string.IsNullOrWhiteSpace(ticketCellContent)
                ? string.Empty
                : $@"<tr>
                          <td width=""35%"" style=""padding:12px 16px; color:#6c757d; font-size:12px; border-bottom:1px solid #e9ecef;"">Номер тикета</td>
                          <td style=""padding:12px 16px; color:#212529; font-weight:bold; border-bottom:1px solid #e9ecef;"">{ticketCellContent}</td>
                        </tr>";

            var wikiRow = string.IsNullOrWhiteSpace(wikiPageUrl)
                ? string.Empty
                : $@"<tr>
                          <td width=""35%"" style=""padding:12px 16px; color:#6c757d; font-size:12px; border-bottom:1px solid #e9ecef;"">Wiki страница</td>
                          <td style=""padding:12px 16px; border-bottom:1px solid #e9ecef;""><a href=""{WebUtility.HtmlEncode(wikiPageUrl)}"" style=""color:#0d6efd;"" target=""_blank"" rel=""noopener"">Открыть ссылку</a></td>
                        </tr>";

            // Экранирование пользовательских данных для безопасности
            var encodedClientId = WebUtility.HtmlEncode(clientId);
            var encodedRealm = WebUtility.HtmlEncode(realm);
            var encodedEnvironment = WebUtility.HtmlEncode(environment);
            var encodedArchivePassword = WebUtility.HtmlEncode(archivePassword);
            var encodedTicketNumber = string.IsNullOrWhiteSpace(ticketNumber) 
                ? null 
                : WebUtility.HtmlEncode(ticketNumber);
            var dateTime = DateTime.UtcNow.ToString("dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture);

            var message = new MimeMessage();
            message.From.Add(CreateMailboxAddress("KeyCloak Assistant", smtpSettings.FromEmail));
            message.To.Add(CreateMailboxAddress("", recipientEmail));
            
            var subject = string.IsNullOrWhiteSpace(ticketNumber)
                ? "Пароль от архива клиента"
                : $"Пароль от архива по заявке {encodedTicketNumber}";
            if (subject.Length > MaxSubjectLength)
            {
                _logger?.LogWarning("Subject too long: {Length} characters, truncating to {MaxLength}", 
                    subject.Length, MaxSubjectLength);
                subject = subject.Substring(0, MaxSubjectLength - 3) + "...";
            }
            message.Subject = subject;

            // HTML шаблон для письма с учетными данными
            // Примечание: HTML шаблоны встроены в код для простоты.
            // Для улучшения конфигурируемости можно вынести шаблоны в отдельные файлы
            // или использовать шаблонизатор (например, Razor Engine).
            // Все пользовательские данные экранируются через WebUtility.HtmlEncode
            // для защиты от XSS атак. Валидация HTML структуры не выполняется,
            // так как шаблоны статичны и контролируются разработчиками.
            var bodyBuilder = new BodyBuilder
            {
                HtmlBody = $@"
<!DOCTYPE html>
<html lang=""ru"">
<head>
  <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8"" />
  <meta name=""viewport"" content=""width=device-width, initial-scale=1"" />
  <meta http-equiv=""X-UA-Compatible"" content=""IE=edge"" />
  <title>Учетные данные клиента - KeyCloak Assistant</title>
</head>
<body style=""margin:0; padding:0; background-color:#E1E2E3;"">
  <center style=""width:100%; background-color:#E1E2E3;"">
    <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" width=""100%"">
      <tr>
        <td align=""center"" style=""padding:20px;"">
          <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" width=""600"" style=""width:600px; max-width:600px; background:#ffffff; border:1px solid #e9ecef;"">
            <tr>
              <td align=""center"" bgcolor=""#6c757d"" style=""padding:24px 20px; color:#ffffff; font-family:Arial, sans-serif;"">
                <div style=""font-size:20px; font-weight:bold; line-height:1.2;"">🔐 Учетные данные клиента</div>
                <div style=""margin-top:4px; font-size:13px; opacity:0.95;"">KeyCloak Assistant</div>
              </td>
            </tr>
            <tr>
              <td style=""padding:24px 20px; font-family:Arial, sans-serif;"">
                <table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"">
                  <tr>
                    <td align=""center"" style=""background:#28a745; color:#ffffff; padding:12px 14px; font-weight:bold;"">✅ Клиент успешно создан на {encodedEnvironment} стенде. Ниже представлены учетные данные.</td>
                  </tr>
                </table>

                <table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""margin-top:20px;"">
                  <tr>
                    <td valign=""top"" style=""width:100%;"">
                      <table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""border:1px solid #e9ecef;"">
                        <tr>
                          <td colspan=""2"" style=""padding:14px 16px; font-weight:bold; color:#495057; background:#f8f9fa; border-bottom:1px solid #e9ecef;"">📋 Информация о клиенте</td>
                        </tr>
                        <tr>
                          <td width=""35%"" style=""padding:12px 16px; color:#6c757d; font-size:12px; border-bottom:1px solid #e9ecef;"">Client ID</td>
                          <td style=""padding:12px 16px; color:#212529; font-weight:bold; border-bottom:1px solid #e9ecef;"">{encodedClientId}</td>
                        </tr>
                        <tr>
                          <td width=""35%"" style=""padding:12px 16px; color:#6c757d; font-size:12px; border-bottom:1px solid #e9ecef;"">Realm</td>
                          <td style=""padding:12px 16px; color:#212529; font-weight:bold; border-bottom:1px solid #e9ecef;"">{encodedRealm}</td>
                        </tr>
                        <tr>
                          <td width=""35%"" style=""padding:12px 16px; color:#6c757d; font-size:12px; border-bottom:1px solid #e9ecef;"">Дата создания</td>
                          <td style=""padding:12px 16px; color:#212529; font-weight:bold; border-bottom:1px solid #e9ecef;"">{dateTime}</td>
                        </tr>
                        {ticketRow}
                        {wikiRow}
                      </table>
                    </td>
                    <td valign=""top"" style=""width:100%; padding-top:16px;"">
                      <table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""background:#4B735C; text-align:center;"">
                        <tr>
                          <td style=""padding:16px; color:#ffffff; font-weight:bold;"">🔑 Пароль от архива</td>
                        </tr>
                        <tr>
                          <td style=""padding:4px 16px 16px 16px;"">
                            <div style=""display:inline-block; font-family:Courier, 'Courier New', monospace; font-size:18px; color:#ffffff; padding:12px 16px; border:2px solid #ffffff;"">{encodedArchivePassword}</div>
                            <div style=""margin-top:8px; font-size:12px; color:#ffffff;"">Архив содержит Client ID и Client Secret</div>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>

                <table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""margin-top:10px; border:1px solid #f5c6cb; background:#f8d7da;"">
                  <tr>
                    <td style=""padding:14px 16px; color:#721c24; font-weight:bold; border-bottom:1px solid #f5c6cb;"">🛡️ Требования безопасности</td>
                  </tr>
                  <tr>
                    <td style=""padding:10px 16px; color:#721c24;"">Сохраните пароль в безопасном месте</td>
                  </tr>
                  <tr>
                    <td style=""padding:10px 16px; color:#721c24;"">Не передавайте данные по незащищенным каналам</td>
                  </tr>
                  <tr>
                    <td style=""padding:10px 16px; color:#721c24;"">Удалите архив и письмо после использования</td>
                  </tr>
                  <tr>
                    <td style=""padding:10px 16px; color:#721c24;"">При компрометации немедленно обратитесь к администратору</td>
                  </tr>
                </table>

                {BuildConnectionInfoSection(baseUrl, endpointsUrl, realm, clientId)}

                <table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""margin-top:20px; border:1px solid #e9ecef;"">
                  <tr>
                    <td style=""padding:14px 16px; font-weight:bold; color:#495057; background:#f8f9fa; border-bottom:1px solid #e9ecef;"">📥 Инструкция по использованию</td>
                  </tr>
                  <tr>
                    <td style=""padding:10px 16px; color:#6c757d;"">1. Скачайте архив с учетными данными через интерфейс {BuildCreatioLink(creatioUrl)}</td>
                  </tr>
                  <tr>
                    <td style=""padding:10px 16px; color:#6c757d;"">2. Распакуйте архив, используя указанный выше пароль</td>
                  </tr>
                  <tr>
                    <td style=""padding:10px 16px; color:#6c757d;"">3. Настройте приложение с Client ID и Client Secret</td>
                  </tr>
                  <tr>
                    <td style=""padding:10px 16px; color:#6c757d;"">4. Удалите архив и это письмо после сохранения данных в безопасном месте</td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td align=""center"" bgcolor=""#f8f9fa"" style=""padding:16px 12px; color:#6c757d; font-size:12px; border-top:1px solid #e9ecef; font-family:Arial, sans-serif;"">KeyCloak Assistant<br/>Автоматическое сообщение системы • Не отвечайте на это письмо</td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </center>
</body>
                </html>"
            };

            // Проверка размера сообщения
            var messageSize = Encoding.UTF8.GetByteCount(bodyBuilder.HtmlBody);
            if (messageSize > MaxMessageSize)
            {
                _logger?.LogWarning("Message size {Size} bytes exceeds maximum {MaxSize} bytes for credentials email to {Email} for client {ClientId}", 
                    messageSize, MaxMessageSize, recipientEmail, clientId);
                return false;
            }

            message.Body = bodyBuilder.ToMessageBody();

            // Использование retry механизма с таймаутом
            var success = await SendWithRetryAsync(async cancellationToken =>
            {
                await SendEmailAsync(message, cancellationToken).ConfigureAwait(false);
            }, CancellationToken.None).ConfigureAwait(false);

            if (success)
            {
                _logger?.LogInformation("Email с учетными данными успешно отправлен на {Email} для клиента {ClientId}", recipientEmail, clientId);
            }

            return success;
        }
        catch (SmtpCommandException ex)
        {
            _logger?.LogError(ex, "SMTP command error sending credentials email to {Email} for client {ClientId}: {StatusCode}", 
                recipientEmail, clientId, ex.StatusCode);
            return false;
        }
        catch (SmtpProtocolException ex)
        {
            _logger?.LogError(ex, "SMTP protocol error sending credentials email to {Email} for client {ClientId}: {Message}", 
                recipientEmail, clientId, ex.Message);
            return false;
        }
        catch (MailKit.Security.AuthenticationException ex)
        {
            _logger?.LogError(ex, "SMTP authentication failed sending credentials email to {Email} for client {ClientId}: {Message}", 
                recipientEmail, clientId, ex.Message);
            return false;
        }
        catch (SocketException ex)
        {
            _logger?.LogError(ex, "Network error connecting to SMTP server for credentials email to {Email} for client {ClientId}: {Message}", 
                recipientEmail, clientId, ex.Message);
            return false;
        }
        catch (TimeoutException ex)
        {
            _logger?.LogError(ex, "SMTP operation timed out for credentials email to {Email} for client {ClientId}: {Message}", 
                recipientEmail, clientId, ex.Message);
            return false;
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Не удалось отправить email на {Email} для клиента {ClientId}", 
                recipientEmail, clientId);
            return false;
        }
        finally
        {
            _sendSemaphore.Release();
        }
    }

    private static string BuildTicketCellContent(string? ticketNumber, string? ticketUrl)
    {
        var hasNumber = !string.IsNullOrWhiteSpace(ticketNumber);
        var hasUrl = !string.IsNullOrWhiteSpace(ticketUrl);

        if (!hasNumber && !hasUrl)
        {
            return string.Empty;
        }

        var displayText = hasNumber ? ticketNumber!.Trim() : ticketUrl!.Trim();
        var encodedText = WebUtility.HtmlEncode(displayText);

        if (hasUrl)
        {
            var encodedUrl = WebUtility.HtmlEncode(ticketUrl!.Trim());
            return $@"<strong><a href=""{encodedUrl}"" style=""color:#0d6efd;"" target=""_blank"" rel=""noopener"">{encodedText}</a></strong>";
        }

        return $"<strong>{encodedText}</strong>";
    }

    private static string BuildConnectionInfoSection(string? baseUrl, string? endpointsUrl, string realm, string clientId)
    {
        if (string.IsNullOrWhiteSpace(baseUrl) && string.IsNullOrWhiteSpace(endpointsUrl))
        {
            return string.Empty;
        }

        var baseUrlRow = string.IsNullOrWhiteSpace(baseUrl)
            ? string.Empty
            : $@"<tr>
                      <td width=""35%"" style=""padding:12px 16px; color:#6c757d; font-size:12px; border-bottom:1px solid #e9ecef;"">Base URL</td>
                      <td style=""padding:12px 16px; color:#212529; font-weight:bold; border-bottom:1px solid #e9ecef;"">{WebUtility.HtmlEncode(baseUrl)}</td>
                    </tr>";

        var endpointsRow = string.IsNullOrWhiteSpace(endpointsUrl)
            ? string.Empty
            : $@"<tr>
                      <td width=""35%"" style=""padding:12px 16px; color:#6c757d; font-size:12px; border-bottom:1px solid #e9ecef;"">Endpoints</td>
                      <td style=""padding:12px 16px; border-bottom:1px solid #e9ecef;""><a href=""{WebUtility.HtmlEncode(endpointsUrl)}"" style=""color:#0d6efd;"" target=""_blank"" rel=""noopener"">{WebUtility.HtmlEncode(endpointsUrl)}</a></td>
                    </tr>";

        var realmRow = $@"<tr>
                      <td width=""35%"" style=""padding:12px 16px; color:#6c757d; font-size:12px; border-bottom:1px solid #e9ecef;"">Realm</td>
                      <td style=""padding:12px 16px; color:#212529; font-weight:bold; border-bottom:1px solid #e9ecef;"">{WebUtility.HtmlEncode(realm)}</td>
                    </tr>";

        var clientIdRow = $@"<tr>
                      <td width=""35%"" style=""padding:12px 16px; color:#6c757d; font-size:12px; border-bottom:1px solid #e9ecef;"">Client ID</td>
                      <td style=""padding:12px 16px; color:#212529; font-weight:bold; border-bottom:1px solid #e9ecef;"">{WebUtility.HtmlEncode(clientId)}</td>
                    </tr>";

        return $@"<table role=""presentation"" width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""margin-top:20px; border:1px solid #e9ecef;"">
                  <tr>
                    <td colspan=""2"" style=""padding:14px 16px; font-weight:bold; color:#495057; background:#f8f9fa; border-bottom:1px solid #e9ecef;"">🔗 Информация по подключению</td>
                  </tr>
                  {baseUrlRow}
                  {endpointsRow}
                  {realmRow}
                  {clientIdRow}
                </table>";
    }

    private static string BuildCreatioLink(string? creatioUrl)
    {
        if (string.IsNullOrWhiteSpace(creatioUrl))
        {
            return "Creatio";
        }

        var encodedUrl = WebUtility.HtmlEncode(creatioUrl.Trim());
        return $@"<a href=""{encodedUrl}"" style=""color:#0d6efd;"" target=""_blank"" rel=""noopener"">Creatio</a>";
    }

    /// <summary>
    /// Тестирует SMTP соединение
    /// </summary>
    /// <returns>True если соединение успешно установлено и тестовое письмо отправлено, иначе False</returns>
    public async Task<bool> TestSmtpConnectionAsync()
    {
        var correlationId = Guid.NewGuid();
        using var scope = _logger?.BeginScope(new Dictionary<string, object>
        {
            ["CorrelationId"] = correlationId.ToString(),
            ["EmailType"] = "smtp_test"
        });

        // Rate limiting: ограничение одновременных отправок
        await _sendSemaphore.WaitAsync();
        try
        {
            var smtpSettings = GetSmtpSettings();
            
            if (smtpSettings == null)
            {
                _logger?.LogWarning("SMTP настройки не сконфигурированы для тестирования");
                return false;
            }

            _logger?.LogInformation("Тестирование SMTP соединения: {Host}:{Port}, SSL: {EnableSsl}", 
                smtpSettings.Host, smtpSettings.Port, smtpSettings.EnableSsl);

            // Создаем тестовое сообщение
            var testMessage = new MimeMessage();
            testMessage.From.Add(CreateMailboxAddress("KeyCloak Assistant Test", smtpSettings.FromEmail));
            testMessage.To.Add(CreateMailboxAddress("", smtpSettings.FromEmail)); // Отправляем себе
            testMessage.Subject = "Тест SMTP соединения";
            
            var bodyBuilder = new BodyBuilder
            {
                TextBody = "Это тестовое сообщение для проверки SMTP соединения."
            };
            
            // Проверка размера сообщения (для полноты, хотя тестовое сообщение всегда маленькое)
            var messageSize = Encoding.UTF8.GetByteCount(bodyBuilder.TextBody ?? "");
            if (messageSize > MaxMessageSize)
            {
                _logger?.LogWarning("Test message size {Size} bytes exceeds maximum {MaxSize} bytes", 
                    messageSize, MaxMessageSize);
                return false;
            }
            
            testMessage.Body = bodyBuilder.ToMessageBody();

            using var cts = new CancellationTokenSource(TestSmtpTimeout);
            var success = await SendEmailAsync(testMessage, cts.Token).ConfigureAwait(false);
            
            if (success)
            {
                _logger?.LogInformation("SMTP соединение успешно протестировано");
            }

            return success;
        }
        catch (SmtpCommandException ex)
        {
            _logger?.LogError(ex, "SMTP command error during test: {StatusCode} - {Message}", ex.StatusCode, ex.Message);
            return false;
        }
        catch (SmtpProtocolException ex)
        {
            _logger?.LogError(ex, "SMTP protocol error during test: {Message}", ex.Message);
            return false;
        }
        catch (MailKit.Security.AuthenticationException ex)
        {
            _logger?.LogError(ex, "SMTP authentication failed during test: {Message}", ex.Message);
            return false;
        }
        catch (SocketException ex)
        {
            _logger?.LogError(ex, "Network error connecting to SMTP server during test: {Message}", ex.Message);
            return false;
        }
        catch (TimeoutException ex)
        {
            _logger?.LogError(ex, "SMTP operation timed out during test: {Message}", ex.Message);
            return false;
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Ошибка при тестировании SMTP соединения: {ErrorMessage}", ex.Message);
            return false;
        }
        finally
        {
            _sendSemaphore.Release();
        }
    }

    /// <summary>
    /// Проверяет валидность email адреса
    /// </summary>
    private static bool IsValidEmail(string email)
    {
        if (string.IsNullOrWhiteSpace(email))
            return false;
        
        if (email.Length > MaxEmailLength)
            return false;

        try
        {
            var addr = new MailAddress(email);
            return addr.Address == email;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Проверяет валидность URL
    /// </summary>
    private static bool IsValidUrl(string? url)
    {
        if (string.IsNullOrWhiteSpace(url))
            return false;
        
        return Uri.TryCreate(url, UriKind.Absolute, out var uri) && 
               (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps);
    }

    /// <summary>
    /// Создает MailboxAddress с обработкой ошибок
    /// </summary>
    private MailboxAddress CreateMailboxAddress(string displayName, string email)
    {
        if (!IsValidEmail(email))
        {
            _logger?.LogWarning("Invalid email format in CreateMailboxAddress: {Email}", email);
            // Все равно пытаемся создать, так как MailboxAddress может обработать некоторые некорректные форматы
        }
        
        try
        {
            return new MailboxAddress(displayName, email);
        }
        catch (Exception ex)
        {
            _logger?.LogWarning(ex, "Failed to create MailboxAddress for {Email}, using email only", email);
            return new MailboxAddress("", email);
        }
    }

    /// <summary>
    /// Отправляет email с retry механизмом
    /// </summary>
    private async Task<bool> SendWithRetryAsync(
        Func<CancellationToken, Task> sendAction, 
        CancellationToken cancellationToken = default,
        int maxRetries = MaxRetries)
    {
        Exception? lastException = null;
        
        for (int attempt = 1; attempt <= maxRetries; attempt++)
        {
            try
            {
                using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                cts.CancelAfter(DefaultSmtpTimeout);
                await sendAction(cts.Token).ConfigureAwait(false);
                return true;
            }
            catch (SmtpCommandException ex) when (attempt < maxRetries && IsRetryableError(ex))
            {
                lastException = ex;
                var delay = TimeSpan.FromSeconds(BaseRetryDelay.TotalSeconds * Math.Pow(2, attempt - 1));
                _logger?.LogWarning("SMTP error on attempt {Attempt}/{MaxRetries}, retrying in {Delay}s: {Error}", 
                    attempt, maxRetries, delay.TotalSeconds, ex.Message);
                await Task.Delay(delay, cancellationToken).ConfigureAwait(false);
            }
            catch (SmtpProtocolException ex) when (attempt < maxRetries)
            {
                lastException = ex;
                var delay = TimeSpan.FromSeconds(BaseRetryDelay.TotalSeconds * Math.Pow(2, attempt - 1));
                _logger?.LogWarning("SMTP protocol error on attempt {Attempt}/{MaxRetries}, retrying in {Delay}s: {Error}", 
                    attempt, maxRetries, delay.TotalSeconds, ex.Message);
                await Task.Delay(delay, cancellationToken).ConfigureAwait(false);
            }
            catch (SocketException ex) when (attempt < maxRetries)
            {
                lastException = ex;
                var delay = TimeSpan.FromSeconds(BaseRetryDelay.TotalSeconds * Math.Pow(2, attempt - 1));
                _logger?.LogWarning("Network error on attempt {Attempt}/{MaxRetries}, retrying in {Delay}s: {Error}", 
                    attempt, maxRetries, delay.TotalSeconds, ex.Message);
                await Task.Delay(delay, cancellationToken).ConfigureAwait(false);
            }
            catch (TimeoutException ex) when (attempt < maxRetries)
            {
                lastException = ex;
                var delay = TimeSpan.FromSeconds(BaseRetryDelay.TotalSeconds * Math.Pow(2, attempt - 1));
                _logger?.LogWarning("Timeout on attempt {Attempt}/{MaxRetries}, retrying in {Delay}s: {Error}", 
                    attempt, maxRetries, delay.TotalSeconds, ex.Message);
                await Task.Delay(delay, cancellationToken).ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                _logger?.LogWarning("Operation was cancelled on attempt {Attempt}/{MaxRetries}", attempt, maxRetries);
                return false;
            }
            catch (Exception ex) when (attempt < maxRetries)
            {
                lastException = ex;
                var delay = TimeSpan.FromSeconds(BaseRetryDelay.TotalSeconds * Math.Pow(2, attempt - 1));
                _logger?.LogWarning("Error on attempt {Attempt}/{MaxRetries}, retrying in {Delay}s: {Error}", 
                    attempt, maxRetries, delay.TotalSeconds, ex.Message);
                await Task.Delay(delay, cancellationToken).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                lastException = ex;
                break; // Не повторяем для неожиданных ошибок
            }
        }
        
        if (lastException != null)
        {
            _logger?.LogError(lastException, "All {MaxRetries} retry attempts failed", maxRetries);
        }
        
        return false;
    }

    /// <summary>
    /// Проверяет, является ли ошибка SMTP повторяемой
    /// </summary>
    private static bool IsRetryableError(SmtpCommandException ex)
    {
        // Временные ошибки, которые можно повторить
        return ex.StatusCode == MailKit.Net.Smtp.SmtpStatusCode.ServiceNotAvailable ||
               ex.StatusCode == MailKit.Net.Smtp.SmtpStatusCode.MailboxUnavailable ||
               ex.StatusCode == MailKit.Net.Smtp.SmtpStatusCode.ExceededStorageAllocation ||
               ex.StatusCode == MailKit.Net.Smtp.SmtpStatusCode.InsufficientStorage;
    }

    /// <summary>
    /// Отправляет email через SMTP (общий метод для устранения дублирования)
    /// </summary>
    /// <remarks>
    /// Примечание о производительности: SMTP клиент создается заново для каждой отправки.
    /// Это обеспечивает thread-safety, но может быть неэффективно при высокой нагрузке.
    /// Для оптимизации можно рассмотреть connection pooling, но это требует осторожности
    /// из-за проблем с thread-safety и управлением соединениями.
    /// </remarks>
    private async Task<bool> SendEmailAsync(MimeMessage message, CancellationToken cancellationToken)
    {
        var smtpSettings = GetSmtpSettings();
        if (smtpSettings == null)
        {
            _logger?.LogWarning("SMTP настройки не сконфигурированы");
            return false;
        }

        using var client = new MailKit.Net.Smtp.SmtpClient();
        
        // Настройка валидации SSL/TLS сертификата
        // По умолчанию MailKit использует стандартную валидацию сертификата
        // Для production это безопасно. Для тестирования с самоподписанными сертификатами
        // можно использовать: client.ServerCertificateValidationCallback = (s, c, h, e) => true;
        // НО это НЕ рекомендуется для production!
        var sslOptions = smtpSettings.EnableSsl ? SecureSocketOptions.StartTls : SecureSocketOptions.None;
        
        await client.ConnectAsync(smtpSettings.Host, smtpSettings.Port, sslOptions, cancellationToken)
            .ConfigureAwait(false);
        
        if (!string.IsNullOrEmpty(smtpSettings.Username) && !string.IsNullOrEmpty(smtpSettings.Password))
        {
            await client.AuthenticateAsync(smtpSettings.Username, smtpSettings.Password, cancellationToken)
                .ConfigureAwait(false);
        }
        
        await client.SendAsync(message, cancellationToken).ConfigureAwait(false);
        await client.DisconnectAsync(true, cancellationToken).ConfigureAwait(false);
        
        return true;
    }

    /// <summary>
    /// Получает настройки SMTP из конфигурации
    /// </summary>
    /// <remarks>
    /// Примечание о thread-safety: IConfiguration в ASP.NET Core является thread-safe для чтения,
    /// поэтому этот метод можно безопасно вызывать из разных потоков одновременно.
    /// </remarks>
    private SmtpSettings? GetSmtpSettings()
    {
        var settings = new SmtpSettings
        {
            Host = _configuration["Email:Smtp:Host"] ?? "",
            Port = int.TryParse(_configuration["Email:Smtp:Port"], out var port) && 
                   port > 0 && port <= 65535 ? port : 587,
            EnableSsl = bool.TryParse(_configuration["Email:Smtp:EnableSsl"], out var enableSsl) && enableSsl,
            Username = _configuration["Email:Smtp:Username"] ?? "",
            Password = _configuration["Email:Smtp:Password"] ?? "",
            FromEmail = _configuration["Email:Smtp:FromEmail"] ?? ""
        };

        // Проверяем, что все необходимые настройки заполнены
        if (string.IsNullOrEmpty(settings.Host) || 
            string.IsNullOrEmpty(settings.Username) || 
            string.IsNullOrEmpty(settings.FromEmail))
        {
            _logger?.LogWarning("SMTP настройки неполные. Host: {HasHost}, Username: {HasUsername}, FromEmail: {HasFromEmail}",
                !string.IsNullOrEmpty(settings.Host),
                !string.IsNullOrEmpty(settings.Username),
                !string.IsNullOrEmpty(settings.FromEmail));
            return null;
        }

        return settings;
    }

    private class SmtpSettings
    {
        public string Host { get; set; } = "";
        public int Port { get; set; }
        public bool EnableSsl { get; set; }
        public string Username { get; set; } = "";
        public string Password { get; set; } = "";
        public string FromEmail { get; set; } = "";
    }
}

