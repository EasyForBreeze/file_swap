using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using new_assistant.Configuration;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Sockets;

namespace new_assistant.Infrastructure.Extensions;

/// <summary>
/// Extension методы для настройки Forwarded Headers
/// </summary>
public static class ForwardedHeadersExtensions
{
    /// <summary>
    /// Настройка Forwarded Headers для корректной обработки HTTPS-схемы и IP-адресов за reverse proxy
    /// </summary>
    /// <param name="services">Коллекция сервисов</param>
    /// <param name="configuration">Конфигурация приложения</param>
    /// <param name="environment">Окружение приложения</param>
    /// <param name="logger">Логгер для записи событий (опционально)</param>
    /// <returns>Коллекция сервисов для цепочки вызовов</returns>
    /// <exception cref="InvalidOperationException">Выбрасывается при ошибках конфигурации</exception>
    public static IServiceCollection AddForwardedHeadersConfiguration(
        this IServiceCollection services, 
        IConfiguration configuration, 
        IHostEnvironment environment,
        ILogger? logger = null)
    {
        var forwardedHeadersSettings = configuration.GetSection("ForwardedHeaders").Get<ForwardedHeadersSettings>();

        if (forwardedHeadersSettings == null)
        {
            var error = "ForwardedHeaders configuration is missing. Check the ForwardedHeaders section in appsettings.json.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Проверка на null для массивов
        var knownProxies = forwardedHeadersSettings.KnownProxies ?? Array.Empty<string>();
        var knownNetworks = forwardedHeadersSettings.KnownNetworks ?? Array.Empty<string>();

        // Проверка на максимальное количество элементов (можно настроить через конфигурацию)
        var maxProxies = configuration.GetValue<int>("ForwardedHeaders:MaxProxies", 100);
        var maxNetworks = configuration.GetValue<int>("ForwardedHeaders:MaxNetworks", 100);

        if (knownProxies.Length > maxProxies)
        {
            var error = $"ForwardedHeaders: KnownProxies содержит слишком много элементов ({knownProxies.Length}). Максимум: {maxProxies}.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        if (knownNetworks.Length > maxNetworks)
        {
            var error = $"ForwardedHeaders: KnownNetworks содержит слишком много элементов ({knownNetworks.Length}). Максимум: {maxNetworks}.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        services.Configure<ForwardedHeadersOptions>(options =>
        {
            // Настройка ForwardedHeaders (можно сделать настраиваемым через конфигурацию)
            var forwardedHeadersValue = configuration.GetValue<string>("ForwardedHeaders:Headers", "XForwardedFor,XForwardedProto");
            
            if (string.IsNullOrWhiteSpace(forwardedHeadersValue))
            {
                logger?.LogWarning("ForwardedHeaders:Headers пустая, используются значения по умолчанию: XForwardedFor,XForwardedProto");
                forwardedHeadersValue = "XForwardedFor,XForwardedProto";
            }

            var headers = ForwardedHeaders.None;
            var validHeaders = new[] { "XForwardedFor", "XForwardedProto", "XForwardedHost", "XForwardedPrefix" };
            var specifiedHeaders = forwardedHeadersValue.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            foreach (var header in specifiedHeaders)
            {
                if (!validHeaders.Contains(header, StringComparer.OrdinalIgnoreCase))
                {
                    logger?.LogWarning("Неизвестный заголовок в ForwardedHeaders:Headers: {Header}. Будет проигнорирован.", header);
                    continue;
                }

                if (header.Equals("XForwardedFor", StringComparison.OrdinalIgnoreCase))
                {
                    headers |= ForwardedHeaders.XForwardedFor;
                }
                else if (header.Equals("XForwardedProto", StringComparison.OrdinalIgnoreCase))
                {
                    headers |= ForwardedHeaders.XForwardedProto;
                }
                else if (header.Equals("XForwardedHost", StringComparison.OrdinalIgnoreCase))
                {
                    headers |= ForwardedHeaders.XForwardedHost;
                }
                else if (header.Equals("XForwardedPrefix", StringComparison.OrdinalIgnoreCase))
                {
                    headers |= ForwardedHeaders.XForwardedPrefix;
                }
            }

            if (headers == ForwardedHeaders.None)
            {
                logger?.LogWarning("ForwardedHeaders установлен в None. Forwarded headers не будут обрабатываться.");
            }

            options.ForwardedHeaders = headers;
            options.KnownNetworks.Clear();
            options.KnownProxies.Clear();

            if (environment.IsDevelopment() &&
                knownNetworks.Length == 0 &&
                knownProxies.Length == 0)
            {
                // The development experience should work without a reverse proxy, so we avoid restricting
                // forwarded headers locally unless values are explicitly configured.
                logger?.LogInformation("ForwardedHeaders: Development режим без явной конфигурации. Ограничения не применяются.");
                return;
            }

            // Обработка прокси с проверкой на дубликаты и пустые строки
            var addedProxies = new HashSet<IPAddress>();
            var hasIPv4 = false;
            var hasIPv6 = false;

            foreach (var proxy in knownProxies)
            {
                // Обрезаем пробелы в начале и конце
                var trimmedProxy = proxy?.Trim();
                if (string.IsNullOrWhiteSpace(trimmedProxy))
                {
                    logger?.LogWarning("Пустой элемент в KnownProxies пропущен.");
                    continue;
                }

                try
                {
                    var address = ParseProxyAddress(trimmedProxy, logger);
                    
                    if (!addedProxies.Add(address))
                    {
                        logger?.LogWarning("Дублирующийся прокси-адрес пропущен: {Proxy}", proxy);
                        continue;
                    }

                    // Отслеживание типов адресов
                    if (address.AddressFamily == AddressFamily.InterNetwork)
                        hasIPv4 = true;
                    else if (address.AddressFamily == AddressFamily.InterNetworkV6)
                        hasIPv6 = true;

                    options.KnownProxies.Add(address);
                }
                catch (Exception ex)
                {
                    logger?.LogError(ex, "Ошибка при обработке прокси-адреса: {Proxy}", proxy);
                    throw;
                }
            }

            if (hasIPv4 && hasIPv6)
            {
                logger?.LogInformation("Известные прокси используют смешанные типы адресов (IPv4 и IPv6). Это нормально, но убедитесь, что все прокси поддерживают оба типа.");
            }

            // Обработка сетей с проверкой на дубликаты и пустые строки
            var addedNetworks = new HashSet<string>();
            var parsedNetworks = new List<Microsoft.AspNetCore.HttpOverrides.IPNetwork>();

            foreach (var network in knownNetworks)
            {
                // Обрезаем пробелы в начале и конце
                var trimmedNetwork = network?.Trim();
                if (string.IsNullOrWhiteSpace(trimmedNetwork))
                {
                    logger?.LogWarning("Пустой элемент в KnownNetworks пропущен.");
                    continue;
                }

                if (addedNetworks.Contains(trimmedNetwork))
                {
                    logger?.LogWarning("Дублирующаяся сеть пропущена: {Network}", trimmedNetwork);
                    continue;
                }

                try
                {
                    var parsedNetwork = ParseNetwork(trimmedNetwork, logger);
                    
                    // Проверка на перекрытие с уже добавленными сетями
                    foreach (var existingNetwork in parsedNetworks)
                    {
                        if (NetworksOverlap(parsedNetwork, existingNetwork))
                        {
                            logger?.LogWarning("Сеть {Network} перекрывается с уже добавленной сетью. Это может привести к путанице.", trimmedNetwork);
                        }
                    }

                    addedNetworks.Add(trimmedNetwork);
                    parsedNetworks.Add(parsedNetwork);
                    options.KnownNetworks.Add(parsedNetwork);
                }
                catch (Exception ex)
                {
                    logger?.LogError(ex, "Ошибка при обработке сети: {Network}", trimmedNetwork);
                    throw;
                }
            }

            // Проверка на конфликт между KnownProxies и KnownNetworks
            foreach (var proxyAddress in options.KnownProxies)
            {
                foreach (var network in options.KnownNetworks)
                {
                    try
                    {
                        if (network.Contains(proxyAddress))
                        {
                            logger?.LogWarning("Прокси-адрес {Address} находится в сети {Network}. Рекомендуется использовать только KnownNetworks для этого адреса.", 
                                proxyAddress, network);
                        }
                    }
                    catch
                    {
                        // Игнорируем ошибки при проверке (например, разные типы адресов)
                    }
                }
            }

            if (options.KnownNetworks.Count == 0 && options.KnownProxies.Count == 0)
            {
                var error = "ForwardedHeaders configuration requires at least one KnownProxies or KnownNetworks entry.";
                logger?.LogError(error);
                throw new InvalidOperationException(error);
            }

            // Валидация ForwardLimit
            if (forwardedHeadersSettings.ForwardLimit is int forwardLimit)
            {
                if (forwardLimit <= 0)
                {
                    var error = $"ForwardedHeaders: ForwardLimit must be a positive integer. Current value: {forwardLimit}";
                    logger?.LogError(error);
                    throw new InvalidOperationException(error);
                }

                var maxForwardLimit = configuration.GetValue<int>("ForwardedHeaders:MaxForwardLimit", 10); // Разумный предел
                if (forwardLimit > maxForwardLimit)
                {
                    logger?.LogWarning("ForwardLimit ({ForwardLimit}) превышает рекомендуемый максимум ({MaxForwardLimit}). Это может быть проблемой безопасности. Используется максимум.", 
                        forwardLimit, maxForwardLimit);
                    forwardLimit = maxForwardLimit;
                }

                options.ForwardLimit = forwardLimit;
            }

            if (forwardedHeadersSettings.RequireHeaderSymmetry is bool requireHeaderSymmetry)
            {
                options.RequireHeaderSymmetry = requireHeaderSymmetry;
            }

            logger?.LogInformation("ForwardedHeaders настроены. KnownProxies: {ProxyCount}, KnownNetworks: {NetworkCount}, ForwardLimit: {ForwardLimit}", 
                options.KnownProxies.Count, options.KnownNetworks.Count, options.ForwardLimit);
        });

        return services;
    }

    /// <summary>
    /// Парсит строку в IP-адрес для KnownProxies
    /// </summary>
    /// <param name="value">Строка с IP-адресом</param>
    /// <param name="logger">Логгер для записи предупреждений (опционально)</param>
    /// <returns>IP-адрес</returns>
    /// <exception cref="InvalidOperationException">Выбрасывается при невалидном IP-адресе</exception>
    private static IPAddress ParseProxyAddress(string? value, ILogger? logger = null)
    {
        // Обрезаем пробелы
        value = value?.Trim();
        
        if (string.IsNullOrWhiteSpace(value))
        {
            var error = "ForwardedHeaders: KnownProxies entries must not be empty.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Проверка на максимальную длину
        const int maxIpAddressLength = 45; // Максимальная длина IPv6 адреса
        if (value.Length > maxIpAddressLength)
        {
            var error = $"ForwardedHeaders: IP-адрес слишком длинный: {value.Length} символов. Максимум: {maxIpAddressLength}";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Проверка на недопустимые символы
        if (value.Contains(' ') || value.Contains('\t') || value.Contains('\n') || value.Contains('\r'))
        {
            var error = $"ForwardedHeaders: IP-адрес содержит недопустимые символы: '{value}'";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        if (!IPAddress.TryParse(value, out var address))
        {
            var error = $"ForwardedHeaders: '{value}' is not a valid IP address.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Проверка на 0.0.0.0 (неопределенный адрес)
        if (address.Equals(IPAddress.Any))
        {
            var error = "ForwardedHeaders: Адрес 0.0.0.0 недопустим в KnownProxies.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Проверка на broadcast адреса (только для IPv4)
        if (address.AddressFamily == AddressFamily.InterNetwork)
        {
            var bytes = address.GetAddressBytes();
            // 255.255.255.255 (limited broadcast)
            if (bytes[0] == 255 && bytes[1] == 255 && bytes[2] == 255 && bytes[3] == 255)
            {
                var error = "ForwardedHeaders: Broadcast адрес недопустим в KnownProxies.";
                logger?.LogError(error);
                throw new InvalidOperationException(error);
            }
        }

        // Проверка на multicast адреса
        if (address.AddressFamily == AddressFamily.InterNetwork)
        {
            var bytes = address.GetAddressBytes();
            // 224.0.0.0/4 (IPv4 multicast)
            if ((bytes[0] & 0xF0) == 0xE0)
            {
                var error = $"ForwardedHeaders: Multicast адрес недопустим в KnownProxies: {address}";
                logger?.LogError(error);
                throw new InvalidOperationException(error);
            }
        }
        else if (address.AddressFamily == AddressFamily.InterNetworkV6)
        {
            var bytes = address.GetAddressBytes();
            // ff00::/8 (IPv6 multicast)
            if (bytes[0] == 0xff)
            {
                var error = $"ForwardedHeaders: Multicast адрес недопустим в KnownProxies: {address}";
                logger?.LogError(error);
                throw new InvalidOperationException(error);
            }
        }

        // Проверка на loopback
        if (IPAddress.IsLoopback(address))
        {
            logger?.LogWarning("Loopback адрес добавлен в KnownProxies: {Address}. Это обычно не требуется.", address);
        }

        // Проверка на приватные/публичные IP
        if (!IsPrivateIPAddress(address))
        {
            logger?.LogWarning("Публичный IP-адрес добавлен в KnownProxies: {Address}. Это может быть проблемой безопасности.", address);
        }

        logger?.LogDebug("Прокси-адрес успешно распознан: {Address}", address);
        return address;
    }

    /// <summary>
    /// Проверяет, является ли IP-адрес приватным
    /// </summary>
    private static bool IsPrivateIPAddress(IPAddress address)
    {
        if (address.AddressFamily == AddressFamily.InterNetwork) // IPv4
        {
            var bytes = address.GetAddressBytes();
            // 10.0.0.0/8
            if (bytes[0] == 10) return true;
            // 172.16.0.0/12
            if (bytes[0] == 172 && bytes[1] >= 16 && bytes[1] <= 31) return true;
            // 192.168.0.0/16
            if (bytes[0] == 192 && bytes[1] == 168) return true;
            // 127.0.0.0/8 (localhost)
            if (bytes[0] == 127) return true;
        }
        else if (address.AddressFamily == AddressFamily.InterNetworkV6) // IPv6
        {
            // ::1 (localhost)
            if (address.Equals(IPAddress.IPv6Loopback)) return true;
            
            var bytes = address.GetAddressBytes();
            
            // fe80::/10 (link-local)
            if (bytes[0] == 0xfe && (bytes[1] & 0xc0) == 0x80) return true;
            
            // fc00::/7 (unique local - ULA)
            if ((bytes[0] & 0xfe) == 0xfc) return true;
            
            // fd00::/8 (ULA с фиксированным префиксом)
            if (bytes[0] == 0xfd) return true;
            
            // ::ffff:0:0/96 (IPv4-mapped IPv6)
            if (bytes[0] == 0 && bytes[1] == 0 && bytes[2] == 0 && bytes[3] == 0 && 
                bytes[4] == 0 && bytes[5] == 0 && bytes[6] == 0 && bytes[7] == 0 &&
                bytes[8] == 0 && bytes[9] == 0 && bytes[10] == 0xff && bytes[11] == 0xff)
            {
                // Проверяем внутренний IPv4 адрес
                var ipv4Bytes = new byte[] { bytes[12], bytes[13], bytes[14], bytes[15] };
                var ipv4Address = new IPAddress(ipv4Bytes);
                return IsPrivateIPAddress(ipv4Address);
            }
        }
        return false;
    }

    /// <summary>
    /// Парсит строку в IPNetwork для KnownNetworks (CIDR notation)
    /// </summary>
    /// <param name="value">Строка с сетью в формате CIDR (например, 10.0.0.0/24)</param>
    /// <param name="logger">Логгер для записи предупреждений (опционально)</param>
    /// <returns>IPNetwork объект</returns>
    /// <exception cref="InvalidOperationException">Выбрасывается при невалидном формате сети</exception>
    private static Microsoft.AspNetCore.HttpOverrides.IPNetwork ParseNetwork(string? value, ILogger? logger = null)
    {
        // Обрезаем пробелы
        value = value?.Trim();
        
        if (string.IsNullOrWhiteSpace(value))
        {
            var error = "ForwardedHeaders: KnownNetworks entries must not be empty.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Проверка на максимальную длину
        const int maxNetworkLength = 50; // Максимальная длина CIDR записи
        if (value.Length > maxNetworkLength)
        {
            var error = $"ForwardedHeaders: Сеть слишком длинная: {value.Length} символов. Максимум: {maxNetworkLength}";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Улучшенная проверка формата
        if (value.Count(c => c == '/') != 1)
        {
            var error = $"ForwardedHeaders: '{value}' must contain exactly one '/' separator for CIDR notation.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        var parts = value.Split('/', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (parts.Length != 2)
        {
            var error = $"ForwardedHeaders: '{value}' must use CIDR notation (for example, 10.0.0.0/24).";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        if (!IPAddress.TryParse(parts[0], out var networkAddress))
        {
            var error = $"ForwardedHeaders: '{parts[0]}' is not a valid IP address.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        var maxPrefix = networkAddress.AddressFamily == AddressFamily.InterNetwork ? 32 : 128;
        if (!int.TryParse(parts[1], NumberStyles.None, CultureInfo.InvariantCulture, out var prefixLength) || 
            prefixLength < 0 || prefixLength > maxPrefix)
        {
            var error = $"ForwardedHeaders: '{parts[1]}' is not a valid prefix length (must be 0-{maxPrefix} for {networkAddress.AddressFamily}).";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Критическая проверка: префикс /0 недопустим
        if (prefixLength == 0)
        {
            var error = "ForwardedHeaders: Префикс /0 недопустим, так как означает все адреса. Это критическая проблема безопасности.";
            logger?.LogError(error);
            throw new InvalidOperationException(error);
        }

        // Проверка на слишком узкие сети
        if (prefixLength == maxPrefix)
        {
            logger?.LogWarning("Префикс /{PrefixLength} означает один адрес. Рекомендуется использовать KnownProxies вместо KnownNetworks для отдельных адресов.", 
                prefixLength);
        }

        // Проверка на слишком широкие сети (можно настроить через конфигурацию)
        var minPrefixIPv4 = 8;  // /8 для IPv4 (можно получить из конфигурации)
        var minPrefixIPv6 = 64; // /64 для IPv6 (можно получить из конфигурации)

        var minPrefix = networkAddress.AddressFamily == AddressFamily.InterNetwork ? minPrefixIPv4 : minPrefixIPv6;
        if (prefixLength < minPrefix)
        {
            logger?.LogWarning("Префикс /{PrefixLength} слишком широкий для {AddressFamily}. Рекомендуется минимум /{MinPrefix}. Это может быть проблемой безопасности.", 
                prefixLength, networkAddress.AddressFamily, minPrefix);
        }

        // Проверка на валидность сетевого адреса (для /32 и /128 пропускаем)
        if (prefixLength != maxPrefix && !IsValidNetworkAddress(networkAddress, prefixLength))
        {
            logger?.LogWarning("IP-адрес {Address} не является валидным сетевым адресом для префикса /{PrefixLength}. Используется как есть.", 
                networkAddress, prefixLength);
        }

        Microsoft.AspNetCore.HttpOverrides.IPNetwork network;
        try
        {
            network = new Microsoft.AspNetCore.HttpOverrides.IPNetwork(networkAddress, prefixLength);
        }
        catch (Exception ex)
        {
            var error = $"ForwardedHeaders: Ошибка при создании IPNetwork для '{value}': {ex.Message}";
            logger?.LogError(ex, error);
            throw new InvalidOperationException(error, ex);
        }

        logger?.LogDebug("Сеть успешно распознана: {Network}", value);
        return network;
    }

    /// <summary>
    /// Проверяет, является ли IP-адрес валидным сетевым адресом для указанного префикса
    /// </summary>
    private static bool IsValidNetworkAddress(IPAddress address, int prefixLength)
    {
        // Для /32 (IPv4) или /128 (IPv6) любой адрес является валидным сетевым адресом
        var maxPrefix = address.AddressFamily == AddressFamily.InterNetwork ? 32 : 128;
        if (prefixLength == maxPrefix)
        {
            return true; // Пропускаем проверку
        }

        if (address.AddressFamily == AddressFamily.InterNetwork) // IPv4
        {
            var bytes = address.GetAddressBytes();
            var hostBits = 32 - prefixLength;
            var hostBytes = hostBits / 8;
            var hostBitsInLastByte = hostBits % 8;
            
            // Проверяем, что все host биты равны 0
            for (int i = 3; i >= 4 - hostBytes; i--)
            {
                if (i == 3 - hostBytes && hostBitsInLastByte > 0)
                {
                    var mask = (byte)(0xFF << hostBitsInLastByte);
                    if ((bytes[i] & mask) != bytes[i]) return false;
                }
                else if (bytes[i] != 0) return false;
            }
        }
        else if (address.AddressFamily == AddressFamily.InterNetworkV6) // IPv6
        {
            var bytes = address.GetAddressBytes();
            var hostBits = 128 - prefixLength;
            var hostBytes = hostBits / 8;
            var hostBitsInLastByte = hostBits % 8;
            
            // Проверяем, что все host биты равны 0
            for (int i = 15; i >= 16 - hostBytes; i--)
            {
                if (i == 15 - hostBytes && hostBitsInLastByte > 0)
                {
                    var mask = (byte)(0xFF << hostBitsInLastByte);
                    if ((bytes[i] & mask) != bytes[i]) return false;
                }
                else if (bytes[i] != 0) return false;
            }
        }
        return true;
    }

    /// <summary>
    /// Проверяет, перекрываются ли две сети
    /// </summary>
    private static bool NetworksOverlap(Microsoft.AspNetCore.HttpOverrides.IPNetwork network1, Microsoft.AspNetCore.HttpOverrides.IPNetwork network2)
    {
        try
        {
            // Проверяем, что сети одного типа
            if (network1.Prefix.AddressFamily != network2.Prefix.AddressFamily)
                return false;

            // Полная проверка: сети перекрываются, если одна содержит другую
            // Упрощенная проверка: если меньшая сеть полностью содержится в большей
            var smallerNetwork = network1.PrefixLength > network2.PrefixLength ? network1 : network2;
            var largerNetwork = network1.PrefixLength > network2.PrefixLength ? network2 : network1;
            
            return largerNetwork.Contains(smallerNetwork.Prefix);
        }
        catch
        {
            // Если сети разных типов (IPv4/IPv6) или другие ошибки, они не перекрываются
            return false;
        }
    }
}

