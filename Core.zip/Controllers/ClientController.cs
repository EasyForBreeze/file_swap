using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using new_assistant.Core.Interfaces;
using new_assistant.Core.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.RateLimiting;

namespace new_assistant.Controllers;

[ApiController]
[Route("api/[controller]")]
[EnableRateLimiting("api")]
public class ClientController : ControllerBase
{
    private readonly IKeycloakAdminService _keycloakAdminService;
    private readonly ILogger<ClientController> _logger;

    public ClientController(
        IKeycloakAdminService keycloakAdminService, 
        ILogger<ClientController> logger)
    {
        _keycloakAdminService = keycloakAdminService ?? throw new ArgumentNullException(nameof(keycloakAdminService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Создать нового клиента в Keycloak
    /// </summary>
    /// <param name="request">Данные для создания клиента</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Результат создания клиента с InternalId</returns>
    /// <response code="200">Клиент успешно создан</response>
    /// <response code="400">Некорректные данные запроса или клиент уже существует</response>
    /// <response code="401">Не авторизован</response>
    /// <response code="403">Недостаточно прав доступа</response>
    /// <response code="500">Внутренняя ошибка сервера</response>
    /// <response code="502">Ошибка взаимодействия с Keycloak</response>
    /// <response code="504">Превышено время ожидания</response>
    /// <remarks>
    /// Требуется роль assistant-admin.
    /// ClientId должен быть уникальным в рамках реалма.
    /// </remarks>
    [HttpPost]
    [Authorize(Roles = "assistant-admin")]
    public async Task<ActionResult<CreateClientResponse>> CreateClient(
        [FromBody] CreateClientRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        var username = User.Identity?.Name ?? "Unknown";

        try
        {
            // Валидация через FluentValidation (автоматически выполняется через AddFluentValidationAutoValidation)
            if (!ModelState.IsValid)
            {
                var errorMessages = string.Join("; ", ModelState.Values
                    .SelectMany(v => v.Errors.Select(e => e.ErrorMessage)));
                
                _logger.LogWarning(
                    "Ошибка валидации при создании клиента {ClientId} пользователем {User}: {ErrorMessage}",
                    request?.ClientId ?? "Unknown",
                    username,
                    errorMessages);
                
                return BadRequest(new CreateClientResponse 
                { 
                    Success = false, 
                    ErrorMessage = errorMessages 
                });
            }

            // Проверяем, существует ли клиент с таким ClientId
            var existingClient = await _keycloakAdminService.GetClientDetailsAsync(
                request.ClientId, 
                request.Realm, 
                cancellationToken);
            
            if (existingClient != null)
            {
                _logger.LogWarning(
                    "Попытка создать клиента с существующим ClientId: {ClientId} в реалме {Realm} пользователем {User}",
                    request.ClientId,
                    request.Realm,
                    username);
                
                return BadRequest(new CreateClientResponse 
                { 
                    Success = false, 
                    ErrorMessage = $"Клиент с ClientId '{request.ClientId}' уже существует в реалме '{request.Realm}'." 
                });
            }

            var clientInternalId = await _keycloakAdminService.CreateClientAsync(request, cancellationToken);
            stopwatch.Stop();

            _logger.LogInformation(
                "Клиент {ClientId} успешно создан в реалме {Realm} с InternalId {InternalId} пользователем {User} за {ElapsedMs}ms",
                request.ClientId,
                request.Realm,
                clientInternalId,
                username,
                stopwatch.ElapsedMilliseconds);

            return Ok(new CreateClientResponse 
            { 
                Success = true, 
                ClientId = request.ClientId, 
                KeycloakInternalId = clientInternalId 
            });
        }
        catch (HttpRequestException ex)
        {
            stopwatch.Stop();
            _logger.LogError(
                ex,
                "Ошибка HTTP при создании клиента {ClientId} в реалме {Realm} пользователем {User} за {ElapsedMs}ms",
                request?.ClientId ?? "Unknown",
                request?.Realm ?? "Unknown",
                username,
                stopwatch.ElapsedMilliseconds);
            
            return StatusCode(502, new CreateClientResponse 
            { 
                Success = false, 
                ErrorMessage = $"Ошибка взаимодействия с Keycloak: {ex.Message}" 
            });
        }
        catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
        {
            stopwatch.Stop();
            _logger.LogError(
                ex,
                "Таймаут при создании клиента {ClientId} в реалме {Realm} пользователем {User} за {ElapsedMs}ms",
                request?.ClientId ?? "Unknown",
                request?.Realm ?? "Unknown",
                username,
                stopwatch.ElapsedMilliseconds);
            
            return StatusCode(504, new CreateClientResponse 
            { 
                Success = false, 
                ErrorMessage = "Превышено время ожидания при создании клиента" 
            });
        }
        catch (TaskCanceledException ex)
        {
            stopwatch.Stop();
            _logger.LogWarning(
                ex,
                "Операция создания клиента {ClientId} в реалме {Realm} была отменена пользователем {User}",
                request?.ClientId ?? "Unknown",
                request?.Realm ?? "Unknown",
                username);
            
            return StatusCode(499, new CreateClientResponse 
            { 
                Success = false, 
                ErrorMessage = "Операция была отменена" 
            });
        }
        catch (ArgumentException ex)
        {
            stopwatch.Stop();
            _logger.LogWarning(
                ex,
                "Некорректные аргументы при создании клиента {ClientId} в реалме {Realm} пользователем {User}: {Message}",
                request?.ClientId ?? "Unknown",
                request?.Realm ?? "Unknown",
                username,
                ex.Message);
            
            return BadRequest(new CreateClientResponse 
            { 
                Success = false, 
                ErrorMessage = $"Некорректные параметры запроса: {ex.Message}" 
            });
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(
                ex,
                "Неожиданная ошибка при создании клиента {ClientId} в реалме {Realm} пользователем {User} за {ElapsedMs}ms",
                request?.ClientId ?? "Unknown",
                request?.Realm ?? "Unknown",
                username,
                stopwatch.ElapsedMilliseconds);
            
            return StatusCode(500, new CreateClientResponse 
            { 
                Success = false, 
                ErrorMessage = "Внутренняя ошибка сервера при создании клиента" 
            });
        }
    }
}
