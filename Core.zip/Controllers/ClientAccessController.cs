using System.Diagnostics;
using System.Net;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Options;
using new_assistant.Configuration;
using new_assistant.Core.Interfaces;
using new_assistant.Core.DTOs;
using System.ComponentModel.DataAnnotations;

namespace new_assistant.Controllers;

/// <summary>
/// Контроллер для управления доступом пользователей к клиентам Keycloak
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "assistant-admin")]
[EnableRateLimiting("admin")]
public class ClientAccessController : ControllerBase
{
    private readonly IKeycloakAdminService _keycloakService;
    private readonly IClientOwnershipService _ownershipService;
    private readonly ILogger<ClientAccessController> _logger;
    private readonly ClientAccessSettings _settings;

    public ClientAccessController(
        IKeycloakAdminService keycloakService,
        IClientOwnershipService ownershipService,
        ILogger<ClientAccessController> logger,
        IOptions<ClientAccessSettings> settings)
    {
        _keycloakService = keycloakService ?? throw new ArgumentNullException(nameof(keycloakService));
        _ownershipService = ownershipService ?? throw new ArgumentNullException(nameof(ownershipService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _settings = settings?.Value ?? throw new ArgumentNullException(nameof(settings));
    }

    /// <summary>
    /// Поиск пользователей в KeyCloak по username
    /// </summary>
    /// <param name="query">Поисковый запрос (минимум 2 символа)</param>
    /// <param name="realm">Реалм для поиска (если не указан, используется реалм по умолчанию из настроек)</param>
    /// <param name="page">Номер страницы (начинается с 1, по умолчанию 1)</param>
    /// <param name="pageSize">Размер страницы (по умолчанию из настроек, максимум из настроек)</param>
    /// <returns>Список найденных пользователей</returns>
    /// <response code="200">Успешный поиск</response>
    /// <response code="400">Некорректные параметры запроса</response>
    /// <response code="401">Не авторизован</response>
    /// <response code="403">Недостаточно прав</response>
    /// <response code="502">Ошибка взаимодействия с Keycloak</response>
    /// <response code="500">Внутренняя ошибка сервера</response>
    /// <example>
    /// GET /api/ClientAccess/search-users?query=john&realm=internal-bank-idm&page=1&pageSize=50
    /// </example>
    [HttpGet("search-users")]
    public async Task<IActionResult> SearchUsers(
        [FromQuery] string query, 
        [FromQuery] string? realm = null,
        [FromQuery, Range(1, int.MaxValue)] int page = 1,
        [FromQuery, Range(1, 100)] int pageSize = 0)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            // Валидация минимальной длины запроса
            if (string.IsNullOrWhiteSpace(query) || query.Length < _settings.MinSearchQueryLength)
            {
                return Ok(new PagedResponse<UserSearchResultDto>
                {
                    Items = Array.Empty<UserSearchResultDto>(),
                    Page = page,
                    PageSize = pageSize > 0 ? pageSize : _settings.DefaultPageSize,
                    TotalCount = 0
                });
            }

            // Нормализация параметров пагинации
            var normalizedPageSize = pageSize > 0 
                ? Math.Min(pageSize, _settings.MaxPageSize) 
                : _settings.DefaultPageSize;

            // Если реалм не указан, используем реалм по умолчанию из настроек
            var searchRealm = realm ?? _settings.DefaultSearchRealm;
            
            var users = await _keycloakService.SearchUsersAsync(query, searchRealm);
            
            // Применяем пагинацию на стороне контроллера (если сервис не поддерживает)
            var totalCount = users.Count;
            var paginatedUsers = users
                .Skip((page - 1) * normalizedPageSize)
                .Take(normalizedPageSize)
                .ToList();

            stopwatch.Stop();
            _logger.LogInformation(
                "SearchUsers completed: Query={Query}, Realm={Realm}, Results={Count}, ElapsedMs={ElapsedMs}",
                query, searchRealm, totalCount, stopwatch.ElapsedMilliseconds);

            return Ok(new PagedResponse<UserSearchResultDto>
            {
                Items = paginatedUsers,
                Page = page,
                PageSize = normalizedPageSize,
                TotalCount = totalCount
            });
        }
        catch (HttpRequestException ex)
        {
            stopwatch.Stop();
            _logger.LogWarning(ex, 
                "Keycloak communication error during user search: Query={Query}, Realm={Realm}, ElapsedMs={ElapsedMs}",
                query, realm ?? _settings.DefaultSearchRealm, stopwatch.ElapsedMilliseconds);
            return StatusCode((int)HttpStatusCode.BadGateway, new ApiErrorResponse
            {
                Error = "Ошибка взаимодействия с Keycloak",
                Details = "Не удалось выполнить запрос к сервису Keycloak"
            });
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, 
                "Unexpected error during user search: Query={Query}, Realm={Realm}, ElapsedMs={ElapsedMs}",
                query, realm ?? _settings.DefaultSearchRealm, stopwatch.ElapsedMilliseconds);
            return StatusCode(500, new ApiErrorResponse
            {
                Error = "Ошибка при поиске пользователей",
                Details = "Произошла внутренняя ошибка сервера"
            });
        }
    }

    /// <summary>
    /// Поиск клиентов по Client ID
    /// </summary>
    /// <param name="query">Поисковый запрос (минимум 2 символа)</param>
    /// <param name="realm">Реалм для поиска (опционально, если не указан, поиск выполняется во всех реалмах)</param>
    /// <param name="page">Номер страницы (начинается с 1, по умолчанию 1)</param>
    /// <param name="pageSize">Размер страницы (по умолчанию из настроек, максимум из настроек)</param>
    /// <returns>Список найденных клиентов</returns>
    /// <response code="200">Успешный поиск</response>
    /// <response code="400">Некорректные параметры запроса</response>
    /// <response code="401">Не авторизован</response>
    /// <response code="403">Недостаточно прав</response>
    /// <response code="502">Ошибка взаимодействия с Keycloak</response>
    /// <response code="500">Внутренняя ошибка сервера</response>
    /// <example>
    /// GET /api/ClientAccess/search-clients?query=app&realm=internal-bank-idm&page=1&pageSize=50
    /// </example>
    [HttpGet("search-clients")]
    public async Task<IActionResult> SearchClients(
        [FromQuery] string query, 
        [FromQuery] string? realm = null,
        [FromQuery, Range(1, int.MaxValue)] int page = 1,
        [FromQuery, Range(1, 100)] int pageSize = 0)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            // Валидация минимальной длины запроса
            if (string.IsNullOrWhiteSpace(query) || query.Length < _settings.MinSearchQueryLength)
            {
                return Ok(new PagedResponse<ClientSearchResult>
                {
                    Items = Array.Empty<ClientSearchResult>(),
                    Page = page,
                    PageSize = pageSize > 0 ? pageSize : _settings.DefaultPageSize,
                    TotalCount = 0
                });
            }

            // Нормализация параметров пагинации
            var normalizedPageSize = pageSize > 0 
                ? Math.Min(pageSize, _settings.MaxPageSize) 
                : _settings.DefaultPageSize;

            var clients = await _keycloakService.SearchClientsByIdAsync(query, realm);
            
            // Применяем пагинацию на стороне контроллера (если сервис не поддерживает)
            var totalCount = clients.Count;
            var paginatedClients = clients
                .Skip((page - 1) * normalizedPageSize)
                .Take(normalizedPageSize)
                .ToList();

            stopwatch.Stop();
            _logger.LogInformation(
                "SearchClients completed: Query={Query}, Realm={Realm}, Results={Count}, ElapsedMs={ElapsedMs}",
                query, realm ?? "all", totalCount, stopwatch.ElapsedMilliseconds);

            return Ok(new PagedResponse<ClientSearchResult>
            {
                Items = paginatedClients,
                Page = page,
                PageSize = normalizedPageSize,
                TotalCount = totalCount
            });
        }
        catch (HttpRequestException ex)
        {
            stopwatch.Stop();
            _logger.LogWarning(ex, 
                "Keycloak communication error during client search: Query={Query}, Realm={Realm}, ElapsedMs={ElapsedMs}",
                query, realm ?? "all", stopwatch.ElapsedMilliseconds);
            return StatusCode((int)HttpStatusCode.BadGateway, new ApiErrorResponse
            {
                Error = "Ошибка взаимодействия с Keycloak",
                Details = "Не удалось выполнить запрос к сервису Keycloak"
            });
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, 
                "Unexpected error during client search: Query={Query}, Realm={Realm}, ElapsedMs={ElapsedMs}",
                query, realm ?? "all", stopwatch.ElapsedMilliseconds);
            return StatusCode(500, new ApiErrorResponse
            {
                Error = "Ошибка при поиске клиентов",
                Details = "Произошла внутренняя ошибка сервера"
            });
        }
    }

    /// <summary>
    /// Получить список клиентов, назначенных пользователю
    /// </summary>
    /// <param name="username">Имя пользователя</param>
    /// <returns>Список клиентов пользователя</returns>
    /// <response code="200">Успешное получение списка клиентов</response>
    /// <response code="400">Некорректный username</response>
    /// <response code="401">Не авторизован</response>
    /// <response code="403">Недостаточно прав</response>
    /// <response code="500">Внутренняя ошибка сервера</response>
    /// <example>
    /// GET /api/ClientAccess/user-clients/john.doe
    /// </example>
    [HttpGet("user-clients/{username}")]
    public async Task<IActionResult> GetUserClients([FromRoute] string username)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            if (string.IsNullOrWhiteSpace(username))
            {
                return BadRequest(new ApiErrorResponse
                {
                    Error = "Username обязателен",
                    Details = "Параметр username не может быть пустым"
                });
            }

            var userClients = await _ownershipService.GetAllUserClientsAsync(username);
            
            stopwatch.Stop();
            _logger.LogInformation(
                "GetUserClients completed: Username={Username}, ClientsCount={Count}, ElapsedMs={ElapsedMs}",
                username, userClients.Count, stopwatch.ElapsedMilliseconds);

            return Ok(userClients);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, 
                "Error getting user clients: Username={Username}, ElapsedMs={ElapsedMs}",
                username, stopwatch.ElapsedMilliseconds);
            return StatusCode(500, new ApiErrorResponse
            {
                Error = "Ошибка при получении клиентов пользователя",
                Details = "Произошла внутренняя ошибка сервера"
            });
        }
    }

    /// <summary>
    /// Назначить клиента пользователю
    /// </summary>
    /// <param name="request">Запрос на назначение клиента</param>
    /// <returns>Результат операции назначения</returns>
    /// <response code="200">Доступ успешно назначен</response>
    /// <response code="400">Некорректные данные запроса или клиент уже назначен</response>
    /// <response code="401">Не авторизован</response>
    /// <response code="403">Недостаточно прав</response>
    /// <response code="500">Внутренняя ошибка сервера</response>
    /// <example>
    /// POST /api/ClientAccess/assign
    /// {
    ///   "username": "john.doe",
    ///   "clientId": "app-client",
    ///   "realm": "internal-bank-idm"
    /// }
    /// </example>
    [HttpPost("assign")]
    public async Task<IActionResult> AssignClient([FromBody] AssignClientRequest request)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            // Валидация модели (автоматически через Data Annotations + ModelState)
            if (!ModelState.IsValid)
            {
                var errors = ModelState
                    .Where(x => x.Value?.Errors.Count > 0)
                    .SelectMany(x => x.Value!.Errors.Select(e => e.ErrorMessage))
                    .ToList();
                
                return BadRequest(new ApiErrorResponse
                {
                    Error = "Некорректные данные запроса",
                    Details = string.Join("; ", errors)
                });
            }

            // Проверяем, не назначен ли клиент уже этому пользователю
            var existingClients = await _ownershipService.GetUserClientsAsync(request.Username, request.Realm);
            if (existingClients.Contains(request.ClientId))
            {
                return BadRequest(new ApiErrorResponse
                {
                    Error = "Клиент уже назначен данному пользователю",
                    Details = $"Клиент {request.ClientId} уже назначен пользователю {request.Username} в реалме {request.Realm}"
                });
            }

            // Назначаем доступ
            await _ownershipService.GrantAccessAsync(request.Username, request.ClientId, request.Realm);

            stopwatch.Stop();
            _logger.LogWarning(
                "Access granted: ClientId={ClientId}, Username={Username}, Realm={Realm}, ElapsedMs={ElapsedMs}",
                request.ClientId, request.Username, request.Realm, stopwatch.ElapsedMilliseconds);

            return Ok(new ApiSuccessResponse
            {
                Success = true,
                Message = "Доступ успешно назначен"
            });
        }
        catch (ArgumentException ex)
        {
            stopwatch.Stop();
            _logger.LogWarning(ex, 
                "Invalid argument during client assignment: ClientId={ClientId}, Username={Username}, Realm={Realm}",
                request.ClientId, request.Username, request.Realm);
            return BadRequest(new ApiErrorResponse
            {
                Error = "Некорректные параметры запроса",
                Details = ex.Message
            });
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, 
                "Error assigning client: ClientId={ClientId}, Username={Username}, Realm={Realm}, ElapsedMs={ElapsedMs}",
                request.ClientId, request.Username, request.Realm, stopwatch.ElapsedMilliseconds);
            return StatusCode(500, new ApiErrorResponse
            {
                Error = "Ошибка при назначении доступа",
                Details = "Произошла внутренняя ошибка сервера"
            });
        }
    }

    /// <summary>
    /// Удалить доступ пользователя к клиенту
    /// </summary>
    /// <param name="username">Имя пользователя</param>
    /// <param name="clientId">Идентификатор клиента</param>
    /// <param name="realm">Реалм</param>
    /// <returns>Результат операции удаления доступа</returns>
    /// <response code="200">Доступ успешно удалён</response>
    /// <response code="400">Некорректные параметры запроса</response>
    /// <response code="401">Не авторизован</response>
    /// <response code="403">Недостаточно прав</response>
    /// <response code="500">Внутренняя ошибка сервера</response>
    /// <example>
    /// DELETE /api/ClientAccess/revoke?username=john.doe&clientId=app-client&realm=internal-bank-idm
    /// </example>
    [HttpDelete("revoke")]
    public async Task<IActionResult> RevokeAccess(
        [FromQuery, Required(ErrorMessage = "Username обязателен")] string username,
        [FromQuery, Required(ErrorMessage = "ClientId обязателен")] string clientId,
        [FromQuery, Required(ErrorMessage = "Realm обязателен")] string realm)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            // Валидация параметров
            if (string.IsNullOrWhiteSpace(username) || 
                string.IsNullOrWhiteSpace(clientId) || 
                string.IsNullOrWhiteSpace(realm))
            {
                return BadRequest(new ApiErrorResponse
                {
                    Error = "Все параметры обязательны",
                    Details = "Username, ClientId и Realm должны быть указаны"
                });
            }

            await _ownershipService.RevokeAccessAsync(username, clientId, realm);

            stopwatch.Stop();
            _logger.LogWarning(
                "Access revoked: ClientId={ClientId}, Username={Username}, Realm={Realm}, ElapsedMs={ElapsedMs}",
                clientId, username, realm, stopwatch.ElapsedMilliseconds);

            return Ok(new ApiSuccessResponse
            {
                Success = true,
                Message = "Доступ успешно удалён"
            });
        }
        catch (ArgumentException ex)
        {
            stopwatch.Stop();
            _logger.LogWarning(ex, 
                "Invalid argument during access revocation: ClientId={ClientId}, Username={Username}, Realm={Realm}",
                clientId, username, realm);
            return BadRequest(new ApiErrorResponse
            {
                Error = "Некорректные параметры запроса",
                Details = ex.Message
            });
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, 
                "Error revoking access: ClientId={ClientId}, Username={Username}, Realm={Realm}, ElapsedMs={ElapsedMs}",
                clientId, username, realm, stopwatch.ElapsedMilliseconds);
            return StatusCode(500, new ApiErrorResponse
            {
                Error = "Ошибка при удалении доступа",
                Details = "Произошла внутренняя ошибка сервера"
            });
        }
    }
}
