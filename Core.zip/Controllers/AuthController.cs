using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using System.Security.Claims;
using new_assistant.Core.Constants;

namespace new_assistant.Controllers;

/// <summary>
/// Контроллер для обработки авторизации через Keycloak.
/// </summary>
[ApiController]
[Route("api/[controller]")]
[EnableRateLimiting("auth")]
public class AuthController : ControllerBase
{
    private const string CookieScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    private const string OidcScheme = OpenIdConnectDefaults.AuthenticationScheme;
    
    private readonly ILogger<AuthController> _logger;

    /// <summary>
    /// Инициализирует новый экземпляр класса AuthController.
    /// </summary>
    /// <param name="logger">Логгер для записи событий</param>
    public AuthController(ILogger<AuthController> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Инициирует авторизацию через Keycloak.
    /// </summary>
    /// <param name="returnUrl">URL для перенаправления после успешной авторизации. Должен быть локальным URL.</param>
    /// <returns>Результат авторизации (редирект на Keycloak)</returns>
    /// <response code="302">Перенаправление на страницу авторизации Keycloak</response>
    /// <remarks>
    /// Если пользователь уже авторизован, будет перенаправлен на returnUrl или главную страницу.
    /// ReturnUrl валидируется на предмет открытых редиректов.
    /// </remarks>
    [HttpGet("login")]
    public IActionResult Login(string? returnUrl = null)
    {
        // Если пользователь уже авторизован, перенаправляем
        if (User.Identity?.IsAuthenticated == true)
        {
            _logger.LogInformation("Пользователь {Username} уже авторизован, перенаправление", User.Identity.Name);
            
            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return Redirect("/");
        }

        // Валидация returnUrl для предотвращения open redirect атак
        if (!string.IsNullOrEmpty(returnUrl) && !Url.IsLocalUrl(returnUrl))
        {
            _logger.LogWarning("Попытка открытого редиректа на внешний URL: {ReturnUrl}", returnUrl);
            returnUrl = null; // Игнорируем внешние URL
        }

        _logger.LogInformation("Попытка входа пользователя. ReturnUrl: {ReturnUrl}", returnUrl);
        
        var properties = new AuthenticationProperties
        {
            RedirectUri = returnUrl ?? "/"
        };
        
        return Challenge(properties, OidcScheme);
    }
    
    /// <summary>
    /// Выход из системы с возможностью выхода из Keycloak.
    /// </summary>
    /// <param name="logoutFromKeycloak">Если true, выполняется выход из Keycloak и из приложения. Если false, выход только из приложения.</param>
    /// <returns>Результат выхода</returns>
    [HttpGet("logout")]
    public async Task<IActionResult> Logout([FromQuery] bool logoutFromKeycloak = true)
    {
        var username = User.Identity?.Name ?? "Unknown";
        _logger.LogInformation(
            "Попытка выхода пользователя {Username}. LogoutFromKeycloak: {LogoutFromKeycloak}", 
            username, 
            logoutFromKeycloak);

        if (logoutFromKeycloak)
        {
            // Выход из Keycloak и из приложения
            return SignOut(new AuthenticationProperties
            {
                RedirectUri = "/"
            }, CookieScheme, OidcScheme);
        }
        else
        {
            // Выход только из приложения
            await HttpContext.SignOutAsync(CookieScheme);
            return Redirect("/");
        }
    }

    /// <summary>
    /// Обработка ошибок аутентификации - доступ запрещен.
    /// </summary>
    /// <param name="returnUrl">URL для перенаправления после обработки ошибки</param>
    /// <returns>Результат обработки ошибки</returns>
    [HttpGet("access-denied")]
    public IActionResult AccessDenied(string? returnUrl = null)
    {
        var username = User.Identity?.Name ?? "Unknown";
        _logger.LogWarning("Доступ запрещен для пользователя {Username}. ReturnUrl: {ReturnUrl}", username, returnUrl);
        return Redirect("/AccessDenied");
    }

    /// <summary>
    /// Обработка ошибок входа.
    /// </summary>
    /// <param name="error">Описание ошибки</param>
    /// <returns>Результат обработки ошибки</returns>
    [HttpGet("login-failed")]
    public IActionResult LoginFailed(string? error = null)
    {
        _logger.LogWarning("Ошибка входа: {Error}", error);
        return BadRequest(new { error = error ?? "Ошибка при входе в систему" });
    }

    /// <summary>
    /// Получить информацию о текущем аутентифицированном пользователе.
    /// </summary>
    /// <returns>Информация о текущем пользователе</returns>
    /// <response code="200">Информация о пользователе успешно получена</response>
    /// <response code="401">Пользователь не аутентифицирован</response>
    [HttpGet("me")]
    [Authorize]
    public IActionResult GetCurrentUser()
    {
        var userInfo = new
        {
            Username = User.Identity?.Name,
            IsAuthenticated = User.Identity?.IsAuthenticated ?? false,
            AuthenticationType = User.Identity?.AuthenticationType,
            Claims = User.Claims.Select(c => new { c.Type, c.Value }).ToList(),
            Roles = User.Claims
                .Where(c => c.Type == ClaimTypes.Role || c.Type == "role")
                .Select(c => c.Value)
                .ToList()
        };

        _logger.LogDebug("Запрос информации о текущем пользователе: {Username}", User.Identity?.Name);
        return Ok(userInfo);
    }

    /// <summary>
    /// Проверить статус аутентификации.
    /// </summary>
    /// <returns>Статус аутентификации</returns>
    /// <response code="200">Статус аутентификации успешно получен</response>
    [HttpGet("status")]
    public IActionResult GetAuthStatus()
    {
        var status = new
        {
            IsAuthenticated = User.Identity?.IsAuthenticated ?? false,
            Username = User.Identity?.Name,
            AuthenticationType = User.Identity?.AuthenticationType
        };

        return Ok(status);
    }
}
