using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Hosting;

namespace new_assistant.Controllers;

/// <summary>
/// Контроллер для проверки здоровья системы.
/// <remarks>
/// Этот контроллер доступен без авторизации для использования системами мониторинга.
/// Не содержит чувствительной информации.
/// </remarks>
/// </summary>
[ApiController]
[Route("api/[controller]")]
[EnableRateLimiting("health")]
public class HealthController : ControllerBase
{
    private readonly HealthCheckService _healthCheckService;
    private readonly IHostEnvironment _environment;
    private readonly ILogger<HealthController> _logger;

    public HealthController(
        HealthCheckService healthCheckService,
        IHostEnvironment environment,
        ILogger<HealthController> logger)
    {
        _healthCheckService = healthCheckService ?? throw new ArgumentNullException(nameof(healthCheckService));
        _environment = environment ?? throw new ArgumentNullException(nameof(environment));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Получить состояние здоровья всех компонентов системы
    /// </summary>
    /// <returns>Отчет о состоянии здоровья системы</returns>
    /// <response code="200">Система здорова или деградирована (Degraded)</response>
    /// <response code="503">Система нездорова (Unhealthy)</response>
    /// <remarks>
    /// Этот endpoint используется системами мониторинга для проверки состояния приложения.
    /// Возвращает детальную информацию о состоянии каждого компонента системы.
    /// </remarks>
    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var stopwatch = Stopwatch.StartNew();
        
        try
        {
            var report = await _healthCheckService.CheckHealthAsync();
            stopwatch.Stop();

            var unhealthyCount = report.Entries.Count(e => e.Value.Status != HealthStatus.Healthy);
            
            if (report.Status != HealthStatus.Healthy)
            {
                _logger.LogWarning(
                    "Health check completed with status {Status}. Unhealthy checks: {UnhealthyCount}",
                    report.Status,
                    unhealthyCount);
            }

            _logger.LogInformation(
                "Health check completed in {ElapsedMs}ms with status {Status}. Total checks: {TotalCount}",
                stopwatch.ElapsedMilliseconds,
                report.Status,
                report.Entries.Count);
            
            var result = new
            {
                Status = report.Status.ToString(),
                TotalDurationMs = report.TotalDuration.TotalMilliseconds,
                TotalDuration = $"{report.TotalDuration.TotalMilliseconds:F2}ms",
                Timestamp = DateTime.UtcNow,
                Application = "KeyCloak Assistant API",
                Checks = report.Entries.Select(entry => new
                {
                    Name = entry.Key,
                    Status = entry.Value.Status.ToString(),
                    DurationMs = entry.Value.Duration.TotalMilliseconds,
                    Duration = $"{entry.Value.Duration.TotalMilliseconds:F2}ms",
                    Description = entry.Value.Description,
                    Data = entry.Value.Data,
                    Exception = _environment.IsDevelopment() 
                        ? entry.Value.Exception?.Message 
                        : entry.Value.Exception != null 
                            ? "Произошла ошибка при проверке здоровья компонента" 
                            : null,
                    Tags = entry.Value.Tags
                })
            };

            var statusCode = report.Status == HealthStatus.Healthy ? 200 :
                            report.Status == HealthStatus.Degraded ? 200 : 503;

            return StatusCode(statusCode, result);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "Ошибка при проверке здоровья системы");
            
            // Если сам health check упал, возвращаем 503
            return StatusCode(503, new
            {
                Status = "Unhealthy",
                Timestamp = DateTime.UtcNow,
                Application = "KeyCloak Assistant API",
                Error = _environment.IsDevelopment() ? ex.Message : "Ошибка при проверке здоровья системы"
            });
        }
    }

    /// <summary>
    /// Получить состояние конкретного компонента
    /// </summary>
    /// <param name="checkName">Имя health check компонента</param>
    /// <returns>Отчет о состоянии конкретного компонента</returns>
    /// <response code="200">Компонент здоров или деградирован (Degraded)</response>
    /// <response code="400">Имя health check не указано</response>
    /// <response code="404">Health check с указанным именем не найден</response>
    /// <response code="503">Компонент нездоров (Unhealthy)</response>
    /// <remarks>
    /// Этот endpoint позволяет получить детальную информацию о состоянии конкретного компонента системы.
    /// </remarks>
    [HttpGet("{checkName}")]
    public async Task<IActionResult> GetByName(string checkName)
    {
        if (string.IsNullOrWhiteSpace(checkName))
        {
            _logger.LogWarning("Попытка получить health check без указания имени");
            return BadRequest(new { Error = "Имя health check не может быть пустым" });
        }

        var stopwatch = Stopwatch.StartNew();
        
        try
        {
            var report = await _healthCheckService.CheckHealthAsync(check => check.Name == checkName);
            stopwatch.Stop();
            
            if (!report.Entries.Any())
            {
                _logger.LogWarning("Health check '{CheckName}' not found", checkName);
                return NotFound(new { Error = $"Health check '{checkName}' not found" });
            }

            var entry = report.Entries.First();
            
            if (entry.Value.Status != HealthStatus.Healthy)
            {
                _logger.LogWarning(
                    "Health check '{CheckName}' completed with status {Status}",
                    checkName,
                    entry.Value.Status);
            }

            _logger.LogInformation(
                "Health check '{CheckName}' completed in {ElapsedMs}ms with status {Status}",
                checkName,
                stopwatch.ElapsedMilliseconds,
                entry.Value.Status);

            var result = new
            {
                Name = entry.Key,
                Status = entry.Value.Status.ToString(),
                DurationMs = entry.Value.Duration.TotalMilliseconds,
                Duration = $"{entry.Value.Duration.TotalMilliseconds:F2}ms",
                Description = entry.Value.Description,
                Data = entry.Value.Data,
                Exception = _environment.IsDevelopment() 
                    ? entry.Value.Exception?.Message 
                    : entry.Value.Exception != null 
                        ? "Произошла ошибка при проверке здоровья компонента" 
                        : null,
                Tags = entry.Value.Tags,
                Timestamp = DateTime.UtcNow
            };

            var statusCode = entry.Value.Status == HealthStatus.Healthy ? 200 :
                            entry.Value.Status == HealthStatus.Degraded ? 200 : 503;

            return StatusCode(statusCode, result);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "Ошибка при проверке здоровья компонента '{CheckName}'", checkName);
            
            return StatusCode(503, new
            {
                Status = "Unhealthy",
                Name = checkName,
                Timestamp = DateTime.UtcNow,
                Application = "KeyCloak Assistant API",
                Error = _environment.IsDevelopment() ? ex.Message : "Ошибка при проверке здоровья компонента"
            });
        }
    }
}
