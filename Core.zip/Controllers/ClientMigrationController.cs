using System.Diagnostics;
using System.Net.Http;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using new_assistant.Core.Constants;
using new_assistant.Core.DTOs;
using new_assistant.Core.Exceptions;
using new_assistant.Core.Interfaces;
using System.Security.Claims;

namespace new_assistant.Controllers;

/// <summary>
/// API контроллер для переноса клиентов из TEST в STAGE реалм Keycloak
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = Roles.Admin)]
[EnableRateLimiting("admin")]
public class ClientMigrationController : ControllerBase
{
    private readonly IClientMigrationService _migrationService;
    private readonly ILogger<ClientMigrationController> _logger;

    /// <summary>
    /// Инициализирует новый экземпляр <see cref="ClientMigrationController"/>
    /// </summary>
    /// <param name="migrationService">Сервис для выполнения миграции клиентов</param>
    /// <param name="logger">Логгер для записи событий</param>
    /// <exception cref="ArgumentNullException">Выбрасывается, если один из параметров равен null</exception>
    public ClientMigrationController(
        IClientMigrationService migrationService,
        ILogger<ClientMigrationController> logger)
    {
        _migrationService = migrationService ?? throw new ArgumentNullException(nameof(migrationService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Имя текущего пользователя из claims
    /// </summary>
    private string CurrentUsername => User.FindFirstValue(ClaimTypes.Name) ?? "Unknown";

    /// <summary>
    /// Валидация возможности переноса клиента из TEST в STAGE реалм
    /// </summary>
    /// <param name="request">Данные для валидации переноса</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Результат валидации с детальной информацией о готовности к миграции</returns>
    /// <response code="200">Валидация выполнена успешно</response>
    /// <response code="400">Некорректные входные данные</response>
    /// <response code="403">Недостаточно прав доступа</response>
    /// <response code="500">Внутренняя ошибка сервера</response>
    /// <response code="502">Ошибка взаимодействия с Keycloak</response>
    /// <response code="504">Превышено время ожидания</response>
    /// <remarks>
    /// Валидация проверяет:
    /// - Существование клиента в исходном реалме
    /// - Отсутствие конфликтов в целевом реалме
    /// - Наличие всех необходимых ролей и скоупов
    /// - Готовность к переносу
    /// </remarks>
    [HttpPost("validate")]
    [ProducesResponseType(typeof(MigrationValidationResult), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [ProducesResponseType(StatusCodes.Status502BadGateway)]
    [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
    public async Task<IActionResult> ValidateMigration(
        [FromBody] ClientMigrationRequest request,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        
        try
        {
            cancellationToken.ThrowIfCancellationRequested();

            if (request == null)
            {
                _logger.LogWarning(
                    "Попытка валидации миграции с null запросом от пользователя {Username}",
                    CurrentUsername);
                return BadRequest(new { error = "Запрос не может быть пустым" });
            }

            if (!ModelState.IsValid)
            {
                _logger.LogWarning(
                    "Попытка валидации миграции с невалидными данными от пользователя {Username}. Ошибки: {Errors}",
                    CurrentUsername,
                    string.Join("; ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage)));
                return BadRequest(ModelState);
            }

            _logger.LogInformation(
                "Начало валидации миграции клиента {ClientId} из {SourceRealm} в {TargetRealm} пользователем {Username}",
                request.ClientId,
                request.SourceRealm,
                request.TargetRealm,
                CurrentUsername);

            var result = await _migrationService.ValidateMigrationAsync(request, cancellationToken);

            stopwatch.Stop();

            _logger.LogInformation(
                "Валидация миграции клиента {ClientId} завершена за {ElapsedMs}ms пользователем {Username}. Результат: {CanMigrate}",
                request.ClientId,
                stopwatch.ElapsedMilliseconds,
                CurrentUsername,
                result.CanMigrate);

            return Ok(new
            {
                canMigrate = result.CanMigrate,
                clientExistsInTarget = result.ClientExistsInTarget,
                missingRealmRoles = result.MissingRealmRoles,
                missingClientRoles = result.MissingClientRoles,
                missingClientScopes = result.MissingClientScopes,
                warningCount = result.WarningCount,
                messages = result.Messages,
                existingWikiPageUrl = result.ExistingWikiPageUrl
            });
        }
        catch (OperationCanceledException)
        {
            if (stopwatch.IsRunning)
                stopwatch.Stop();
                
            _logger.LogInformation(
                "Валидация миграции клиента {ClientId} отменена пользователем {Username}",
                request?.ClientId ?? "unknown",
                CurrentUsername);
            return StatusCode(499, new { error = "Операция отменена" });
        }
        catch (ArgumentNullException ex)
        {
            if (stopwatch.IsRunning)
                stopwatch.Stop();
                
            _logger.LogWarning(
                ex,
                "Некорректные входные данные для валидации миграции клиента {ClientId} от пользователя {Username}",
                request?.ClientId ?? "unknown",
                CurrentUsername);
            return BadRequest(new { error = ex.Message });
        }
        catch (ArgumentException ex)
        {
            if (stopwatch.IsRunning)
                stopwatch.Stop();
                
            _logger.LogWarning(
                ex,
                "Ошибка валидации входных данных для миграции клиента {ClientId} от пользователя {Username}: {Message}",
                request?.ClientId ?? "unknown",
                CurrentUsername,
                ex.Message);
            return BadRequest(new { error = ex.Message });
        }
        catch (TokenExchangeException ex)
        {
            if (stopwatch.IsRunning)
                stopwatch.Stop();
                
            _logger.LogError(
                ex,
                "Ошибка взаимодействия с Keycloak при валидации миграции клиента {ClientId} в реалме {Realm} от пользователя {Username}",
                request?.ClientId ?? "unknown",
                ex.Realm ?? "unknown",
                CurrentUsername);
            return StatusCode(502, new { error = "Ошибка взаимодействия с Keycloak" });
        }
        catch (HttpRequestException ex)
        {
            if (stopwatch.IsRunning)
                stopwatch.Stop();
                
            _logger.LogError(
                ex,
                "Сетевая ошибка при валидации миграции клиента {ClientId} от пользователя {Username}",
                request?.ClientId ?? "unknown",
                CurrentUsername);
            return StatusCode(502, new { error = "Ошибка взаимодействия с внешним сервисом" });
        }
        catch (TimeoutException ex)
        {
            if (stopwatch.IsRunning)
                stopwatch.Stop();
                
            _logger.LogError(
                ex,
                "Таймаут при валидации миграции клиента {ClientId} от пользователя {Username}",
                request?.ClientId ?? "unknown",
                CurrentUsername);
            return StatusCode(504, new { error = "Превышено время ожидания" });
        }
        catch (Exception ex)
        {
            if (stopwatch.IsRunning)
                stopwatch.Stop();
                
            _logger.LogError(
                ex,
                "Ошибка валидации миграции для клиента {ClientId} от пользователя {Username}",
                request?.ClientId ?? "unknown",
                CurrentUsername);
            return StatusCode(500, new { error = "Внутренняя ошибка сервера при валидации" });
        }
    }

    /// <summary>
    /// Выполнить перенос клиента из TEST в STAGE реалм
    /// </summary>
    /// <param name="request">Данные для переноса</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Результат переноса с детальной информацией</returns>
    /// <response code="200">Миграция выполнена успешно</response>
    /// <response code="400">Некорректные входные данные или миграция невозможна</response>
    /// <response code="403">Недостаточно прав доступа</response>
    /// <response code="500">Внутренняя ошибка сервера</response>
    /// <response code="502">Ошибка взаимодействия с Keycloak</response>
    /// <response code="504">Превышено время ожидания</response>
    /// <remarks>
    /// Перед миграцией автоматически выполняется валидация. 
    /// Миграция возможна только если валидация прошла успешно.
    /// </remarks>
    [HttpPost("migrate")]
    [ProducesResponseType(typeof(ClientMigrationResult), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [ProducesResponseType(StatusCodes.Status502BadGateway)]
    [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
    public async Task<IActionResult> MigrateClient(
        [FromBody] ClientMigrationRequest request,
        CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        
        try
        {
            cancellationToken.ThrowIfCancellationRequested();

            if (request == null)
            {
                _logger.LogWarning(
                    "Попытка миграции с null запросом от пользователя {Username}",
                    CurrentUsername);
                return BadRequest(new { error = "Запрос не может быть пустым" });
            }

            if (!ModelState.IsValid)
            {
                _logger.LogWarning(
                    "Попытка миграции с невалидными данными от пользователя {Username}. Ошибки: {Errors}",
                    CurrentUsername,
                    string.Join("; ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage)));
                return BadRequest(ModelState);
            }

            _logger.LogInformation(
                "Начало миграции клиента {ClientId} из {SourceRealm} в {TargetRealm} пользователем {Username}",
                request.ClientId,
                request.SourceRealm,
                request.TargetRealm,
                CurrentUsername);

            // Валидация перед миграцией (обязательно!)
            var validationResult = await _migrationService.ValidateMigrationAsync(request, cancellationToken);
            
            if (!validationResult.CanMigrate)
            {
                stopwatch.Stop();
                _logger.LogWarning(
                    "Миграция клиента {ClientId} невозможна из-за ошибок валидации от пользователя {Username}. Сообщения: {Messages}",
                    request.ClientId,
                    CurrentUsername,
                    string.Join("; ", validationResult.Messages));
                    
                return BadRequest(new 
                { 
                    error = "Миграция невозможна",
                    messages = validationResult.Messages
                });
            }

            // Выполняем миграцию
            var result = await _migrationService.MigrateClientAsync(request, CurrentUsername, cancellationToken);

            stopwatch.Stop();

            if (!result.Success)
            {
                _logger.LogWarning(
                    "Миграция клиента {ClientId} завершилась с ошибками от пользователя {Username} за {ElapsedMs}ms. Ошибки: {Errors}",
                    request.ClientId,
                    CurrentUsername,
                    stopwatch.ElapsedMilliseconds,
                    string.Join("; ", result.Errors));
                    
                return BadRequest(new
                {
                    success = false,
                    errors = result.Errors,
                    warnings = result.Warnings
                });
            }

            _logger.LogInformation(
                "Миграция клиента {ClientId} успешно завершена пользователем {Username} за {ElapsedMs}ms",
                request.ClientId,
                CurrentUsername,
                stopwatch.ElapsedMilliseconds);

            return Ok(new
            {
                success = result.Success,
                clientId = result.ClientId,
                newClientSecret = result.NewClientSecret,
                newInternalId = result.NewInternalId,
                archivePassword = result.ArchivePassword,
                redirectUris = result.RedirectUris,
                wikiPageUrl = result.WikiPageUrl,
                localRolesMigrated = result.LocalRolesMigrated,
                serviceRolesMigrated = result.ServiceRolesMigrated,
                warnings = result.Warnings,
                errors = result.Errors
            });
        }
        catch (OperationCanceledException)
        {
            if (stopwatch.IsRunning)
                stopwatch.Stop();
                
            _logger.LogInformation(
                "Миграция клиента {ClientId} отменена пользователем {Username}",
                request?.ClientId ?? "unknown",
                CurrentUsername);
            return StatusCode(499, new { error = "Операция отменена" });
        }
        catch (ArgumentNullException ex)
        {
            if (stopwatch.IsRunning)
                stopwatch.Stop();
                
            _logger.LogWarning(
                ex,
                "Некорректные входные данные для миграции клиента {ClientId} от пользователя {Username}",
                request?.ClientId ?? "unknown",
                CurrentUsername);
            return BadRequest(new { error = ex.Message });
        }
        catch (ArgumentException ex)
        {
            if (stopwatch.IsRunning)
                stopwatch.Stop();
                
            _logger.LogWarning(
                ex,
                "Ошибка валидации входных данных для миграции клиента {ClientId} от пользователя {Username}: {Message}",
                request?.ClientId ?? "unknown",
                CurrentUsername,
                ex.Message);
            return BadRequest(new { error = ex.Message });
        }
        catch (TokenExchangeException ex)
        {
            if (stopwatch.IsRunning)
                stopwatch.Stop();
                
            _logger.LogError(
                ex,
                "Ошибка взаимодействия с Keycloak при миграции клиента {ClientId} в реалме {Realm} от пользователя {Username}",
                request?.ClientId ?? "unknown",
                ex.Realm ?? "unknown",
                CurrentUsername);
            return StatusCode(502, new { error = "Ошибка взаимодействия с Keycloak" });
        }
        catch (HttpRequestException ex)
        {
            if (stopwatch.IsRunning)
                stopwatch.Stop();
                
            _logger.LogError(
                ex,
                "Сетевая ошибка при миграции клиента {ClientId} от пользователя {Username}",
                request?.ClientId ?? "unknown",
                CurrentUsername);
            return StatusCode(502, new { error = "Ошибка взаимодействия с внешним сервисом" });
        }
        catch (TimeoutException ex)
        {
            if (stopwatch.IsRunning)
                stopwatch.Stop();
                
            _logger.LogError(
                ex,
                "Таймаут при миграции клиента {ClientId} от пользователя {Username}",
                request?.ClientId ?? "unknown",
                CurrentUsername);
            return StatusCode(504, new { error = "Превышено время ожидания" });
        }
        catch (Exception ex)
        {
            if (stopwatch.IsRunning)
                stopwatch.Stop();
                
            _logger.LogError(
                ex,
                "Критическая ошибка миграции клиента {ClientId} от пользователя {Username}",
                request?.ClientId ?? "unknown",
                CurrentUsername);
            return StatusCode(500, new { error = "Внутренняя ошибка сервера при миграции" });
        }
    }
}
