using new_assistant.Core.DTOs;

namespace new_assistant.Pages.ClientMigration;

/// <summary>
/// ViewModel для управления состоянием компонента ClientMigration
/// Инкапсулирует все поля состояния для упрощения управления и валидации
/// </summary>
public class ClientMigrationViewModel
{
    // Состояние поиска клиентов
    public string SearchQuery { get; set; } = string.Empty;
    public List<ClientSearchResult> SearchResults { get; set; } = new();
    public ClientSearchResult? SelectedClient { get; set; }
    public bool IsSearching { get; set; }
    public bool HasSearched { get; set; }

    // Состояние выбора целевого realm
    public List<string> StageRealms { get; set; } = new();
    public string SelectedTargetRealm { get; set; } = string.Empty;
    public bool IsLoadingStageRealms { get; set; }
    public bool StageRealmsLoaded { get; set; }

    // Состояние валидации
    public MigrationValidationResult? ValidationResult { get; set; }
    public bool IsValidating { get; set; }

    // Дополнительная информация для миграции
    public string TicketNumber { get; set; } = string.Empty;
    public string NotificationEmail { get; set; } = string.Empty;
    public string TicketUrl { get; set; } = string.Empty;
    public string WikiPageUrl { get; set; } = string.Empty;

    // Состояние миграции
    public bool IsMigrating { get; set; }
    public ClientMigrationResult? MigrationResult { get; set; }
    public bool ShowMigrationResultModal { get; set; }
    public bool IsClosingModal { get; set; }

    /// <summary>
    /// Валидация шага 1: выбор клиента
    /// </summary>
    public bool ValidateStep1()
    {
        return !string.IsNullOrWhiteSpace(SearchQuery) && SearchQuery.Length >= 2;
    }

    /// <summary>
    /// Валидация шага 2: выбор целевого реалма
    /// </summary>
    public bool ValidateStep2()
    {
        return SelectedClient != null && !string.IsNullOrWhiteSpace(SelectedTargetRealm);
    }

    /// <summary>
    /// Валидация шага 3: готовность к миграции
    /// </summary>
    public bool ValidateStep3()
    {
        return ValidationResult?.CanMigrate == true;
    }

    /// <summary>
    /// Сброс состояния после успешной миграции
    /// </summary>
    public void ResetAfterSuccessfulMigration()
    {
        ValidationResult = null;
        TicketNumber = string.Empty;
        NotificationEmail = string.Empty;
        TicketUrl = string.Empty;
        
        if (MigrationResult?.Success == true && !string.IsNullOrWhiteSpace(MigrationResult.WikiPageUrl))
        {
            WikiPageUrl = MigrationResult.WikiPageUrl.Trim();
        }
    }

    /// <summary>
    /// Сброс состояния при выборе нового клиента
    /// </summary>
    public void ResetOnClientSelection()
    {
        SelectedTargetRealm = string.Empty;
        ValidationResult = null;
        MigrationResult = null;
        TicketNumber = string.Empty;
        NotificationEmail = string.Empty;
        TicketUrl = string.Empty;
        WikiPageUrl = string.Empty;
    }
}

