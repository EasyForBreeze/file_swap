using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.JSInterop;
using Microsoft.Extensions.Logging;
using new_assistant.Core.Constants;
using new_assistant.Core.DTOs;
using new_assistant.Core.Interfaces;
using new_assistant.Pages.ClientDetails.Components;

namespace new_assistant.Pages.ClientDetails;

/// <summary>
/// Code-behind для компонента ClientDetails
/// Содержит всю бизнес-логику компонента
/// </summary>
public partial class ClientDetails : IDisposable
{
    #region Injected Services

    [Inject] private IUserRoleService UserRoleService { get; set; } = null!;
    [Inject] private IKeycloakAdminService KeycloakAdminService { get; set; } = null!;
    [Inject] private NavigationManager Navigation { get; set; } = null!;
    [Inject] private IHttpContextAccessor HttpContextAccessor { get; set; } = null!;
    [Inject] private IJSRuntime JSRuntime { get; set; } = null!;
    [Inject] private IModalService ModalService { get; set; } = null!;
    [Inject] private INotificationService NotificationService { get; set; } = null!;
    [Inject] private IClientOwnershipService OwnershipService { get; set; } = null!;
    [Inject] private IAuditService AuditService { get; set; } = null!;
    [Inject] private IConfluenceService? ConfluenceService { get; set; }
    [Inject] private IForbiddenClientRepository ForbiddenRepo { get; set; } = null!;
    [Inject] private ISearchStateService SearchStateService { get; set; } = null!;
    [Inject] private ILogger<ClientDetails> Logger { get; set; } = null!;
    [Inject] private IValidationService ValidationService { get; set; } = null!;
    [Inject] private IClientEventsService ClientEventsService { get; set; } = null!;

    #endregion

    #region Parameters

    [Parameter] public string Realm { get; set; } = string.Empty;
    [Parameter] public string ClientId { get; set; } = string.Empty;

    #endregion

    #region ViewModel

    private ClientDetailsViewModel ViewModel { get; set; } = new();

    #endregion

    #region Private Fields

    private readonly SemaphoreSlim _loadSemaphore = new(1, 1);
    private CancellationTokenSource? _loadingCts;
    private CancellationTokenSource? _searchSpinnerCts;
    private Action<string>? _deleteConfirmedHandler;
    private bool _isSaving;

    #endregion

    #region Lifecycle Methods

    protected override Task OnInitializedAsync()
    {
        _deleteConfirmedHandler = async (clientName) => await HandleDeleteConfirmedAsync(clientName);
        ModalService.OnDeleteConfirmed += _deleteConfirmedHandler;
        return Task.CompletedTask;
    }

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (firstRender)
        {
            await LoadClientDetails();
        }
    }

    protected override async Task OnParametersSetAsync()
    {
        if (ViewModel.ClientDetails != null &&
            (ViewModel.ClientDetails.ClientId != ClientId || ViewModel.ClientDetails.Realm != Realm))
        {
            await LoadClientDetails();
        }
    }

    public void Dispose()
    {
        if (_deleteConfirmedHandler != null)
        {
            ModalService.OnDeleteConfirmed -= _deleteConfirmedHandler;
            _deleteConfirmedHandler = null;
        }
        
        // Отменяем операции перед освобождением
        _loadingCts?.Cancel();
        _searchSpinnerCts?.Cancel();
        
        // Освобождаем ресурсы
        _loadingCts?.Dispose();
        _searchSpinnerCts?.Dispose();
        _loadSemaphore?.Dispose();
    }

    #endregion

    #region Loading Methods

    private async Task ShowLoadingIndicatorWithDelay(CancellationToken cancellationToken)
    {
        try
        {
            await Task.Delay(ClientDetailsConstants.Ui.LoadingIndicatorDelay, cancellationToken).ConfigureAwait(false);
            ViewModel.ShowLoadingIndicator = true;
            await InvokeAsync(StateHasChanged);
        }
        catch (TaskCanceledException)
        {
            // Операция была отменена, ничего не делаем
        }
    }

    private async Task ShowSearchSpinnerWithDelay(CancellationToken cancellationToken)
    {
        try
        {
            await Task.Delay(ClientDetailsConstants.Ui.SearchSpinnerDelay, cancellationToken).ConfigureAwait(false);
            ViewModel.ShowSearchSpinner = true;
            await InvokeAsync(StateHasChanged);
        }
        catch (TaskCanceledException)
        {
            // Операция была отменена, ничего не делаем
        }
    }

    private async Task LoadClientDetails()
    {
        // Отменяем предыдущую операцию ДО получения семафора для предотвращения race condition
        _loadingCts?.Cancel();
        
        await _loadSemaphore.WaitAsync();
        try
        {
            if (ViewModel.IsLoadingInProgress)
            {
                Logger.LogWarning("LoadClientDetails already in progress, skipping for {ClientId}", ClientId);
                return;
            }

            ViewModel.IsLoadingInProgress = true;
            ViewModel.ShowLoadingIndicator = false;
            ViewModel.Error = null;

            // Освобождаем и создаем новый CTS внутри критической секции
            _loadingCts?.Dispose();
            _loadingCts = new CancellationTokenSource(TimeSpan.FromSeconds(ClientDetailsConstants.Timeouts.LoadClientDetails));

            // Показываем индикатор загрузки с задержкой
            _ = ShowLoadingIndicatorWithDelay(_loadingCts.Token);

            ViewModel.ClientDetails = await KeycloakAdminService.GetClientDetailsAsync(ClientId, Realm).ConfigureAwait(false);

            if (ViewModel.ClientDetails == null)
            {
                ViewModel.Error = "Не удалось загрузить данные клиента";
                try
                {
                    var username = UserRoleService.GetUserName();
                    var userClients = await OwnershipService.GetUserClientsAsync(username ?? "", Realm).ConfigureAwait(false);
                    if (userClients.Contains(ClientId))
                    {
                        Logger.LogWarning("Клиент {ClientId} не найден в Keycloak, но есть записи владения в SQLite. Очищаем записи владения.", ClientId);
                        await OwnershipService.RemoveAllClientOwnershipsAsync(ClientId, Realm).ConfigureAwait(false);
                        await AuditService.LogClientDeletedAsync(username ?? "", ClientId, Realm).ConfigureAwait(false);
                        ViewModel.Error = $"Клиент {ClientId} был удален из Keycloak. Записи владения очищены.";
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex, "Ошибка при очистке записей владения для несуществующего клиента {ClientId}", ClientId);
                }
            }

            if (UserRoleService.IsUser() && !UserRoleService.IsAdmin())
            {
                var username = UserRoleService.GetUserName();
                var userClients = await OwnershipService.GetUserClientsAsync(username ?? "", Realm).ConfigureAwait(false);
                if (!userClients.Contains(ClientId))
                {
                    ViewModel.Error = "У вас нет доступа к этому клиенту";
                    ViewModel.ClientDetails = null;
                }
            }

            // Создаем копии коллекций для сравнения изменений
            ViewModel.OriginalLocalRoles = ViewModel.ClientDetails?.LocalRoles != null
                ? new List<string>(ViewModel.ClientDetails.LocalRoles)
                : new List<string>();
            ViewModel.OriginalServiceRoles = ViewModel.ClientDetails?.ServiceRoles != null
                ? new List<string>(ViewModel.ClientDetails.ServiceRoles)
                : new List<string>();
            ViewModel.OriginalClientId = ViewModel.ClientDetails?.ClientId ?? "";

            if (ViewModel.ClientDetails != null)
            {
                ViewModel.OriginalClientDetails = new ClientDetailsDto
                {
                    ClientId = ViewModel.ClientDetails.ClientId,
                    Name = ViewModel.ClientDetails.Name,
                    Description = ViewModel.ClientDetails.Description,
                    Enabled = ViewModel.ClientDetails.Enabled,
                    ClientAuthentication = ViewModel.ClientDetails.ClientAuthentication,
                    StandardFlow = ViewModel.ClientDetails.StandardFlow,
                    ServiceAccountsEnabled = ViewModel.ClientDetails.ServiceAccountsEnabled,
                    RedirectUris = new List<string>(ViewModel.ClientDetails.RedirectUris),
                    LocalRoles = new List<string>(ViewModel.ClientDetails.LocalRoles),
                    ServiceRoles = new List<string>(ViewModel.ClientDetails.ServiceRoles)
                };
            }

            ViewModel.EventsViewModel.EventsLoaded = false;

            if (ConfluenceService != null && ViewModel.ClientDetails != null)
            {
                try
                {
                    ViewModel.WikiPageUrl = await ConfluenceService.GetWikiPageUrlAsync(
                        ViewModel.ClientDetails.ClientId,
                        ViewModel.ClientDetails.Realm).ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    Logger.LogWarning(ex, "Не удалось загрузить Wiki URL");
                }
            }
        }
        catch (Exception ex)
        {
            var (userMessage, _) = ClientDetailsErrorHandler.HandleError(
                ex,
                Logger,
                "загрузке данных клиента",
                $"ClientId: {ClientId}, Realm: {Realm}");
            ViewModel.Error = userMessage;
        }
        finally
        {
            _loadingCts?.Cancel();
            ViewModel.ShowLoadingIndicator = false;
            ViewModel.IsLoadingInProgress = false;
            _loadSemaphore.Release();
            await InvokeAsync(StateHasChanged);
        }
    }

    #endregion

    #region Tab Management

    private async Task HandleTabChanged(string tab)
    {
        ViewModel.ActiveTab = tab;

        if (tab == ClientDetailsConstants.Tabs.Events)
        {
            await OnEventsTabClick();
        }
    }

    #endregion

    #region Save & Delete Operations

    private ValidationResult ValidateBeforeSave()
    {
        var result = new ValidationResult();

        if (ViewModel.ClientDetails == null)
        {
            result.AddError("Данные клиента не загружены");
            return result;
        }

        if (ViewModel.ClientDetails.StandardFlow && !ViewModel.ClientDetails.RedirectUris.Any())
        {
            result.AddError("При включенном Standard Flow необходимо добавить хотя бы один Valid Redirect URI");
        }

        return result;
    }

    private async Task SaveChanges()
    {
        if (ViewModel.ClientDetails == null) return;

        var validation = ValidateBeforeSave();
        if (!validation.IsValid)
        {
            await NotificationService.ShowNotificationAsync(
                NotificationType.Warning,
                "Внимание",
                validation.Errors.First());
            return;
        }

        if (UserRoleService.IsUser() && !UserRoleService.IsAdmin())
        {
            var username = UserRoleService.GetUserName();
            var userClients = await OwnershipService.GetUserClientsAsync(username ?? "", ViewModel.ClientDetails.Realm).ConfigureAwait(false);
            if (!userClients.Contains(ViewModel.ClientDetails.ClientId))
            {
                await NotificationService.ShowNotificationAsync(NotificationType.Error, "Доступ запрещен", "У вас нет прав на редактирование этого клиента");
                return;
            }
        }

        _isSaving = true;
        await InvokeAsync(StateHasChanged);

        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(ClientDetailsConstants.Timeouts.SaveChanges));

        try
        {
            await KeycloakAdminService.UpdateClientDetailsAsync(ViewModel.ClientDetails).ConfigureAwait(false);

            if (!ViewModel.OriginalLocalRoles.SequenceEqual(ViewModel.ClientDetails.LocalRoles))
            {
                await KeycloakAdminService.SyncClientLocalRolesAsync(
                    ViewModel.ClientDetails.ClientId,
                    ViewModel.ClientDetails.Realm,
                    ViewModel.ClientDetails.Id,
                    ViewModel.OriginalLocalRoles,
                    ViewModel.ClientDetails.LocalRoles).ConfigureAwait(false);
            }

            if (!ViewModel.OriginalServiceRoles.SequenceEqual(ViewModel.ClientDetails.ServiceRoles))
            {
                await KeycloakAdminService.SyncServiceAccountRolesAsync(
                    ViewModel.ClientDetails.ClientId,
                    ViewModel.ClientDetails.Realm,
                    ViewModel.ClientDetails.Id,
                    ViewModel.OriginalServiceRoles,
                    ViewModel.ClientDetails.ServiceRoles).ConfigureAwait(false);
            }

            var changes = GetClientChanges();
            if (changes.Any())
            {
                var username = UserRoleService.GetUserName();
                await AuditService.LogClientUpdatedAsync(username ?? "", ViewModel.ClientDetails.ClientId, ViewModel.ClientDetails.Realm, changes).ConfigureAwait(false);
            }

            if (ConfluenceService != null && changes.Any())
            {
                try
                {
                    var username = UserRoleService.GetUserName();
                    await ConfluenceService.UpdateClientPageAsync(ViewModel.ClientDetails, username ?? "").ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    Logger.LogWarning(ex, "Не удалось обновить Wiki страницу после сохранения изменений");
                }
            }

            await NotificationService.ShowNotificationAsync(NotificationType.Success, "Успешно", "Изменения успешно сохранены!");

            if (!string.IsNullOrEmpty(ViewModel.OriginalClientId) && ViewModel.ClientDetails.ClientId != ViewModel.OriginalClientId)
            {
                Logger.LogWarning("Client ID изменился с {OldClientId} на {NewClientId}, перенаправляем",
                    ViewModel.OriginalClientId, ViewModel.ClientDetails.ClientId);
                Navigation.NavigateTo($"/clients/{Realm}/{ViewModel.ClientDetails.ClientId}", forceLoad: true);
            }
            else
            {
                await LoadClientDetails().ConfigureAwait(false);
            }
        }
        catch (Exception ex)
        {
            await ClientDetailsErrorHandler.HandleAndNotifyAsync(
                ex,
                Logger,
                (type, title, message) => NotificationService.ShowNotificationAsync(type, title, message),
                "сохранении изменений клиента",
                $"ClientId: {ClientId}, Realm: {Realm}");
        }
        finally
        {
            _isSaving = false;
            await InvokeAsync(StateHasChanged);
        }
    }

    private void ToggleClientStatus()
    {
        if (ViewModel.ClientDetails != null)
        {
            ViewModel.ClientDetails.Enabled = !ViewModel.ClientDetails.Enabled;
        }
    }

    private void DeleteClient()
    {
        if (ViewModel.ClientDetails == null)
        {
            _ = NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Данные клиента не загружены");
            return;
        }
        try
        {
            ModalService.ShowDeleteConfirmationModal(ViewModel.ClientDetails.ClientId);
        }
        catch (Exception ex)
        {
            _ = NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", $"Не удалось показать диалог удаления: {ex.Message}");
        }
    }

    private void NavigateBack()
    {
        if (UserRoleService.IsAdmin())
        {
            Navigation.NavigateTo("/clients");
        }
        else
        {
            Navigation.NavigateTo("/my-clients");
        }
    }

    private async Task HandleDeleteConfirmedAsync(string clientName)
    {
        if (ViewModel.ClientDetails == null || ViewModel.ClientDetails.ClientId != clientName) return;

        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(ClientDetailsConstants.Timeouts.DeleteClient));

        try
        {
            var username = UserRoleService.GetUserName();

            if (UserRoleService.IsUser() && !UserRoleService.IsAdmin())
            {
                var userClients = await OwnershipService.GetUserClientsAsync(username ?? "", ViewModel.ClientDetails.Realm).ConfigureAwait(false);

                if (!userClients.Contains(ViewModel.ClientDetails.ClientId))
                {
                    await NotificationService.ShowNotificationAsync(NotificationType.Error, "Доступ запрещен",
                        "У вас нет прав на удаление этого клиента").ConfigureAwait(false);
                    return;
                }
            }

            await KeycloakAdminService.DeleteClientAsync(
                ViewModel.ClientDetails.ClientId,
                ViewModel.ClientDetails.Realm,
                ViewModel.ClientDetails.Id).ConfigureAwait(false);

            if (ConfluenceService != null)
            {
                try
                {
                    await ConfluenceService.ArchiveClientPageAsync(ViewModel.ClientDetails.ClientId, ViewModel.ClientDetails.Realm, username ?? "").ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    Logger.LogWarning(ex, "Не удалось архивировать Wiki страницу");
                }
            }

            await AuditService.LogClientDeletedAsync(username ?? "", ViewModel.ClientDetails.ClientId, ViewModel.ClientDetails.Realm).ConfigureAwait(false);

            try
            {
                await OwnershipService.RemoveAllClientOwnershipsAsync(ViewModel.ClientDetails.ClientId, ViewModel.ClientDetails.Realm).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                Logger.LogWarning(ex, "Не удалось удалить записи владения для клиента {ClientId}", ViewModel.ClientDetails.ClientId);
            }

            SearchStateService.ClearSearchState();
            SearchStateService.RequestUserClientsRefresh();

            NavigateBack();

            _ = NotificationService.ShowNotificationAsync(NotificationType.Success, "Клиент удален",
                $"Клиент {ViewModel.ClientDetails.ClientId} успешно удален из реалма {ViewModel.ClientDetails.Realm}");
        }
        catch (HttpRequestException ex) when (ex.Message.Contains("InternalServerError"))
        {
            Logger.LogError(ex, "Ошибка при удалении клиента {ClientId} из реалма {Realm}", ViewModel.ClientDetails.ClientId, ViewModel.ClientDetails.Realm);

            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка удаления клиента",
                $"Не удалось удалить клиента {ViewModel.ClientDetails.ClientId}. " +
                $"Возможно, клиент имеет активные зависимости (service accounts, role mappings и т.д.). " +
                $"Проверьте логи Keycloak для деталей.").ConfigureAwait(false);
        }
        catch (HttpRequestException ex)
        {
            Logger.LogError(ex, "HTTP ошибка при удалении клиента {ClientId} из реалма {Realm}", ViewModel.ClientDetails.ClientId, ViewModel.ClientDetails.Realm);

            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка удаления клиента",
                $"Не удалось удалить клиента: {ex.Message}").ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Неожиданная ошибка при удалении клиента {ClientId} из реалма {Realm}", ViewModel.ClientDetails.ClientId, ViewModel.ClientDetails.Realm);

            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка удаления клиента",
                $"Произошла неожиданная ошибка: {ex.Message}").ConfigureAwait(false);
        }
    }

    private List<FieldChangeDto> GetClientChanges()
    {
        var changes = new List<FieldChangeDto>();

        if (ViewModel.OriginalClientDetails == null || ViewModel.ClientDetails == null) return changes;

        if (ViewModel.OriginalClientDetails.Name != ViewModel.ClientDetails.Name)
            changes.Add(new FieldChangeDto { FieldName = "Название", OldValue = ViewModel.OriginalClientDetails.Name, NewValue = ViewModel.ClientDetails.Name });

        if (ViewModel.OriginalClientDetails.Description != ViewModel.ClientDetails.Description)
            changes.Add(new FieldChangeDto { FieldName = "Описание", OldValue = ViewModel.OriginalClientDetails.Description, NewValue = ViewModel.ClientDetails.Description });

        if (ViewModel.OriginalClientDetails.Enabled != ViewModel.ClientDetails.Enabled)
            changes.Add(new FieldChangeDto { FieldName = "Включен", OldValue = ViewModel.OriginalClientDetails.Enabled.ToString(), NewValue = ViewModel.ClientDetails.Enabled.ToString() });

        if (ViewModel.OriginalClientDetails.ClientAuthentication != ViewModel.ClientDetails.ClientAuthentication)
            changes.Add(new FieldChangeDto { FieldName = "Client Authentication", OldValue = ViewModel.OriginalClientDetails.ClientAuthentication.ToString(), NewValue = ViewModel.ClientDetails.ClientAuthentication.ToString() });

        if (ViewModel.OriginalClientDetails.StandardFlow != ViewModel.ClientDetails.StandardFlow)
            changes.Add(new FieldChangeDto { FieldName = "Standard Flow", OldValue = ViewModel.OriginalClientDetails.StandardFlow.ToString(), NewValue = ViewModel.ClientDetails.StandardFlow.ToString() });

        if (ViewModel.OriginalClientDetails.ServiceAccountsEnabled != ViewModel.ClientDetails.ServiceAccountsEnabled)
            changes.Add(new FieldChangeDto { FieldName = "Service Accounts", OldValue = ViewModel.OriginalClientDetails.ServiceAccountsEnabled.ToString(), NewValue = ViewModel.ClientDetails.ServiceAccountsEnabled.ToString() });

        if (!ViewModel.OriginalClientDetails.RedirectUris.SequenceEqual(ViewModel.ClientDetails.RedirectUris))
            changes.Add(new FieldChangeDto { FieldName = "Redirect URIs", OldValue = string.Join(", ", ViewModel.OriginalClientDetails.RedirectUris), NewValue = string.Join(", ", ViewModel.ClientDetails.RedirectUris) });

        if (!ViewModel.OriginalLocalRoles.SequenceEqual(ViewModel.ClientDetails.LocalRoles))
            changes.Add(new FieldChangeDto { FieldName = "Локальные роли", OldValue = string.Join(", ", ViewModel.OriginalLocalRoles), NewValue = string.Join(", ", ViewModel.ClientDetails.LocalRoles) });

        if (!ViewModel.OriginalServiceRoles.SequenceEqual(ViewModel.ClientDetails.ServiceRoles))
            changes.Add(new FieldChangeDto { FieldName = "Service Account роли", OldValue = string.Join(", ", ViewModel.OriginalServiceRoles), NewValue = string.Join(", ", ViewModel.ClientDetails.ServiceRoles) });

        return changes;
    }

    #endregion

    #region Redirect URI Management

    private async Task AddRedirectUri(string uriInput)
    {
        if (ViewModel.ClientDetails == null)
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Данные клиента не загружены");
            return;
        }

        if (string.IsNullOrWhiteSpace(uriInput))
        {
            return;
        }

        var uri = uriInput.Trim();

        if (!ValidationService.IsValidRedirectUri(uri))
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Warning, "Некорректный URL", "Используйте формат: https://example.com/callback или http://localhost:3000/callback");
            return;
        }

        if (ViewModel.ClientDetails.RedirectUris.Contains(uri))
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Warning, "Дубликат", "Этот URI уже добавлен");
            return;
        }

        ViewModel.ClientDetails.RedirectUris.Add(uri);
        ViewModel.NewRedirectUri = "";
    }

    private void RemoveRedirectUri(int index)
    {
        if (ViewModel.ClientDetails == null)
        {
            _ = NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Данные клиента не загружены");
            return;
        }

        if (index < 0 || index >= ViewModel.ClientDetails.RedirectUris.Count)
        {
            _ = NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Некорректный индекс URI");
            return;
        }

        try
        {
            ViewModel.ClientDetails.RedirectUris.RemoveAt(index);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при удалении Redirect URI с индексом {Index}", index);
            _ = NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", $"Не удалось удалить URI: {ex.Message}");
        }
    }

    #endregion

    #region Credentials Management

    private void ToggleSecretVisibility()
    {
        ViewModel.IsSecretVisible = !ViewModel.IsSecretVisible;
    }

    private async Task CopyToClipboard(string text)
    {
        if (string.IsNullOrEmpty(text))
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Warning, "Внимание", "Нечего копировать");
            return;
        }
        try
        {
            await JSRuntime.InvokeVoidAsync("navigator.clipboard.writeText", text);
            await NotificationService.ShowNotificationAsync(NotificationType.Success, "Скопировано", "Текст скопирован в буфер обмена");
        }
        catch (Exception ex)
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", $"Не удалось скопировать в буфер обмена: {ex.Message}");
        }
    }

    private async Task HandleCopySecretToClipboard()
    {
        if (ViewModel.ClientDetails != null)
        {
            await CopyToClipboard(ViewModel.ClientDetails.ClientSecret ?? "");
        }
    }

    private async Task RegenerateSecret()
    {
        if (ViewModel.ClientDetails == null)
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Данные клиента не загружены");
            return;
        }

        bool confirmed;
        try
        {
            confirmed = await JSRuntime.InvokeAsync<bool>("confirm", "Вы уверены, что хотите сгенерировать новый secret? Старый secret станет недействительным!");
        }
        catch (Exception ex)
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", $"Не удалось показать диалог подтверждения: {ex.Message}");
            return;
        }

        if (confirmed)
        {
            try
            {
                var newSecret = await KeycloakAdminService.RegenerateClientSecretAsync(
                    ViewModel.ClientDetails.ClientId,
                    ViewModel.ClientDetails.Realm,
                    ViewModel.ClientDetails.Id).ConfigureAwait(false);

                if (newSecret != null)
                {
                    ViewModel.ClientDetails.ClientSecret = newSecret;
                    var username = UserRoleService.GetUserName();
                    await AuditService.LogSecretRegeneratedAsync(username ?? "", ViewModel.ClientDetails.ClientId, ViewModel.ClientDetails.Realm).ConfigureAwait(false);
                    await NotificationService.ShowNotificationAsync(NotificationType.Success, "Успешно", "Secret успешно регенерирован!");
                }
                else
                {
                    await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Не удалось регенерировать secret");
                }
            }
            catch (Exception ex)
            {
                await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", $"Ошибка при регенерации secret: {ex.Message}");
            }
        }
    }

    #endregion

    #region Roles Management

    private async Task AddLocalRole(string roleName)
    {
        if (ViewModel.ClientDetails == null)
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Данные клиента не загружены");
            return;
        }

        if (string.IsNullOrWhiteSpace(roleName))
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Warning, "Внимание", "Введите название роли");
            return;
        }

        try
        {
            var trimmedRole = roleName.Trim();
            if (ViewModel.ClientDetails.LocalRoles.Contains(trimmedRole))
            {
                await NotificationService.ShowNotificationAsync(NotificationType.Warning, "Внимание", "Эта роль уже добавлена");
                return;
            }

            ViewModel.ClientDetails.LocalRoles.Add(trimmedRole);
            ViewModel.NewLocalRole = "";
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при добавлении локальной роли {RoleName}", roleName);
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", $"Не удалось добавить роль: {ex.Message}");
        }
    }

    private void RemoveLocalRole(int index)
    {
        if (ViewModel.ClientDetails == null)
        {
            _ = NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Данные клиента не загружены");
            return;
        }

        if (index < 0 || index >= ViewModel.ClientDetails.LocalRoles.Count)
        {
            _ = NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Некорректный индекс роли");
            return;
        }

        try
        {
            ViewModel.ClientDetails.LocalRoles.RemoveAt(index);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Ошибка при удалении локальной роли с индексом {Index}", index);
            _ = NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", $"Не удалось удалить роль: {ex.Message}");
        }
    }

    private async Task SearchRoles(string searchTerm)
    {
        if (ViewModel.ClientDetails == null)
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Данные клиента не загружены");
            return;
        }

        if (string.IsNullOrWhiteSpace(searchTerm))
        {
            ViewModel.RoleSearchResults.Clear();
            ViewModel.RoleSearchTerm = searchTerm;
            return;
        }

        ViewModel.RoleSearchTerm = searchTerm;

        _searchSpinnerCts?.Cancel();
        _searchSpinnerCts = new CancellationTokenSource(TimeSpan.FromSeconds(ClientDetailsConstants.Timeouts.SearchRoles));

        ViewModel.RoleSearchResults.Clear();
        ViewModel.IsSearchingRoles = true;
        ViewModel.ShowSearchSpinner = false;

        _ = ShowSearchSpinnerWithDelay(_searchSpinnerCts.Token);

        try
        {
            var result = await KeycloakAdminService.SearchRolesForServiceAccountAsync(
                ViewModel.ClientDetails.Realm,
                ViewModel.ClientDetails.Id,
                searchTerm).ConfigureAwait(false);

            var forbiddenClientIds = await ForbiddenRepo.GetForbiddenClientIdsAsync(ViewModel.ClientDetails.Realm).ConfigureAwait(false);
            ViewModel.RoleSearchResults = result.Roles.Where(r =>
                r.Source == "realm" ||
                !forbiddenClientIds.Contains(r.ClientId ?? "")
            ).ToList();
        }
        catch (Exception ex)
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", $"Ошибка поиска ролей: {ex.Message}");
            ViewModel.RoleSearchResults.Clear();
        }
        finally
        {
            _searchSpinnerCts?.Cancel();
            ViewModel.IsSearchingRoles = false;
            ViewModel.ShowSearchSpinner = false;
            await InvokeAsync(StateHasChanged);
        }
    }

    private async Task AddRoleFromSearch(RoleSearchResult role)
    {
        if (ViewModel.ClientDetails == null)
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Данные клиента не загружены");
            return;
        }

        if (role == null)
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Роль не указана");
            return;
        }

        string roleStr;
        if (role.Source == "client")
        {
            roleStr = $"{role.ClientId}|{role.ClientInternalId}:{role.RoleId}:{role.RoleName}";
        }
        else
        {
            roleStr = role.RoleName;
        }

        if (ViewModel.ClientDetails.ServiceRoles.Contains(roleStr))
        {
            return;
        }

        ViewModel.ClientDetails.ServiceRoles.Add(roleStr);

        await SaveServiceAccountRoles();
    }

    private async Task SaveServiceAccountRoles()
    {
        if (ViewModel.ClientDetails == null)
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Данные клиента не загружены");
            return;
        }

        try
        {
            await KeycloakAdminService.SyncServiceAccountRolesAsync(
                ViewModel.ClientDetails.ClientId,
                ViewModel.ClientDetails.Realm,
                ViewModel.ClientDetails.Id,
                ViewModel.OriginalServiceRoles,
                ViewModel.ClientDetails.ServiceRoles).ConfigureAwait(false);

            ViewModel.OriginalServiceRoles = new List<string>(ViewModel.ClientDetails.ServiceRoles);

            if (ConfluenceService != null)
            {
                try
                {
                    var username = UserRoleService.GetUserName();
                    await ConfluenceService.UpdateClientPageAsync(ViewModel.ClientDetails, username ?? "").ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    Logger.LogWarning(ex, "Не удалось обновить Wiki страницу после сохранения Service Account Roles");
                }
            }
        }
        catch (Exception ex)
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", $"Ошибка при сохранении ролей: {ex.Message}");
        }
    }

    private async Task RemoveServiceRole(int index)
    {
        if (ViewModel.ClientDetails == null)
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Данные клиента не загружены");
            return;
        }

        if (index < 0 || index >= ViewModel.ClientDetails.ServiceRoles.Count)
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Некорректный индекс роли");
            return;
        }

        ViewModel.ClientDetails.ServiceRoles.RemoveAt(index);
        await SaveServiceAccountRoles();
    }

    private ClientRolesTabViewModel GetRolesTabViewModel()
    {
        return new ClientRolesTabViewModel
        {
            ClientDetails = ViewModel.ClientDetails ?? throw new InvalidOperationException("ClientDetails is null"),
            ActiveTab = ViewModel.ActiveTab,
            NewLocalRole = ViewModel.NewLocalRole,
            RoleSearchTerm = ViewModel.RoleSearchTerm,
            IsSearchingRoles = ViewModel.IsSearchingRoles,
            ShowSearchSpinner = ViewModel.ShowSearchSpinner,
            RoleSearchResults = ViewModel.RoleSearchResults,
            RoleSearchValidationClass = GetRoleSearchValidationClass()
        };
    }

    private string GetRoleSearchValidationClass()
    {
        if (string.IsNullOrWhiteSpace(ViewModel.RoleSearchTerm))
            return "";

        if (!ValidationService.IsValidRoleName(ViewModel.RoleSearchTerm))
            return "border-2 border-red-500";

        return "";
    }

    #endregion

    #region Settings Management

    private void OnClientAuthenticationChanged()
    {
        if (ViewModel.ClientDetails != null)
        {
            if (!ViewModel.ClientDetails.ClientAuthentication && ViewModel.ClientDetails.ServiceAccountsEnabled)
            {
                ViewModel.ClientDetails.ServiceAccountsEnabled = false;
            }
        }
    }

    private void OnStandardFlowChanged()
    {
        // Метод оставлен для совместимости
    }

    private void OnServiceAccountsChanged()
    {
        // Метод оставлен для совместимости
    }

    #endregion

    #region Evaluate Tab (Token Generation)

    private async Task SearchUsers(string searchTerm)
    {
        if (ViewModel.ClientDetails == null)
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Данные клиента не загружены");
            return;
        }

        if (string.IsNullOrWhiteSpace(searchTerm))
        {
            ViewModel.UserSearchResults.Clear();
            ViewModel.UserSearchTerm = searchTerm;
            return;
        }

        ViewModel.UserSearchTerm = searchTerm;
        ViewModel.IsSearchingUsers = true;
        ViewModel.UserSearchResults.Clear();

        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(ClientDetailsConstants.Timeouts.SearchUsers));

        try
        {
            var results = await KeycloakAdminService.SearchUsersByUsernameAsync(
                ViewModel.ClientDetails.Realm,
                searchTerm).ConfigureAwait(false);

            ViewModel.UserSearchResults = results;
        }
        catch (Exception ex)
        {
            await ClientDetailsErrorHandler.HandleAndNotifyAsync(
                ex,
                Logger,
                (type, title, message) => NotificationService.ShowNotificationAsync(type, title, message),
                "поиске пользователей",
                $"SearchTerm: {searchTerm}");
        }
        finally
        {
            ViewModel.IsSearchingUsers = false;
        }
    }

    private void ToggleUserSelection(UserSearchResultDto user)
    {
        if (ViewModel.SelectedUser?.Id == user.Id)
        {
            ViewModel.SelectedUser = null;
        }
        else
        {
            ViewModel.SelectedUser = user;
        }
    }

    private void ClearSelectedUser()
    {
        ViewModel.SelectedUser = null;
        ViewModel.GeneratedTokenResult = "";
        ViewModel.CurrentTokenType = "";
    }

    private async Task GenerateToken(string tokenType)
    {
        if (ViewModel.ClientDetails == null)
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Данные клиента не загружены");
            return;
        }

        if (ViewModel.SelectedUser == null)
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Warning, "Внимание", "Сначала выберите пользователя");
            return;
        }

        if (string.IsNullOrWhiteSpace(tokenType))
        {
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Тип токена не указан");
            return;
        }

        if (UserRoleService.IsUser() && !UserRoleService.IsAdmin())
        {
            var username = UserRoleService.GetUserName();
            var userClients = await OwnershipService.GetUserClientsAsync(username ?? "", ViewModel.ClientDetails.Realm).ConfigureAwait(false);

            if (!userClients.Contains(ViewModel.ClientDetails.ClientId))
            {
                await NotificationService.ShowNotificationAsync(NotificationType.Error, "Доступ запрещен", "У вас нет прав на генерацию токенов для этого клиента");
                return;
            }
        }

        ViewModel.IsGeneratingToken = true;
        // Очищаем предыдущий результат только если меняется тип токена
        if (ViewModel.CurrentTokenType != tokenType)
        {
            ViewModel.GeneratedTokenResult = string.Empty;
        }
        ViewModel.CurrentTokenType = tokenType;
        // Не вызываем StateHasChanged здесь - Blazor автоматически обновит компонент при изменении параметров

        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(ClientDetailsConstants.Timeouts.GenerateToken));

        try
        {
            string result;

            switch (tokenType)
            {
                case ClientDetailsConstants.TokenTypes.Access:
                    result = await KeycloakAdminService.GenerateExampleAccessTokenAsync(
                        ViewModel.ClientDetails.Realm,
                        ViewModel.ClientDetails.Id,
                        ViewModel.SelectedUser.Id).ConfigureAwait(false);
                    break;

                case ClientDetailsConstants.TokenTypes.Id:
                    result = await KeycloakAdminService.GenerateExampleIdTokenAsync(
                        ViewModel.ClientDetails.Realm,
                        ViewModel.ClientDetails.Id,
                        ViewModel.SelectedUser.Id).ConfigureAwait(false);
                    break;

                case ClientDetailsConstants.TokenTypes.UserInfo:
                    result = await KeycloakAdminService.GenerateExampleUserInfoAsync(
                        ViewModel.ClientDetails.Realm,
                        ViewModel.ClientDetails.Id,
                        ViewModel.SelectedUser.Id).ConfigureAwait(false);
                    break;

                default:
                    await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка", "Неизвестный тип токена");
                    return;
            }

            try
            {
                var jsonDoc = System.Text.Json.JsonDocument.Parse(result);
                ViewModel.GeneratedTokenResult = System.Text.Json.JsonSerializer.Serialize(
                    jsonDoc,
                    new System.Text.Json.JsonSerializerOptions { WriteIndented = true });
            }
            catch
            {
                ViewModel.GeneratedTokenResult = result;
            }
            
            // Убеждаемся, что CurrentTokenType установлен правильно после успешной генерации
            ViewModel.CurrentTokenType = tokenType;
            // Blazor автоматически обновит компонент при изменении параметров через биндинг
        }
        catch (Exception ex)
        {
            var (userMessage, _) = ClientDetailsErrorHandler.HandleError(
                ex,
                Logger,
                "генерации токена",
                $"TokenType: {tokenType}, UserId: {ViewModel.SelectedUser?.Id ?? "не выбран"}");
            await NotificationService.ShowNotificationAsync(NotificationType.Error, "Ошибка генерации", userMessage);
            ViewModel.GeneratedTokenResult = $"Error: {userMessage}";
            // Убеждаемся, что CurrentTokenType установлен правильно даже при ошибке
            ViewModel.CurrentTokenType = tokenType;
            // Blazor автоматически обновит компонент при изменении параметров через биндинг
        }
        finally
        {
            ViewModel.IsGeneratingToken = false;
            // Blazor автоматически обновит компонент при изменении параметров через биндинг
        }
    }

    private async Task HandleCopyTokenToClipboard()
    {
        await CopyToClipboard(ViewModel.GeneratedTokenResult);
    }

    private void ClearTokenResult()
    {
        ViewModel.GeneratedTokenResult = "";
        ViewModel.CurrentTokenType = "";
    }

    #endregion

    #region Events Management

    private async Task OnEventsTabClick()
    {
        ViewModel.ActiveTab = ClientDetailsConstants.Tabs.Events;

        if (!ViewModel.EventsViewModel.EventsLoaded && ViewModel.ClientDetails != null)
        {
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(ClientDetailsConstants.Timeouts.LoadEvents));

            try
            {
                var events = await KeycloakAdminService.GetClientEventsAsync(
                    ViewModel.ClientDetails.ClientId,
                    ViewModel.ClientDetails.Realm,
                    first: 0,
                    maxEvents: ViewModel.EventsViewModel.EventsPerPage).ConfigureAwait(false);

                ViewModel.EventsViewModel.AllEvents = events.ToList().AsReadOnly();
                ViewModel.ClientDetails.Events = ViewModel.EventsViewModel.AllEvents.ToList();

                ViewModel.EventsViewModel.CurrentEventsPage = 1;
                ViewModel.EventsViewModel.FilteredEvents = ViewModel.EventsViewModel.AllEvents;
                ViewModel.EventsViewModel.HasAppliedFilters = false;
                ViewModel.EventsViewModel.EventsLoaded = true;

                await LoadAllEventTypes();
            }
            catch (Exception ex)
            {
                await ClientDetailsErrorHandler.HandleAndNotifyAsync(
                    ex,
                    Logger,
                    (type, title, message) => NotificationService.ShowNotificationAsync(type, title, message),
                    "загрузке событий",
                    $"ClientId: {ViewModel.ClientDetails.ClientId}, Realm: {ViewModel.ClientDetails.Realm}");
            }
        }
    }

    private async Task LoadAllEventTypes()
    {
        try
        {
            if (ViewModel.ClientDetails == null)
            {
                Logger.LogWarning("Не удалось загрузить типы событий: clientDetails равен null");
                ViewModel.EventsViewModel.AllEventTypes = ClientEventsService.GetUniqueEventTypes(ViewModel.EventsViewModel.AllEvents);
                return;
            }

            var eventTypesFromApi = await KeycloakAdminService.GetAllEventTypesAsync(ViewModel.ClientDetails.Realm).ConfigureAwait(false);
            ViewModel.EventsViewModel.AllEventTypes = eventTypesFromApi.ToList().AsReadOnly();

            Logger.LogInformation("Загружено {Count} типов событий из Keycloak API для реалма {Realm}",
                ViewModel.EventsViewModel.AllEventTypes.Count, ViewModel.ClientDetails.Realm);
        }
        catch (Exception ex)
        {
            Logger.LogWarning(ex, "Ошибка при загрузке типов событий из API, используем типы из загруженных событий");
            ViewModel.EventsViewModel.AllEventTypes = ClientEventsService.GetUniqueEventTypes(ViewModel.EventsViewModel.AllEvents);

            await ClientDetailsErrorHandler.HandleAndNotifyAsync(
                ex,
                Logger,
                (type, title, message) => NotificationService.ShowNotificationAsync(type, title, message),
                "загрузке типов событий",
                $"Realm: {ViewModel.ClientDetails?.Realm ?? "unknown"}");
        }
    }

    private async Task ApplyEventFilters()
    {
        try
        {
            await AnimateEventsUpdate(async () =>
            {
                bool hasFilters = ViewModel.EventsViewModel.SelectedEventType != ClientDetailsConstants.EventFilters.All ||
                                 !string.IsNullOrWhiteSpace(ViewModel.EventsViewModel.UserFilter) ||
                                 ViewModel.EventsViewModel.DateFrom.HasValue ||
                                 ViewModel.EventsViewModel.DateTo.HasValue;

                if (hasFilters)
                {
                    await LoadAllEventsForFiltering();
                    ViewModel.EventsViewModel.HasAppliedFilters = true;
                }
                else
                {
                    ViewModel.EventsViewModel.AllEvents = ViewModel.ClientDetails?.Events != null
                        ? new List<ClientEventDto>(ViewModel.ClientDetails.Events).AsReadOnly()
                        : Array.Empty<ClientEventDto>();
                    ViewModel.EventsViewModel.HasAppliedFilters = false;
                }

                ViewModel.EventsViewModel.AllEvents = ClientEventsService.ApplyFilters(
                    ViewModel.EventsViewModel.AllEvents,
                    ViewModel.EventsViewModel.SelectedEventType,
                    ViewModel.EventsViewModel.UserFilter,
                    ViewModel.EventsViewModel.DateFrom,
                    ViewModel.EventsViewModel.DateTo);

                ViewModel.EventsViewModel.CurrentEventsPage = 1;
                UpdateFilteredEvents();
            });
        }
        catch (Exception ex)
        {
            await ClientDetailsErrorHandler.HandleAndNotifyAsync(
                ex,
                Logger,
                (type, title, message) => NotificationService.ShowNotificationAsync(type, title, message),
                "применении фильтров событий",
                $"ClientId: {ClientId}, Realm: {Realm}");
        }
    }

    private async Task LoadAllEventsForFiltering()
    {
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(ClientDetailsConstants.Timeouts.LoadEvents));

        try
        {
            var allEventsFromApi = await KeycloakAdminService.GetAllClientEventsAsync(ClientId, Realm).ConfigureAwait(false);
            ViewModel.EventsViewModel.AllEvents = allEventsFromApi.ToList().AsReadOnly();
        }
        catch (Exception ex)
        {
            ViewModel.EventsViewModel.AllEvents = ViewModel.ClientDetails?.Events != null
                ? new List<ClientEventDto>(ViewModel.ClientDetails.Events).AsReadOnly()
                : Array.Empty<ClientEventDto>();
            await ClientDetailsErrorHandler.HandleAndNotifyAsync(
                ex,
                Logger,
                (type, title, message) => NotificationService.ShowNotificationAsync(type, title, message),
                "загрузке всех событий",
                $"ClientId: {ClientId}, Realm: {Realm}");
        }
    }

    private async Task AnimateEventsUpdate(Func<Task> updateAction)
    {
        try
        {
            await InvokeAsync(() =>
            {
                ViewModel.EventsViewModel.IsEventsAnimating = true;
            });
            await InvokeAsync(StateHasChanged);

            await Task.Delay(ClientDetailsConstants.Ui.EventsAnimationDelay).ConfigureAwait(false);

            await updateAction().ConfigureAwait(false);

            await Task.Delay(ClientDetailsConstants.Ui.EventsUpdateDelay).ConfigureAwait(false);

            await InvokeAsync(() =>
            {
                ViewModel.EventsViewModel.IsEventsAnimating = false;
            });
            await InvokeAsync(StateHasChanged);
        }
        catch (ObjectDisposedException)
        {
            // Компонент был удален, игнорируем
        }
        catch (TaskCanceledException)
        {
            ViewModel.EventsViewModel.IsEventsAnimating = false;
        }
        catch (Exception ex)
        {
            ViewModel.EventsViewModel.IsEventsAnimating = false;
            await ClientDetailsErrorHandler.HandleAndNotifyAsync(
                ex,
                Logger,
                (type, title, message) => NotificationService.ShowNotificationAsync(type, title, message),
                "обновлении событий");
        }
    }

    private void UpdateFilteredEvents()
    {
        ViewModel.EventsViewModel.FilteredEvents = ClientEventsService.GetPageEvents(
            ViewModel.EventsViewModel.AllEvents,
            ViewModel.EventsViewModel.CurrentEventsPage,
            ViewModel.EventsViewModel.EventsPerPage);
    }

    private async Task GoToEventsPage(int page)
    {
        try
        {
            if (page < 1 || ViewModel.ClientDetails == null)
            {
                return;
            }

            var first = (page - 1) * ViewModel.EventsViewModel.EventsPerPage;
            var max = ViewModel.EventsViewModel.EventsPerPage;

            Logger.LogInformation("Загрузка страницы {Page} событий: first={First}, max={Max}", page, first, max);

            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(ClientDetailsConstants.Timeouts.LoadEvents));

            var events = await KeycloakAdminService.GetClientEventsAsync(
                ViewModel.ClientDetails.ClientId,
                ViewModel.ClientDetails.Realm,
                first: first,
                maxEvents: max).ConfigureAwait(false);

            var eventsList = events.ToList();

            Logger.LogInformation("Страница {Page} событий загружена: получено {Count} событий", page, eventsList.Count);

            await AnimateEventsUpdate(async () =>
            {
                ViewModel.EventsViewModel.CurrentEventsPage = page;
                ViewModel.EventsViewModel.AllEvents = eventsList.AsReadOnly();
                ViewModel.ClientDetails.Events = eventsList;

                ViewModel.EventsViewModel.FilteredEvents = ViewModel.EventsViewModel.AllEvents;

                await InvokeAsync(StateHasChanged);
            });
        }
        catch (Exception ex)
        {
            await ClientDetailsErrorHandler.HandleAndNotifyAsync(
                ex,
                Logger,
                (type, title, message) => NotificationService.ShowNotificationAsync(type, title, message),
                "переходе на страницу событий",
                $"Page: {page}");
        }
    }

    private async Task ClearEventFilters()
    {
        try
        {
            await AnimateEventsUpdate(() =>
            {
                ViewModel.EventsViewModel.SelectedEventType = ClientDetailsConstants.EventFilters.All;
                ViewModel.EventsViewModel.UserFilter = "";
                ViewModel.EventsViewModel.DateFrom = null;
                ViewModel.EventsViewModel.DateTo = null;
                ViewModel.EventsViewModel.CurrentEventsPage = 1;
                ViewModel.EventsViewModel.HasAppliedFilters = false;

                ViewModel.EventsViewModel.AllEvents = ViewModel.ClientDetails?.Events != null
                    ? new List<ClientEventDto>(ViewModel.ClientDetails.Events).AsReadOnly()
                    : Array.Empty<ClientEventDto>();
                ViewModel.EventsViewModel.FilteredEvents = ClientEventsService.GetPageEvents(
                    ViewModel.EventsViewModel.AllEvents,
                    ViewModel.EventsViewModel.CurrentEventsPage,
                    ViewModel.EventsViewModel.EventsPerPage);
                return Task.CompletedTask;
            });
        }
        catch (Exception ex)
        {
            await ClientDetailsErrorHandler.HandleAndNotifyAsync(
                ex,
                Logger,
                (type, title, message) => NotificationService.ShowNotificationAsync(type, title, message),
                "очистке фильтров событий");
        }
    }

    #endregion
}

