using System.Collections.Generic;
using System.Security.Claims;
using new_assistant.Core.DTOs;

namespace new_assistant.Pages.UserManagement;

/// <summary>
/// ViewModel для управления состоянием компонента UserInfo
/// </summary>
public class UserInfoViewModel
{
    // Пользователь и поиск
    public UserDetailedInfoDto? SelectedUser { get; set; }
    public IReadOnlyList<UserSearchResultDto>? SearchResults { get; set; }
    public bool SearchPerformed { get; set; }
    public string SearchTerm { get; set; } = string.Empty;
    
    // Реалмы
    public List<string> Realms { get; set; } = new();
    public string SelectedRealm { get; set; } = string.Empty;
    
    // Пагинация
    public int CurrentPage { get; set; } = 1;
    public const int PageSize = 3;
    
    // Вкладки
    public string ActiveTab { get; set; } = "details";
    
    // Редактирование пользователя
    public string EditableDisplayName { get; set; } = string.Empty;
    public string EditableEmail { get; set; } = string.Empty;
    
    // Роли
    public string? SelectedRealmRoleId { get; set; }
    public string? SelectedClientRoleKey { get; set; }
    
    // Блокировка
    public string BlockReason { get; set; } = string.Empty;
    
    // Сертификаты
    public Microsoft.AspNetCore.Components.Forms.IBrowserFile? SelectedCertificateFile { get; set; }
    public string? SelectedCertificateFileName { get; set; }
    public long? SelectedCertificateFileSize { get; set; }
    public const long MaxCertificateFileSizeBytes = 2 * 1024 * 1024; // 2 MB
    
    // Доступные роли из claims
    public List<(string Id, string Name)> AvailableRealmRoles { get; set; } = new();
    public List<(string ClientId, string RoleId, string RoleName)> AvailableClientRoles { get; set; } = new();
    
    // Кэш для клиентов
    public Dictionary<string, string> ClientUuidCache { get; set; } = new();
    
    // Кэш для отфильтрованных ролей
    public List<(string Id, string Name)>? CachedFilteredRealmRoles { get; set; }
    public List<(string ClientId, string RoleId, string RoleName)>? CachedFilteredClientRoles { get; set; }
    public string? CachedFilteredRealmRolesUserId { get; set; }
    public string? CachedFilteredClientRolesUserId { get; set; }
    
    // Состояния загрузки
    public bool IsLoading { get; set; }
    public bool IsSearching { get; set; }
    public bool IsSaving { get; set; }
    public bool IsCertificateLoading { get; set; }
    public bool IsCertificateUploading { get; set; }
    public bool IsCertificateDeleting { get; set; }
    
    /// <summary>
    /// Сбрасывает состояние поиска
    /// </summary>
    public void ResetSearchState(bool clearSearchTerm = false)
    {
        if (clearSearchTerm)
        {
            SearchTerm = string.Empty;
        }
        
        SearchResults = null;
        SearchPerformed = false;
        SelectedUser = null;
        CurrentPage = 1;
        ActiveTab = "details";
        BlockReason = string.Empty;
        SelectedRealmRoleId = null;
        SelectedClientRoleKey = null;
        ClientUuidCache.Clear();
        InvalidateFilteredRolesCache();
    }
    
    /// <summary>
    /// Инвалидирует кэш отфильтрованных ролей
    /// </summary>
    public void InvalidateFilteredRolesCache()
    {
        CachedFilteredRealmRoles = null;
        CachedFilteredClientRoles = null;
        CachedFilteredRealmRolesUserId = null;
        CachedFilteredClientRolesUserId = null;
    }
    
    /// <summary>
    /// Получает общее количество страниц для результатов поиска
    /// </summary>
    public int TotalSearchPages =>
        SearchResults == null || SearchResults.Count == 0
            ? 1
            : (int)System.Math.Ceiling(SearchResults.Count / (double)PageSize);
    
    /// <summary>
    /// Проверяет и корректирует текущую страницу, чтобы она была в допустимых пределах
    /// </summary>
    public void EnsureCurrentPageInRange()
    {
        if (SearchResults == null || SearchResults.Count == 0)
        {
            CurrentPage = 1;
            return;
        }
        
        var totalPages = TotalSearchPages;
        if (CurrentPage > totalPages)
        {
            CurrentPage = totalPages;
        }
        
        if (CurrentPage < 1)
        {
            CurrentPage = 1;
        }
    }
}
