# Value Objects

Этот каталог содержит Value Objects для типизации примитивных значений и обеспечения валидации на уровне типов.

## ClientId

Value Object для идентификатора клиента с валидацией формата.

### Использование

```csharp
// Создание с валидацией
var clientId = ClientId.Parse("app-my-client");

// Безопасное создание
if (ClientId.TryParse("app-my-client", out var clientId))
{
    // Использование clientId
}

// Неявное преобразование в string (для обратной совместимости)
string id = clientId;

// Явное преобразование из string
ClientId id = (ClientId)"app-my-client";
```

### Валидация

- Формат: `^app-[a-z0-9-]+$`
- Максимальная длина: 200 символов
- Не может быть null или пустым

## Realm

Value Object для названия реалма с валидацией.

### Использование

```csharp
// Создание с валидацией
var realm = Realm.Parse("my-realm");

// Безопасное создание
if (Realm.TryParse("my-realm", out var realm))
{
    // Использование realm
}

// Неявное преобразование в string (для обратной совместимости)
string realmName = realm;

// Явное преобразование из string
Realm realm = (Realm)"my-realm";
```

### Валидация

- Формат: `^[a-zA-Z0-9_-]+$` (буквы, цифры, подчеркивание, дефис)
- Минимальная длина: 1 символ
- Максимальная длина: 100 символов
- Не может быть null или пустым

## Миграция существующего кода

Для постепенной миграции можно использовать неявное преобразование:

```csharp
// Старый код продолжает работать
string clientId = "app-my-client";
string realm = "my-realm";

// Новый код использует Value Objects
ClientId validatedClientId = ClientId.Parse(clientId);
Realm validatedRealm = Realm.Parse(realm);

// Value Objects можно использовать как строки
string id = validatedClientId; // Неявное преобразование
```

## Рекомендации

1. **Новые методы** должны принимать Value Objects вместо строк
2. **Существующие методы** можно постепенно мигрировать
3. **Валидация** происходит при создании Value Object, что предотвращает передачу невалидных значений
4. **Обратная совместимость** обеспечивается через неявное преобразование в string

