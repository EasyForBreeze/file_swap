using System;
using System.Text.RegularExpressions;

namespace new_assistant.Core.ValueObjects;

/// <summary>
/// Value Object для названия реалма
/// </summary>
public readonly record struct Realm
{
    private static readonly Regex RealmPattern = new(@"^[a-zA-Z0-9_-]+$", RegexOptions.Compiled);
    private const int MaxLength = 100;
    private const int MinLength = 1;
    
    public string Value { get; }

    private Realm(string value)
    {
        Value = value;
    }

    /// <summary>
    /// Создает Realm из строки с валидацией
    /// </summary>
    /// <param name="value">Название реалма</param>
    /// <returns>Realm если значение валидно</returns>
    /// <exception cref="ArgumentException">Если значение невалидно</exception>
    public static Realm Parse(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new ArgumentException("Realm cannot be null or empty", nameof(value));

        if (value.Length < MinLength)
            throw new ArgumentException($"Realm cannot be shorter than {MinLength} character", nameof(value));

        if (value.Length > MaxLength)
            throw new ArgumentException($"Realm cannot be longer than {MaxLength} characters", nameof(value));

        if (!RealmPattern.IsMatch(value))
            throw new ArgumentException($"Realm must match pattern: {RealmPattern} (alphanumeric, underscore, hyphen)", nameof(value));

        return new Realm(value);
    }

    /// <summary>
    /// Пытается создать Realm из строки
    /// </summary>
    /// <param name="value">Название реалма</param>
    /// <param name="realm">Результат, если успешно</param>
    /// <returns>true если успешно, false если невалидно</returns>
    public static bool TryParse(string? value, out Realm realm)
    {
        realm = default;
        
        if (string.IsNullOrWhiteSpace(value))
            return false;

        if (value.Length < MinLength || value.Length > MaxLength)
            return false;

        if (!RealmPattern.IsMatch(value))
            return false;

        realm = new Realm(value);
        return true;
    }

    /// <summary>
    /// Неявное преобразование в string для обратной совместимости
    /// </summary>
    public static implicit operator string(Realm realm) => realm.Value;

    /// <summary>
    /// Явное преобразование из string (использует Parse)
    /// </summary>
    public static explicit operator Realm(string value) => Parse(value);

    public override string ToString() => Value;
}

