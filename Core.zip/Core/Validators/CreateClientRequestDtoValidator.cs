using FluentValidation;
using new_assistant.Core.DTOs;

namespace new_assistant.Core.Validators;

/// <summary>
/// Статический класс с общими правилами валидации для клиентов.
/// Предоставляет переиспользуемые методы валидации для различных DTOs.
/// </summary>
public static class ClientValidationRules
{
    // Константы для валидации
    private const string ClientIdPattern = @"^app-[a-z0-9-]+$";
    private const int MaxClientIdLength = 255;
    private const int MaxRealmLength = 100;
    private const int MaxNameLength = 200;
    private const int MaxDescriptionLength = 500;
    
    /// <summary>
    /// Валидирует Client ID согласно бизнес-правилам.
    /// Client ID должен начинаться с 'app-' и содержать только строчные буквы, цифры и дефисы.
    /// </summary>
    /// <typeparam name="T">Тип объекта валидации</typeparam>
    /// <param name="ruleBuilder">Построитель правил FluentValidation</param>
    /// <returns>Настроенные правила валидации</returns>
    public static IRuleBuilderOptions<T, string> ValidateClientId<T>(IRuleBuilder<T, string> ruleBuilder)
    {
        return ruleBuilder
            .NotEmpty().WithMessage("Client ID обязателен")
            .Matches(ClientIdPattern)
            .WithMessage("Client ID должен начинаться с 'app-' и содержать только буквы, цифры и дефисы")
            .MaximumLength(MaxClientIdLength).WithMessage($"Client ID не должен превышать {MaxClientIdLength} символов");
    }
    
    /// <summary>
    /// Валидирует Realm согласно бизнес-правилам.
    /// Realm не может быть пустым и имеет ограничение по длине.
    /// </summary>
    /// <typeparam name="T">Тип объекта валидации</typeparam>
    /// <param name="ruleBuilder">Построитель правил FluentValidation</param>
    /// <returns>Настроенные правила валидации</returns>
    public static IRuleBuilderOptions<T, string> ValidateRealm<T>(IRuleBuilder<T, string> ruleBuilder)
    {
        return ruleBuilder
            .NotEmpty().WithMessage("Realm обязателен")
            .MaximumLength(MaxRealmLength).WithMessage($"Realm не должен превышать {MaxRealmLength} символов");
    }
    
    /// <summary>
    /// Валидирует название клиента согласно бизнес-правилам.
    /// Название обязательно и имеет ограничение по длине.
    /// </summary>
    /// <typeparam name="T">Тип объекта валидации</typeparam>
    /// <param name="ruleBuilder">Построитель правил FluentValidation</param>
    /// <returns>Настроенные правила валидации</returns>
    public static IRuleBuilderOptions<T, string> ValidateName<T>(IRuleBuilder<T, string> ruleBuilder)
    {
        return ruleBuilder
            .NotEmpty().WithMessage("Название обязательно")
            .MaximumLength(MaxNameLength).WithMessage($"Название не должно превышать {MaxNameLength} символов");
    }
    
    /// <summary>
    /// Валидирует название клиента (nullable) согласно бизнес-правилам.
    /// Название опционально, но при наличии должно соответствовать правилам.
    /// </summary>
    /// <typeparam name="T">Тип объекта валидации</typeparam>
    /// <param name="ruleBuilder">Построитель правил FluentValidation</param>
    /// <returns>Настроенные правила валидации</returns>
    public static IRuleBuilderOptions<T, string?> ValidateNameNullable<T>(IRuleBuilder<T, string?> ruleBuilder)
    {
        return ruleBuilder
            .MaximumLength(MaxNameLength)
            .WithMessage($"Название не должно превышать {MaxNameLength} символов");
    }
    
    /// <summary>
    /// Валидирует описание клиента согласно бизнес-правилам.
    /// Описание опционально, но при наличии имеет ограничение по длине.
    /// </summary>
    /// <typeparam name="T">Тип объекта валидации</typeparam>
    /// <param name="ruleBuilder">Построитель правил FluentValidation</param>
    /// <returns>Настроенные правила валидации</returns>
    public static IRuleBuilderOptions<T, string?> ValidateDescription<T>(IRuleBuilder<T, string?> ruleBuilder)
    {
        return ruleBuilder
            .MaximumLength(MaxDescriptionLength).WithMessage($"Описание не должно превышать {MaxDescriptionLength} символов");
    }
}

/// <summary>
/// Валидатор для CreateClientRequestDto (API запросы).
/// Использует общие правила валидации из ClientValidationRules для обеспечения консистентности.
/// </summary>
public class CreateClientRequestDtoValidator : AbstractValidator<CreateClientRequestDto>
{
    // Константа для валидации ClientId (соответствует паттерну из CreateClientRequestDto)
    private const string ClientIdPattern = @"^[a-zA-Z0-9_-]+$";
    private const int MinClientIdLength = 3;
    private const int MaxClientIdLength = 100;

    /// <summary>
    /// Инициализирует правила валидации для CreateClientRequestDto.
    /// Применяет стандартные правила валидации для основных полей клиента.
    /// </summary>
    public CreateClientRequestDtoValidator()
    {
        // Валидация Realm
        ClientValidationRules.ValidateRealm(RuleFor(x => x.Realm));

        // Валидация ClientId (используем паттерн из DTO, а не из ClientValidationRules)
        RuleFor(x => x.ClientId)
            .NotEmpty().WithMessage("Client ID не может быть пустым")
            .MinimumLength(MinClientIdLength).WithMessage($"Client ID должен содержать минимум {MinClientIdLength} символа")
            .MaximumLength(MaxClientIdLength).WithMessage($"Client ID не должен превышать {MaxClientIdLength} символов")
            .Matches(ClientIdPattern).WithMessage("Client ID может содержать только буквы, цифры, дефисы и подчеркивания");

        // Валидация Name (опционально)
        ClientValidationRules.ValidateNameNullable(RuleFor(x => x.Name));

        // Валидация Description (опционально)
        ClientValidationRules.ValidateDescription(RuleFor(x => x.Description));

        // Валидация OwnerSystemName (обязательно)
        RuleFor(x => x.OwnerSystemName)
            .NotEmpty().WithMessage("Название системы-владельца не может быть пустым");

        // Валидация OwnerSystemUrl (опционально, но если указан - должен быть валидным URI)
        RuleFor(x => x.OwnerSystemUrl)
            .Must(uri => string.IsNullOrWhiteSpace(uri) || Uri.IsWellFormedUriString(uri, UriKind.Absolute))
            .WithMessage("Некорректный формат URL системы-владельца")
            .When(x => !string.IsNullOrWhiteSpace(x.OwnerSystemUrl));

        // Валидация RedirectUris (если StandardFlow включен)
        RuleFor(x => x.RedirectUris)
            .Must(uris => uris != null && uris.Any() && uris.All(uri => !string.IsNullOrWhiteSpace(uri) && Uri.IsWellFormedUriString(uri, UriKind.Absolute)))
            .WithMessage("Для Standard Flow необходимо указать хотя бы один валидный Redirect URI")
            .When(x => x.StandardFlow);

        // Валидация каждого RedirectUri отдельно (для более детальных сообщений об ошибках)
        RuleForEach(x => x.RedirectUris)
            .Must(uri => !string.IsNullOrWhiteSpace(uri) && Uri.IsWellFormedUriString(uri, UriKind.Absolute))
            .WithMessage("Некорректный формат Redirect URI: {PropertyValue}")
            .When(x => x.StandardFlow && x.RedirectUris != null && x.RedirectUris.Any());
    }
}

