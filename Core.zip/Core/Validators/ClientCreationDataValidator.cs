using FluentValidation;
using new_assistant.Core.DTOs;

using new_assistant.Core.Constants;

namespace new_assistant.Core.Validators;

/// <summary>
/// Валидатор для данных создания клиента.
/// Выполняет валидацию всех полей при создании нового клиента в системе.
/// </summary>
public class ClientCreationDataValidator : AbstractValidator<ClientCreationData>
{
    // Константы для валидации
    private const int MaxOwnerSystemNameLength = 200;
    private const int MaxOwnerNameLength = 100;
    private const int MaxSupportManagerLength = 100;
    private const int MaxRedirectUrisCount = 50;
    private const int MaxLocalRolesCount = 100;
    private const int MaxTicketNumberLength = 50;
    
    /// <summary>
    /// Инициализирует правила валидации для всех полей ClientCreationData
    /// </summary>
    public ClientCreationDataValidator()
    {
        // Базовая валидация через общие правила
        ClientValidationRules.ValidateRealm(RuleFor(x => x.Realm));
        ClientValidationRules.ValidateClientId(RuleFor(x => x.ClientId));
        ClientValidationRules.ValidateName(RuleFor(x => x.Name));
        ClientValidationRules.ValidateDescription(RuleFor(x => x.Description));

        // Валидация информации о владельце
        RuleFor(x => x.OwnerSystemName)
            .NotEmpty().WithMessage("Название системы-владельца обязательно")
            .MaximumLength(MaxOwnerSystemNameLength).WithMessage($"Название системы не должно превышать {MaxOwnerSystemNameLength} символов");

        RuleFor(x => x.OwnerSystemUrl)
            .NotEmpty().WithMessage("URL системы-владельца обязателен")
            .Must(BeValidUrl).WithMessage("URL системы должен быть валидным")
            .When(x => !string.IsNullOrWhiteSpace(x.OwnerSystemUrl));

        RuleFor(x => x.OwnerName)
            .NotEmpty().WithMessage("Имя владельца обязательно")
            .MaximumLength(MaxOwnerNameLength).WithMessage($"Имя владельца не должно превышать {MaxOwnerNameLength} символов");

        RuleFor(x => x.SupportManager)
            .MaximumLength(MaxSupportManagerLength).WithMessage($"Имя менеджера поддержки не должно превышать {MaxSupportManagerLength} символов");

        // Валидация Redirect URIs
        RuleForEach(x => x.RedirectUris)
            .Must(BeValidUrl).WithMessage("Все Redirect URIs должны быть валидными URL")
            .When(x => x.RedirectUris != null && x.RedirectUris.Any());

        RuleFor(x => x.RedirectUris)
            .Must(list => list == null || list.Count <= MaxRedirectUrisCount)
            .WithMessage($"Максимум {MaxRedirectUrisCount} Redirect URIs");

        // Валидация ролей
        RuleFor(x => x.LocalRoles)
            .Must(list => list == null || list.Count <= MaxLocalRolesCount)
            .WithMessage($"Максимум {MaxLocalRolesCount} локальных ролей");

        // Валидация контактной информации
        RuleFor(x => x.NotificationEmail)
            .EmailAddress().When(x => !string.IsNullOrWhiteSpace(x.NotificationEmail))
            .WithMessage("Email уведомлений должен быть валидным");

        RuleFor(x => x.TicketNumber)
            .MaximumLength(MaxTicketNumberLength).When(x => !string.IsNullOrWhiteSpace(x.TicketNumber))
            .WithMessage($"Номер тикета не должен превышать {MaxTicketNumberLength} символов");

        RuleFor(x => x.TicketUrl)
            .Must(BeValidUrl)
            .WithMessage("Ссылка на заявку должна быть валидным URL")
            .When(x => !string.IsNullOrWhiteSpace(x.TicketUrl));
    }

    /// <summary>
    /// Проверяет, является ли строка валидным URL.
    /// </summary>
    /// <param name="url">Строка для проверки</param>
    /// <returns>true, если строка является валидным HTTP/HTTPS URL, иначе false</returns>
    private bool BeValidUrl(string? url)
    {
        if (string.IsNullOrWhiteSpace(url))
            return false;
        
        // Проверка максимальной длины URL
        if (url.Length > MigrationConstants.MaxUrlLength)
            return false;

        return Uri.TryCreate(url, UriKind.Absolute, out var uri) &&
               (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps);
    }
}

