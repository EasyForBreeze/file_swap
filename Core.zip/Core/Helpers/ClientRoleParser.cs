namespace new_assistant.Core.Helpers;

/// <summary>
/// Утилитный класс для парсинга client roles
/// </summary>
public static class ClientRoleParser
{
    // Константы для валидации
    private const int MaxRoleStringLength = 500;
    private const int MaxClientIdLength = 255;
    private const int MaxRoleNameLength = 255;
    
    /// <summary>
    /// Парсит client role в формате "clientId:roleName" или "clientId|additionalInfo:roleName"
    /// </summary>
    /// <param name="role">Роль в формате "clientId:roleName"</param>
    /// <returns>Кортеж (clientId, roleName) или null, если формат некорректный</returns>
    /// <exception cref="ArgumentException">Если роль содержит недопустимые символы или превышает максимальную длину</exception>
    public static (string ClientId, string RoleName)? ParseClientRole(string role)
    {
        if (string.IsNullOrWhiteSpace(role))
            return null;
        
        // Валидация длины входной строки
        if (role.Length > MaxRoleStringLength)
            throw new ArgumentException($"Роль слишком длинная (максимум {MaxRoleStringLength} символов, получено {role.Length})", nameof(role));
        
        // Проверка на опасные символы (path traversal)
        if (role.Contains("..") || role.Contains("/") || role.Contains("\\"))
            throw new ArgumentException("Роль содержит недопустимые символы", nameof(role));
        
        // Оптимизация: используем IndexOf для поиска разделителя без создания массива
        var colonIndex = role.IndexOf(':');
        if (colonIndex < 0 || colonIndex == 0 || colonIndex == role.Length - 1)
            return null;
        
        // Проверка на наличие второго двоеточия (недопустимый формат)
        var secondColonIndex = role.IndexOf(':', colonIndex + 1);
        if (secondColonIndex >= 0)
            return null;
        
        // Используем Span для эффективного извлечения частей без создания массивов
        ReadOnlySpan<char> roleSpan = role;
        var clientPartSpan = roleSpan[..colonIndex];
        var roleNameSpan = roleSpan[(colonIndex + 1)..];
        
        // Проверка на пустые части
        if (clientPartSpan.IsEmpty || roleNameSpan.IsEmpty)
            return null;
        
        var clientPart = clientPartSpan.ToString();
        var roleName = roleNameSpan.ToString();
        
        // Обработка формата "clientId|additionalInfo:roleName"
        // Формат позволяет указать дополнительную информацию после символа '|',
        // но для парсинга используется только часть до '|' как clientId
        // Пример: "app-client|env=prod:admin" -> clientId = "app-client", roleName = "admin"
        var pipeIndex = clientPartSpan.IndexOf('|');
        var targetClientId = pipeIndex >= 0
            ? clientPartSpan[..pipeIndex].ToString()
            : clientPart;
        
        if (string.IsNullOrWhiteSpace(targetClientId) || string.IsNullOrWhiteSpace(roleName))
            return null;
        
        // Валидация длины и символов
        if (targetClientId.Length > MaxClientIdLength)
            throw new ArgumentException($"Client ID слишком длинный (максимум {MaxClientIdLength} символов, получено {targetClientId.Length})", nameof(role));
        
        if (roleName.Length > MaxRoleNameLength)
            throw new ArgumentException($"Название роли слишком длинное (максимум {MaxRoleNameLength} символов, получено {roleName.Length})", nameof(role));
        
        // Дополнительная проверка на опасные символы в clientId и roleName
        if (targetClientId.Contains("..") || targetClientId.Contains("/") || targetClientId.Contains("\\"))
            throw new ArgumentException("Client ID содержит недопустимые символы", nameof(role));
        
        if (roleName.Contains("..") || roleName.Contains("/") || roleName.Contains("\\"))
            throw new ArgumentException("Название роли содержит недопустимые символы", nameof(role));
        
        return (targetClientId, roleName);
    }
    
    /// <summary>
    /// Группирует client roles по clientId
    /// </summary>
    /// <param name="clientRoles">Список client roles в формате "clientId:roleName"</param>
    /// <returns>Словарь, где ключ - clientId, значение - HashSet roleName для O(1) операций</returns>
    public static Dictionary<string, HashSet<string>> GroupByClientId(IEnumerable<string> clientRoles)
    {
        var result = new Dictionary<string, HashSet<string>>();
        
        if (clientRoles == null)
            return result;
        
        foreach (var role in clientRoles)
        {
            var parsed = ParseClientRole(role);
            if (!parsed.HasValue)
                continue;
            
            var (clientId, roleName) = parsed.Value;
            
            // Оптимизация: используем TryGetValue для избежания двойного поиска
            if (!result.TryGetValue(clientId, out var roles))
            {
                roles = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                result[clientId] = roles;
            }
            
            // Дедупликация на уровне клиента (O(1) операция с HashSet)
            roles.Add(roleName);
        }
        
        return result;
    }
    
    /// <summary>
    /// Группирует client roles по clientId и возвращает как Dictionary с IReadOnlyList
    /// </summary>
    /// <param name="clientRoles">Список client roles в формате "clientId:roleName"</param>
    /// <returns>Словарь, где ключ - clientId, значение - список roleName</returns>
    public static Dictionary<string, IReadOnlyList<string>> GroupByClientIdAsReadOnlyList(IEnumerable<string> clientRoles)
    {
        var hashSetResult = GroupByClientId(clientRoles);
        return hashSetResult.ToDictionary(
            kvp => kvp.Key, 
            kvp => (IReadOnlyList<string>)kvp.Value.ToList(), 
            StringComparer.OrdinalIgnoreCase);
    }
    
    /// <summary>
    /// Группирует client roles по clientId и возвращает как Dictionary с List (для обратной совместимости)
    /// </summary>
    /// <param name="clientRoles">Список client roles в формате "clientId:roleName"</param>
    /// <returns>Словарь, где ключ - clientId, значение - список roleName</returns>
    [Obsolete("Use GroupByClientIdAsReadOnlyList for better immutability")]
    public static Dictionary<string, List<string>> GroupByClientIdAsList(IEnumerable<string> clientRoles)
    {
        var hashSetResult = GroupByClientId(clientRoles);
        return hashSetResult.ToDictionary(
            kvp => kvp.Key, 
            kvp => kvp.Value.ToList(), 
            StringComparer.OrdinalIgnoreCase);
    }
}

