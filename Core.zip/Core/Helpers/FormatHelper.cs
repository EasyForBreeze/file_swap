namespace new_assistant.Core.Helpers;

/// <summary>
/// Утилита для форматирования различных типов данных
/// </summary>
public static class FormatHelper
{
    /// <summary>
    /// Форматирует размер в байтах в читаемый формат (B, KB, MB, GB, TB)
    /// </summary>
    /// <param name="bytes">Размер в байтах</param>
    /// <returns>Отформатированная строка с размером</returns>
    public static string FormatBytes(long bytes)
    {
        string[] sizes = { "B", "KB", "MB", "GB", "TB" };
        double len = bytes;
        int order = 0;
        while (len >= 1024 && order < sizes.Length - 1)
        {
            order++;
            len = len / 1024;
        }
        return $"{len:0.##} {sizes[order]}";
    }

    /// <summary>
    /// Форматирует дату и время в относительный формат (например, "2 дня назад", "3 часа назад")
    /// </summary>
    /// <param name="dateTime">Дата и время для форматирования</param>
    /// <returns>Отформатированная строка с относительным временем</returns>
    public static string FormatRelativeTime(DateTime dateTime)
    {
        var diff = DateTime.UtcNow - dateTime;
        
        if (diff.TotalDays >= 1)
            return $"{(int)diff.TotalDays} {GetDayWord((int)diff.TotalDays)} назад";
        else if (diff.TotalHours >= 1)
            return $"{(int)diff.TotalHours} {GetHourWord((int)diff.TotalHours)} назад";
        else if (diff.TotalMinutes >= 1)
            return $"{(int)diff.TotalMinutes} {GetMinuteWord((int)diff.TotalMinutes)} назад";
        else
            return "только что";
    }
    
    /// <summary>
    /// Получает правильную форму слова "день" в зависимости от числа
    /// </summary>
    /// <param name="days">Количество дней</param>
    /// <returns>Правильная форма слова "день"</returns>
    private static string GetDayWord(int days)
    {
        return days switch
        {
            1 => "день",
            >= 2 and <= 4 => "дня",
            _ => "дней"
        };
    }
    
    /// <summary>
    /// Получает правильную форму слова "час" в зависимости от числа
    /// </summary>
    /// <param name="hours">Количество часов</param>
    /// <returns>Правильная форма слова "час"</returns>
    private static string GetHourWord(int hours)
    {
        return hours switch
        {
            1 => "час",
            >= 2 and <= 4 => "часа",
            _ => "часов"
        };
    }
    
    /// <summary>
    /// Получает правильную форму слова "минута" в зависимости от числа
    /// </summary>
    /// <param name="minutes">Количество минут</param>
    /// <returns>Правильная форма слова "минута"</returns>
    private static string GetMinuteWord(int minutes)
    {
        return minutes switch
        {
            1 => "минуту",
            >= 2 and <= 4 => "минуты",
            _ => "минут"
        };
    }
}

