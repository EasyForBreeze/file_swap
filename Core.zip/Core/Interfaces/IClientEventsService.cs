using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Сервис для работы с событиями клиента
/// </summary>
public interface IClientEventsService
{
    /// <summary>
    /// Получить уникальные типы событий из списка событий
    /// </summary>
    /// <param name="events">Коллекция событий клиента. Может быть null.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Отсортированный список уникальных типов событий. Возвращает пустую коллекцию, если events равен null или не содержит событий.</returns>
    IReadOnlyList<string> GetUniqueEventTypes(IEnumerable<ClientEventDto> events, CancellationToken cancellationToken = default);

    /// <summary>
    /// Применить фильтры к событиям
    /// </summary>
    /// <param name="events">Коллекция событий для фильтрации. Может быть null.</param>
    /// <param name="eventType">Тип события для фильтрации. Если null, пустая строка или "all", фильтр не применяется.</param>
    /// <param name="userFilter">Фильтр по пользователю. Если null или пустая строка, фильтр не применяется. Значение "system" фильтрует события без UserId.</param>
    /// <param name="dateFrom">Начальная дата диапазона. Если null, фильтр не применяется.</param>
    /// <param name="dateTo">Конечная дата диапазона. Если null, фильтр не применяется.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Отсортированный по времени (от новых к старым) список отфильтрованных событий.</returns>
    /// <exception cref="ArgumentException">Выбрасывается, если dateFrom больше dateTo или если даты невалидны.</exception>
    IReadOnlyList<ClientEventDto> ApplyFilters(
        IEnumerable<ClientEventDto> events,
        string? eventType,
        string? userFilter,
        DateTime? dateFrom,
        DateTime? dateTo,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Получить отфильтрованные события для страницы
    /// </summary>
    /// <param name="events">Коллекция событий для пагинации. Может быть null.</param>
    /// <param name="page">Номер страницы (начиная с 1). Должен быть больше 0.</param>
    /// <param name="pageSize">Размер страницы. Должен быть больше 0.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список событий для указанной страницы.</returns>
    /// <exception cref="ArgumentException">Выбрасывается, если page или pageSize меньше или равны 0.</exception>
    IReadOnlyList<ClientEventDto> GetPageEvents(
        IEnumerable<ClientEventDto> events,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Получить общее количество страниц
    /// </summary>
    /// <param name="totalEvents">Общее количество событий. Не может быть отрицательным.</param>
    /// <param name="pageSize">Размер страницы. Должен быть больше 0.</param>
    /// <returns>Количество страниц. Возвращает 0, если totalEvents равен 0.</returns>
    /// <exception cref="ArgumentException">Выбрасывается, если totalEvents отрицательное или pageSize меньше или равен 0.</exception>
    int GetTotalPages(int totalEvents, int pageSize);

    /// <summary>
    /// Получить уникальные типы событий из IQueryable (для оптимизации работы с БД)
    /// </summary>
    /// <param name="events">Queryable коллекция событий клиента</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Отсортированный список уникальных типов событий</returns>
    Task<IReadOnlyList<string>> GetUniqueEventTypesAsync(
        IQueryable<ClientEventDto> events,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Применить фильтры к событиям из IQueryable (для оптимизации работы с БД)
    /// </summary>
    /// <param name="events">Queryable коллекция событий для фильтрации</param>
    /// <param name="eventType">Тип события для фильтрации. Если null, пустая строка или "all", фильтр не применяется.</param>
    /// <param name="userFilter">Фильтр по пользователю. Если null или пустая строка, фильтр не применяется. Значение "system" фильтрует события без UserId.</param>
    /// <param name="dateFrom">Начальная дата диапазона. Если null, фильтр не применяется.</param>
    /// <param name="dateTo">Конечная дата диапазона. Если null, фильтр не применяется.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Отсортированный по времени (от новых к старым) список отфильтрованных событий.</returns>
    /// <exception cref="ArgumentException">Выбрасывается, если dateFrom больше dateTo или если даты невалидны.</exception>
    Task<IReadOnlyList<ClientEventDto>> ApplyFiltersAsync(
        IQueryable<ClientEventDto> events,
        string? eventType,
        string? userFilter,
        DateTime? dateFrom,
        DateTime? dateTo,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Получить отфильтрованные события для страницы из IQueryable (для оптимизации работы с БД)
    /// </summary>
    /// <param name="events">Queryable коллекция событий для пагинации</param>
    /// <param name="page">Номер страницы (начиная с 1). Должен быть больше 0.</param>
    /// <param name="pageSize">Размер страницы. Должен быть больше 0.</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Список событий для указанной страницы.</returns>
    /// <exception cref="ArgumentException">Выбрасывается, если page или pageSize меньше или равны 0.</exception>
    Task<IReadOnlyList<ClientEventDto>> GetPageEventsAsync(
        IQueryable<ClientEventDto> events,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default);
}

