using System.Security.Claims;
using System.Threading;
using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Сервис для определения доступных пунктов меню пользователя на основе его ролей
/// </summary>
public interface IUserMenuService
{
    /// <summary>
    /// Получить разрешения пользователя для отображения пунктов меню
    /// Получает роли из всех реалмов через Keycloak Admin API
    /// </summary>
    /// <param name="user">ClaimsPrincipal текущего пользователя</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Объект с разрешениями для меню</returns>
    Task<UserMenuPermissions> GetUserMenuPermissionsAsync(ClaimsPrincipal user, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить роли пользователя из всех реалмов через Keycloak Admin API
    /// </summary>
    /// <param name="username">Username пользователя (из claim preferred_username)</param>
    /// <param name="cancellationToken">Токен отмены</param>
    /// <returns>Список ролей со всех реалмов</returns>
    Task<List<UserRoleInfo>> GetUserRolesFromAllRealmsAsync(string username, CancellationToken cancellationToken = default);
}

