namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для сервиса работы с сертификатами пользователей через users-management API
/// </summary>
public interface IUsersCertificateService
{
    /// <summary>
    /// Получить сертификат пользователя в формате Base64 (X.509)
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>Базовое64 представление сертификата или null, если сертификат отсутствует</returns>
    Task<string?> GetUserCertificateAsync(
        string accessToken,
        string realm,
        string userId,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Загрузить (обновить) сертификат пользователя
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="certificateStream">Поток с данными сертификата</param>
    /// <param name="fileName">Имя файла сертификата</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>true, если загрузка выполнена успешно, иначе false</returns>
    Task<bool> UploadUserCertificateAsync(
        string accessToken,
        string realm,
        string userId,
        Stream certificateStream,
        string fileName,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Удалить сертификат пользователя
    /// </summary>
    /// <param name="accessToken">Access token для аутентификации запроса</param>
    /// <param name="realm">Название реалма</param>
    /// <param name="userId">ID пользователя</param>
    /// <param name="targetUsername">Имя целевого пользователя для аудита (может быть null)</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    /// <returns>true, если удаление выполнено успешно, иначе false</returns>
    Task<bool> DeleteUserCertificateAsync(
        string accessToken,
        string realm,
        string userId,
        string? targetUsername = null,
        CancellationToken cancellationToken = default);
}

