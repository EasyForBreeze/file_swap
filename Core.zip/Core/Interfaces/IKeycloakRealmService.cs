using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для работы с реалмами Keycloak
/// </summary>
public interface IKeycloakRealmService
{
    /// <summary>
    /// Получить список всех реалмов (кроме master)
    /// </summary>
    Task<IEnumerable<string>> GetRealmsListAsync(CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить детальную информацию о всех реалмах (с Display Name)
    /// </summary>
    Task<IReadOnlyList<RealmDto>> GetRealmsWithDetailsAsync(CancellationToken cancellationToken = default);
}

