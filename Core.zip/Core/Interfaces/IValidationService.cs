namespace new_assistant.Core.Interfaces;

/// <summary>
/// Сервис для валидации данных клиентов Keycloak.
/// Предоставляет методы для проверки корректности различных типов данных,
/// используемых при работе с клиентами в Keycloak.
/// </summary>
public interface IValidationService
{
    /// <summary>
    /// Проверяет валидность имени роли согласно бизнес-правилам.
    /// </summary>
    /// <param name="roleName">Имя роли для проверки. Может быть null или пустой строкой.</param>
    /// <returns>true, если имя роли валидно (не null, не пустое и соответствует правилам), иначе false</returns>
    /// <remarks>
    /// Валидное имя роли должно:
    /// - Не быть null или пустой строкой
    /// - Соответствовать правилам именования ролей в Keycloak
    /// </remarks>
    bool IsValidRoleName(string? roleName);

    /// <summary>
    /// Проверяет валидность Redirect URI согласно стандартам OAuth2/OIDC.
    /// </summary>
    /// <param name="uri">URI для проверки. Может быть null или пустой строкой.</param>
    /// <returns>true, если URI валиден (корректный формат, поддерживаемая схема), иначе false</returns>
    /// <remarks>
    /// Валидный Redirect URI должен:
    /// - Быть абсолютным URI (содержать схему)
    /// - Использовать поддерживаемые схемы (обычно http:// или https://)
    /// - Соответствовать требованиям безопасности (не содержать опасные символы)
    /// </remarks>
    bool IsValidRedirectUri(string? uri);
}

