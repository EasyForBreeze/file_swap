using new_assistant.Core.Entities;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для работы с запрещенными клиентами
/// </summary>
public interface IForbiddenClientRepository
{
    /// <summary>
    /// Получить все запрещенные клиенты
    /// </summary>
    Task<List<ForbiddenClient>> GetAllAsync();
    
    /// <summary>
    /// Получить запрещенные клиенты для конкретного realm
    /// </summary>
    Task<List<ForbiddenClient>> GetByRealmAsync(string realm);
    
    /// <summary>
    /// Проверить, является ли клиент запрещенным
    /// </summary>
    Task<bool> IsForbiddenAsync(string clientId, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Добавить клиента в запрещенные
    /// </summary>
    Task<bool> AddAsync(string clientId, string realm, string addedBy);
    
    /// <summary>
    /// Удалить клиента из запрещенных
    /// </summary>
    Task<bool> RemoveAsync(string clientId, string realm);
    
    /// <summary>
    /// Получить список всех запрещенных ClientId для указанного realm
    /// </summary>
    Task<List<string>> GetForbiddenClientIdsAsync(string realm);
    
    /// <summary>
    /// Получить список всех запрещенных ClientId для всех реалмов
    /// </summary>
    Task<List<(string ClientId, string Realm)>> GetAllForbiddenClientIdsAsync(CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить статистику производительности SQLite
    /// </summary>
    (long TotalTimeMs, long RequestCount, double AverageTimeMs) GetPerformanceStats();
    
    /// <summary>
    /// Сбросить статистику производительности SQLite
    /// </summary>
    void ResetPerformanceStats();
}

