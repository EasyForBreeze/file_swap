using System.Net.Http;
using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// HTTP клиент для работы с Keycloak STAGE Admin API.
/// Предоставляет методы для выполнения HTTP-запросов с автоматической аутентификацией и управлением токенами.
/// </summary>
public interface IKeycloakStageHttpClient : IDisposable
{
    /// <summary>
    /// Выполняет GET запрос к указанному endpoint Keycloak Admin API.
    /// Автоматически добавляет Bearer токен аутентификации.
    /// </summary>
    /// <typeparam name="T">Тип объекта для десериализации ответа. Используйте JsonElement для динамической обработки.</typeparam>
    /// <param name="endpoint">Endpoint относительно базового URL Admin API (например, "admin/realms/my-realm/clients")</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>Десериализованный объект типа T или null, если ответ пуст</returns>
    /// <exception cref="ArgumentException">Если endpoint пуст или null</exception>
    /// <exception cref="HttpRequestException">При ошибках HTTP запроса или таймауте</exception>
    /// <exception cref="JsonException">При ошибках десериализации JSON</exception>
    Task<T?> GetAsync<T>(string endpoint, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Выполняет POST запрос к указанному endpoint Keycloak Admin API.
    /// Автоматически добавляет Bearer токен аутентификации и сериализует содержимое в JSON.
    /// </summary>
    /// <param name="endpoint">Endpoint относительно базового URL Admin API</param>
    /// <param name="content">Объект для сериализации в JSON тело запроса. Может быть null для пустого тела.</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>HttpResponseMessage с ответом сервера. ВАЖНО: вызывающий код должен вызвать Dispose() для освобождения ресурсов.</returns>
    /// <exception cref="ArgumentException">Если endpoint пуст или null</exception>
    /// <exception cref="HttpRequestException">При ошибках HTTP запроса или таймауте</exception>
    /// <remarks>
    /// ВАЖНО: Возвращаемый HttpResponseMessage должен быть освобожден вызывающим кодом через вызов Dispose() или использование using.
    /// Пример использования:
    /// <code>
    /// using var response = await client.PostAsync("admin/realms/my-realm/clients", clientData);
    /// if (response.IsSuccessStatusCode) { /* обработка */ }
    /// </code>
    /// </remarks>
    Task<HttpResponseMessage> PostAsync(string endpoint, object? content, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Выполняет PUT запрос к указанному endpoint Keycloak Admin API.
    /// Автоматически добавляет Bearer токен аутентификации и сериализует содержимое в JSON.
    /// </summary>
    /// <param name="endpoint">Endpoint относительно базового URL Admin API</param>
    /// <param name="content">Объект для сериализации в JSON тело запроса. Не может быть null.</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>HttpResponseMessage с ответом сервера. ВАЖНО: вызывающий код должен вызвать Dispose() для освобождения ресурсов.</returns>
    /// <exception cref="ArgumentException">Если endpoint пуст или null</exception>
    /// <exception cref="ArgumentNullException">Если content равен null</exception>
    /// <exception cref="HttpRequestException">При ошибках HTTP запроса или таймауте</exception>
    /// <remarks>
    /// ВАЖНО: Возвращаемый HttpResponseMessage должен быть освобожден вызывающим кодом через вызов Dispose() или использование using.
    /// Пример использования:
    /// <code>
    /// using var response = await client.PutAsync("admin/realms/my-realm/clients/{id}", updateData);
    /// if (response.IsSuccessStatusCode) { /* обработка */ }
    /// </code>
    /// </remarks>
    Task<HttpResponseMessage> PutAsync(string endpoint, object content, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Выполняет HEAD запрос к указанному endpoint Keycloak Admin API.
    /// Используется для проверки существования ресурса без загрузки его содержимого.
    /// Автоматически добавляет Bearer токен аутентификации.
    /// </summary>
    /// <param name="endpoint">Endpoint относительно базового URL Admin API</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>true, если ресурс существует (HTTP статус 2xx), иначе false</returns>
    /// <exception cref="ArgumentException">Если endpoint пуст или null</exception>
    Task<bool> HeadAsync(string endpoint, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Выполняет DELETE запрос к указанному endpoint Keycloak Admin API.
    /// Автоматически добавляет Bearer токен аутентификации.
    /// </summary>
    /// <param name="endpoint">Endpoint относительно базового URL Admin API</param>
    /// <param name="cancellationToken">Токен отмены для асинхронной операции</param>
    /// <returns>HttpResponseMessage с ответом сервера. ВАЖНО: вызывающий код должен вызвать Dispose() для освобождения ресурсов.</returns>
    /// <exception cref="ArgumentException">Если endpoint пуст или null</exception>
    /// <exception cref="HttpRequestException">При ошибках HTTP запроса или таймауте</exception>
    /// <remarks>
    /// ВАЖНО: Возвращаемый HttpResponseMessage должен быть освобожден вызывающим кодом через вызов Dispose() или использование using.
    /// Пример использования:
    /// <code>
    /// using var response = await client.DeleteAsync("admin/realms/my-realm/clients/{id}");
    /// if (response.IsSuccessStatusCode) { /* обработка */ }
    /// </code>
    /// </remarks>
    Task<HttpResponseMessage> DeleteAsync(string endpoint, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получает статистику использования кеша токенов.
    /// </summary>
    /// <returns>Объект с информацией о количестве попаданий и промахов кеша, а также процент попаданий</returns>
    TokenCacheStatistics GetTokenCacheStatistics();
}

