using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для запросов к аудит-логам
/// </summary>
public interface IAuditQueryService
{
    /// <summary>
    /// Получение записей аудита с фильтрацией и пагинацией
    /// </summary>
    Task<AuditLogPagedResult> GetAuditLogsAsync(AuditLogFilterDto filter);

    /// <summary>
    /// Экспорт записей аудита в CSV
    /// </summary>
    Task<string> ExportToCsvAsync(AuditLogFilterDto filter);

    /// <summary>
    /// Экспорт записей аудита в CSV с указанием кодировки
    /// </summary>
    Task<CsvExportResult> ExportToCsvBytesAsync(AuditLogFilterDto filter);

    /// <summary>
    /// Получение всех типов событий
    /// </summary>
    List<string> GetEventTypes();

    /// <summary>
    /// Очистка старых записей аудита
    /// </summary>
    Task<int> CleanupOldRecordsAsync(DateTime olderThan);
}

