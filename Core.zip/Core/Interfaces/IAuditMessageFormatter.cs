namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для форматирования сообщений аудит-логов
/// </summary>
public interface IAuditMessageFormatter
{
    /// <summary>
    /// Форматирует сообщение о создании клиента
    /// </summary>
    string ClientCreated(string clientId, string realm);

    /// <summary>
    /// Форматирует сообщение об удалении клиента
    /// </summary>
    string ClientDeleted(string clientId, string realm);

    /// <summary>
    /// Форматирует сообщение об обновлении клиента
    /// </summary>
    string ClientUpdated(string changedFields);

    /// <summary>
    /// Форматирует сообщение о предоставлении доступа
    /// </summary>
    string AccessGranted(string targetUsername, string clientId, string realm);

    /// <summary>
    /// Форматирует сообщение об отзыве доступа
    /// </summary>
    string AccessRevoked(string targetUsername, string clientId, string realm);

    /// <summary>
    /// Форматирует сообщение о добавлении роли
    /// </summary>
    string RoleAdded(string roleName, string clientId, string realm);

    /// <summary>
    /// Форматирует сообщение об удалении роли
    /// </summary>
    string RoleRemoved(string roleName, string clientId, string realm);

    /// <summary>
    /// Форматирует сообщение о регенерации секрета
    /// </summary>
    string SecretRegenerated(string clientId, string realm);

    /// <summary>
    /// Форматирует сообщение о входе пользователя
    /// </summary>
    string UserLogin(string username);

    /// <summary>
    /// Форматирует сообщение о добавлении клиента в запрещенные
    /// </summary>
    string ForbiddenClientAdded(string clientId, string realm);

    /// <summary>
    /// Форматирует сообщение об удалении клиента из запрещенных
    /// </summary>
    string ForbiddenClientRemoved(string clientId, string realm);

    /// <summary>
    /// Форматирует сообщение о миграции клиента
    /// </summary>
    string ClientMigrated(string sourceRealm, string targetRealm, string status);
}

