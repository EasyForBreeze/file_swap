using System.Text.Json;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для получения детальной информации о клиентах Keycloak
/// </summary>
public interface IKeycloakClientDetailsService
{
    /// <summary>
    /// Получить детальную информацию о клиенте
    /// </summary>
    Task<Core.DTOs.ClientDetailsDto?> GetClientDetailsAsync(string clientId, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить роли клиента (локальные и сервисные)
    /// </summary>
    Task<(List<string> LocalRoles, List<string> ServiceRoles)> GetClientRolesAsync(string clientId, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить эндпоинты клиента
    /// </summary>
    Task<List<string>> GetClientEndpointsAsync(string clientId, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить всех клиентов реалма в виде JsonElement
    /// </summary>
    Task<List<JsonElement>> GetAllClientsAsJsonAsync(string realm, CancellationToken cancellationToken = default);
}

