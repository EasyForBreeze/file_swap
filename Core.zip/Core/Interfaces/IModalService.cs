using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Сервис для управления модальными окнами
/// </summary>
public interface IModalService
{
    /// <summary>
    /// Событие изменения состояния модального окна
    /// </summary>
    event Action? OnModalStateChanged;
    
    /// <summary>
    /// Событие подтверждения удаления клиента
    /// </summary>
    event Action<string>? OnDeleteConfirmed;
    
    /// <summary>
    /// Показать модальное окно создания клиента
    /// </summary>
    void ShowCreateClientModal();
    
    /// <summary>
    /// Скрыть модальное окно создания клиента
    /// </summary>
    void HideCreateClientModal();
    
    /// <summary>
    /// Проверить, показано ли модальное окно создания клиента
    /// </summary>
    bool IsCreateClientModalVisible { get; }

    /// <summary>
    /// Показать модальное окно подтверждения удаления
    /// </summary>
    void ShowDeleteConfirmationModal(string clientName);
    
    /// <summary>
    /// Скрыть модальное окно подтверждения удаления
    /// </summary>
    void HideDeleteConfirmationModal();
    
    /// <summary>
    /// Проверить, показано ли модальное окно подтверждения удаления
    /// </summary>
    bool IsDeleteConfirmationModalVisible { get; }
    
    /// <summary>
    /// Получить имя клиента для удаления
    /// </summary>
    string? DeleteClientName { get; }
    
    /// <summary>
    /// Подтвердить удаление клиента
    /// </summary>
    void ConfirmDelete(string clientName);
    
    /// <summary>
    /// Показать модальное окно с информацией о созданном клиенте
    /// </summary>
    void ShowClientCreatedInfoModal(ClientCreationResultDto result);
    
    /// <summary>
    /// Скрыть модальное окно с информацией о созданном клиенте
    /// </summary>
    void HideClientCreatedInfoModal();
    
    /// <summary>
    /// Проверить, показано ли модальное окно с информацией о созданном клиенте
    /// </summary>
    bool IsClientCreatedInfoModalVisible { get; }
    
    /// <summary>
    /// Получить результат создания клиента
    /// </summary>
    ClientCreationResultDto? CreationResult { get; }
}
