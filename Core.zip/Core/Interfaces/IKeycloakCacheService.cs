namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс сервиса для кэширования статических данных из Keycloak
/// </summary>
public interface IKeycloakCacheService
{
    /// <summary>
    /// Получить список реалмов из кэша или выполнить функцию загрузки
    /// </summary>
    Task<List<string>> GetOrCreateRealmsListAsync(
        Func<Task<List<string>>> factory,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Инвалидировать кэш списка реалмов
    /// </summary>
    void InvalidateRealmsList();
    
    /// <summary>
    /// Получить типы событий для реалма из кэша или выполнить функцию загрузки
    /// </summary>
    Task<List<string>> GetOrCreateEventTypesAsync(
        string realm,
        Func<Task<List<string>>> factory,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Инвалидировать кэш типов событий для реалма
    /// </summary>
    void InvalidateEventTypes(string realm);
    
    /// <summary>
    /// Получить well-known endpoints для реалма из кэша или выполнить функцию загрузки
    /// </summary>
    Task<Dictionary<string, string>> GetOrCreateWellKnownEndpointsAsync(
        string realm,
        Func<Task<Dictionary<string, string>>> factory,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Инвалидировать кэш well-known endpoints для реалма
    /// </summary>
    void InvalidateWellKnownEndpoints(string realm);
    
    /// <summary>
    /// Получить значение из кэша по ключу
    /// </summary>
    Task<T?> GetAsync<T>(string key, CancellationToken cancellationToken = default) where T : class;
    
    /// <summary>
    /// Сохранить значение в кэш с указанным TTL
    /// </summary>
    Task SetAsync<T>(string key, T value, TimeSpan ttl, CancellationToken cancellationToken = default) where T : class;
    
    /// <summary>
    /// Удалить значение из кэша по ключу
    /// </summary>
    Task RemoveAsync(string key, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить или создать значение в кэше (GetOrCreate pattern)
    /// </summary>
    Task<T> GetOrCreateAsync<T>(
        string key,
        Func<Task<T>> factory,
        TimeSpan ttl,
        CancellationToken cancellationToken = default) where T : class;
    
    /// <summary>
    /// Очистить весь кэш Keycloak
    /// </summary>
    void ClearAll();
    
    /// <summary>
    /// Получить статистику кэша
    /// </summary>
    CacheStatistics GetStatistics();
}

/// <summary>
/// Статистика кэша
/// </summary>
public class CacheStatistics
{
    public string Message { get; set; } = string.Empty;
    public int TotalEntries { get; set; }
    public long TotalMemoryBytes { get; set; }
    public long TotalHits { get; set; }
    public long TotalMisses { get; set; }
    public long TotalSets { get; set; }
    public long TotalRemoves { get; set; }
    public double HitRate { get; set; }
}

