using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс клиента для выполнения массовых операций с ролями
/// </summary>
public interface IKeycloakRoleBatchOperationsClient
{
    /// <summary>
    /// Назначить несколько realm ролей пользователю
    /// </summary>
    Task AssignMultipleRealmRolesToUserAsync(string realm, string userId, IReadOnlyList<string> roleNames, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Назначить несколько client ролей пользователю
    /// </summary>
    Task AssignMultipleClientRolesToUserAsync(string realm, string userId, string clientInternalId, IReadOnlyList<(string roleId, string roleName)> roles, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Удалить несколько client ролей у пользователя
    /// </summary>
    Task RemoveMultipleClientRolesFromUserAsync(string realm, string userId, string clientInternalId, IReadOnlyList<(string roleId, string roleName)> roles, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Удалить несколько realm ролей у пользователя
    /// </summary>
    Task RemoveMultipleRealmRolesFromUserAsync(string realm, string userId, IReadOnlyList<string> roleNames, CancellationToken cancellationToken = default);
}

