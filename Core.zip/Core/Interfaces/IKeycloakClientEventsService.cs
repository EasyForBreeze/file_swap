using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Интерфейс для работы с событиями клиентов Keycloak
/// </summary>
public interface IKeycloakClientEventsService
{
    /// <summary>
    /// Загружает события клиента (для ленивой загрузки)
    /// </summary>
    Task<List<ClientEventDto>> LoadClientEventsAsync(string clientId, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получение событий клиента с пагинацией (first и max)
    /// </summary>
    Task<IEnumerable<ClientEventDto>> GetClientEventsAsync(string clientId, string realm, int first, int maxEvents, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить события клиента
    /// </summary>
    Task<IEnumerable<ClientEventDto>> GetClientEventsAsync(string clientId, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить все события клиента для фильтрации
    /// </summary>
    Task<IEnumerable<ClientEventDto>> GetAllClientEventsAsync(string clientId, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Получить все возможные типы событий из реалма
    /// </summary>
    Task<IEnumerable<string>> GetAllEventTypesAsync(string realm, CancellationToken cancellationToken = default);
}

