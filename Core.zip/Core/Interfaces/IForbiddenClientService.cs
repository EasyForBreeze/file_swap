using new_assistant.Core.DTOs;

namespace new_assistant.Core.Interfaces;

/// <summary>
/// Сервис для работы с запрещенными клиентами (системные + кастомные)
/// </summary>
public interface IForbiddenClientService
{
    /// <summary>
    /// Проверить, является ли клиент запрещенным (с учетом системных и кастомных запретов)
    /// </summary>
    /// <param name="clientId">Идентификатор клиента для проверки</param>
    /// <param name="realm">Название реалма, в котором находится клиент</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    Task<bool> IsForbiddenAsync(string clientId, string realm, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Проверить, является ли клиент системным запрещенным клиентом
    /// </summary>
    /// <param name="clientId">Идентификатор клиента для проверки</param>
    /// <returns>
    /// <c>true</c> если клиент является системным запрещенным, <c>false</c> в противном случае.
    /// </returns>
    /// <remarks>
    /// Метод выполняет быструю проверку в памяти без обращения к БД.
    /// </remarks>
    bool IsSystemForbidden(string clientId);
    
    /// <summary>
    /// Получить копию HashSet системных запрещенных клиентов
    /// </summary>
    /// <returns>Неизменяемая копия HashSet системных запрещенных клиентов</returns>
    IReadOnlySet<string> GetAlwaysForbiddenSet();
    
    /// <summary>
    /// Отфильтровать список клиентов, исключив запрещенные
    /// </summary>
    /// <param name="clients">Список клиентов для фильтрации</param>
    /// <param name="cancellationToken">Токен отмены операции</param>
    Task<IReadOnlyList<ClientSearchResult>> FilterForbiddenClientsAsync(IReadOnlyList<ClientSearchResult> clients, CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Инвалидировать кэш запрещенных клиентов
    /// </summary>
    /// <remarks>
    /// Вызывайте этот метод после добавления или удаления запрещенных клиентов,
    /// чтобы обеспечить актуальность кэшированных данных.
    /// </remarks>
    void InvalidateCache();
    
    /// <summary>
    /// Получить статистику использования кэша
    /// </summary>
    /// <returns>
    /// Кортеж с количеством попаданий в кэш (Hits), промахов (Misses) и коэффициентом попаданий (HitRatio).
    /// </returns>
    (long Hits, long Misses, double HitRatio) GetCacheStats();
}

