namespace new_assistant.Core.Extensions;

/// <summary>
/// Extension-методы для форматирования ролей
/// </summary>
public static class RoleFormattingExtensions
{
    /// <summary>
    /// Форматирует имя роли для отображения
    /// </summary>
    /// <param name="roleStr">Строка роли в формате "clientId|realm:roleName" или просто "roleName"</param>
    /// <returns>Отформатированное имя роли для отображения</returns>
    /// <remarks>
    /// Если роль содержит символ '|', то извлекается часть после '|' и после последнего ':'
    /// Например: "client-id|realm:role-name" -> "role-name"
    /// </remarks>
    public static string FormatRoleDisplayName(this string roleStr)
    {
        if (string.IsNullOrWhiteSpace(roleStr))
            return roleStr;

        if (roleStr.Contains('|'))
        {
            var parts = roleStr.Split('|');
            if (parts.Length > 1)
            {
                var rolePart = parts[1];
                var roleParts = rolePart.Split(':');
                return roleParts.Length > 0 ? roleParts[^1] : roleStr;
            }
        }
        return roleStr;
    }

    /// <summary>
    /// Извлекает источник роли (clientId или "Realm")
    /// </summary>
    /// <param name="roleStr">Строка роли в формате "clientId|realm:roleName" или просто "roleName"</param>
    /// <returns>Источник роли: clientId для client roles или "Realm" для realm roles</returns>
    public static string GetRoleSource(this string roleStr)
    {
        if (string.IsNullOrWhiteSpace(roleStr))
            return "Realm";

        if (roleStr.Contains('|'))
        {
            var parts = roleStr.Split('|');
            return parts.Length > 0 ? parts[0] : "Realm";
        }
        return "Realm";
    }

    /// <summary>
    /// Проверяет, является ли роль client role
    /// </summary>
    /// <param name="roleStr">Строка роли</param>
    /// <returns>true если роль является client role, иначе false</returns>
    public static bool IsClientRole(this string roleStr)
    {
        return !string.IsNullOrWhiteSpace(roleStr) && roleStr.Contains('|');
    }
}

