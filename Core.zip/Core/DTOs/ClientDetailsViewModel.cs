using new_assistant.Core.DTOs;
using new_assistant.Core.Constants;

namespace new_assistant.Core.DTOs;

/// <summary>
/// ViewModel для компонента ClientDetails
/// Группирует все состояние компонента для упрощения управления
/// </summary>
public class ClientDetailsViewModel
{
    /// <summary>
    /// Данные клиента
    /// </summary>
    public ClientDetailsDto? ClientDetails { get; set; }

    /// <summary>
    /// Оригинальные данные клиента для отслеживания изменений
    /// </summary>
    public ClientDetailsDto? OriginalClientDetails { get; set; }

    /// <summary>
    /// Показывать индикатор загрузки
    /// </summary>
    public bool ShowLoadingIndicator { get; set; } = false;

    /// <summary>
    /// Текст ошибки
    /// </summary>
    public string? Error { get; set; }

    /// <summary>
    /// Активная вкладка
    /// </summary>
    public string ActiveTab { get; set; } = ClientDetailsConstants.Tabs.Settings;

    /// <summary>
    /// Новый Redirect URI для добавления
    /// </summary>
    public string NewRedirectUri { get; set; } = string.Empty;

    /// <summary>
    /// Новая локальная роль для добавления
    /// </summary>
    public string NewLocalRole { get; set; } = string.Empty;

    /// <summary>
    /// Видимость секрета
    /// </summary>
    public bool IsSecretVisible { get; set; } = false;

    /// <summary>
    /// Оригинальные локальные роли для отслеживания изменений
    /// </summary>
    public List<string> OriginalLocalRoles { get; set; } = new();

    /// <summary>
    /// Оригинальные Service Account роли для отслеживания изменений
    /// </summary>
    public List<string> OriginalServiceRoles { get; set; } = new();

    /// <summary>
    /// Оригинальный Client ID для отслеживания изменений
    /// </summary>
    public string OriginalClientId { get; set; } = string.Empty;

    /// <summary>
    /// Поисковый запрос для ролей
    /// </summary>
    public string RoleSearchTerm { get; set; } = string.Empty;

    /// <summary>
    /// Флаг выполнения поиска ролей
    /// </summary>
    public bool IsSearchingRoles { get; set; } = false;

    /// <summary>
    /// Флаг показа спиннера поиска
    /// </summary>
    public bool ShowSearchSpinner { get; set; } = false;

    /// <summary>
    /// Результаты поиска ролей
    /// </summary>
    public List<RoleSearchResult> RoleSearchResults { get; set; } = new();

    /// <summary>
    /// ViewModel для работы с событиями
    /// </summary>
    public ClientEventsViewModel EventsViewModel { get; set; } = new()
    {
        EventsPerPage = ClientDetailsConstants.Ui.EventsPerPage,
        SelectedEventType = ClientDetailsConstants.EventFilters.All
    };

    /// <summary>
    /// Флаг загрузки данных
    /// </summary>
    public bool IsLoadingInProgress { get; set; } = false;

    /// <summary>
    /// URL Wiki страницы
    /// </summary>
    public string? WikiPageUrl { get; set; } = null;

    /// <summary>
    /// Поисковый запрос для пользователей
    /// </summary>
    public string UserSearchTerm { get; set; } = string.Empty;

    /// <summary>
    /// Флаг выполнения поиска пользователей
    /// </summary>
    public bool IsSearchingUsers { get; set; } = false;

    /// <summary>
    /// Результаты поиска пользователей
    /// </summary>
    public List<UserSearchResultDto> UserSearchResults { get; set; } = new();

    /// <summary>
    /// Выбранный пользователь
    /// </summary>
    public UserSearchResultDto? SelectedUser { get; set; } = null;

    /// <summary>
    /// Флаг генерации токена
    /// </summary>
    public bool IsGeneratingToken { get; set; } = false;

    /// <summary>
    /// Текущий тип токена
    /// </summary>
    public string CurrentTokenType { get; set; } = string.Empty;

    /// <summary>
    /// Результат генерации токена
    /// </summary>
    public string GeneratedTokenResult { get; set; } = string.Empty;
}

