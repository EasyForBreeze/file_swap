using System.Collections.Generic;

namespace new_assistant.Core.DTOs;

/// <summary>
/// Конфигурация клиента
/// </summary>
public class ClientConfigurationDto
{
    public string Protocol { get; set; } = "openid-connect";
    public string ClientType { get; set; } = "confidential"; // public, confidential, bearer-only
    public string AccessType { get; set; } = "confidential"; // public, confidential, bearer-only
    public string? RootUrl { get; set; }
    public string? BaseUrl { get; set; }
    public string? AdminUrl { get; set; }
    public List<string> RedirectUris { get; set; } = new();
    public List<string> WebOrigins { get; set; } = new();
    public bool ServiceAccountsEnabled { get; set; } = false;
    public bool DirectAccessGrantsEnabled { get; set; } = false;
    public bool AuthorizationServicesEnabled { get; set; } = false;
    public bool FrontChannelLogout { get; set; } = true;
    
    // Capability config
    public bool ClientAuthentication { get; set; } = true;
    public bool StandardFlow { get; set; } = true;
    public string? ClientSecret { get; set; }
    public Dictionary<string, List<string>> Attributes { get; set; } = new();
    public List<string> DefaultClientScopes { get; set; } = new();
    public List<string> OptionalClientScopes { get; set; } = new();
}

