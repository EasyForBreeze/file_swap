using new_assistant.Core.DTOs;

namespace new_assistant.Core.DTOs;

/// <summary>
/// ViewModel для компонента ClientRolesTab
/// Группирует связанные параметры для упрощения передачи данных
/// </summary>
public class ClientRolesTabViewModel
{
    /// <summary>
    /// Данные клиента
    /// </summary>
    public ClientDetailsDto ClientDetails { get; set; } = null!;

    /// <summary>
    /// Активная вкладка
    /// </summary>
    public string ActiveTab { get; set; } = "roles";

    /// <summary>
    /// Новое имя локальной роли
    /// </summary>
    public string NewLocalRole { get; set; } = string.Empty;

    /// <summary>
    /// Поисковый запрос для ролей
    /// </summary>
    public string RoleSearchTerm { get; set; } = string.Empty;

    /// <summary>
    /// Флаг выполнения поиска ролей
    /// </summary>
    public bool IsSearchingRoles { get; set; }

    /// <summary>
    /// Флаг показа спиннера поиска
    /// </summary>
    public bool ShowSearchSpinner { get; set; }

    /// <summary>
    /// Результаты поиска ролей
    /// </summary>
    public List<RoleSearchResult> RoleSearchResults { get; set; } = new();

    /// <summary>
    /// CSS класс для валидации поиска ролей
    /// </summary>
    public string RoleSearchValidationClass { get; set; } = string.Empty;
}

