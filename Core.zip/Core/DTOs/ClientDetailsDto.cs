using System;
using System.Collections.Generic;

namespace new_assistant.Core.DTOs;

/// <summary>
/// Детальная информация о клиенте для просмотра/редактирования.
/// Объединяет все аспекты информации о клиенте для обратной совместимости.
/// </summary>
/// <remarks>
/// Этот класс является композицией более специализированных DTOs:
/// - ClientBasicInfoDto - базовая информация
/// - ClientConfigurationDto - конфигурация
/// - ClientRolesDto - роли
/// - ClientEndpointsDto - эндпоинты и события
/// 
/// Для новых компонентов рекомендуется использовать специализированные DTOs напрямую.
/// </remarks>
public class ClientDetailsDto
{
    // Базовая информация
    public string Id { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool Enabled { get; set; } = true;
    public string Realm { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public string? PublicationStatus { get; set; }
    public string? TicketNumber { get; set; }
    public string? TicketUrl { get; set; }
    
    // Конфигурация
    public string Protocol { get; set; } = "openid-connect";
    public string ClientType { get; set; } = "confidential"; // public, confidential, bearer-only
    public string AccessType { get; set; } = "confidential"; // public, confidential, bearer-only
    public string? RootUrl { get; set; }
    public string? BaseUrl { get; set; }
    public string? AdminUrl { get; set; }
    public List<string> RedirectUris { get; set; } = new();
    public List<string> WebOrigins { get; set; } = new();
    public bool ServiceAccountsEnabled { get; set; } = false;
    public bool DirectAccessGrantsEnabled { get; set; } = false;
    public bool AuthorizationServicesEnabled { get; set; } = false;
    public bool FrontChannelLogout { get; set; } = true;
    
    // Capability config
    public bool ClientAuthentication { get; set; } = true;
    public bool StandardFlow { get; set; } = true;
    public string? ClientSecret { get; set; }
    public Dictionary<string, List<string>> Attributes { get; set; } = new();
    public List<string> DefaultClientScopes { get; set; } = new();
    public List<string> OptionalClientScopes { get; set; } = new();
    
    // Роли
    public List<string> LocalRoles { get; set; } = new();
    public List<string> ServiceRoles { get; set; } = new();
    
    // Эндпоинты и события
    public List<string> Endpoints { get; set; } = new();
    public List<ClientEventDto> Events { get; set; } = new();
    
    /// <summary>
    /// Преобразует ClientDetailsDto в ClientBasicInfoDto
    /// </summary>
    public ClientBasicInfoDto ToBasicInfo() => new()
    {
        Id = Id,
        ClientId = ClientId,
        Name = Name,
        Description = Description,
        Enabled = Enabled,
        Realm = Realm,
        CreatedAt = CreatedAt,
        UpdatedAt = UpdatedAt,
        PublicationStatus = PublicationStatus,
        TicketNumber = TicketNumber,
        TicketUrl = TicketUrl
    };
    
    /// <summary>
    /// Преобразует ClientDetailsDto в ClientConfigurationDto
    /// </summary>
    public ClientConfigurationDto ToConfiguration() => new()
    {
        Protocol = Protocol,
        ClientType = ClientType,
        AccessType = AccessType,
        RootUrl = RootUrl,
        BaseUrl = BaseUrl,
        AdminUrl = AdminUrl,
        RedirectUris = RedirectUris,
        WebOrigins = WebOrigins,
        ServiceAccountsEnabled = ServiceAccountsEnabled,
        DirectAccessGrantsEnabled = DirectAccessGrantsEnabled,
        AuthorizationServicesEnabled = AuthorizationServicesEnabled,
        FrontChannelLogout = FrontChannelLogout,
        ClientAuthentication = ClientAuthentication,
        StandardFlow = StandardFlow,
        ClientSecret = ClientSecret,
        Attributes = Attributes,
        DefaultClientScopes = DefaultClientScopes,
        OptionalClientScopes = OptionalClientScopes
    };
    
    /// <summary>
    /// Преобразует ClientDetailsDto в ClientRolesDto
    /// </summary>
    public ClientRolesDto ToRoles() => new()
    {
        LocalRoles = LocalRoles,
        ServiceRoles = ServiceRoles
    };
    
    /// <summary>
    /// Преобразует ClientDetailsDto в ClientEndpointsDto
    /// </summary>
    public ClientEndpointsDto ToEndpoints() => new()
    {
        Endpoints = Endpoints,
        Events = Events
    };
    
    /// <summary>
    /// Создает ClientDetailsDto из специализированных DTOs
    /// </summary>
    public static ClientDetailsDto FromComponents(
        ClientBasicInfoDto basicInfo,
        ClientConfigurationDto configuration,
        ClientRolesDto roles,
        ClientEndpointsDto endpoints)
    {
        return new ClientDetailsDto
        {
            // Basic info
            Id = basicInfo.Id,
            ClientId = basicInfo.ClientId,
            Name = basicInfo.Name,
            Description = basicInfo.Description,
            Enabled = basicInfo.Enabled,
            Realm = basicInfo.Realm,
            CreatedAt = basicInfo.CreatedAt,
            UpdatedAt = basicInfo.UpdatedAt,
            PublicationStatus = basicInfo.PublicationStatus,
            TicketNumber = basicInfo.TicketNumber,
            TicketUrl = basicInfo.TicketUrl,
            
            // Configuration
            Protocol = configuration.Protocol,
            ClientType = configuration.ClientType,
            AccessType = configuration.AccessType,
            RootUrl = configuration.RootUrl,
            BaseUrl = configuration.BaseUrl,
            AdminUrl = configuration.AdminUrl,
            RedirectUris = configuration.RedirectUris,
            WebOrigins = configuration.WebOrigins,
            ServiceAccountsEnabled = configuration.ServiceAccountsEnabled,
            DirectAccessGrantsEnabled = configuration.DirectAccessGrantsEnabled,
            AuthorizationServicesEnabled = configuration.AuthorizationServicesEnabled,
            FrontChannelLogout = configuration.FrontChannelLogout,
            ClientAuthentication = configuration.ClientAuthentication,
            StandardFlow = configuration.StandardFlow,
            ClientSecret = configuration.ClientSecret,
            Attributes = configuration.Attributes,
            DefaultClientScopes = configuration.DefaultClientScopes,
            OptionalClientScopes = configuration.OptionalClientScopes,
            
            // Roles
            LocalRoles = roles.LocalRoles,
            ServiceRoles = roles.ServiceRoles,
            
            // Endpoints
            Endpoints = endpoints.Endpoints,
            Events = endpoints.Events
        };
    }
}

/// <summary>
/// Событие клиента.
/// </summary>
public record ClientEventDto
{
    public string Id { get; init; } = string.Empty;
    public DateTime Time { get; init; }
    public string Type { get; init; } = string.Empty;
    public string? Details { get; init; }
    public string? UserId { get; init; }
    public string? IpAddress { get; init; }
}

/// <summary>
/// Результат поиска ролей для Service Account.
/// </summary>
public class RoleSearchResult
{
    public string RoleName { get; set; } = string.Empty;
    public string RoleId { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string Source { get; set; } = "realm"; // "realm" или "client"
    public string? ClientId { get; set; } // Для client roles
    public string? ClientName { get; set; } // Для client roles
    public string? ClientInternalId { get; set; } // Internal ID клиента для client roles
}

/// <summary>
/// Клиент с его ролями для поиска.
/// </summary>
public class ClientWithRoles
{
    public string ClientId { get; set; } = string.Empty;
    public string ClientName { get; set; } = string.Empty;
    public string InternalId { get; set; } = string.Empty;
    public List<RoleSearchResult> Roles { get; set; } = new();
}

/// <summary>
/// Service Account роль с информацией о её источнике.
/// </summary>
public class ServiceAccountRoleDto
{
    public string RoleName { get; set; } = string.Empty;
    public string RoleId { get; set; } = string.Empty;
    public string Source { get; set; } = "realm"; // "realm" или "client"
    public string? ClientId { get; set; } // Для client roles
    public string? ClientInternalId { get; set; } // Internal ID клиента для client roles
    
    /// <summary>
    /// Форматированное имя роли для отображения
    /// </summary>
    public string DisplayName => Source == "client" ? $"{ClientId}:{RoleName}" : RoleName;
}