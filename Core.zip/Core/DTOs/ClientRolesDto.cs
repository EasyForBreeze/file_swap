using System.Collections.Generic;

namespace new_assistant.Core.DTOs;

/// <summary>
/// Роли клиента
/// </summary>
public class ClientRolesDto
{
    public List<string> LocalRoles { get; set; } = new();
    public List<string> ServiceRoles { get; set; } = new();
}

