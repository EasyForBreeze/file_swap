namespace new_assistant.Core.DTOs;

/// <summary>
/// Результат валидации данных
/// </summary>
public class ValidationResult
{
    /// <summary>
    /// Список ошибок валидации
    /// </summary>
    public List<string> Errors { get; set; } = new();

    /// <summary>
    /// Флаг успешности валидации
    /// </summary>
    public bool IsValid => Errors.Count == 0;

    /// <summary>
    /// Создает успешный результат валидации
    /// </summary>
    public static ValidationResult Success() => new();

    /// <summary>
    /// Создает результат валидации с ошибками
    /// </summary>
    public static ValidationResult Failure(params string[] errors) => new()
    {
        Errors = errors.ToList()
    };

    /// <summary>
    /// Добавляет ошибку
    /// </summary>
    public void AddError(string error)
    {
        if (!string.IsNullOrWhiteSpace(error))
        {
            Errors.Add(error);
        }
    }
}

