namespace new_assistant.Core.DTOs;

/// <summary>
/// Класс для пагинированных ответов API
/// </summary>
/// <typeparam name="T">Тип элементов в коллекции</typeparam>
public class PagedResponse<T>
{
    /// <summary>
    /// Элементы текущей страницы
    /// </summary>
    public IReadOnlyList<T> Items { get; set; } = Array.Empty<T>();
    
    /// <summary>
    /// Номер текущей страницы (начинается с 1)
    /// </summary>
    public int Page { get; set; }
    
    /// <summary>
    /// Размер страницы
    /// </summary>
    public int PageSize { get; set; }
    
    /// <summary>
    /// Общее количество элементов
    /// </summary>
    public int TotalCount { get; set; }
    
    /// <summary>
    /// Общее количество страниц
    /// </summary>
    public int TotalPages => PageSize > 0 ? (int)Math.Ceiling((double)TotalCount / PageSize) : 0;
    
    /// <summary>
    /// Есть ли следующая страница
    /// </summary>
    public bool HasNextPage => Page < TotalPages;
    
    /// <summary>
    /// Есть ли предыдущая страница
    /// </summary>
    public bool HasPreviousPage => Page > 1;
}

