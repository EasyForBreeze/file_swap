using System;

namespace new_assistant.Core.DTOs;

/// <summary>
/// Базовая информация о клиенте
/// </summary>
public class ClientBasicInfoDto
{
    public string Id { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool Enabled { get; set; } = true;
    public string Realm { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public string? PublicationStatus { get; set; }
    public string? TicketNumber { get; set; }
    public string? TicketUrl { get; set; }
}

