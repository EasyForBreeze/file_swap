using System.ComponentModel.DataAnnotations;

namespace new_assistant.Core.DTOs;

/// <summary>
/// Модель для запроса назначения клиента пользователю
/// </summary>
public class AssignClientRequest
{
    /// <summary>
    /// Имя пользователя
    /// </summary>
    [Required(ErrorMessage = "Username обязателен")]
    [MinLength(2, ErrorMessage = "Username должен содержать минимум 2 символа")]
    public string Username { get; set; } = string.Empty;

    /// <summary>
    /// Идентификатор клиента
    /// </summary>
    [Required(ErrorMessage = "ClientId обязателен")]
    public string ClientId { get; set; } = string.Empty;

    /// <summary>
    /// Реалм
    /// </summary>
    [Required(ErrorMessage = "Realm обязателен")]
    public string Realm { get; set; } = string.Empty;
}

