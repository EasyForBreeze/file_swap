using System.Collections.Generic;

namespace new_assistant.Core.DTOs;

/// <summary>
/// Эндпоинты и события клиента
/// </summary>
public class ClientEndpointsDto
{
    public List<string> Endpoints { get; set; } = new();
    public List<ClientEventDto> Events { get; set; } = new();
}

