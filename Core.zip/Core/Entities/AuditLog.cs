using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace new_assistant.Core.Entities;

/// <summary>
/// Сущность для хранения логов аудита действий пользователей
/// </summary>
[Table("audit_logs")]
public class AuditLog
{
    /// <summary>
    /// Уникальный идентификатор записи аудита
    /// </summary>
    [Key]
    [Column("id")]
    public long Id { get; set; }

    /// <summary>
    /// Тип события (ClientCreated, ClientUpdated, ClientDeleted, AccessGranted, AccessRevoked, RoleAdded, RoleRemoved, SecretRegenerated, UserLogin)
    /// </summary>
    [Required]
    [Column("event_type")]
    [MaxLength(100)]
    // Note: Create index for performance: CREATE INDEX IX_audit_logs_event_type ON audit_logs(event_type);
    public string EventType { get; set; } = string.Empty;

    /// <summary>
    /// Имя пользователя, выполнившего действие
    /// </summary>
    [Required]
    [Column("username")]
    [MaxLength(255)]
    // Note: Create index for performance: CREATE INDEX IX_audit_logs_username ON audit_logs(username);
    public string Username { get; set; } = string.Empty;

    /// <summary>
    /// Client ID, над которым выполнено действие (если применимо)
    /// </summary>
    [Column("client_id")]
    [MaxLength(255)]
    // Note: Create index for performance: CREATE INDEX IX_audit_logs_client_id ON audit_logs(client_id);
    public string? ClientId { get; set; }

    /// <summary>
    /// Реалм, в котором выполнено действие (если применимо)
    /// </summary>
    [Column("realm")]
    [MaxLength(255)]
    // Note: Create index for performance: CREATE INDEX IX_audit_logs_realm ON audit_logs(realm);
    public string? Realm { get; set; }

    /// <summary>
    /// Целевой пользователь (для событий назначения/отзыва прав)
    /// </summary>
    [Column("target_username")]
    [MaxLength(255)]
    public string? TargetUsername { get; set; }

    /// <summary>
    /// Описание действия
    /// </summary>
    [Required]
    [Column("description")]
    [MaxLength(2000)]
    public string Description { get; set; } = string.Empty;

    /// <summary>
    /// Детали изменений в формате JSON (старые и новые значения)
    /// </summary>
    [Column("change_details")]
    [MaxLength(10000)]
    public string? ChangeDetails { get; set; }

    /// <summary>
    /// Дата и время события (UTC)
    /// </summary>
    [Required]
    [Column("created_at")]
    // Note: Create index for performance: CREATE INDEX IX_audit_logs_created_at ON audit_logs(created_at);
    public DateTime CreatedAt { get; set; }
}

