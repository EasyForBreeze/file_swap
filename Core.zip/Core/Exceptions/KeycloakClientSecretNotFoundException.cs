namespace new_assistant.Core.Exceptions;

/// <summary>
/// Исключение, которое выбрасывается когда client secret не найден в Keycloak
/// </summary>
public class KeycloakClientSecretNotFoundException : Exception
{
    /// <summary>
    /// Название реалма, в котором не найден секрет
    /// </summary>
    public string Realm { get; }
    
    /// <summary>
    /// Внутренний ID клиента, для которого не найден секрет
    /// </summary>
    public string ClientInternalId { get; }
    
    /// <summary>
    /// Инициализирует новый экземпляр класса KeycloakClientSecretNotFoundException
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента</param>
    public KeycloakClientSecretNotFoundException(string realm, string clientInternalId)
        : base($"Client secret not found for realm '{realm}' and client '{clientInternalId}'")
    {
        Realm = realm ?? throw new ArgumentNullException(nameof(realm));
        ClientInternalId = clientInternalId ?? throw new ArgumentNullException(nameof(clientInternalId));
    }
    
    /// <summary>
    /// Инициализирует новый экземпляр класса KeycloakClientSecretNotFoundException с внутренним исключением
    /// </summary>
    /// <param name="realm">Название реалма</param>
    /// <param name="clientInternalId">Внутренний ID клиента</param>
    /// <param name="innerException">Внутреннее исключение</param>
    public KeycloakClientSecretNotFoundException(string realm, string clientInternalId, Exception? innerException)
        : base($"Client secret not found for realm '{realm}' and client '{clientInternalId}'", innerException)
    {
        Realm = realm ?? throw new ArgumentNullException(nameof(realm));
        ClientInternalId = clientInternalId ?? throw new ArgumentNullException(nameof(clientInternalId));
    }
}

